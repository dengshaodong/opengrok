<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>
<a class="l" name="2" href="#2">2</a>NOTE:
<a class="l" name="3" href="#3">3</a>	This zip file is a eclipse project for common java platform, to use in android, export the source and change jars under lib dir to <a href="http://android-rtmp-client.googlecode.com/files/lib_without_logback.zip">http://android-rtmp-client.googlecode.com/files/lib_without_logback.zip</a> 
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a>&#27880;&#24847;&#65306;
<a class="l" name="7" href="#7">7</a>	&#36825;&#20010;&#21387;&#32553;&#21253;&#26159;&#19968;&#20010;eclipse&#24037;&#31243;&#65292;&#21487;&#30452;&#25509;&#22312;pc&#19978;&#36816;&#34892;&#65292;&#22914;&#26524;&#35201;&#29992;&#22312;android&#19978;&#65292;&#38656;&#35201;&#23558;&#20195;&#30721;&#23548;&#20986;&#65288;&#23548;&#25104;&#19968;&#20010;jar&#21253;),&#24182;&#23558;lib&#30446;&#24405;&#19979;&#30340;&#20381;&#36182;&#21253;&#26367;&#25442;&#25104;:<a href="http://android-rtmp-client.googlecode.com/files/lib_without_logback.zip">http://android-rtmp-client.googlecode.com/files/lib_without_logback.zip</a>
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a>
<a class="hl" name="10" href="#10">10</a>  &#27426;&#36814;&#25351;&#20986;bug&#12289;&#36129;&#29486;&#20195;&#30721;
<a class="l" name="11" href="#11">11</a>
<a class="l" name="12" href="#12">12</a>  <a href="/source/s?path=www.ryong21.com&amp;project=rtmp_client">www.ryong21.com</a>