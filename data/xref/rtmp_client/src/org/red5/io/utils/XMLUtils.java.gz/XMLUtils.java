<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["XMLUtils",49]]],["Package","xp",[["org.red5.io.utils",1]]],["Method","xmt",[["docToString",87],["docToString1",96],["docToString2",108],["stringToDoc",61]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=Reader&amp;project=rtmp_client">Reader</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=StringReader&amp;project=rtmp_client">StringReader</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=StringWriter&amp;project=rtmp_client">StringWriter</a>;
<a class="l" name="26" href="#26">26</a>
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=parsers&amp;project=rtmp_client">parsers</a>.<a href="/source/s?defs=DocumentBuilder&amp;project=rtmp_client">DocumentBuilder</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=parsers&amp;project=rtmp_client">parsers</a>.<a href="/source/s?defs=DocumentBuilderFactory&amp;project=rtmp_client">DocumentBuilderFactory</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=transform&amp;project=rtmp_client">transform</a>.<a href="/source/s?defs=OutputKeys&amp;project=rtmp_client">OutputKeys</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=transform&amp;project=rtmp_client">transform</a>.<a href="/source/s?defs=Result&amp;project=rtmp_client">Result</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=transform&amp;project=rtmp_client">transform</a>.<a href="/source/s?defs=Transformer&amp;project=rtmp_client">Transformer</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=transform&amp;project=rtmp_client">transform</a>.<a href="/source/s?defs=TransformerFactory&amp;project=rtmp_client">TransformerFactory</a>;
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=transform&amp;project=rtmp_client">transform</a>.<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=DOMSource&amp;project=rtmp_client">DOMSource</a>;
<a class="l" name="34" href="#34">34</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=transform&amp;project=rtmp_client">transform</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=StreamResult&amp;project=rtmp_client">StreamResult</a>;
<a class="l" name="35" href="#35">35</a>
<a class="l" name="36" href="#36">36</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=commons&amp;project=rtmp_client">commons</a>.<a href="/source/s?defs=lang&amp;project=rtmp_client">lang</a>.<a href="/source/s?defs=StringUtils&amp;project=rtmp_client">StringUtils</a>;
<a class="l" name="37" href="#37">37</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="38" href="#38">38</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="39" href="#39">39</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=w3c&amp;project=rtmp_client">w3c</a>.<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a>;
<a class="hl" name="40" href="#40">40</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=sax&amp;project=rtmp_client">sax</a>.<a href="/source/s?defs=InputSource&amp;project=rtmp_client">InputSource</a>;
<a class="l" name="41" href="#41">41</a>
<a class="l" name="42" href="#42">42</a><span class="c">/**
<a class="l" name="43" href="#43">43</a> * Misc XML utils
<a class="l" name="44" href="#44">44</a> *
<a class="l" name="45" href="#45">45</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="46" href="#46">46</a> * <strong>@author</strong> Luke Hubbard, Codegent Ltd (luke@codegent.com)
<a class="l" name="47" href="#47">47</a> * <strong>@author</strong> Paul Gregoire (mondain@gmail.com)
<a class="l" name="48" href="#48">48</a> */</span>
<a class="l" name="49" href="#49">49</a><b>public</b> <b>class</b> <a class="xc" name="XMLUtils"/><a href="/source/s?refs=XMLUtils&amp;project=rtmp_client" class="xc">XMLUtils</a> {
<a class="hl" name="50" href="#50">50</a>    <span class="c">/**
<a class="l" name="51" href="#51">51</a>     * Logger
<a class="l" name="52" href="#52">52</a>     */</span>
<a class="l" name="53" href="#53">53</a>	<b>protected</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a class="d" href="#XMLUtils">XMLUtils</a>.<b>class</b>);
<a class="l" name="54" href="#54">54</a>
<a class="l" name="55" href="#55">55</a>    <span class="c">/**
<a class="l" name="56" href="#56">56</a>     * Converts string representation of XML into Document
<a class="l" name="57" href="#57">57</a>     * <strong>@param</strong> <em>str</em>              String representation of XML
<a class="l" name="58" href="#58">58</a>     * <strong>@return</strong>                 DOM object
<a class="l" name="59" href="#59">59</a>     * <strong>@throws</strong> <em>IOException</em>     I/O exception
<a class="hl" name="60" href="#60">60</a>     */</span>
<a class="l" name="61" href="#61">61</a>    <b>public</b> <b>static</b> <a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a> <a class="xmt" name="stringToDoc"/><a href="/source/s?refs=stringToDoc&amp;project=rtmp_client" class="xmt">stringToDoc</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="str"/><a href="/source/s?refs=str&amp;project=rtmp_client" class="xa">str</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="62" href="#62">62</a>    	<b>if</b> (<a href="/source/s?defs=StringUtils&amp;project=rtmp_client">StringUtils</a>.<a href="/source/s?defs=isNotEmpty&amp;project=rtmp_client">isNotEmpty</a>(<a class="d" href="#str">str</a>)) {
<a class="l" name="63" href="#63">63</a>    		<b>try</b> {
<a class="l" name="64" href="#64">64</a>    			<a href="/source/s?defs=Reader&amp;project=rtmp_client">Reader</a> <a href="/source/s?defs=reader&amp;project=rtmp_client">reader</a> = <b>new</b> <a href="/source/s?defs=StringReader&amp;project=rtmp_client">StringReader</a>(<a class="d" href="#str">str</a>);
<a class="l" name="65" href="#65">65</a>
<a class="l" name="66" href="#66">66</a>    			<a href="/source/s?defs=DocumentBuilder&amp;project=rtmp_client">DocumentBuilder</a> <a href="/source/s?defs=db&amp;project=rtmp_client">db</a> = <a href="/source/s?defs=DocumentBuilderFactory&amp;project=rtmp_client">DocumentBuilderFactory</a>.<a href="/source/s?defs=newInstance&amp;project=rtmp_client">newInstance</a>()
<a class="l" name="67" href="#67">67</a>    					.<a href="/source/s?defs=newDocumentBuilder&amp;project=rtmp_client">newDocumentBuilder</a>();
<a class="l" name="68" href="#68">68</a>    			<a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a> <a href="/source/s?defs=doc&amp;project=rtmp_client">doc</a> = <a href="/source/s?defs=db&amp;project=rtmp_client">db</a>.<a href="/source/s?defs=parse&amp;project=rtmp_client">parse</a>(<b>new</b> <a href="/source/s?defs=InputSource&amp;project=rtmp_client">InputSource</a>(<a href="/source/s?defs=reader&amp;project=rtmp_client">reader</a>));
<a class="l" name="69" href="#69">69</a>
<a class="hl" name="70" href="#70">70</a>    			<a href="/source/s?defs=reader&amp;project=rtmp_client">reader</a>.<a href="/source/s?defs=close&amp;project=rtmp_client">close</a>();
<a class="l" name="71" href="#71">71</a>
<a class="l" name="72" href="#72">72</a>    			<b>return</b> <a href="/source/s?defs=doc&amp;project=rtmp_client">doc</a>;
<a class="l" name="73" href="#73">73</a>    		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> <a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>) {
<a class="l" name="74" href="#74">74</a>    			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"String: {}"</span>, <a class="d" href="#str">str</a>);
<a class="l" name="75" href="#75">75</a>    			<b>throw</b> <b>new</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<a href="/source/s?defs=format&amp;project=rtmp_client">format</a>(<span class="s">"Error converting from string to doc %s"</span>, <a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>.<a href="/source/s?defs=getMessage&amp;project=rtmp_client">getMessage</a>()));
<a class="l" name="76" href="#76">76</a>    		}
<a class="l" name="77" href="#77">77</a>    	} <b>else</b> {
<a class="l" name="78" href="#78">78</a>    		<b>throw</b> <b>new</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>(<span class="s">"Error - could not convert empty string to doc"</span>);
<a class="l" name="79" href="#79">79</a>    	}
<a class="hl" name="80" href="#80">80</a>	}
<a class="l" name="81" href="#81">81</a>
<a class="l" name="82" href="#82">82</a>    <span class="c">/**
<a class="l" name="83" href="#83">83</a>     * Converts doc to String
<a class="l" name="84" href="#84">84</a>     * <strong>@param</strong> <em>dom</em>            DOM object to convert
<a class="l" name="85" href="#85">85</a>     * <strong>@return</strong>               XML as String
<a class="l" name="86" href="#86">86</a>     */</span>
<a class="l" name="87" href="#87">87</a>    <b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="docToString"/><a href="/source/s?refs=docToString&amp;project=rtmp_client" class="xmt">docToString</a>(<a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a> <a class="xa" name="dom"/><a href="/source/s?refs=dom&amp;project=rtmp_client" class="xa">dom</a>) {
<a class="l" name="88" href="#88">88</a>		<b>return</b> <a class="d" href="#XMLUtils">XMLUtils</a>.<a class="d" href="#docToString1">docToString1</a>(<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>);
<a class="l" name="89" href="#89">89</a>	}
<a class="hl" name="90" href="#90">90</a>
<a class="l" name="91" href="#91">91</a>	<span class="c">/**
<a class="l" name="92" href="#92">92</a>	 * Convert a DOM tree into a String using Dom2Writer
<a class="l" name="93" href="#93">93</a>     * <strong>@return</strong>               XML as String
<a class="l" name="94" href="#94">94</a>     * <strong>@param</strong> <em>dom</em>            DOM object to convert
<a class="l" name="95" href="#95">95</a>     */</span>
<a class="l" name="96" href="#96">96</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="docToString1"/><a href="/source/s?refs=docToString1&amp;project=rtmp_client" class="xmt">docToString1</a>(<a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a> <a class="xa" name="dom"/><a href="/source/s?refs=dom&amp;project=rtmp_client" class="xa">dom</a>) {
<a class="l" name="97" href="#97">97</a>		<a href="/source/s?defs=StringWriter&amp;project=rtmp_client">StringWriter</a> <a href="/source/s?defs=sw&amp;project=rtmp_client">sw</a> = <b>new</b> <a href="/source/s?defs=StringWriter&amp;project=rtmp_client">StringWriter</a>();
<a class="l" name="98" href="#98">98</a>		<a href="/source/s?defs=DOM2Writer&amp;project=rtmp_client">DOM2Writer</a>.<a href="/source/s?defs=serializeAsXML&amp;project=rtmp_client">serializeAsXML</a>(<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>, <a href="/source/s?defs=sw&amp;project=rtmp_client">sw</a>);
<a class="l" name="99" href="#99">99</a>		<b>return</b> <a href="/source/s?defs=sw&amp;project=rtmp_client">sw</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>();
<a class="hl" name="100" href="#100">100</a>	}
<a class="l" name="101" href="#101">101</a>
<a class="l" name="102" href="#102">102</a>	<span class="c">/**
<a class="l" name="103" href="#103">103</a>	 * Convert a DOM tree into a String using transform
<a class="l" name="104" href="#104">104</a>     * <strong>@param</strong> <em>domDoc</em>                  DOM object
<a class="l" name="105" href="#105">105</a>     * <strong>@throws</strong> <em>java.io.IOException</em>    I/O exception
<a class="l" name="106" href="#106">106</a>     * <strong>@return</strong>                        XML as String
<a class="l" name="107" href="#107">107</a>     */</span>
<a class="l" name="108" href="#108">108</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="docToString2"/><a href="/source/s?refs=docToString2&amp;project=rtmp_client" class="xmt">docToString2</a>(<a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a> <a class="xa" name="domDoc"/><a href="/source/s?refs=domDoc&amp;project=rtmp_client" class="xa">domDoc</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="109" href="#109">109</a>		<b>try</b> {
<a class="hl" name="110" href="#110">110</a>			<a href="/source/s?defs=TransformerFactory&amp;project=rtmp_client">TransformerFactory</a> <a href="/source/s?defs=transFact&amp;project=rtmp_client">transFact</a> = <a href="/source/s?defs=TransformerFactory&amp;project=rtmp_client">TransformerFactory</a>.<a href="/source/s?defs=newInstance&amp;project=rtmp_client">newInstance</a>();
<a class="l" name="111" href="#111">111</a>			<a href="/source/s?defs=Transformer&amp;project=rtmp_client">Transformer</a> <a href="/source/s?defs=trans&amp;project=rtmp_client">trans</a> = <a href="/source/s?defs=transFact&amp;project=rtmp_client">transFact</a>.<a href="/source/s?defs=newTransformer&amp;project=rtmp_client">newTransformer</a>();
<a class="l" name="112" href="#112">112</a>			<a href="/source/s?defs=trans&amp;project=rtmp_client">trans</a>.<a href="/source/s?defs=setOutputProperty&amp;project=rtmp_client">setOutputProperty</a>(<a href="/source/s?defs=OutputKeys&amp;project=rtmp_client">OutputKeys</a>.<a href="/source/s?defs=INDENT&amp;project=rtmp_client">INDENT</a>, <span class="s">"no"</span>);
<a class="l" name="113" href="#113">113</a>			<a href="/source/s?defs=StringWriter&amp;project=rtmp_client">StringWriter</a> <a href="/source/s?defs=sw&amp;project=rtmp_client">sw</a> = <b>new</b> <a href="/source/s?defs=StringWriter&amp;project=rtmp_client">StringWriter</a>();
<a class="l" name="114" href="#114">114</a>			<a href="/source/s?defs=Result&amp;project=rtmp_client">Result</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>new</b> <a href="/source/s?defs=StreamResult&amp;project=rtmp_client">StreamResult</a>(<a href="/source/s?defs=sw&amp;project=rtmp_client">sw</a>);
<a class="l" name="115" href="#115">115</a>			<a href="/source/s?defs=trans&amp;project=rtmp_client">trans</a>.<a href="/source/s?defs=transform&amp;project=rtmp_client">transform</a>(<b>new</b> <a href="/source/s?defs=DOMSource&amp;project=rtmp_client">DOMSource</a>(<a class="d" href="#domDoc">domDoc</a>), <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>);
<a class="l" name="116" href="#116">116</a>			<b>return</b> <a href="/source/s?defs=sw&amp;project=rtmp_client">sw</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>();
<a class="l" name="117" href="#117">117</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> <a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>) {
<a class="l" name="118" href="#118">118</a>			<b>throw</b> <b>new</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<a href="/source/s?defs=format&amp;project=rtmp_client">format</a>(<span class="s">"Error converting from doc to string %s"</span>, <a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>.<a href="/source/s?defs=getMessage&amp;project=rtmp_client">getMessage</a>()));
<a class="l" name="119" href="#119">119</a>		}
<a class="hl" name="120" href="#120">120</a>	}
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>}
<a class="l" name="123" href="#123">123</a>