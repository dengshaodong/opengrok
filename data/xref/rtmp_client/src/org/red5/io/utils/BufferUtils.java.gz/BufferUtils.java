<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["BufferUtils",31]]],["Package","xp",[["org.red5.io.utils",1]]],["Method","xmt",[["put",93],["readMediumInt",71],["readUnsignedMediumInt",55],["writeMediumInt",41]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a><span class="c">/**
<a class="l" name="25" href="#25">25</a> * Buffer Utility class which <a href="/source/s?path=reads/">reads</a>/<a href="/source/s?path=reads/writes">writes</a> intergers to the <a href="/source/s?path=input/">input</a>/<a href="/source/s?path=input/output">output</a> buffer
<a class="l" name="26" href="#26">26</a> *
<a class="l" name="27" href="#27">27</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="28" href="#28">28</a> * <strong>@author</strong> Luke Hubbard, Codegent Ltd (luke@codegent.com)
<a class="l" name="29" href="#29">29</a> * <strong>@author</strong> Andy Shaules (bowljoman@hotmail.com)
<a class="hl" name="30" href="#30">30</a> */</span>
<a class="l" name="31" href="#31">31</a><b>public</b> <b>class</b> <a class="xc" name="BufferUtils"/><a href="/source/s?refs=BufferUtils&amp;project=rtmp_client" class="xc">BufferUtils</a> {
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a>	<span class="c">//private static Logger log = LoggerFactory.getLogger(BufferUtils.class);</span>
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a>	<span class="c">/**
<a class="l" name="36" href="#36">36</a>	 * Writes a Medium Int to the output buffer
<a class="l" name="37" href="#37">37</a>	 *
<a class="l" name="38" href="#38">38</a>	 * <strong>@param</strong> <em>out</em>          Container to write to
<a class="l" name="39" href="#39">39</a>	 * <strong>@param</strong> <em>value</em>        Integer to write
<a class="hl" name="40" href="#40">40</a>	 */</span>
<a class="l" name="41" href="#41">41</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="writeMediumInt"/><a href="/source/s?refs=writeMediumInt&amp;project=rtmp_client" class="xmt">writeMediumInt</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>, <b>int</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="42" href="#42">42</a>		<b>byte</b>[] <a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a> = <b>new</b> <b>byte</b>[<span class="n">3</span>];
<a class="l" name="43" href="#43">43</a>		<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">0</span>] = (<b>byte</b>) ((<a class="d" href="#value">value</a> &gt;&gt;&gt; <span class="n">16</span>) &amp; <span class="n">0x000000FF</span>);
<a class="l" name="44" href="#44">44</a>		<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">1</span>] = (<b>byte</b>) ((<a class="d" href="#value">value</a> &gt;&gt;&gt; <span class="n">8</span>) &amp; <span class="n">0x000000FF</span>);
<a class="l" name="45" href="#45">45</a>		<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">2</span>] = (<b>byte</b>) (<a class="d" href="#value">value</a> &amp; <span class="n">0x00FF</span>);
<a class="l" name="46" href="#46">46</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a class="d" href="#put">put</a>(<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>);
<a class="l" name="47" href="#47">47</a>	}
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>	<span class="c">/**
<a class="hl" name="50" href="#50">50</a>	 * Reads an unsigned Medium Int from the in buffer
<a class="l" name="51" href="#51">51</a>	 *
<a class="l" name="52" href="#52">52</a>	 * <strong>@param</strong> <em>in</em>           Source
<a class="l" name="53" href="#53">53</a>	 * <strong>@return</strong> int         Integer value
<a class="l" name="54" href="#54">54</a>	 */</span>
<a class="l" name="55" href="#55">55</a>	<b>public</b> <b>static</b> <b>int</b> <a class="xmt" name="readUnsignedMediumInt"/><a href="/source/s?refs=readUnsignedMediumInt&amp;project=rtmp_client" class="xmt">readUnsignedMediumInt</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="56" href="#56">56</a>		<b>byte</b>[] <a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a> = <b>new</b> <b>byte</b>[<span class="n">3</span>];
<a class="l" name="57" href="#57">57</a>		<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>);
<a class="l" name="58" href="#58">58</a>		<b>int</b> <a href="/source/s?defs=val&amp;project=rtmp_client">val</a> = <span class="n">0</span>;
<a class="l" name="59" href="#59">59</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += (<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">0</span>] &amp; <span class="n">0xFF</span>) * <span class="n">256</span> * <span class="n">256</span>;
<a class="hl" name="60" href="#60">60</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += (<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">1</span>] &amp; <span class="n">0xFF</span>) * <span class="n">256</span>;
<a class="l" name="61" href="#61">61</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += (<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">2</span>] &amp; <span class="n">0xFF</span>);
<a class="l" name="62" href="#62">62</a>		<b>return</b> <a href="/source/s?defs=val&amp;project=rtmp_client">val</a>;
<a class="l" name="63" href="#63">63</a>	}
<a class="l" name="64" href="#64">64</a>
<a class="l" name="65" href="#65">65</a>	<span class="c">/**
<a class="l" name="66" href="#66">66</a>	 * Reads a Medium Int to the in buffer
<a class="l" name="67" href="#67">67</a>	 *
<a class="l" name="68" href="#68">68</a>	 * <strong>@param</strong> <em>in</em>           Source
<a class="l" name="69" href="#69">69</a>	 * <strong>@return</strong> int         Medium int
<a class="hl" name="70" href="#70">70</a>	 */</span>
<a class="l" name="71" href="#71">71</a>	<b>public</b> <b>static</b> <b>int</b> <a class="xmt" name="readMediumInt"/><a href="/source/s?refs=readMediumInt&amp;project=rtmp_client" class="xmt">readMediumInt</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="72" href="#72">72</a>		<b>byte</b>[] <a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a> = <b>new</b> <b>byte</b>[<span class="n">3</span>];
<a class="l" name="73" href="#73">73</a>		<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>);
<a class="l" name="74" href="#74">74</a>		<b>int</b> <a href="/source/s?defs=val&amp;project=rtmp_client">val</a> = <span class="n">0</span>;
<a class="l" name="75" href="#75">75</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += <a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">0</span>] * <span class="n">256</span> * <span class="n">256</span>;
<a class="l" name="76" href="#76">76</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += <a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">1</span>] * <span class="n">256</span>;
<a class="l" name="77" href="#77">77</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += <a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">2</span>];
<a class="l" name="78" href="#78">78</a>		<b>if</b> (<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> &lt; <span class="n">0</span>) {
<a class="l" name="79" href="#79">79</a>			<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += <span class="n">256</span>;
<a class="hl" name="80" href="#80">80</a>		}
<a class="l" name="81" href="#81">81</a>		<b>return</b> <a href="/source/s?defs=val&amp;project=rtmp_client">val</a>;
<a class="l" name="82" href="#82">82</a>	}
<a class="l" name="83" href="#83">83</a>
<a class="l" name="84" href="#84">84</a>	<span class="c">/**
<a class="l" name="85" href="#85">85</a>	 * Puts input buffer stream to output buffer
<a class="l" name="86" href="#86">86</a>	 * and returns number of bytes written
<a class="l" name="87" href="#87">87</a>	 * <strong>@param</strong> <em>out</em>                Output buffer
<a class="l" name="88" href="#88">88</a>	 * <strong>@param</strong> <em>in</em>                 Input buffer
<a class="l" name="89" href="#89">89</a>	 * <strong>@param</strong> <em>numBytesMax</em>        Number of bytes max
<a class="hl" name="90" href="#90">90</a>	 * <strong>@return</strong> int               Number of bytes written
<a class="l" name="91" href="#91">91</a>	 */</span>
<a class="l" name="92" href="#92">92</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unused"</span>)
<a class="l" name="93" href="#93">93</a>	<b>public</b> <b>final</b> <b>static</b> <b>int</b> <a class="xmt" name="put"/><a href="/source/s?refs=put&amp;project=rtmp_client" class="xmt">put</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>, <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>, <b>int</b> <a class="xa" name="numBytesMax"/><a href="/source/s?refs=numBytesMax&amp;project=rtmp_client" class="xa">numBytesMax</a>) {
<a class="l" name="94" href="#94">94</a>		<span class="c">//log.trace("Put - out buffer: {} in buffer: {} max bytes: {}", new Object[]{out, in, numBytesMax});</span>
<a class="l" name="95" href="#95">95</a>		<b>int</b> <a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>();
<a class="l" name="96" href="#96">96</a>		<b>int</b> <a href="/source/s?defs=capacity&amp;project=rtmp_client">capacity</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=capacity&amp;project=rtmp_client">capacity</a>();
<a class="l" name="97" href="#97">97</a>		<b>int</b> <a href="/source/s?defs=numBytesRead&amp;project=rtmp_client">numBytesRead</a> = (<a class="d" href="#numBytesMax">numBytesMax</a> &gt; <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>()) ? <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>() : <a class="d" href="#numBytesMax">numBytesMax</a>;
<a class="l" name="98" href="#98">98</a>		<span class="c">//log.trace("limit: {} capacity: {} bytes read: {}", new Object[]{limit, capacity, numBytesRead});</span>
<a class="l" name="99" href="#99">99</a>		<span class="c">// buffer.limit</span>
<a class="hl" name="100" href="#100">100</a>		<span class="c">// The new limit value, must be non-negative and no larger than this buffer's capacity</span>
<a class="l" name="101" href="#101">101</a>		<span class="c">// <a href="http://java.sun.com/j2se/1.4.2/docs/api/java/nio/Buffer.html">http://java.sun.com/j2se/1.4.2/docs/api/java/nio/Buffer.html</a>#limit(int);</span>
<a class="l" name="102" href="#102">102</a>		<span class="c">// This is causing decoding error by raising RuntimeException IllegalArgumentError in</span>
<a class="l" name="103" href="#103">103</a>		<span class="c">// RTMPProtocolDecoder.decode to ProtocolException.</span>
<a class="l" name="104" href="#104">104</a>		<b>int</b> <a href="/source/s?defs=thisLimit&amp;project=rtmp_client">thisLimit</a> = (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() + <a href="/source/s?defs=numBytesRead&amp;project=rtmp_client">numBytesRead</a> &lt;= <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=capacity&amp;project=rtmp_client">capacity</a>()) ? <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() + <a href="/source/s?defs=numBytesRead&amp;project=rtmp_client">numBytesRead</a> : <a href="/source/s?defs=capacity&amp;project=rtmp_client">capacity</a>;
<a class="l" name="105" href="#105">105</a>		<span class="c">//somehow the "in" buffer becomes null here occasionally</span>
<a class="l" name="106" href="#106">106</a>		<b>if</b> (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="107" href="#107">107</a>    		<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(<a href="/source/s?defs=thisLimit&amp;project=rtmp_client">thisLimit</a>);
<a class="l" name="108" href="#108">108</a>    		<span class="c">// any implication to giving output buffer in with limit set to capacity?</span>
<a class="l" name="109" href="#109">109</a>    		<span class="c">// Reduces numBytesRead, triggers continueDecode?</span>
<a class="hl" name="110" href="#110">110</a>    		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a class="d" href="#put">put</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="111" href="#111">111</a>		} <b>else</b> {
<a class="l" name="112" href="#112">112</a>			<a href="/source/s?defs=numBytesRead&amp;project=rtmp_client">numBytesRead</a> = <span class="n">0</span>;
<a class="l" name="113" href="#113">113</a>		}
<a class="l" name="114" href="#114">114</a>		<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>);
<a class="l" name="115" href="#115">115</a>		<b>return</b> <a href="/source/s?defs=numBytesRead&amp;project=rtmp_client">numBytesRead</a>;
<a class="l" name="116" href="#116">116</a>	}
<a class="l" name="117" href="#117">117</a>
<a class="l" name="118" href="#118">118</a>}
<a class="l" name="119" href="#119">119</a>