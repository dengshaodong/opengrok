<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["DOM2Writer",37]]],["Package","xp",[["org.red5.io.utils",1]]],["Method","xmt",[["print",61],["serializeAsXML",47]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * Copyright 2001-2004 The Apache Software Foundation.
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Licensed under the Apache License, Version 2.0 (the "License");
<a class="l" name="7" href="#7">7</a> * you may not use this file except in compliance with the License.
<a class="l" name="8" href="#8">8</a> * You may obtain a copy of the License at
<a class="l" name="9" href="#9">9</a> *
<a class="hl" name="10" href="#10">10</a> *      <a href="http://www.apache.org/licenses/LICENSE-2.0">http://www.apache.org/licenses/LICENSE-2.0</a>
<a class="l" name="11" href="#11">11</a> *
<a class="l" name="12" href="#12">12</a> * Unless required by applicable law or agreed to in writing, software
<a class="l" name="13" href="#13">13</a> * distributed under the License is distributed on an "AS IS" BASIS,
<a class="l" name="14" href="#14">14</a> * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
<a class="l" name="15" href="#15">15</a> * See the License for the specific language governing permissions and
<a class="l" name="16" href="#16">16</a> * limitations under the License.
<a class="l" name="17" href="#17">17</a> */</span>
<a class="l" name="18" href="#18">18</a>
<a class="l" name="19" href="#19">19</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=PrintWriter&amp;project=rtmp_client">PrintWriter</a>;
<a class="hl" name="20" href="#20">20</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=Writer&amp;project=rtmp_client">Writer</a>;
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=w3c&amp;project=rtmp_client">w3c</a>.<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=Attr&amp;project=rtmp_client">Attr</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=w3c&amp;project=rtmp_client">w3c</a>.<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=NamedNodeMap&amp;project=rtmp_client">NamedNodeMap</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=w3c&amp;project=rtmp_client">w3c</a>.<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=Node&amp;project=rtmp_client">Node</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=w3c&amp;project=rtmp_client">w3c</a>.<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=NodeList&amp;project=rtmp_client">NodeList</a>;
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a><span class="c">/**
<a class="hl" name="30" href="#30">30</a> * This class is a utility to serialize a DOM node as XML. This class uses the
<a class="l" name="31" href="#31">31</a> * &lt;code&gt;DOM Level 2&lt;/code&gt; APIs. The main difference between this class and
<a class="l" name="32" href="#32">32</a> * DOMWriter is that this class generates and prints out namespace declarations.
<a class="l" name="33" href="#33">33</a> *
<a class="l" name="34" href="#34">34</a> * <strong>@author</strong> Matthew J. Duftler (duftler@us.ibm.com)
<a class="l" name="35" href="#35">35</a> * <strong>@author</strong> Joseph Kesselman
<a class="l" name="36" href="#36">36</a> */</span>
<a class="l" name="37" href="#37">37</a><b>public</b> <b>class</b> <a class="xc" name="DOM2Writer"/><a href="/source/s?refs=DOM2Writer&amp;project=rtmp_client" class="xc">DOM2Writer</a> {
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>	<b>private</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="logger"/><a href="/source/s?refs=logger&amp;project=rtmp_client" class="xfld">logger</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a class="d" href="#DOM2Writer">DOM2Writer</a>.<b>class</b>);
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a>	<span class="c">/**
<a class="l" name="42" href="#42">42</a>	 * Serialize this node into the writer as XML.
<a class="l" name="43" href="#43">43</a>	 *
<a class="l" name="44" href="#44">44</a>	 * <strong>@param</strong> <em>writer</em> Writer object
<a class="l" name="45" href="#45">45</a>	 * <strong>@param</strong> <em>node</em>  DOM node
<a class="l" name="46" href="#46">46</a>	 */</span>
<a class="l" name="47" href="#47">47</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="serializeAsXML"/><a href="/source/s?refs=serializeAsXML&amp;project=rtmp_client" class="xmt">serializeAsXML</a>(<a href="/source/s?defs=Node&amp;project=rtmp_client">Node</a> <a class="xa" name="node"/><a href="/source/s?refs=node&amp;project=rtmp_client" class="xa">node</a>, <a href="/source/s?defs=Writer&amp;project=rtmp_client">Writer</a> <a class="xa" name="writer"/><a href="/source/s?refs=writer&amp;project=rtmp_client" class="xa">writer</a>) {
<a class="l" name="48" href="#48">48</a>		<a href="/source/s?defs=PrintWriter&amp;project=rtmp_client">PrintWriter</a> <a class="d" href="#out">out</a> = <b>new</b> <a href="/source/s?defs=PrintWriter&amp;project=rtmp_client">PrintWriter</a>(<a class="d" href="#writer">writer</a>);
<a class="l" name="49" href="#49">49</a>		<a class="d" href="#print">print</a>(<a href="/source/s?defs=node&amp;project=rtmp_client">node</a>, <a class="d" href="#out">out</a>);
<a class="hl" name="50" href="#50">50</a>		<a class="d" href="#out">out</a>.<a href="/source/s?defs=flush&amp;project=rtmp_client">flush</a>();
<a class="l" name="51" href="#51">51</a>	}
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>	<span class="c">/**
<a class="l" name="54" href="#54">54</a>	 * Dumps DOM node
<a class="l" name="55" href="#55">55</a>	 *
<a class="l" name="56" href="#56">56</a>	 * <strong>@param</strong> <em>node</em>
<a class="l" name="57" href="#57">57</a>	 *            Node to dump
<a class="l" name="58" href="#58">58</a>	 * <strong>@param</strong> <em>out</em>
<a class="l" name="59" href="#59">59</a>	 *            Writer object
<a class="hl" name="60" href="#60">60</a>	 */</span>
<a class="l" name="61" href="#61">61</a>	<b>private</b> <b>static</b> <b>void</b> <a class="xmt" name="print"/><a href="/source/s?refs=print&amp;project=rtmp_client" class="xmt">print</a>(<a href="/source/s?defs=Node&amp;project=rtmp_client">Node</a> <a class="xa" name="node"/><a href="/source/s?refs=node&amp;project=rtmp_client" class="xa">node</a>, <a href="/source/s?defs=PrintWriter&amp;project=rtmp_client">PrintWriter</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>) {
<a class="l" name="62" href="#62">62</a>		<b>if</b> (<a href="/source/s?defs=node&amp;project=rtmp_client">node</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="63" href="#63">63</a>			<b>return</b>;
<a class="l" name="64" href="#64">64</a>		}
<a class="l" name="65" href="#65">65</a>
<a class="l" name="66" href="#66">66</a>		<b>boolean</b> <a href="/source/s?defs=hasChildren&amp;project=rtmp_client">hasChildren</a> = <b>false</b>;
<a class="l" name="67" href="#67">67</a>		<b>int</b> <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <a href="/source/s?defs=node&amp;project=rtmp_client">node</a>.<a href="/source/s?defs=getNodeType&amp;project=rtmp_client">getNodeType</a>();
<a class="l" name="68" href="#68">68</a>		<a href="/source/s?defs=NodeList&amp;project=rtmp_client">NodeList</a> <a href="/source/s?defs=children&amp;project=rtmp_client">children</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="69" href="#69">69</a>		<b>switch</b> (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>) {
<a class="hl" name="70" href="#70">70</a>			<b>case</b> <a href="/source/s?defs=Node&amp;project=rtmp_client">Node</a>.<a href="/source/s?defs=DOCUMENT_NODE&amp;project=rtmp_client">DOCUMENT_NODE</a>:
<a class="l" name="71" href="#71">71</a>				<a href="/source/s?defs=children&amp;project=rtmp_client">children</a> = <a href="/source/s?defs=node&amp;project=rtmp_client">node</a>.<a href="/source/s?defs=getChildNodes&amp;project=rtmp_client">getChildNodes</a>();
<a class="l" name="72" href="#72">72</a>				<b>if</b> (<a href="/source/s?defs=children&amp;project=rtmp_client">children</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="73" href="#73">73</a>					<b>int</b> <a href="/source/s?defs=numChildren&amp;project=rtmp_client">numChildren</a> = <a href="/source/s?defs=children&amp;project=rtmp_client">children</a>.<a href="/source/s?defs=getLength&amp;project=rtmp_client">getLength</a>();
<a class="l" name="74" href="#74">74</a>					<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=numChildren&amp;project=rtmp_client">numChildren</a>; i++) {
<a class="l" name="75" href="#75">75</a>						<a class="d" href="#print">print</a>(<a href="/source/s?defs=children&amp;project=rtmp_client">children</a>.<a href="/source/s?defs=item&amp;project=rtmp_client">item</a>(i), <a class="d" href="#out">out</a>);
<a class="l" name="76" href="#76">76</a>					}
<a class="l" name="77" href="#77">77</a>				}
<a class="l" name="78" href="#78">78</a>				<b>break</b>;
<a class="l" name="79" href="#79">79</a>			<b>case</b> <a href="/source/s?defs=Node&amp;project=rtmp_client">Node</a>.<a href="/source/s?defs=ELEMENT_NODE&amp;project=rtmp_client">ELEMENT_NODE</a>:
<a class="hl" name="80" href="#80">80</a>				<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<span class="s">'&lt;'</span>);
<a class="l" name="81" href="#81">81</a>				<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<a href="/source/s?defs=node&amp;project=rtmp_client">node</a>.<a href="/source/s?defs=getNodeName&amp;project=rtmp_client">getNodeName</a>());
<a class="l" name="82" href="#82">82</a>				<b>if</b> (<a href="/source/s?defs=node&amp;project=rtmp_client">node</a>.<a href="/source/s?defs=hasAttributes&amp;project=rtmp_client">hasAttributes</a>()) {
<a class="l" name="83" href="#83">83</a>					<a href="/source/s?defs=NamedNodeMap&amp;project=rtmp_client">NamedNodeMap</a> <a href="/source/s?defs=attrs&amp;project=rtmp_client">attrs</a> = <a href="/source/s?defs=node&amp;project=rtmp_client">node</a>.<a href="/source/s?defs=getAttributes&amp;project=rtmp_client">getAttributes</a>();
<a class="l" name="84" href="#84">84</a>					<b>int</b> <a href="/source/s?defs=len&amp;project=rtmp_client">len</a> = (<a href="/source/s?defs=attrs&amp;project=rtmp_client">attrs</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) ? <a href="/source/s?defs=attrs&amp;project=rtmp_client">attrs</a>.<a href="/source/s?defs=getLength&amp;project=rtmp_client">getLength</a>() : <span class="n">0</span>;
<a class="l" name="85" href="#85">85</a>					<b>for</b> (<b>int</b> a = <span class="n">0</span>; a &lt; <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>; a++) {
<a class="l" name="86" href="#86">86</a>						<a href="/source/s?defs=Attr&amp;project=rtmp_client">Attr</a> <a href="/source/s?defs=attr&amp;project=rtmp_client">attr</a> = (<a href="/source/s?defs=Attr&amp;project=rtmp_client">Attr</a>) <a href="/source/s?defs=attrs&amp;project=rtmp_client">attrs</a>.<a href="/source/s?defs=item&amp;project=rtmp_client">item</a>(a);
<a class="l" name="87" href="#87">87</a>						<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<span class="s">' '</span>);
<a class="l" name="88" href="#88">88</a>						<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<a href="/source/s?defs=attr&amp;project=rtmp_client">attr</a>.<a href="/source/s?defs=getNodeName&amp;project=rtmp_client">getNodeName</a>());
<a class="l" name="89" href="#89">89</a>						<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<span class="s">"=\""</span>);
<a class="hl" name="90" href="#90">90</a>						<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<a href="/source/s?defs=attr&amp;project=rtmp_client">attr</a>.<a href="/source/s?defs=getValue&amp;project=rtmp_client">getValue</a>());
<a class="l" name="91" href="#91">91</a>						<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<span class="s">'\"'</span>);
<a class="l" name="92" href="#92">92</a>					}
<a class="l" name="93" href="#93">93</a>				}
<a class="l" name="94" href="#94">94</a>				<a href="/source/s?defs=children&amp;project=rtmp_client">children</a> = <a href="/source/s?defs=node&amp;project=rtmp_client">node</a>.<a href="/source/s?defs=getChildNodes&amp;project=rtmp_client">getChildNodes</a>();
<a class="l" name="95" href="#95">95</a>				<b>if</b> (<a href="/source/s?defs=children&amp;project=rtmp_client">children</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="96" href="#96">96</a>					<b>int</b> <a href="/source/s?defs=numChildren&amp;project=rtmp_client">numChildren</a> = <a href="/source/s?defs=children&amp;project=rtmp_client">children</a>.<a href="/source/s?defs=getLength&amp;project=rtmp_client">getLength</a>();
<a class="l" name="97" href="#97">97</a>					<a href="/source/s?defs=hasChildren&amp;project=rtmp_client">hasChildren</a> = (<a href="/source/s?defs=numChildren&amp;project=rtmp_client">numChildren</a> &gt; <span class="n">0</span>);
<a class="l" name="98" href="#98">98</a>					<b>if</b> (<a href="/source/s?defs=hasChildren&amp;project=rtmp_client">hasChildren</a>) {
<a class="l" name="99" href="#99">99</a>						<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<span class="s">'&gt;'</span>);
<a class="hl" name="100" href="#100">100</a>					}
<a class="l" name="101" href="#101">101</a>					<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=numChildren&amp;project=rtmp_client">numChildren</a>; i++) {
<a class="l" name="102" href="#102">102</a>						<a class="d" href="#print">print</a>(<a href="/source/s?defs=children&amp;project=rtmp_client">children</a>.<a href="/source/s?defs=item&amp;project=rtmp_client">item</a>(i), <a class="d" href="#out">out</a>);
<a class="l" name="103" href="#103">103</a>					}
<a class="l" name="104" href="#104">104</a>				} <b>else</b> {
<a class="l" name="105" href="#105">105</a>					<a href="/source/s?defs=hasChildren&amp;project=rtmp_client">hasChildren</a> = <b>false</b>;
<a class="l" name="106" href="#106">106</a>				}
<a class="l" name="107" href="#107">107</a>				<b>if</b> (!<a href="/source/s?defs=hasChildren&amp;project=rtmp_client">hasChildren</a>) {
<a class="l" name="108" href="#108">108</a>					<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<span class="s">"/&gt;"</span>);
<a class="l" name="109" href="#109">109</a>				}
<a class="hl" name="110" href="#110">110</a>				<b>break</b>;
<a class="l" name="111" href="#111">111</a>			<b>case</b> <a href="/source/s?defs=Node&amp;project=rtmp_client">Node</a>.<a href="/source/s?defs=ENTITY_REFERENCE_NODE&amp;project=rtmp_client">ENTITY_REFERENCE_NODE</a>:
<a class="l" name="112" href="#112">112</a>				<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<span class="s">'&amp;'</span>);
<a class="l" name="113" href="#113">113</a>				<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<a href="/source/s?defs=node&amp;project=rtmp_client">node</a>.<a href="/source/s?defs=getNodeName&amp;project=rtmp_client">getNodeName</a>());
<a class="l" name="114" href="#114">114</a>				<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<span class="s">';'</span>);
<a class="l" name="115" href="#115">115</a>				<b>break</b>;
<a class="l" name="116" href="#116">116</a>			<b>case</b> <a href="/source/s?defs=Node&amp;project=rtmp_client">Node</a>.<a href="/source/s?defs=CDATA_SECTION_NODE&amp;project=rtmp_client">CDATA_SECTION_NODE</a>:
<a class="l" name="117" href="#117">117</a>				<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<span class="s">"&lt;![CDATA["</span>);
<a class="l" name="118" href="#118">118</a>				<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<a href="/source/s?defs=node&amp;project=rtmp_client">node</a>.<a href="/source/s?defs=getNodeValue&amp;project=rtmp_client">getNodeValue</a>());
<a class="l" name="119" href="#119">119</a>				<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<span class="s">"]]&gt;"</span>);
<a class="hl" name="120" href="#120">120</a>				<b>break</b>;
<a class="l" name="121" href="#121">121</a>			<b>case</b> <a href="/source/s?defs=Node&amp;project=rtmp_client">Node</a>.<a href="/source/s?defs=TEXT_NODE&amp;project=rtmp_client">TEXT_NODE</a>:
<a class="l" name="122" href="#122">122</a>				<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<a href="/source/s?defs=node&amp;project=rtmp_client">node</a>.<a href="/source/s?defs=getNodeValue&amp;project=rtmp_client">getNodeValue</a>());
<a class="l" name="123" href="#123">123</a>				<b>break</b>;
<a class="l" name="124" href="#124">124</a>			<b>default</b>:
<a class="l" name="125" href="#125">125</a>				<b>if</b> (<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=isDebugEnabled&amp;project=rtmp_client">isDebugEnabled</a>()) {
<a class="l" name="126" href="#126">126</a>					<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Unknown type: "</span> + <a href="/source/s?defs=type&amp;project=rtmp_client">type</a>);
<a class="l" name="127" href="#127">127</a>				}
<a class="l" name="128" href="#128">128</a>		}
<a class="l" name="129" href="#129">129</a>		<b>if</b> (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> == <a href="/source/s?defs=Node&amp;project=rtmp_client">Node</a>.<a href="/source/s?defs=ELEMENT_NODE&amp;project=rtmp_client">ELEMENT_NODE</a> &amp;&amp; <a href="/source/s?defs=hasChildren&amp;project=rtmp_client">hasChildren</a>) {
<a class="hl" name="130" href="#130">130</a>			<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<span class="s">"&lt;/"</span>);
<a class="l" name="131" href="#131">131</a>			<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<a href="/source/s?defs=node&amp;project=rtmp_client">node</a>.<a href="/source/s?defs=getNodeName&amp;project=rtmp_client">getNodeName</a>());
<a class="l" name="132" href="#132">132</a>			<a class="d" href="#out">out</a>.<a class="d" href="#print">print</a>(<span class="s">'&gt;'</span>);
<a class="l" name="133" href="#133">133</a>			<a href="/source/s?defs=hasChildren&amp;project=rtmp_client">hasChildren</a> = <b>false</b>;
<a class="l" name="134" href="#134">134</a>		}
<a class="l" name="135" href="#135">135</a>	}
<a class="l" name="136" href="#136">136</a>}
<a class="l" name="137" href="#137">137</a>