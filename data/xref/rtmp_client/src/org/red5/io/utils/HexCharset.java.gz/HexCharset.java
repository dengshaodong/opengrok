<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["Decoder",210],["Encoder",113],["HexCharset",37]]],["Package","xp",[["org.red5.io.utils",1]]],["Method","xmt",[["Decoder",213],["Encoder",118],["HexCharset",50],["HexCharset",60],["contains",109],["decodeLoop",252],["encodeLoop",180],["implFlush",137],["implReset",203],["implReset",276],["newDecoder",80],["newEncoder",71]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=Buffer&amp;project=rtmp_client">Buffer</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=charset&amp;project=rtmp_client">charset</a>.<a href="/source/s?defs=Charset&amp;project=rtmp_client">Charset</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=charset&amp;project=rtmp_client">charset</a>.<a href="/source/s?defs=CharsetDecoder&amp;project=rtmp_client">CharsetDecoder</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=charset&amp;project=rtmp_client">charset</a>.<a href="/source/s?defs=CharsetEncoder&amp;project=rtmp_client">CharsetEncoder</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=charset&amp;project=rtmp_client">charset</a>.<a href="/source/s?defs=CoderResult&amp;project=rtmp_client">CoderResult</a>;
<a class="l" name="27" href="#27">27</a>
<a class="l" name="28" href="#28">28</a><span class="c">/**
<a class="l" name="29" href="#29">29</a> * This was borrowed from the Soupdragon base64 library.
<a class="hl" name="30" href="#30">30</a> *
<a class="l" name="31" href="#31">31</a> * &lt;p&gt;Codec to translate between hex coding and byte string.&lt;/p&gt;
<a class="l" name="32" href="#32">32</a> * &lt;p&gt;Hex output is capital if the char set name is given in capitals.&lt;/p&gt;
<a class="l" name="33" href="#33">33</a> * &lt;p&gt;hex:nn used as a charset name inserts \n after every nnth character.&lt;/p&gt;
<a class="l" name="34" href="#34">34</a> *
<a class="l" name="35" href="#35">35</a> * <strong>@author</strong> Malcolm McMahon
<a class="l" name="36" href="#36">36</a> */</span>
<a class="l" name="37" href="#37">37</a><b>public</b> <b>class</b> <a class="xc" name="HexCharset"/><a href="/source/s?refs=HexCharset&amp;project=rtmp_client" class="xc">HexCharset</a> <b>extends</b> <a href="/source/s?defs=Charset&amp;project=rtmp_client">Charset</a> {
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>	<b>private</b> <b>final</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="codeHEX"/><a href="/source/s?refs=codeHEX&amp;project=rtmp_client" class="xfld">codeHEX</a> = <span class="s">"0123456789ABCDEF"</span>;
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a>	<b>private</b> <b>final</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="codehex"/><a href="/source/s?refs=codehex&amp;project=rtmp_client" class="xfld">codehex</a> = <span class="s">"0123456789abcdef"</span>;
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a>	<b>private</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="codes"/><a href="/source/s?refs=codes&amp;project=rtmp_client" class="xfld">codes</a>;
<a class="l" name="44" href="#44">44</a>
<a class="l" name="45" href="#45">45</a>	<b>private</b> <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a> <a class="xfld" name="measure"/><a href="/source/s?refs=measure&amp;project=rtmp_client" class="xfld">measure</a>;
<a class="l" name="46" href="#46">46</a>
<a class="l" name="47" href="#47">47</a>	<span class="c">/** Creates a new instance of HexCharset
<a class="l" name="48" href="#48">48</a>	 * <strong>@param</strong> <em>caps</em> true for A-F, false for a-f
<a class="l" name="49" href="#49">49</a>	 */</span>
<a class="hl" name="50" href="#50">50</a>	<b>public</b> <a class="xmt" name="HexCharset"/><a href="/source/s?refs=HexCharset&amp;project=rtmp_client" class="xmt">HexCharset</a>(<b>boolean</b> <a class="xa" name="caps"/><a href="/source/s?refs=caps&amp;project=rtmp_client" class="xa">caps</a>) {
<a class="l" name="51" href="#51">51</a>		<b>super</b>(<a href="/source/s?defs=caps&amp;project=rtmp_client">caps</a> ? <span class="s">"HEX"</span> : <span class="s">"hex"</span>, <b>new</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>[] { <span class="s">"HEX"</span> });
<a class="l" name="52" href="#52">52</a>		<a class="d" href="#codes">codes</a> = <a href="/source/s?defs=caps&amp;project=rtmp_client">caps</a> ? <a class="d" href="#codeHEX">codeHEX</a> : <a class="d" href="#codehex">codehex</a>;
<a class="l" name="53" href="#53">53</a>	}
<a class="l" name="54" href="#54">54</a>
<a class="l" name="55" href="#55">55</a>	<span class="c">/**
<a class="l" name="56" href="#56">56</a>	 * Construct the charset
<a class="l" name="57" href="#57">57</a>	 * <strong>@param</strong> <em>caps</em> true for A-F, false for a-f
<a class="l" name="58" href="#58">58</a>	 * <strong>@param</strong> <em>measure</em> Line width for decoding
<a class="l" name="59" href="#59">59</a>	 */</span>
<a class="hl" name="60" href="#60">60</a>	<b>public</b> <a class="xmt" name="HexCharset"/><a href="/source/s?refs=HexCharset&amp;project=rtmp_client" class="xmt">HexCharset</a>(<b>boolean</b> <a class="xa" name="caps"/><a href="/source/s?refs=caps&amp;project=rtmp_client" class="xa">caps</a>, <b>int</b> <a class="xa" name="measure"/><a href="/source/s?refs=measure&amp;project=rtmp_client" class="xa">measure</a>) {
<a class="l" name="61" href="#61">61</a>		<b>super</b>((<a href="/source/s?defs=caps&amp;project=rtmp_client">caps</a> ? <span class="s">"HEX"</span> : <span class="s">"hex"</span>) + <span class="s">":"</span> + <a href="/source/s?defs=measure&amp;project=rtmp_client">measure</a>, <b>new</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>[] { <span class="s">"HEX"</span> });
<a class="l" name="62" href="#62">62</a>		<a class="d" href="#codes">codes</a> = <a href="/source/s?defs=caps&amp;project=rtmp_client">caps</a> ? <a class="d" href="#codeHEX">codeHEX</a> : <a class="d" href="#codehex">codehex</a>;
<a class="l" name="63" href="#63">63</a>		<b>this</b>.<a href="/source/s?defs=measure&amp;project=rtmp_client">measure</a> = <a href="/source/s?defs=measure&amp;project=rtmp_client">measure</a>;
<a class="l" name="64" href="#64">64</a>	}
<a class="l" name="65" href="#65">65</a>
<a class="l" name="66" href="#66">66</a>	<span class="c">/**
<a class="l" name="67" href="#67">67</a>	 * Constructs a new encoder for this charset. &lt;/p&gt;
<a class="l" name="68" href="#68">68</a>	 *
<a class="l" name="69" href="#69">69</a>	 * <strong>@return</strong>  A new encoder for this charset
<a class="hl" name="70" href="#70">70</a>	 */</span>
<a class="l" name="71" href="#71">71</a>	<b>public</b> <a href="/source/s?defs=CharsetEncoder&amp;project=rtmp_client">CharsetEncoder</a> <a class="xmt" name="newEncoder"/><a href="/source/s?refs=newEncoder&amp;project=rtmp_client" class="xmt">newEncoder</a>() {
<a class="l" name="72" href="#72">72</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=Encoder&amp;project=rtmp_client">Encoder</a>();
<a class="l" name="73" href="#73">73</a>	}
<a class="l" name="74" href="#74">74</a>
<a class="l" name="75" href="#75">75</a>	<span class="c">/**
<a class="l" name="76" href="#76">76</a>	 * Constructs a new decoder for this charset. &lt;/p&gt;
<a class="l" name="77" href="#77">77</a>	 *
<a class="l" name="78" href="#78">78</a>	 * <strong>@return</strong>  A new decoder for this charset
<a class="l" name="79" href="#79">79</a>	 */</span>
<a class="hl" name="80" href="#80">80</a>	<b>public</b> <a href="/source/s?defs=CharsetDecoder&amp;project=rtmp_client">CharsetDecoder</a> <a class="xmt" name="newDecoder"/><a href="/source/s?refs=newDecoder&amp;project=rtmp_client" class="xmt">newDecoder</a>() {
<a class="l" name="81" href="#81">81</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=Decoder&amp;project=rtmp_client">Decoder</a>();
<a class="l" name="82" href="#82">82</a>	}
<a class="l" name="83" href="#83">83</a>
<a class="l" name="84" href="#84">84</a>	<span class="c">/**
<a class="l" name="85" href="#85">85</a>	 * Tells whether or not this charset contains the given charset.
<a class="l" name="86" href="#86">86</a>	 *
<a class="l" name="87" href="#87">87</a>	 * &lt;p&gt; A charset &lt;i&gt;C&lt;/i&gt; is said to &lt;i&gt;contain&lt;/i&gt; a charset &lt;i&gt;D&lt;/i&gt; if,
<a class="l" name="88" href="#88">88</a>	 * and only if, every character representable in &lt;i&gt;D&lt;/i&gt; is also
<a class="l" name="89" href="#89">89</a>	 * representable in &lt;i&gt;C&lt;/i&gt;.  If this relationship holds then it is
<a class="hl" name="90" href="#90">90</a>	 * guaranteed that every string that can be encoded in &lt;i&gt;D&lt;/i&gt; can also be
<a class="l" name="91" href="#91">91</a>	 * encoded in &lt;i&gt;C&lt;/i&gt; without performing any replacements.
<a class="l" name="92" href="#92">92</a>	 *
<a class="l" name="93" href="#93">93</a>	 * &lt;p&gt; That &lt;i&gt;C&lt;/i&gt; contains &lt;i&gt;D&lt;/i&gt; does not imply that each character
<a class="l" name="94" href="#94">94</a>	 * representable in &lt;i&gt;C&lt;/i&gt; by a particular byte sequence is represented
<a class="l" name="95" href="#95">95</a>	 * in &lt;i&gt;D&lt;/i&gt; by the same byte sequence, although sometimes this is the
<a class="l" name="96" href="#96">96</a>	 * case.
<a class="l" name="97" href="#97">97</a>	 *
<a class="l" name="98" href="#98">98</a>	 * &lt;p&gt; Every charset contains itself.
<a class="l" name="99" href="#99">99</a>	 *
<a class="hl" name="100" href="#100">100</a>	 * &lt;p&gt; This method computes an approximation of the containment relation:
<a class="l" name="101" href="#101">101</a>	 * If it returns &lt;tt&gt;true&lt;/tt&gt; then the given charset is known to be
<a class="l" name="102" href="#102">102</a>	 * contained by this charset; if it returns &lt;tt&gt;false&lt;/tt&gt;, however, then
<a class="l" name="103" href="#103">103</a>	 * it is not necessarily the case that the given charset is not contained
<a class="l" name="104" href="#104">104</a>	 * in this charset.
<a class="l" name="105" href="#105">105</a>	 *
<a class="l" name="106" href="#106">106</a>	 * <strong>@return</strong>  &lt;tt&gt;true&lt;/tt&gt; if, and only if, the given charset
<a class="l" name="107" href="#107">107</a>	 *          is contained in this charset
<a class="l" name="108" href="#108">108</a>	 */</span>
<a class="l" name="109" href="#109">109</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="contains"/><a href="/source/s?refs=contains&amp;project=rtmp_client" class="xmt">contains</a>(<a href="/source/s?defs=Charset&amp;project=rtmp_client">Charset</a> <a class="xa" name="cs"/><a href="/source/s?refs=cs&amp;project=rtmp_client" class="xa">cs</a>) {
<a class="hl" name="110" href="#110">110</a>		<b>return</b> <a class="d" href="#cs">cs</a> <b>instanceof</b> <a href="/source/s?defs=HexCharset&amp;project=rtmp_client">HexCharset</a>;
<a class="l" name="111" href="#111">111</a>	}
<a class="l" name="112" href="#112">112</a>
<a class="l" name="113" href="#113">113</a>	<b>private</b> <b>class</b> <a class="xc" name="Encoder"/><a href="/source/s?refs=Encoder&amp;project=rtmp_client" class="xc">Encoder</a> <b>extends</b> <a href="/source/s?defs=CharsetEncoder&amp;project=rtmp_client">CharsetEncoder</a> {
<a class="l" name="114" href="#114">114</a>		<b>private</b> <b>boolean</b> <a class="xfld" name="unpaired"/><a href="/source/s?refs=unpaired&amp;project=rtmp_client" class="xfld">unpaired</a>;
<a class="l" name="115" href="#115">115</a>
<a class="l" name="116" href="#116">116</a>		<b>private</b> <b>int</b> <a class="xfld" name="nyble"/><a href="/source/s?refs=nyble&amp;project=rtmp_client" class="xfld">nyble</a>;
<a class="l" name="117" href="#117">117</a>
<a class="l" name="118" href="#118">118</a>		<b>private</b> <a class="xmt" name="Encoder"/><a href="/source/s?refs=Encoder&amp;project=rtmp_client" class="xmt">Encoder</a>() {
<a class="l" name="119" href="#119">119</a>			<b>super</b>(<a href="/source/s?defs=HexCharset&amp;project=rtmp_client">HexCharset</a>.<b>this</b>, <span class="n">0.49f</span>, <span class="n">1f</span>);
<a class="hl" name="120" href="#120">120</a>
<a class="l" name="121" href="#121">121</a>		}
<a class="l" name="122" href="#122">122</a>
<a class="l" name="123" href="#123">123</a>		<span class="c">/**
<a class="l" name="124" href="#124">124</a>		 * Flushes this encoder.
<a class="l" name="125" href="#125">125</a>		 *
<a class="l" name="126" href="#126">126</a>		 * &lt;p&gt; The default implementation of this method does nothing, and always
<a class="l" name="127" href="#127">127</a>		 * returns {<strong>@link</strong> CoderResult#UNDERFLOW}.  This method should be overridden
<a class="l" name="128" href="#128">128</a>		 * by encoders that may need to write final bytes to the output buffer
<a class="l" name="129" href="#129">129</a>		 * once the entire input sequence has been read. &lt;/p&gt;
<a class="hl" name="130" href="#130">130</a>		 *
<a class="l" name="131" href="#131">131</a>		 * <strong>@param</strong>  <em>out</em>
<a class="l" name="132" href="#132">132</a>		 *         The output byte buffer
<a class="l" name="133" href="#133">133</a>		 *
<a class="l" name="134" href="#134">134</a>		 * <strong>@return</strong>  A coder-result object, either {<strong>@link</strong> CoderResult#UNDERFLOW} or
<a class="l" name="135" href="#135">135</a>		 *          {<strong>@link</strong> CoderResult#OVERFLOW}
<a class="l" name="136" href="#136">136</a>		 */</span>
<a class="l" name="137" href="#137">137</a>		<b>protected</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=charset&amp;project=rtmp_client">charset</a>.<a href="/source/s?defs=CoderResult&amp;project=rtmp_client">CoderResult</a> <a class="xmt" name="implFlush"/><a href="/source/s?refs=implFlush&amp;project=rtmp_client" class="xmt">implFlush</a>(<a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>) {
<a class="l" name="138" href="#138">138</a>			<b>if</b> (!<a class="d" href="#unpaired">unpaired</a>) {
<a class="l" name="139" href="#139">139</a>				<a href="/source/s?defs=implReset&amp;project=rtmp_client">implReset</a>();
<a class="hl" name="140" href="#140">140</a>				<b>return</b> <a href="/source/s?defs=CoderResult&amp;project=rtmp_client">CoderResult</a>.<a href="/source/s?defs=UNDERFLOW&amp;project=rtmp_client">UNDERFLOW</a>;
<a class="l" name="141" href="#141">141</a>			} <b>else</b>
<a class="l" name="142" href="#142">142</a>				<b>throw</b> <b>new</b> <a href="/source/s?defs=IllegalArgumentException&amp;project=rtmp_client">IllegalArgumentException</a>(<span class="s">"Hex string must be an even number of digits"</span>);
<a class="l" name="143" href="#143">143</a>		}
<a class="l" name="144" href="#144">144</a>
<a class="l" name="145" href="#145">145</a>		<span class="c">/**
<a class="l" name="146" href="#146">146</a>		 * Encodes one or more characters into one or more bytes.
<a class="l" name="147" href="#147">147</a>		 *
<a class="l" name="148" href="#148">148</a>		 * &lt;p&gt; This method encapsulates the basic encoding loop, encoding as many
<a class="l" name="149" href="#149">149</a>		 * characters as possible until it either runs out of input, runs out of room
<a class="hl" name="150" href="#150">150</a>		 * in the output buffer, or encounters an encoding error.  This method is
<a class="l" name="151" href="#151">151</a>		 * invoked by the {<strong>@link</strong> #encode encode} method, which handles result
<a class="l" name="152" href="#152">152</a>		 * interpretation and error recovery.
<a class="l" name="153" href="#153">153</a>		 *
<a class="l" name="154" href="#154">154</a>		 * &lt;p&gt; The buffers are read from, and written to, starting at their current
<a class="l" name="155" href="#155">155</a>		 * positions.  At most {<strong>@link</strong> Buffer#remaining in.remaining()} characters
<a class="l" name="156" href="#156">156</a>		 * will be read, and at most {<strong>@link</strong> Buffer#remaining out.remaining()}
<a class="l" name="157" href="#157">157</a>		 * bytes will be written.  The buffers' positions will be advanced to
<a class="l" name="158" href="#158">158</a>		 * reflect the characters read and the bytes written, but their marks and
<a class="l" name="159" href="#159">159</a>		 * limits will not be modified.
<a class="hl" name="160" href="#160">160</a>		 *
<a class="l" name="161" href="#161">161</a>		 * &lt;p&gt; This method returns a {<strong>@link</strong> CoderResult} object to describe its
<a class="l" name="162" href="#162">162</a>		 * reason for termination, in the same manner as the {<strong>@link</strong> #encode encode}
<a class="l" name="163" href="#163">163</a>		 * method.  Most implementations of this method will handle encoding errors
<a class="l" name="164" href="#164">164</a>		 * by returning an appropriate result object for interpretation by the
<a class="l" name="165" href="#165">165</a>		 * {<strong>@link</strong> #encode encode} method.  An optimized implementation may instead
<a class="l" name="166" href="#166">166</a>		 * examine the relevant error action and implement that action itself.
<a class="l" name="167" href="#167">167</a>		 *
<a class="l" name="168" href="#168">168</a>		 * &lt;p&gt; An implementation of this method may perform arbitrary lookahead by
<a class="l" name="169" href="#169">169</a>		 * returning {<strong>@link</strong> CoderResult#UNDERFLOW} until it receives sufficient
<a class="hl" name="170" href="#170">170</a>		 * input.  &lt;/p&gt;
<a class="l" name="171" href="#171">171</a>		 *
<a class="l" name="172" href="#172">172</a>		 * <strong>@param</strong>  <em>in</em>
<a class="l" name="173" href="#173">173</a>		 *         The input character buffer
<a class="l" name="174" href="#174">174</a>		 *
<a class="l" name="175" href="#175">175</a>		 * <strong>@param</strong>  <em>out</em>
<a class="l" name="176" href="#176">176</a>		 *         The output byte buffer
<a class="l" name="177" href="#177">177</a>		 *
<a class="l" name="178" href="#178">178</a>		 * <strong>@return</strong>  A coder-result object describing the reason for termination
<a class="l" name="179" href="#179">179</a>		 */</span>
<a class="hl" name="180" href="#180">180</a>		<b>public</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=charset&amp;project=rtmp_client">charset</a>.<a href="/source/s?defs=CoderResult&amp;project=rtmp_client">CoderResult</a> <a class="xmt" name="encodeLoop"/><a href="/source/s?refs=encodeLoop&amp;project=rtmp_client" class="xmt">encodeLoop</a>(<a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=CharBuffer&amp;project=rtmp_client">CharBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>, <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>) {
<a class="l" name="181" href="#181">181</a>			<b>while</b> (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>() &gt; <span class="n">0</span>) {
<a class="l" name="182" href="#182">182</a>				<b>if</b> (<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>() &lt;= <span class="n">0</span>)
<a class="l" name="183" href="#183">183</a>					<b>return</b> <a href="/source/s?defs=CoderResult&amp;project=rtmp_client">CoderResult</a>.<a href="/source/s?defs=OVERFLOW&amp;project=rtmp_client">OVERFLOW</a>;
<a class="l" name="184" href="#184">184</a>				<b>char</b> <a href="/source/s?defs=inch&amp;project=rtmp_client">inch</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="185" href="#185">185</a>				<b>if</b> (!<a href="/source/s?defs=Character&amp;project=rtmp_client">Character</a>.<a href="/source/s?defs=isWhitespace&amp;project=rtmp_client">isWhitespace</a>(<a href="/source/s?defs=inch&amp;project=rtmp_client">inch</a>)) {
<a class="l" name="186" href="#186">186</a>					<b>int</b> d = <a href="/source/s?defs=Character&amp;project=rtmp_client">Character</a>.<a href="/source/s?defs=digit&amp;project=rtmp_client">digit</a>(<a href="/source/s?defs=inch&amp;project=rtmp_client">inch</a>, <span class="n">16</span>);
<a class="l" name="187" href="#187">187</a>					<b>if</b> (d &lt; <span class="n">0</span>)
<a class="l" name="188" href="#188">188</a>						<b>throw</b> <b>new</b> <a href="/source/s?defs=IllegalArgumentException&amp;project=rtmp_client">IllegalArgumentException</a>(<span class="s">"Bad hex character "</span> + <a href="/source/s?defs=inch&amp;project=rtmp_client">inch</a>);
<a class="l" name="189" href="#189">189</a>					<b>if</b> (<a class="d" href="#unpaired">unpaired</a>)
<a class="hl" name="190" href="#190">190</a>						<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) (<a class="d" href="#nyble">nyble</a> | d));
<a class="l" name="191" href="#191">191</a>					<b>else</b>
<a class="l" name="192" href="#192">192</a>						<a class="d" href="#nyble">nyble</a> = d &lt;&lt; <span class="n">4</span>;
<a class="l" name="193" href="#193">193</a>					<a class="d" href="#unpaired">unpaired</a> = !<a class="d" href="#unpaired">unpaired</a>;
<a class="l" name="194" href="#194">194</a>				}
<a class="l" name="195" href="#195">195</a>			}
<a class="l" name="196" href="#196">196</a>			<b>return</b> <a href="/source/s?defs=CoderResult&amp;project=rtmp_client">CoderResult</a>.<a href="/source/s?defs=UNDERFLOW&amp;project=rtmp_client">UNDERFLOW</a>;
<a class="l" name="197" href="#197">197</a>		}
<a class="l" name="198" href="#198">198</a>
<a class="l" name="199" href="#199">199</a>		<span class="c">/**
<a class="hl" name="200" href="#200">200</a>		 * Clear state
<a class="l" name="201" href="#201">201</a>		 */</span>
<a class="l" name="202" href="#202">202</a>
<a class="l" name="203" href="#203">203</a>		<b>protected</b> <b>void</b> <a class="xmt" name="implReset"/><a href="/source/s?refs=implReset&amp;project=rtmp_client" class="xmt">implReset</a>() {
<a class="l" name="204" href="#204">204</a>			<a class="d" href="#unpaired">unpaired</a> = <b>false</b>;
<a class="l" name="205" href="#205">205</a>			<a class="d" href="#nyble">nyble</a> = <span class="n">0</span>;
<a class="l" name="206" href="#206">206</a>		}
<a class="l" name="207" href="#207">207</a>
<a class="l" name="208" href="#208">208</a>	}
<a class="l" name="209" href="#209">209</a>
<a class="hl" name="210" href="#210">210</a>	<b>private</b> <b>class</b> <a class="xc" name="Decoder"/><a href="/source/s?refs=Decoder&amp;project=rtmp_client" class="xc">Decoder</a> <b>extends</b> <a href="/source/s?defs=CharsetDecoder&amp;project=rtmp_client">CharsetDecoder</a> {
<a class="l" name="211" href="#211">211</a>		<b>private</b> <b>int</b> <a class="xfld" name="charCount"/><a href="/source/s?refs=charCount&amp;project=rtmp_client" class="xfld">charCount</a>;
<a class="l" name="212" href="#212">212</a>
<a class="l" name="213" href="#213">213</a>		<b>private</b> <a class="xmt" name="Decoder"/><a href="/source/s?refs=Decoder&amp;project=rtmp_client" class="xmt">Decoder</a>() {
<a class="l" name="214" href="#214">214</a>			<b>super</b>(<a href="/source/s?defs=HexCharset&amp;project=rtmp_client">HexCharset</a>.<b>this</b>, <span class="n">2f</span>, <a href="/source/s?defs=measure&amp;project=rtmp_client">measure</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> ? <span class="n">2f</span> : <span class="n">2f</span> + (<span class="n">2f</span> / (<b>float</b>) <a href="/source/s?defs=measure&amp;project=rtmp_client">measure</a>));
<a class="l" name="215" href="#215">215</a>		}
<a class="l" name="216" href="#216">216</a>
<a class="l" name="217" href="#217">217</a>		<span class="c">/**
<a class="l" name="218" href="#218">218</a>		 * Decodes one or more bytes into one or more characters.
<a class="l" name="219" href="#219">219</a>		 *
<a class="hl" name="220" href="#220">220</a>		 * &lt;p&gt; This method encapsulates the basic decoding loop, decoding as many
<a class="l" name="221" href="#221">221</a>		 * bytes as possible until it either runs out of input, runs out of room
<a class="l" name="222" href="#222">222</a>		 * in the output buffer, or encounters a decoding error.  This method is
<a class="l" name="223" href="#223">223</a>		 * invoked by the {<strong>@link</strong> #decode decode} method, which handles result
<a class="l" name="224" href="#224">224</a>		 * interpretation and error recovery.
<a class="l" name="225" href="#225">225</a>		 *
<a class="l" name="226" href="#226">226</a>		 * &lt;p&gt; The buffers are read from, and written to, starting at their current
<a class="l" name="227" href="#227">227</a>		 * positions.  At most {<strong>@link</strong> Buffer#remaining in.remaining()} bytes
<a class="l" name="228" href="#228">228</a>		 * will be read, and at most {<strong>@link</strong> Buffer#remaining out.remaining()}
<a class="l" name="229" href="#229">229</a>		 * characters will be written.  The buffers' positions will be advanced to
<a class="hl" name="230" href="#230">230</a>		 * reflect the bytes read and the characters written, but their marks and
<a class="l" name="231" href="#231">231</a>		 * limits will not be modified.
<a class="l" name="232" href="#232">232</a>		 *
<a class="l" name="233" href="#233">233</a>		 * &lt;p&gt; This method returns a {<strong>@link</strong> CoderResult} object to describe its
<a class="l" name="234" href="#234">234</a>		 * reason for termination, in the same manner as the {<strong>@link</strong> #decode decode}
<a class="l" name="235" href="#235">235</a>		 * method.  Most implementations of this method will handle decoding errors
<a class="l" name="236" href="#236">236</a>		 * by returning an appropriate result object for interpretation by the
<a class="l" name="237" href="#237">237</a>		 * {<strong>@link</strong> #decode decode} method.  An optimized implementation may instead
<a class="l" name="238" href="#238">238</a>		 * examine the relevant error action and implement that action itself.
<a class="l" name="239" href="#239">239</a>		 *
<a class="hl" name="240" href="#240">240</a>		 * &lt;p&gt; An implementation of this method may perform arbitrary lookahead by
<a class="l" name="241" href="#241">241</a>		 * returning {<strong>@link</strong> CoderResult#UNDERFLOW} until it receives sufficient
<a class="l" name="242" href="#242">242</a>		 * input.  &lt;/p&gt;
<a class="l" name="243" href="#243">243</a>		 *
<a class="l" name="244" href="#244">244</a>		 * <strong>@param</strong>  <em>in</em>
<a class="l" name="245" href="#245">245</a>		 *         The input byte buffer
<a class="l" name="246" href="#246">246</a>		 *
<a class="l" name="247" href="#247">247</a>		 * <strong>@param</strong>  <em>out</em>
<a class="l" name="248" href="#248">248</a>		 *         The output character buffer
<a class="l" name="249" href="#249">249</a>		 *
<a class="hl" name="250" href="#250">250</a>		 * <strong>@return</strong>  A coder-result object describing the reason for termination
<a class="l" name="251" href="#251">251</a>		 */</span>
<a class="l" name="252" href="#252">252</a>		<b>public</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=charset&amp;project=rtmp_client">charset</a>.<a href="/source/s?defs=CoderResult&amp;project=rtmp_client">CoderResult</a> <a class="xmt" name="decodeLoop"/><a href="/source/s?refs=decodeLoop&amp;project=rtmp_client" class="xmt">decodeLoop</a>(<a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>, <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=CharBuffer&amp;project=rtmp_client">CharBuffer</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>) {
<a class="l" name="253" href="#253">253</a>			<b>while</b> (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>() &gt; <span class="n">0</span>) {
<a class="l" name="254" href="#254">254</a>				<b>if</b> (<a href="/source/s?defs=measure&amp;project=rtmp_client">measure</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a class="d" href="#charCount">charCount</a> &gt;= <a href="/source/s?defs=measure&amp;project=rtmp_client">measure</a>) {
<a class="l" name="255" href="#255">255</a>					<b>if</b> (<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>() == <span class="n">0</span>)
<a class="l" name="256" href="#256">256</a>						<b>return</b> <a href="/source/s?defs=CoderResult&amp;project=rtmp_client">CoderResult</a>.<a href="/source/s?defs=OVERFLOW&amp;project=rtmp_client">OVERFLOW</a>;
<a class="l" name="257" href="#257">257</a>					<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">'\n'</span>);
<a class="l" name="258" href="#258">258</a>					<a class="d" href="#charCount">charCount</a> = <span class="n">0</span>;
<a class="l" name="259" href="#259">259</a>				}
<a class="hl" name="260" href="#260">260</a>				<b>if</b> (<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>() &lt; <span class="n">2</span>)
<a class="l" name="261" href="#261">261</a>					<b>return</b> <a href="/source/s?defs=CoderResult&amp;project=rtmp_client">CoderResult</a>.<a href="/source/s?defs=OVERFLOW&amp;project=rtmp_client">OVERFLOW</a>;
<a class="l" name="262" href="#262">262</a>				<b>int</b> b = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xff</span>;
<a class="l" name="263" href="#263">263</a>				<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#codes">codes</a>.<a href="/source/s?defs=charAt&amp;project=rtmp_client">charAt</a>(b &gt;&gt;&gt; <span class="n">4</span>));
<a class="l" name="264" href="#264">264</a>				<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#codes">codes</a>.<a href="/source/s?defs=charAt&amp;project=rtmp_client">charAt</a>(b &amp; <span class="n">0x0f</span>));
<a class="l" name="265" href="#265">265</a>				<a class="d" href="#charCount">charCount</a> += <span class="n">2</span>;
<a class="l" name="266" href="#266">266</a>			}
<a class="l" name="267" href="#267">267</a>			<b>return</b> <a href="/source/s?defs=CoderResult&amp;project=rtmp_client">CoderResult</a>.<a href="/source/s?defs=UNDERFLOW&amp;project=rtmp_client">UNDERFLOW</a>;
<a class="l" name="268" href="#268">268</a>		}
<a class="l" name="269" href="#269">269</a>
<a class="hl" name="270" href="#270">270</a>		<span class="c">/**
<a class="l" name="271" href="#271">271</a>		 * Resets this decoder, clearing any charset-specific internal state.
<a class="l" name="272" href="#272">272</a>		 *
<a class="l" name="273" href="#273">273</a>		 * &lt;p&gt; The default implementation of this method does nothing.  This method
<a class="l" name="274" href="#274">274</a>		 * should be overridden by decoders that maintain internal state.  &lt;/p&gt;
<a class="l" name="275" href="#275">275</a>		 */</span>
<a class="l" name="276" href="#276">276</a>		<b>protected</b> <b>void</b> <a class="xmt" name="implReset"/><a href="/source/s?refs=implReset&amp;project=rtmp_client" class="xmt">implReset</a>() {
<a class="l" name="277" href="#277">277</a>			<a class="d" href="#charCount">charCount</a> = <span class="n">0</span>;
<a class="l" name="278" href="#278">278</a>		}
<a class="l" name="279" href="#279">279</a>
<a class="hl" name="280" href="#280">280</a>	}
<a class="l" name="281" href="#281">281</a>}
<a class="l" name="282" href="#282">282</a>