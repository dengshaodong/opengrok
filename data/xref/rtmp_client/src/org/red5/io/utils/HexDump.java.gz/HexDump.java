<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["HexDump",32]]],["Package","xp",[["org.red5.io.utils",18]]],["Method","xmt",[["byte2bin",687],["byte2hex",672],["byteArrayToBinaryString",184],["byteArrayToHexString",307],["byteArrayToHexString",338],["dumpHex",90],["formatHexDump",824],["hexStringToByteArray",461],["intToHexString",707],["main",721],["prettyPrintHex",46],["prettyPrintHex",57],["prettyPrintHex",74],["setBitDigits",152],["setBitDigits",169],["setByteSeparator",142],["setWithByteSeparator",133],["stringToHexString",325],["toBinaryString",208],["toBinaryString",218],["toBinaryString",230],["toBinaryString",240],["toBinaryString",250],["toByteArray",260],["toByteArray",273],["toByteArray",288],["toHexString",361],["toHexString",371],["toHexString",383],["toHexString",393],["toHexString",403],["toHexString",437],["toString",413],["toString",423]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">/*
<a class="l" name="2" href="#2">2</a> * Copyright  1999-2004 The Apache Software Foundation.
<a class="l" name="3" href="#3">3</a> *
<a class="l" name="4" href="#4">4</a> *  Licensed under the Apache License, Version 2.0 (the "License");
<a class="l" name="5" href="#5">5</a> *  you may not use this file except in compliance with the License.
<a class="l" name="6" href="#6">6</a> *  You may obtain a copy of the License at
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> *      <a href="http://www.apache.org/licenses/LICENSE-2.0">http://www.apache.org/licenses/LICENSE-2.0</a>
<a class="l" name="9" href="#9">9</a> *
<a class="hl" name="10" href="#10">10</a> *  Unless required by applicable law or agreed to in writing, software
<a class="l" name="11" href="#11">11</a> *  distributed under the License is distributed on an "AS IS" BASIS,
<a class="l" name="12" href="#12">12</a> *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
<a class="l" name="13" href="#13">13</a> *  See the License for the specific language governing permissions and
<a class="l" name="14" href="#14">14</a> *  limitations under the License.
<a class="l" name="15" href="#15">15</a> *
<a class="l" name="16" href="#16">16</a> */</span>
<a class="l" name="17" href="#17">17</a>
<a class="l" name="18" href="#18">18</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>;
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=ByteArrayOutputStream&amp;project=rtmp_client">ByteArrayOutputStream</a>;
<a class="l" name="21" href="#21">21</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a>;
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=charset&amp;project=rtmp_client">charset</a>.<a href="/source/s?defs=UnsupportedCharsetException&amp;project=rtmp_client">UnsupportedCharsetException</a>;
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="26" href="#26">26</a>
<a class="l" name="27" href="#27">27</a><span class="c">/**
<a class="l" name="28" href="#28">28</a> * Hexadecimal byte dumper
<a class="l" name="29" href="#29">29</a> *
<a class="hl" name="30" href="#30">30</a> * <strong>@author</strong> Niko Schweitzer
<a class="l" name="31" href="#31">31</a> */</span>
<a class="l" name="32" href="#32">32</a><b>public</b> <b>class</b> <a class="xc" name="HexDump"/><a href="/source/s?refs=HexDump&amp;project=rtmp_client" class="xc">HexDump</a> {
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a>	<span class="c">/**
<a class="l" name="35" href="#35">35</a>	 * Logger
<a class="l" name="36" href="#36">36</a>	 */</span>
<a class="l" name="37" href="#37">37</a>	<b>private</b> <b>static</b> <b>final</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="logger"/><a href="/source/s?refs=logger&amp;project=rtmp_client" class="xfld">logger</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a class="d" href="#HexDump">HexDump</a>.<b>class</b>);
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>	<span class="c">/**
<a class="hl" name="40" href="#40">40</a>	 * Method prettyPrintHex
<a class="l" name="41" href="#41">41</a>	 *
<a class="l" name="42" href="#42">42</a>	 *
<a class="l" name="43" href="#43">43</a>	 * <strong>@param</strong> <em>bbToConvert</em> ByteBuffer to encode
<a class="l" name="44" href="#44">44</a>	 * <strong>@return</strong> Hexdump string
<a class="l" name="45" href="#45">45</a>	 */</span>
<a class="l" name="46" href="#46">46</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="prettyPrintHex"/><a href="/source/s?refs=prettyPrintHex&amp;project=rtmp_client" class="xmt">prettyPrintHex</a>(<a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a> <a class="xa" name="bbToConvert"/><a href="/source/s?refs=bbToConvert&amp;project=rtmp_client" class="xa">bbToConvert</a>) {
<a class="l" name="47" href="#47">47</a>		<b>return</b> <a href="/source/s?defs=prettyPrintHex&amp;project=rtmp_client">prettyPrintHex</a>(<a class="d" href="#bbToConvert">bbToConvert</a>.<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>());
<a class="l" name="48" href="#48">48</a>	}
<a class="l" name="49" href="#49">49</a>
<a class="hl" name="50" href="#50">50</a>	<span class="c">/**
<a class="l" name="51" href="#51">51</a>	 * Method prettyPrintHex
<a class="l" name="52" href="#52">52</a>	 *
<a class="l" name="53" href="#53">53</a>	 *
<a class="l" name="54" href="#54">54</a>	 * <strong>@param</strong> <em>baToConvert</em> Array of bytes to encode
<a class="l" name="55" href="#55">55</a>	 * <strong>@return</strong> Hexdump string
<a class="l" name="56" href="#56">56</a>	 */</span>
<a class="l" name="57" href="#57">57</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="prettyPrintHex"/><a href="/source/s?refs=prettyPrintHex&amp;project=rtmp_client" class="xmt">prettyPrintHex</a>(<b>byte</b>[] <a class="xa" name="baToConvert"/><a href="/source/s?refs=baToConvert&amp;project=rtmp_client" class="xa">baToConvert</a>) {
<a class="l" name="58" href="#58">58</a>		<a href="/source/s?defs=HexCharset&amp;project=rtmp_client">HexCharset</a> <a href="/source/s?defs=hde&amp;project=rtmp_client">hde</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="59" href="#59">59</a>		<b>try</b> {
<a class="hl" name="60" href="#60">60</a>			<a href="/source/s?defs=hde&amp;project=rtmp_client">hde</a> = (<a href="/source/s?defs=HexCharset&amp;project=rtmp_client">HexCharset</a>) <a href="/source/s?defs=HexCharset&amp;project=rtmp_client">HexCharset</a>.<a href="/source/s?defs=forName&amp;project=rtmp_client">forName</a>(<span class="s">"HEX"</span>);
<a class="l" name="61" href="#61">61</a>		} <b>catch</b> (<a href="/source/s?defs=UnsupportedCharsetException&amp;project=rtmp_client">UnsupportedCharsetException</a> <a href="/source/s?defs=uce&amp;project=rtmp_client">uce</a>) {
<a class="l" name="62" href="#62">62</a>			<a href="/source/s?defs=hde&amp;project=rtmp_client">hde</a> = <b>new</b> <a href="/source/s?defs=HexCharset&amp;project=rtmp_client">HexCharset</a>(<b>true</b>);
<a class="l" name="63" href="#63">63</a>		}
<a class="l" name="64" href="#64">64</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>(<a href="/source/s?defs=hde&amp;project=rtmp_client">hde</a>.<a href="/source/s?defs=encode&amp;project=rtmp_client">encode</a>(<b>new</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>(<a class="d" href="#baToConvert">baToConvert</a>)).<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>());
<a class="l" name="65" href="#65">65</a>	}
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a>	<span class="c">/**
<a class="l" name="68" href="#68">68</a>	 * Method prettyPrintHex
<a class="l" name="69" href="#69">69</a>	 *
<a class="hl" name="70" href="#70">70</a>	 *
<a class="l" name="71" href="#71">71</a>	 * <strong>@param</strong> <em>sToConvert</em> string to convert
<a class="l" name="72" href="#72">72</a>	 * <strong>@return</strong> hexdump string
<a class="l" name="73" href="#73">73</a>	 */</span>
<a class="l" name="74" href="#74">74</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="prettyPrintHex"/><a href="/source/s?refs=prettyPrintHex&amp;project=rtmp_client" class="xmt">prettyPrintHex</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="sToConvert"/><a href="/source/s?refs=sToConvert&amp;project=rtmp_client" class="xa">sToConvert</a>) {
<a class="l" name="75" href="#75">75</a>		<a href="/source/s?defs=HexCharset&amp;project=rtmp_client">HexCharset</a> <a href="/source/s?defs=hde&amp;project=rtmp_client">hde</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="76" href="#76">76</a>		<b>try</b> {
<a class="l" name="77" href="#77">77</a>			<a href="/source/s?defs=hde&amp;project=rtmp_client">hde</a> = (<a href="/source/s?defs=HexCharset&amp;project=rtmp_client">HexCharset</a>) <a href="/source/s?defs=HexCharset&amp;project=rtmp_client">HexCharset</a>.<a href="/source/s?defs=forName&amp;project=rtmp_client">forName</a>(<span class="s">"HEX"</span>);
<a class="l" name="78" href="#78">78</a>		} <b>catch</b> (<a href="/source/s?defs=UnsupportedCharsetException&amp;project=rtmp_client">UnsupportedCharsetException</a> <a href="/source/s?defs=uce&amp;project=rtmp_client">uce</a>) {
<a class="l" name="79" href="#79">79</a>			<a href="/source/s?defs=hde&amp;project=rtmp_client">hde</a> = <b>new</b> <a href="/source/s?defs=HexCharset&amp;project=rtmp_client">HexCharset</a>(<b>true</b>);
<a class="hl" name="80" href="#80">80</a>		}
<a class="l" name="81" href="#81">81</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>(<a href="/source/s?defs=hde&amp;project=rtmp_client">hde</a>.<a href="/source/s?defs=encode&amp;project=rtmp_client">encode</a>(<a class="d" href="#sToConvert">sToConvert</a>).<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>());
<a class="l" name="82" href="#82">82</a>	}
<a class="l" name="83" href="#83">83</a>
<a class="l" name="84" href="#84">84</a>	<span class="c">/**
<a class="l" name="85" href="#85">85</a>	 * Dumps a byte array as hex.
<a class="l" name="86" href="#86">86</a>	 *
<a class="l" name="87" href="#87">87</a>	 * <strong>@param</strong> <em>sb</em>
<a class="l" name="88" href="#88">88</a>	 * <strong>@param</strong> b
<a class="l" name="89" href="#89">89</a>	 */</span>
<a class="hl" name="90" href="#90">90</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="dumpHex"/><a href="/source/s?refs=dumpHex&amp;project=rtmp_client" class="xmt">dumpHex</a>(<a href="/source/s?defs=StringBuilder&amp;project=rtmp_client">StringBuilder</a> <a class="xa" name="sb"/><a href="/source/s?refs=sb&amp;project=rtmp_client" class="xa">sb</a>, <b>byte</b>[] b) {
<a class="l" name="91" href="#91">91</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; b.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>; ++i) {
<a class="l" name="92" href="#92">92</a>			<b>if</b> (i % <span class="n">16</span> == <span class="n">0</span>) {
<a class="l" name="93" href="#93">93</a>				<a class="d" href="#sb">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>((i &amp; <span class="n">0xFFFF</span>) | <span class="n">0x10000</span>).<a href="/source/s?defs=substring&amp;project=rtmp_client">substring</a>(<span class="n">1</span>, <span class="n">5</span>) + <span class="s">" - "</span>);
<a class="l" name="94" href="#94">94</a>			}
<a class="l" name="95" href="#95">95</a>			<a class="d" href="#sb">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>((b[i] &amp; <span class="n">0xFF</span>) | <span class="n">0x100</span>).<a href="/source/s?defs=substring&amp;project=rtmp_client">substring</a>(<span class="n">1</span>, <span class="n">3</span>) + <span class="s">" "</span>);
<a class="l" name="96" href="#96">96</a>			<b>if</b> (i % <span class="n">16</span> == <span class="n">15</span> || i == b.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> - <span class="n">1</span>) {
<a class="l" name="97" href="#97">97</a>				<b>int</b> j;
<a class="l" name="98" href="#98">98</a>				<b>for</b> (j = <span class="n">16</span> - i % <span class="n">16</span>; j &gt; <span class="n">1</span>; --j)
<a class="l" name="99" href="#99">99</a>					<a class="d" href="#sb">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">"   "</span>);
<a class="hl" name="100" href="#100">100</a>				<a class="d" href="#sb">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">" - "</span>);
<a class="l" name="101" href="#101">101</a>				<b>int</b> <a href="/source/s?defs=start&amp;project=rtmp_client">start</a> = (i / <span class="n">16</span>) * <span class="n">16</span>;
<a class="l" name="102" href="#102">102</a>				<b>int</b> <a href="/source/s?defs=end&amp;project=rtmp_client">end</a> = (b.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> &lt; i + <span class="n">1</span>) ? b.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> : (i + <span class="n">1</span>);
<a class="l" name="103" href="#103">103</a>				<b>for</b> (j = <a href="/source/s?defs=start&amp;project=rtmp_client">start</a>; j &lt; <a href="/source/s?defs=end&amp;project=rtmp_client">end</a>; ++j)
<a class="l" name="104" href="#104">104</a>					<b>if</b> (b[j] &gt;= <span class="n">32</span> &amp;&amp; b[j] &lt;= <span class="n">126</span>)
<a class="l" name="105" href="#105">105</a>						<a class="d" href="#sb">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>((<b>char</b>) b[j]);
<a class="l" name="106" href="#106">106</a>					<b>else</b>
<a class="l" name="107" href="#107">107</a>						<a class="d" href="#sb">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">"."</span>);
<a class="l" name="108" href="#108">108</a>				<a class="d" href="#sb">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">"\n"</span>);
<a class="l" name="109" href="#109">109</a>			}
<a class="hl" name="110" href="#110">110</a>		}
<a class="l" name="111" href="#111">111</a>	}
<a class="l" name="112" href="#112">112</a>
<a class="l" name="113" href="#113">113</a>	<span class="c">/** Field HEX_DIGITS */</span>
<a class="l" name="114" href="#114">114</a>	<b>private</b> <b>static</b> <b>final</b> <b>char</b>[] <a class="xfld" name="HEX_DIGITS"/><a href="/source/s?refs=HEX_DIGITS&amp;project=rtmp_client" class="xfld">HEX_DIGITS</a> = { <span class="s">'0'</span>, <span class="s">'1'</span>, <span class="s">'2'</span>, <span class="s">'3'</span>, <span class="s">'4'</span>, <span class="s">'5'</span>, <span class="s">'6'</span>, <span class="s">'7'</span>, <span class="s">'8'</span>, <span class="s">'9'</span>, <span class="s">'A'</span>, <span class="s">'B'</span>, <span class="s">'C'</span>, <span class="s">'D'</span>, <span class="s">'E'</span>, <span class="s">'F'</span> };
<a class="l" name="115" href="#115">115</a>
<a class="l" name="116" href="#116">116</a>	<span class="c">/** Field BIT_DIGIT */</span>
<a class="l" name="117" href="#117">117</a>	<b>private</b> <b>static</b> <b>char</b>[] <a class="xfld" name="BIT_DIGIT"/><a href="/source/s?refs=BIT_DIGIT&amp;project=rtmp_client" class="xfld">BIT_DIGIT</a> = { <span class="s">'0'</span>, <span class="s">'1'</span> };
<a class="l" name="118" href="#118">118</a>
<a class="l" name="119" href="#119">119</a>	<span class="c">/** Field COMPARE_BITS */</span>
<a class="hl" name="120" href="#120">120</a>	<b>private</b> <b>static</b> <b>final</b> <b>byte</b>[] <a class="xfld" name="COMPARE_BITS"/><a href="/source/s?refs=COMPARE_BITS&amp;project=rtmp_client" class="xfld">COMPARE_BITS</a> = { (<b>byte</b>) <span class="n">0x80</span>, (<b>byte</b>) <span class="n">0x40</span>, (<b>byte</b>) <span class="n">0x20</span>, (<b>byte</b>) <span class="n">0x10</span>, (<b>byte</b>) <span class="n">0x08</span>, (<b>byte</b>) <span class="n">0x04</span>, (<b>byte</b>) <span class="n">0x02</span>, (<b>byte</b>) <span class="n">0x01</span> };
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>	<span class="c">/** Field BYTE_SEPARATOR */</span>
<a class="l" name="123" href="#123">123</a>	<b>private</b> <b>static</b> <b>char</b> <a class="xfld" name="BYTE_SEPARATOR"/><a href="/source/s?refs=BYTE_SEPARATOR&amp;project=rtmp_client" class="xfld">BYTE_SEPARATOR</a> = <span class="s">' '</span>;
<a class="l" name="124" href="#124">124</a>
<a class="l" name="125" href="#125">125</a>	<span class="c">/** Field WITH_BYTE_SEPARATOR */</span>
<a class="l" name="126" href="#126">126</a>	<b>private</b> <b>static</b> <b>boolean</b> <a class="xfld" name="WITH_BYTE_SEPARATOR"/><a href="/source/s?refs=WITH_BYTE_SEPARATOR&amp;project=rtmp_client" class="xfld">WITH_BYTE_SEPARATOR</a> = <b>true</b>;
<a class="l" name="127" href="#127">127</a>
<a class="l" name="128" href="#128">128</a>	<span class="c">/**
<a class="l" name="129" href="#129">129</a>	 * Sets the WithByteSeparator attribute of the Convert class
<a class="hl" name="130" href="#130">130</a>	 *
<a class="l" name="131" href="#131">131</a>	 * <strong>@param</strong> <em>bs</em> The new WithByteSeparator value
<a class="l" name="132" href="#132">132</a>	 */</span>
<a class="l" name="133" href="#133">133</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="setWithByteSeparator"/><a href="/source/s?refs=setWithByteSeparator&amp;project=rtmp_client" class="xmt">setWithByteSeparator</a>(<b>boolean</b> <a class="xa" name="bs"/><a href="/source/s?refs=bs&amp;project=rtmp_client" class="xa">bs</a>) {
<a class="l" name="134" href="#134">134</a>		<a class="d" href="#WITH_BYTE_SEPARATOR">WITH_BYTE_SEPARATOR</a> = <a href="/source/s?defs=bs&amp;project=rtmp_client">bs</a>;
<a class="l" name="135" href="#135">135</a>	}
<a class="l" name="136" href="#136">136</a>
<a class="l" name="137" href="#137">137</a>	<span class="c">/**
<a class="l" name="138" href="#138">138</a>	 * Sets the ByteSeparator attribute of the Convert class
<a class="l" name="139" href="#139">139</a>	 *
<a class="hl" name="140" href="#140">140</a>	 * <strong>@param</strong> <em>bs</em> The new ByteSeparator value
<a class="l" name="141" href="#141">141</a>	 */</span>
<a class="l" name="142" href="#142">142</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="setByteSeparator"/><a href="/source/s?refs=setByteSeparator&amp;project=rtmp_client" class="xmt">setByteSeparator</a>(<b>char</b> <a class="xa" name="bs"/><a href="/source/s?refs=bs&amp;project=rtmp_client" class="xa">bs</a>) {
<a class="l" name="143" href="#143">143</a>		<a class="d" href="#BYTE_SEPARATOR">BYTE_SEPARATOR</a> = <a href="/source/s?defs=bs&amp;project=rtmp_client">bs</a>;
<a class="l" name="144" href="#144">144</a>	}
<a class="l" name="145" href="#145">145</a>
<a class="l" name="146" href="#146">146</a>	<span class="c">/**
<a class="l" name="147" href="#147">147</a>	 * Sets the BitDigits attribute of the Convert class
<a class="l" name="148" href="#148">148</a>	 *
<a class="l" name="149" href="#149">149</a>	 * <strong>@param</strong> <em>bd</em> The new BitDigits value
<a class="hl" name="150" href="#150">150</a>	 * <strong>@exception</strong> <em>Exception</em> Description of Exception
<a class="l" name="151" href="#151">151</a>	 */</span>
<a class="l" name="152" href="#152">152</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="setBitDigits"/><a href="/source/s?refs=setBitDigits&amp;project=rtmp_client" class="xmt">setBitDigits</a>(<b>char</b>[] <a class="xa" name="bd"/><a href="/source/s?refs=bd&amp;project=rtmp_client" class="xa">bd</a>) <b>throws</b> <a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> {
<a class="l" name="153" href="#153">153</a>
<a class="l" name="154" href="#154">154</a>		<b>if</b> (<a class="d" href="#bd">bd</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> != <span class="n">2</span>) {
<a class="l" name="155" href="#155">155</a>			<b>throw</b> <b>new</b> <a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a>(<span class="s">"wrong number of characters!"</span>);
<a class="l" name="156" href="#156">156</a>		}
<a class="l" name="157" href="#157">157</a>
<a class="l" name="158" href="#158">158</a>		<a class="d" href="#BIT_DIGIT">BIT_DIGIT</a> = <a class="d" href="#bd">bd</a>;
<a class="l" name="159" href="#159">159</a>	}
<a class="hl" name="160" href="#160">160</a>
<a class="l" name="161" href="#161">161</a>	<span class="c">/**
<a class="l" name="162" href="#162">162</a>	 * Method setBitDigits
<a class="l" name="163" href="#163">163</a>	 *
<a class="l" name="164" href="#164">164</a>	 * <strong>@param</strong> <em>zeroBit</em> zero bit
<a class="l" name="165" href="#165">165</a>	 * <strong>@param</strong> <em>oneBit</em> one bit
<a class="l" name="166" href="#166">166</a>	 * param redFish red fish
<a class="l" name="167" href="#167">167</a>	 * param blueFish blue fish
<a class="l" name="168" href="#168">168</a>	 */</span>
<a class="l" name="169" href="#169">169</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="setBitDigits"/><a href="/source/s?refs=setBitDigits&amp;project=rtmp_client" class="xmt">setBitDigits</a>(<b>char</b> <a class="xa" name="zeroBit"/><a href="/source/s?refs=zeroBit&amp;project=rtmp_client" class="xa">zeroBit</a>, <b>char</b> <a class="xa" name="oneBit"/><a href="/source/s?refs=oneBit&amp;project=rtmp_client" class="xa">oneBit</a>) {
<a class="hl" name="170" href="#170">170</a>		<a class="d" href="#BIT_DIGIT">BIT_DIGIT</a>[<span class="n">0</span>] = <a class="d" href="#zeroBit">zeroBit</a>;
<a class="l" name="171" href="#171">171</a>		<a class="d" href="#BIT_DIGIT">BIT_DIGIT</a>[<span class="n">1</span>] = <a class="d" href="#oneBit">oneBit</a>;
<a class="l" name="172" href="#172">172</a>	}
<a class="l" name="173" href="#173">173</a>
<a class="l" name="174" href="#174">174</a>	<span class="c">/*
<a class="l" name="175" href="#175">175</a>	 * Converts a byte array to hex string
<a class="l" name="176" href="#176">176</a>	 */</span>
<a class="l" name="177" href="#177">177</a>
<a class="l" name="178" href="#178">178</a>	<span class="c">/**
<a class="l" name="179" href="#179">179</a>	 * Description of the Method
<a class="hl" name="180" href="#180">180</a>	 *
<a class="l" name="181" href="#181">181</a>	 * <strong>@param</strong> <em>block</em> Description of Parameter
<a class="l" name="182" href="#182">182</a>	 * <strong>@return</strong> Description of the Returned Value
<a class="l" name="183" href="#183">183</a>	 */</span>
<a class="l" name="184" href="#184">184</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="byteArrayToBinaryString"/><a href="/source/s?refs=byteArrayToBinaryString&amp;project=rtmp_client" class="xmt">byteArrayToBinaryString</a>(<b>byte</b>[] <a class="xa" name="block"/><a href="/source/s?refs=block&amp;project=rtmp_client" class="xa">block</a>) {
<a class="l" name="185" href="#185">185</a>
<a class="l" name="186" href="#186">186</a>		<a href="/source/s?defs=StringBuffer&amp;project=rtmp_client">StringBuffer</a> <a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a> = <b>new</b> <a href="/source/s?defs=StringBuffer&amp;project=rtmp_client">StringBuffer</a>();
<a class="l" name="187" href="#187">187</a>		<b>int</b> <a href="/source/s?defs=iLen&amp;project=rtmp_client">iLen</a> = <a href="/source/s?defs=block&amp;project=rtmp_client">block</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>;
<a class="l" name="188" href="#188">188</a>
<a class="l" name="189" href="#189">189</a>		<span class="c">// ---- for all bytes of array</span>
<a class="hl" name="190" href="#190">190</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=iLen&amp;project=rtmp_client">iLen</a>; i++) {
<a class="l" name="191" href="#191">191</a>			<a class="d" href="#byte2bin">byte2bin</a>(<a href="/source/s?defs=block&amp;project=rtmp_client">block</a>[i], <a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a>);
<a class="l" name="192" href="#192">192</a>
<a class="l" name="193" href="#193">193</a>			<span class="c">// ---- if bit i is set ----//</span>
<a class="l" name="194" href="#194">194</a>			<b>if</b> ((i &lt; <a href="/source/s?defs=iLen&amp;project=rtmp_client">iLen</a> - <span class="n">1</span>) &amp; <a class="d" href="#WITH_BYTE_SEPARATOR">WITH_BYTE_SEPARATOR</a>) {
<a class="l" name="195" href="#195">195</a>				<a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a class="d" href="#BYTE_SEPARATOR">BYTE_SEPARATOR</a>);
<a class="l" name="196" href="#196">196</a>			}
<a class="l" name="197" href="#197">197</a>		}
<a class="l" name="198" href="#198">198</a>
<a class="l" name="199" href="#199">199</a>		<b>return</b> <a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>();
<a class="hl" name="200" href="#200">200</a>	}
<a class="l" name="201" href="#201">201</a>
<a class="l" name="202" href="#202">202</a>	<span class="c">/**
<a class="l" name="203" href="#203">203</a>	 * Method toBinaryString
<a class="l" name="204" href="#204">204</a>	 *
<a class="l" name="205" href="#205">205</a>	 * <strong>@param</strong> <em>ba</em> binary array
<a class="l" name="206" href="#206">206</a>	 * <strong>@return</strong> the binary representation of the byte array
<a class="l" name="207" href="#207">207</a>	 */</span>
<a class="l" name="208" href="#208">208</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toBinaryString"/><a href="/source/s?refs=toBinaryString&amp;project=rtmp_client" class="xmt">toBinaryString</a>(<b>byte</b>[] <a class="xa" name="ba"/><a href="/source/s?refs=ba&amp;project=rtmp_client" class="xa">ba</a>) {
<a class="l" name="209" href="#209">209</a>		<b>return</b> <a class="d" href="#byteArrayToBinaryString">byteArrayToBinaryString</a>(<a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a>);
<a class="hl" name="210" href="#210">210</a>	}
<a class="l" name="211" href="#211">211</a>
<a class="l" name="212" href="#212">212</a>	<span class="c">/**
<a class="l" name="213" href="#213">213</a>	 * Method toBinaryString
<a class="l" name="214" href="#214">214</a>	 *
<a class="l" name="215" href="#215">215</a>	 * <strong>@param</strong> b byte array
<a class="l" name="216" href="#216">216</a>	 * <strong>@return</strong> the binary representation of the byte
<a class="l" name="217" href="#217">217</a>	 */</span>
<a class="l" name="218" href="#218">218</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toBinaryString"/><a href="/source/s?refs=toBinaryString&amp;project=rtmp_client" class="xmt">toBinaryString</a>(<b>byte</b> b) {
<a class="l" name="219" href="#219">219</a>		<b>byte</b>[] <a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a> = <b>new</b> <b>byte</b>[<span class="n">1</span>];
<a class="hl" name="220" href="#220">220</a>		<a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a>[<span class="n">0</span>] = b;
<a class="l" name="221" href="#221">221</a>		<b>return</b> <a class="d" href="#byteArrayToBinaryString">byteArrayToBinaryString</a>(<a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a>);
<a class="l" name="222" href="#222">222</a>	}
<a class="l" name="223" href="#223">223</a>
<a class="l" name="224" href="#224">224</a>	<span class="c">/**
<a class="l" name="225" href="#225">225</a>	 * Method toBinaryString
<a class="l" name="226" href="#226">226</a>	 *
<a class="l" name="227" href="#227">227</a>	 * <strong>@param</strong> s short
<a class="l" name="228" href="#228">228</a>	 * <strong>@return</strong> the binary representation of the short
<a class="l" name="229" href="#229">229</a>	 */</span>
<a class="hl" name="230" href="#230">230</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toBinaryString"/><a href="/source/s?refs=toBinaryString&amp;project=rtmp_client" class="xmt">toBinaryString</a>(<b>short</b> s) {
<a class="l" name="231" href="#231">231</a>		<b>return</b> <a href="/source/s?defs=toBinaryString&amp;project=rtmp_client">toBinaryString</a>(<a href="/source/s?defs=toByteArray&amp;project=rtmp_client">toByteArray</a>(s));
<a class="l" name="232" href="#232">232</a>	}
<a class="l" name="233" href="#233">233</a>
<a class="l" name="234" href="#234">234</a>	<span class="c">/**
<a class="l" name="235" href="#235">235</a>	 * Method toBinaryString
<a class="l" name="236" href="#236">236</a>	 *
<a class="l" name="237" href="#237">237</a>	 * <strong>@param</strong> i integer
<a class="l" name="238" href="#238">238</a>	 * <strong>@return</strong> the binary representation of the int
<a class="l" name="239" href="#239">239</a>	 */</span>
<a class="hl" name="240" href="#240">240</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toBinaryString"/><a href="/source/s?refs=toBinaryString&amp;project=rtmp_client" class="xmt">toBinaryString</a>(<b>int</b> i) {
<a class="l" name="241" href="#241">241</a>		<b>return</b> <a href="/source/s?defs=toBinaryString&amp;project=rtmp_client">toBinaryString</a>(<a href="/source/s?defs=toByteArray&amp;project=rtmp_client">toByteArray</a>(i));
<a class="l" name="242" href="#242">242</a>	}
<a class="l" name="243" href="#243">243</a>
<a class="l" name="244" href="#244">244</a>	<span class="c">/**
<a class="l" name="245" href="#245">245</a>	 * Method toBinaryString
<a class="l" name="246" href="#246">246</a>	 *
<a class="l" name="247" href="#247">247</a>	 * <strong>@param</strong> l long
<a class="l" name="248" href="#248">248</a>	 * <strong>@return</strong> the binary representation of the long
<a class="l" name="249" href="#249">249</a>	 */</span>
<a class="hl" name="250" href="#250">250</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toBinaryString"/><a href="/source/s?refs=toBinaryString&amp;project=rtmp_client" class="xmt">toBinaryString</a>(<b>long</b> l) {
<a class="l" name="251" href="#251">251</a>		<b>return</b> <a href="/source/s?defs=toBinaryString&amp;project=rtmp_client">toBinaryString</a>(<a href="/source/s?defs=toByteArray&amp;project=rtmp_client">toByteArray</a>(l));
<a class="l" name="252" href="#252">252</a>	}
<a class="l" name="253" href="#253">253</a>
<a class="l" name="254" href="#254">254</a>	<span class="c">/**
<a class="l" name="255" href="#255">255</a>	 * Method toByteArray
<a class="l" name="256" href="#256">256</a>	 *
<a class="l" name="257" href="#257">257</a>	 * <strong>@param</strong> s short
<a class="l" name="258" href="#258">258</a>	 * <strong>@return</strong> the short as array of bytes
<a class="l" name="259" href="#259">259</a>	 */</span>
<a class="hl" name="260" href="#260">260</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b>[] <a class="xmt" name="toByteArray"/><a href="/source/s?refs=toByteArray&amp;project=rtmp_client" class="xmt">toByteArray</a>(<b>short</b> s) {
<a class="l" name="261" href="#261">261</a>		<b>byte</b>[] <a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a> = <b>new</b> <b>byte</b>[<span class="n">2</span>];
<a class="l" name="262" href="#262">262</a>		<a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a>[<span class="n">1</span>] = (<b>byte</b>) (s);
<a class="l" name="263" href="#263">263</a>		<a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a>[<span class="n">0</span>] = (<b>byte</b>) (s &gt;&gt; <span class="n">8</span>);
<a class="l" name="264" href="#264">264</a>		<b>return</b> <a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a>;
<a class="l" name="265" href="#265">265</a>	}
<a class="l" name="266" href="#266">266</a>
<a class="l" name="267" href="#267">267</a>	<span class="c">/**
<a class="l" name="268" href="#268">268</a>	 * Method toByteArray
<a class="l" name="269" href="#269">269</a>	 *
<a class="hl" name="270" href="#270">270</a>	 * <strong>@param</strong> i int
<a class="l" name="271" href="#271">271</a>	 * <strong>@return</strong> the int as array of bytes
<a class="l" name="272" href="#272">272</a>	 */</span>
<a class="l" name="273" href="#273">273</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b>[] <a class="xmt" name="toByteArray"/><a href="/source/s?refs=toByteArray&amp;project=rtmp_client" class="xmt">toByteArray</a>(<b>int</b> i) {
<a class="l" name="274" href="#274">274</a>		<b>byte</b>[] <a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a> = <b>new</b> <b>byte</b>[<span class="n">4</span>];
<a class="l" name="275" href="#275">275</a>		<a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a>[<span class="n">3</span>] = (<b>byte</b>) i;
<a class="l" name="276" href="#276">276</a>		<a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a>[<span class="n">2</span>] = (<b>byte</b>) (i &gt;&gt; <span class="n">8</span>);
<a class="l" name="277" href="#277">277</a>		<a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a>[<span class="n">1</span>] = (<b>byte</b>) (i &gt;&gt; <span class="n">16</span>);
<a class="l" name="278" href="#278">278</a>		<a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a>[<span class="n">0</span>] = (<b>byte</b>) (i &gt;&gt; <span class="n">24</span>);
<a class="l" name="279" href="#279">279</a>		<b>return</b> <a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a>;
<a class="hl" name="280" href="#280">280</a>	}
<a class="l" name="281" href="#281">281</a>
<a class="l" name="282" href="#282">282</a>	<span class="c">/**
<a class="l" name="283" href="#283">283</a>	 * Method toByteArray
<a class="l" name="284" href="#284">284</a>	 *
<a class="l" name="285" href="#285">285</a>	 * <strong>@param</strong> l long
<a class="l" name="286" href="#286">286</a>	 * <strong>@return</strong> the long as array of bytes
<a class="l" name="287" href="#287">287</a>	 */</span>
<a class="l" name="288" href="#288">288</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b>[] <a class="xmt" name="toByteArray"/><a href="/source/s?refs=toByteArray&amp;project=rtmp_client" class="xmt">toByteArray</a>(<b>long</b> l) {
<a class="l" name="289" href="#289">289</a>		<b>byte</b>[] <a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a> = <b>new</b> <b>byte</b>[<span class="n">8</span>];
<a class="hl" name="290" href="#290">290</a>		<a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a>[<span class="n">7</span>] = (<b>byte</b>) l;
<a class="l" name="291" href="#291">291</a>		<a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a>[<span class="n">6</span>] = (<b>byte</b>) (l &gt;&gt; <span class="n">8</span>);
<a class="l" name="292" href="#292">292</a>		<a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a>[<span class="n">5</span>] = (<b>byte</b>) (l &gt;&gt; <span class="n">16</span>);
<a class="l" name="293" href="#293">293</a>		<a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a>[<span class="n">4</span>] = (<b>byte</b>) (l &gt;&gt; <span class="n">24</span>);
<a class="l" name="294" href="#294">294</a>		<a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a>[<span class="n">3</span>] = (<b>byte</b>) (l &gt;&gt; <span class="n">32</span>);
<a class="l" name="295" href="#295">295</a>		<a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a>[<span class="n">2</span>] = (<b>byte</b>) (l &gt;&gt; <span class="n">40</span>);
<a class="l" name="296" href="#296">296</a>		<a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a>[<span class="n">1</span>] = (<b>byte</b>) (l &gt;&gt; <span class="n">48</span>);
<a class="l" name="297" href="#297">297</a>		<a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a>[<span class="n">0</span>] = (<b>byte</b>) (l &gt;&gt; <span class="n">56</span>);
<a class="l" name="298" href="#298">298</a>		<b>return</b> <a href="/source/s?defs=baTemp&amp;project=rtmp_client">baTemp</a>;
<a class="l" name="299" href="#299">299</a>	}
<a class="hl" name="300" href="#300">300</a>
<a class="l" name="301" href="#301">301</a>	<span class="c">/**
<a class="l" name="302" href="#302">302</a>	 * Description of the Method
<a class="l" name="303" href="#303">303</a>	 *
<a class="l" name="304" href="#304">304</a>	 * <strong>@param</strong> <em>block</em> Description of Parameter
<a class="l" name="305" href="#305">305</a>	 * <strong>@return</strong> Description of the Returned Value
<a class="l" name="306" href="#306">306</a>	 */</span>
<a class="l" name="307" href="#307">307</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="byteArrayToHexString"/><a href="/source/s?refs=byteArrayToHexString&amp;project=rtmp_client" class="xmt">byteArrayToHexString</a>(<b>byte</b>[] <a class="xa" name="block"/><a href="/source/s?refs=block&amp;project=rtmp_client" class="xa">block</a>) {
<a class="l" name="308" href="#308">308</a>		<a href="/source/s?defs=StringBuffer&amp;project=rtmp_client">StringBuffer</a> <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> = <b>new</b> <a href="/source/s?defs=StringBuffer&amp;project=rtmp_client">StringBuffer</a>();
<a class="l" name="309" href="#309">309</a>		<b>int</b> <a href="/source/s?defs=len&amp;project=rtmp_client">len</a> = <a href="/source/s?defs=block&amp;project=rtmp_client">block</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>;
<a class="hl" name="310" href="#310">310</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>; i++) {
<a class="l" name="311" href="#311">311</a>			<a class="d" href="#byte2hex">byte2hex</a>(<a href="/source/s?defs=block&amp;project=rtmp_client">block</a>[i], <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="312" href="#312">312</a>			<b>if</b> ((i &lt; <a href="/source/s?defs=len&amp;project=rtmp_client">len</a> - <span class="n">1</span>) &amp; <a class="d" href="#WITH_BYTE_SEPARATOR">WITH_BYTE_SEPARATOR</a>) {
<a class="l" name="313" href="#313">313</a>				<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a class="d" href="#BYTE_SEPARATOR">BYTE_SEPARATOR</a>);
<a class="l" name="314" href="#314">314</a>			}
<a class="l" name="315" href="#315">315</a>		}
<a class="l" name="316" href="#316">316</a>		<b>return</b> <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>();
<a class="l" name="317" href="#317">317</a>	}
<a class="l" name="318" href="#318">318</a>
<a class="l" name="319" href="#319">319</a>	<span class="c">/**
<a class="hl" name="320" href="#320">320</a>	 * Description of the Method
<a class="l" name="321" href="#321">321</a>	 *
<a class="l" name="322" href="#322">322</a>	 * <strong>@param</strong> <em>in</em> string to be converted
<a class="l" name="323" href="#323">323</a>	 * <strong>@return</strong> String in readable hex encoding
<a class="l" name="324" href="#324">324</a>	 */</span>
<a class="l" name="325" href="#325">325</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="stringToHexString"/><a href="/source/s?refs=stringToHexString&amp;project=rtmp_client" class="xmt">stringToHexString</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="326" href="#326">326</a>		<b>byte</b>[] <a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getBytes&amp;project=rtmp_client">getBytes</a>();
<a class="l" name="327" href="#327">327</a>		<b>return</b> <a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>(<a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a>);
<a class="l" name="328" href="#328">328</a>	}
<a class="l" name="329" href="#329">329</a>
<a class="hl" name="330" href="#330">330</a>	<span class="c">/**
<a class="l" name="331" href="#331">331</a>	 * Description of the Method
<a class="l" name="332" href="#332">332</a>	 *
<a class="l" name="333" href="#333">333</a>	 * <strong>@param</strong> <em>block</em> Description of Parameter
<a class="l" name="334" href="#334">334</a>	 * <strong>@param</strong> <em>offset</em> Description of Parameter
<a class="l" name="335" href="#335">335</a>	 * <strong>@param</strong> <em>length</em> Description of Parameter
<a class="l" name="336" href="#336">336</a>	 * <strong>@return</strong> Description of the Returned Value
<a class="l" name="337" href="#337">337</a>	 */</span>
<a class="l" name="338" href="#338">338</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="byteArrayToHexString"/><a href="/source/s?refs=byteArrayToHexString&amp;project=rtmp_client" class="xmt">byteArrayToHexString</a>(<b>byte</b>[] <a class="xa" name="block"/><a href="/source/s?refs=block&amp;project=rtmp_client" class="xa">block</a>, <b>int</b> <a class="xa" name="offset"/><a href="/source/s?refs=offset&amp;project=rtmp_client" class="xa">offset</a>, <b>int</b> <a class="xa" name="length"/><a href="/source/s?refs=length&amp;project=rtmp_client" class="xa">length</a>) {
<a class="l" name="339" href="#339">339</a>		<a href="/source/s?defs=StringBuffer&amp;project=rtmp_client">StringBuffer</a> <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> = <b>new</b> <a href="/source/s?defs=StringBuffer&amp;project=rtmp_client">StringBuffer</a>();
<a class="hl" name="340" href="#340">340</a>		<b>int</b> <a href="/source/s?defs=len&amp;project=rtmp_client">len</a> = <a href="/source/s?defs=block&amp;project=rtmp_client">block</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>;
<a class="l" name="341" href="#341">341</a>		<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> = <a href="/source/s?defs=length&amp;project=rtmp_client">length</a> + <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>;
<a class="l" name="342" href="#342">342</a>		<b>if</b> ((<a href="/source/s?defs=len&amp;project=rtmp_client">len</a> &lt; <a href="/source/s?defs=length&amp;project=rtmp_client">length</a>)) {
<a class="l" name="343" href="#343">343</a>			<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> = <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>;
<a class="l" name="344" href="#344">344</a>		}
<a class="l" name="345" href="#345">345</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span> + <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>; i &lt; <a href="/source/s?defs=length&amp;project=rtmp_client">length</a>; i++) {
<a class="l" name="346" href="#346">346</a>			<a class="d" href="#byte2hex">byte2hex</a>(<a href="/source/s?defs=block&amp;project=rtmp_client">block</a>[i], <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="347" href="#347">347</a>			<b>if</b> (i &lt; <a href="/source/s?defs=length&amp;project=rtmp_client">length</a> - <span class="n">1</span>) {
<a class="l" name="348" href="#348">348</a>				<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">':'</span>);
<a class="l" name="349" href="#349">349</a>			}
<a class="hl" name="350" href="#350">350</a>		}
<a class="l" name="351" href="#351">351</a>		<b>return</b> <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>();
<a class="l" name="352" href="#352">352</a>	}
<a class="l" name="353" href="#353">353</a>
<a class="l" name="354" href="#354">354</a>	<span class="c">/**
<a class="l" name="355" href="#355">355</a>	 * Returns a string of hexadecimal digits from a byte array. Each byte is
<a class="l" name="356" href="#356">356</a>	 * converted to 2 hex symbols.
<a class="l" name="357" href="#357">357</a>	 *
<a class="l" name="358" href="#358">358</a>	 * <strong>@param</strong> <em>ba</em> Description of Parameter
<a class="l" name="359" href="#359">359</a>	 * <strong>@return</strong> Description of the Returned Value
<a class="hl" name="360" href="#360">360</a>	 */</span>
<a class="l" name="361" href="#361">361</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toHexString"/><a href="/source/s?refs=toHexString&amp;project=rtmp_client" class="xmt">toHexString</a>(<b>byte</b>[] <a class="xa" name="ba"/><a href="/source/s?refs=ba&amp;project=rtmp_client" class="xa">ba</a>) {
<a class="l" name="362" href="#362">362</a>		<b>return</b> <a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>(<a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a>, <span class="n">0</span>, <a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>);
<a class="l" name="363" href="#363">363</a>	}
<a class="l" name="364" href="#364">364</a>
<a class="l" name="365" href="#365">365</a>	<span class="c">/**
<a class="l" name="366" href="#366">366</a>	 * Method toHexString
<a class="l" name="367" href="#367">367</a>	 *
<a class="l" name="368" href="#368">368</a>	 * <strong>@param</strong> b byte
<a class="l" name="369" href="#369">369</a>	 * <strong>@return</strong> the hexadecimal representation of the byte
<a class="hl" name="370" href="#370">370</a>	 */</span>
<a class="l" name="371" href="#371">371</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toHexString"/><a href="/source/s?refs=toHexString&amp;project=rtmp_client" class="xmt">toHexString</a>(<b>byte</b> b) {
<a class="l" name="372" href="#372">372</a>		<b>byte</b>[] <a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a> = <b>new</b> <b>byte</b>[<span class="n">1</span>];
<a class="l" name="373" href="#373">373</a>		<a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a>[<span class="n">0</span>] = b;
<a class="l" name="374" href="#374">374</a>		<b>return</b> <a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>(<a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a>, <span class="n">0</span>, <a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>);
<a class="l" name="375" href="#375">375</a>	}
<a class="l" name="376" href="#376">376</a>
<a class="l" name="377" href="#377">377</a>	<span class="c">/**
<a class="l" name="378" href="#378">378</a>	 * Description of the Method
<a class="l" name="379" href="#379">379</a>	 *
<a class="hl" name="380" href="#380">380</a>	 * <strong>@param</strong> s short
<a class="l" name="381" href="#381">381</a>	 * <strong>@return</strong> Description of the Returned Value
<a class="l" name="382" href="#382">382</a>	 */</span>
<a class="l" name="383" href="#383">383</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toHexString"/><a href="/source/s?refs=toHexString&amp;project=rtmp_client" class="xmt">toHexString</a>(<b>short</b> s) {
<a class="l" name="384" href="#384">384</a>		<b>return</b> <a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>(<a href="/source/s?defs=toByteArray&amp;project=rtmp_client">toByteArray</a>(s));
<a class="l" name="385" href="#385">385</a>	}
<a class="l" name="386" href="#386">386</a>
<a class="l" name="387" href="#387">387</a>	<span class="c">/**
<a class="l" name="388" href="#388">388</a>	 * Method toHexString
<a class="l" name="389" href="#389">389</a>	 *
<a class="hl" name="390" href="#390">390</a>	 * <strong>@param</strong> i int
<a class="l" name="391" href="#391">391</a>	 * <strong>@return</strong> the hexadecimal representation of the int
<a class="l" name="392" href="#392">392</a>	 */</span>
<a class="l" name="393" href="#393">393</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toHexString"/><a href="/source/s?refs=toHexString&amp;project=rtmp_client" class="xmt">toHexString</a>(<b>int</b> i) {
<a class="l" name="394" href="#394">394</a>		<b>return</b> <a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>(<a href="/source/s?defs=toByteArray&amp;project=rtmp_client">toByteArray</a>(i));
<a class="l" name="395" href="#395">395</a>	}
<a class="l" name="396" href="#396">396</a>
<a class="l" name="397" href="#397">397</a>	<span class="c">/**
<a class="l" name="398" href="#398">398</a>	 * Method toHexString
<a class="l" name="399" href="#399">399</a>	 *
<a class="hl" name="400" href="#400">400</a>	 * <strong>@param</strong> l long
<a class="l" name="401" href="#401">401</a>	 * <strong>@return</strong> the hexadecimal representation of the long
<a class="l" name="402" href="#402">402</a>	 */</span>
<a class="l" name="403" href="#403">403</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toHexString"/><a href="/source/s?refs=toHexString&amp;project=rtmp_client" class="xmt">toHexString</a>(<b>long</b> l) {
<a class="l" name="404" href="#404">404</a>		<b>return</b> <a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>(<a href="/source/s?defs=toByteArray&amp;project=rtmp_client">toByteArray</a>(l));
<a class="l" name="405" href="#405">405</a>	}
<a class="l" name="406" href="#406">406</a>
<a class="l" name="407" href="#407">407</a>	<span class="c">/**
<a class="l" name="408" href="#408">408</a>	 * Method toString
<a class="l" name="409" href="#409">409</a>	 *
<a class="hl" name="410" href="#410">410</a>	 * <strong>@param</strong> <em>ba</em> byte array
<a class="l" name="411" href="#411">411</a>	 * <strong>@return</strong> the byte array as string
<a class="l" name="412" href="#412">412</a>	 */</span>
<a class="l" name="413" href="#413">413</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toString"/><a href="/source/s?refs=toString&amp;project=rtmp_client" class="xmt">toString</a>(<b>byte</b>[] <a class="xa" name="ba"/><a href="/source/s?refs=ba&amp;project=rtmp_client" class="xa">ba</a>) {
<a class="l" name="414" href="#414">414</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>(<a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a>);
<a class="l" name="415" href="#415">415</a>	}
<a class="l" name="416" href="#416">416</a>
<a class="l" name="417" href="#417">417</a>	<span class="c">/**
<a class="l" name="418" href="#418">418</a>	 * Method toString
<a class="l" name="419" href="#419">419</a>	 *
<a class="hl" name="420" href="#420">420</a>	 * <strong>@param</strong> b byte
<a class="l" name="421" href="#421">421</a>	 * <strong>@return</strong> the byte as string
<a class="l" name="422" href="#422">422</a>	 */</span>
<a class="l" name="423" href="#423">423</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toString"/><a href="/source/s?refs=toString&amp;project=rtmp_client" class="xmt">toString</a>(<b>byte</b> b) {
<a class="l" name="424" href="#424">424</a>		<b>byte</b>[] <a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a> = <b>new</b> <b>byte</b>[<span class="n">1</span>];
<a class="l" name="425" href="#425">425</a>		<a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a>[<span class="n">0</span>] = b;
<a class="l" name="426" href="#426">426</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>(<a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a>);
<a class="l" name="427" href="#427">427</a>	}
<a class="l" name="428" href="#428">428</a>
<a class="l" name="429" href="#429">429</a>	<span class="c">/**
<a class="hl" name="430" href="#430">430</a>	 * converts String to Hex String. Example: niko -&gt;6E696B6F
<a class="l" name="431" href="#431">431</a>	 *
<a class="l" name="432" href="#432">432</a>	 * <strong>@param</strong> <em>ba</em> byte array
<a class="l" name="433" href="#433">433</a>	 * <strong>@param</strong> <em>offset</em> offset in array
<a class="l" name="434" href="#434">434</a>	 * <strong>@param</strong> <em>length</em> number of bytes
<a class="l" name="435" href="#435">435</a>	 * <strong>@return</strong> Description of the Returned Value
<a class="l" name="436" href="#436">436</a>	 */</span>
<a class="l" name="437" href="#437">437</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toHexString"/><a href="/source/s?refs=toHexString&amp;project=rtmp_client" class="xmt">toHexString</a>(<b>byte</b>[] <a class="xa" name="ba"/><a href="/source/s?refs=ba&amp;project=rtmp_client" class="xa">ba</a>, <b>int</b> <a class="xa" name="offset"/><a href="/source/s?refs=offset&amp;project=rtmp_client" class="xa">offset</a>, <b>int</b> <a class="xa" name="length"/><a href="/source/s?refs=length&amp;project=rtmp_client" class="xa">length</a>) {
<a class="l" name="438" href="#438">438</a>		<b>char</b>[] <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>;
<a class="l" name="439" href="#439">439</a>		<b>if</b> (<a class="d" href="#WITH_BYTE_SEPARATOR">WITH_BYTE_SEPARATOR</a>) {
<a class="hl" name="440" href="#440">440</a>			<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> = <b>new</b> <b>char</b>[<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> * <span class="n">3</span>];
<a class="l" name="441" href="#441">441</a>		} <b>else</b> {
<a class="l" name="442" href="#442">442</a>			<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> = <b>new</b> <b>char</b>[<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> * <span class="n">2</span>];
<a class="l" name="443" href="#443">443</a>		}
<a class="l" name="444" href="#444">444</a>		<b>for</b> (<b>int</b> i = <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>, j = <span class="n">0</span>, k; i &lt; <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> + <a href="/source/s?defs=length&amp;project=rtmp_client">length</a>;) {
<a class="l" name="445" href="#445">445</a>			k = <a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a>[i++];
<a class="l" name="446" href="#446">446</a>			<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>[j++] = <a class="d" href="#HEX_DIGITS">HEX_DIGITS</a>[(k &gt;&gt;&gt; <span class="n">4</span>) &amp; <span class="n">0x0F</span>];
<a class="l" name="447" href="#447">447</a>			<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>[j++] = <a class="d" href="#HEX_DIGITS">HEX_DIGITS</a>[k &amp; <span class="n">0x0F</span>];
<a class="l" name="448" href="#448">448</a>			<b>if</b> (<a class="d" href="#WITH_BYTE_SEPARATOR">WITH_BYTE_SEPARATOR</a>) {
<a class="l" name="449" href="#449">449</a>				<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>[j++] = <a class="d" href="#BYTE_SEPARATOR">BYTE_SEPARATOR</a>;
<a class="hl" name="450" href="#450">450</a>			}
<a class="l" name="451" href="#451">451</a>		}
<a class="l" name="452" href="#452">452</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="453" href="#453">453</a>	}
<a class="l" name="454" href="#454">454</a>
<a class="l" name="455" href="#455">455</a>	<span class="c">/**
<a class="l" name="456" href="#456">456</a>	 * Converts readable hex-String to byteArray
<a class="l" name="457" href="#457">457</a>	 *
<a class="l" name="458" href="#458">458</a>	 * <strong>@param</strong> <em>strA</em> string
<a class="l" name="459" href="#459">459</a>	 * <strong>@return</strong> the hexadecimal string as byte array
<a class="hl" name="460" href="#460">460</a>	 */</span>
<a class="l" name="461" href="#461">461</a>	<b>public</b> <b>static</b> <b>byte</b>[] <a class="xmt" name="hexStringToByteArray"/><a href="/source/s?refs=hexStringToByteArray&amp;project=rtmp_client" class="xmt">hexStringToByteArray</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="strA"/><a href="/source/s?refs=strA&amp;project=rtmp_client" class="xa">strA</a>) {
<a class="l" name="462" href="#462">462</a>		<a href="/source/s?defs=ByteArrayOutputStream&amp;project=rtmp_client">ByteArrayOutputStream</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>new</b> <a href="/source/s?defs=ByteArrayOutputStream&amp;project=rtmp_client">ByteArrayOutputStream</a>();
<a class="l" name="463" href="#463">463</a>
<a class="l" name="464" href="#464">464</a>		<b>byte</b> <a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> = (<b>byte</b>) <span class="n">0x00</span>;
<a class="l" name="465" href="#465">465</a>		<b>boolean</b> <a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>true</b>;
<a class="l" name="466" href="#466">466</a>
<a class="l" name="467" href="#467">467</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#strA">strA</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>(); i++) {
<a class="l" name="468" href="#468">468</a>			<b>char</b> c = <a class="d" href="#strA">strA</a>.<a href="/source/s?defs=charAt&amp;project=rtmp_client">charAt</a>(i);
<a class="l" name="469" href="#469">469</a>
<a class="hl" name="470" href="#470">470</a>			<b>switch</b> (<a href="/source/s?defs=Character&amp;project=rtmp_client">Character</a>.<a href="/source/s?defs=toUpperCase&amp;project=rtmp_client">toUpperCase</a>(c)) {
<a class="l" name="471" href="#471">471</a>
<a class="l" name="472" href="#472">472</a>				<b>case</b> <span class="s">'0'</span>:
<a class="l" name="473" href="#473">473</a>					<b>if</b> (<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a>) {
<a class="l" name="474" href="#474">474</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> = (<b>byte</b>) <span class="n">0x00</span>;
<a class="l" name="475" href="#475">475</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>false</b>;
<a class="l" name="476" href="#476">476</a>					} <b>else</b> {
<a class="l" name="477" href="#477">477</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> |= (<b>byte</b>) <span class="n">0x00</span>;
<a class="l" name="478" href="#478">478</a>						<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a>);
<a class="l" name="479" href="#479">479</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>true</b>;
<a class="hl" name="480" href="#480">480</a>					}
<a class="l" name="481" href="#481">481</a>					<b>break</b>;
<a class="l" name="482" href="#482">482</a>
<a class="l" name="483" href="#483">483</a>				<b>case</b> <span class="s">'1'</span>:
<a class="l" name="484" href="#484">484</a>					<b>if</b> (<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a>) {
<a class="l" name="485" href="#485">485</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> = (<b>byte</b>) <span class="n">0x10</span>;
<a class="l" name="486" href="#486">486</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>false</b>;
<a class="l" name="487" href="#487">487</a>					} <b>else</b> {
<a class="l" name="488" href="#488">488</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> |= (<b>byte</b>) <span class="n">0x01</span>;
<a class="l" name="489" href="#489">489</a>						<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a>);
<a class="hl" name="490" href="#490">490</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>true</b>;
<a class="l" name="491" href="#491">491</a>					}
<a class="l" name="492" href="#492">492</a>					<b>break</b>;
<a class="l" name="493" href="#493">493</a>
<a class="l" name="494" href="#494">494</a>				<b>case</b> <span class="s">'2'</span>:
<a class="l" name="495" href="#495">495</a>					<b>if</b> (<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a>) {
<a class="l" name="496" href="#496">496</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> = (<b>byte</b>) <span class="n">0x20</span>;
<a class="l" name="497" href="#497">497</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>false</b>;
<a class="l" name="498" href="#498">498</a>					} <b>else</b> {
<a class="l" name="499" href="#499">499</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> |= (<b>byte</b>) <span class="n">0x02</span>;
<a class="hl" name="500" href="#500">500</a>						<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a>);
<a class="l" name="501" href="#501">501</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>true</b>;
<a class="l" name="502" href="#502">502</a>					}
<a class="l" name="503" href="#503">503</a>					<b>break</b>;
<a class="l" name="504" href="#504">504</a>
<a class="l" name="505" href="#505">505</a>				<b>case</b> <span class="s">'3'</span>:
<a class="l" name="506" href="#506">506</a>					<b>if</b> (<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a>) {
<a class="l" name="507" href="#507">507</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> = (<b>byte</b>) <span class="n">0x30</span>;
<a class="l" name="508" href="#508">508</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>false</b>;
<a class="l" name="509" href="#509">509</a>					} <b>else</b> {
<a class="hl" name="510" href="#510">510</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> |= (<b>byte</b>) <span class="n">0x03</span>;
<a class="l" name="511" href="#511">511</a>						<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a>);
<a class="l" name="512" href="#512">512</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>true</b>;
<a class="l" name="513" href="#513">513</a>					}
<a class="l" name="514" href="#514">514</a>					<b>break</b>;
<a class="l" name="515" href="#515">515</a>
<a class="l" name="516" href="#516">516</a>				<b>case</b> <span class="s">'4'</span>:
<a class="l" name="517" href="#517">517</a>					<b>if</b> (<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a>) {
<a class="l" name="518" href="#518">518</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> = (<b>byte</b>) <span class="n">0x40</span>;
<a class="l" name="519" href="#519">519</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>false</b>;
<a class="hl" name="520" href="#520">520</a>					} <b>else</b> {
<a class="l" name="521" href="#521">521</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> |= (<b>byte</b>) <span class="n">0x04</span>;
<a class="l" name="522" href="#522">522</a>						<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a>);
<a class="l" name="523" href="#523">523</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>true</b>;
<a class="l" name="524" href="#524">524</a>					}
<a class="l" name="525" href="#525">525</a>					<b>break</b>;
<a class="l" name="526" href="#526">526</a>
<a class="l" name="527" href="#527">527</a>				<b>case</b> <span class="s">'5'</span>:
<a class="l" name="528" href="#528">528</a>					<b>if</b> (<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a>) {
<a class="l" name="529" href="#529">529</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> = (<b>byte</b>) <span class="n">0x50</span>;
<a class="hl" name="530" href="#530">530</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>false</b>;
<a class="l" name="531" href="#531">531</a>					} <b>else</b> {
<a class="l" name="532" href="#532">532</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> |= (<b>byte</b>) <span class="n">0x05</span>;
<a class="l" name="533" href="#533">533</a>						<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a>);
<a class="l" name="534" href="#534">534</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>true</b>;
<a class="l" name="535" href="#535">535</a>					}
<a class="l" name="536" href="#536">536</a>					<b>break</b>;
<a class="l" name="537" href="#537">537</a>
<a class="l" name="538" href="#538">538</a>				<b>case</b> <span class="s">'6'</span>:
<a class="l" name="539" href="#539">539</a>					<b>if</b> (<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a>) {
<a class="hl" name="540" href="#540">540</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> = (<b>byte</b>) <span class="n">0x60</span>;
<a class="l" name="541" href="#541">541</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>false</b>;
<a class="l" name="542" href="#542">542</a>					} <b>else</b> {
<a class="l" name="543" href="#543">543</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> |= (<b>byte</b>) <span class="n">0x06</span>;
<a class="l" name="544" href="#544">544</a>						<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a>);
<a class="l" name="545" href="#545">545</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>true</b>;
<a class="l" name="546" href="#546">546</a>					}
<a class="l" name="547" href="#547">547</a>					<b>break</b>;
<a class="l" name="548" href="#548">548</a>
<a class="l" name="549" href="#549">549</a>				<b>case</b> <span class="s">'7'</span>:
<a class="hl" name="550" href="#550">550</a>					<b>if</b> (<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a>) {
<a class="l" name="551" href="#551">551</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> = (<b>byte</b>) <span class="n">0x70</span>;
<a class="l" name="552" href="#552">552</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>false</b>;
<a class="l" name="553" href="#553">553</a>					} <b>else</b> {
<a class="l" name="554" href="#554">554</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> |= (<b>byte</b>) <span class="n">0x07</span>;
<a class="l" name="555" href="#555">555</a>						<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a>);
<a class="l" name="556" href="#556">556</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>true</b>;
<a class="l" name="557" href="#557">557</a>					}
<a class="l" name="558" href="#558">558</a>					<b>break</b>;
<a class="l" name="559" href="#559">559</a>
<a class="hl" name="560" href="#560">560</a>				<b>case</b> <span class="s">'8'</span>:
<a class="l" name="561" href="#561">561</a>					<b>if</b> (<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a>) {
<a class="l" name="562" href="#562">562</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> = (<b>byte</b>) <span class="n">0x80</span>;
<a class="l" name="563" href="#563">563</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>false</b>;
<a class="l" name="564" href="#564">564</a>					} <b>else</b> {
<a class="l" name="565" href="#565">565</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> |= (<b>byte</b>) <span class="n">0x08</span>;
<a class="l" name="566" href="#566">566</a>						<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a>);
<a class="l" name="567" href="#567">567</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>true</b>;
<a class="l" name="568" href="#568">568</a>					}
<a class="l" name="569" href="#569">569</a>					<b>break</b>;
<a class="hl" name="570" href="#570">570</a>
<a class="l" name="571" href="#571">571</a>				<b>case</b> <span class="s">'9'</span>:
<a class="l" name="572" href="#572">572</a>					<b>if</b> (<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a>) {
<a class="l" name="573" href="#573">573</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> = (<b>byte</b>) <span class="n">0x90</span>;
<a class="l" name="574" href="#574">574</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>false</b>;
<a class="l" name="575" href="#575">575</a>					} <b>else</b> {
<a class="l" name="576" href="#576">576</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> |= (<b>byte</b>) <span class="n">0x09</span>;
<a class="l" name="577" href="#577">577</a>						<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a>);
<a class="l" name="578" href="#578">578</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>true</b>;
<a class="l" name="579" href="#579">579</a>					}
<a class="hl" name="580" href="#580">580</a>					<b>break</b>;
<a class="l" name="581" href="#581">581</a>
<a class="l" name="582" href="#582">582</a>				<b>case</b> <span class="s">'A'</span>:
<a class="l" name="583" href="#583">583</a>					<b>if</b> (<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a>) {
<a class="l" name="584" href="#584">584</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> = (<b>byte</b>) <span class="n">0xA0</span>;
<a class="l" name="585" href="#585">585</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>false</b>;
<a class="l" name="586" href="#586">586</a>					} <b>else</b> {
<a class="l" name="587" href="#587">587</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> |= (<b>byte</b>) <span class="n">0x0A</span>;
<a class="l" name="588" href="#588">588</a>						<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a>);
<a class="l" name="589" href="#589">589</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>true</b>;
<a class="hl" name="590" href="#590">590</a>					}
<a class="l" name="591" href="#591">591</a>					<b>break</b>;
<a class="l" name="592" href="#592">592</a>
<a class="l" name="593" href="#593">593</a>				<b>case</b> <span class="s">'B'</span>:
<a class="l" name="594" href="#594">594</a>					<b>if</b> (<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a>) {
<a class="l" name="595" href="#595">595</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> = (<b>byte</b>) <span class="n">0xB0</span>;
<a class="l" name="596" href="#596">596</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>false</b>;
<a class="l" name="597" href="#597">597</a>					} <b>else</b> {
<a class="l" name="598" href="#598">598</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> |= (<b>byte</b>) <span class="n">0x0B</span>;
<a class="l" name="599" href="#599">599</a>						<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a>);
<a class="hl" name="600" href="#600">600</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>true</b>;
<a class="l" name="601" href="#601">601</a>					}
<a class="l" name="602" href="#602">602</a>					<b>break</b>;
<a class="l" name="603" href="#603">603</a>
<a class="l" name="604" href="#604">604</a>				<b>case</b> <span class="s">'C'</span>:
<a class="l" name="605" href="#605">605</a>					<b>if</b> (<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a>) {
<a class="l" name="606" href="#606">606</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> = (<b>byte</b>) <span class="n">0xC0</span>;
<a class="l" name="607" href="#607">607</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>false</b>;
<a class="l" name="608" href="#608">608</a>					} <b>else</b> {
<a class="l" name="609" href="#609">609</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> |= (<b>byte</b>) <span class="n">0x0C</span>;
<a class="hl" name="610" href="#610">610</a>						<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a>);
<a class="l" name="611" href="#611">611</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>true</b>;
<a class="l" name="612" href="#612">612</a>					}
<a class="l" name="613" href="#613">613</a>					<b>break</b>;
<a class="l" name="614" href="#614">614</a>
<a class="l" name="615" href="#615">615</a>				<b>case</b> <span class="s">'D'</span>:
<a class="l" name="616" href="#616">616</a>					<b>if</b> (<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a>) {
<a class="l" name="617" href="#617">617</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> = (<b>byte</b>) <span class="n">0xD0</span>;
<a class="l" name="618" href="#618">618</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>false</b>;
<a class="l" name="619" href="#619">619</a>					} <b>else</b> {
<a class="hl" name="620" href="#620">620</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> |= (<b>byte</b>) <span class="n">0x0D</span>;
<a class="l" name="621" href="#621">621</a>						<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a>);
<a class="l" name="622" href="#622">622</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>true</b>;
<a class="l" name="623" href="#623">623</a>					}
<a class="l" name="624" href="#624">624</a>					<b>break</b>;
<a class="l" name="625" href="#625">625</a>
<a class="l" name="626" href="#626">626</a>				<b>case</b> <span class="s">'E'</span>:
<a class="l" name="627" href="#627">627</a>					<b>if</b> (<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a>) {
<a class="l" name="628" href="#628">628</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> = (<b>byte</b>) <span class="n">0xE0</span>;
<a class="l" name="629" href="#629">629</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>false</b>;
<a class="hl" name="630" href="#630">630</a>					} <b>else</b> {
<a class="l" name="631" href="#631">631</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> |= (<b>byte</b>) <span class="n">0x0E</span>;
<a class="l" name="632" href="#632">632</a>						<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a>);
<a class="l" name="633" href="#633">633</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>true</b>;
<a class="l" name="634" href="#634">634</a>					}
<a class="l" name="635" href="#635">635</a>					<b>break</b>;
<a class="l" name="636" href="#636">636</a>
<a class="l" name="637" href="#637">637</a>				<b>case</b> <span class="s">'F'</span>:
<a class="l" name="638" href="#638">638</a>					<b>if</b> (<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a>) {
<a class="l" name="639" href="#639">639</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> = (<b>byte</b>) <span class="n">0xF0</span>;
<a class="hl" name="640" href="#640">640</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>false</b>;
<a class="l" name="641" href="#641">641</a>					} <b>else</b> {
<a class="l" name="642" href="#642">642</a>						<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a> |= (<b>byte</b>) <span class="n">0x0F</span>;
<a class="l" name="643" href="#643">643</a>						<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=sum&amp;project=rtmp_client">sum</a>);
<a class="l" name="644" href="#644">644</a>						<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a> = <b>true</b>;
<a class="l" name="645" href="#645">645</a>					}
<a class="l" name="646" href="#646">646</a>					<b>break</b>;
<a class="l" name="647" href="#647">647</a>
<a class="l" name="648" href="#648">648</a>				<b>default</b>:
<a class="l" name="649" href="#649">649</a>					<b>break</b>;
<a class="hl" name="650" href="#650">650</a>			}
<a class="l" name="651" href="#651">651</a>		}
<a class="l" name="652" href="#652">652</a>
<a class="l" name="653" href="#653">653</a>		<b>if</b> (!<a href="/source/s?defs=nextCharIsUpper&amp;project=rtmp_client">nextCharIsUpper</a>) {
<a class="l" name="654" href="#654">654</a>			<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"The String did not contain an equal number of hex digits"</span>);
<a class="l" name="655" href="#655">655</a>		}
<a class="l" name="656" href="#656">656</a>
<a class="l" name="657" href="#657">657</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=toByteArray&amp;project=rtmp_client">toByteArray</a>();
<a class="l" name="658" href="#658">658</a>	}
<a class="l" name="659" href="#659">659</a>
<a class="hl" name="660" href="#660">660</a>	<span class="c">/*
<a class="l" name="661" href="#661">661</a>	 * Converts a byte to hex digit and writes to the supplied buffer
<a class="l" name="662" href="#662">662</a>	 */</span>
<a class="l" name="663" href="#663">663</a>
<a class="l" name="664" href="#664">664</a>	<span class="c">/**
<a class="l" name="665" href="#665">665</a>	 * Description of the Method
<a class="l" name="666" href="#666">666</a>	 *
<a class="l" name="667" href="#667">667</a>	 * <strong>@param</strong> b
<a class="l" name="668" href="#668">668</a>	 *            Description of Parameter
<a class="l" name="669" href="#669">669</a>	 * <strong>@param</strong> <em>buf</em>
<a class="hl" name="670" href="#670">670</a>	 *            Description of Parameter
<a class="l" name="671" href="#671">671</a>	 */</span>
<a class="l" name="672" href="#672">672</a>	<b>private</b> <b>static</b> <b>void</b> <a class="xmt" name="byte2hex"/><a href="/source/s?refs=byte2hex&amp;project=rtmp_client" class="xmt">byte2hex</a>(<b>byte</b> b, <a href="/source/s?defs=StringBuffer&amp;project=rtmp_client">StringBuffer</a> <a class="xa" name="buf"/><a href="/source/s?refs=buf&amp;project=rtmp_client" class="xa">buf</a>) {
<a class="l" name="673" href="#673">673</a>		<b>int</b> <a href="/source/s?defs=high&amp;project=rtmp_client">high</a> = ((b &amp; <span class="n">0xf0</span>) &gt;&gt; <span class="n">4</span>);
<a class="l" name="674" href="#674">674</a>		<b>int</b> <a href="/source/s?defs=low&amp;project=rtmp_client">low</a> = (b &amp; <span class="n">0x0f</span>);
<a class="l" name="675" href="#675">675</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a class="d" href="#HEX_DIGITS">HEX_DIGITS</a>[<a href="/source/s?defs=high&amp;project=rtmp_client">high</a>]);
<a class="l" name="676" href="#676">676</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a class="d" href="#HEX_DIGITS">HEX_DIGITS</a>[<a href="/source/s?defs=low&amp;project=rtmp_client">low</a>]);
<a class="l" name="677" href="#677">677</a>	}
<a class="l" name="678" href="#678">678</a>
<a class="l" name="679" href="#679">679</a>	<span class="c">/**
<a class="hl" name="680" href="#680">680</a>	 * Description of the Method
<a class="l" name="681" href="#681">681</a>	 *
<a class="l" name="682" href="#682">682</a>	 * <strong>@param</strong> b
<a class="l" name="683" href="#683">683</a>	 *            Description of Parameter
<a class="l" name="684" href="#684">684</a>	 * <strong>@param</strong> <em>buf</em>
<a class="l" name="685" href="#685">685</a>	 *            Description of Parameter
<a class="l" name="686" href="#686">686</a>	 */</span>
<a class="l" name="687" href="#687">687</a>	<b>private</b> <b>static</b> <b>void</b> <a class="xmt" name="byte2bin"/><a href="/source/s?refs=byte2bin&amp;project=rtmp_client" class="xmt">byte2bin</a>(<b>byte</b> b, <a href="/source/s?defs=StringBuffer&amp;project=rtmp_client">StringBuffer</a> <a class="xa" name="buf"/><a href="/source/s?refs=buf&amp;project=rtmp_client" class="xa">buf</a>) {
<a class="l" name="688" href="#688">688</a>		<span class="c">// test every 8 bit</span>
<a class="l" name="689" href="#689">689</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <span class="n">8</span>; i++) {
<a class="hl" name="690" href="#690">690</a>			<span class="c">// ---test if bit is set</span>
<a class="l" name="691" href="#691">691</a>			<b>if</b> ((b &amp; <a class="d" href="#COMPARE_BITS">COMPARE_BITS</a>[i]) != <span class="n">0</span>) {
<a class="l" name="692" href="#692">692</a>				<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a class="d" href="#BIT_DIGIT">BIT_DIGIT</a>[<span class="n">1</span>]);
<a class="l" name="693" href="#693">693</a>			} <b>else</b> {
<a class="l" name="694" href="#694">694</a>				<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a class="d" href="#BIT_DIGIT">BIT_DIGIT</a>[<span class="n">0</span>]);
<a class="l" name="695" href="#695">695</a>			}
<a class="l" name="696" href="#696">696</a>		}
<a class="l" name="697" href="#697">697</a>	}
<a class="l" name="698" href="#698">698</a>
<a class="l" name="699" href="#699">699</a>	<span class="c">/**
<a class="hl" name="700" href="#700">700</a>	 * Returns a string of 8 hexadecimal digits (most significant digit first)
<a class="l" name="701" href="#701">701</a>	 * corresponding to the integer &lt;i&gt;n&lt;/i&gt; , which is treated as unsigned.
<a class="l" name="702" href="#702">702</a>	 *
<a class="l" name="703" href="#703">703</a>	 * <strong>@param</strong> n
<a class="l" name="704" href="#704">704</a>	 *            Description of Parameter
<a class="l" name="705" href="#705">705</a>	 * <strong>@return</strong> Description of the Returned Value
<a class="l" name="706" href="#706">706</a>	 */</span>
<a class="l" name="707" href="#707">707</a>	<b>private</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="intToHexString"/><a href="/source/s?refs=intToHexString&amp;project=rtmp_client" class="xmt">intToHexString</a>(<b>int</b> n) {
<a class="l" name="708" href="#708">708</a>		<b>char</b>[] <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> = <b>new</b> <b>char</b>[<span class="n">8</span>];
<a class="l" name="709" href="#709">709</a>		<b>for</b> (<b>int</b> i = <span class="n">7</span>; i &gt;= <span class="n">0</span>; i--) {
<a class="hl" name="710" href="#710">710</a>			<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>[i] = <a class="d" href="#HEX_DIGITS">HEX_DIGITS</a>[n &amp; <span class="n">0x0F</span>];
<a class="l" name="711" href="#711">711</a>			n &gt;&gt;&gt;= <span class="n">4</span>;
<a class="l" name="712" href="#712">712</a>		}
<a class="l" name="713" href="#713">713</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="714" href="#714">714</a>	}
<a class="l" name="715" href="#715">715</a>
<a class="l" name="716" href="#716">716</a>	<span class="c">/**
<a class="l" name="717" href="#717">717</a>	 * test and demo for the Convert class
<a class="l" name="718" href="#718">718</a>	 *
<a class="l" name="719" href="#719">719</a>	 * <strong>@param</strong> <em>args</em> none needed
<a class="hl" name="720" href="#720">720</a>	 */</span>
<a class="l" name="721" href="#721">721</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="main"/><a href="/source/s?refs=main&amp;project=rtmp_client" class="xmt">main</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="args"/><a href="/source/s?refs=args&amp;project=rtmp_client" class="xa">args</a>[]) {
<a class="l" name="722" href="#722">722</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"-test and demo of the converter "</span>);
<a class="l" name="723" href="#723">723</a>
<a class="l" name="724" href="#724">724</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=str&amp;project=rtmp_client">str</a> = <span class="s">"Niko"</span>;
<a class="l" name="725" href="#725">725</a>		<b>byte</b>[] <a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a> = <a href="/source/s?defs=str&amp;project=rtmp_client">str</a>.<a href="/source/s?defs=getBytes&amp;project=rtmp_client">getBytes</a>();
<a class="l" name="726" href="#726">726</a>
<a class="l" name="727" href="#727">727</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"to convert: "</span> + <a href="/source/s?defs=str&amp;project=rtmp_client">str</a>);
<a class="l" name="728" href="#728">728</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"converted1: "</span> + <a href="/source/s?defs=byteArrayToHexString&amp;project=rtmp_client">byteArrayToHexString</a>(<a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a>));
<a class="l" name="729" href="#729">729</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"converted1: "</span> + <a href="/source/s?defs=byteArrayToHexString&amp;project=rtmp_client">byteArrayToHexString</a>(<a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a>, <span class="n">0</span>, <a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>));
<a class="hl" name="730" href="#730">730</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"converted3: "</span> + <a class="d" href="#stringToHexString">stringToHexString</a>(<a href="/source/s?defs=str&amp;project=rtmp_client">str</a>));
<a class="l" name="731" href="#731">731</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"----Convert integer to hexString..."</span>);
<a class="l" name="732" href="#732">732</a>
<a class="l" name="733" href="#733">733</a>		<b>int</b> i = -<span class="n">2</span>;
<a class="l" name="734" href="#734">734</a>
<a class="l" name="735" href="#735">735</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"to convert: "</span> + i + <span class="s">" -&gt; "</span> + <a class="d" href="#intToHexString">intToHexString</a>(i));
<a class="l" name="736" href="#736">736</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"----Convert byte[] to binary String..."</span>);
<a class="l" name="737" href="#737">737</a>
<a class="l" name="738" href="#738">738</a>		<b>byte</b>[] <a class="d" href="#baToConvert">baToConvert</a> = { (<b>byte</b>) <span class="n">0xff</span>, (<b>byte</b>) <span class="n">0x00</span>, (<b>byte</b>) <span class="n">0x33</span>, (<b>byte</b>) <span class="n">0x11</span>, (<b>byte</b>) <span class="n">0xff</span>, (<b>byte</b>) <span class="n">0x5f</span>, (<b>byte</b>) <span class="n">0x5f</span>, (<b>byte</b>) <span class="n">0x4f</span>, (<b>byte</b>) <span class="n">0x1f</span>, (<b>byte</b>) <span class="n">0xff</span> };
<a class="l" name="739" href="#739">739</a>
<a class="hl" name="740" href="#740">740</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"to convert: "</span> + <a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>(<a class="d" href="#baToConvert">baToConvert</a>) + <span class="s">" -&gt; "</span> + <a class="d" href="#byteArrayToBinaryString">byteArrayToBinaryString</a>(<a class="d" href="#baToConvert">baToConvert</a>));
<a class="l" name="741" href="#741">741</a>
<a class="l" name="742" href="#742">742</a>		<span class="c">// ---- modify line separator</span>
<a class="l" name="743" href="#743">743</a>		<a class="d" href="#setByteSeparator">setByteSeparator</a>(<span class="s">'-'</span>);
<a class="l" name="744" href="#744">744</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"to convert: "</span> + <a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>(<a class="d" href="#baToConvert">baToConvert</a>) + <span class="s">" -&gt; "</span> + <a class="d" href="#byteArrayToBinaryString">byteArrayToBinaryString</a>(<a class="d" href="#baToConvert">baToConvert</a>));
<a class="l" name="745" href="#745">745</a>
<a class="l" name="746" href="#746">746</a>		<span class="c">// ---- modify line separator</span>
<a class="l" name="747" href="#747">747</a>		<a class="d" href="#setByteSeparator">setByteSeparator</a>(<span class="s">'*'</span>);
<a class="l" name="748" href="#748">748</a>		<a class="d" href="#setWithByteSeparator">setWithByteSeparator</a>(<b>true</b>);
<a class="l" name="749" href="#749">749</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"to convert: "</span> + <a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>(<a class="d" href="#baToConvert">baToConvert</a>) + <span class="s">" -&gt; "</span> + <a class="d" href="#byteArrayToBinaryString">byteArrayToBinaryString</a>(<a class="d" href="#baToConvert">baToConvert</a>));
<a class="hl" name="750" href="#750">750</a>
<a class="l" name="751" href="#751">751</a>		<span class="c">// ---- modify bit digits</span>
<a class="l" name="752" href="#752">752</a>		<b>char</b>[] <a class="d" href="#bd">bd</a> = { <span class="s">'a'</span>, <span class="s">'b'</span> };
<a class="l" name="753" href="#753">753</a>
<a class="l" name="754" href="#754">754</a>		<b>try</b> {
<a class="l" name="755" href="#755">755</a>			<a href="/source/s?defs=setBitDigits&amp;project=rtmp_client">setBitDigits</a>(<a class="d" href="#bd">bd</a>);
<a class="l" name="756" href="#756">756</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> <a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>) {
<a class="l" name="757" href="#757">757</a>			<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">""</span>, <a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>);
<a class="l" name="758" href="#758">758</a>			<span class="c">// ex.printStackTrace();</span>
<a class="l" name="759" href="#759">759</a>		}
<a class="hl" name="760" href="#760">760</a>
<a class="l" name="761" href="#761">761</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"to convert: "</span> + <a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>(<a class="d" href="#baToConvert">baToConvert</a>) + <span class="s">" -&gt; "</span> + <a class="d" href="#byteArrayToBinaryString">byteArrayToBinaryString</a>(<a class="d" href="#baToConvert">baToConvert</a>));
<a class="l" name="762" href="#762">762</a>
<a class="l" name="763" href="#763">763</a>		<span class="c">// ------------------------------------------------//</span>
<a class="l" name="764" href="#764">764</a>		<a href="/source/s?defs=setBitDigits&amp;project=rtmp_client">setBitDigits</a>(<span class="s">'0'</span>, <span class="s">'1'</span>);
<a class="l" name="765" href="#765">765</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"---- Convert.toByteArray(int) "</span>);
<a class="l" name="766" href="#766">766</a>
<a class="l" name="767" href="#767">767</a>		<b>for</b> (<b>int</b> <a href="/source/s?defs=iToConvert&amp;project=rtmp_client">iToConvert</a> = -<span class="n">10</span>; <a href="/source/s?defs=iToConvert&amp;project=rtmp_client">iToConvert</a> &lt; <span class="n">10</span>; <a href="/source/s?defs=iToConvert&amp;project=rtmp_client">iToConvert</a>++) {
<a class="l" name="768" href="#768">768</a>			<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"to convert = "</span> + <a href="/source/s?defs=iToConvert&amp;project=rtmp_client">iToConvert</a> + <span class="s">" = "</span> + <a class="d" href="#HexDump">HexDump</a>.<a href="/source/s?defs=toBinaryString&amp;project=rtmp_client">toBinaryString</a>(<a href="/source/s?defs=iToConvert&amp;project=rtmp_client">iToConvert</a>));
<a class="l" name="769" href="#769">769</a>
<a class="hl" name="770" href="#770">770</a>			<b>byte</b>[] <a href="/source/s?defs=baConvInt&amp;project=rtmp_client">baConvInt</a> = <b>new</b> <b>byte</b>[<span class="n">4</span>];
<a class="l" name="771" href="#771">771</a>
<a class="l" name="772" href="#772">772</a>			<a href="/source/s?defs=baConvInt&amp;project=rtmp_client">baConvInt</a> = <a class="d" href="#HexDump">HexDump</a>.<a href="/source/s?defs=toByteArray&amp;project=rtmp_client">toByteArray</a>(<a href="/source/s?defs=iToConvert&amp;project=rtmp_client">iToConvert</a>);
<a class="l" name="773" href="#773">773</a>
<a class="l" name="774" href="#774">774</a>			<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"convertet byteArray = "</span> + <a class="d" href="#HexDump">HexDump</a>.<a href="/source/s?defs=toBinaryString&amp;project=rtmp_client">toBinaryString</a>(<a href="/source/s?defs=baConvInt&amp;project=rtmp_client">baConvInt</a>));
<a class="l" name="775" href="#775">775</a>		}
<a class="l" name="776" href="#776">776</a>
<a class="l" name="777" href="#777">777</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"---- toHexString(int) "</span>);
<a class="l" name="778" href="#778">778</a>
<a class="l" name="779" href="#779">779</a>		i = -<span class="n">1</span>;
<a class="hl" name="780" href="#780">780</a>
<a class="l" name="781" href="#781">781</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(i + <span class="s">" = 0x"</span> + <a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>(i) + <span class="s">" = "</span> + <a href="/source/s?defs=toBinaryString&amp;project=rtmp_client">toBinaryString</a>(i));
<a class="l" name="782" href="#782">782</a>
<a class="l" name="783" href="#783">783</a>		i++;
<a class="l" name="784" href="#784">784</a>
<a class="l" name="785" href="#785">785</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(i + <span class="s">" = 0x"</span> + <a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>(i) + <span class="s">" = "</span> + <a href="/source/s?defs=toBinaryString&amp;project=rtmp_client">toBinaryString</a>(i));
<a class="l" name="786" href="#786">786</a>
<a class="l" name="787" href="#787">787</a>		<span class="c">// ------------------------------------------------//</span>
<a class="l" name="788" href="#788">788</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"---- toHexString(long) "</span>);
<a class="l" name="789" href="#789">789</a>
<a class="hl" name="790" href="#790">790</a>		<b>long</b> l = <span class="n">100</span>;
<a class="l" name="791" href="#791">791</a>
<a class="l" name="792" href="#792">792</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(l + <span class="s">" = 0x"</span> + <a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>(l) + <span class="s">" = "</span> + <a href="/source/s?defs=toBinaryString&amp;project=rtmp_client">toBinaryString</a>(l));
<a class="l" name="793" href="#793">793</a>
<a class="l" name="794" href="#794">794</a>		<a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Random&amp;project=rtmp_client">Random</a> <a href="/source/s?defs=rnd&amp;project=rtmp_client">rnd</a> = <b>new</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Random&amp;project=rtmp_client">Random</a>();
<a class="l" name="795" href="#795">795</a>
<a class="l" name="796" href="#796">796</a>		l = <a href="/source/s?defs=rnd&amp;project=rtmp_client">rnd</a>.<a href="/source/s?defs=nextLong&amp;project=rtmp_client">nextLong</a>();
<a class="l" name="797" href="#797">797</a>
<a class="l" name="798" href="#798">798</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(l + <span class="s">" = 0x"</span> + <a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>(l) + <span class="s">" = "</span> + <a href="/source/s?defs=toBinaryString&amp;project=rtmp_client">toBinaryString</a>(l));
<a class="l" name="799" href="#799">799</a>
<a class="hl" name="800" href="#800">800</a>		<span class="c">// ------------------------------------------------//</span>
<a class="l" name="801" href="#801">801</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"---- toHexString(short) "</span>);
<a class="l" name="802" href="#802">802</a>
<a class="l" name="803" href="#803">803</a>		<b>short</b> s = <span class="n">100</span>;
<a class="l" name="804" href="#804">804</a>
<a class="l" name="805" href="#805">805</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(s + <span class="s">" = 0x"</span> + <a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>(s) + <span class="s">" = "</span> + <a href="/source/s?defs=toBinaryString&amp;project=rtmp_client">toBinaryString</a>(s));
<a class="l" name="806" href="#806">806</a>
<a class="l" name="807" href="#807">807</a>		<a href="/source/s?defs=rnd&amp;project=rtmp_client">rnd</a> = <b>new</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Random&amp;project=rtmp_client">Random</a>();
<a class="l" name="808" href="#808">808</a>		s = (<b>short</b>) <a href="/source/s?defs=rnd&amp;project=rtmp_client">rnd</a>.<a href="/source/s?defs=nextInt&amp;project=rtmp_client">nextInt</a>();
<a class="l" name="809" href="#809">809</a>
<a class="hl" name="810" href="#810">810</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(s + <span class="s">" = 0x"</span> + <a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>(s) + <span class="s">" = "</span> + <a href="/source/s?defs=toBinaryString&amp;project=rtmp_client">toBinaryString</a>(s));
<a class="l" name="811" href="#811">811</a>
<a class="l" name="812" href="#812">812</a>		<span class="c">// ---------------------------------------------------------------------------//</span>
<a class="l" name="813" href="#813">813</a>		<span class="c">// convert dezimal-String to binary</span>
<a class="l" name="814" href="#814">814</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"---- read file in Hex-Format "</span>);
<a class="l" name="815" href="#815">815</a>
<a class="l" name="816" href="#816">816</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=strToConvert&amp;project=rtmp_client">strToConvert</a> = <span class="s">"12345654321"</span>;
<a class="l" name="817" href="#817">817</a>
<a class="l" name="818" href="#818">818</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<a href="/source/s?defs=strToConvert&amp;project=rtmp_client">strToConvert</a> + <span class="s">" = "</span> + <a class="d" href="#stringToHexString">stringToHexString</a>(<a href="/source/s?defs=strToConvert&amp;project=rtmp_client">strToConvert</a>));
<a class="l" name="819" href="#819">819</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"Das ist die Hex-Darstellung des obigen Strings"</span>);
<a class="hl" name="820" href="#820">820</a>
<a class="l" name="821" href="#821">821</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"ba = "</span> + <a href="/source/s?defs=toHexString&amp;project=rtmp_client">toHexString</a>(<a href="/source/s?defs=ba&amp;project=rtmp_client">ba</a>));
<a class="l" name="822" href="#822">822</a>	}
<a class="l" name="823" href="#823">823</a>
<a class="l" name="824" href="#824">824</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="formatHexDump"/><a href="/source/s?refs=formatHexDump&amp;project=rtmp_client" class="xmt">formatHexDump</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="825" href="#825">825</a>		<b>int</b> <a href="/source/s?defs=chunk&amp;project=rtmp_client">chunk</a> = <span class="n">60</span>;
<a class="l" name="826" href="#826">826</a>		<a href="/source/s?defs=StringBuilder&amp;project=rtmp_client">StringBuilder</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <b>new</b> <a href="/source/s?defs=StringBuilder&amp;project=rtmp_client">StringBuilder</a>();
<a class="l" name="827" href="#827">827</a>		<b>int</b> <a href="/source/s?defs=from&amp;project=rtmp_client">from</a> = <span class="n">0</span>;
<a class="l" name="828" href="#828">828</a>		<b>int</b> <a href="/source/s?defs=to&amp;project=rtmp_client">to</a> = <span class="n">0</span>;
<a class="l" name="829" href="#829">829</a>		<b>int</b> <a href="/source/s?defs=size&amp;project=rtmp_client">size</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>();
<a class="hl" name="830" href="#830">830</a>		<b>while</b> (<a href="/source/s?defs=from&amp;project=rtmp_client">from</a> &lt; <a href="/source/s?defs=size&amp;project=rtmp_client">size</a>) {
<a class="l" name="831" href="#831">831</a>			<b>if</b> (<a href="/source/s?defs=size&amp;project=rtmp_client">size</a> &lt; <a href="/source/s?defs=from&amp;project=rtmp_client">from</a> + <a href="/source/s?defs=chunk&amp;project=rtmp_client">chunk</a>) {
<a class="l" name="832" href="#832">832</a>				<a href="/source/s?defs=to&amp;project=rtmp_client">to</a> = <a href="/source/s?defs=size&amp;project=rtmp_client">size</a>;
<a class="l" name="833" href="#833">833</a>			} <b>else</b> {
<a class="l" name="834" href="#834">834</a>				<a href="/source/s?defs=to&amp;project=rtmp_client">to</a> = <a href="/source/s?defs=from&amp;project=rtmp_client">from</a> + <a href="/source/s?defs=chunk&amp;project=rtmp_client">chunk</a>;
<a class="l" name="835" href="#835">835</a>			}
<a class="l" name="836" href="#836">836</a>			<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=substring&amp;project=rtmp_client">substring</a>(<a href="/source/s?defs=from&amp;project=rtmp_client">from</a>, <a href="/source/s?defs=to&amp;project=rtmp_client">to</a>));
<a class="l" name="837" href="#837">837</a>			<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">'\n'</span>);
<a class="l" name="838" href="#838">838</a>			<a href="/source/s?defs=from&amp;project=rtmp_client">from</a> = <a href="/source/s?defs=to&amp;project=rtmp_client">to</a>;
<a class="l" name="839" href="#839">839</a>		}
<a class="hl" name="840" href="#840">840</a>		<b>return</b> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>();
<a class="l" name="841" href="#841">841</a>	}
<a class="l" name="842" href="#842">842</a>
<a class="l" name="843" href="#843">843</a>}
<a class="l" name="844" href="#844">844</a>