<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["FileUtil",47]]],["Package","xp",[["org.red5.io.utils",1]]],["Method","xmt",[["copy",398],["copyFile",51],["copyFile",91],["deleteDirectory",121],["deleteDirectory",135],["formatPath",472],["generateCustomName",520],["makeDirectory",283],["makeDirectory",297],["moveFile",95],["rename",205],["stdOut",246],["unzip",328]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a>
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=BufferedInputStream&amp;project=rtmp_client">BufferedInputStream</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=File&amp;project=rtmp_client">File</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=FileInputStream&amp;project=rtmp_client">FileInputStream</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=FileOutputStream&amp;project=rtmp_client">FileOutputStream</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=InputStream&amp;project=rtmp_client">InputStream</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=OutputStream&amp;project=rtmp_client">OutputStream</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=MappedByteBuffer&amp;project=rtmp_client">MappedByteBuffer</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=channels&amp;project=rtmp_client">channels</a>.<a href="/source/s?defs=FileChannel&amp;project=rtmp_client">FileChannel</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Enumeration&amp;project=rtmp_client">Enumeration</a>;
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Random&amp;project=rtmp_client">Random</a>;
<a class="l" name="34" href="#34">34</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=zip&amp;project=rtmp_client">zip</a>.<a href="/source/s?defs=ZipEntry&amp;project=rtmp_client">ZipEntry</a>;
<a class="l" name="35" href="#35">35</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=zip&amp;project=rtmp_client">zip</a>.<a href="/source/s?defs=ZipFile&amp;project=rtmp_client">ZipFile</a>;
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="38" href="#38">38</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="39" href="#39">39</a>
<a class="hl" name="40" href="#40">40</a><span class="c">/**
<a class="l" name="41" href="#41">41</a> * Generic file utility containing useful file or directory
<a class="l" name="42" href="#42">42</a> * manipulation functions.
<a class="l" name="43" href="#43">43</a> *
<a class="l" name="44" href="#44">44</a> * <strong>@author</strong> Paul Gregoire (mondain@gmail.com)
<a class="l" name="45" href="#45">45</a> * <strong>@author</strong> Dominick Accattato (daccattato@gmail.com)
<a class="l" name="46" href="#46">46</a> */</span>
<a class="l" name="47" href="#47">47</a><b>public</b> <b>class</b> <a class="xc" name="FileUtil"/><a href="/source/s?refs=FileUtil&amp;project=rtmp_client" class="xc">FileUtil</a> {
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>	<b>private</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a class="d" href="#FileUtil">FileUtil</a>.<b>class</b>);
<a class="hl" name="50" href="#50">50</a>
<a class="l" name="51" href="#51">51</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="copyFile"/><a href="/source/s?refs=copyFile&amp;project=rtmp_client" class="xmt">copyFile</a>(<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a class="xa" name="dest"/><a href="/source/s?refs=dest&amp;project=rtmp_client" class="xa">dest</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="52" href="#52">52</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Copy from {} to {}"</span>, <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>.<a href="/source/s?defs=getAbsoluteFile&amp;project=rtmp_client">getAbsoluteFile</a>(), <a href="/source/s?defs=dest&amp;project=rtmp_client">dest</a>
<a class="l" name="53" href="#53">53</a>				.<a href="/source/s?defs=getAbsoluteFile&amp;project=rtmp_client">getAbsoluteFile</a>());
<a class="l" name="54" href="#54">54</a>		<a href="/source/s?defs=FileInputStream&amp;project=rtmp_client">FileInputStream</a> <a href="/source/s?defs=fi&amp;project=rtmp_client">fi</a> = <b>new</b> <a href="/source/s?defs=FileInputStream&amp;project=rtmp_client">FileInputStream</a>(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>);
<a class="l" name="55" href="#55">55</a>		<a href="/source/s?defs=FileChannel&amp;project=rtmp_client">FileChannel</a> <a href="/source/s?defs=fic&amp;project=rtmp_client">fic</a> = <a href="/source/s?defs=fi&amp;project=rtmp_client">fi</a>.<a href="/source/s?defs=getChannel&amp;project=rtmp_client">getChannel</a>();
<a class="l" name="56" href="#56">56</a>		<a href="/source/s?defs=MappedByteBuffer&amp;project=rtmp_client">MappedByteBuffer</a> <a href="/source/s?defs=mbuf&amp;project=rtmp_client">mbuf</a> = <a href="/source/s?defs=fic&amp;project=rtmp_client">fic</a>.<a href="/source/s?defs=map&amp;project=rtmp_client">map</a>(<a href="/source/s?defs=FileChannel&amp;project=rtmp_client">FileChannel</a>.<a href="/source/s?defs=MapMode&amp;project=rtmp_client">MapMode</a>.<a href="/source/s?defs=READ_ONLY&amp;project=rtmp_client">READ_ONLY</a>, <span class="n">0</span>,
<a class="l" name="57" href="#57">57</a>				<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>());
<a class="l" name="58" href="#58">58</a>		<a href="/source/s?defs=fic&amp;project=rtmp_client">fic</a>.<a href="/source/s?defs=close&amp;project=rtmp_client">close</a>();
<a class="l" name="59" href="#59">59</a>		<a href="/source/s?defs=fi&amp;project=rtmp_client">fi</a>.<a href="/source/s?defs=close&amp;project=rtmp_client">close</a>();
<a class="hl" name="60" href="#60">60</a>		<a href="/source/s?defs=fi&amp;project=rtmp_client">fi</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="61" href="#61">61</a>
<a class="l" name="62" href="#62">62</a>		<span class="c">// ensure the destination directory exists</span>
<a class="l" name="63" href="#63">63</a>		<b>if</b> (!<a href="/source/s?defs=dest&amp;project=rtmp_client">dest</a>.<a href="/source/s?defs=exists&amp;project=rtmp_client">exists</a>()) {
<a class="l" name="64" href="#64">64</a>			<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=destPath&amp;project=rtmp_client">destPath</a> = <a href="/source/s?defs=dest&amp;project=rtmp_client">dest</a>.<a href="/source/s?defs=getPath&amp;project=rtmp_client">getPath</a>();
<a class="l" name="65" href="#65">65</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Destination path: {}"</span>, <a href="/source/s?defs=destPath&amp;project=rtmp_client">destPath</a>);
<a class="l" name="66" href="#66">66</a>			<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=destDir&amp;project=rtmp_client">destDir</a> = <a href="/source/s?defs=destPath&amp;project=rtmp_client">destPath</a>.<a href="/source/s?defs=substring&amp;project=rtmp_client">substring</a>(<span class="n">0</span>, <a href="/source/s?defs=destPath&amp;project=rtmp_client">destPath</a>
<a class="l" name="67" href="#67">67</a>					.<a href="/source/s?defs=lastIndexOf&amp;project=rtmp_client">lastIndexOf</a>(<a href="/source/s?defs=File&amp;project=rtmp_client">File</a>.<a href="/source/s?defs=separatorChar&amp;project=rtmp_client">separatorChar</a>));
<a class="l" name="68" href="#68">68</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Destination dir: {}"</span>, <a href="/source/s?defs=destDir&amp;project=rtmp_client">destDir</a>);
<a class="l" name="69" href="#69">69</a>			<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a> = <b>new</b> <a href="/source/s?defs=File&amp;project=rtmp_client">File</a>(<a href="/source/s?defs=destDir&amp;project=rtmp_client">destDir</a>);
<a class="hl" name="70" href="#70">70</a>			<b>if</b> (!<a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a>.<a href="/source/s?defs=exists&amp;project=rtmp_client">exists</a>()) {
<a class="l" name="71" href="#71">71</a>				<b>if</b> (<a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a>.<a href="/source/s?defs=mkdirs&amp;project=rtmp_client">mkdirs</a>()) {
<a class="l" name="72" href="#72">72</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Directory created"</span>);
<a class="l" name="73" href="#73">73</a>				} <b>else</b> {
<a class="l" name="74" href="#74">74</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Directory not created"</span>);
<a class="l" name="75" href="#75">75</a>				}
<a class="l" name="76" href="#76">76</a>			}
<a class="l" name="77" href="#77">77</a>			<a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="78" href="#78">78</a>		}
<a class="l" name="79" href="#79">79</a>
<a class="hl" name="80" href="#80">80</a>		<a href="/source/s?defs=FileOutputStream&amp;project=rtmp_client">FileOutputStream</a> <a href="/source/s?defs=fo&amp;project=rtmp_client">fo</a> = <b>new</b> <a href="/source/s?defs=FileOutputStream&amp;project=rtmp_client">FileOutputStream</a>(<a href="/source/s?defs=dest&amp;project=rtmp_client">dest</a>);
<a class="l" name="81" href="#81">81</a>		<a href="/source/s?defs=FileChannel&amp;project=rtmp_client">FileChannel</a> <a href="/source/s?defs=foc&amp;project=rtmp_client">foc</a> = <a href="/source/s?defs=fo&amp;project=rtmp_client">fo</a>.<a href="/source/s?defs=getChannel&amp;project=rtmp_client">getChannel</a>();
<a class="l" name="82" href="#82">82</a>		<a href="/source/s?defs=foc&amp;project=rtmp_client">foc</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=mbuf&amp;project=rtmp_client">mbuf</a>);
<a class="l" name="83" href="#83">83</a>		<a href="/source/s?defs=foc&amp;project=rtmp_client">foc</a>.<a href="/source/s?defs=close&amp;project=rtmp_client">close</a>();
<a class="l" name="84" href="#84">84</a>		<a href="/source/s?defs=fo&amp;project=rtmp_client">fo</a>.<a href="/source/s?defs=close&amp;project=rtmp_client">close</a>();
<a class="l" name="85" href="#85">85</a>		<a href="/source/s?defs=fo&amp;project=rtmp_client">fo</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="86" href="#86">86</a>
<a class="l" name="87" href="#87">87</a>		<a href="/source/s?defs=mbuf&amp;project=rtmp_client">mbuf</a>.<a href="/source/s?defs=clear&amp;project=rtmp_client">clear</a>();
<a class="l" name="88" href="#88">88</a>		<a href="/source/s?defs=mbuf&amp;project=rtmp_client">mbuf</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="89" href="#89">89</a>	}
<a class="hl" name="90" href="#90">90</a>
<a class="l" name="91" href="#91">91</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="copyFile"/><a href="/source/s?refs=copyFile&amp;project=rtmp_client" class="xmt">copyFile</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="dest"/><a href="/source/s?refs=dest&amp;project=rtmp_client" class="xa">dest</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="92" href="#92">92</a>		<a href="/source/s?defs=copyFile&amp;project=rtmp_client">copyFile</a>(<b>new</b> <a href="/source/s?defs=File&amp;project=rtmp_client">File</a>(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>), <b>new</b> <a href="/source/s?defs=File&amp;project=rtmp_client">File</a>(<a href="/source/s?defs=dest&amp;project=rtmp_client">dest</a>));
<a class="l" name="93" href="#93">93</a>	}
<a class="l" name="94" href="#94">94</a>
<a class="l" name="95" href="#95">95</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="moveFile"/><a href="/source/s?refs=moveFile&amp;project=rtmp_client" class="xmt">moveFile</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="dest"/><a href="/source/s?refs=dest&amp;project=rtmp_client" class="xa">dest</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="96" href="#96">96</a>		<a href="/source/s?defs=copyFile&amp;project=rtmp_client">copyFile</a>(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>, <a href="/source/s?defs=dest&amp;project=rtmp_client">dest</a>);
<a class="l" name="97" href="#97">97</a>		<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a href="/source/s?defs=src&amp;project=rtmp_client">src</a> = <b>new</b> <a href="/source/s?defs=File&amp;project=rtmp_client">File</a>(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>);
<a class="l" name="98" href="#98">98</a>		<b>if</b> (<a href="/source/s?defs=src&amp;project=rtmp_client">src</a>.<a href="/source/s?defs=exists&amp;project=rtmp_client">exists</a>() &amp;&amp; <a href="/source/s?defs=src&amp;project=rtmp_client">src</a>.<a href="/source/s?defs=canRead&amp;project=rtmp_client">canRead</a>()) {
<a class="l" name="99" href="#99">99</a>			<b>if</b> (<a href="/source/s?defs=src&amp;project=rtmp_client">src</a>.<a href="/source/s?defs=delete&amp;project=rtmp_client">delete</a>()) {
<a class="hl" name="100" href="#100">100</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Source file was deleted"</span>);
<a class="l" name="101" href="#101">101</a>			} <b>else</b> {
<a class="l" name="102" href="#102">102</a>				<a class="d" href="#log">log</a>
<a class="l" name="103" href="#103">103</a>						.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Source file was not deleted, the file will be deleted on exit"</span>);
<a class="l" name="104" href="#104">104</a>				<a href="/source/s?defs=src&amp;project=rtmp_client">src</a>.<a href="/source/s?defs=deleteOnExit&amp;project=rtmp_client">deleteOnExit</a>();
<a class="l" name="105" href="#105">105</a>			}
<a class="l" name="106" href="#106">106</a>		} <b>else</b> {
<a class="l" name="107" href="#107">107</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Source file could not be accessed for removal"</span>);
<a class="l" name="108" href="#108">108</a>		}
<a class="l" name="109" href="#109">109</a>		<a href="/source/s?defs=src&amp;project=rtmp_client">src</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="hl" name="110" href="#110">110</a>	}
<a class="l" name="111" href="#111">111</a>
<a class="l" name="112" href="#112">112</a>	<span class="c">/**
<a class="l" name="113" href="#113">113</a>	 * Deletes a directory and its contents. This will fail if there are any
<a class="l" name="114" href="#114">114</a>	 * file locks or if the directory cannot be emptied.
<a class="l" name="115" href="#115">115</a>	 *
<a class="l" name="116" href="#116">116</a>	 * <strong>@param</strong> <em>directory</em> directory to delete
<a class="l" name="117" href="#117">117</a>	 * <strong>@throws</strong> <em>IOException</em> if directory cannot be deleted
<a class="l" name="118" href="#118">118</a>	 * <strong>@return</strong> true if directory was successfully deleted; false if directory
<a class="l" name="119" href="#119">119</a>	 *  did not exist
<a class="hl" name="120" href="#120">120</a>	 */</span>
<a class="l" name="121" href="#121">121</a>	<b>public</b> <b>static</b> <b>boolean</b> <a class="xmt" name="deleteDirectory"/><a href="/source/s?refs=deleteDirectory&amp;project=rtmp_client" class="xmt">deleteDirectory</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="directory"/><a href="/source/s?refs=directory&amp;project=rtmp_client" class="xa">directory</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="122" href="#122">122</a>		<b>return</b> <a href="/source/s?defs=deleteDirectory&amp;project=rtmp_client">deleteDirectory</a>(<a href="/source/s?defs=directory&amp;project=rtmp_client">directory</a>, <b>false</b>);
<a class="l" name="123" href="#123">123</a>	}
<a class="l" name="124" href="#124">124</a>
<a class="l" name="125" href="#125">125</a>	<span class="c">/**
<a class="l" name="126" href="#126">126</a>	 * Deletes a directory and its contents. This will fail if there are any
<a class="l" name="127" href="#127">127</a>	 * file locks or if the directory cannot be emptied.
<a class="l" name="128" href="#128">128</a>	 *
<a class="l" name="129" href="#129">129</a>	 * <strong>@param</strong> <em>directory</em> directory to delete
<a class="hl" name="130" href="#130">130</a>	 * <strong>@param</strong> <em>useOSNativeDelete</em> flag to signify use of operating system delete function
<a class="l" name="131" href="#131">131</a>	 * <strong>@throws</strong> <em>IOException</em> if directory cannot be deleted
<a class="l" name="132" href="#132">132</a>	 * <strong>@return</strong> true if directory was successfully deleted; false if directory
<a class="l" name="133" href="#133">133</a>	 *  did not exist
<a class="l" name="134" href="#134">134</a>	 */</span>
<a class="l" name="135" href="#135">135</a>	<b>public</b> <b>static</b> <b>boolean</b> <a class="xmt" name="deleteDirectory"/><a href="/source/s?refs=deleteDirectory&amp;project=rtmp_client" class="xmt">deleteDirectory</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="directory"/><a href="/source/s?refs=directory&amp;project=rtmp_client" class="xa">directory</a>,
<a class="l" name="136" href="#136">136</a>			<b>boolean</b> <a class="d" href="#useOSNativeDelete">useOSNativeDelete</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="137" href="#137">137</a>		<b>boolean</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>false</b>;
<a class="l" name="138" href="#138">138</a>		<b>if</b> (!<a class="d" href="#useOSNativeDelete">useOSNativeDelete</a>) {
<a class="l" name="139" href="#139">139</a>			<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a> = <b>new</b> <a href="/source/s?defs=File&amp;project=rtmp_client">File</a>(<a href="/source/s?defs=directory&amp;project=rtmp_client">directory</a>);
<a class="hl" name="140" href="#140">140</a>			<span class="c">// first all files have to be cleared out</span>
<a class="l" name="141" href="#141">141</a>			<b>for</b> (<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a href="/source/s?defs=file&amp;project=rtmp_client">file</a> : <a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a>.<a href="/source/s?defs=listFiles&amp;project=rtmp_client">listFiles</a>()) {
<a class="l" name="142" href="#142">142</a>				<b>if</b> (<a href="/source/s?defs=file&amp;project=rtmp_client">file</a>.<a href="/source/s?defs=delete&amp;project=rtmp_client">delete</a>()) {
<a class="l" name="143" href="#143">143</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"{} was deleted"</span>, <a href="/source/s?defs=file&amp;project=rtmp_client">file</a>.<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>());
<a class="l" name="144" href="#144">144</a>				} <b>else</b> {
<a class="l" name="145" href="#145">145</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"{} was not deleted"</span>, <a href="/source/s?defs=file&amp;project=rtmp_client">file</a>.<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>());
<a class="l" name="146" href="#146">146</a>					<a href="/source/s?defs=file&amp;project=rtmp_client">file</a>.<a href="/source/s?defs=deleteOnExit&amp;project=rtmp_client">deleteOnExit</a>();
<a class="l" name="147" href="#147">147</a>				}
<a class="l" name="148" href="#148">148</a>				<a href="/source/s?defs=file&amp;project=rtmp_client">file</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="149" href="#149">149</a>			}
<a class="hl" name="150" href="#150">150</a>			<span class="c">// not you may remove the dir</span>
<a class="l" name="151" href="#151">151</a>			<b>if</b> (<a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a>.<a href="/source/s?defs=delete&amp;project=rtmp_client">delete</a>()) {
<a class="l" name="152" href="#152">152</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Directory was deleted"</span>);
<a class="l" name="153" href="#153">153</a>				<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>true</b>;
<a class="l" name="154" href="#154">154</a>			} <b>else</b> {
<a class="l" name="155" href="#155">155</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Directory was not deleted, it may be deleted on exit"</span>);
<a class="l" name="156" href="#156">156</a>				<a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a>.<a href="/source/s?defs=deleteOnExit&amp;project=rtmp_client">deleteOnExit</a>();
<a class="l" name="157" href="#157">157</a>			}
<a class="l" name="158" href="#158">158</a>			<a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="159" href="#159">159</a>		} <b>else</b> {
<a class="hl" name="160" href="#160">160</a>			<a href="/source/s?defs=Process&amp;project=rtmp_client">Process</a> p = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="161" href="#161">161</a>			<a href="/source/s?defs=Thread&amp;project=rtmp_client">Thread</a> <a href="/source/s?defs=std&amp;project=rtmp_client">std</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="162" href="#162">162</a>			<b>try</b> {
<a class="l" name="163" href="#163">163</a>				<a href="/source/s?defs=Runtime&amp;project=rtmp_client">Runtime</a> <a href="/source/s?defs=runTime&amp;project=rtmp_client">runTime</a> = <a href="/source/s?defs=Runtime&amp;project=rtmp_client">Runtime</a>.<a href="/source/s?defs=getRuntime&amp;project=rtmp_client">getRuntime</a>();
<a class="l" name="164" href="#164">164</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Execute runtime"</span>);
<a class="l" name="165" href="#165">165</a>				<span class="c">//determine file system type</span>
<a class="l" name="166" href="#166">166</a>				<b>if</b> (<a href="/source/s?defs=File&amp;project=rtmp_client">File</a>.<a href="/source/s?defs=separatorChar&amp;project=rtmp_client">separatorChar</a> == <span class="s">'\\'</span>) {
<a class="l" name="167" href="#167">167</a>					<span class="c">//we are windows</span>
<a class="l" name="168" href="#168">168</a>					p = <a href="/source/s?defs=runTime&amp;project=rtmp_client">runTime</a>.<a href="/source/s?defs=exec&amp;project=rtmp_client">exec</a>(<span class="s">"CMD /D /C \"RMDIR /Q /S "</span>
<a class="l" name="169" href="#169">169</a>						+ <a href="/source/s?defs=directory&amp;project=rtmp_client">directory</a>.<a href="/source/s?defs=replace&amp;project=rtmp_client">replace</a>(<span class="s">'/'</span>, <span class="s">'\\'</span>) + <span class="s">"\""</span>);
<a class="hl" name="170" href="#170">170</a>				} <b>else</b> {
<a class="l" name="171" href="#171">171</a>					<span class="c">//we are unix variant</span>
<a class="l" name="172" href="#172">172</a>					p = <a href="/source/s?defs=runTime&amp;project=rtmp_client">runTime</a>.<a href="/source/s?defs=exec&amp;project=rtmp_client">exec</a>(<span class="s">"rm -rf "</span> + <a href="/source/s?defs=directory&amp;project=rtmp_client">directory</a>.<a href="/source/s?defs=replace&amp;project=rtmp_client">replace</a>(<span class="s">'\\'</span>, <a href="/source/s?defs=File&amp;project=rtmp_client">File</a>.<a href="/source/s?defs=separatorChar&amp;project=rtmp_client">separatorChar</a>));
<a class="l" name="173" href="#173">173</a>				}
<a class="l" name="174" href="#174">174</a>				<span class="c">// observe std out</span>
<a class="l" name="175" href="#175">175</a>				<a href="/source/s?defs=std&amp;project=rtmp_client">std</a> = <a class="d" href="#stdOut">stdOut</a>(p);
<a class="l" name="176" href="#176">176</a>				<span class="c">// wait for the observer threads to finish</span>
<a class="l" name="177" href="#177">177</a>				<b>while</b> (<a href="/source/s?defs=std&amp;project=rtmp_client">std</a>.<a href="/source/s?defs=isAlive&amp;project=rtmp_client">isAlive</a>()) {
<a class="l" name="178" href="#178">178</a>					<b>try</b> {
<a class="l" name="179" href="#179">179</a>						<a href="/source/s?defs=Thread&amp;project=rtmp_client">Thread</a>.<a href="/source/s?defs=sleep&amp;project=rtmp_client">sleep</a>(<span class="n">250</span>);
<a class="hl" name="180" href="#180">180</a>					} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="181" href="#181">181</a>					}
<a class="l" name="182" href="#182">182</a>				}
<a class="l" name="183" href="#183">183</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Process threads wait exited"</span>);
<a class="l" name="184" href="#184">184</a>				<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>true</b>;
<a class="l" name="185" href="#185">185</a>			} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="186" href="#186">186</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error running delete script"</span>, e);
<a class="l" name="187" href="#187">187</a>			} <b>finally</b> {
<a class="l" name="188" href="#188">188</a>				<b>if</b> (<a href="/source/s?defs=null&amp;project=rtmp_client">null</a> != p) {
<a class="l" name="189" href="#189">189</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Destroying process"</span>);
<a class="hl" name="190" href="#190">190</a>					p.<a href="/source/s?defs=destroy&amp;project=rtmp_client">destroy</a>();
<a class="l" name="191" href="#191">191</a>					p = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="192" href="#192">192</a>				}
<a class="l" name="193" href="#193">193</a>				<a href="/source/s?defs=std&amp;project=rtmp_client">std</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="194" href="#194">194</a>			}
<a class="l" name="195" href="#195">195</a>		}
<a class="l" name="196" href="#196">196</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="197" href="#197">197</a>	}
<a class="l" name="198" href="#198">198</a>
<a class="l" name="199" href="#199">199</a>	<span class="c">/**
<a class="hl" name="200" href="#200">200</a>	 * Rename a file natively; using REN on Windows and mv on *nix.
<a class="l" name="201" href="#201">201</a>	 *
<a class="l" name="202" href="#202">202</a>	 * <strong>@param</strong> <em>from</em> old name
<a class="l" name="203" href="#203">203</a>	 * <strong>@param</strong> <em>to</em> new name
<a class="l" name="204" href="#204">204</a>	 */</span>
<a class="l" name="205" href="#205">205</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="rename"/><a href="/source/s?refs=rename&amp;project=rtmp_client" class="xmt">rename</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="from"/><a href="/source/s?refs=from&amp;project=rtmp_client" class="xa">from</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="to"/><a href="/source/s?refs=to&amp;project=rtmp_client" class="xa">to</a>) {
<a class="l" name="206" href="#206">206</a>		<a href="/source/s?defs=Process&amp;project=rtmp_client">Process</a> p = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="207" href="#207">207</a>		<a href="/source/s?defs=Thread&amp;project=rtmp_client">Thread</a> <a href="/source/s?defs=std&amp;project=rtmp_client">std</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="208" href="#208">208</a>		<b>try</b> {
<a class="l" name="209" href="#209">209</a>			<a href="/source/s?defs=Runtime&amp;project=rtmp_client">Runtime</a> <a href="/source/s?defs=runTime&amp;project=rtmp_client">runTime</a> = <a href="/source/s?defs=Runtime&amp;project=rtmp_client">Runtime</a>.<a href="/source/s?defs=getRuntime&amp;project=rtmp_client">getRuntime</a>();
<a class="hl" name="210" href="#210">210</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Execute runtime"</span>);
<a class="l" name="211" href="#211">211</a>			<span class="c">//determine file system type</span>
<a class="l" name="212" href="#212">212</a>			<b>if</b> (<a href="/source/s?defs=File&amp;project=rtmp_client">File</a>.<a href="/source/s?defs=separatorChar&amp;project=rtmp_client">separatorChar</a> == <span class="s">'\\'</span>) {
<a class="l" name="213" href="#213">213</a>				<span class="c">//we are windows</span>
<a class="l" name="214" href="#214">214</a>				p = <a href="/source/s?defs=runTime&amp;project=rtmp_client">runTime</a>.<a href="/source/s?defs=exec&amp;project=rtmp_client">exec</a>(<span class="s">"CMD /D /C \"REN "</span> + <a class="d" href="#from">from</a> + <span class="s">' '</span> + <a class="d" href="#to">to</a> + <span class="s">"\""</span>);
<a class="l" name="215" href="#215">215</a>			} <b>else</b> {
<a class="l" name="216" href="#216">216</a>				<span class="c">//we are unix variant</span>
<a class="l" name="217" href="#217">217</a>				p = <a href="/source/s?defs=runTime&amp;project=rtmp_client">runTime</a>.<a href="/source/s?defs=exec&amp;project=rtmp_client">exec</a>(<span class="s">"mv -f "</span> + <a class="d" href="#from">from</a> + <span class="s">' '</span> + <a class="d" href="#to">to</a>);
<a class="l" name="218" href="#218">218</a>			}
<a class="l" name="219" href="#219">219</a>			<span class="c">// observe std out</span>
<a class="hl" name="220" href="#220">220</a>			<a href="/source/s?defs=std&amp;project=rtmp_client">std</a> = <a class="d" href="#stdOut">stdOut</a>(p);
<a class="l" name="221" href="#221">221</a>			<span class="c">// wait for the observer threads to finish</span>
<a class="l" name="222" href="#222">222</a>			<b>while</b> (<a href="/source/s?defs=std&amp;project=rtmp_client">std</a>.<a href="/source/s?defs=isAlive&amp;project=rtmp_client">isAlive</a>()) {
<a class="l" name="223" href="#223">223</a>				<b>try</b> {
<a class="l" name="224" href="#224">224</a>					<a href="/source/s?defs=Thread&amp;project=rtmp_client">Thread</a>.<a href="/source/s?defs=sleep&amp;project=rtmp_client">sleep</a>(<span class="n">250</span>);
<a class="l" name="225" href="#225">225</a>				} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="226" href="#226">226</a>				}
<a class="l" name="227" href="#227">227</a>			}
<a class="l" name="228" href="#228">228</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Process threads wait exited"</span>);
<a class="l" name="229" href="#229">229</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="hl" name="230" href="#230">230</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error running delete script"</span>, e);
<a class="l" name="231" href="#231">231</a>		} <b>finally</b> {
<a class="l" name="232" href="#232">232</a>			<b>if</b> (<a href="/source/s?defs=null&amp;project=rtmp_client">null</a> != p) {
<a class="l" name="233" href="#233">233</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Destroying process"</span>);
<a class="l" name="234" href="#234">234</a>				p.<a href="/source/s?defs=destroy&amp;project=rtmp_client">destroy</a>();
<a class="l" name="235" href="#235">235</a>				p = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="236" href="#236">236</a>				<a href="/source/s?defs=std&amp;project=rtmp_client">std</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="237" href="#237">237</a>			}
<a class="l" name="238" href="#238">238</a>		}
<a class="l" name="239" href="#239">239</a>	}
<a class="hl" name="240" href="#240">240</a>
<a class="l" name="241" href="#241">241</a>	<span class="c">/**
<a class="l" name="242" href="#242">242</a>	 * Special method for capture of StdOut.
<a class="l" name="243" href="#243">243</a>	 *
<a class="l" name="244" href="#244">244</a>	 * <strong>@return</strong>
<a class="l" name="245" href="#245">245</a>	 */</span>
<a class="l" name="246" href="#246">246</a>	<b>private</b> <b>final</b> <b>static</b> <a href="/source/s?defs=Thread&amp;project=rtmp_client">Thread</a> <a class="xmt" name="stdOut"/><a href="/source/s?refs=stdOut&amp;project=rtmp_client" class="xmt">stdOut</a>(<b>final</b> <a href="/source/s?defs=Process&amp;project=rtmp_client">Process</a> p) {
<a class="l" name="247" href="#247">247</a>		<b>final</b> <b>byte</b>[] <a href="/source/s?defs=empty&amp;project=rtmp_client">empty</a> = <b>new</b> <b>byte</b>[<span class="n">128</span>];
<a class="l" name="248" href="#248">248</a>		<b>for</b> (<b>int</b> b = <span class="n">0</span>; b &lt; <a href="/source/s?defs=empty&amp;project=rtmp_client">empty</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>; b++) {
<a class="l" name="249" href="#249">249</a>			<a href="/source/s?defs=empty&amp;project=rtmp_client">empty</a>[b] = (<b>byte</b>) <span class="n">0</span>;
<a class="hl" name="250" href="#250">250</a>		}
<a class="l" name="251" href="#251">251</a>		<a href="/source/s?defs=Thread&amp;project=rtmp_client">Thread</a> <a href="/source/s?defs=std&amp;project=rtmp_client">std</a> = <b>new</b> <a href="/source/s?defs=Thread&amp;project=rtmp_client">Thread</a>() {
<a class="l" name="252" href="#252">252</a>			<b>public</b> <b>void</b> <a href="/source/s?defs=run&amp;project=rtmp_client">run</a>() {
<a class="l" name="253" href="#253">253</a>				<a href="/source/s?defs=StringBuilder&amp;project=rtmp_client">StringBuilder</a> <a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a> = <b>new</b> <a href="/source/s?defs=StringBuilder&amp;project=rtmp_client">StringBuilder</a>(<span class="n">1024</span>);
<a class="l" name="254" href="#254">254</a>				<b>byte</b>[] <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> = <b>new</b> <b>byte</b>[<span class="n">128</span>];
<a class="l" name="255" href="#255">255</a>				<a href="/source/s?defs=BufferedInputStream&amp;project=rtmp_client">BufferedInputStream</a> <a href="/source/s?defs=bis&amp;project=rtmp_client">bis</a> = <b>new</b> <a href="/source/s?defs=BufferedInputStream&amp;project=rtmp_client">BufferedInputStream</a>(p
<a class="l" name="256" href="#256">256</a>						.<a href="/source/s?defs=getInputStream&amp;project=rtmp_client">getInputStream</a>());
<a class="l" name="257" href="#257">257</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Process output:"</span>);
<a class="l" name="258" href="#258">258</a>				<b>try</b> {
<a class="l" name="259" href="#259">259</a>					<b>while</b> (<a href="/source/s?defs=bis&amp;project=rtmp_client">bis</a>.<a href="/source/s?defs=read&amp;project=rtmp_client">read</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>) != -<span class="n">1</span>) {
<a class="hl" name="260" href="#260">260</a>						<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<b>new</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>).<a href="/source/s?defs=trim&amp;project=rtmp_client">trim</a>());
<a class="l" name="261" href="#261">261</a>						<span class="c">// clear buffer</span>
<a class="l" name="262" href="#262">262</a>						<a href="/source/s?defs=System&amp;project=rtmp_client">System</a>.<a href="/source/s?defs=arraycopy&amp;project=rtmp_client">arraycopy</a>(<a href="/source/s?defs=empty&amp;project=rtmp_client">empty</a>, <span class="n">0</span>, <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>, <span class="n">0</span>, <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>);
<a class="l" name="263" href="#263">263</a>					}
<a class="l" name="264" href="#264">264</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>());
<a class="l" name="265" href="#265">265</a>					<a href="/source/s?defs=bis&amp;project=rtmp_client">bis</a>.<a href="/source/s?defs=close&amp;project=rtmp_client">close</a>();
<a class="l" name="266" href="#266">266</a>				} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="267" href="#267">267</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"{}"</span>, e);
<a class="l" name="268" href="#268">268</a>				}
<a class="l" name="269" href="#269">269</a>			}
<a class="hl" name="270" href="#270">270</a>		};
<a class="l" name="271" href="#271">271</a>		<a href="/source/s?defs=std&amp;project=rtmp_client">std</a>.<a href="/source/s?defs=setDaemon&amp;project=rtmp_client">setDaemon</a>(<b>true</b>);
<a class="l" name="272" href="#272">272</a>		<a href="/source/s?defs=std&amp;project=rtmp_client">std</a>.<a href="/source/s?defs=start&amp;project=rtmp_client">start</a>();
<a class="l" name="273" href="#273">273</a>		<b>return</b> <a href="/source/s?defs=std&amp;project=rtmp_client">std</a>;
<a class="l" name="274" href="#274">274</a>	}
<a class="l" name="275" href="#275">275</a>
<a class="l" name="276" href="#276">276</a>	<span class="c">/**
<a class="l" name="277" href="#277">277</a>	 * Create a directory.
<a class="l" name="278" href="#278">278</a>	 *
<a class="l" name="279" href="#279">279</a>	 * <strong>@param</strong> <em>directory</em> directory to make
<a class="hl" name="280" href="#280">280</a>	 * <strong>@return</strong> whether a new directory was made
<a class="l" name="281" href="#281">281</a>	 * <strong>@throws</strong> <em>IOException</em> if directory does not already exist or cannot be made
<a class="l" name="282" href="#282">282</a>	 */</span>
<a class="l" name="283" href="#283">283</a>	<b>public</b> <b>static</b> <b>boolean</b> <a class="xmt" name="makeDirectory"/><a href="/source/s?refs=makeDirectory&amp;project=rtmp_client" class="xmt">makeDirectory</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="directory"/><a href="/source/s?refs=directory&amp;project=rtmp_client" class="xa">directory</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="284" href="#284">284</a>		<b>return</b> <a href="/source/s?defs=makeDirectory&amp;project=rtmp_client">makeDirectory</a>(<a href="/source/s?defs=directory&amp;project=rtmp_client">directory</a>, <b>false</b>);
<a class="l" name="285" href="#285">285</a>	}
<a class="l" name="286" href="#286">286</a>
<a class="l" name="287" href="#287">287</a>	<span class="c">/**
<a class="l" name="288" href="#288">288</a>	 * Create a directory. The parent directories will be created if
<a class="l" name="289" href="#289">289</a>	 * &lt;i&gt;createParents&lt;/i&gt; is passed as true.
<a class="hl" name="290" href="#290">290</a>	 *
<a class="l" name="291" href="#291">291</a>	 * <strong>@param</strong> <em>directory</em> directory
<a class="l" name="292" href="#292">292</a>	 * <strong>@param</strong> <em>createParents</em> whether to create all parents
<a class="l" name="293" href="#293">293</a>	 * <strong>@return</strong> true if directory was created; false if it already existed
<a class="l" name="294" href="#294">294</a>	 * <strong>@throws</strong> <em>IOException</em> if we cannot create directory
<a class="l" name="295" href="#295">295</a>	 *
<a class="l" name="296" href="#296">296</a>	 */</span>
<a class="l" name="297" href="#297">297</a>	<b>public</b> <b>static</b> <b>boolean</b> <a class="xmt" name="makeDirectory"/><a href="/source/s?refs=makeDirectory&amp;project=rtmp_client" class="xmt">makeDirectory</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="directory"/><a href="/source/s?refs=directory&amp;project=rtmp_client" class="xa">directory</a>, <b>boolean</b> <a class="xa" name="createParents"/><a href="/source/s?refs=createParents&amp;project=rtmp_client" class="xa">createParents</a>)
<a class="l" name="298" href="#298">298</a>			<b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="299" href="#299">299</a>		<b>boolean</b> <a href="/source/s?defs=created&amp;project=rtmp_client">created</a> = <b>false</b>;
<a class="hl" name="300" href="#300">300</a>		<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a> = <b>new</b> <a href="/source/s?defs=File&amp;project=rtmp_client">File</a>(<a href="/source/s?defs=directory&amp;project=rtmp_client">directory</a>);
<a class="l" name="301" href="#301">301</a>		<b>if</b> (<a class="d" href="#createParents">createParents</a>) {
<a class="l" name="302" href="#302">302</a>			<a href="/source/s?defs=created&amp;project=rtmp_client">created</a> = <a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a>.<a href="/source/s?defs=mkdirs&amp;project=rtmp_client">mkdirs</a>();
<a class="l" name="303" href="#303">303</a>			<b>if</b> (<a href="/source/s?defs=created&amp;project=rtmp_client">created</a>) {
<a class="l" name="304" href="#304">304</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Directory created: {}"</span>, <a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a>.<a href="/source/s?defs=getAbsolutePath&amp;project=rtmp_client">getAbsolutePath</a>());
<a class="l" name="305" href="#305">305</a>			} <b>else</b> {
<a class="l" name="306" href="#306">306</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Directory was not created: {}"</span>, <a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a>
<a class="l" name="307" href="#307">307</a>						.<a href="/source/s?defs=getAbsolutePath&amp;project=rtmp_client">getAbsolutePath</a>());
<a class="l" name="308" href="#308">308</a>			}
<a class="l" name="309" href="#309">309</a>		} <b>else</b> {
<a class="hl" name="310" href="#310">310</a>			<a href="/source/s?defs=created&amp;project=rtmp_client">created</a> = <a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a>.<a href="/source/s?defs=mkdir&amp;project=rtmp_client">mkdir</a>();
<a class="l" name="311" href="#311">311</a>			<b>if</b> (<a href="/source/s?defs=created&amp;project=rtmp_client">created</a>) {
<a class="l" name="312" href="#312">312</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Directory created: {}"</span>, <a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a>.<a href="/source/s?defs=getAbsolutePath&amp;project=rtmp_client">getAbsolutePath</a>());
<a class="l" name="313" href="#313">313</a>			} <b>else</b> {
<a class="l" name="314" href="#314">314</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Directory was not created: {}"</span>, <a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a>
<a class="l" name="315" href="#315">315</a>						.<a href="/source/s?defs=getAbsolutePath&amp;project=rtmp_client">getAbsolutePath</a>());
<a class="l" name="316" href="#316">316</a>			}
<a class="l" name="317" href="#317">317</a>		}
<a class="l" name="318" href="#318">318</a>		<a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="319" href="#319">319</a>		<b>return</b> <a href="/source/s?defs=created&amp;project=rtmp_client">created</a>;
<a class="hl" name="320" href="#320">320</a>	}
<a class="l" name="321" href="#321">321</a>
<a class="l" name="322" href="#322">322</a>	<span class="c">/**
<a class="l" name="323" href="#323">323</a>	 * Unzips a war file to an application located under the webapps directory
<a class="l" name="324" href="#324">324</a>	 *
<a class="l" name="325" href="#325">325</a>	 * <strong>@param</strong> <em>compressedFileName</em> The String name of the war file
<a class="l" name="326" href="#326">326</a>	 * <strong>@param</strong> <em>destinationDir</em> The destination directory, ie: webapps
<a class="l" name="327" href="#327">327</a>	 */</span>
<a class="l" name="328" href="#328">328</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="unzip"/><a href="/source/s?refs=unzip&amp;project=rtmp_client" class="xmt">unzip</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="compressedFileName"/><a href="/source/s?refs=compressedFileName&amp;project=rtmp_client" class="xa">compressedFileName</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="destinationDir"/><a href="/source/s?refs=destinationDir&amp;project=rtmp_client" class="xa">destinationDir</a>) {
<a class="l" name="329" href="#329">329</a>
<a class="hl" name="330" href="#330">330</a>		<span class="c">//strip everything except the applications name</span>
<a class="l" name="331" href="#331">331</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=dirName&amp;project=rtmp_client">dirName</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="332" href="#332">332</a>
<a class="l" name="333" href="#333">333</a>		<span class="c">// checks to see if there is a dash "-" in the filename of the war.</span>
<a class="l" name="334" href="#334">334</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=applicationName&amp;project=rtmp_client">applicationName</a> = <a class="d" href="#compressedFileName">compressedFileName</a>.<a href="/source/s?defs=substring&amp;project=rtmp_client">substring</a>(<a class="d" href="#compressedFileName">compressedFileName</a>.<a href="/source/s?defs=lastIndexOf&amp;project=rtmp_client">lastIndexOf</a>(<span class="s">"/"</span>));
<a class="l" name="335" href="#335">335</a>
<a class="l" name="336" href="#336">336</a>		<b>int</b> <a href="/source/s?defs=dashIndex&amp;project=rtmp_client">dashIndex</a> = <a href="/source/s?defs=applicationName&amp;project=rtmp_client">applicationName</a>.<a href="/source/s?defs=indexOf&amp;project=rtmp_client">indexOf</a>(<span class="s">'-'</span>);
<a class="l" name="337" href="#337">337</a>		<b>if</b> (<a href="/source/s?defs=dashIndex&amp;project=rtmp_client">dashIndex</a> != -<span class="n">1</span>) {
<a class="l" name="338" href="#338">338</a>			<span class="c">//strip everything except the applications name</span>
<a class="l" name="339" href="#339">339</a>			<a href="/source/s?defs=dirName&amp;project=rtmp_client">dirName</a> = <a class="d" href="#compressedFileName">compressedFileName</a>.<a href="/source/s?defs=substring&amp;project=rtmp_client">substring</a>(<span class="n">0</span>, <a href="/source/s?defs=dashIndex&amp;project=rtmp_client">dashIndex</a>);
<a class="hl" name="340" href="#340">340</a>		} <b>else</b> {
<a class="l" name="341" href="#341">341</a>			<span class="c">//grab every char up to the last '.'</span>
<a class="l" name="342" href="#342">342</a>			<a href="/source/s?defs=dirName&amp;project=rtmp_client">dirName</a> = <a class="d" href="#compressedFileName">compressedFileName</a>.<a href="/source/s?defs=substring&amp;project=rtmp_client">substring</a>(<span class="n">0</span>, <a class="d" href="#compressedFileName">compressedFileName</a>.<a href="/source/s?defs=lastIndexOf&amp;project=rtmp_client">lastIndexOf</a>(<span class="s">'.'</span>));
<a class="l" name="343" href="#343">343</a>		}
<a class="l" name="344" href="#344">344</a>
<a class="l" name="345" href="#345">345</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Directory: {}"</span>, <a href="/source/s?defs=dirName&amp;project=rtmp_client">dirName</a>);
<a class="l" name="346" href="#346">346</a>		<span class="c">//String tmpDir = System.getProperty("java.io.tmpdir");</span>
<a class="l" name="347" href="#347">347</a>		<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a href="/source/s?defs=zipDir&amp;project=rtmp_client">zipDir</a> = <b>new</b> <a href="/source/s?defs=File&amp;project=rtmp_client">File</a>(<a class="d" href="#compressedFileName">compressedFileName</a>);
<a class="l" name="348" href="#348">348</a>		<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a href="/source/s?defs=parent&amp;project=rtmp_client">parent</a> = <a href="/source/s?defs=zipDir&amp;project=rtmp_client">zipDir</a>.<a href="/source/s?defs=getParentFile&amp;project=rtmp_client">getParentFile</a>();
<a class="l" name="349" href="#349">349</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Parent: {}"</span>, (<a href="/source/s?defs=parent&amp;project=rtmp_client">parent</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> ? <a href="/source/s?defs=parent&amp;project=rtmp_client">parent</a>.<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>() : <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>));
<a class="hl" name="350" href="#350">350</a>		<span class="c">//File tmpDir = new File(System.getProperty("java.io.tmpdir"), dirName);</span>
<a class="l" name="351" href="#351">351</a>		<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a href="/source/s?defs=tmpDir&amp;project=rtmp_client">tmpDir</a> = <b>new</b> <a href="/source/s?defs=File&amp;project=rtmp_client">File</a>(<a class="d" href="#destinationDir">destinationDir</a>);
<a class="l" name="352" href="#352">352</a>
<a class="l" name="353" href="#353">353</a>		<span class="c">// make the war directory</span>
<a class="l" name="354" href="#354">354</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Making directory: {}"</span>, <a href="/source/s?defs=tmpDir&amp;project=rtmp_client">tmpDir</a>.<a href="/source/s?defs=mkdirs&amp;project=rtmp_client">mkdirs</a>());
<a class="l" name="355" href="#355">355</a>
<a class="l" name="356" href="#356">356</a>		<b>try</b> {
<a class="l" name="357" href="#357">357</a>			<a href="/source/s?defs=ZipFile&amp;project=rtmp_client">ZipFile</a> <a href="/source/s?defs=zf&amp;project=rtmp_client">zf</a> = <b>new</b> <a href="/source/s?defs=ZipFile&amp;project=rtmp_client">ZipFile</a>(<a class="d" href="#compressedFileName">compressedFileName</a>);
<a class="l" name="358" href="#358">358</a>			<a href="/source/s?defs=Enumeration&amp;project=rtmp_client">Enumeration</a>&lt;?&gt; e = <a href="/source/s?defs=zf&amp;project=rtmp_client">zf</a>.<a href="/source/s?defs=entries&amp;project=rtmp_client">entries</a>();
<a class="l" name="359" href="#359">359</a>			<b>while</b>(e.<a href="/source/s?defs=hasMoreElements&amp;project=rtmp_client">hasMoreElements</a>()) {
<a class="hl" name="360" href="#360">360</a>				<a href="/source/s?defs=ZipEntry&amp;project=rtmp_client">ZipEntry</a> <a href="/source/s?defs=ze&amp;project=rtmp_client">ze</a> = (<a href="/source/s?defs=ZipEntry&amp;project=rtmp_client">ZipEntry</a>) e.<a href="/source/s?defs=nextElement&amp;project=rtmp_client">nextElement</a>();
<a class="l" name="361" href="#361">361</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Unzipping {}"</span>, <a href="/source/s?defs=ze&amp;project=rtmp_client">ze</a>.<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>());
<a class="l" name="362" href="#362">362</a>				<b>if</b>(<a href="/source/s?defs=ze&amp;project=rtmp_client">ze</a>.<a href="/source/s?defs=isDirectory&amp;project=rtmp_client">isDirectory</a>()) {
<a class="l" name="363" href="#363">363</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"is a directory"</span>);
<a class="l" name="364" href="#364">364</a>					<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a> = <b>new</b> <a href="/source/s?defs=File&amp;project=rtmp_client">File</a>(<a href="/source/s?defs=tmpDir&amp;project=rtmp_client">tmpDir</a> + <span class="s">"/"</span> + <a href="/source/s?defs=ze&amp;project=rtmp_client">ze</a>.<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>());
<a class="l" name="365" href="#365">365</a>					<a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a> <a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a> = <a href="/source/s?defs=dir&amp;project=rtmp_client">dir</a>.<a href="/source/s?defs=mkdir&amp;project=rtmp_client">mkdir</a>();
<a class="l" name="366" href="#366">366</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"{}"</span>, <a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a>);
<a class="l" name="367" href="#367">367</a>					<b>continue</b>;
<a class="l" name="368" href="#368">368</a>				}
<a class="l" name="369" href="#369">369</a>
<a class="hl" name="370" href="#370">370</a>				<span class="c">// checks to see if a zipEntry contains a path</span>
<a class="l" name="371" href="#371">371</a>				<span class="c">// i.e. ze.getName() == "<a href="/source/s?path=META-INF/">META-INF</a>/<a href="/source/s?path=META-INF/MANIFEST.MF">MANIFEST.MF</a>"</span>
<a class="l" name="372" href="#372">372</a>				<span class="c">// if this case is true, then we create the path first</span>
<a class="l" name="373" href="#373">373</a>				<b>if</b>(<a href="/source/s?defs=ze&amp;project=rtmp_client">ze</a>.<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>().<a href="/source/s?defs=lastIndexOf&amp;project=rtmp_client">lastIndexOf</a>(<span class="s">"/"</span>) != -<span class="n">1</span>) {
<a class="l" name="374" href="#374">374</a>					<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=zipName&amp;project=rtmp_client">zipName</a> = <a href="/source/s?defs=ze&amp;project=rtmp_client">ze</a>.<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>();
<a class="l" name="375" href="#375">375</a>					<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=zipDirStructure&amp;project=rtmp_client">zipDirStructure</a> = <a href="/source/s?defs=zipName&amp;project=rtmp_client">zipName</a>.<a href="/source/s?defs=substring&amp;project=rtmp_client">substring</a>(<span class="n">0</span>, <a href="/source/s?defs=zipName&amp;project=rtmp_client">zipName</a>.<a href="/source/s?defs=lastIndexOf&amp;project=rtmp_client">lastIndexOf</a>(<span class="s">"/"</span>));
<a class="l" name="376" href="#376">376</a>					<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a href="/source/s?defs=completeDirectory&amp;project=rtmp_client">completeDirectory</a> = <b>new</b> <a href="/source/s?defs=File&amp;project=rtmp_client">File</a>(<a href="/source/s?defs=tmpDir&amp;project=rtmp_client">tmpDir</a> + <span class="s">"/"</span> + <a href="/source/s?defs=zipDirStructure&amp;project=rtmp_client">zipDirStructure</a>);
<a class="l" name="377" href="#377">377</a>					<b>if</b>(!<a href="/source/s?defs=completeDirectory&amp;project=rtmp_client">completeDirectory</a>.<a href="/source/s?defs=exists&amp;project=rtmp_client">exists</a>()) {
<a class="l" name="378" href="#378">378</a>						<b>if</b>(!<a href="/source/s?defs=completeDirectory&amp;project=rtmp_client">completeDirectory</a>.<a href="/source/s?defs=mkdirs&amp;project=rtmp_client">mkdirs</a>()) {
<a class="l" name="379" href="#379">379</a>							<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"could not create complete directory structure"</span>);
<a class="hl" name="380" href="#380">380</a>						}
<a class="l" name="381" href="#381">381</a>					}
<a class="l" name="382" href="#382">382</a>				}
<a class="l" name="383" href="#383">383</a>
<a class="l" name="384" href="#384">384</a>				<span class="c">// creates the file</span>
<a class="l" name="385" href="#385">385</a>				<a href="/source/s?defs=FileOutputStream&amp;project=rtmp_client">FileOutputStream</a> <a href="/source/s?defs=fout&amp;project=rtmp_client">fout</a> = <b>new</b> <a href="/source/s?defs=FileOutputStream&amp;project=rtmp_client">FileOutputStream</a>(<a href="/source/s?defs=tmpDir&amp;project=rtmp_client">tmpDir</a> + <span class="s">"/"</span> + <a href="/source/s?defs=ze&amp;project=rtmp_client">ze</a>.<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>());
<a class="l" name="386" href="#386">386</a>				<a href="/source/s?defs=InputStream&amp;project=rtmp_client">InputStream</a> <a class="d" href="#in">in</a> = <a href="/source/s?defs=zf&amp;project=rtmp_client">zf</a>.<a href="/source/s?defs=getInputStream&amp;project=rtmp_client">getInputStream</a>(<a href="/source/s?defs=ze&amp;project=rtmp_client">ze</a>);
<a class="l" name="387" href="#387">387</a>				<a class="d" href="#copy">copy</a>(<a class="d" href="#in">in</a>, <a href="/source/s?defs=fout&amp;project=rtmp_client">fout</a>);
<a class="l" name="388" href="#388">388</a>				<a class="d" href="#in">in</a>.<a href="/source/s?defs=close&amp;project=rtmp_client">close</a>();
<a class="l" name="389" href="#389">389</a>				<a href="/source/s?defs=fout&amp;project=rtmp_client">fout</a>.<a href="/source/s?defs=close&amp;project=rtmp_client">close</a>();
<a class="hl" name="390" href="#390">390</a>			}
<a class="l" name="391" href="#391">391</a>			e = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="392" href="#392">392</a>		} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> e) {
<a class="l" name="393" href="#393">393</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Errord unzipping"</span>, e);
<a class="l" name="394" href="#394">394</a>			<span class="c">//log.warn("Exception {}", e);</span>
<a class="l" name="395" href="#395">395</a>		}
<a class="l" name="396" href="#396">396</a>	}
<a class="l" name="397" href="#397">397</a>
<a class="l" name="398" href="#398">398</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="copy"/><a href="/source/s?refs=copy&amp;project=rtmp_client" class="xmt">copy</a>(<a href="/source/s?defs=InputStream&amp;project=rtmp_client">InputStream</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>, <a href="/source/s?defs=OutputStream&amp;project=rtmp_client">OutputStream</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="399" href="#399">399</a>		<b>synchronized</b>(<a class="d" href="#in">in</a>) {
<a class="hl" name="400" href="#400">400</a>			<b>synchronized</b>(<a class="d" href="#out">out</a>) {
<a class="l" name="401" href="#401">401</a>				<b>byte</b>[] <a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a> = <b>new</b> <b>byte</b>[<span class="n">256</span>];
<a class="l" name="402" href="#402">402</a>				<b>while</b> (<b>true</b>) {
<a class="l" name="403" href="#403">403</a>					<b>int</b> <a href="/source/s?defs=bytesRead&amp;project=rtmp_client">bytesRead</a> = <a class="d" href="#in">in</a>.<a href="/source/s?defs=read&amp;project=rtmp_client">read</a>(<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>);
<a class="l" name="404" href="#404">404</a>					<b>if</b>(<a href="/source/s?defs=bytesRead&amp;project=rtmp_client">bytesRead</a> == -<span class="n">1</span>) <b>break</b>;
<a class="l" name="405" href="#405">405</a>					<a class="d" href="#out">out</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>, <span class="n">0</span>, <a href="/source/s?defs=bytesRead&amp;project=rtmp_client">bytesRead</a>);
<a class="l" name="406" href="#406">406</a>				}
<a class="l" name="407" href="#407">407</a>			}
<a class="l" name="408" href="#408">408</a>		}
<a class="l" name="409" href="#409">409</a>	}
<a class="hl" name="410" href="#410">410</a>
<a class="l" name="411" href="#411">411</a>	<span class="c">/**
<a class="l" name="412" href="#412">412</a>	 * Unzips a given archive to a specified destination directory.
<a class="l" name="413" href="#413">413</a>	 *
<a class="l" name="414" href="#414">414</a>	 * <strong>@param</strong> <em>compressedFileName</em>
<a class="l" name="415" href="#415">415</a>	 * <strong>@param</strong> <em>destinationDir</em>
<a class="l" name="416" href="#416">416</a>	 */</span>
<a class="l" name="417" href="#417">417</a><span class="c">//	public static void unzip(String compressedFileName, String destinationDir) {</span>
<a class="l" name="418" href="#418">418</a><span class="c">//		log.debug("Unzip - file: {} destination: {}", compressedFileName, destinationDir);</span>
<a class="l" name="419" href="#419">419</a><span class="c">//		try {</span>
<a class="hl" name="420" href="#420">420</a><span class="c">//			final int BUFFER = 2048;</span>
<a class="l" name="421" href="#421">421</a><span class="c">//			BufferedOutputStream dest = null;</span>
<a class="l" name="422" href="#422">422</a><span class="c">//			FileInputStream fis = new FileInputStream(compressedFileName);</span>
<a class="l" name="423" href="#423">423</a><span class="c">//			CheckedInputStream checksum = new CheckedInputStream(fis,</span>
<a class="l" name="424" href="#424">424</a><span class="c">//					new Adler32());</span>
<a class="l" name="425" href="#425">425</a><span class="c">//			ZipInputStream zis = new ZipInputStream(new BufferedInputStream(</span>
<a class="l" name="426" href="#426">426</a><span class="c">//					checksum));</span>
<a class="l" name="427" href="#427">427</a><span class="c">//			ZipEntry entry;</span>
<a class="l" name="428" href="#428">428</a><span class="c">//			while ((entry = zis.getNextEntry()) != null) {</span>
<a class="l" name="429" href="#429">429</a><span class="c">//				log.debug("Extracting: {}", entry);</span>
<a class="hl" name="430" href="#430">430</a><span class="c">//				String name = entry.getName();</span>
<a class="l" name="431" href="#431">431</a><span class="c">//				int count;</span>
<a class="l" name="432" href="#432">432</a><span class="c">//				byte data[] = new byte[BUFFER];</span>
<a class="l" name="433" href="#433">433</a><span class="c">//				// write the files to the disk</span>
<a class="l" name="434" href="#434">434</a><span class="c">//				File destFile = new File(destinationDir, name);</span>
<a class="l" name="435" href="#435">435</a><span class="c">//				log.debug("Absolute path: {}", destFile.getAbsolutePath());</span>
<a class="l" name="436" href="#436">436</a><span class="c">//				//create dirs as needed, look for file extension to determine type</span>
<a class="l" name="437" href="#437">437</a><span class="c">//				if (entry.isDirectory()) {</span>
<a class="l" name="438" href="#438">438</a><span class="c">//					log.debug("Entry is detected as a directory");</span>
<a class="l" name="439" href="#439">439</a><span class="c">//					if (destFile.mkdirs()) {</span>
<a class="hl" name="440" href="#440">440</a><span class="c">//						log.debug("Directory created: {}", destFile.getName());</span>
<a class="l" name="441" href="#441">441</a><span class="c">//					} else {</span>
<a class="l" name="442" href="#442">442</a><span class="c">//						log.warn("Directory was not created: {}", destFile.getName());</span>
<a class="l" name="443" href="#443">443</a><span class="c">//					}</span>
<a class="l" name="444" href="#444">444</a><span class="c">//					destFile = null;</span>
<a class="l" name="445" href="#445">445</a><span class="c">//					continue;</span>
<a class="l" name="446" href="#446">446</a><span class="c">//				}</span>
<a class="l" name="447" href="#447">447</a><span class="c">//</span>
<a class="l" name="448" href="#448">448</a><span class="c">//				FileOutputStream fos = new FileOutputStream(destFile);</span>
<a class="l" name="449" href="#449">449</a><span class="c">//				dest = new BufferedOutputStream(fos, BUFFER);</span>
<a class="hl" name="450" href="#450">450</a><span class="c">//				while ((count = zis.read(data, 0, BUFFER)) != -1) {</span>
<a class="l" name="451" href="#451">451</a><span class="c">//					dest.write(data, 0, count);</span>
<a class="l" name="452" href="#452">452</a><span class="c">//				}</span>
<a class="l" name="453" href="#453">453</a><span class="c">//				dest.flush();</span>
<a class="l" name="454" href="#454">454</a><span class="c">//				dest.close();</span>
<a class="l" name="455" href="#455">455</a><span class="c">//				destFile = null;</span>
<a class="l" name="456" href="#456">456</a><span class="c">//			}</span>
<a class="l" name="457" href="#457">457</a><span class="c">//			zis.close();</span>
<a class="l" name="458" href="#458">458</a><span class="c">//			log.debug("Checksum: {}", checksum.getChecksum().getValue());</span>
<a class="l" name="459" href="#459">459</a><span class="c">//		} catch (Exception e) {</span>
<a class="hl" name="460" href="#460">460</a><span class="c">//			log.error("Error unzipping {}", compressedFileName, e);</span>
<a class="l" name="461" href="#461">461</a><span class="c">//			log.warn("Exception {}", e);</span>
<a class="l" name="462" href="#462">462</a><span class="c">//		}</span>
<a class="l" name="463" href="#463">463</a><span class="c">//</span>
<a class="l" name="464" href="#464">464</a><span class="c">//	}</span>
<a class="l" name="465" href="#465">465</a>
<a class="l" name="466" href="#466">466</a>    <span class="c">/**
<a class="l" name="467" href="#467">467</a>     * Quick-n-dirty directory formatting to support launching in windows, specifically from ant.
<a class="l" name="468" href="#468">468</a>     * <strong>@param</strong> <em>absWebappsPath</em> abs webapps path
<a class="l" name="469" href="#469">469</a>     * <strong>@param</strong> <em>contextDirName</em> conext directory name
<a class="hl" name="470" href="#470">470</a>     * <strong>@return</strong> full path
<a class="l" name="471" href="#471">471</a>     */</span>
<a class="l" name="472" href="#472">472</a>    <b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="formatPath"/><a href="/source/s?refs=formatPath&amp;project=rtmp_client" class="xmt">formatPath</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="absWebappsPath"/><a href="/source/s?refs=absWebappsPath&amp;project=rtmp_client" class="xa">absWebappsPath</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="contextDirName"/><a href="/source/s?refs=contextDirName&amp;project=rtmp_client" class="xa">contextDirName</a>) {
<a class="l" name="473" href="#473">473</a>        <a href="/source/s?defs=StringBuilder&amp;project=rtmp_client">StringBuilder</a> <a href="/source/s?defs=path&amp;project=rtmp_client">path</a> = <b>new</b> <a href="/source/s?defs=StringBuilder&amp;project=rtmp_client">StringBuilder</a>(<a class="d" href="#absWebappsPath">absWebappsPath</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>() + <a class="d" href="#contextDirName">contextDirName</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>());
<a class="l" name="474" href="#474">474</a>        <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a class="d" href="#absWebappsPath">absWebappsPath</a>);
<a class="l" name="475" href="#475">475</a>        <b>if</b> (<a class="d" href="#log">log</a>.<a href="/source/s?defs=isTraceEnabled&amp;project=rtmp_client">isTraceEnabled</a>()) {
<a class="l" name="476" href="#476">476</a>        	<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Path start: {}"</span>, <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>());
<a class="l" name="477" href="#477">477</a>        }
<a class="l" name="478" href="#478">478</a>        <b>int</b> <a href="/source/s?defs=idx&amp;project=rtmp_client">idx</a> = -<span class="n">1</span>;
<a class="l" name="479" href="#479">479</a>        <b>if</b> (<a href="/source/s?defs=File&amp;project=rtmp_client">File</a>.<a href="/source/s?defs=separatorChar&amp;project=rtmp_client">separatorChar</a> != <span class="s">'/'</span>) {
<a class="hl" name="480" href="#480">480</a>            <b>while</b> ((<a href="/source/s?defs=idx&amp;project=rtmp_client">idx</a> = <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=indexOf&amp;project=rtmp_client">indexOf</a>(<a href="/source/s?defs=File&amp;project=rtmp_client">File</a>.<a href="/source/s?defs=separator&amp;project=rtmp_client">separator</a>)) != -<span class="n">1</span>) {
<a class="l" name="481" href="#481">481</a>                <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=deleteCharAt&amp;project=rtmp_client">deleteCharAt</a>(<a href="/source/s?defs=idx&amp;project=rtmp_client">idx</a>);
<a class="l" name="482" href="#482">482</a>                <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=insert&amp;project=rtmp_client">insert</a>(<a href="/source/s?defs=idx&amp;project=rtmp_client">idx</a>, <span class="s">'/'</span>);
<a class="l" name="483" href="#483">483</a>            }
<a class="l" name="484" href="#484">484</a>        }
<a class="l" name="485" href="#485">485</a>        <b>if</b> (<a class="d" href="#log">log</a>.<a href="/source/s?defs=isTraceEnabled&amp;project=rtmp_client">isTraceEnabled</a>()) {
<a class="l" name="486" href="#486">486</a>        	<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Path step 1: {}"</span>, <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>());
<a class="l" name="487" href="#487">487</a>        }
<a class="l" name="488" href="#488">488</a>        <span class="c">//remove any './'</span>
<a class="l" name="489" href="#489">489</a>        <b>if</b> ((<a href="/source/s?defs=idx&amp;project=rtmp_client">idx</a> = <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=indexOf&amp;project=rtmp_client">indexOf</a>(<span class="s">"./"</span>)) != -<span class="n">1</span>) {
<a class="hl" name="490" href="#490">490</a>        	<a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=delete&amp;project=rtmp_client">delete</a>(<a href="/source/s?defs=idx&amp;project=rtmp_client">idx</a>, <a href="/source/s?defs=idx&amp;project=rtmp_client">idx</a> + <span class="n">2</span>);
<a class="l" name="491" href="#491">491</a>        }
<a class="l" name="492" href="#492">492</a>        <b>if</b> (<a class="d" href="#log">log</a>.<a href="/source/s?defs=isTraceEnabled&amp;project=rtmp_client">isTraceEnabled</a>()) {
<a class="l" name="493" href="#493">493</a>        	<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Path step 2: {}"</span>, <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>());
<a class="l" name="494" href="#494">494</a>        }
<a class="l" name="495" href="#495">495</a>        <span class="c">//add / to base path if one doesnt exist</span>
<a class="l" name="496" href="#496">496</a>        <b>if</b> (<a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=charAt&amp;project=rtmp_client">charAt</a>(<a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>() - <span class="n">1</span>) != <span class="s">'/'</span>) {
<a class="l" name="497" href="#497">497</a>        	<a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">'/'</span>);
<a class="l" name="498" href="#498">498</a>        }
<a class="l" name="499" href="#499">499</a>        <b>if</b> (<a class="d" href="#log">log</a>.<a href="/source/s?defs=isTraceEnabled&amp;project=rtmp_client">isTraceEnabled</a>()) {
<a class="hl" name="500" href="#500">500</a>        	<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Path step 3: {}"</span>, <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>());
<a class="l" name="501" href="#501">501</a>        }
<a class="l" name="502" href="#502">502</a>        <span class="c">//remove the / from the beginning of the context dir</span>
<a class="l" name="503" href="#503">503</a>        <b>if</b> (<a class="d" href="#contextDirName">contextDirName</a>.<a href="/source/s?defs=charAt&amp;project=rtmp_client">charAt</a>(<span class="n">0</span>) == <span class="s">'/'</span> &amp;&amp; <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=charAt&amp;project=rtmp_client">charAt</a>(<a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>() - <span class="n">1</span>) == <span class="s">'/'</span>) {
<a class="l" name="504" href="#504">504</a>            <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a class="d" href="#contextDirName">contextDirName</a>.<a href="/source/s?defs=substring&amp;project=rtmp_client">substring</a>(<span class="n">1</span>));
<a class="l" name="505" href="#505">505</a>        } <b>else</b> {
<a class="l" name="506" href="#506">506</a>            <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a class="d" href="#contextDirName">contextDirName</a>);
<a class="l" name="507" href="#507">507</a>        }
<a class="l" name="508" href="#508">508</a>        <b>if</b> (<a class="d" href="#log">log</a>.<a href="/source/s?defs=isTraceEnabled&amp;project=rtmp_client">isTraceEnabled</a>()) {
<a class="l" name="509" href="#509">509</a>        	<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Path step 4: {}"</span>, <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>());
<a class="hl" name="510" href="#510">510</a>        }
<a class="l" name="511" href="#511">511</a>        <b>return</b> <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>();
<a class="l" name="512" href="#512">512</a>    }
<a class="l" name="513" href="#513">513</a>
<a class="l" name="514" href="#514">514</a>	<span class="c">/**
<a class="l" name="515" href="#515">515</a>	 * Generates a custom name containing numbers and an underscore ex. 282818_00023.
<a class="l" name="516" href="#516">516</a>	 * The name contains current seconds and a random number component.
<a class="l" name="517" href="#517">517</a>	 *
<a class="l" name="518" href="#518">518</a>	 * <strong>@return</strong> custom name
<a class="l" name="519" href="#519">519</a>	 */</span>
<a class="hl" name="520" href="#520">520</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="generateCustomName"/><a href="/source/s?refs=generateCustomName&amp;project=rtmp_client" class="xmt">generateCustomName</a>() {
<a class="l" name="521" href="#521">521</a>		<a href="/source/s?defs=Random&amp;project=rtmp_client">Random</a> <a href="/source/s?defs=random&amp;project=rtmp_client">random</a> = <b>new</b> <a href="/source/s?defs=Random&amp;project=rtmp_client">Random</a>();
<a class="l" name="522" href="#522">522</a>    	<a href="/source/s?defs=StringBuilder&amp;project=rtmp_client">StringBuilder</a> <a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a> = <b>new</b> <a href="/source/s?defs=StringBuilder&amp;project=rtmp_client">StringBuilder</a>();
<a class="l" name="523" href="#523">523</a>    	<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a href="/source/s?defs=PropertyConverter&amp;project=rtmp_client">PropertyConverter</a>.<a href="/source/s?defs=getCurrentTimeSeconds&amp;project=rtmp_client">getCurrentTimeSeconds</a>());
<a class="l" name="524" href="#524">524</a>    	<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">'_'</span>);
<a class="l" name="525" href="#525">525</a>    	<b>int</b> i = <a href="/source/s?defs=random&amp;project=rtmp_client">random</a>.<a href="/source/s?defs=nextInt&amp;project=rtmp_client">nextInt</a>(<span class="n">99999</span>);
<a class="l" name="526" href="#526">526</a>    	<b>if</b> (i &lt; <span class="n">10</span>) {
<a class="l" name="527" href="#527">527</a>    		<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">"0000"</span>);
<a class="l" name="528" href="#528">528</a>    	} <b>else</b> <b>if</b> (i &lt; <span class="n">100</span>) {
<a class="l" name="529" href="#529">529</a>       		<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">"000"</span>);
<a class="hl" name="530" href="#530">530</a>    	} <b>else</b> <b>if</b> (i &lt; <span class="n">1000</span>) {
<a class="l" name="531" href="#531">531</a>       		<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">"00"</span>);
<a class="l" name="532" href="#532">532</a>    	} <b>else</b> <b>if</b> (i &lt; <span class="n">10000</span>) {
<a class="l" name="533" href="#533">533</a>       		<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">'0'</span>);
<a class="l" name="534" href="#534">534</a>    	}
<a class="l" name="535" href="#535">535</a>    	<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(i);
<a class="l" name="536" href="#536">536</a>    	<b>return</b> <a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>();
<a class="l" name="537" href="#537">537</a>    }
<a class="l" name="538" href="#538">538</a>
<a class="l" name="539" href="#539">539</a>}
<a class="hl" name="540" href="#540">540</a>