<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.red5.io",1]]],["Interface","xi",[["ITag",31]]],["Method","xmt",[["getBody",38],["getBodySize",45],["getData",66],["getDataType",52],["getPreviousTagSize",73],["getTimestamp",59],["setBody",79],["setBodySize",85],["setDataType",91],["setPreviousTagSize",103],["setTimestamp",97]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a><span class="c">/**
<a class="l" name="25" href="#25">25</a> * A Tag represents the contents or payload of a streamable file.
<a class="l" name="26" href="#26">26</a> *
<a class="l" name="27" href="#27">27</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="28" href="#28">28</a> * <strong>@author</strong> Dominick Accattato (daccattato@gmail.com)
<a class="l" name="29" href="#29">29</a> * <strong>@author</strong> Luke Hubbard, Codegent Ltd (luke@codegent.com)
<a class="hl" name="30" href="#30">30</a> */</span>
<a class="l" name="31" href="#31">31</a><b>public</b> <b>interface</b> <a class="xi" name="ITag"/><a href="/source/s?refs=ITag&amp;project=rtmp_client" class="xi">ITag</a> <b>extends</b> <a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a> {
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a>	<span class="c">/**
<a class="l" name="34" href="#34">34</a>	 * Return the body ByteBuffer
<a class="l" name="35" href="#35">35</a>	 *
<a class="l" name="36" href="#36">36</a>	 * <strong>@return</strong> ByteBuffer        Body as byte buffer
<a class="l" name="37" href="#37">37</a>	 */</span>
<a class="l" name="38" href="#38">38</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="getBody"/><a href="/source/s?refs=getBody&amp;project=rtmp_client" class="xmt">getBody</a>();
<a class="l" name="39" href="#39">39</a>
<a class="hl" name="40" href="#40">40</a>	<span class="c">/**
<a class="l" name="41" href="#41">41</a>	 * Return the size of the body
<a class="l" name="42" href="#42">42</a>	 *
<a class="l" name="43" href="#43">43</a>	 * <strong>@return</strong> int               Body size
<a class="l" name="44" href="#44">44</a>	 */</span>
<a class="l" name="45" href="#45">45</a>	<b>public</b> <b>int</b> <a class="xmt" name="getBodySize"/><a href="/source/s?refs=getBodySize&amp;project=rtmp_client" class="xmt">getBodySize</a>();
<a class="l" name="46" href="#46">46</a>
<a class="l" name="47" href="#47">47</a>	<span class="c">/**
<a class="l" name="48" href="#48">48</a>	 * Get the data type
<a class="l" name="49" href="#49">49</a>	 *
<a class="hl" name="50" href="#50">50</a>	 * <strong>@return</strong> byte              Data type as byte
<a class="l" name="51" href="#51">51</a>	 */</span>
<a class="l" name="52" href="#52">52</a>	<b>public</b> <b>byte</b> <a class="xmt" name="getDataType"/><a href="/source/s?refs=getDataType&amp;project=rtmp_client" class="xmt">getDataType</a>();
<a class="l" name="53" href="#53">53</a>
<a class="l" name="54" href="#54">54</a>	<span class="c">/**
<a class="l" name="55" href="#55">55</a>	 * Return the timestamp
<a class="l" name="56" href="#56">56</a>	 *
<a class="l" name="57" href="#57">57</a>	 * <strong>@return</strong> int               Timestamp
<a class="l" name="58" href="#58">58</a>	 */</span>
<a class="l" name="59" href="#59">59</a>	<b>public</b> <b>int</b> <a class="xmt" name="getTimestamp"/><a href="/source/s?refs=getTimestamp&amp;project=rtmp_client" class="xmt">getTimestamp</a>();
<a class="hl" name="60" href="#60">60</a>
<a class="l" name="61" href="#61">61</a>	<span class="c">/**
<a class="l" name="62" href="#62">62</a>	 * Returns the data as a ByteBuffer
<a class="l" name="63" href="#63">63</a>	 *
<a class="l" name="64" href="#64">64</a>	 * <strong>@return</strong> ByteBuffer        Data as byte buffer
<a class="l" name="65" href="#65">65</a>	 */</span>
<a class="l" name="66" href="#66">66</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="getData"/><a href="/source/s?refs=getData&amp;project=rtmp_client" class="xmt">getData</a>();
<a class="l" name="67" href="#67">67</a>
<a class="l" name="68" href="#68">68</a>	<span class="c">/**
<a class="l" name="69" href="#69">69</a>	 * Returns previous tag size
<a class="hl" name="70" href="#70">70</a>	 *
<a class="l" name="71" href="#71">71</a>	 * <strong>@return</strong> int               Previous tag size
<a class="l" name="72" href="#72">72</a>	 */</span>
<a class="l" name="73" href="#73">73</a>	<b>public</b> <b>int</b> <a class="xmt" name="getPreviousTagSize"/><a href="/source/s?refs=getPreviousTagSize&amp;project=rtmp_client" class="xmt">getPreviousTagSize</a>();
<a class="l" name="74" href="#74">74</a>
<a class="l" name="75" href="#75">75</a>	<span class="c">/**
<a class="l" name="76" href="#76">76</a>	 * Set the body ByteBuffer.
<a class="l" name="77" href="#77">77</a>     * <strong>@param</strong> <em>body</em>               Body as ByteBuffer
<a class="l" name="78" href="#78">78</a>     */</span>
<a class="l" name="79" href="#79">79</a>	<b>public</b> <b>void</b> <a class="xmt" name="setBody"/><a href="/source/s?refs=setBody&amp;project=rtmp_client" class="xmt">setBody</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="body"/><a href="/source/s?refs=body&amp;project=rtmp_client" class="xa">body</a>);
<a class="hl" name="80" href="#80">80</a>
<a class="l" name="81" href="#81">81</a>	<span class="c">/**
<a class="l" name="82" href="#82">82</a>	 * Set the size of the body.
<a class="l" name="83" href="#83">83</a>     * <strong>@param</strong> <em>size</em>               Body size
<a class="l" name="84" href="#84">84</a>     */</span>
<a class="l" name="85" href="#85">85</a>	<b>public</b> <b>void</b> <a class="xmt" name="setBodySize"/><a href="/source/s?refs=setBodySize&amp;project=rtmp_client" class="xmt">setBodySize</a>(<b>int</b> <a class="xa" name="size"/><a href="/source/s?refs=size&amp;project=rtmp_client" class="xa">size</a>);
<a class="l" name="86" href="#86">86</a>
<a class="l" name="87" href="#87">87</a>	<span class="c">/**
<a class="l" name="88" href="#88">88</a>	 * Set the data type.
<a class="l" name="89" href="#89">89</a>     * <strong>@param</strong> <em>datatype</em>           Data type
<a class="hl" name="90" href="#90">90</a>     */</span>
<a class="l" name="91" href="#91">91</a>	<b>public</b> <b>void</b> <a class="xmt" name="setDataType"/><a href="/source/s?refs=setDataType&amp;project=rtmp_client" class="xmt">setDataType</a>(<b>byte</b> <a class="xa" name="datatype"/><a href="/source/s?refs=datatype&amp;project=rtmp_client" class="xa">datatype</a>);
<a class="l" name="92" href="#92">92</a>
<a class="l" name="93" href="#93">93</a>	<span class="c">/**
<a class="l" name="94" href="#94">94</a>	 * Set the timestamp.
<a class="l" name="95" href="#95">95</a>     * <strong>@param</strong> <em>timestamp</em>          Timestamp
<a class="l" name="96" href="#96">96</a>     */</span>
<a class="l" name="97" href="#97">97</a>	<b>public</b> <b>void</b> <a class="xmt" name="setTimestamp"/><a href="/source/s?refs=setTimestamp&amp;project=rtmp_client" class="xmt">setTimestamp</a>(<b>int</b> <a class="xa" name="timestamp"/><a href="/source/s?refs=timestamp&amp;project=rtmp_client" class="xa">timestamp</a>);
<a class="l" name="98" href="#98">98</a>
<a class="l" name="99" href="#99">99</a>	<span class="c">/**
<a class="hl" name="100" href="#100">100</a>	 * Set the size of the previous tag.
<a class="l" name="101" href="#101">101</a>     * <strong>@param</strong> <em>size</em>               Previous tag size
<a class="l" name="102" href="#102">102</a>     */</span>
<a class="l" name="103" href="#103">103</a>	<b>public</b> <b>void</b> <a class="xmt" name="setPreviousTagSize"/><a href="/source/s?refs=setPreviousTagSize&amp;project=rtmp_client" class="xmt">setPreviousTagSize</a>(<b>int</b> <a class="xa" name="size"/><a href="/source/s?refs=size&amp;project=rtmp_client" class="xa">size</a>);
<a class="l" name="104" href="#104">104</a>
<a class="l" name="105" href="#105">105</a>}
<a class="l" name="106" href="#106">106</a>