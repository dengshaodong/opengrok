<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["FileKeyFrameMetaCache",54]]],["Package","xp",[["org.red5.io",1]]],["Method","xmt",[["loadKeyFrameMeta",62],["saveKeyFrameMeta",143]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=File&amp;project=rtmp_client">File</a>;
<a class="l" name="23" href="#23">23</a><span class="c">//import java.io.FileOutputStream;</span>
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=parsers&amp;project=rtmp_client">parsers</a>.<a href="/source/s?defs=DocumentBuilder&amp;project=rtmp_client">DocumentBuilder</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=parsers&amp;project=rtmp_client">parsers</a>.<a href="/source/s?defs=DocumentBuilderFactory&amp;project=rtmp_client">DocumentBuilderFactory</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=parsers&amp;project=rtmp_client">parsers</a>.<a href="/source/s?defs=ParserConfigurationException&amp;project=rtmp_client">ParserConfigurationException</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=xpath&amp;project=rtmp_client">xpath</a>.<a href="/source/s?defs=XPath&amp;project=rtmp_client">XPath</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=xpath&amp;project=rtmp_client">xpath</a>.<a href="/source/s?defs=XPathConstants&amp;project=rtmp_client">XPathConstants</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=xpath&amp;project=rtmp_client">xpath</a>.<a href="/source/s?defs=XPathExpression&amp;project=rtmp_client">XPathExpression</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=xpath&amp;project=rtmp_client">xpath</a>.<a href="/source/s?defs=XPathExpressionException&amp;project=rtmp_client">XPathExpressionException</a>;
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=xpath&amp;project=rtmp_client">xpath</a>.<a href="/source/s?defs=XPathFactory&amp;project=rtmp_client">XPathFactory</a>;
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a><span class="c">//import <a href="/source/s?path=org.apache.xml&amp;project=rtmp_client">org.apache.xml</a>.serialize.OutputFormat;</span>
<a class="l" name="36" href="#36">36</a><span class="c">//import <a href="/source/s?path=org.apache.xml.serialize.XML&amp;project=rtmp_client">org.apache.xml.serialize.XML</a>Serializer;</span>
<a class="l" name="37" href="#37">37</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>.<a href="/source/s?defs=IKeyFrameDataAnalyzer&amp;project=rtmp_client">IKeyFrameDataAnalyzer</a>.<a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a>;
<a class="l" name="38" href="#38">38</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="39" href="#39">39</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="hl" name="40" href="#40">40</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=w3c&amp;project=rtmp_client">w3c</a>.<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a>;
<a class="l" name="41" href="#41">41</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=w3c&amp;project=rtmp_client">w3c</a>.<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=Element&amp;project=rtmp_client">Element</a>;
<a class="l" name="42" href="#42">42</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=w3c&amp;project=rtmp_client">w3c</a>.<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=NamedNodeMap&amp;project=rtmp_client">NamedNodeMap</a>;
<a class="l" name="43" href="#43">43</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=w3c&amp;project=rtmp_client">w3c</a>.<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=Node&amp;project=rtmp_client">Node</a>;
<a class="l" name="44" href="#44">44</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=w3c&amp;project=rtmp_client">w3c</a>.<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=NodeList&amp;project=rtmp_client">NodeList</a>;
<a class="l" name="45" href="#45">45</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>.<a href="/source/s?defs=sax&amp;project=rtmp_client">sax</a>.<a href="/source/s?defs=SAXException&amp;project=rtmp_client">SAXException</a>;
<a class="l" name="46" href="#46">46</a>
<a class="l" name="47" href="#47">47</a><span class="c">/**
<a class="l" name="48" href="#48">48</a> * File-based keyframe metadata cache.
<a class="l" name="49" href="#49">49</a> *
<a class="hl" name="50" href="#50">50</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="51" href="#51">51</a> * <strong>@author</strong> Joachim Bauch (jojo@struktur.de)
<a class="l" name="52" href="#52">52</a> */</span>
<a class="l" name="53" href="#53">53</a><span class="c">//@SuppressWarnings("deprecation")</span>
<a class="l" name="54" href="#54">54</a><b>public</b> <b>class</b> <a class="xc" name="FileKeyFrameMetaCache"/><a href="/source/s?refs=FileKeyFrameMetaCache&amp;project=rtmp_client" class="xc">FileKeyFrameMetaCache</a> <b>implements</b> <a href="/source/s?defs=IKeyFrameMetaCache&amp;project=rtmp_client">IKeyFrameMetaCache</a> {
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a>    <span class="c">/**
<a class="l" name="57" href="#57">57</a>     * Logger
<a class="l" name="58" href="#58">58</a>     */</span>
<a class="l" name="59" href="#59">59</a>    <b>private</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a class="d" href="#FileKeyFrameMetaCache">FileKeyFrameMetaCache</a>.<b>class</b>);
<a class="hl" name="60" href="#60">60</a>
<a class="l" name="61" href="#61">61</a>    <span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="62" href="#62">62</a>	<b>public</b> <a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a> <a class="xmt" name="loadKeyFrameMeta"/><a href="/source/s?refs=loadKeyFrameMeta&amp;project=rtmp_client" class="xmt">loadKeyFrameMeta</a>(<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a class="xa" name="file"/><a href="/source/s?refs=file&amp;project=rtmp_client" class="xa">file</a>) {
<a class="l" name="63" href="#63">63</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=filename&amp;project=rtmp_client">filename</a> = <a href="/source/s?defs=file&amp;project=rtmp_client">file</a>.<a href="/source/s?defs=getAbsolutePath&amp;project=rtmp_client">getAbsolutePath</a>() + <span class="s">".meta"</span>;
<a class="l" name="64" href="#64">64</a>		<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a href="/source/s?defs=metadataFile&amp;project=rtmp_client">metadataFile</a> = <b>new</b> <a href="/source/s?defs=File&amp;project=rtmp_client">File</a>(<a href="/source/s?defs=filename&amp;project=rtmp_client">filename</a>);
<a class="l" name="65" href="#65">65</a>		<b>if</b> (!<a href="/source/s?defs=metadataFile&amp;project=rtmp_client">metadataFile</a>.<a href="/source/s?defs=exists&amp;project=rtmp_client">exists</a>()) {
<a class="l" name="66" href="#66">66</a>			<span class="c">// No such metadata</span>
<a class="l" name="67" href="#67">67</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="68" href="#68">68</a>		}
<a class="l" name="69" href="#69">69</a>
<a class="hl" name="70" href="#70">70</a>		<a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a> <a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>;
<a class="l" name="71" href="#71">71</a>		<a href="/source/s?defs=DocumentBuilderFactory&amp;project=rtmp_client">DocumentBuilderFactory</a> <a href="/source/s?defs=dbf&amp;project=rtmp_client">dbf</a> = <a href="/source/s?defs=DocumentBuilderFactory&amp;project=rtmp_client">DocumentBuilderFactory</a>.<a href="/source/s?defs=newInstance&amp;project=rtmp_client">newInstance</a>();
<a class="l" name="72" href="#72">72</a>		<b>try</b> {
<a class="l" name="73" href="#73">73</a>			<span class="c">// Using factory get an instance of document builder</span>
<a class="l" name="74" href="#74">74</a>			<a href="/source/s?defs=DocumentBuilder&amp;project=rtmp_client">DocumentBuilder</a> <a href="/source/s?defs=db&amp;project=rtmp_client">db</a> = <a href="/source/s?defs=dbf&amp;project=rtmp_client">dbf</a>.<a href="/source/s?defs=newDocumentBuilder&amp;project=rtmp_client">newDocumentBuilder</a>();
<a class="l" name="75" href="#75">75</a>
<a class="l" name="76" href="#76">76</a>			<span class="c">// parse using builder to get DOM representation of the XML file</span>
<a class="l" name="77" href="#77">77</a>			<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a> = <a href="/source/s?defs=db&amp;project=rtmp_client">db</a>.<a href="/source/s?defs=parse&amp;project=rtmp_client">parse</a>(<a href="/source/s?defs=filename&amp;project=rtmp_client">filename</a>);
<a class="l" name="78" href="#78">78</a>
<a class="l" name="79" href="#79">79</a>			<a href="/source/s?defs=db&amp;project=rtmp_client">db</a>.<a href="/source/s?defs=reset&amp;project=rtmp_client">reset</a>();
<a class="hl" name="80" href="#80">80</a>		} <b>catch</b> (<a href="/source/s?defs=ParserConfigurationException&amp;project=rtmp_client">ParserConfigurationException</a> <a href="/source/s?defs=pce&amp;project=rtmp_client">pce</a>) {
<a class="l" name="81" href="#81">81</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Could not parse XML file."</span>, <a href="/source/s?defs=pce&amp;project=rtmp_client">pce</a>);
<a class="l" name="82" href="#82">82</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="83" href="#83">83</a>		} <b>catch</b> (<a href="/source/s?defs=SAXException&amp;project=rtmp_client">SAXException</a> <a href="/source/s?defs=se&amp;project=rtmp_client">se</a>) {
<a class="l" name="84" href="#84">84</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Could not parse XML file."</span>, <a href="/source/s?defs=se&amp;project=rtmp_client">se</a>);
<a class="l" name="85" href="#85">85</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="86" href="#86">86</a>		} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> <a href="/source/s?defs=ioe&amp;project=rtmp_client">ioe</a>) {
<a class="l" name="87" href="#87">87</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Could not parse XML file."</span>, <a href="/source/s?defs=ioe&amp;project=rtmp_client">ioe</a>);
<a class="l" name="88" href="#88">88</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="89" href="#89">89</a>		}
<a class="hl" name="90" href="#90">90</a>
<a class="l" name="91" href="#91">91</a>		<a href="/source/s?defs=Element&amp;project=rtmp_client">Element</a> <a href="/source/s?defs=root&amp;project=rtmp_client">root</a> = <a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=getDocumentElement&amp;project=rtmp_client">getDocumentElement</a>();
<a class="l" name="92" href="#92">92</a>		<span class="c">// Check if .xml file is valid and for this .flv file</span>
<a class="l" name="93" href="#93">93</a>		<b>if</b> (!<span class="s">"FrameMetadata"</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=root&amp;project=rtmp_client">root</a>.<a href="/source/s?defs=getNodeName&amp;project=rtmp_client">getNodeName</a>())) {
<a class="l" name="94" href="#94">94</a>			<span class="c">// Invalid XML</span>
<a class="l" name="95" href="#95">95</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="96" href="#96">96</a>		}
<a class="l" name="97" href="#97">97</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=modified&amp;project=rtmp_client">modified</a> = <a href="/source/s?defs=root&amp;project=rtmp_client">root</a>.<a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<span class="s">"modified"</span>);
<a class="l" name="98" href="#98">98</a>		<b>if</b> (<a href="/source/s?defs=modified&amp;project=rtmp_client">modified</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> || !<a href="/source/s?defs=modified&amp;project=rtmp_client">modified</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=file&amp;project=rtmp_client">file</a>.<a href="/source/s?defs=lastModified&amp;project=rtmp_client">lastModified</a>()))) {
<a class="l" name="99" href="#99">99</a>			<span class="c">// File has changed in the meantime</span>
<a class="hl" name="100" href="#100">100</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="101" href="#101">101</a>		}
<a class="l" name="102" href="#102">102</a>		<b>if</b> (!<a href="/source/s?defs=root&amp;project=rtmp_client">root</a>.<a href="/source/s?defs=hasAttribute&amp;project=rtmp_client">hasAttribute</a>(<span class="s">"duration"</span>)) {
<a class="l" name="103" href="#103">103</a>			<span class="c">// Old file without duration informations</span>
<a class="l" name="104" href="#104">104</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="105" href="#105">105</a>		}
<a class="l" name="106" href="#106">106</a>		<b>if</b> (!<a href="/source/s?defs=root&amp;project=rtmp_client">root</a>.<a href="/source/s?defs=hasAttribute&amp;project=rtmp_client">hasAttribute</a>(<span class="s">"audioOnly"</span>)) {
<a class="l" name="107" href="#107">107</a>			<span class="c">// Old file without <a href="/source/s?path=audio/">audio</a>/<a href="/source/s?path=audio/video">video</a> informations</span>
<a class="l" name="108" href="#108">108</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="109" href="#109">109</a>		}
<a class="hl" name="110" href="#110">110</a>		<a href="/source/s?defs=XPathFactory&amp;project=rtmp_client">XPathFactory</a> <a href="/source/s?defs=factory&amp;project=rtmp_client">factory</a> = <a href="/source/s?defs=XPathFactory&amp;project=rtmp_client">XPathFactory</a>.<a href="/source/s?defs=newInstance&amp;project=rtmp_client">newInstance</a>();
<a class="l" name="111" href="#111">111</a>        <a href="/source/s?defs=XPath&amp;project=rtmp_client">XPath</a> <a href="/source/s?defs=xpath&amp;project=rtmp_client">xpath</a> = <a href="/source/s?defs=factory&amp;project=rtmp_client">factory</a>.<a href="/source/s?defs=newXPath&amp;project=rtmp_client">newXPath</a>();
<a class="l" name="112" href="#112">112</a>        <a href="/source/s?defs=NodeList&amp;project=rtmp_client">NodeList</a> <a href="/source/s?defs=keyFrames&amp;project=rtmp_client">keyFrames</a>;
<a class="l" name="113" href="#113">113</a>        <b>try</b> {
<a class="l" name="114" href="#114">114</a>            <a href="/source/s?defs=XPathExpression&amp;project=rtmp_client">XPathExpression</a> <a href="/source/s?defs=xexpr&amp;project=rtmp_client">xexpr</a> = <a href="/source/s?defs=xpath&amp;project=rtmp_client">xpath</a>.<a href="/source/s?defs=compile&amp;project=rtmp_client">compile</a>(<span class="s">"/<a href="/source/s?path=/FrameMetadata/">FrameMetadata</a>/<a href="/source/s?path=/FrameMetadata/KeyFrame">KeyFrame</a>"</span>);
<a class="l" name="115" href="#115">115</a>            <a href="/source/s?defs=keyFrames&amp;project=rtmp_client">keyFrames</a> = (<a href="/source/s?defs=NodeList&amp;project=rtmp_client">NodeList</a>) <a href="/source/s?defs=xexpr&amp;project=rtmp_client">xexpr</a>.<a href="/source/s?defs=evaluate&amp;project=rtmp_client">evaluate</a>(<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>, <a href="/source/s?defs=XPathConstants&amp;project=rtmp_client">XPathConstants</a>.<a href="/source/s?defs=NODESET&amp;project=rtmp_client">NODESET</a>);
<a class="l" name="116" href="#116">116</a>        } <b>catch</b> (<a href="/source/s?defs=XPathExpressionException&amp;project=rtmp_client">XPathExpressionException</a> <a href="/source/s?defs=err&amp;project=rtmp_client">err</a>) {
<a class="l" name="117" href="#117">117</a>        	<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"could not compile xpath expression"</span>, <a href="/source/s?defs=err&amp;project=rtmp_client">err</a>);
<a class="l" name="118" href="#118">118</a>        	<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="119" href="#119">119</a>        }
<a class="hl" name="120" href="#120">120</a>
<a class="l" name="121" href="#121">121</a>        <b>int</b> <a href="/source/s?defs=length&amp;project=rtmp_client">length</a> = <a href="/source/s?defs=keyFrames&amp;project=rtmp_client">keyFrames</a>.<a href="/source/s?defs=getLength&amp;project=rtmp_client">getLength</a>();
<a class="l" name="122" href="#122">122</a>        <b>if</b> (<a href="/source/s?defs=keyFrames&amp;project=rtmp_client">keyFrames</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> || <a href="/source/s?defs=length&amp;project=rtmp_client">length</a> == <span class="n">0</span>) {
<a class="l" name="123" href="#123">123</a>        	<span class="c">// File doesn't contain informations about keyframes</span>
<a class="l" name="124" href="#124">124</a>        	<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="125" href="#125">125</a>        }
<a class="l" name="126" href="#126">126</a>
<a class="l" name="127" href="#127">127</a>        <a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>new</b> <a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a>();
<a class="l" name="128" href="#128">128</a>        <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=duration&amp;project=rtmp_client">duration</a> = <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>.<a href="/source/s?defs=parseLong&amp;project=rtmp_client">parseLong</a>(<a href="/source/s?defs=root&amp;project=rtmp_client">root</a>.<a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<span class="s">"duration"</span>));
<a class="l" name="129" href="#129">129</a>        <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a> = <b>new</b> <b>long</b>[<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>];
<a class="hl" name="130" href="#130">130</a>        <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=timestamps&amp;project=rtmp_client">timestamps</a> = <b>new</b> <b>int</b>[<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>];
<a class="l" name="131" href="#131">131</a>		<b>for</b> (<b>int</b> i=<span class="n">0</span>; i&lt;<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>; i++) {
<a class="l" name="132" href="#132">132</a>			<a href="/source/s?defs=Node&amp;project=rtmp_client">Node</a> <a href="/source/s?defs=node&amp;project=rtmp_client">node</a> = <a href="/source/s?defs=keyFrames&amp;project=rtmp_client">keyFrames</a>.<a href="/source/s?defs=item&amp;project=rtmp_client">item</a>(i);
<a class="l" name="133" href="#133">133</a>			<a href="/source/s?defs=NamedNodeMap&amp;project=rtmp_client">NamedNodeMap</a> <a href="/source/s?defs=attrs&amp;project=rtmp_client">attrs</a> = <a href="/source/s?defs=node&amp;project=rtmp_client">node</a>.<a href="/source/s?defs=getAttributes&amp;project=rtmp_client">getAttributes</a>();
<a class="l" name="134" href="#134">134</a>			<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a>[i] = <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>.<a href="/source/s?defs=parseLong&amp;project=rtmp_client">parseLong</a>(<a href="/source/s?defs=attrs&amp;project=rtmp_client">attrs</a>.<a href="/source/s?defs=getNamedItem&amp;project=rtmp_client">getNamedItem</a>(<span class="s">"position"</span>).<a href="/source/s?defs=getNodeValue&amp;project=rtmp_client">getNodeValue</a>());
<a class="l" name="135" href="#135">135</a>			<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=timestamps&amp;project=rtmp_client">timestamps</a>[i] = <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=parseInt&amp;project=rtmp_client">parseInt</a>(<a href="/source/s?defs=attrs&amp;project=rtmp_client">attrs</a>.<a href="/source/s?defs=getNamedItem&amp;project=rtmp_client">getNamedItem</a>(<span class="s">"timestamp"</span>).<a href="/source/s?defs=getNodeValue&amp;project=rtmp_client">getNodeValue</a>());
<a class="l" name="136" href="#136">136</a>		}
<a class="l" name="137" href="#137">137</a>		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=audioOnly&amp;project=rtmp_client">audioOnly</a> = <span class="s">"true"</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=root&amp;project=rtmp_client">root</a>.<a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<span class="s">"audioOnly"</span>));
<a class="l" name="138" href="#138">138</a>
<a class="l" name="139" href="#139">139</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="hl" name="140" href="#140">140</a>	}
<a class="l" name="141" href="#141">141</a>
<a class="l" name="142" href="#142">142</a>    <span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="143" href="#143">143</a>	<b>public</b> <b>void</b> <a class="xmt" name="saveKeyFrameMeta"/><a href="/source/s?refs=saveKeyFrameMeta&amp;project=rtmp_client" class="xmt">saveKeyFrameMeta</a>(<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a class="xa" name="file"/><a href="/source/s?refs=file&amp;project=rtmp_client" class="xa">file</a>, <a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a> <a class="xa" name="meta"/><a href="/source/s?refs=meta&amp;project=rtmp_client" class="xa">meta</a>) {
<a class="l" name="144" href="#144">144</a>		<b>if</b> (<a class="d" href="#meta">meta</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> == <span class="n">0</span>) {
<a class="l" name="145" href="#145">145</a>			<span class="c">// Don't store empty meta informations</span>
<a class="l" name="146" href="#146">146</a>			<b>return</b>;
<a class="l" name="147" href="#147">147</a>		}
<a class="l" name="148" href="#148">148</a>
<a class="l" name="149" href="#149">149</a>		<a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a> <a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>;
<a class="hl" name="150" href="#150">150</a>		<a href="/source/s?defs=DocumentBuilderFactory&amp;project=rtmp_client">DocumentBuilderFactory</a> <a href="/source/s?defs=dbf&amp;project=rtmp_client">dbf</a> = <a href="/source/s?defs=DocumentBuilderFactory&amp;project=rtmp_client">DocumentBuilderFactory</a>.<a href="/source/s?defs=newInstance&amp;project=rtmp_client">newInstance</a>();
<a class="l" name="151" href="#151">151</a>		<b>try</b> {
<a class="l" name="152" href="#152">152</a>			<span class="c">//get an instance of builder</span>
<a class="l" name="153" href="#153">153</a>			<a href="/source/s?defs=DocumentBuilder&amp;project=rtmp_client">DocumentBuilder</a> <a href="/source/s?defs=db&amp;project=rtmp_client">db</a> = <a href="/source/s?defs=dbf&amp;project=rtmp_client">dbf</a>.<a href="/source/s?defs=newDocumentBuilder&amp;project=rtmp_client">newDocumentBuilder</a>();
<a class="l" name="154" href="#154">154</a>			<span class="c">//create an instance of DOM</span>
<a class="l" name="155" href="#155">155</a>			<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a> = <a href="/source/s?defs=db&amp;project=rtmp_client">db</a>.<a href="/source/s?defs=newDocument&amp;project=rtmp_client">newDocument</a>();
<a class="l" name="156" href="#156">156</a>		} <b>catch</b> (<a href="/source/s?defs=ParserConfigurationException&amp;project=rtmp_client">ParserConfigurationException</a> <a href="/source/s?defs=pce&amp;project=rtmp_client">pce</a>) {
<a class="l" name="157" href="#157">157</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error while creating document."</span>, <a href="/source/s?defs=pce&amp;project=rtmp_client">pce</a>);
<a class="l" name="158" href="#158">158</a>			<b>return</b>;
<a class="l" name="159" href="#159">159</a>		}
<a class="hl" name="160" href="#160">160</a>
<a class="l" name="161" href="#161">161</a>		<span class="c">// Create file and add keyframe informations</span>
<a class="l" name="162" href="#162">162</a>		<a href="/source/s?defs=Element&amp;project=rtmp_client">Element</a> <a href="/source/s?defs=root&amp;project=rtmp_client">root</a> = <a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=createElement&amp;project=rtmp_client">createElement</a>(<span class="s">"FrameMetadata"</span>);
<a class="l" name="163" href="#163">163</a>		<a href="/source/s?defs=root&amp;project=rtmp_client">root</a>.<a href="/source/s?defs=setAttribute&amp;project=rtmp_client">setAttribute</a>(<span class="s">"modified"</span>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=file&amp;project=rtmp_client">file</a>.<a href="/source/s?defs=lastModified&amp;project=rtmp_client">lastModified</a>()));
<a class="l" name="164" href="#164">164</a>		<a href="/source/s?defs=root&amp;project=rtmp_client">root</a>.<a href="/source/s?defs=setAttribute&amp;project=rtmp_client">setAttribute</a>(<span class="s">"duration"</span>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a class="d" href="#meta">meta</a>.<a href="/source/s?defs=duration&amp;project=rtmp_client">duration</a>));
<a class="l" name="165" href="#165">165</a>		<a href="/source/s?defs=root&amp;project=rtmp_client">root</a>.<a href="/source/s?defs=setAttribute&amp;project=rtmp_client">setAttribute</a>(<span class="s">"audioOnly"</span>, <a class="d" href="#meta">meta</a>.<a href="/source/s?defs=audioOnly&amp;project=rtmp_client">audioOnly</a> ? <span class="s">"true"</span> : <span class="s">"false"</span>);
<a class="l" name="166" href="#166">166</a>		<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=appendChild&amp;project=rtmp_client">appendChild</a>(<a href="/source/s?defs=root&amp;project=rtmp_client">root</a>);
<a class="l" name="167" href="#167">167</a>
<a class="l" name="168" href="#168">168</a>		<b>for</b> (<b>int</b> i=<span class="n">0</span>; i&lt;<a class="d" href="#meta">meta</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>; i++) {
<a class="l" name="169" href="#169">169</a>			<a href="/source/s?defs=Element&amp;project=rtmp_client">Element</a> <a href="/source/s?defs=node&amp;project=rtmp_client">node</a> = <a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=createElement&amp;project=rtmp_client">createElement</a>(<span class="s">"KeyFrame"</span>);
<a class="hl" name="170" href="#170">170</a>			<a href="/source/s?defs=node&amp;project=rtmp_client">node</a>.<a href="/source/s?defs=setAttribute&amp;project=rtmp_client">setAttribute</a>(<span class="s">"position"</span>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a class="d" href="#meta">meta</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a>[i]));
<a class="l" name="171" href="#171">171</a>			<a href="/source/s?defs=node&amp;project=rtmp_client">node</a>.<a href="/source/s?defs=setAttribute&amp;project=rtmp_client">setAttribute</a>(<span class="s">"timestamp"</span>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a class="d" href="#meta">meta</a>.<a href="/source/s?defs=timestamps&amp;project=rtmp_client">timestamps</a>[i]));
<a class="l" name="172" href="#172">172</a>			<a href="/source/s?defs=root&amp;project=rtmp_client">root</a>.<a href="/source/s?defs=appendChild&amp;project=rtmp_client">appendChild</a>(<a href="/source/s?defs=node&amp;project=rtmp_client">node</a>);
<a class="l" name="173" href="#173">173</a>		}
<a class="l" name="174" href="#174">174</a>
<a class="l" name="175" href="#175">175</a><span class="c">//		String filename = file.getAbsolutePath() + ".meta";</span>
<a class="l" name="176" href="#176">176</a>
<a class="l" name="177" href="#177">177</a><span class="c">//		OutputFormat format = new OutputFormat(dom);</span>
<a class="l" name="178" href="#178">178</a><span class="c">//		format.setIndenting(true);</span>
<a class="l" name="179" href="#179">179</a><span class="c">//</span>
<a class="hl" name="180" href="#180">180</a><span class="c">//		try {</span>
<a class="l" name="181" href="#181">181</a><span class="c">//			XMLSerializer serializer = new XMLSerializer(</span>
<a class="l" name="182" href="#182">182</a><span class="c">//				new FileOutputStream(new File(filename)), format);</span>
<a class="l" name="183" href="#183">183</a><span class="c">//			serializer.serialize(dom);</span>
<a class="l" name="184" href="#184">184</a><span class="c">//		} catch (IOException err) {</span>
<a class="l" name="185" href="#185">185</a><span class="c">//			log.error("could not save keyframe data", err);</span>
<a class="l" name="186" href="#186">186</a><span class="c">//		}</span>
<a class="l" name="187" href="#187">187</a>	}
<a class="l" name="188" href="#188">188</a>
<a class="l" name="189" href="#189">189</a>}
<a class="hl" name="190" href="#190">190</a>