<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["MetaService",47]]],["Package","xp",[["org.red5.io.flv",1]]],["Method","xmt",[["MetaService",97],["MetaService",101],["getDeserializer",69],["getFile",318],["getSerializer",83],["getTimeInMilliseconds",290],["injectMetaCue",266],["injectMetaData",240],["mergeMeta",180],["readMetaCue",345],["readMetaData",331],["setDeserializer",76],["setFile",325],["setSerializer",90],["write",109],["writeMetaCue",311],["writeMetaData",298]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=File&amp;project=rtmp_client">File</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Arrays&amp;project=rtmp_client">Arrays</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>.<a href="/source/s?defs=Entry&amp;project=rtmp_client">Entry</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>;
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>;
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>;
<a class="l" name="34" href="#34">34</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>;
<a class="l" name="35" href="#35">35</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a>;
<a class="l" name="36" href="#36">36</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>;
<a class="l" name="37" href="#37">37</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="38" href="#38">38</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="39" href="#39">39</a>
<a class="hl" name="40" href="#40">40</a><span class="c">/**
<a class="l" name="41" href="#41">41</a> * MetaService represents a MetaData service in Spring
<a class="l" name="42" href="#42">42</a> *
<a class="l" name="43" href="#43">43</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="44" href="#44">44</a> * <strong>@author</strong> Dominick Accattato (daccattato@gmail.com)
<a class="l" name="45" href="#45">45</a> * <strong>@author</strong> Luke Hubbard, Codegent Ltd (luke@codegent.com)
<a class="l" name="46" href="#46">46</a> */</span>
<a class="l" name="47" href="#47">47</a><b>public</b> <b>class</b> <a class="xc" name="MetaService"/><a href="/source/s?refs=MetaService&amp;project=rtmp_client" class="xc">MetaService</a> <b>implements</b> <a href="/source/s?defs=IMetaService&amp;project=rtmp_client">IMetaService</a> {
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>	<b>protected</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a href="/source/s?defs=MetaService&amp;project=rtmp_client">MetaService</a>.<b>class</b>);
<a class="hl" name="50" href="#50">50</a>
<a class="l" name="51" href="#51">51</a>	<span class="c">/**
<a class="l" name="52" href="#52">52</a>	 * Source file
<a class="l" name="53" href="#53">53</a>	 */</span>
<a class="l" name="54" href="#54">54</a>	<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a class="xfld" name="file"/><a href="/source/s?refs=file&amp;project=rtmp_client" class="xfld">file</a>;
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a>	<span class="c">/**
<a class="l" name="57" href="#57">57</a>	 * Serializer
<a class="l" name="58" href="#58">58</a>	 */</span>
<a class="l" name="59" href="#59">59</a>	<b>private</b> <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xfld" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xfld">serializer</a>;
<a class="hl" name="60" href="#60">60</a>
<a class="l" name="61" href="#61">61</a>	<span class="c">/**
<a class="l" name="62" href="#62">62</a>	 * Deserializer
<a class="l" name="63" href="#63">63</a>	 */</span>
<a class="l" name="64" href="#64">64</a>	<b>private</b> <a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xfld" name="deserializer"/><a href="/source/s?refs=deserializer&amp;project=rtmp_client" class="xfld">deserializer</a>;
<a class="l" name="65" href="#65">65</a>
<a class="l" name="66" href="#66">66</a>	<span class="c">/**
<a class="l" name="67" href="#67">67</a>	 * <strong>@return</strong> Returns the deserializer.
<a class="l" name="68" href="#68">68</a>	 */</span>
<a class="l" name="69" href="#69">69</a>	<b>public</b> <a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xmt" name="getDeserializer"/><a href="/source/s?refs=getDeserializer&amp;project=rtmp_client" class="xmt">getDeserializer</a>() {
<a class="hl" name="70" href="#70">70</a>		<b>return</b> <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>;
<a class="l" name="71" href="#71">71</a>	}
<a class="l" name="72" href="#72">72</a>
<a class="l" name="73" href="#73">73</a>	<span class="c">/**
<a class="l" name="74" href="#74">74</a>	 * <strong>@param</strong> <em>deserializer</em> The deserializer to set.
<a class="l" name="75" href="#75">75</a>	 */</span>
<a class="l" name="76" href="#76">76</a>	<b>public</b> <b>void</b> <a class="xmt" name="setDeserializer"/><a href="/source/s?refs=setDeserializer&amp;project=rtmp_client" class="xmt">setDeserializer</a>(<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xa" name="deserializer"/><a href="/source/s?refs=deserializer&amp;project=rtmp_client" class="xa">deserializer</a>) {
<a class="l" name="77" href="#77">77</a>		<b>this</b>.<a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>;
<a class="l" name="78" href="#78">78</a>	}
<a class="l" name="79" href="#79">79</a>
<a class="hl" name="80" href="#80">80</a>	<span class="c">/**
<a class="l" name="81" href="#81">81</a>	 * <strong>@return</strong> Returns the serializer.
<a class="l" name="82" href="#82">82</a>	 */</span>
<a class="l" name="83" href="#83">83</a>	<b>public</b> <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xmt" name="getSerializer"/><a href="/source/s?refs=getSerializer&amp;project=rtmp_client" class="xmt">getSerializer</a>() {
<a class="l" name="84" href="#84">84</a>		<b>return</b> <a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>;
<a class="l" name="85" href="#85">85</a>	}
<a class="l" name="86" href="#86">86</a>
<a class="l" name="87" href="#87">87</a>	<span class="c">/**
<a class="l" name="88" href="#88">88</a>	 * <strong>@param</strong> <em>serializer</em> The serializer to set.
<a class="l" name="89" href="#89">89</a>	 */</span>
<a class="hl" name="90" href="#90">90</a>	<b>public</b> <b>void</b> <a class="xmt" name="setSerializer"/><a href="/source/s?refs=setSerializer&amp;project=rtmp_client" class="xmt">setSerializer</a>(<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xa" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xa">serializer</a>) {
<a class="l" name="91" href="#91">91</a>		<b>this</b>.<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a> = <a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>;
<a class="l" name="92" href="#92">92</a>	}
<a class="l" name="93" href="#93">93</a>
<a class="l" name="94" href="#94">94</a>	<span class="c">/**
<a class="l" name="95" href="#95">95</a>	 * MetaService constructor
<a class="l" name="96" href="#96">96</a>	 */</span>
<a class="l" name="97" href="#97">97</a>	<b>public</b> <a class="xmt" name="MetaService"/><a href="/source/s?refs=MetaService&amp;project=rtmp_client" class="xmt">MetaService</a>() {
<a class="l" name="98" href="#98">98</a>		<b>super</b>();
<a class="l" name="99" href="#99">99</a>	}
<a class="hl" name="100" href="#100">100</a>
<a class="l" name="101" href="#101">101</a>	<b>public</b> <a class="xmt" name="MetaService"/><a href="/source/s?refs=MetaService&amp;project=rtmp_client" class="xmt">MetaService</a>(<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a class="xa" name="poFil"/><a href="/source/s?refs=poFil&amp;project=rtmp_client" class="xa">poFil</a>) {
<a class="l" name="102" href="#102">102</a>		<b>this</b>();
<a class="l" name="103" href="#103">103</a>		<b>this</b>.<a href="/source/s?defs=file&amp;project=rtmp_client">file</a> = <a class="d" href="#poFil">poFil</a>;
<a class="l" name="104" href="#104">104</a>	}
<a class="l" name="105" href="#105">105</a>
<a class="l" name="106" href="#106">106</a>	<span class="c">/**
<a class="l" name="107" href="#107">107</a>	 * {<strong>@inheritDoc</strong>}
<a class="l" name="108" href="#108">108</a>	 */</span>
<a class="l" name="109" href="#109">109</a>	<b>public</b> <b>void</b> <a class="xmt" name="write"/><a href="/source/s?refs=write&amp;project=rtmp_client" class="xmt">write</a>(<a href="/source/s?defs=IMetaData&amp;project=rtmp_client">IMetaData</a>&lt;?, ?&gt; <a class="xa" name="meta"/><a href="/source/s?refs=meta&amp;project=rtmp_client" class="xa">meta</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="hl" name="110" href="#110">110</a>		<span class="c">// Get cue points, FLV reader and writer</span>
<a class="l" name="111" href="#111">111</a>		<a href="/source/s?defs=IMetaCue&amp;project=rtmp_client">IMetaCue</a>[] <a href="/source/s?defs=metaArr&amp;project=rtmp_client">metaArr</a> = <a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a>.<a href="/source/s?defs=getMetaCue&amp;project=rtmp_client">getMetaCue</a>();
<a class="l" name="112" href="#112">112</a>		<a href="/source/s?defs=FLVReader&amp;project=rtmp_client">FLVReader</a> <a href="/source/s?defs=reader&amp;project=rtmp_client">reader</a> = <b>new</b> <a href="/source/s?defs=FLVReader&amp;project=rtmp_client">FLVReader</a>(<a href="/source/s?defs=file&amp;project=rtmp_client">file</a>, <b>false</b>);
<a class="l" name="113" href="#113">113</a>		<a href="/source/s?defs=FLVWriter&amp;project=rtmp_client">FLVWriter</a> <a href="/source/s?defs=writer&amp;project=rtmp_client">writer</a> = <b>new</b> <a href="/source/s?defs=FLVWriter&amp;project=rtmp_client">FLVWriter</a>(<a href="/source/s?defs=file&amp;project=rtmp_client">file</a>, <b>false</b>);
<a class="l" name="114" href="#114">114</a>		<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="115" href="#115">115</a>		<span class="c">// Read first tag</span>
<a class="l" name="116" href="#116">116</a>		<b>if</b> (<a href="/source/s?defs=reader&amp;project=rtmp_client">reader</a>.<a href="/source/s?defs=hasMoreTags&amp;project=rtmp_client">hasMoreTags</a>()) {
<a class="l" name="117" href="#117">117</a>			<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a> = <a href="/source/s?defs=reader&amp;project=rtmp_client">reader</a>.<a href="/source/s?defs=readTag&amp;project=rtmp_client">readTag</a>();
<a class="l" name="118" href="#118">118</a>			<b>if</b> (<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>() == <a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=TYPE_METADATA&amp;project=rtmp_client">TYPE_METADATA</a>) {
<a class="l" name="119" href="#119">119</a>				<b>if</b> (!<a href="/source/s?defs=reader&amp;project=rtmp_client">reader</a>.<a href="/source/s?defs=hasMoreTags&amp;project=rtmp_client">hasMoreTags</a>()) {
<a class="hl" name="120" href="#120">120</a>					<b>throw</b> <b>new</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>(<span class="s">"File we're writing is metadata only?"</span>);
<a class="l" name="121" href="#121">121</a>				}
<a class="l" name="122" href="#122">122</a>			}
<a class="l" name="123" href="#123">123</a>		}
<a class="l" name="124" href="#124">124</a>		<b>if</b> (<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="125" href="#125">125</a>			<b>throw</b> <b>new</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>(<span class="s">"Tag was null"</span>);
<a class="l" name="126" href="#126">126</a>		}
<a class="l" name="127" href="#127">127</a>		<a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a>.<a href="/source/s?defs=setDuration&amp;project=rtmp_client">setDuration</a>(((<b>double</b>) <a href="/source/s?defs=reader&amp;project=rtmp_client">reader</a>.<a href="/source/s?defs=getDuration&amp;project=rtmp_client">getDuration</a>() / <span class="n">1000</span>));
<a class="l" name="128" href="#128">128</a>		<a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a>.<a href="/source/s?defs=setVideoCodecId&amp;project=rtmp_client">setVideoCodecId</a>(<a href="/source/s?defs=reader&amp;project=rtmp_client">reader</a>.<a href="/source/s?defs=getVideoCodecId&amp;project=rtmp_client">getVideoCodecId</a>());
<a class="l" name="129" href="#129">129</a>		<a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a>.<a href="/source/s?defs=setAudioCodecId&amp;project=rtmp_client">setAudioCodecId</a>(<a href="/source/s?defs=reader&amp;project=rtmp_client">reader</a>.<a href="/source/s?defs=getAudioCodecId&amp;project=rtmp_client">getAudioCodecId</a>());
<a class="hl" name="130" href="#130">130</a>
<a class="l" name="131" href="#131">131</a>		<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a href="/source/s?defs=injectedTag&amp;project=rtmp_client">injectedTag</a> = <a class="d" href="#injectMetaData">injectMetaData</a>(<a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a>, <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>);
<a class="l" name="132" href="#132">132</a>		<a href="/source/s?defs=injectedTag&amp;project=rtmp_client">injectedTag</a>.<a href="/source/s?defs=setPreviousTagSize&amp;project=rtmp_client">setPreviousTagSize</a>(<span class="n">0</span>);
<a class="l" name="133" href="#133">133</a>		<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=setPreviousTagSize&amp;project=rtmp_client">setPreviousTagSize</a>(<a href="/source/s?defs=injectedTag&amp;project=rtmp_client">injectedTag</a>.<a href="/source/s?defs=getBodySize&amp;project=rtmp_client">getBodySize</a>());
<a class="l" name="134" href="#134">134</a>
<a class="l" name="135" href="#135">135</a>		<a href="/source/s?defs=writer&amp;project=rtmp_client">writer</a>.<a href="/source/s?defs=writeTag&amp;project=rtmp_client">writeTag</a>(<a href="/source/s?defs=injectedTag&amp;project=rtmp_client">injectedTag</a>);
<a class="l" name="136" href="#136">136</a>		<a href="/source/s?defs=writer&amp;project=rtmp_client">writer</a>.<a href="/source/s?defs=writeTag&amp;project=rtmp_client">writeTag</a>(<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>);
<a class="l" name="137" href="#137">137</a>
<a class="l" name="138" href="#138">138</a>		<b>int</b> <a href="/source/s?defs=cuePointTimeStamp&amp;project=rtmp_client">cuePointTimeStamp</a> = <span class="n">0</span>;
<a class="l" name="139" href="#139">139</a>		<b>int</b> <a href="/source/s?defs=counter&amp;project=rtmp_client">counter</a> = <span class="n">0</span>;
<a class="hl" name="140" href="#140">140</a>
<a class="l" name="141" href="#141">141</a>		<b>if</b> (<a href="/source/s?defs=metaArr&amp;project=rtmp_client">metaArr</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="142" href="#142">142</a>			<a href="/source/s?defs=Arrays&amp;project=rtmp_client">Arrays</a>.<a href="/source/s?defs=sort&amp;project=rtmp_client">sort</a>(<a href="/source/s?defs=metaArr&amp;project=rtmp_client">metaArr</a>);
<a class="l" name="143" href="#143">143</a>			<a href="/source/s?defs=cuePointTimeStamp&amp;project=rtmp_client">cuePointTimeStamp</a> = <a class="d" href="#getTimeInMilliseconds">getTimeInMilliseconds</a>(<a href="/source/s?defs=metaArr&amp;project=rtmp_client">metaArr</a>[<span class="n">0</span>]);
<a class="l" name="144" href="#144">144</a>		}
<a class="l" name="145" href="#145">145</a>		<b>while</b> (<a href="/source/s?defs=reader&amp;project=rtmp_client">reader</a>.<a href="/source/s?defs=hasMoreTags&amp;project=rtmp_client">hasMoreTags</a>()) {
<a class="l" name="146" href="#146">146</a>			<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a> = <a href="/source/s?defs=reader&amp;project=rtmp_client">reader</a>.<a href="/source/s?defs=readTag&amp;project=rtmp_client">readTag</a>();
<a class="l" name="147" href="#147">147</a>			<span class="c">// if there are cuePoints in the array</span>
<a class="l" name="148" href="#148">148</a>			<b>if</b> (<a href="/source/s?defs=counter&amp;project=rtmp_client">counter</a> &lt; <a href="/source/s?defs=metaArr&amp;project=rtmp_client">metaArr</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>) {
<a class="l" name="149" href="#149">149</a>				<span class="c">// If the tag has a greater timestamp than the</span>
<a class="hl" name="150" href="#150">150</a>				<span class="c">// cuePointTimeStamp, then inject the tag</span>
<a class="l" name="151" href="#151">151</a>				<b>while</b> (<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getTimestamp&amp;project=rtmp_client">getTimestamp</a>() &gt; <a href="/source/s?defs=cuePointTimeStamp&amp;project=rtmp_client">cuePointTimeStamp</a>) {
<a class="l" name="152" href="#152">152</a>					<a href="/source/s?defs=injectedTag&amp;project=rtmp_client">injectedTag</a> = <a class="d" href="#injectMetaCue">injectMetaCue</a>(<a href="/source/s?defs=metaArr&amp;project=rtmp_client">metaArr</a>[<a href="/source/s?defs=counter&amp;project=rtmp_client">counter</a>], <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>);
<a class="l" name="153" href="#153">153</a>					<a href="/source/s?defs=writer&amp;project=rtmp_client">writer</a>.<a href="/source/s?defs=writeTag&amp;project=rtmp_client">writeTag</a>(<a href="/source/s?defs=injectedTag&amp;project=rtmp_client">injectedTag</a>);
<a class="l" name="154" href="#154">154</a>					<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=setPreviousTagSize&amp;project=rtmp_client">setPreviousTagSize</a>(<a href="/source/s?defs=injectedTag&amp;project=rtmp_client">injectedTag</a>.<a href="/source/s?defs=getBodySize&amp;project=rtmp_client">getBodySize</a>());
<a class="l" name="155" href="#155">155</a>					<span class="c">// Advance to the next CuePoint</span>
<a class="l" name="156" href="#156">156</a>					<a href="/source/s?defs=counter&amp;project=rtmp_client">counter</a>++;
<a class="l" name="157" href="#157">157</a>					<b>if</b> (<a href="/source/s?defs=counter&amp;project=rtmp_client">counter</a> &gt; (<a href="/source/s?defs=metaArr&amp;project=rtmp_client">metaArr</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> - <span class="n">1</span>)) {
<a class="l" name="158" href="#158">158</a>						<b>break</b>;
<a class="l" name="159" href="#159">159</a>					}
<a class="hl" name="160" href="#160">160</a>					<a href="/source/s?defs=cuePointTimeStamp&amp;project=rtmp_client">cuePointTimeStamp</a> = <a class="d" href="#getTimeInMilliseconds">getTimeInMilliseconds</a>(<a href="/source/s?defs=metaArr&amp;project=rtmp_client">metaArr</a>[<a href="/source/s?defs=counter&amp;project=rtmp_client">counter</a>]);
<a class="l" name="161" href="#161">161</a>				}
<a class="l" name="162" href="#162">162</a>			}
<a class="l" name="163" href="#163">163</a>			<b>if</b> (<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>() != <a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=TYPE_METADATA&amp;project=rtmp_client">TYPE_METADATA</a>) {
<a class="l" name="164" href="#164">164</a>				<a href="/source/s?defs=writer&amp;project=rtmp_client">writer</a>.<a href="/source/s?defs=writeTag&amp;project=rtmp_client">writeTag</a>(<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>);
<a class="l" name="165" href="#165">165</a>			}
<a class="l" name="166" href="#166">166</a>		}
<a class="l" name="167" href="#167">167</a>		<a href="/source/s?defs=writer&amp;project=rtmp_client">writer</a>.<a href="/source/s?defs=close&amp;project=rtmp_client">close</a>();
<a class="l" name="168" href="#168">168</a>	}
<a class="l" name="169" href="#169">169</a>
<a class="hl" name="170" href="#170">170</a>	<span class="c">/**
<a class="l" name="171" href="#171">171</a>	 * Merges the two Meta objects
<a class="l" name="172" href="#172">172</a>	 *
<a class="l" name="173" href="#173">173</a>	 * <strong>@param</strong> <em>metaData1</em>
<a class="l" name="174" href="#174">174</a>	 *            First metadata object
<a class="l" name="175" href="#175">175</a>	 * <strong>@param</strong> <em>metaData2</em>
<a class="l" name="176" href="#176">176</a>	 *            Second metadata object
<a class="l" name="177" href="#177">177</a>	 * <strong>@return</strong> Merged metadata
<a class="l" name="178" href="#178">178</a>	 */</span>
<a class="l" name="179" href="#179">179</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>({ <span class="s">"unchecked"</span> })
<a class="hl" name="180" href="#180">180</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=IMeta&amp;project=rtmp_client">IMeta</a> <a class="xmt" name="mergeMeta"/><a href="/source/s?refs=mergeMeta&amp;project=rtmp_client" class="xmt">mergeMeta</a>(<a href="/source/s?defs=IMetaData&amp;project=rtmp_client">IMetaData</a>&lt;?, ?&gt; <a class="xa" name="metaData1"/><a href="/source/s?refs=metaData1&amp;project=rtmp_client" class="xa">metaData1</a>, <a href="/source/s?defs=IMetaData&amp;project=rtmp_client">IMetaData</a>&lt;?, ?&gt; <a class="xa" name="metaData2"/><a href="/source/s?refs=metaData2&amp;project=rtmp_client" class="xa">metaData2</a>) {
<a class="l" name="181" href="#181">181</a>		<span class="c">//walk the entries and merge them</span>
<a class="l" name="182" href="#182">182</a>		<span class="c">//1. higher number values trump lower ones</span>
<a class="l" name="183" href="#183">183</a>		<span class="c">//2. true considered higher than false</span>
<a class="l" name="184" href="#184">184</a>		<span class="c">//3. strings are not replaced</span>
<a class="l" name="185" href="#185">185</a>		<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=map1&amp;project=rtmp_client">map1</a> = ((<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;) <a class="d" href="#metaData1">metaData1</a>);
<a class="l" name="186" href="#186">186</a>		<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>&lt;<a href="/source/s?defs=Entry&amp;project=rtmp_client">Entry</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;&gt; <a href="/source/s?defs=set1&amp;project=rtmp_client">set1</a> = <a href="/source/s?defs=map1&amp;project=rtmp_client">map1</a>.<a href="/source/s?defs=entrySet&amp;project=rtmp_client">entrySet</a>();
<a class="l" name="187" href="#187">187</a>		<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=map2&amp;project=rtmp_client">map2</a> = ((<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;) <a class="d" href="#metaData2">metaData2</a>);
<a class="l" name="188" href="#188">188</a>		<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>&lt;<a href="/source/s?defs=Entry&amp;project=rtmp_client">Entry</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;&gt; <a href="/source/s?defs=set2&amp;project=rtmp_client">set2</a> = <a href="/source/s?defs=map2&amp;project=rtmp_client">map2</a>.<a href="/source/s?defs=entrySet&amp;project=rtmp_client">entrySet</a>();
<a class="l" name="189" href="#189">189</a>		<span class="c">//map to hold updates / replacements</span>
<a class="hl" name="190" href="#190">190</a>		<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=rep&amp;project=rtmp_client">rep</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="l" name="191" href="#191">191</a>		<span class="c">//loop to update common elements</span>
<a class="l" name="192" href="#192">192</a>		<b>for</b> (<a href="/source/s?defs=Entry&amp;project=rtmp_client">Entry</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=entry1&amp;project=rtmp_client">entry1</a> : <a href="/source/s?defs=set1&amp;project=rtmp_client">set1</a>) {
<a class="l" name="193" href="#193">193</a>			<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=key1&amp;project=rtmp_client">key1</a> = <a href="/source/s?defs=entry1&amp;project=rtmp_client">entry1</a>.<a href="/source/s?defs=getKey&amp;project=rtmp_client">getKey</a>();
<a class="l" name="194" href="#194">194</a>			<b>if</b> (<a href="/source/s?defs=map2&amp;project=rtmp_client">map2</a>.<a href="/source/s?defs=containsKey&amp;project=rtmp_client">containsKey</a>(<a href="/source/s?defs=key1&amp;project=rtmp_client">key1</a>)) {
<a class="l" name="195" href="#195">195</a>				<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=value1&amp;project=rtmp_client">value1</a> = <a href="/source/s?defs=map1&amp;project=rtmp_client">map1</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=key1&amp;project=rtmp_client">key1</a>);
<a class="l" name="196" href="#196">196</a>				<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a> = <a href="/source/s?defs=map2&amp;project=rtmp_client">map2</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=key1&amp;project=rtmp_client">key1</a>);
<a class="l" name="197" href="#197">197</a>				<span class="c">//we dont replace strings</span>
<a class="l" name="198" href="#198">198</a>				<span class="c">//check numbers</span>
<a class="l" name="199" href="#199">199</a>				<b>if</b> (<a href="/source/s?defs=value1&amp;project=rtmp_client">value1</a> <b>instanceof</b> <a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>) {
<a class="hl" name="200" href="#200">200</a>					<b>if</b> (<a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=value1&amp;project=rtmp_client">value1</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>()).<a href="/source/s?defs=doubleValue&amp;project=rtmp_client">doubleValue</a>() &lt; <a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>()).<a href="/source/s?defs=doubleValue&amp;project=rtmp_client">doubleValue</a>()) {
<a class="l" name="201" href="#201">201</a>						<a href="/source/s?defs=rep&amp;project=rtmp_client">rep</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=key1&amp;project=rtmp_client">key1</a>, <a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a>);
<a class="l" name="202" href="#202">202</a>					}
<a class="l" name="203" href="#203">203</a>				} <b>else</b> <b>if</b> (<a href="/source/s?defs=value1&amp;project=rtmp_client">value1</a> <b>instanceof</b> <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>) {
<a class="l" name="204" href="#204">204</a>					<b>if</b> (<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=value1&amp;project=rtmp_client">value1</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>()).<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>() &lt; <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>()).<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>()) {
<a class="l" name="205" href="#205">205</a>						<a href="/source/s?defs=rep&amp;project=rtmp_client">rep</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=key1&amp;project=rtmp_client">key1</a>, <a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a>);
<a class="l" name="206" href="#206">206</a>					}
<a class="l" name="207" href="#207">207</a>				} <b>else</b> <b>if</b> (<a href="/source/s?defs=value1&amp;project=rtmp_client">value1</a> <b>instanceof</b> <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>) {
<a class="l" name="208" href="#208">208</a>					<b>if</b> (<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=value1&amp;project=rtmp_client">value1</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>()).<a href="/source/s?defs=longValue&amp;project=rtmp_client">longValue</a>() &lt; <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>()).<a href="/source/s?defs=longValue&amp;project=rtmp_client">longValue</a>()) {
<a class="l" name="209" href="#209">209</a>						<a href="/source/s?defs=rep&amp;project=rtmp_client">rep</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=key1&amp;project=rtmp_client">key1</a>, <a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a>);
<a class="hl" name="210" href="#210">210</a>					}
<a class="l" name="211" href="#211">211</a>				}
<a class="l" name="212" href="#212">212</a>				<span class="c">//check boolean</span>
<a class="l" name="213" href="#213">213</a>				<b>if</b> (<a href="/source/s?defs=value1&amp;project=rtmp_client">value1</a> <b>instanceof</b> <a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a>) {
<a class="l" name="214" href="#214">214</a>					<span class="c">//consider true &gt; false</span>
<a class="l" name="215" href="#215">215</a>					<b>if</b> (!<a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=value1&amp;project=rtmp_client">value1</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>()) &amp;&amp; <a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>())) {
<a class="l" name="216" href="#216">216</a>						<a href="/source/s?defs=rep&amp;project=rtmp_client">rep</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=key1&amp;project=rtmp_client">key1</a>, <a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a>);
<a class="l" name="217" href="#217">217</a>					}
<a class="l" name="218" href="#218">218</a>				}
<a class="l" name="219" href="#219">219</a>			}
<a class="hl" name="220" href="#220">220</a>		}
<a class="l" name="221" href="#221">221</a>		<span class="c">//remove all changed</span>
<a class="l" name="222" href="#222">222</a>		<a href="/source/s?defs=set1&amp;project=rtmp_client">set1</a>.<a href="/source/s?defs=removeAll&amp;project=rtmp_client">removeAll</a>(<a href="/source/s?defs=rep&amp;project=rtmp_client">rep</a>.<a href="/source/s?defs=entrySet&amp;project=rtmp_client">entrySet</a>());
<a class="l" name="223" href="#223">223</a>		<span class="c">//add the updates</span>
<a class="l" name="224" href="#224">224</a>		<a href="/source/s?defs=set1&amp;project=rtmp_client">set1</a>.<a href="/source/s?defs=addAll&amp;project=rtmp_client">addAll</a>(<a href="/source/s?defs=rep&amp;project=rtmp_client">rep</a>.<a href="/source/s?defs=entrySet&amp;project=rtmp_client">entrySet</a>());
<a class="l" name="225" href="#225">225</a>		<span class="c">//perform a union / adds all elements missing from set1</span>
<a class="l" name="226" href="#226">226</a>		<a href="/source/s?defs=set1&amp;project=rtmp_client">set1</a>.<a href="/source/s?defs=addAll&amp;project=rtmp_client">addAll</a>(<a href="/source/s?defs=set2&amp;project=rtmp_client">set2</a>);
<a class="l" name="227" href="#227">227</a>		<span class="c">//return the original object with merges</span>
<a class="l" name="228" href="#228">228</a>		<b>return</b> <a class="d" href="#metaData1">metaData1</a>;
<a class="l" name="229" href="#229">229</a>	}
<a class="hl" name="230" href="#230">230</a>
<a class="l" name="231" href="#231">231</a>	<span class="c">/**
<a class="l" name="232" href="#232">232</a>	 * Injects metadata (other than Cue points) into a tag
<a class="l" name="233" href="#233">233</a>	 *
<a class="l" name="234" href="#234">234</a>	 * <strong>@param</strong> <em>meta</em>
<a class="l" name="235" href="#235">235</a>	 *            Metadata
<a class="l" name="236" href="#236">236</a>	 * <strong>@param</strong> <em>tag</em>
<a class="l" name="237" href="#237">237</a>	 *            Tag
<a class="l" name="238" href="#238">238</a>	 * <strong>@return</strong> New tag with injected metadata
<a class="l" name="239" href="#239">239</a>	 */</span>
<a class="hl" name="240" href="#240">240</a>	<b>private</b> <a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a class="xmt" name="injectMetaData"/><a href="/source/s?refs=injectMetaData&amp;project=rtmp_client" class="xmt">injectMetaData</a>(<a href="/source/s?defs=IMetaData&amp;project=rtmp_client">IMetaData</a>&lt;?, ?&gt; <a class="xa" name="meta"/><a href="/source/s?refs=meta&amp;project=rtmp_client" class="xa">meta</a>, <a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a class="xa" name="tag"/><a href="/source/s?refs=tag&amp;project=rtmp_client" class="xa">tag</a>) {
<a class="l" name="241" href="#241">241</a>
<a class="l" name="242" href="#242">242</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=bb&amp;project=rtmp_client">bb</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">1000</span>);
<a class="l" name="243" href="#243">243</a>		<a href="/source/s?defs=bb&amp;project=rtmp_client">bb</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="244" href="#244">244</a>
<a class="l" name="245" href="#245">245</a>		<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <b>new</b> <a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>(<a href="/source/s?defs=bb&amp;project=rtmp_client">bb</a>);
<a class="l" name="246" href="#246">246</a>		<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a href="/source/s?defs=ser&amp;project=rtmp_client">ser</a> = <b>new</b> <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>();
<a class="l" name="247" href="#247">247</a>		<a href="/source/s?defs=ser&amp;project=rtmp_client">ser</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>, <span class="s">"onMetaData"</span>);
<a class="l" name="248" href="#248">248</a>		<a href="/source/s?defs=ser&amp;project=rtmp_client">ser</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>, <a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a>);
<a class="l" name="249" href="#249">249</a>
<a class="hl" name="250" href="#250">250</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=tmpBody&amp;project=rtmp_client">tmpBody</a> = <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>().<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="251" href="#251">251</a>		<b>int</b> <a href="/source/s?defs=tmpBodySize&amp;project=rtmp_client">tmpBodySize</a> = <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>().<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>();
<a class="l" name="252" href="#252">252</a>		<b>int</b> <a href="/source/s?defs=tmpPreviousTagSize&amp;project=rtmp_client">tmpPreviousTagSize</a> = <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getPreviousTagSize&amp;project=rtmp_client">getPreviousTagSize</a>();
<a class="l" name="253" href="#253">253</a>
<a class="l" name="254" href="#254">254</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=Tag&amp;project=rtmp_client">Tag</a>(<a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=TYPE_METADATA&amp;project=rtmp_client">TYPE_METADATA</a>, <span class="n">0</span>, <a href="/source/s?defs=tmpBodySize&amp;project=rtmp_client">tmpBodySize</a>, <a href="/source/s?defs=tmpBody&amp;project=rtmp_client">tmpBody</a>, <a href="/source/s?defs=tmpPreviousTagSize&amp;project=rtmp_client">tmpPreviousTagSize</a>);
<a class="l" name="255" href="#255">255</a>	}
<a class="l" name="256" href="#256">256</a>
<a class="l" name="257" href="#257">257</a>	<span class="c">/**
<a class="l" name="258" href="#258">258</a>	 * Injects metadata (Cue Points) into a tag
<a class="l" name="259" href="#259">259</a>	 *
<a class="hl" name="260" href="#260">260</a>	 * <strong>@param</strong> <em>meta</em>
<a class="l" name="261" href="#261">261</a>	 *            Metadata (cue points)
<a class="l" name="262" href="#262">262</a>	 * <strong>@param</strong> <em>tag</em>
<a class="l" name="263" href="#263">263</a>	 *            Tag
<a class="l" name="264" href="#264">264</a>	 * <strong>@return</strong> ITag tag New tag with injected metadata
<a class="l" name="265" href="#265">265</a>	 */</span>
<a class="l" name="266" href="#266">266</a>	<b>private</b> <a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a class="xmt" name="injectMetaCue"/><a href="/source/s?refs=injectMetaCue&amp;project=rtmp_client" class="xmt">injectMetaCue</a>(<a href="/source/s?defs=IMetaCue&amp;project=rtmp_client">IMetaCue</a> <a class="xa" name="meta"/><a href="/source/s?refs=meta&amp;project=rtmp_client" class="xa">meta</a>, <a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a class="xa" name="tag"/><a href="/source/s?refs=tag&amp;project=rtmp_client" class="xa">tag</a>) {
<a class="l" name="267" href="#267">267</a>
<a class="l" name="268" href="#268">268</a>		<span class="c">// IMeta meta = (MetaCue) cue;</span>
<a class="l" name="269" href="#269">269</a>		<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <b>new</b> <a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">1000</span>));
<a class="hl" name="270" href="#270">270</a>		<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a href="/source/s?defs=ser&amp;project=rtmp_client">ser</a> = <b>new</b> <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>();
<a class="l" name="271" href="#271">271</a>		<a href="/source/s?defs=ser&amp;project=rtmp_client">ser</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>, <span class="s">"onCuePoint"</span>);
<a class="l" name="272" href="#272">272</a>		<a href="/source/s?defs=ser&amp;project=rtmp_client">ser</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>, <a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a>);
<a class="l" name="273" href="#273">273</a>
<a class="l" name="274" href="#274">274</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=tmpBody&amp;project=rtmp_client">tmpBody</a> = <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>().<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="275" href="#275">275</a>		<b>int</b> <a href="/source/s?defs=tmpBodySize&amp;project=rtmp_client">tmpBodySize</a> = <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>().<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>();
<a class="l" name="276" href="#276">276</a>		<b>int</b> <a href="/source/s?defs=tmpPreviousTagSize&amp;project=rtmp_client">tmpPreviousTagSize</a> = <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getPreviousTagSize&amp;project=rtmp_client">getPreviousTagSize</a>();
<a class="l" name="277" href="#277">277</a>		<b>int</b> <a href="/source/s?defs=tmpTimestamp&amp;project=rtmp_client">tmpTimestamp</a> = <a class="d" href="#getTimeInMilliseconds">getTimeInMilliseconds</a>(<a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a>);
<a class="l" name="278" href="#278">278</a>
<a class="l" name="279" href="#279">279</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=Tag&amp;project=rtmp_client">Tag</a>(<a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=TYPE_METADATA&amp;project=rtmp_client">TYPE_METADATA</a>, <a href="/source/s?defs=tmpTimestamp&amp;project=rtmp_client">tmpTimestamp</a>, <a href="/source/s?defs=tmpBodySize&amp;project=rtmp_client">tmpBodySize</a>, <a href="/source/s?defs=tmpBody&amp;project=rtmp_client">tmpBody</a>, <a href="/source/s?defs=tmpPreviousTagSize&amp;project=rtmp_client">tmpPreviousTagSize</a>);
<a class="hl" name="280" href="#280">280</a>
<a class="l" name="281" href="#281">281</a>	}
<a class="l" name="282" href="#282">282</a>
<a class="l" name="283" href="#283">283</a>	<span class="c">/**
<a class="l" name="284" href="#284">284</a>	 * Returns a timestamp of cue point in milliseconds
<a class="l" name="285" href="#285">285</a>	 *
<a class="l" name="286" href="#286">286</a>	 * <strong>@param</strong> <em>metaCue</em>
<a class="l" name="287" href="#287">287</a>	 *            Cue point
<a class="l" name="288" href="#288">288</a>	 * <strong>@return</strong> int time Timestamp of given cue point (in milliseconds)
<a class="l" name="289" href="#289">289</a>	 */</span>
<a class="hl" name="290" href="#290">290</a>	<b>private</b> <b>int</b> <a class="xmt" name="getTimeInMilliseconds"/><a href="/source/s?refs=getTimeInMilliseconds&amp;project=rtmp_client" class="xmt">getTimeInMilliseconds</a>(<a href="/source/s?defs=IMetaCue&amp;project=rtmp_client">IMetaCue</a> <a class="xa" name="metaCue"/><a href="/source/s?refs=metaCue&amp;project=rtmp_client" class="xa">metaCue</a>) {
<a class="l" name="291" href="#291">291</a>		<b>return</b> (<b>int</b>) (<a class="d" href="#metaCue">metaCue</a>.<a href="/source/s?defs=getTime&amp;project=rtmp_client">getTime</a>() * <span class="n">1000.00</span>);
<a class="l" name="292" href="#292">292</a>
<a class="l" name="293" href="#293">293</a>	}
<a class="l" name="294" href="#294">294</a>
<a class="l" name="295" href="#295">295</a>	<span class="c">/**
<a class="l" name="296" href="#296">296</a>	 * {<strong>@inheritDoc</strong>}
<a class="l" name="297" href="#297">297</a>	 */</span>
<a class="l" name="298" href="#298">298</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeMetaData"/><a href="/source/s?refs=writeMetaData&amp;project=rtmp_client" class="xmt">writeMetaData</a>(<a href="/source/s?defs=IMetaData&amp;project=rtmp_client">IMetaData</a>&lt;?, ?&gt; <a class="xa" name="metaData"/><a href="/source/s?refs=metaData&amp;project=rtmp_client" class="xa">metaData</a>) {
<a class="l" name="299" href="#299">299</a>		<a href="/source/s?defs=IMetaCue&amp;project=rtmp_client">IMetaCue</a> <a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a> = (<a href="/source/s?defs=MetaCue&amp;project=rtmp_client">MetaCue</a>&lt;?, ?&gt;) <a class="d" href="#metaData">metaData</a>;
<a class="hl" name="300" href="#300">300</a>		<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <b>new</b> <a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">1000</span>));
<a class="l" name="301" href="#301">301</a>		<b>if</b> (<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="302" href="#302">302</a>			<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a> = <b>new</b> <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>();
<a class="l" name="303" href="#303">303</a>		}
<a class="l" name="304" href="#304">304</a>		<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>, <span class="s">"onCuePoint"</span>);
<a class="l" name="305" href="#305">305</a>		<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>, <a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a>);
<a class="l" name="306" href="#306">306</a>	}
<a class="l" name="307" href="#307">307</a>
<a class="l" name="308" href="#308">308</a>	<span class="c">/**
<a class="l" name="309" href="#309">309</a>	 * {<strong>@inheritDoc</strong>}
<a class="hl" name="310" href="#310">310</a>	 */</span>
<a class="l" name="311" href="#311">311</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeMetaCue"/><a href="/source/s?refs=writeMetaCue&amp;project=rtmp_client" class="xmt">writeMetaCue</a>() {
<a class="l" name="312" href="#312">312</a>
<a class="l" name="313" href="#313">313</a>	}
<a class="l" name="314" href="#314">314</a>
<a class="l" name="315" href="#315">315</a>	<span class="c">/**
<a class="l" name="316" href="#316">316</a>	 * <strong>@return</strong> Returns the file.
<a class="l" name="317" href="#317">317</a>	 */</span>
<a class="l" name="318" href="#318">318</a>	<b>public</b> <a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a class="xmt" name="getFile"/><a href="/source/s?refs=getFile&amp;project=rtmp_client" class="xmt">getFile</a>() {
<a class="l" name="319" href="#319">319</a>		<b>return</b> <a href="/source/s?defs=file&amp;project=rtmp_client">file</a>;
<a class="hl" name="320" href="#320">320</a>	}
<a class="l" name="321" href="#321">321</a>
<a class="l" name="322" href="#322">322</a>	<span class="c">/**
<a class="l" name="323" href="#323">323</a>	 * <strong>@param</strong> <em>file</em> The file to set.
<a class="l" name="324" href="#324">324</a>	 */</span>
<a class="l" name="325" href="#325">325</a>	<b>public</b> <b>void</b> <a class="xmt" name="setFile"/><a href="/source/s?refs=setFile&amp;project=rtmp_client" class="xmt">setFile</a>(<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a class="xa" name="file"/><a href="/source/s?refs=file&amp;project=rtmp_client" class="xa">file</a>) {
<a class="l" name="326" href="#326">326</a>		<b>this</b>.<a href="/source/s?defs=file&amp;project=rtmp_client">file</a> = <a href="/source/s?defs=file&amp;project=rtmp_client">file</a>;
<a class="l" name="327" href="#327">327</a>	}
<a class="l" name="328" href="#328">328</a>
<a class="l" name="329" href="#329">329</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="330" href="#330">330</a>	<span class="c">// TODO need to fix</span>
<a class="l" name="331" href="#331">331</a>	<b>public</b> <a href="/source/s?defs=MetaData&amp;project=rtmp_client">MetaData</a>&lt;?, ?&gt; <a class="xmt" name="readMetaData"/><a href="/source/s?refs=readMetaData&amp;project=rtmp_client" class="xmt">readMetaData</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="buffer"/><a href="/source/s?refs=buffer&amp;project=rtmp_client" class="xa">buffer</a>) {
<a class="l" name="332" href="#332">332</a>		<a href="/source/s?defs=MetaData&amp;project=rtmp_client">MetaData</a>&lt;?, ?&gt; <a href="/source/s?defs=retMeta&amp;project=rtmp_client">retMeta</a> = <b>new</b> <a href="/source/s?defs=MetaData&amp;project=rtmp_client">MetaData</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="l" name="333" href="#333">333</a>		<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a> <a href="/source/s?defs=input&amp;project=rtmp_client">input</a> = <b>new</b> <a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>(<a class="d" href="#buffer">buffer</a>);
<a class="l" name="334" href="#334">334</a>		<b>if</b> (<a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="335" href="#335">335</a>			<a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a> = <b>new</b> <a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a>();
<a class="l" name="336" href="#336">336</a>		}
<a class="l" name="337" href="#337">337</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=metaType&amp;project=rtmp_client">metaType</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<a href="/source/s?defs=input&amp;project=rtmp_client">input</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>);
<a class="l" name="338" href="#338">338</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Metadata type: {}"</span>, <a href="/source/s?defs=metaType&amp;project=rtmp_client">metaType</a>);
<a class="l" name="339" href="#339">339</a>		<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, ?&gt; m = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<a href="/source/s?defs=input&amp;project=rtmp_client">input</a>, <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>.<b>class</b>);
<a class="hl" name="340" href="#340">340</a>		<a href="/source/s?defs=retMeta&amp;project=rtmp_client">retMeta</a>.<a href="/source/s?defs=putAll&amp;project=rtmp_client">putAll</a>(m);
<a class="l" name="341" href="#341">341</a>		<b>return</b> <a href="/source/s?defs=retMeta&amp;project=rtmp_client">retMeta</a>;
<a class="l" name="342" href="#342">342</a>	}
<a class="l" name="343" href="#343">343</a>
<a class="l" name="344" href="#344">344</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="345" href="#345">345</a>	<b>public</b> <a href="/source/s?defs=IMetaCue&amp;project=rtmp_client">IMetaCue</a>[] <a class="xmt" name="readMetaCue"/><a href="/source/s?refs=readMetaCue&amp;project=rtmp_client" class="xmt">readMetaCue</a>() {
<a class="l" name="346" href="#346">346</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="347" href="#347">347</a>	}
<a class="l" name="348" href="#348">348</a>
<a class="l" name="349" href="#349">349</a>}
<a class="hl" name="350" href="#350">350</a>