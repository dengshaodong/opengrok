<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["FLVService",39]]],["Package","xp",[["org.red5.io.flv",1]]],["Method","xmt",[["getDeserializer",114],["getExtension",65],["getPrefix",59],["getSerializer",105],["getStreamableFile",87],["setDeserializer",79],["setGenerateMetadata",96],["setSerializer",72]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=File&amp;project=rtmp_client">File</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=BaseStreamableFileService&amp;project=rtmp_client">BaseStreamableFileService</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IStreamableFile&amp;project=rtmp_client">IStreamableFile</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>;
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a><span class="c">/**
<a class="l" name="31" href="#31">31</a> * A FLVServiceImpl sets up the service and hands out FLV objects to
<a class="l" name="32" href="#32">32</a> * its callers.
<a class="l" name="33" href="#33">33</a> *
<a class="l" name="34" href="#34">34</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="35" href="#35">35</a> * <strong>@author</strong> Dominick Accattato (daccattato@gmail.com)
<a class="l" name="36" href="#36">36</a> * <strong>@author</strong> Luke Hubbard, Codegent Ltd (luke@codegent.com)
<a class="l" name="37" href="#37">37</a> * <strong>@author</strong> Paul Gregoire (mondain@gmail.com)
<a class="l" name="38" href="#38">38</a> */</span>
<a class="l" name="39" href="#39">39</a><b>public</b> <b>class</b> <a class="xc" name="FLVService"/><a href="/source/s?refs=FLVService&amp;project=rtmp_client" class="xc">FLVService</a> <b>extends</b> <a href="/source/s?defs=BaseStreamableFileService&amp;project=rtmp_client">BaseStreamableFileService</a> <b>implements</b>
<a class="hl" name="40" href="#40">40</a>		<a href="/source/s?defs=IFLVService&amp;project=rtmp_client">IFLVService</a> {
<a class="l" name="41" href="#41">41</a>
<a class="l" name="42" href="#42">42</a>    <span class="c">/**
<a class="l" name="43" href="#43">43</a>     * Serializer
<a class="l" name="44" href="#44">44</a>     */</span>
<a class="l" name="45" href="#45">45</a>    <b>private</b> <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xfld" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xfld">serializer</a>;
<a class="l" name="46" href="#46">46</a>
<a class="l" name="47" href="#47">47</a>    <span class="c">/**
<a class="l" name="48" href="#48">48</a>     * Deserializer
<a class="l" name="49" href="#49">49</a>     */</span>
<a class="hl" name="50" href="#50">50</a>    <b>private</b> <a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xfld" name="deserializer"/><a href="/source/s?refs=deserializer&amp;project=rtmp_client" class="xfld">deserializer</a>;
<a class="l" name="51" href="#51">51</a>
<a class="l" name="52" href="#52">52</a>    <span class="c">/**
<a class="l" name="53" href="#53">53</a>     * Generate FLV metadata?
<a class="l" name="54" href="#54">54</a>     */</span>
<a class="l" name="55" href="#55">55</a>    <b>private</b> <b>boolean</b> <a class="xfld" name="generateMetadata"/><a href="/source/s?refs=generateMetadata&amp;project=rtmp_client" class="xfld">generateMetadata</a>;
<a class="l" name="56" href="#56">56</a>
<a class="l" name="57" href="#57">57</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="58" href="#58">58</a>    @<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="59" href="#59">59</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getPrefix"/><a href="/source/s?refs=getPrefix&amp;project=rtmp_client" class="xmt">getPrefix</a>() {
<a class="hl" name="60" href="#60">60</a>		<b>return</b> <span class="s">"flv"</span>;
<a class="l" name="61" href="#61">61</a>	}
<a class="l" name="62" href="#62">62</a>
<a class="l" name="63" href="#63">63</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="64" href="#64">64</a>    @<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="65" href="#65">65</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getExtension"/><a href="/source/s?refs=getExtension&amp;project=rtmp_client" class="xmt">getExtension</a>() {
<a class="l" name="66" href="#66">66</a>		<b>return</b> <span class="s">".flv"</span>;
<a class="l" name="67" href="#67">67</a>	}
<a class="l" name="68" href="#68">68</a>
<a class="l" name="69" href="#69">69</a>	<span class="c">/**
<a class="hl" name="70" href="#70">70</a>     * {<strong>@inheritDoc</strong>}
<a class="l" name="71" href="#71">71</a>	 */</span>
<a class="l" name="72" href="#72">72</a>	<b>public</b> <b>void</b> <a class="xmt" name="setSerializer"/><a href="/source/s?refs=setSerializer&amp;project=rtmp_client" class="xmt">setSerializer</a>(<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xa" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xa">serializer</a>) {
<a class="l" name="73" href="#73">73</a>		<b>this</b>.<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a> = <a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>;
<a class="l" name="74" href="#74">74</a>
<a class="l" name="75" href="#75">75</a>	}
<a class="l" name="76" href="#76">76</a>
<a class="l" name="77" href="#77">77</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="l" name="78" href="#78">78</a>	 */</span>
<a class="l" name="79" href="#79">79</a>	<b>public</b> <b>void</b> <a class="xmt" name="setDeserializer"/><a href="/source/s?refs=setDeserializer&amp;project=rtmp_client" class="xmt">setDeserializer</a>(<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xa" name="deserializer"/><a href="/source/s?refs=deserializer&amp;project=rtmp_client" class="xa">deserializer</a>) {
<a class="hl" name="80" href="#80">80</a>		<b>this</b>.<a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>;
<a class="l" name="81" href="#81">81</a>
<a class="l" name="82" href="#82">82</a>	}
<a class="l" name="83" href="#83">83</a>
<a class="l" name="84" href="#84">84</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="l" name="85" href="#85">85</a>	 */</span>
<a class="l" name="86" href="#86">86</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="87" href="#87">87</a>	<b>public</b> <a href="/source/s?defs=IStreamableFile&amp;project=rtmp_client">IStreamableFile</a> <a class="xmt" name="getStreamableFile"/><a href="/source/s?refs=getStreamableFile&amp;project=rtmp_client" class="xmt">getStreamableFile</a>(<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a class="xa" name="file"/><a href="/source/s?refs=file&amp;project=rtmp_client" class="xa">file</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="88" href="#88">88</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=FLV&amp;project=rtmp_client">FLV</a>(<a class="d" href="#file">file</a>, <a class="d" href="#generateMetadata">generateMetadata</a>);
<a class="l" name="89" href="#89">89</a>	}
<a class="hl" name="90" href="#90">90</a>
<a class="l" name="91" href="#91">91</a>	<span class="c">/**
<a class="l" name="92" href="#92">92</a>     * Generate metadata or not
<a class="l" name="93" href="#93">93</a>     *
<a class="l" name="94" href="#94">94</a>     * <strong>@param</strong> <em>generate</em>  &lt;code&gt;true&lt;/code&gt; if there's need to generate metadata, &lt;code&gt;false&lt;/code&gt; otherwise
<a class="l" name="95" href="#95">95</a>     */</span>
<a class="l" name="96" href="#96">96</a>    <b>public</b> <b>void</b> <a class="xmt" name="setGenerateMetadata"/><a href="/source/s?refs=setGenerateMetadata&amp;project=rtmp_client" class="xmt">setGenerateMetadata</a>(<b>boolean</b> <a class="xa" name="generate"/><a href="/source/s?refs=generate&amp;project=rtmp_client" class="xa">generate</a>) {
<a class="l" name="97" href="#97">97</a>		<a class="d" href="#generateMetadata">generateMetadata</a> = <a class="d" href="#generate">generate</a>;
<a class="l" name="98" href="#98">98</a>	}
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a>	<span class="c">/**
<a class="l" name="101" href="#101">101</a>     * Getter for serializer
<a class="l" name="102" href="#102">102</a>     *
<a class="l" name="103" href="#103">103</a>     * <strong>@return</strong>  Serializer
<a class="l" name="104" href="#104">104</a>     */</span>
<a class="l" name="105" href="#105">105</a>    <b>public</b> <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xmt" name="getSerializer"/><a href="/source/s?refs=getSerializer&amp;project=rtmp_client" class="xmt">getSerializer</a>() {
<a class="l" name="106" href="#106">106</a>		<b>return</b> <a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>;
<a class="l" name="107" href="#107">107</a>	}
<a class="l" name="108" href="#108">108</a>
<a class="l" name="109" href="#109">109</a>	<span class="c">/**
<a class="hl" name="110" href="#110">110</a>     * Getter for deserializer
<a class="l" name="111" href="#111">111</a>     *
<a class="l" name="112" href="#112">112</a>     * <strong>@return</strong>  Deserializer
<a class="l" name="113" href="#113">113</a>     */</span>
<a class="l" name="114" href="#114">114</a>    <b>public</b> <a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xmt" name="getDeserializer"/><a href="/source/s?refs=getDeserializer&amp;project=rtmp_client" class="xmt">getDeserializer</a>() {
<a class="l" name="115" href="#115">115</a>		<b>return</b> <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>;
<a class="l" name="116" href="#116">116</a>	}
<a class="l" name="117" href="#117">117</a>}
<a class="l" name="118" href="#118">118</a>