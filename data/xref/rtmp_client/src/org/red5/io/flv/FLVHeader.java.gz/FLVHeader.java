<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["FLVHeader",37]]],["Package","xp",[["org.red5.io.flv",1]]],["Method","xmt",[["getDataOffset",86],["getFlagAudio",142],["getFlagReserved01",171],["getFlagReserved02",192],["getFlagVideo",212],["getSignature",104],["getVersion",230],["setDataOffset",95],["setFlagAudio",151],["setFlagReserved01",182],["setFlagReserved02",203],["setFlagVideo",221],["setSignature",133],["setTypeFlags",160],["setVersion",240],["toString",115],["write",249],["write",263]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a>;
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a><span class="c">/*
<a class="l" name="8" href="#8">8</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="9" href="#9">9</a> *
<a class="hl" name="10" href="#10">10</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="11" href="#11">11</a> *
<a class="l" name="12" href="#12">12</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="13" href="#13">13</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="l" name="14" href="#14">14</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="15" href="#15">15</a> * version.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="18" href="#18">18</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="19" href="#19">19</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="hl" name="20" href="#20">20</a> *
<a class="l" name="21" href="#21">21</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="22" href="#22">22</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="23" href="#23">23</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="l" name="24" href="#24">24</a> */</span>
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a><span class="c">/**
<a class="l" name="27" href="#27">27</a> * FLVHeader parses out the contents of a FLV video file and returns
<a class="l" name="28" href="#28">28</a> * the Header data
<a class="l" name="29" href="#29">29</a> *
<a class="hl" name="30" href="#30">30</a> * <strong>@see</strong> &lt;a href="<a href="http://osflash.org/flv">http://osflash.org/flv</a>#flv_header"&gt;OSFlash (external)&lt;/a&gt;
<a class="l" name="31" href="#31">31</a> *
<a class="l" name="32" href="#32">32</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="33" href="#33">33</a> * <strong>@author</strong> Dominick Accattato (daccattato@gmail.com)
<a class="l" name="34" href="#34">34</a> * <strong>@author</strong> Luke Hubbard, Codegent Ltd (luke@codegent.com)
<a class="l" name="35" href="#35">35</a> * <strong>@author</strong> Tiago Jacobs (tiago@imdt.com.br)
<a class="l" name="36" href="#36">36</a> */</span>
<a class="l" name="37" href="#37">37</a><b>public</b> <b>class</b> <a class="xc" name="FLVHeader"/><a href="/source/s?refs=FLVHeader&amp;project=rtmp_client" class="xc">FLVHeader</a> {
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>	<b>static</b> <b>final</b> <b>int</b> <a class="xfld" name="FLV_HEADER_FLAG_HAS_AUDIO"/><a href="/source/s?refs=FLV_HEADER_FLAG_HAS_AUDIO&amp;project=rtmp_client" class="xfld">FLV_HEADER_FLAG_HAS_AUDIO</a> = <span class="n">4</span>;
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a>	<b>static</b> <b>final</b> <b>int</b> <a class="xfld" name="FLV_HEADER_FLAG_HAS_VIDEO"/><a href="/source/s?refs=FLV_HEADER_FLAG_HAS_VIDEO&amp;project=rtmp_client" class="xfld">FLV_HEADER_FLAG_HAS_VIDEO</a> = <span class="n">1</span>;
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a>	<span class="c">/**
<a class="l" name="44" href="#44">44</a>	 * Signature
<a class="l" name="45" href="#45">45</a>	 */</span>
<a class="l" name="46" href="#46">46</a>	<b>public</b> <b>static</b> <b>byte</b>[] <a class="xfld" name="signature"/><a href="/source/s?refs=signature&amp;project=rtmp_client" class="xfld">signature</a> = <span class="s">"FLV"</span>.<a href="/source/s?defs=getBytes&amp;project=rtmp_client">getBytes</a>();
<a class="l" name="47" href="#47">47</a>
<a class="l" name="48" href="#48">48</a>	<span class="c">/**
<a class="l" name="49" href="#49">49</a>	 * FLV version
<a class="hl" name="50" href="#50">50</a>	 */</span>
<a class="l" name="51" href="#51">51</a>	<b>public</b> <b>static</b> <b>byte</b> <a class="xfld" name="version"/><a href="/source/s?refs=version&amp;project=rtmp_client" class="xfld">version</a> = <span class="n">0x01</span>; <span class="c">//version 1</span>
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>	<span class="c">// TYPES</span>
<a class="l" name="54" href="#54">54</a>
<a class="l" name="55" href="#55">55</a>	<span class="c">/**
<a class="l" name="56" href="#56">56</a>	 * Reserved flag, one
<a class="l" name="57" href="#57">57</a>	 */</span>
<a class="l" name="58" href="#58">58</a>	<b>public</b> <b>static</b> <b>byte</b> <a class="xfld" name="flagReserved01"/><a href="/source/s?refs=flagReserved01&amp;project=rtmp_client" class="xfld">flagReserved01</a> = <span class="n">0x00</span>;
<a class="l" name="59" href="#59">59</a>
<a class="hl" name="60" href="#60">60</a>	<span class="c">/**
<a class="l" name="61" href="#61">61</a>	 * Audio flag
<a class="l" name="62" href="#62">62</a>	 */</span>
<a class="l" name="63" href="#63">63</a>	<b>public</b> <b>boolean</b> <a class="xfld" name="flagAudio"/><a href="/source/s?refs=flagAudio&amp;project=rtmp_client" class="xfld">flagAudio</a>;
<a class="l" name="64" href="#64">64</a>
<a class="l" name="65" href="#65">65</a>	<span class="c">/**
<a class="l" name="66" href="#66">66</a>	 * Reserved flag, two
<a class="l" name="67" href="#67">67</a>	 */</span>
<a class="l" name="68" href="#68">68</a>	<b>public</b> <b>static</b> <b>byte</b> <a class="xfld" name="flagReserved02"/><a href="/source/s?refs=flagReserved02&amp;project=rtmp_client" class="xfld">flagReserved02</a> = <span class="n">0x00</span>;
<a class="l" name="69" href="#69">69</a>
<a class="hl" name="70" href="#70">70</a>	<span class="c">/**
<a class="l" name="71" href="#71">71</a>	 * Video flag
<a class="l" name="72" href="#72">72</a>	 */</span>
<a class="l" name="73" href="#73">73</a>	<b>public</b> <b>boolean</b> <a class="xfld" name="flagVideo"/><a href="/source/s?refs=flagVideo&amp;project=rtmp_client" class="xfld">flagVideo</a>;
<a class="l" name="74" href="#74">74</a>
<a class="l" name="75" href="#75">75</a>	<span class="c">// DATA OFFSET</span>
<a class="l" name="76" href="#76">76</a>	<span class="c">/**
<a class="l" name="77" href="#77">77</a>	 * reserved for data up to 4,294,967,295
<a class="l" name="78" href="#78">78</a>	 */</span>
<a class="l" name="79" href="#79">79</a>	<b>public</b> <b>int</b> <a class="xfld" name="dataOffset"/><a href="/source/s?refs=dataOffset&amp;project=rtmp_client" class="xfld">dataOffset</a> = <span class="n">0x00</span>;
<a class="hl" name="80" href="#80">80</a>
<a class="l" name="81" href="#81">81</a>	<span class="c">/**
<a class="l" name="82" href="#82">82</a>	 * Returns the data offset bytes
<a class="l" name="83" href="#83">83</a>	 *
<a class="l" name="84" href="#84">84</a>	 * <strong>@return</strong> int           Data offset
<a class="l" name="85" href="#85">85</a>	 */</span>
<a class="l" name="86" href="#86">86</a>	<b>public</b> <b>int</b> <a class="xmt" name="getDataOffset"/><a href="/source/s?refs=getDataOffset&amp;project=rtmp_client" class="xmt">getDataOffset</a>() {
<a class="l" name="87" href="#87">87</a>		<b>return</b> <a class="d" href="#dataOffset">dataOffset</a>;
<a class="l" name="88" href="#88">88</a>	}
<a class="l" name="89" href="#89">89</a>
<a class="hl" name="90" href="#90">90</a>	<span class="c">/**
<a class="l" name="91" href="#91">91</a>	 * Sets the data offset bytes
<a class="l" name="92" href="#92">92</a>	 *
<a class="l" name="93" href="#93">93</a>	 * <strong>@param</strong> <em>data_offset</em>    Data offset
<a class="l" name="94" href="#94">94</a>	 */</span>
<a class="l" name="95" href="#95">95</a>	<b>public</b> <b>void</b> <a class="xmt" name="setDataOffset"/><a href="/source/s?refs=setDataOffset&amp;project=rtmp_client" class="xmt">setDataOffset</a>(<b>int</b> <a class="xa" name="data_offset"/><a href="/source/s?refs=data_offset&amp;project=rtmp_client" class="xa">data_offset</a>) {
<a class="l" name="96" href="#96">96</a>		<a class="d" href="#dataOffset">dataOffset</a> = <a class="d" href="#data_offset">data_offset</a>;
<a class="l" name="97" href="#97">97</a>	}
<a class="l" name="98" href="#98">98</a>
<a class="l" name="99" href="#99">99</a>	<span class="c">/**
<a class="hl" name="100" href="#100">100</a>	 * Returns the signature bytes
<a class="l" name="101" href="#101">101</a>	 *
<a class="l" name="102" href="#102">102</a>	 * <strong>@return</strong> byte[]       Signature
<a class="l" name="103" href="#103">103</a>	 */</span>
<a class="l" name="104" href="#104">104</a>	<b>public</b> <b>byte</b>[] <a class="xmt" name="getSignature"/><a href="/source/s?refs=getSignature&amp;project=rtmp_client" class="xmt">getSignature</a>() {
<a class="l" name="105" href="#105">105</a>		<b>return</b> <a href="/source/s?defs=signature&amp;project=rtmp_client">signature</a>;
<a class="l" name="106" href="#106">106</a>	}
<a class="l" name="107" href="#107">107</a>
<a class="l" name="108" href="#108">108</a>	<span class="c">/**
<a class="l" name="109" href="#109">109</a>	 * Overrides the toString method so that a FLVHeader can
<a class="hl" name="110" href="#110">110</a>	 * be represented by its datatypes
<a class="l" name="111" href="#111">111</a>	 *
<a class="l" name="112" href="#112">112</a>	 * <strong>@return</strong> String       String representation
<a class="l" name="113" href="#113">113</a>	 */</span>
<a class="l" name="114" href="#114">114</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="115" href="#115">115</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toString"/><a href="/source/s?refs=toString&amp;project=rtmp_client" class="xmt">toString</a>() {
<a class="l" name="116" href="#116">116</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=ret&amp;project=rtmp_client">ret</a> = <span class="s">""</span>;
<a class="l" name="117" href="#117">117</a>		<span class="c">//ret += "SIGNATURE: \t" + getSIGNATURE() + "\n";</span>
<a class="l" name="118" href="#118">118</a>		<span class="c">//ret += "SIGNATURE: \t\t" + new String(signature) + "\n";</span>
<a class="l" name="119" href="#119">119</a>		<a href="/source/s?defs=ret&amp;project=rtmp_client">ret</a> += <span class="s">"VERSION: \t\t"</span> + <a class="d" href="#getVersion">getVersion</a>() + <span class="s">"\n"</span>;
<a class="hl" name="120" href="#120">120</a>		<a href="/source/s?defs=ret&amp;project=rtmp_client">ret</a> += <span class="s">"TYPE FLAGS VIDEO: \t"</span> + <a class="d" href="#getFlagVideo">getFlagVideo</a>() + <span class="s">"\n"</span>;
<a class="l" name="121" href="#121">121</a>		<a href="/source/s?defs=ret&amp;project=rtmp_client">ret</a> += <span class="s">"TYPE FLAGS AUDIO: \t"</span> + <a class="d" href="#getFlagAudio">getFlagAudio</a>() + <span class="s">"\n"</span>;
<a class="l" name="122" href="#122">122</a>		<a href="/source/s?defs=ret&amp;project=rtmp_client">ret</a> += <span class="s">"DATA OFFSET: \t\t"</span> + <a class="d" href="#getDataOffset">getDataOffset</a>() + <span class="s">"\n"</span>;
<a class="l" name="123" href="#123">123</a>		<span class="c">//byte b = 0x01;</span>
<a class="l" name="124" href="#124">124</a>		<b>return</b> <a href="/source/s?defs=ret&amp;project=rtmp_client">ret</a>;
<a class="l" name="125" href="#125">125</a>	}
<a class="l" name="126" href="#126">126</a>
<a class="l" name="127" href="#127">127</a>	<span class="c">/**
<a class="l" name="128" href="#128">128</a>	 * Sets the signature bytes
<a class="l" name="129" href="#129">129</a>	 *
<a class="hl" name="130" href="#130">130</a>	 * <strong>@param</strong> <em>signature</em>     Signature
<a class="l" name="131" href="#131">131</a>	 */</span>
<a class="l" name="132" href="#132">132</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"static-access"</span>)
<a class="l" name="133" href="#133">133</a>	<b>public</b> <b>void</b> <a class="xmt" name="setSignature"/><a href="/source/s?refs=setSignature&amp;project=rtmp_client" class="xmt">setSignature</a>(<b>byte</b>[] <a class="xa" name="signature"/><a href="/source/s?refs=signature&amp;project=rtmp_client" class="xa">signature</a>) {
<a class="l" name="134" href="#134">134</a>		<b>this</b>.<a href="/source/s?defs=signature&amp;project=rtmp_client">signature</a> = <a href="/source/s?defs=signature&amp;project=rtmp_client">signature</a>;
<a class="l" name="135" href="#135">135</a>	}
<a class="l" name="136" href="#136">136</a>
<a class="l" name="137" href="#137">137</a>	<span class="c">/**
<a class="l" name="138" href="#138">138</a>	 * Returns a boolean on whether this data contains audio
<a class="l" name="139" href="#139">139</a>	 *
<a class="hl" name="140" href="#140">140</a>	 * <strong>@return</strong> boolean      &lt;code&gt;true&lt;/code&gt; if this FLV header contains audio data, &lt;code&gt;false&lt;/code&gt; otherwise
<a class="l" name="141" href="#141">141</a>	 */</span>
<a class="l" name="142" href="#142">142</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="getFlagAudio"/><a href="/source/s?refs=getFlagAudio&amp;project=rtmp_client" class="xmt">getFlagAudio</a>() {
<a class="l" name="143" href="#143">143</a>		<b>return</b> <a href="/source/s?defs=flagAudio&amp;project=rtmp_client">flagAudio</a>;
<a class="l" name="144" href="#144">144</a>	}
<a class="l" name="145" href="#145">145</a>
<a class="l" name="146" href="#146">146</a>	<span class="c">/**
<a class="l" name="147" href="#147">147</a>	 * Sets the audioflag on whether this data contains audio
<a class="l" name="148" href="#148">148</a>	 *
<a class="l" name="149" href="#149">149</a>	 * <strong>@param</strong> <em>flagAudio</em>     &lt;code&gt;true&lt;/code&gt; if this FLV header contains audio data, &lt;code&gt;false&lt;/code&gt; otherwise
<a class="hl" name="150" href="#150">150</a>	 */</span>
<a class="l" name="151" href="#151">151</a>	<b>public</b> <b>void</b> <a class="xmt" name="setFlagAudio"/><a href="/source/s?refs=setFlagAudio&amp;project=rtmp_client" class="xmt">setFlagAudio</a>(<b>boolean</b> <a class="xa" name="flagAudio"/><a href="/source/s?refs=flagAudio&amp;project=rtmp_client" class="xa">flagAudio</a>) {
<a class="l" name="152" href="#152">152</a>		<b>this</b>.<a href="/source/s?defs=flagAudio&amp;project=rtmp_client">flagAudio</a> = <a href="/source/s?defs=flagAudio&amp;project=rtmp_client">flagAudio</a>;
<a class="l" name="153" href="#153">153</a>	}
<a class="l" name="154" href="#154">154</a>
<a class="l" name="155" href="#155">155</a>	<span class="c">/**
<a class="l" name="156" href="#156">156</a>	 * Sets the type flags on whether this data is audio or video
<a class="l" name="157" href="#157">157</a>	 *
<a class="l" name="158" href="#158">158</a>	 * <strong>@param</strong> <em>typeFlags</em>     Type flags determining data types (audio or video)
<a class="l" name="159" href="#159">159</a>	 */</span>
<a class="hl" name="160" href="#160">160</a>	<b>public</b> <b>void</b> <a class="xmt" name="setTypeFlags"/><a href="/source/s?refs=setTypeFlags&amp;project=rtmp_client" class="xmt">setTypeFlags</a>(<b>byte</b> <a class="xa" name="typeFlags"/><a href="/source/s?refs=typeFlags&amp;project=rtmp_client" class="xa">typeFlags</a>) {
<a class="l" name="161" href="#161">161</a>		<a class="d" href="#flagVideo">flagVideo</a> = (((<b>byte</b>) (((<a class="d" href="#typeFlags">typeFlags</a> &lt;&lt; <span class="n">0x7</span>) &gt;&gt;&gt; <span class="n">0x7</span>) &amp; <span class="n">0x01</span>)) &gt; <span class="n">0x00</span>);
<a class="l" name="162" href="#162">162</a>		<a href="/source/s?defs=flagAudio&amp;project=rtmp_client">flagAudio</a> = (((<b>byte</b>) (((<a class="d" href="#typeFlags">typeFlags</a> &lt;&lt; <span class="n">0x5</span>) &gt;&gt;&gt; <span class="n">0x7</span>) &amp; <span class="n">0x01</span>)) &gt; <span class="n">0x00</span>);
<a class="l" name="163" href="#163">163</a>	}
<a class="l" name="164" href="#164">164</a>
<a class="l" name="165" href="#165">165</a>	<span class="c">/**
<a class="l" name="166" href="#166">166</a>	 * Gets the FlagReserved01 which is a datatype specified in the Flash
<a class="l" name="167" href="#167">167</a>	 * Specification
<a class="l" name="168" href="#168">168</a>	 *
<a class="l" name="169" href="#169">169</a>	 * <strong>@return</strong> byte             Flag reserved, first
<a class="hl" name="170" href="#170">170</a>	 */</span>
<a class="l" name="171" href="#171">171</a>	<b>public</b> <b>byte</b> <a class="xmt" name="getFlagReserved01"/><a href="/source/s?refs=getFlagReserved01&amp;project=rtmp_client" class="xmt">getFlagReserved01</a>() {
<a class="l" name="172" href="#172">172</a>		<b>return</b> <a href="/source/s?defs=flagReserved01&amp;project=rtmp_client">flagReserved01</a>;
<a class="l" name="173" href="#173">173</a>	}
<a class="l" name="174" href="#174">174</a>
<a class="l" name="175" href="#175">175</a>	<span class="c">/**
<a class="l" name="176" href="#176">176</a>	 * Sets the FlagReserved01 which is a datatype specified in the Flash
<a class="l" name="177" href="#177">177</a>	 * Specification
<a class="l" name="178" href="#178">178</a>	 *
<a class="l" name="179" href="#179">179</a>	 * <strong>@param</strong> <em>flagReserved01</em>    Flag reserved, first
<a class="hl" name="180" href="#180">180</a>	 */</span>
<a class="l" name="181" href="#181">181</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"static-access"</span>)
<a class="l" name="182" href="#182">182</a>	<b>public</b> <b>void</b> <a class="xmt" name="setFlagReserved01"/><a href="/source/s?refs=setFlagReserved01&amp;project=rtmp_client" class="xmt">setFlagReserved01</a>(<b>byte</b> <a class="xa" name="flagReserved01"/><a href="/source/s?refs=flagReserved01&amp;project=rtmp_client" class="xa">flagReserved01</a>) {
<a class="l" name="183" href="#183">183</a>		<b>this</b>.<a href="/source/s?defs=flagReserved01&amp;project=rtmp_client">flagReserved01</a> = <a href="/source/s?defs=flagReserved01&amp;project=rtmp_client">flagReserved01</a>;
<a class="l" name="184" href="#184">184</a>	}
<a class="l" name="185" href="#185">185</a>
<a class="l" name="186" href="#186">186</a>	<span class="c">/**
<a class="l" name="187" href="#187">187</a>	 * Gets the FlagReserved02 which is a datatype specified in the Flash
<a class="l" name="188" href="#188">188</a>	 * Specification
<a class="l" name="189" href="#189">189</a>	 *
<a class="hl" name="190" href="#190">190</a>	 * <strong>@return</strong> byte             FlagReserved02
<a class="l" name="191" href="#191">191</a>	 */</span>
<a class="l" name="192" href="#192">192</a>	<b>public</b> <b>byte</b> <a class="xmt" name="getFlagReserved02"/><a href="/source/s?refs=getFlagReserved02&amp;project=rtmp_client" class="xmt">getFlagReserved02</a>() {
<a class="l" name="193" href="#193">193</a>		<b>return</b> <a href="/source/s?defs=flagReserved02&amp;project=rtmp_client">flagReserved02</a>;
<a class="l" name="194" href="#194">194</a>	}
<a class="l" name="195" href="#195">195</a>
<a class="l" name="196" href="#196">196</a>	<span class="c">/**
<a class="l" name="197" href="#197">197</a>	 * Sets the Flag Reserved02 which is a datatype specified in the Flash
<a class="l" name="198" href="#198">198</a>	 * Specification
<a class="l" name="199" href="#199">199</a>	 *
<a class="hl" name="200" href="#200">200</a>	 * <strong>@param</strong> <em>flagReserved02</em>    FlagReserved02
<a class="l" name="201" href="#201">201</a>	 */</span>
<a class="l" name="202" href="#202">202</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"static-access"</span>)
<a class="l" name="203" href="#203">203</a>	<b>public</b> <b>void</b> <a class="xmt" name="setFlagReserved02"/><a href="/source/s?refs=setFlagReserved02&amp;project=rtmp_client" class="xmt">setFlagReserved02</a>(<b>byte</b> <a class="xa" name="flagReserved02"/><a href="/source/s?refs=flagReserved02&amp;project=rtmp_client" class="xa">flagReserved02</a>) {
<a class="l" name="204" href="#204">204</a>		<b>this</b>.<a href="/source/s?defs=flagReserved02&amp;project=rtmp_client">flagReserved02</a> = <a href="/source/s?defs=flagReserved02&amp;project=rtmp_client">flagReserved02</a>;
<a class="l" name="205" href="#205">205</a>	}
<a class="l" name="206" href="#206">206</a>
<a class="l" name="207" href="#207">207</a>	<span class="c">/**
<a class="l" name="208" href="#208">208</a>	 * Returns a boolean on whether this data contains video
<a class="l" name="209" href="#209">209</a>	 *
<a class="hl" name="210" href="#210">210</a>	 * <strong>@return</strong> boolean          &lt;code&gt;true&lt;/code&gt; if this FLV header contains vide data, &lt;code&gt;false&lt;/code&gt; otherwise
<a class="l" name="211" href="#211">211</a>	 */</span>
<a class="l" name="212" href="#212">212</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="getFlagVideo"/><a href="/source/s?refs=getFlagVideo&amp;project=rtmp_client" class="xmt">getFlagVideo</a>() {
<a class="l" name="213" href="#213">213</a>		<b>return</b> <a class="d" href="#flagVideo">flagVideo</a>;
<a class="l" name="214" href="#214">214</a>	}
<a class="l" name="215" href="#215">215</a>
<a class="l" name="216" href="#216">216</a>	<span class="c">/**
<a class="l" name="217" href="#217">217</a>	 * Sets the audioflag on whether this data contains audio
<a class="l" name="218" href="#218">218</a>	 *
<a class="l" name="219" href="#219">219</a>	 * <strong>@param</strong> <em>type_flags_video</em>  &lt;code&gt;true&lt;/code&gt; if this FLV header contains video data, &lt;code&gt;false&lt;/code&gt; otherwise
<a class="hl" name="220" href="#220">220</a>	 */</span>
<a class="l" name="221" href="#221">221</a>	<b>public</b> <b>void</b> <a class="xmt" name="setFlagVideo"/><a href="/source/s?refs=setFlagVideo&amp;project=rtmp_client" class="xmt">setFlagVideo</a>(<b>boolean</b> <a class="xa" name="type_flags_video"/><a href="/source/s?refs=type_flags_video&amp;project=rtmp_client" class="xa">type_flags_video</a>) {
<a class="l" name="222" href="#222">222</a>		<a class="d" href="#flagVideo">flagVideo</a> = <a class="d" href="#type_flags_video">type_flags_video</a>;
<a class="l" name="223" href="#223">223</a>	}
<a class="l" name="224" href="#224">224</a>
<a class="l" name="225" href="#225">225</a>	<span class="c">/**
<a class="l" name="226" href="#226">226</a>	 * Gets the version byte
<a class="l" name="227" href="#227">227</a>	 *
<a class="l" name="228" href="#228">228</a>	 * <strong>@return</strong> byte             FLV version byte
<a class="l" name="229" href="#229">229</a>	 */</span>
<a class="hl" name="230" href="#230">230</a>	<b>public</b> <b>byte</b> <a class="xmt" name="getVersion"/><a href="/source/s?refs=getVersion&amp;project=rtmp_client" class="xmt">getVersion</a>() {
<a class="l" name="231" href="#231">231</a>		<b>return</b> <a href="/source/s?defs=version&amp;project=rtmp_client">version</a>;
<a class="l" name="232" href="#232">232</a>	}
<a class="l" name="233" href="#233">233</a>
<a class="l" name="234" href="#234">234</a>	<span class="c">/**
<a class="l" name="235" href="#235">235</a>	 * Sets the version byte
<a class="l" name="236" href="#236">236</a>	 *
<a class="l" name="237" href="#237">237</a>	 * <strong>@param</strong> <em>version</em>           FLV version byte
<a class="l" name="238" href="#238">238</a>	 */</span>
<a class="l" name="239" href="#239">239</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"static-access"</span>)
<a class="hl" name="240" href="#240">240</a>	<b>public</b> <b>void</b> <a class="xmt" name="setVersion"/><a href="/source/s?refs=setVersion&amp;project=rtmp_client" class="xmt">setVersion</a>(<b>byte</b> <a class="xa" name="version"/><a href="/source/s?refs=version&amp;project=rtmp_client" class="xa">version</a>) {
<a class="l" name="241" href="#241">241</a>		<b>this</b>.<a href="/source/s?defs=version&amp;project=rtmp_client">version</a> = <a href="/source/s?defs=version&amp;project=rtmp_client">version</a>;
<a class="l" name="242" href="#242">242</a>	}
<a class="l" name="243" href="#243">243</a>
<a class="l" name="244" href="#244">244</a>	<span class="c">/**
<a class="l" name="245" href="#245">245</a>	 * Writes the FLVHeader to IoBuffer.
<a class="l" name="246" href="#246">246</a>	 *
<a class="l" name="247" href="#247">247</a>	 * <strong>@param</strong> <em>buffer</em>           IoBuffer to write
<a class="l" name="248" href="#248">248</a>	 */</span>
<a class="l" name="249" href="#249">249</a>	<b>public</b> <b>void</b> <a class="xmt" name="write"/><a href="/source/s?refs=write&amp;project=rtmp_client" class="xmt">write</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="buffer"/><a href="/source/s?refs=buffer&amp;project=rtmp_client" class="xa">buffer</a>) {
<a class="hl" name="250" href="#250">250</a>		<span class="c">// FLV</span>
<a class="l" name="251" href="#251">251</a>		<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=signature&amp;project=rtmp_client">signature</a>);
<a class="l" name="252" href="#252">252</a>		<span class="c">// version</span>
<a class="l" name="253" href="#253">253</a>		<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=version&amp;project=rtmp_client">version</a>);
<a class="l" name="254" href="#254">254</a>		<span class="c">// flags</span>
<a class="l" name="255" href="#255">255</a>		<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) (<a class="d" href="#FLV_HEADER_FLAG_HAS_AUDIO">FLV_HEADER_FLAG_HAS_AUDIO</a> * (<a href="/source/s?defs=flagAudio&amp;project=rtmp_client">flagAudio</a> ? <span class="n">1</span> : <span class="n">0</span>) + <a class="d" href="#FLV_HEADER_FLAG_HAS_VIDEO">FLV_HEADER_FLAG_HAS_VIDEO</a> * (<a class="d" href="#flagVideo">flagVideo</a> ? <span class="n">1</span> : <span class="n">0</span>)));
<a class="l" name="256" href="#256">256</a>		<span class="c">// data offset</span>
<a class="l" name="257" href="#257">257</a>		<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<span class="n">9</span>);
<a class="l" name="258" href="#258">258</a>		<span class="c">// previous tag size 0 (this is the "first" tag)</span>
<a class="l" name="259" href="#259">259</a>		<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<span class="n">0</span>);
<a class="hl" name="260" href="#260">260</a>		<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="261" href="#261">261</a>	}
<a class="l" name="262" href="#262">262</a>
<a class="l" name="263" href="#263">263</a>	<b>public</b> <b>void</b> <a class="xmt" name="write"/><a href="/source/s?refs=write&amp;project=rtmp_client" class="xmt">write</a>(<a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a> <a class="xa" name="buffer"/><a href="/source/s?refs=buffer&amp;project=rtmp_client" class="xa">buffer</a>) {
<a class="l" name="264" href="#264">264</a>		<span class="c">// FLV</span>
<a class="l" name="265" href="#265">265</a>		<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=signature&amp;project=rtmp_client">signature</a>);
<a class="l" name="266" href="#266">266</a>		<span class="c">// version</span>
<a class="l" name="267" href="#267">267</a>		<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=version&amp;project=rtmp_client">version</a>);
<a class="l" name="268" href="#268">268</a>		<span class="c">// flags</span>
<a class="l" name="269" href="#269">269</a>		<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) (<a class="d" href="#FLV_HEADER_FLAG_HAS_AUDIO">FLV_HEADER_FLAG_HAS_AUDIO</a> * (<a href="/source/s?defs=flagAudio&amp;project=rtmp_client">flagAudio</a> ? <span class="n">1</span> : <span class="n">0</span>) + <a class="d" href="#FLV_HEADER_FLAG_HAS_VIDEO">FLV_HEADER_FLAG_HAS_VIDEO</a> * (<a class="d" href="#flagVideo">flagVideo</a> ? <span class="n">1</span> : <span class="n">0</span>)));
<a class="hl" name="270" href="#270">270</a>		<span class="c">// data offset</span>
<a class="l" name="271" href="#271">271</a>		<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<span class="n">9</span>);
<a class="l" name="272" href="#272">272</a>		<span class="c">// previous tag size 0 (this is the "first" tag)</span>
<a class="l" name="273" href="#273">273</a>		<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<span class="n">0</span>);
<a class="l" name="274" href="#274">274</a>		<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="275" href="#275">275</a>	}
<a class="l" name="276" href="#276">276</a>
<a class="l" name="277" href="#277">277</a>}
<a class="l" name="278" href="#278">278</a>