<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["MetaCue",47]]],["Package","xp",[["org.red5.io.flv",1]]],["Method","xmt",[["MetaCue",57],["compareTo",98],["getName",69],["getTime",93],["getType",81],["setName",63],["setTime",87],["setType",75],["toString",114]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a><span class="c">/**
<a class="l" name="26" href="#26">26</a> * Cue point is metadata marker used to control and accompany video playback with client-side application
<a class="l" name="27" href="#27">27</a> * events. Each cue point have at least one attribute, timestamp. Timestamp specifies position of cue point in
<a class="l" name="28" href="#28">28</a> * FLV file.
<a class="l" name="29" href="#29">29</a> *
<a class="hl" name="30" href="#30">30</a> * &lt;p&gt;Cue points are usually used as event triggers down video flow or navigation points in a file. Cue points are
<a class="l" name="31" href="#31">31</a> * of two types:
<a class="l" name="32" href="#32">32</a> * &lt;ul&gt;
<a class="l" name="33" href="#33">33</a> *  &lt;li&gt;Embedded into FLV or SWF&lt;/li&gt;
<a class="l" name="34" href="#34">34</a> *  &lt;li&gt;External, or added on fly (e.g. with FLVPlayback component or ActionScript) on both server-side and client-side.&lt;/li&gt;
<a class="l" name="35" href="#35">35</a> * &lt;/ul&gt;
<a class="l" name="36" href="#36">36</a> * &lt;/p&gt;
<a class="l" name="37" href="#37">37</a> *
<a class="l" name="38" href="#38">38</a> * &lt;p&gt;To add cue point trigger event listener at client-side in <a href="/source/s?path=Flex/">Flex</a>/<a href="/source/s?path=Flex/Flash">Flash</a> application, use NetStream.onCuePoint event
<a class="l" name="39" href="#39">39</a> * handler.&lt;/p&gt;
<a class="hl" name="40" href="#40">40</a> *
<a class="l" name="41" href="#41">41</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="42" href="#42">42</a> * <strong>@author</strong> Dominick Accattato (daccattato@gmail.com)
<a class="l" name="43" href="#43">43</a> * <strong>@author</strong> Luke Hubbard, Codegent Ltd (luke@codegent.com)
<a class="l" name="44" href="#44">44</a> * <strong>@param</strong> &lt;K&gt; key type
<a class="l" name="45" href="#45">45</a> * <strong>@param</strong> &lt;V&gt; value type
<a class="l" name="46" href="#46">46</a> */</span>
<a class="l" name="47" href="#47">47</a><b>public</b> <b>class</b> <a class="xc" name="MetaCue"/><a href="/source/s?refs=MetaCue&amp;project=rtmp_client" class="xc">MetaCue</a>&lt;K, V&gt; <b>extends</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <b>implements</b> <a href="/source/s?defs=IMetaCue&amp;project=rtmp_client">IMetaCue</a> {
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>	<span class="c">/**
<a class="hl" name="50" href="#50">50</a>	 * SerialVersionUID = -1769771340654996861L;
<a class="l" name="51" href="#51">51</a>	 */</span>
<a class="l" name="52" href="#52">52</a>	<b>private</b> <b>static</b> <b>final</b> <b>long</b> <a class="xfld" name="serialVersionUID"/><a href="/source/s?refs=serialVersionUID&amp;project=rtmp_client" class="xfld">serialVersionUID</a> = -<span class="n">1769771340654996861L</span>;
<a class="l" name="53" href="#53">53</a>
<a class="l" name="54" href="#54">54</a>	<span class="c">/**
<a class="l" name="55" href="#55">55</a>	 * CuePoint constructor
<a class="l" name="56" href="#56">56</a>	 */</span>
<a class="l" name="57" href="#57">57</a>	<b>public</b> <a class="xmt" name="MetaCue"/><a href="/source/s?refs=MetaCue&amp;project=rtmp_client" class="xmt">MetaCue</a>() {
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a>	}
<a class="hl" name="60" href="#60">60</a>
<a class="l" name="61" href="#61">61</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="l" name="62" href="#62">62</a>	 */</span>
<a class="l" name="63" href="#63">63</a>	<b>public</b> <b>void</b> <a class="xmt" name="setName"/><a href="/source/s?refs=setName&amp;project=rtmp_client" class="xmt">setName</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="l" name="64" href="#64">64</a>		<b>this</b>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"name"</span>, <a class="d" href="#name">name</a>);
<a class="l" name="65" href="#65">65</a>	}
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="l" name="68" href="#68">68</a>	 */</span>
<a class="l" name="69" href="#69">69</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getName"/><a href="/source/s?refs=getName&amp;project=rtmp_client" class="xmt">getName</a>() {
<a class="hl" name="70" href="#70">70</a>		<b>return</b> (<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>) <b>this</b>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<span class="s">"name"</span>);
<a class="l" name="71" href="#71">71</a>	}
<a class="l" name="72" href="#72">72</a>
<a class="l" name="73" href="#73">73</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="l" name="74" href="#74">74</a>	 */</span>
<a class="l" name="75" href="#75">75</a>	<b>public</b> <b>void</b> <a class="xmt" name="setType"/><a href="/source/s?refs=setType&amp;project=rtmp_client" class="xmt">setType</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="type"/><a href="/source/s?refs=type&amp;project=rtmp_client" class="xa">type</a>) {
<a class="l" name="76" href="#76">76</a>		<b>this</b>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"type"</span>, <a class="d" href="#type">type</a>);
<a class="l" name="77" href="#77">77</a>	}
<a class="l" name="78" href="#78">78</a>
<a class="l" name="79" href="#79">79</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="hl" name="80" href="#80">80</a>	 */</span>
<a class="l" name="81" href="#81">81</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getType"/><a href="/source/s?refs=getType&amp;project=rtmp_client" class="xmt">getType</a>() {
<a class="l" name="82" href="#82">82</a>		<b>return</b> (<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>) <b>this</b>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<span class="s">"type"</span>);
<a class="l" name="83" href="#83">83</a>	}
<a class="l" name="84" href="#84">84</a>
<a class="l" name="85" href="#85">85</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="l" name="86" href="#86">86</a>	 */</span>
<a class="l" name="87" href="#87">87</a>	<b>public</b> <b>void</b> <a class="xmt" name="setTime"/><a href="/source/s?refs=setTime&amp;project=rtmp_client" class="xmt">setTime</a>(<b>double</b> d) {
<a class="l" name="88" href="#88">88</a>		<b>this</b>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"time"</span>, d);
<a class="l" name="89" href="#89">89</a>	}
<a class="hl" name="90" href="#90">90</a>
<a class="l" name="91" href="#91">91</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="l" name="92" href="#92">92</a>	 */</span>
<a class="l" name="93" href="#93">93</a>	<b>public</b> <b>double</b> <a class="xmt" name="getTime"/><a href="/source/s?refs=getTime&amp;project=rtmp_client" class="xmt">getTime</a>() {
<a class="l" name="94" href="#94">94</a>		<b>return</b> (<a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>) <b>this</b>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<span class="s">"time"</span>);
<a class="l" name="95" href="#95">95</a>	}
<a class="l" name="96" href="#96">96</a>
<a class="l" name="97" href="#97">97</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="98" href="#98">98</a>	<b>public</b> <b>int</b> <a class="xmt" name="compareTo"/><a href="/source/s?refs=compareTo&amp;project=rtmp_client" class="xmt">compareTo</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="arg0"/><a href="/source/s?refs=arg0&amp;project=rtmp_client" class="xa">arg0</a>) {
<a class="l" name="99" href="#99">99</a>		<a href="/source/s?defs=MetaCue&amp;project=rtmp_client">MetaCue</a>&lt;?, ?&gt; <a href="/source/s?defs=cp&amp;project=rtmp_client">cp</a> = (<a href="/source/s?defs=MetaCue&amp;project=rtmp_client">MetaCue</a>&lt;?, ?&gt;) <a class="d" href="#arg0">arg0</a>;
<a class="hl" name="100" href="#100">100</a>		<b>double</b> <a href="/source/s?defs=cpTime&amp;project=rtmp_client">cpTime</a> = <a href="/source/s?defs=cp&amp;project=rtmp_client">cp</a>.<a class="d" href="#getTime">getTime</a>();
<a class="l" name="101" href="#101">101</a>		<b>double</b> <a href="/source/s?defs=thisTime&amp;project=rtmp_client">thisTime</a> = <b>this</b>.<a class="d" href="#getTime">getTime</a>();
<a class="l" name="102" href="#102">102</a>
<a class="l" name="103" href="#103">103</a>		<b>if</b> (<a href="/source/s?defs=cpTime&amp;project=rtmp_client">cpTime</a> &gt; <a href="/source/s?defs=thisTime&amp;project=rtmp_client">thisTime</a>) {
<a class="l" name="104" href="#104">104</a>			<b>return</b> -<span class="n">1</span>;
<a class="l" name="105" href="#105">105</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=cpTime&amp;project=rtmp_client">cpTime</a> &lt; <a href="/source/s?defs=thisTime&amp;project=rtmp_client">thisTime</a>) {
<a class="l" name="106" href="#106">106</a>			<b>return</b> <span class="n">1</span>;
<a class="l" name="107" href="#107">107</a>		}
<a class="l" name="108" href="#108">108</a>
<a class="l" name="109" href="#109">109</a>		<b>return</b> <span class="n">0</span>;
<a class="hl" name="110" href="#110">110</a>	}
<a class="l" name="111" href="#111">111</a>
<a class="l" name="112" href="#112">112</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="113" href="#113">113</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="114" href="#114">114</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toString"/><a href="/source/s?refs=toString&amp;project=rtmp_client" class="xmt">toString</a>() {
<a class="l" name="115" href="#115">115</a>		<a href="/source/s?defs=StringBuilder&amp;project=rtmp_client">StringBuilder</a> <a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a> = <b>new</b> <a href="/source/s?defs=StringBuilder&amp;project=rtmp_client">StringBuilder</a>(<span class="s">"MetaCue{"</span>);
<a class="l" name="116" href="#116">116</a>		<b>for</b> (<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>.<a href="/source/s?defs=Entry&amp;project=rtmp_client">Entry</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a> : <a href="/source/s?defs=entrySet&amp;project=rtmp_client">entrySet</a>()) {
<a class="l" name="117" href="#117">117</a>			<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a>.<a href="/source/s?defs=getKey&amp;project=rtmp_client">getKey</a>().<a href="/source/s?defs=toLowerCase&amp;project=rtmp_client">toLowerCase</a>());
<a class="l" name="118" href="#118">118</a>			<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">'='</span>);
<a class="l" name="119" href="#119">119</a>			<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a>.<a href="/source/s?defs=getValue&amp;project=rtmp_client">getValue</a>());
<a class="hl" name="120" href="#120">120</a>		}
<a class="l" name="121" href="#121">121</a>		<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">'}'</span>);
<a class="l" name="122" href="#122">122</a>		<b>return</b> <a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a class="d" href="#toString">toString</a>();
<a class="l" name="123" href="#123">123</a>	}
<a class="l" name="124" href="#124">124</a>}
<a class="l" name="125" href="#125">125</a>