<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["FLVReader",56]]],["Package","xp",[["org.red5.io.flv",1]]],["Method","xmt",[["FLVReader",123],["FLVReader",132],["FLVReader",143],["FLVReader",165],["FLVReader",191],["analyzeKeyFrames",640],["close",618],["createFileMeta",535],["decodeHeader",455],["fillBuffer",287],["fillBuffer",296],["fillBuffer",309],["getAudioCodecId",510],["getBufferSize",424],["getBufferType",383],["getBytesRead",485],["getCurrentPosition",240],["getDuration",492],["getDuration",796],["getFile",471],["getFileData",446],["getOffset",478],["getRemainingBytes",206],["getTotalBytes",223],["getVideoCodecId",496],["hasMoreTags",526],["hasVideo",370],["position",756],["postInitialize",355],["readTag",578],["readTagHeader",765],["setBufferSize",433],["setBufferType",401],["setCurrentPosition",263],["setKeyFrameCache",197]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=File&amp;project=rtmp_client">File</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=FileInputStream&amp;project=rtmp_client">FileInputStream</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=RandomAccessFile&amp;project=rtmp_client">RandomAccessFile</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=channels&amp;project=rtmp_client">channels</a>.<a href="/source/s?defs=FileChannel&amp;project=rtmp_client">FileChannel</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="31" href="#31">31</a>
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=BufferType&amp;project=rtmp_client">BufferType</a>;
<a class="l" name="34" href="#34">34</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IKeyFrameMetaCache&amp;project=rtmp_client">IKeyFrameMetaCache</a>;
<a class="l" name="35" href="#35">35</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IStreamableFile&amp;project=rtmp_client">IStreamableFile</a>;
<a class="l" name="36" href="#36">36</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a>;
<a class="l" name="37" href="#37">37</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=ITagReader&amp;project=rtmp_client">ITagReader</a>;
<a class="l" name="38" href="#38">38</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>;
<a class="l" name="39" href="#39">39</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>;
<a class="hl" name="40" href="#40">40</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>;
<a class="l" name="41" href="#41">41</a><span class="c">//import org.red5.io.utils.HexDump;</span>
<a class="l" name="42" href="#42">42</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>.<a href="/source/s?defs=IOUtils&amp;project=rtmp_client">IOUtils</a>;
<a class="l" name="43" href="#43">43</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="44" href="#44">44</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a><span class="c">/**
<a class="l" name="47" href="#47">47</a> * A Reader is used to read the contents of a FLV file.
<a class="l" name="48" href="#48">48</a> * NOTE: This class is not implemented as threading-safe. The caller
<a class="l" name="49" href="#49">49</a> * should make sure the threading-safety.
<a class="hl" name="50" href="#50">50</a> *
<a class="l" name="51" href="#51">51</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="52" href="#52">52</a> * <strong>@author</strong> Dominick Accattato (daccattato@gmail.com)
<a class="l" name="53" href="#53">53</a> * <strong>@author</strong> Luke Hubbard, Codegent Ltd (luke@codegent.com)
<a class="l" name="54" href="#54">54</a> * <strong>@author</strong> Paul Gregoire, (mondain@gmail.com)
<a class="l" name="55" href="#55">55</a> */</span>
<a class="l" name="56" href="#56">56</a><b>public</b> <b>class</b> <a class="xc" name="FLVReader"/><a href="/source/s?refs=FLVReader&amp;project=rtmp_client" class="xc">FLVReader</a> <b>implements</b> <a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>, <a href="/source/s?defs=ITagReader&amp;project=rtmp_client">ITagReader</a>, <a href="/source/s?defs=IKeyFrameDataAnalyzer&amp;project=rtmp_client">IKeyFrameDataAnalyzer</a> {
<a class="l" name="57" href="#57">57</a>
<a class="l" name="58" href="#58">58</a>	<span class="c">/**
<a class="l" name="59" href="#59">59</a>	 * Logger
<a class="hl" name="60" href="#60">60</a>	 */</span>
<a class="l" name="61" href="#61">61</a>	<b>private</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a href="/source/s?defs=FLVReader&amp;project=rtmp_client">FLVReader</a>.<b>class</b>);
<a class="l" name="62" href="#62">62</a>
<a class="l" name="63" href="#63">63</a>	<span class="c">/**
<a class="l" name="64" href="#64">64</a>	 * File
<a class="l" name="65" href="#65">65</a>	 */</span>
<a class="l" name="66" href="#66">66</a>	<b>private</b> <a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a class="xfld" name="file"/><a href="/source/s?refs=file&amp;project=rtmp_client" class="xfld">file</a>;
<a class="l" name="67" href="#67">67</a>
<a class="l" name="68" href="#68">68</a>	<span class="c">/**
<a class="l" name="69" href="#69">69</a>	 * File input stream
<a class="hl" name="70" href="#70">70</a>	 */</span>
<a class="l" name="71" href="#71">71</a>	<b>private</b> <a href="/source/s?defs=FileInputStream&amp;project=rtmp_client">FileInputStream</a> <a class="xfld" name="fis"/><a href="/source/s?refs=fis&amp;project=rtmp_client" class="xfld">fis</a>;
<a class="l" name="72" href="#72">72</a>
<a class="l" name="73" href="#73">73</a>	<span class="c">/**
<a class="l" name="74" href="#74">74</a>	 * File channel
<a class="l" name="75" href="#75">75</a>	 */</span>
<a class="l" name="76" href="#76">76</a>	<b>private</b> <a href="/source/s?defs=FileChannel&amp;project=rtmp_client">FileChannel</a> <a class="xfld" name="channel"/><a href="/source/s?refs=channel&amp;project=rtmp_client" class="xfld">channel</a>;
<a class="l" name="77" href="#77">77</a>
<a class="l" name="78" href="#78">78</a>	<b>private</b> <b>long</b> <a class="xfld" name="channelSize"/><a href="/source/s?refs=channelSize&amp;project=rtmp_client" class="xfld">channelSize</a>;
<a class="l" name="79" href="#79">79</a>
<a class="hl" name="80" href="#80">80</a>	<span class="c">/**
<a class="l" name="81" href="#81">81</a>	 * Keyframe metadata
<a class="l" name="82" href="#82">82</a>	 */</span>
<a class="l" name="83" href="#83">83</a>	<b>private</b> <a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a> <a class="xfld" name="keyframeMeta"/><a href="/source/s?refs=keyframeMeta&amp;project=rtmp_client" class="xfld">keyframeMeta</a>;
<a class="l" name="84" href="#84">84</a>
<a class="l" name="85" href="#85">85</a>	<span class="c">/**
<a class="l" name="86" href="#86">86</a>	 * Input byte buffer
<a class="l" name="87" href="#87">87</a>	 */</span>
<a class="l" name="88" href="#88">88</a>	<b>private</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xfld" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xfld">in</a>;
<a class="l" name="89" href="#89">89</a>
<a class="hl" name="90" href="#90">90</a>	<span class="c">/** Set to true to generate metadata automatically before the first tag. */</span>
<a class="l" name="91" href="#91">91</a>	<b>private</b> <b>boolean</b> <a class="xfld" name="generateMetadata"/><a href="/source/s?refs=generateMetadata&amp;project=rtmp_client" class="xfld">generateMetadata</a>;
<a class="l" name="92" href="#92">92</a>
<a class="l" name="93" href="#93">93</a>	<span class="c">/** Position of first video tag. */</span>
<a class="l" name="94" href="#94">94</a>	<b>private</b> <b>long</b> <a class="xfld" name="firstVideoTag"/><a href="/source/s?refs=firstVideoTag&amp;project=rtmp_client" class="xfld">firstVideoTag</a> = -<span class="n">1</span>;
<a class="l" name="95" href="#95">95</a>
<a class="l" name="96" href="#96">96</a>	<span class="c">/** Position of first audio tag. */</span>
<a class="l" name="97" href="#97">97</a>	<b>private</b> <b>long</b> <a class="xfld" name="firstAudioTag"/><a href="/source/s?refs=firstAudioTag&amp;project=rtmp_client" class="xfld">firstAudioTag</a> = -<span class="n">1</span>;
<a class="l" name="98" href="#98">98</a>
<a class="l" name="99" href="#99">99</a>	<span class="c">/** metadata sent flag */</span>
<a class="hl" name="100" href="#100">100</a>	<b>private</b> <b>boolean</b> <a class="xfld" name="metadataSent"/><a href="/source/s?refs=metadataSent&amp;project=rtmp_client" class="xfld">metadataSent</a> = <b>false</b>;
<a class="l" name="101" href="#101">101</a>
<a class="l" name="102" href="#102">102</a>	<span class="c">/** Duration in milliseconds. */</span>
<a class="l" name="103" href="#103">103</a>	<b>private</b> <b>long</b> <a class="xfld" name="duration"/><a href="/source/s?refs=duration&amp;project=rtmp_client" class="xfld">duration</a>;
<a class="l" name="104" href="#104">104</a>
<a class="l" name="105" href="#105">105</a>	<span class="c">/** Mapping between file position and timestamp in ms. */</span>
<a class="l" name="106" href="#106">106</a>	<b>private</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>, <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt; <a class="xfld" name="posTimeMap"/><a href="/source/s?refs=posTimeMap&amp;project=rtmp_client" class="xfld">posTimeMap</a>;
<a class="l" name="107" href="#107">107</a>
<a class="l" name="108" href="#108">108</a>	<span class="c">/** Buffer type / style to use **/</span>
<a class="l" name="109" href="#109">109</a>	<b>private</b> <b>static</b> <a href="/source/s?defs=BufferType&amp;project=rtmp_client">BufferType</a> <a class="xfld" name="bufferType"/><a href="/source/s?refs=bufferType&amp;project=rtmp_client" class="xfld">bufferType</a> = <a href="/source/s?defs=BufferType&amp;project=rtmp_client">BufferType</a>.<a href="/source/s?defs=AUTO&amp;project=rtmp_client">AUTO</a>;
<a class="hl" name="110" href="#110">110</a>
<a class="l" name="111" href="#111">111</a>	<b>private</b> <b>static</b> <b>int</b> <a class="xfld" name="bufferSize"/><a href="/source/s?refs=bufferSize&amp;project=rtmp_client" class="xfld">bufferSize</a> = <span class="n">1024</span>;
<a class="l" name="112" href="#112">112</a>
<a class="l" name="113" href="#113">113</a>	<span class="c">/** Use load buffer */</span>
<a class="l" name="114" href="#114">114</a>	<b>private</b> <b>boolean</b> <a class="xfld" name="useLoadBuf"/><a href="/source/s?refs=useLoadBuf&amp;project=rtmp_client" class="xfld">useLoadBuf</a>;
<a class="l" name="115" href="#115">115</a>
<a class="l" name="116" href="#116">116</a>	<span class="c">/** Cache for keyframe informations. */</span>
<a class="l" name="117" href="#117">117</a>	<b>private</b> <b>static</b> <a href="/source/s?defs=IKeyFrameMetaCache&amp;project=rtmp_client">IKeyFrameMetaCache</a> <a class="xfld" name="keyframeCache"/><a href="/source/s?refs=keyframeCache&amp;project=rtmp_client" class="xfld">keyframeCache</a>;
<a class="l" name="118" href="#118">118</a>
<a class="l" name="119" href="#119">119</a>	<span class="c">/** The header of this FLV file. */</span>
<a class="hl" name="120" href="#120">120</a>	<b>private</b> <a href="/source/s?defs=FLVHeader&amp;project=rtmp_client">FLVHeader</a> <a class="xfld" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xfld">header</a>;
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>	<span class="c">/** Constructs a new FLVReader. */</span>
<a class="l" name="123" href="#123">123</a>	<a class="xmt" name="FLVReader"/><a href="/source/s?refs=FLVReader&amp;project=rtmp_client" class="xmt">FLVReader</a>() {
<a class="l" name="124" href="#124">124</a>	}
<a class="l" name="125" href="#125">125</a>
<a class="l" name="126" href="#126">126</a>	<span class="c">/**
<a class="l" name="127" href="#127">127</a>	 * Creates FLV reader from file input stream.
<a class="l" name="128" href="#128">128</a>	 *
<a class="l" name="129" href="#129">129</a>	 * <strong>@param</strong> f         File
<a class="hl" name="130" href="#130">130</a>	 * <strong>@throws</strong> <em>IOException</em> on error
<a class="l" name="131" href="#131">131</a>	 */</span>
<a class="l" name="132" href="#132">132</a>	<b>public</b> <a class="xmt" name="FLVReader"/><a href="/source/s?refs=FLVReader&amp;project=rtmp_client" class="xmt">FLVReader</a>(<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> f) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="133" href="#133">133</a>		<b>this</b>(f, <b>false</b>);
<a class="l" name="134" href="#134">134</a>	}
<a class="l" name="135" href="#135">135</a>
<a class="l" name="136" href="#136">136</a>	<span class="c">/**
<a class="l" name="137" href="#137">137</a>	 * Creates FLV reader from file input stream, sets up metadata generation flag.
<a class="l" name="138" href="#138">138</a>	 *
<a class="l" name="139" href="#139">139</a>	 * <strong>@param</strong> f                    File input stream
<a class="hl" name="140" href="#140">140</a>	 * <strong>@param</strong> <em>generateMetadata</em>     &lt;code&gt;true&lt;/code&gt; if metadata generation required, &lt;code&gt;false&lt;/code&gt; otherwise
<a class="l" name="141" href="#141">141</a>	 * <strong>@throws</strong> <em>IOException</em> on error
<a class="l" name="142" href="#142">142</a>	 */</span>
<a class="l" name="143" href="#143">143</a>	<b>public</b> <a class="xmt" name="FLVReader"/><a href="/source/s?refs=FLVReader&amp;project=rtmp_client" class="xmt">FLVReader</a>(<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> f, <b>boolean</b> <a class="xa" name="generateMetadata"/><a href="/source/s?refs=generateMetadata&amp;project=rtmp_client" class="xa">generateMetadata</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="144" href="#144">144</a>		<b>if</b> (<a href="/source/s?defs=null&amp;project=rtmp_client">null</a> == f) {
<a class="l" name="145" href="#145">145</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Reader was passed a null file"</span>);
<a class="l" name="146" href="#146">146</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"{}"</span>, <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=commons&amp;project=rtmp_client">commons</a>.<a href="/source/s?defs=lang&amp;project=rtmp_client">lang</a>.<a href="/source/s?defs=builder&amp;project=rtmp_client">builder</a>.<a href="/source/s?defs=ToStringBuilder&amp;project=rtmp_client">ToStringBuilder</a>.<a href="/source/s?defs=reflectionToString&amp;project=rtmp_client">reflectionToString</a>(<b>this</b>));
<a class="l" name="147" href="#147">147</a>		}
<a class="l" name="148" href="#148">148</a>
<a class="l" name="149" href="#149">149</a>		<b>this</b>.<a class="d" href="#file">file</a> = f;
<a class="hl" name="150" href="#150">150</a>		<b>this</b>.<a class="d" href="#fis">fis</a> = <b>new</b> <a href="/source/s?defs=FileInputStream&amp;project=rtmp_client">FileInputStream</a>(f);
<a class="l" name="151" href="#151">151</a>		<b>this</b>.<a href="/source/s?defs=generateMetadata&amp;project=rtmp_client">generateMetadata</a> = <a href="/source/s?defs=generateMetadata&amp;project=rtmp_client">generateMetadata</a>;
<a class="l" name="152" href="#152">152</a>		<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a> = <a class="d" href="#fis">fis</a>.<a href="/source/s?defs=getChannel&amp;project=rtmp_client">getChannel</a>();
<a class="l" name="153" href="#153">153</a>		<a class="d" href="#channelSize">channelSize</a> = <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>();
<a class="l" name="154" href="#154">154</a>		<a class="d" href="#in">in</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="155" href="#155">155</a>		<a href="/source/s?defs=fillBuffer&amp;project=rtmp_client">fillBuffer</a>();
<a class="l" name="156" href="#156">156</a>		<a class="d" href="#postInitialize">postInitialize</a>();
<a class="l" name="157" href="#157">157</a>	}
<a class="l" name="158" href="#158">158</a>
<a class="l" name="159" href="#159">159</a>	<span class="c">/**
<a class="hl" name="160" href="#160">160</a>	 * Creates FLV reader from file channel.
<a class="l" name="161" href="#161">161</a>	 *
<a class="l" name="162" href="#162">162</a>	 * <strong>@param</strong> <em>channel</em>
<a class="l" name="163" href="#163">163</a>	 * <strong>@throws</strong> <em>IOException</em> on error
<a class="l" name="164" href="#164">164</a>	 */</span>
<a class="l" name="165" href="#165">165</a>	<b>public</b> <a class="xmt" name="FLVReader"/><a href="/source/s?refs=FLVReader&amp;project=rtmp_client" class="xmt">FLVReader</a>(<a href="/source/s?defs=FileChannel&amp;project=rtmp_client">FileChannel</a> <a class="xa" name="channel"/><a href="/source/s?refs=channel&amp;project=rtmp_client" class="xa">channel</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="166" href="#166">166</a>		<b>if</b> (<a href="/source/s?defs=null&amp;project=rtmp_client">null</a> == <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>) {
<a class="l" name="167" href="#167">167</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Reader was passed a null channel"</span>);
<a class="l" name="168" href="#168">168</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"{}"</span>, <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=commons&amp;project=rtmp_client">commons</a>.<a href="/source/s?defs=lang&amp;project=rtmp_client">lang</a>.<a href="/source/s?defs=builder&amp;project=rtmp_client">builder</a>.<a href="/source/s?defs=ToStringBuilder&amp;project=rtmp_client">ToStringBuilder</a>.<a href="/source/s?defs=reflectionToString&amp;project=rtmp_client">reflectionToString</a>(<b>this</b>));
<a class="l" name="169" href="#169">169</a>		}
<a class="hl" name="170" href="#170">170</a>		<b>if</b> (!<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a href="/source/s?defs=isOpen&amp;project=rtmp_client">isOpen</a>()) {
<a class="l" name="171" href="#171">171</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Reader was passed a closed channel"</span>);
<a class="l" name="172" href="#172">172</a>			<b>return</b>;
<a class="l" name="173" href="#173">173</a>		}
<a class="l" name="174" href="#174">174</a>		<b>this</b>.<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a> = <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>;
<a class="l" name="175" href="#175">175</a>		<a class="d" href="#channelSize">channelSize</a> = <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>();
<a class="l" name="176" href="#176">176</a>		<span class="c">//log.debug("Channel size: {}", channelSize);</span>
<a class="l" name="177" href="#177">177</a>		<b>if</b> (<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a class="d" href="#position">position</a>() &gt; <span class="n">0</span>) {
<a class="l" name="178" href="#178">178</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Channel position: {}"</span>, <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a class="d" href="#position">position</a>());
<a class="l" name="179" href="#179">179</a>			<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a class="d" href="#position">position</a>(<span class="n">0</span>);
<a class="hl" name="180" href="#180">180</a>		}
<a class="l" name="181" href="#181">181</a>		<a href="/source/s?defs=fillBuffer&amp;project=rtmp_client">fillBuffer</a>();
<a class="l" name="182" href="#182">182</a>		<a class="d" href="#postInitialize">postInitialize</a>();
<a class="l" name="183" href="#183">183</a>	}
<a class="l" name="184" href="#184">184</a>
<a class="l" name="185" href="#185">185</a>	<span class="c">/**
<a class="l" name="186" href="#186">186</a>	 * Accepts mapped file bytes to construct internal members.
<a class="l" name="187" href="#187">187</a>	 *
<a class="l" name="188" href="#188">188</a>	 * <strong>@param</strong> <em>generateMetadata</em>         &lt;code&gt;true&lt;/code&gt; if metadata generation required, &lt;code&gt;false&lt;/code&gt; otherwise
<a class="l" name="189" href="#189">189</a>	 * <strong>@param</strong> <em>buffer</em>                   IoBuffer
<a class="hl" name="190" href="#190">190</a>	 */</span>
<a class="l" name="191" href="#191">191</a>	<b>public</b> <a class="xmt" name="FLVReader"/><a href="/source/s?refs=FLVReader&amp;project=rtmp_client" class="xmt">FLVReader</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="buffer"/><a href="/source/s?refs=buffer&amp;project=rtmp_client" class="xa">buffer</a>, <b>boolean</b> <a class="xa" name="generateMetadata"/><a href="/source/s?refs=generateMetadata&amp;project=rtmp_client" class="xa">generateMetadata</a>) {
<a class="l" name="192" href="#192">192</a>		<b>this</b>.<a href="/source/s?defs=generateMetadata&amp;project=rtmp_client">generateMetadata</a> = <a href="/source/s?defs=generateMetadata&amp;project=rtmp_client">generateMetadata</a>;
<a class="l" name="193" href="#193">193</a>		<a class="d" href="#in">in</a> = <a class="d" href="#buffer">buffer</a>;
<a class="l" name="194" href="#194">194</a>		<a class="d" href="#postInitialize">postInitialize</a>();
<a class="l" name="195" href="#195">195</a>	}
<a class="l" name="196" href="#196">196</a>
<a class="l" name="197" href="#197">197</a>	<b>public</b> <b>void</b> <a class="xmt" name="setKeyFrameCache"/><a href="/source/s?refs=setKeyFrameCache&amp;project=rtmp_client" class="xmt">setKeyFrameCache</a>(<a href="/source/s?defs=IKeyFrameMetaCache&amp;project=rtmp_client">IKeyFrameMetaCache</a> <a class="xa" name="keyframeCache"/><a href="/source/s?refs=keyframeCache&amp;project=rtmp_client" class="xa">keyframeCache</a>) {
<a class="l" name="198" href="#198">198</a>		<a href="/source/s?defs=FLVReader&amp;project=rtmp_client">FLVReader</a>.<a href="/source/s?defs=keyframeCache&amp;project=rtmp_client">keyframeCache</a> = <a href="/source/s?defs=keyframeCache&amp;project=rtmp_client">keyframeCache</a>;
<a class="l" name="199" href="#199">199</a>	}
<a class="hl" name="200" href="#200">200</a>
<a class="l" name="201" href="#201">201</a>	<span class="c">/**
<a class="l" name="202" href="#202">202</a>	 * Get the remaining bytes that could be read from a file or ByteBuffer.
<a class="l" name="203" href="#203">203</a>	 *
<a class="l" name="204" href="#204">204</a>	 * <strong>@return</strong>          Number of remaining bytes
<a class="l" name="205" href="#205">205</a>	 */</span>
<a class="l" name="206" href="#206">206</a>	<b>private</b> <b>long</b> <a class="xmt" name="getRemainingBytes"/><a href="/source/s?refs=getRemainingBytes&amp;project=rtmp_client" class="xmt">getRemainingBytes</a>() {
<a class="l" name="207" href="#207">207</a>		<b>if</b> (!<a class="d" href="#useLoadBuf">useLoadBuf</a>) {
<a class="l" name="208" href="#208">208</a>			<b>return</b> <a class="d" href="#in">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>();
<a class="l" name="209" href="#209">209</a>		}
<a class="hl" name="210" href="#210">210</a>		<b>try</b> {
<a class="l" name="211" href="#211">211</a>			<b>return</b> <a class="d" href="#channelSize">channelSize</a> - <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a class="d" href="#position">position</a>() + <a class="d" href="#in">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>();
<a class="l" name="212" href="#212">212</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="213" href="#213">213</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error getRemainingBytes"</span>, e);
<a class="l" name="214" href="#214">214</a>			<b>return</b> <span class="n">0</span>;
<a class="l" name="215" href="#215">215</a>		}
<a class="l" name="216" href="#216">216</a>	}
<a class="l" name="217" href="#217">217</a>
<a class="l" name="218" href="#218">218</a>	<span class="c">/**
<a class="l" name="219" href="#219">219</a>	 * Get the total readable bytes in a file or ByteBuffer.
<a class="hl" name="220" href="#220">220</a>	 *
<a class="l" name="221" href="#221">221</a>	 * <strong>@return</strong>          Total readable bytes
<a class="l" name="222" href="#222">222</a>	 */</span>
<a class="l" name="223" href="#223">223</a>	<b>public</b> <b>long</b> <a class="xmt" name="getTotalBytes"/><a href="/source/s?refs=getTotalBytes&amp;project=rtmp_client" class="xmt">getTotalBytes</a>() {
<a class="l" name="224" href="#224">224</a>		<b>if</b> (!<a class="d" href="#useLoadBuf">useLoadBuf</a>) {
<a class="l" name="225" href="#225">225</a>			<b>return</b> <a class="d" href="#in">in</a>.<a href="/source/s?defs=capacity&amp;project=rtmp_client">capacity</a>();
<a class="l" name="226" href="#226">226</a>		}
<a class="l" name="227" href="#227">227</a>		<b>try</b> {
<a class="l" name="228" href="#228">228</a>			<b>return</b> <a class="d" href="#channelSize">channelSize</a>;
<a class="l" name="229" href="#229">229</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="hl" name="230" href="#230">230</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error getTotalBytes"</span>, e);
<a class="l" name="231" href="#231">231</a>			<b>return</b> <span class="n">0</span>;
<a class="l" name="232" href="#232">232</a>		}
<a class="l" name="233" href="#233">233</a>	}
<a class="l" name="234" href="#234">234</a>
<a class="l" name="235" href="#235">235</a>	<span class="c">/**
<a class="l" name="236" href="#236">236</a>	 * Get the current position in a file or ByteBuffer.
<a class="l" name="237" href="#237">237</a>	 *
<a class="l" name="238" href="#238">238</a>	 * <strong>@return</strong>           Current position in a file
<a class="l" name="239" href="#239">239</a>	 */</span>
<a class="hl" name="240" href="#240">240</a>	<b>private</b> <b>long</b> <a class="xmt" name="getCurrentPosition"/><a href="/source/s?refs=getCurrentPosition&amp;project=rtmp_client" class="xmt">getCurrentPosition</a>() {
<a class="l" name="241" href="#241">241</a>		<b>long</b> <a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a>;
<a class="l" name="242" href="#242">242</a>		<b>if</b> (!<a class="d" href="#useLoadBuf">useLoadBuf</a>) {
<a class="l" name="243" href="#243">243</a>			<b>return</b> <a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>();
<a class="l" name="244" href="#244">244</a>		}
<a class="l" name="245" href="#245">245</a>		<b>try</b> {
<a class="l" name="246" href="#246">246</a>			<b>if</b> (<a class="d" href="#in">in</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="247" href="#247">247</a>				<a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a> = (<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a class="d" href="#position">position</a>() - <a class="d" href="#in">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>());
<a class="l" name="248" href="#248">248</a>			} <b>else</b> {
<a class="l" name="249" href="#249">249</a>				<a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a> = <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a class="d" href="#position">position</a>();
<a class="hl" name="250" href="#250">250</a>			}
<a class="l" name="251" href="#251">251</a>			<b>return</b> <a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a>;
<a class="l" name="252" href="#252">252</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="253" href="#253">253</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error getCurrentPosition"</span>, e);
<a class="l" name="254" href="#254">254</a>			<b>return</b> <span class="n">0</span>;
<a class="l" name="255" href="#255">255</a>		}
<a class="l" name="256" href="#256">256</a>	}
<a class="l" name="257" href="#257">257</a>
<a class="l" name="258" href="#258">258</a>	<span class="c">/**
<a class="l" name="259" href="#259">259</a>	 * Modifies current position.
<a class="hl" name="260" href="#260">260</a>	 *
<a class="l" name="261" href="#261">261</a>	 * <strong>@param</strong> <em>pos</em>  Current position in file
<a class="l" name="262" href="#262">262</a>	 */</span>
<a class="l" name="263" href="#263">263</a>	<b>private</b> <b>void</b> <a class="xmt" name="setCurrentPosition"/><a href="/source/s?refs=setCurrentPosition&amp;project=rtmp_client" class="xmt">setCurrentPosition</a>(<b>long</b> <a class="xa" name="pos"/><a href="/source/s?refs=pos&amp;project=rtmp_client" class="xa">pos</a>) {
<a class="l" name="264" href="#264">264</a>		<b>if</b> (<a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a> == <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>.<a href="/source/s?defs=MAX_VALUE&amp;project=rtmp_client">MAX_VALUE</a>) {
<a class="l" name="265" href="#265">265</a>			<a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a> = <a class="d" href="#file">file</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>();
<a class="l" name="266" href="#266">266</a>		}
<a class="l" name="267" href="#267">267</a>		<b>if</b> (!<a class="d" href="#useLoadBuf">useLoadBuf</a>) {
<a class="l" name="268" href="#268">268</a>			<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>((<b>int</b>) <a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a>);
<a class="l" name="269" href="#269">269</a>			<b>return</b>;
<a class="hl" name="270" href="#270">270</a>		}
<a class="l" name="271" href="#271">271</a>		<b>try</b> {
<a class="l" name="272" href="#272">272</a>			<b>if</b> (<a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a> &gt;= (<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a class="d" href="#position">position</a>() - <a class="d" href="#in">in</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>()) &amp;&amp; <a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a> &lt; <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a class="d" href="#position">position</a>()) {
<a class="l" name="273" href="#273">273</a>				<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>((<b>int</b>) (<a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a> - (<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a class="d" href="#position">position</a>() - <a class="d" href="#in">in</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>())));
<a class="l" name="274" href="#274">274</a>			} <b>else</b> {
<a class="l" name="275" href="#275">275</a>				<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a class="d" href="#position">position</a>(<a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a>);
<a class="l" name="276" href="#276">276</a>				<a href="/source/s?defs=fillBuffer&amp;project=rtmp_client">fillBuffer</a>(<a href="/source/s?defs=bufferSize&amp;project=rtmp_client">bufferSize</a>, <b>true</b>);
<a class="l" name="277" href="#277">277</a>			}
<a class="l" name="278" href="#278">278</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="279" href="#279">279</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error setCurrentPosition"</span>, e);
<a class="hl" name="280" href="#280">280</a>		}
<a class="l" name="281" href="#281">281</a>
<a class="l" name="282" href="#282">282</a>	}
<a class="l" name="283" href="#283">283</a>
<a class="l" name="284" href="#284">284</a>	<span class="c">/**
<a class="l" name="285" href="#285">285</a>	 * Loads whole buffer from file channel, with no reloading (that is, appending).
<a class="l" name="286" href="#286">286</a>	 */</span>
<a class="l" name="287" href="#287">287</a>	<b>private</b> <b>void</b> <a class="xmt" name="fillBuffer"/><a href="/source/s?refs=fillBuffer&amp;project=rtmp_client" class="xmt">fillBuffer</a>() {
<a class="l" name="288" href="#288">288</a>		<a href="/source/s?defs=fillBuffer&amp;project=rtmp_client">fillBuffer</a>(<a href="/source/s?defs=bufferSize&amp;project=rtmp_client">bufferSize</a>, <b>false</b>);
<a class="l" name="289" href="#289">289</a>	}
<a class="hl" name="290" href="#290">290</a>
<a class="l" name="291" href="#291">291</a>	<span class="c">/**
<a class="l" name="292" href="#292">292</a>	 * Loads data from channel to buffer.
<a class="l" name="293" href="#293">293</a>	 *
<a class="l" name="294" href="#294">294</a>	 * <strong>@param</strong> <em>amount</em>         Amount of data to load with no reloading
<a class="l" name="295" href="#295">295</a>	 */</span>
<a class="l" name="296" href="#296">296</a>	<b>private</b> <b>void</b> <a class="xmt" name="fillBuffer"/><a href="/source/s?refs=fillBuffer&amp;project=rtmp_client" class="xmt">fillBuffer</a>(<b>long</b> <a class="xa" name="amount"/><a href="/source/s?refs=amount&amp;project=rtmp_client" class="xa">amount</a>) {
<a class="l" name="297" href="#297">297</a>		<a href="/source/s?defs=fillBuffer&amp;project=rtmp_client">fillBuffer</a>(<a href="/source/s?defs=amount&amp;project=rtmp_client">amount</a>, <b>false</b>);
<a class="l" name="298" href="#298">298</a>	}
<a class="l" name="299" href="#299">299</a>
<a class="hl" name="300" href="#300">300</a>	<span class="c">/**
<a class="l" name="301" href="#301">301</a>	 * Load enough bytes from channel to buffer.
<a class="l" name="302" href="#302">302</a>	 * After the loading process, the caller can make sure the amount
<a class="l" name="303" href="#303">303</a>	 * in buffer is of size 'amount' if we haven't reached the end of channel.
<a class="l" name="304" href="#304">304</a>	 *
<a class="l" name="305" href="#305">305</a>	 * <strong>@param</strong> <em>amount</em> The amount of bytes in buffer after returning,
<a class="l" name="306" href="#306">306</a>	 * no larger than bufferSize
<a class="l" name="307" href="#307">307</a>	 * <strong>@param</strong> <em>reload</em> Whether to reload or append
<a class="l" name="308" href="#308">308</a>	 */</span>
<a class="l" name="309" href="#309">309</a>	<b>private</b> <b>void</b> <a class="xmt" name="fillBuffer"/><a href="/source/s?refs=fillBuffer&amp;project=rtmp_client" class="xmt">fillBuffer</a>(<b>long</b> <a class="xa" name="amount"/><a href="/source/s?refs=amount&amp;project=rtmp_client" class="xa">amount</a>, <b>boolean</b> <a class="xa" name="reload"/><a href="/source/s?refs=reload&amp;project=rtmp_client" class="xa">reload</a>) {
<a class="hl" name="310" href="#310">310</a>		<b>try</b> {
<a class="l" name="311" href="#311">311</a>			<b>if</b> (<a href="/source/s?defs=amount&amp;project=rtmp_client">amount</a> &gt; <a href="/source/s?defs=bufferSize&amp;project=rtmp_client">bufferSize</a>) {
<a class="l" name="312" href="#312">312</a>				<a href="/source/s?defs=amount&amp;project=rtmp_client">amount</a> = <a href="/source/s?defs=bufferSize&amp;project=rtmp_client">bufferSize</a>;
<a class="l" name="313" href="#313">313</a>			}
<a class="l" name="314" href="#314">314</a>			<span class="c">//log.debug("Buffering amount: {} buffer size: {}", amount, bufferSize);</span>
<a class="l" name="315" href="#315">315</a>			<span class="c">// Read all remaining bytes if the requested amount reach the end</span>
<a class="l" name="316" href="#316">316</a>			<span class="c">// of channel.</span>
<a class="l" name="317" href="#317">317</a>			<b>if</b> (<a class="d" href="#channelSize">channelSize</a> - <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a class="d" href="#position">position</a>() &lt; <a href="/source/s?defs=amount&amp;project=rtmp_client">amount</a>) {
<a class="l" name="318" href="#318">318</a>				<a href="/source/s?defs=amount&amp;project=rtmp_client">amount</a> = <a class="d" href="#channelSize">channelSize</a> - <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a class="d" href="#position">position</a>();
<a class="l" name="319" href="#319">319</a>			}
<a class="hl" name="320" href="#320">320</a>			<b>if</b> (<a class="d" href="#in">in</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="321" href="#321">321</a>				<b>switch</b> (<a href="/source/s?defs=bufferType&amp;project=rtmp_client">bufferType</a>) {
<a class="l" name="322" href="#322">322</a>					<b>case</b> <a href="/source/s?defs=HEAP&amp;project=rtmp_client">HEAP</a>:
<a class="l" name="323" href="#323">323</a>						<a class="d" href="#in">in</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<a href="/source/s?defs=bufferSize&amp;project=rtmp_client">bufferSize</a>, <b>false</b>);
<a class="l" name="324" href="#324">324</a>						<b>break</b>;
<a class="l" name="325" href="#325">325</a>					<b>case</b> <a href="/source/s?defs=DIRECT&amp;project=rtmp_client">DIRECT</a>:
<a class="l" name="326" href="#326">326</a>						<a class="d" href="#in">in</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<a href="/source/s?defs=bufferSize&amp;project=rtmp_client">bufferSize</a>, <b>true</b>);
<a class="l" name="327" href="#327">327</a>						<b>break</b>;
<a class="l" name="328" href="#328">328</a>					<b>default</b>:
<a class="l" name="329" href="#329">329</a>						<a class="d" href="#in">in</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<a href="/source/s?defs=bufferSize&amp;project=rtmp_client">bufferSize</a>);
<a class="hl" name="330" href="#330">330</a>				}
<a class="l" name="331" href="#331">331</a>				<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a href="/source/s?defs=read&amp;project=rtmp_client">read</a>(<a class="d" href="#in">in</a>.<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>());
<a class="l" name="332" href="#332">332</a>				<a class="d" href="#in">in</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="333" href="#333">333</a>				<a class="d" href="#useLoadBuf">useLoadBuf</a> = <b>true</b>;
<a class="l" name="334" href="#334">334</a>			}
<a class="l" name="335" href="#335">335</a>			<b>if</b> (!<a class="d" href="#useLoadBuf">useLoadBuf</a>) {
<a class="l" name="336" href="#336">336</a>				<b>return</b>;
<a class="l" name="337" href="#337">337</a>			}
<a class="l" name="338" href="#338">338</a>			<b>if</b> (<a class="d" href="#reload">reload</a> || <a class="d" href="#in">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>() &lt; <a href="/source/s?defs=amount&amp;project=rtmp_client">amount</a>) {
<a class="l" name="339" href="#339">339</a>				<b>if</b> (!<a class="d" href="#reload">reload</a>) {
<a class="hl" name="340" href="#340">340</a>					<a class="d" href="#in">in</a>.<a href="/source/s?defs=compact&amp;project=rtmp_client">compact</a>();
<a class="l" name="341" href="#341">341</a>				} <b>else</b> {
<a class="l" name="342" href="#342">342</a>					<a class="d" href="#in">in</a>.<a href="/source/s?defs=clear&amp;project=rtmp_client">clear</a>();
<a class="l" name="343" href="#343">343</a>				}
<a class="l" name="344" href="#344">344</a>				<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a href="/source/s?defs=read&amp;project=rtmp_client">read</a>(<a class="d" href="#in">in</a>.<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>());
<a class="l" name="345" href="#345">345</a>				<a class="d" href="#in">in</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="346" href="#346">346</a>			}
<a class="l" name="347" href="#347">347</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="348" href="#348">348</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error fillBuffer"</span>, e);
<a class="l" name="349" href="#349">349</a>		}
<a class="hl" name="350" href="#350">350</a>	}
<a class="l" name="351" href="#351">351</a>
<a class="l" name="352" href="#352">352</a>	<span class="c">/**
<a class="l" name="353" href="#353">353</a>	 * Post-initialization hook, reads keyframe metadata and decodes header (if any).
<a class="l" name="354" href="#354">354</a>	 */</span>
<a class="l" name="355" href="#355">355</a>	<b>private</b> <b>void</b> <a class="xmt" name="postInitialize"/><a href="/source/s?refs=postInitialize&amp;project=rtmp_client" class="xmt">postInitialize</a>() {
<a class="l" name="356" href="#356">356</a><span class="c">//		if (log.isDebugEnabled()) {</span>
<a class="l" name="357" href="#357">357</a><span class="c">//			//log.debug("FLVReader 1 - Buffer size: {} position: {} remaining: {}", new Object[] { getTotalBytes(), getCurrentPosition(), getRemainingBytes() });</span>
<a class="l" name="358" href="#358">358</a><span class="c">//		}</span>
<a class="l" name="359" href="#359">359</a>		<b>if</b> (<a class="d" href="#getRemainingBytes">getRemainingBytes</a>() &gt;= <span class="n">9</span>) {
<a class="hl" name="360" href="#360">360</a>			<a class="d" href="#decodeHeader">decodeHeader</a>();
<a class="l" name="361" href="#361">361</a>		}
<a class="l" name="362" href="#362">362</a>		<b>if</b> (<a class="d" href="#file">file</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="363" href="#363">363</a><span class="c">//			keyframeMeta = analyzeKeyFrames();</span>
<a class="l" name="364" href="#364">364</a>		}
<a class="l" name="365" href="#365">365</a><span class="c">//		long old = getCurrentPosition();</span>
<a class="l" name="366" href="#366">366</a>		<span class="c">//log.debug("Position: {}", old);</span>
<a class="l" name="367" href="#367">367</a>	}
<a class="l" name="368" href="#368">368</a>
<a class="l" name="369" href="#369">369</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="370" href="#370">370</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="hasVideo"/><a href="/source/s?refs=hasVideo&amp;project=rtmp_client" class="xmt">hasVideo</a>() {
<a class="l" name="371" href="#371">371</a>		<a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a> <a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a> = <a class="d" href="#analyzeKeyFrames">analyzeKeyFrames</a>();
<a class="l" name="372" href="#372">372</a>		<b>if</b> (<a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="373" href="#373">373</a>			<b>return</b> <b>false</b>;
<a class="l" name="374" href="#374">374</a>		}
<a class="l" name="375" href="#375">375</a>		<b>return</b> (!<a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a>.<a href="/source/s?defs=audioOnly&amp;project=rtmp_client">audioOnly</a> &amp;&amp; <a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> &gt; <span class="n">0</span>);
<a class="l" name="376" href="#376">376</a>	}
<a class="l" name="377" href="#377">377</a>
<a class="l" name="378" href="#378">378</a>	<span class="c">/**
<a class="l" name="379" href="#379">379</a>	 * Getter for buffer type (auto, direct or heap).
<a class="hl" name="380" href="#380">380</a>	 *
<a class="l" name="381" href="#381">381</a>	 * <strong>@return</strong> Value for property 'bufferType'
<a class="l" name="382" href="#382">382</a>	 */</span>
<a class="l" name="383" href="#383">383</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getBufferType"/><a href="/source/s?refs=getBufferType&amp;project=rtmp_client" class="xmt">getBufferType</a>() {
<a class="l" name="384" href="#384">384</a>		<b>switch</b> (<a href="/source/s?defs=bufferType&amp;project=rtmp_client">bufferType</a>) {
<a class="l" name="385" href="#385">385</a>			<b>case</b> <a href="/source/s?defs=AUTO&amp;project=rtmp_client">AUTO</a>:
<a class="l" name="386" href="#386">386</a>				<b>return</b> <span class="s">"auto"</span>;
<a class="l" name="387" href="#387">387</a>			<b>case</b> <a href="/source/s?defs=DIRECT&amp;project=rtmp_client">DIRECT</a>:
<a class="l" name="388" href="#388">388</a>				<b>return</b> <span class="s">"direct"</span>;
<a class="l" name="389" href="#389">389</a>			<b>case</b> <a href="/source/s?defs=HEAP&amp;project=rtmp_client">HEAP</a>:
<a class="hl" name="390" href="#390">390</a>				<b>return</b> <span class="s">"heap"</span>;
<a class="l" name="391" href="#391">391</a>			<b>default</b>:
<a class="l" name="392" href="#392">392</a>				<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="393" href="#393">393</a>		}
<a class="l" name="394" href="#394">394</a>	}
<a class="l" name="395" href="#395">395</a>
<a class="l" name="396" href="#396">396</a>	<span class="c">/**
<a class="l" name="397" href="#397">397</a>	 * Setter for buffer type.
<a class="l" name="398" href="#398">398</a>	 *
<a class="l" name="399" href="#399">399</a>	 * <strong>@param</strong> <em>bufferType</em> Value to set for property 'bufferType'
<a class="hl" name="400" href="#400">400</a>	 */</span>
<a class="l" name="401" href="#401">401</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="setBufferType"/><a href="/source/s?refs=setBufferType&amp;project=rtmp_client" class="xmt">setBufferType</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="bufferType"/><a href="/source/s?refs=bufferType&amp;project=rtmp_client" class="xa">bufferType</a>) {
<a class="l" name="402" href="#402">402</a>		<b>int</b> <a href="/source/s?defs=bufferTypeHash&amp;project=rtmp_client">bufferTypeHash</a> = <a href="/source/s?defs=bufferType&amp;project=rtmp_client">bufferType</a>.<a href="/source/s?defs=hashCode&amp;project=rtmp_client">hashCode</a>();
<a class="l" name="403" href="#403">403</a>		<b>switch</b> (<a href="/source/s?defs=bufferTypeHash&amp;project=rtmp_client">bufferTypeHash</a>) {
<a class="l" name="404" href="#404">404</a>			<b>case</b> <span class="n">3198444</span>: <span class="c">//heap</span>
<a class="l" name="405" href="#405">405</a>				<span class="c">//Get a heap buffer from buffer pool</span>
<a class="l" name="406" href="#406">406</a>				<a href="/source/s?defs=FLVReader&amp;project=rtmp_client">FLVReader</a>.<a href="/source/s?defs=bufferType&amp;project=rtmp_client">bufferType</a> = <a href="/source/s?defs=BufferType&amp;project=rtmp_client">BufferType</a>.<a href="/source/s?defs=HEAP&amp;project=rtmp_client">HEAP</a>;
<a class="l" name="407" href="#407">407</a>				<b>break</b>;
<a class="l" name="408" href="#408">408</a>			<b>case</b> -<span class="n">1331586071</span>: <span class="c">//direct</span>
<a class="l" name="409" href="#409">409</a>				<span class="c">//Get a direct buffer from buffer pool</span>
<a class="hl" name="410" href="#410">410</a>				<a href="/source/s?defs=FLVReader&amp;project=rtmp_client">FLVReader</a>.<a href="/source/s?defs=bufferType&amp;project=rtmp_client">bufferType</a> = <a href="/source/s?defs=BufferType&amp;project=rtmp_client">BufferType</a>.<a href="/source/s?defs=DIRECT&amp;project=rtmp_client">DIRECT</a>;
<a class="l" name="411" href="#411">411</a>				<b>break</b>;
<a class="l" name="412" href="#412">412</a>			<b>case</b> <span class="n">3005871</span>: <span class="c">//auto</span>
<a class="l" name="413" href="#413">413</a>				<span class="c">//Let MINA choose</span>
<a class="l" name="414" href="#414">414</a>			<b>default</b>:
<a class="l" name="415" href="#415">415</a>				<a href="/source/s?defs=FLVReader&amp;project=rtmp_client">FLVReader</a>.<a href="/source/s?defs=bufferType&amp;project=rtmp_client">bufferType</a> = <a href="/source/s?defs=BufferType&amp;project=rtmp_client">BufferType</a>.<a href="/source/s?defs=AUTO&amp;project=rtmp_client">AUTO</a>;
<a class="l" name="416" href="#416">416</a>		}
<a class="l" name="417" href="#417">417</a>	}
<a class="l" name="418" href="#418">418</a>
<a class="l" name="419" href="#419">419</a>	<span class="c">/**
<a class="hl" name="420" href="#420">420</a>	 * Getter for buffer size.
<a class="l" name="421" href="#421">421</a>	 *
<a class="l" name="422" href="#422">422</a>	 * <strong>@return</strong> Value for property 'bufferSize'
<a class="l" name="423" href="#423">423</a>	 */</span>
<a class="l" name="424" href="#424">424</a>	<b>public</b> <b>static</b> <b>int</b> <a class="xmt" name="getBufferSize"/><a href="/source/s?refs=getBufferSize&amp;project=rtmp_client" class="xmt">getBufferSize</a>() {
<a class="l" name="425" href="#425">425</a>		<b>return</b> <a href="/source/s?defs=bufferSize&amp;project=rtmp_client">bufferSize</a>;
<a class="l" name="426" href="#426">426</a>	}
<a class="l" name="427" href="#427">427</a>
<a class="l" name="428" href="#428">428</a>	<span class="c">/**
<a class="l" name="429" href="#429">429</a>	 * Setter for property 'bufferSize'.
<a class="hl" name="430" href="#430">430</a>	 *
<a class="l" name="431" href="#431">431</a>	 * <strong>@param</strong> <em>bufferSize</em> Value to set for property 'bufferSize'
<a class="l" name="432" href="#432">432</a>	 */</span>
<a class="l" name="433" href="#433">433</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="setBufferSize"/><a href="/source/s?refs=setBufferSize&amp;project=rtmp_client" class="xmt">setBufferSize</a>(<b>int</b> <a class="xa" name="bufferSize"/><a href="/source/s?refs=bufferSize&amp;project=rtmp_client" class="xa">bufferSize</a>) {
<a class="l" name="434" href="#434">434</a>		<span class="c">// make sure buffer size is no less than 1024 bytes.</span>
<a class="l" name="435" href="#435">435</a>		<b>if</b> (<a href="/source/s?defs=bufferSize&amp;project=rtmp_client">bufferSize</a> &lt; <span class="n">1024</span>) {
<a class="l" name="436" href="#436">436</a>			<a href="/source/s?defs=bufferSize&amp;project=rtmp_client">bufferSize</a> = <span class="n">1024</span>;
<a class="l" name="437" href="#437">437</a>		}
<a class="l" name="438" href="#438">438</a>		<a href="/source/s?defs=FLVReader&amp;project=rtmp_client">FLVReader</a>.<a href="/source/s?defs=bufferSize&amp;project=rtmp_client">bufferSize</a> = <a href="/source/s?defs=bufferSize&amp;project=rtmp_client">bufferSize</a>;
<a class="l" name="439" href="#439">439</a>	}
<a class="hl" name="440" href="#440">440</a>
<a class="l" name="441" href="#441">441</a>	<span class="c">/**
<a class="l" name="442" href="#442">442</a>	 * Returns the file buffer.
<a class="l" name="443" href="#443">443</a>	 *
<a class="l" name="444" href="#444">444</a>	 * <strong>@return</strong>  File contents as byte buffer
<a class="l" name="445" href="#445">445</a>	 */</span>
<a class="l" name="446" href="#446">446</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="getFileData"/><a href="/source/s?refs=getFileData&amp;project=rtmp_client" class="xmt">getFileData</a>() {
<a class="l" name="447" href="#447">447</a>		<span class="c">// TODO as of now, return null will disable cache</span>
<a class="l" name="448" href="#448">448</a>		<span class="c">// we need to redesign the cache architecture so that</span>
<a class="l" name="449" href="#449">449</a>		<span class="c">// the cache is layered underneath FLVReader not above it,</span>
<a class="hl" name="450" href="#450">450</a>		<span class="c">// thus both tag cache and file cache are feasible.</span>
<a class="l" name="451" href="#451">451</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="452" href="#452">452</a>	}
<a class="l" name="453" href="#453">453</a>
<a class="l" name="454" href="#454">454</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="455" href="#455">455</a>	<b>public</b> <b>void</b> <a class="xmt" name="decodeHeader"/><a href="/source/s?refs=decodeHeader&amp;project=rtmp_client" class="xmt">decodeHeader</a>() {
<a class="l" name="456" href="#456">456</a>		<span class="c">// flv header is 9 bytes</span>
<a class="l" name="457" href="#457">457</a>		<a href="/source/s?defs=fillBuffer&amp;project=rtmp_client">fillBuffer</a>(<span class="n">9</span>);
<a class="l" name="458" href="#458">458</a>		<a class="d" href="#header">header</a> = <b>new</b> <a href="/source/s?defs=FLVHeader&amp;project=rtmp_client">FLVHeader</a>();
<a class="l" name="459" href="#459">459</a>		<span class="c">// skip signature</span>
<a class="hl" name="460" href="#460">460</a>		<a class="d" href="#in">in</a>.<a href="/source/s?defs=skip&amp;project=rtmp_client">skip</a>(<span class="n">3</span>);
<a class="l" name="461" href="#461">461</a>		<a class="d" href="#header">header</a>.<a href="/source/s?defs=setVersion&amp;project=rtmp_client">setVersion</a>(<a class="d" href="#in">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>());
<a class="l" name="462" href="#462">462</a>		<a class="d" href="#header">header</a>.<a href="/source/s?defs=setTypeFlags&amp;project=rtmp_client">setTypeFlags</a>(<a class="d" href="#in">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>());
<a class="l" name="463" href="#463">463</a>		<a class="d" href="#header">header</a>.<a href="/source/s?defs=setDataOffset&amp;project=rtmp_client">setDataOffset</a>(<a class="d" href="#in">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>());
<a class="l" name="464" href="#464">464</a><span class="c">//		if (log.isDebugEnabled()) {</span>
<a class="l" name="465" href="#465">465</a><span class="c">//			//log.debug("Header: {}", header.toString());</span>
<a class="l" name="466" href="#466">466</a><span class="c">//		}</span>
<a class="l" name="467" href="#467">467</a>	}
<a class="l" name="468" href="#468">468</a>
<a class="l" name="469" href="#469">469</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="hl" name="470" href="#470">470</a>	 */</span>
<a class="l" name="471" href="#471">471</a>	<b>public</b> <a href="/source/s?defs=IStreamableFile&amp;project=rtmp_client">IStreamableFile</a> <a class="xmt" name="getFile"/><a href="/source/s?refs=getFile&amp;project=rtmp_client" class="xmt">getFile</a>() {
<a class="l" name="472" href="#472">472</a>		<span class="c">// TODO wondering if we need to have a reference</span>
<a class="l" name="473" href="#473">473</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="474" href="#474">474</a>	}
<a class="l" name="475" href="#475">475</a>
<a class="l" name="476" href="#476">476</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="l" name="477" href="#477">477</a>	 */</span>
<a class="l" name="478" href="#478">478</a>	<b>public</b> <b>int</b> <a class="xmt" name="getOffset"/><a href="/source/s?refs=getOffset&amp;project=rtmp_client" class="xmt">getOffset</a>() {
<a class="l" name="479" href="#479">479</a>		<span class="c">// XXX what's the difference from getBytesRead</span>
<a class="hl" name="480" href="#480">480</a>		<b>return</b> <span class="n">0</span>;
<a class="l" name="481" href="#481">481</a>	}
<a class="l" name="482" href="#482">482</a>
<a class="l" name="483" href="#483">483</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="l" name="484" href="#484">484</a>	 */</span>
<a class="l" name="485" href="#485">485</a>	<b>public</b> <b>long</b> <a class="xmt" name="getBytesRead"/><a href="/source/s?refs=getBytesRead&amp;project=rtmp_client" class="xmt">getBytesRead</a>() {
<a class="l" name="486" href="#486">486</a>		<span class="c">// XXX should summarize the total bytes read or</span>
<a class="l" name="487" href="#487">487</a>		<span class="c">// just the current position?</span>
<a class="l" name="488" href="#488">488</a>		<b>return</b> <a class="d" href="#getCurrentPosition">getCurrentPosition</a>();
<a class="l" name="489" href="#489">489</a>	}
<a class="hl" name="490" href="#490">490</a>
<a class="l" name="491" href="#491">491</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="492" href="#492">492</a>	<b>public</b> <b>long</b> <a class="xmt" name="getDuration"/><a href="/source/s?refs=getDuration&amp;project=rtmp_client" class="xmt">getDuration</a>() {
<a class="l" name="493" href="#493">493</a>		<b>return</b> <a class="d" href="#duration">duration</a>;
<a class="l" name="494" href="#494">494</a>	}
<a class="l" name="495" href="#495">495</a>
<a class="l" name="496" href="#496">496</a>	<b>public</b> <b>int</b> <a class="xmt" name="getVideoCodecId"/><a href="/source/s?refs=getVideoCodecId&amp;project=rtmp_client" class="xmt">getVideoCodecId</a>() {
<a class="l" name="497" href="#497">497</a>		<a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a> <a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a> = <a class="d" href="#analyzeKeyFrames">analyzeKeyFrames</a>();
<a class="l" name="498" href="#498">498</a>		<b>if</b> (<a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="499" href="#499">499</a>			<b>return</b> -<span class="n">1</span>;
<a class="hl" name="500" href="#500">500</a>		}
<a class="l" name="501" href="#501">501</a>		<b>long</b> <a href="/source/s?defs=old&amp;project=rtmp_client">old</a> = <a class="d" href="#getCurrentPosition">getCurrentPosition</a>();
<a class="l" name="502" href="#502">502</a>		<a class="d" href="#setCurrentPosition">setCurrentPosition</a>(<a class="d" href="#firstVideoTag">firstVideoTag</a>);
<a class="l" name="503" href="#503">503</a>		<a class="d" href="#readTagHeader">readTagHeader</a>();
<a class="l" name="504" href="#504">504</a>		<a href="/source/s?defs=fillBuffer&amp;project=rtmp_client">fillBuffer</a>(<span class="n">1</span>);
<a class="l" name="505" href="#505">505</a>		<b>byte</b> <a href="/source/s?defs=frametype&amp;project=rtmp_client">frametype</a> = <a class="d" href="#in">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="506" href="#506">506</a>		<a class="d" href="#setCurrentPosition">setCurrentPosition</a>(<a href="/source/s?defs=old&amp;project=rtmp_client">old</a>);
<a class="l" name="507" href="#507">507</a>		<b>return</b> <a href="/source/s?defs=frametype&amp;project=rtmp_client">frametype</a> &amp; <a href="/source/s?defs=MASK_VIDEO_CODEC&amp;project=rtmp_client">MASK_VIDEO_CODEC</a>;
<a class="l" name="508" href="#508">508</a>	}
<a class="l" name="509" href="#509">509</a>
<a class="hl" name="510" href="#510">510</a>	<b>public</b> <b>int</b> <a class="xmt" name="getAudioCodecId"/><a href="/source/s?refs=getAudioCodecId&amp;project=rtmp_client" class="xmt">getAudioCodecId</a>() {
<a class="l" name="511" href="#511">511</a>		<a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a> <a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a> = <a class="d" href="#analyzeKeyFrames">analyzeKeyFrames</a>();
<a class="l" name="512" href="#512">512</a>		<b>if</b> (<a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="513" href="#513">513</a>			<b>return</b> -<span class="n">1</span>;
<a class="l" name="514" href="#514">514</a>		}
<a class="l" name="515" href="#515">515</a>		<b>long</b> <a href="/source/s?defs=old&amp;project=rtmp_client">old</a> = <a class="d" href="#getCurrentPosition">getCurrentPosition</a>();
<a class="l" name="516" href="#516">516</a>		<a class="d" href="#setCurrentPosition">setCurrentPosition</a>(<a class="d" href="#firstAudioTag">firstAudioTag</a>);
<a class="l" name="517" href="#517">517</a>		<a class="d" href="#readTagHeader">readTagHeader</a>();
<a class="l" name="518" href="#518">518</a>		<a href="/source/s?defs=fillBuffer&amp;project=rtmp_client">fillBuffer</a>(<span class="n">1</span>);
<a class="l" name="519" href="#519">519</a>		<b>byte</b> <a href="/source/s?defs=frametype&amp;project=rtmp_client">frametype</a> = <a class="d" href="#in">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="hl" name="520" href="#520">520</a>		<a class="d" href="#setCurrentPosition">setCurrentPosition</a>(<a href="/source/s?defs=old&amp;project=rtmp_client">old</a>);
<a class="l" name="521" href="#521">521</a>		<b>return</b> <a href="/source/s?defs=frametype&amp;project=rtmp_client">frametype</a> &amp; <a href="/source/s?defs=MASK_SOUND_FORMAT&amp;project=rtmp_client">MASK_SOUND_FORMAT</a>;
<a class="l" name="522" href="#522">522</a>	}
<a class="l" name="523" href="#523">523</a>
<a class="l" name="524" href="#524">524</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="l" name="525" href="#525">525</a>	 */</span>
<a class="l" name="526" href="#526">526</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="hasMoreTags"/><a href="/source/s?refs=hasMoreTags&amp;project=rtmp_client" class="xmt">hasMoreTags</a>() {
<a class="l" name="527" href="#527">527</a>		<b>return</b> <a class="d" href="#getRemainingBytes">getRemainingBytes</a>() &gt; <span class="n">4</span>;
<a class="l" name="528" href="#528">528</a>	}
<a class="l" name="529" href="#529">529</a>
<a class="hl" name="530" href="#530">530</a>	<span class="c">/**
<a class="l" name="531" href="#531">531</a>	 * Create tag for metadata event.
<a class="l" name="532" href="#532">532</a>	 *
<a class="l" name="533" href="#533">533</a>	 * <strong>@return</strong>         Metadata event tag
<a class="l" name="534" href="#534">534</a>	 */</span>
<a class="l" name="535" href="#535">535</a>	<b>private</b> <a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a class="xmt" name="createFileMeta"/><a href="/source/s?refs=createFileMeta&amp;project=rtmp_client" class="xmt">createFileMeta</a>() {
<a class="l" name="536" href="#536">536</a>		<span class="c">// Create tag for onMetaData event</span>
<a class="l" name="537" href="#537">537</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">1024</span>);
<a class="l" name="538" href="#538">538</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="539" href="#539">539</a>		<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <b>new</b> <a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="hl" name="540" href="#540">540</a>		<span class="c">// Duration property</span>
<a class="l" name="541" href="#541">541</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=writeString&amp;project=rtmp_client">writeString</a>(<span class="s">"onMetaData"</span>);
<a class="l" name="542" href="#542">542</a>		<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=props&amp;project=rtmp_client">props</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="l" name="543" href="#543">543</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"duration"</span>, <a class="d" href="#duration">duration</a> / <span class="n">1000.0</span>);
<a class="l" name="544" href="#544">544</a>		<b>if</b> (<a class="d" href="#firstVideoTag">firstVideoTag</a> != -<span class="n">1</span>) {
<a class="l" name="545" href="#545">545</a>			<b>long</b> <a href="/source/s?defs=old&amp;project=rtmp_client">old</a> = <a class="d" href="#getCurrentPosition">getCurrentPosition</a>();
<a class="l" name="546" href="#546">546</a>			<a class="d" href="#setCurrentPosition">setCurrentPosition</a>(<a class="d" href="#firstVideoTag">firstVideoTag</a>);
<a class="l" name="547" href="#547">547</a>			<a class="d" href="#readTagHeader">readTagHeader</a>();
<a class="l" name="548" href="#548">548</a>			<a href="/source/s?defs=fillBuffer&amp;project=rtmp_client">fillBuffer</a>(<span class="n">1</span>);
<a class="l" name="549" href="#549">549</a>			<b>byte</b> <a href="/source/s?defs=frametype&amp;project=rtmp_client">frametype</a> = <a class="d" href="#in">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="hl" name="550" href="#550">550</a>			<span class="c">// Video codec id</span>
<a class="l" name="551" href="#551">551</a>			<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"videocodecid"</span>, <a href="/source/s?defs=frametype&amp;project=rtmp_client">frametype</a> &amp; <a href="/source/s?defs=MASK_VIDEO_CODEC&amp;project=rtmp_client">MASK_VIDEO_CODEC</a>);
<a class="l" name="552" href="#552">552</a>			<a class="d" href="#setCurrentPosition">setCurrentPosition</a>(<a href="/source/s?defs=old&amp;project=rtmp_client">old</a>);
<a class="l" name="553" href="#553">553</a>		}
<a class="l" name="554" href="#554">554</a>		<b>if</b> (<a class="d" href="#firstAudioTag">firstAudioTag</a> != -<span class="n">1</span>) {
<a class="l" name="555" href="#555">555</a>			<b>long</b> <a href="/source/s?defs=old&amp;project=rtmp_client">old</a> = <a class="d" href="#getCurrentPosition">getCurrentPosition</a>();
<a class="l" name="556" href="#556">556</a>			<a class="d" href="#setCurrentPosition">setCurrentPosition</a>(<a class="d" href="#firstAudioTag">firstAudioTag</a>);
<a class="l" name="557" href="#557">557</a>			<a class="d" href="#readTagHeader">readTagHeader</a>();
<a class="l" name="558" href="#558">558</a>			<a href="/source/s?defs=fillBuffer&amp;project=rtmp_client">fillBuffer</a>(<span class="n">1</span>);
<a class="l" name="559" href="#559">559</a>			<b>byte</b> <a href="/source/s?defs=frametype&amp;project=rtmp_client">frametype</a> = <a class="d" href="#in">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="hl" name="560" href="#560">560</a>			<span class="c">// Audio codec id</span>
<a class="l" name="561" href="#561">561</a>			<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"audiocodecid"</span>, (<a href="/source/s?defs=frametype&amp;project=rtmp_client">frametype</a> &amp; <a href="/source/s?defs=MASK_SOUND_FORMAT&amp;project=rtmp_client">MASK_SOUND_FORMAT</a>) &gt;&gt; <span class="n">4</span>);
<a class="l" name="562" href="#562">562</a>			<a class="d" href="#setCurrentPosition">setCurrentPosition</a>(<a href="/source/s?defs=old&amp;project=rtmp_client">old</a>);
<a class="l" name="563" href="#563">563</a>		}
<a class="l" name="564" href="#564">564</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"canSeekToEnd"</span>, <b>true</b>);
<a class="l" name="565" href="#565">565</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=writeMap&amp;project=rtmp_client">writeMap</a>(<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>, <b>new</b> <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>());
<a class="l" name="566" href="#566">566</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="567" href="#567">567</a>
<a class="l" name="568" href="#568">568</a>		<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>new</b> <a href="/source/s?defs=Tag&amp;project=rtmp_client">Tag</a>(<a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=TYPE_METADATA&amp;project=rtmp_client">TYPE_METADATA</a>, <span class="n">0</span>, <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(), <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <span class="n">0</span>);
<a class="l" name="569" href="#569">569</a>		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=setBody&amp;project=rtmp_client">setBody</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="hl" name="570" href="#570">570</a>		<a class="d" href="#metadataSent">metadataSent</a> = <b>true</b>;
<a class="l" name="571" href="#571">571</a>		<span class="c">//</span>
<a class="l" name="572" href="#572">572</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="573" href="#573">573</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="574" href="#574">574</a>	}
<a class="l" name="575" href="#575">575</a>
<a class="l" name="576" href="#576">576</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="l" name="577" href="#577">577</a>	 */</span>
<a class="l" name="578" href="#578">578</a>	<b>public</b> <b>synchronized</b> <a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a class="xmt" name="readTag"/><a href="/source/s?refs=readTag&amp;project=rtmp_client" class="xmt">readTag</a>() {
<a class="l" name="579" href="#579">579</a>		<b>long</b> <a href="/source/s?defs=oldPos&amp;project=rtmp_client">oldPos</a> = <a class="d" href="#getCurrentPosition">getCurrentPosition</a>();
<a class="hl" name="580" href="#580">580</a>		<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a> = <a class="d" href="#readTagHeader">readTagHeader</a>();
<a class="l" name="581" href="#581">581</a><span class="c">//		log.debug("readTag, oldPos: {}, tag header: \n{}", oldPos, tag);</span>
<a class="l" name="582" href="#582">582</a>		<b>if</b> (!<a class="d" href="#metadataSent">metadataSent</a> &amp;&amp; <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>() != <a href="/source/s?defs=TYPE_METADATA&amp;project=rtmp_client">TYPE_METADATA</a> &amp;&amp; <a href="/source/s?defs=generateMetadata&amp;project=rtmp_client">generateMetadata</a>) {
<a class="l" name="583" href="#583">583</a>			<span class="c">// Generate initial metadata automatically</span>
<a class="l" name="584" href="#584">584</a>			<a class="d" href="#setCurrentPosition">setCurrentPosition</a>(<a href="/source/s?defs=oldPos&amp;project=rtmp_client">oldPos</a>);
<a class="l" name="585" href="#585">585</a>			<a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a> <a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a> = <a class="d" href="#analyzeKeyFrames">analyzeKeyFrames</a>();
<a class="l" name="586" href="#586">586</a>			<b>if</b> (<a href="/source/s?defs=meta&amp;project=rtmp_client">meta</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="587" href="#587">587</a>				<b>return</b> <a class="d" href="#createFileMeta">createFileMeta</a>();
<a class="l" name="588" href="#588">588</a>			}
<a class="l" name="589" href="#589">589</a>		}
<a class="hl" name="590" href="#590">590</a>		<b>int</b> <a href="/source/s?defs=bodySize&amp;project=rtmp_client">bodySize</a> = <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getBodySize&amp;project=rtmp_client">getBodySize</a>();
<a class="l" name="591" href="#591">591</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=body&amp;project=rtmp_client">body</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<a href="/source/s?defs=bodySize&amp;project=rtmp_client">bodySize</a>, <b>false</b>);
<a class="l" name="592" href="#592">592</a>		<span class="c">// XXX Paul: this assists in 'properly' handling damaged FLV files</span>
<a class="l" name="593" href="#593">593</a>		<b>long</b> <a href="/source/s?defs=newPosition&amp;project=rtmp_client">newPosition</a> = <a class="d" href="#getCurrentPosition">getCurrentPosition</a>() + <a href="/source/s?defs=bodySize&amp;project=rtmp_client">bodySize</a>;
<a class="l" name="594" href="#594">594</a>		<b>if</b> (<a href="/source/s?defs=newPosition&amp;project=rtmp_client">newPosition</a> &lt;= <a class="d" href="#getTotalBytes">getTotalBytes</a>()) {
<a class="l" name="595" href="#595">595</a>			<b>int</b> <a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>;
<a class="l" name="596" href="#596">596</a>			<b>while</b> (<a class="d" href="#getCurrentPosition">getCurrentPosition</a>() &lt; <a href="/source/s?defs=newPosition&amp;project=rtmp_client">newPosition</a>) {
<a class="l" name="597" href="#597">597</a>				<a href="/source/s?defs=fillBuffer&amp;project=rtmp_client">fillBuffer</a>(<a href="/source/s?defs=newPosition&amp;project=rtmp_client">newPosition</a> - <a class="d" href="#getCurrentPosition">getCurrentPosition</a>());
<a class="l" name="598" href="#598">598</a>				<b>if</b> (<a class="d" href="#getCurrentPosition">getCurrentPosition</a>() + <a class="d" href="#in">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>() &gt; <a href="/source/s?defs=newPosition&amp;project=rtmp_client">newPosition</a>) {
<a class="l" name="599" href="#599">599</a>					<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a> = <a class="d" href="#in">in</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>();
<a class="hl" name="600" href="#600">600</a>					<a class="d" href="#in">in</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>((<b>int</b>) (<a href="/source/s?defs=newPosition&amp;project=rtmp_client">newPosition</a> - <a class="d" href="#getCurrentPosition">getCurrentPosition</a>()) + <a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>());
<a class="l" name="601" href="#601">601</a>					<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#in">in</a>);
<a class="l" name="602" href="#602">602</a>					<a class="d" href="#in">in</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>);
<a class="l" name="603" href="#603">603</a>				} <b>else</b> {
<a class="l" name="604" href="#604">604</a>					<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#in">in</a>);
<a class="l" name="605" href="#605">605</a>				}
<a class="l" name="606" href="#606">606</a>			}
<a class="l" name="607" href="#607">607</a>			<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="608" href="#608">608</a>			<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=setBody&amp;project=rtmp_client">setBody</a>(<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>);
<a class="l" name="609" href="#609">609</a>		}
<a class="hl" name="610" href="#610">610</a>		<b>if</b> (<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>() == <a href="/source/s?defs=TYPE_METADATA&amp;project=rtmp_client">TYPE_METADATA</a>) {
<a class="l" name="611" href="#611">611</a>			<a class="d" href="#metadataSent">metadataSent</a> = <b>true</b>;
<a class="l" name="612" href="#612">612</a>		}
<a class="l" name="613" href="#613">613</a>		<b>return</b> <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>;
<a class="l" name="614" href="#614">614</a>	}
<a class="l" name="615" href="#615">615</a>
<a class="l" name="616" href="#616">616</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="l" name="617" href="#617">617</a>	 */</span>
<a class="l" name="618" href="#618">618</a>	<b>public</b> <b>void</b> <a class="xmt" name="close"/><a href="/source/s?refs=close&amp;project=rtmp_client" class="xmt">close</a>() {
<a class="l" name="619" href="#619">619</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Reader close"</span>);
<a class="hl" name="620" href="#620">620</a>		<b>if</b> (<a class="d" href="#in">in</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="621" href="#621">621</a>			<a class="d" href="#in">in</a>.<a href="/source/s?defs=free&amp;project=rtmp_client">free</a>();
<a class="l" name="622" href="#622">622</a>			<a class="d" href="#in">in</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="623" href="#623">623</a>		}
<a class="l" name="624" href="#624">624</a>		<b>if</b> (<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="625" href="#625">625</a>			<b>try</b> {
<a class="l" name="626" href="#626">626</a>				<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a class="d" href="#close">close</a>();
<a class="l" name="627" href="#627">627</a>				<a class="d" href="#fis">fis</a>.<a class="d" href="#close">close</a>();
<a class="l" name="628" href="#628">628</a>			} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> e) {
<a class="l" name="629" href="#629">629</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"FLVReader :: close ::&gt;\n"</span>, e);
<a class="hl" name="630" href="#630">630</a>			}
<a class="l" name="631" href="#631">631</a>		}
<a class="l" name="632" href="#632">632</a>	}
<a class="l" name="633" href="#633">633</a>
<a class="l" name="634" href="#634">634</a>	<span class="c">/**
<a class="l" name="635" href="#635">635</a>	 * Key frames analysis may be used as a utility method so
<a class="l" name="636" href="#636">636</a>	 * synchronize it.
<a class="l" name="637" href="#637">637</a>	 *
<a class="l" name="638" href="#638">638</a>	 * <strong>@return</strong>             Keyframe metadata
<a class="l" name="639" href="#639">639</a>	 */</span>
<a class="hl" name="640" href="#640">640</a>	<b>public</b> <b>synchronized</b> <a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a> <a class="xmt" name="analyzeKeyFrames"/><a href="/source/s?refs=analyzeKeyFrames&amp;project=rtmp_client" class="xmt">analyzeKeyFrames</a>() {
<a class="l" name="641" href="#641">641</a>		<b>if</b> (<a class="d" href="#keyframeMeta">keyframeMeta</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="642" href="#642">642</a>			<b>return</b> <a class="d" href="#keyframeMeta">keyframeMeta</a>;
<a class="l" name="643" href="#643">643</a>		}
<a class="l" name="644" href="#644">644</a>		<span class="c">// check for cached keyframe informations</span>
<a class="l" name="645" href="#645">645</a>		<b>if</b> (<a href="/source/s?defs=keyframeCache&amp;project=rtmp_client">keyframeCache</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="646" href="#646">646</a>			<a class="d" href="#keyframeMeta">keyframeMeta</a> = <a href="/source/s?defs=keyframeCache&amp;project=rtmp_client">keyframeCache</a>.<a href="/source/s?defs=loadKeyFrameMeta&amp;project=rtmp_client">loadKeyFrameMeta</a>(<a class="d" href="#file">file</a>);
<a class="l" name="647" href="#647">647</a>			<b>if</b> (<a class="d" href="#keyframeMeta">keyframeMeta</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="648" href="#648">648</a>				<span class="c">// Keyframe data loaded, create other mappings</span>
<a class="l" name="649" href="#649">649</a>				<a class="d" href="#duration">duration</a> = <a class="d" href="#keyframeMeta">keyframeMeta</a>.<a class="d" href="#duration">duration</a>;
<a class="hl" name="650" href="#650">650</a>				<a class="d" href="#posTimeMap">posTimeMap</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>, <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt;();
<a class="l" name="651" href="#651">651</a>				<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#keyframeMeta">keyframeMeta</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>; i++) {
<a class="l" name="652" href="#652">652</a>					<a class="d" href="#posTimeMap">posTimeMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#keyframeMeta">keyframeMeta</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a>[i], (<b>long</b>) <a class="d" href="#keyframeMeta">keyframeMeta</a>.<a href="/source/s?defs=timestamps&amp;project=rtmp_client">timestamps</a>[i]);
<a class="l" name="653" href="#653">653</a>				}
<a class="l" name="654" href="#654">654</a>				<b>return</b> <a class="d" href="#keyframeMeta">keyframeMeta</a>;
<a class="l" name="655" href="#655">655</a>			}
<a class="l" name="656" href="#656">656</a>		}
<a class="l" name="657" href="#657">657</a>		<span class="c">// Lists of video positions and timestamps</span>
<a class="l" name="658" href="#658">658</a>		<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt; <a href="/source/s?defs=positionList&amp;project=rtmp_client">positionList</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt;();
<a class="l" name="659" href="#659">659</a>		<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt; <a href="/source/s?defs=timestampList&amp;project=rtmp_client">timestampList</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt;();
<a class="hl" name="660" href="#660">660</a>		<span class="c">// Lists of audio positions and timestamps</span>
<a class="l" name="661" href="#661">661</a>		<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt; <a href="/source/s?defs=audioPositionList&amp;project=rtmp_client">audioPositionList</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt;();
<a class="l" name="662" href="#662">662</a>		<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt; <a href="/source/s?defs=audioTimestampList&amp;project=rtmp_client">audioTimestampList</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt;();
<a class="l" name="663" href="#663">663</a>		<b>long</b> <a href="/source/s?defs=origPos&amp;project=rtmp_client">origPos</a> = <a class="d" href="#getCurrentPosition">getCurrentPosition</a>();
<a class="l" name="664" href="#664">664</a>		<span class="c">// point to the first tag</span>
<a class="l" name="665" href="#665">665</a>		<a class="d" href="#setCurrentPosition">setCurrentPosition</a>(<span class="n">9</span>);
<a class="l" name="666" href="#666">666</a>
<a class="l" name="667" href="#667">667</a>		<b>boolean</b> <a href="/source/s?defs=audioOnly&amp;project=rtmp_client">audioOnly</a> = <b>true</b>;
<a class="l" name="668" href="#668">668</a>		<b>while</b> (<b>this</b>.<a class="d" href="#hasMoreTags">hasMoreTags</a>()) {
<a class="l" name="669" href="#669">669</a>			<b>long</b> <a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a> = <a class="d" href="#getCurrentPosition">getCurrentPosition</a>();
<a class="hl" name="670" href="#670">670</a>			<span class="c">// Read tag header and duration</span>
<a class="l" name="671" href="#671">671</a>			<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a href="/source/s?defs=tmpTag&amp;project=rtmp_client">tmpTag</a> = <b>this</b>.<a class="d" href="#readTagHeader">readTagHeader</a>();
<a class="l" name="672" href="#672">672</a>			<a class="d" href="#duration">duration</a> = <a href="/source/s?defs=tmpTag&amp;project=rtmp_client">tmpTag</a>.<a href="/source/s?defs=getTimestamp&amp;project=rtmp_client">getTimestamp</a>();
<a class="l" name="673" href="#673">673</a>			<b>if</b> (<a href="/source/s?defs=tmpTag&amp;project=rtmp_client">tmpTag</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>() == <a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=TYPE_VIDEO&amp;project=rtmp_client">TYPE_VIDEO</a>) {
<a class="l" name="674" href="#674">674</a>				<b>if</b> (<a href="/source/s?defs=audioOnly&amp;project=rtmp_client">audioOnly</a>) {
<a class="l" name="675" href="#675">675</a>					<a href="/source/s?defs=audioOnly&amp;project=rtmp_client">audioOnly</a> = <b>false</b>;
<a class="l" name="676" href="#676">676</a>					<a href="/source/s?defs=audioPositionList&amp;project=rtmp_client">audioPositionList</a>.<a href="/source/s?defs=clear&amp;project=rtmp_client">clear</a>();
<a class="l" name="677" href="#677">677</a>					<a href="/source/s?defs=audioTimestampList&amp;project=rtmp_client">audioTimestampList</a>.<a href="/source/s?defs=clear&amp;project=rtmp_client">clear</a>();
<a class="l" name="678" href="#678">678</a>				}
<a class="l" name="679" href="#679">679</a>				<b>if</b> (<a class="d" href="#firstVideoTag">firstVideoTag</a> == -<span class="n">1</span>) {
<a class="hl" name="680" href="#680">680</a>					<a class="d" href="#firstVideoTag">firstVideoTag</a> = <a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a>;
<a class="l" name="681" href="#681">681</a>				}
<a class="l" name="682" href="#682">682</a>
<a class="l" name="683" href="#683">683</a>				<span class="c">// Grab Frame type</span>
<a class="l" name="684" href="#684">684</a>				<a href="/source/s?defs=fillBuffer&amp;project=rtmp_client">fillBuffer</a>(<span class="n">1</span>);
<a class="l" name="685" href="#685">685</a>				<b>byte</b> <a href="/source/s?defs=frametype&amp;project=rtmp_client">frametype</a> = <a class="d" href="#in">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="686" href="#686">686</a>				<b>if</b> (((<a href="/source/s?defs=frametype&amp;project=rtmp_client">frametype</a> &amp; <a href="/source/s?defs=MASK_VIDEO_FRAMETYPE&amp;project=rtmp_client">MASK_VIDEO_FRAMETYPE</a>) &gt;&gt; <span class="n">4</span>) == <a href="/source/s?defs=FLAG_FRAMETYPE_KEYFRAME&amp;project=rtmp_client">FLAG_FRAMETYPE_KEYFRAME</a>) {
<a class="l" name="687" href="#687">687</a>					<a href="/source/s?defs=positionList&amp;project=rtmp_client">positionList</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a>);
<a class="l" name="688" href="#688">688</a>					<a href="/source/s?defs=timestampList&amp;project=rtmp_client">timestampList</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=tmpTag&amp;project=rtmp_client">tmpTag</a>.<a href="/source/s?defs=getTimestamp&amp;project=rtmp_client">getTimestamp</a>());
<a class="l" name="689" href="#689">689</a>				}
<a class="hl" name="690" href="#690">690</a>
<a class="l" name="691" href="#691">691</a>			} <b>else</b> <b>if</b> (<a href="/source/s?defs=tmpTag&amp;project=rtmp_client">tmpTag</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>() == <a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=TYPE_AUDIO&amp;project=rtmp_client">TYPE_AUDIO</a>) {
<a class="l" name="692" href="#692">692</a>				<b>if</b> (<a class="d" href="#firstAudioTag">firstAudioTag</a> == -<span class="n">1</span>) {
<a class="l" name="693" href="#693">693</a>					<a class="d" href="#firstAudioTag">firstAudioTag</a> = <a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a>;
<a class="l" name="694" href="#694">694</a>				}
<a class="l" name="695" href="#695">695</a>				<b>if</b> (<a href="/source/s?defs=audioOnly&amp;project=rtmp_client">audioOnly</a>) {
<a class="l" name="696" href="#696">696</a>					<a href="/source/s?defs=audioPositionList&amp;project=rtmp_client">audioPositionList</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a>);
<a class="l" name="697" href="#697">697</a>					<a href="/source/s?defs=audioTimestampList&amp;project=rtmp_client">audioTimestampList</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=tmpTag&amp;project=rtmp_client">tmpTag</a>.<a href="/source/s?defs=getTimestamp&amp;project=rtmp_client">getTimestamp</a>());
<a class="l" name="698" href="#698">698</a>				}
<a class="l" name="699" href="#699">699</a>			}
<a class="hl" name="700" href="#700">700</a>			<span class="c">// XXX Paul: this 'properly' handles damaged FLV files - as far as</span>
<a class="l" name="701" href="#701">701</a>			<span class="c">// <a href="/source/s?path=duration/">duration</a>/<a href="/source/s?path=duration/size">size</a> is concerned</span>
<a class="l" name="702" href="#702">702</a>			<b>long</b> <a href="/source/s?defs=newPosition&amp;project=rtmp_client">newPosition</a> = <a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a> + <a href="/source/s?defs=tmpTag&amp;project=rtmp_client">tmpTag</a>.<a href="/source/s?defs=getBodySize&amp;project=rtmp_client">getBodySize</a>() + <span class="n">15</span>;
<a class="l" name="703" href="#703">703</a>			<span class="c">// log.debug("----&gt;" + in.remaining() + " limit=" + in.limit() + "</span>
<a class="l" name="704" href="#704">704</a>			<span class="c">// new pos=" + newPosition);</span>
<a class="l" name="705" href="#705">705</a>			<b>if</b> (<a href="/source/s?defs=newPosition&amp;project=rtmp_client">newPosition</a> &gt;= <a class="d" href="#getTotalBytes">getTotalBytes</a>()) {
<a class="l" name="706" href="#706">706</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"New position exceeds limit"</span>);
<a class="l" name="707" href="#707">707</a><span class="c">//				if (log.isDebugEnabled()) {</span>
<a class="l" name="708" href="#708">708</a><span class="c">//					log.debug("-----");</span>
<a class="l" name="709" href="#709">709</a><span class="c">//					log.debug("Keyframe analysis");</span>
<a class="hl" name="710" href="#710">710</a><span class="c">//					log.debug(" data type=" + tmpTag.getDataType() + " bodysize=" + tmpTag.getBodySize());</span>
<a class="l" name="711" href="#711">711</a><span class="c">//					log.debug(" remaining=" + getRemainingBytes() + " limit=" + getTotalBytes() + " new pos=" + newPosition);</span>
<a class="l" name="712" href="#712">712</a><span class="c">//					log.debug(" pos=" + pos);</span>
<a class="l" name="713" href="#713">713</a><span class="c">//					log.debug("-----");</span>
<a class="l" name="714" href="#714">714</a><span class="c">//				}</span>
<a class="l" name="715" href="#715">715</a><span class="c">//				//XXX Paul: A runtime exception is probably not needed here</span>
<a class="l" name="716" href="#716">716</a><span class="c">//				log.info("New position {} exceeds limit {}", newPosition, getTotalBytes());</span>
<a class="l" name="717" href="#717">717</a>				<span class="c">//just break from the loop</span>
<a class="l" name="718" href="#718">718</a>				<b>break</b>;
<a class="l" name="719" href="#719">719</a>			} <b>else</b> {
<a class="hl" name="720" href="#720">720</a>				<a class="d" href="#setCurrentPosition">setCurrentPosition</a>(<a href="/source/s?defs=newPosition&amp;project=rtmp_client">newPosition</a>);
<a class="l" name="721" href="#721">721</a>			}
<a class="l" name="722" href="#722">722</a>		}
<a class="l" name="723" href="#723">723</a>		<span class="c">// restore the pos</span>
<a class="l" name="724" href="#724">724</a>		<a class="d" href="#setCurrentPosition">setCurrentPosition</a>(<a href="/source/s?defs=origPos&amp;project=rtmp_client">origPos</a>);
<a class="l" name="725" href="#725">725</a>
<a class="l" name="726" href="#726">726</a>		<a class="d" href="#keyframeMeta">keyframeMeta</a> = <b>new</b> <a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a>();
<a class="l" name="727" href="#727">727</a>		<a class="d" href="#keyframeMeta">keyframeMeta</a>.<a class="d" href="#duration">duration</a> = <a class="d" href="#duration">duration</a>;
<a class="l" name="728" href="#728">728</a>		<a class="d" href="#posTimeMap">posTimeMap</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>, <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt;();
<a class="l" name="729" href="#729">729</a>		<b>if</b> (<a href="/source/s?defs=audioOnly&amp;project=rtmp_client">audioOnly</a>) {
<a class="hl" name="730" href="#730">730</a>			<span class="c">// The flv only contains audio tags, use their lists</span>
<a class="l" name="731" href="#731">731</a>			<span class="c">// to support pause and seeking</span>
<a class="l" name="732" href="#732">732</a>			<a href="/source/s?defs=positionList&amp;project=rtmp_client">positionList</a> = <a href="/source/s?defs=audioPositionList&amp;project=rtmp_client">audioPositionList</a>;
<a class="l" name="733" href="#733">733</a>			<a href="/source/s?defs=timestampList&amp;project=rtmp_client">timestampList</a> = <a href="/source/s?defs=audioTimestampList&amp;project=rtmp_client">audioTimestampList</a>;
<a class="l" name="734" href="#734">734</a>		}
<a class="l" name="735" href="#735">735</a>		<a class="d" href="#keyframeMeta">keyframeMeta</a>.<a href="/source/s?defs=audioOnly&amp;project=rtmp_client">audioOnly</a> = <a href="/source/s?defs=audioOnly&amp;project=rtmp_client">audioOnly</a>;
<a class="l" name="736" href="#736">736</a>		<a class="d" href="#keyframeMeta">keyframeMeta</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a> = <b>new</b> <b>long</b>[<a href="/source/s?defs=positionList&amp;project=rtmp_client">positionList</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>()];
<a class="l" name="737" href="#737">737</a>		<a class="d" href="#keyframeMeta">keyframeMeta</a>.<a href="/source/s?defs=timestamps&amp;project=rtmp_client">timestamps</a> = <b>new</b> <b>int</b>[<a href="/source/s?defs=timestampList&amp;project=rtmp_client">timestampList</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>()];
<a class="l" name="738" href="#738">738</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#keyframeMeta">keyframeMeta</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>; i++) {
<a class="l" name="739" href="#739">739</a>			<a class="d" href="#keyframeMeta">keyframeMeta</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a>[i] = <a href="/source/s?defs=positionList&amp;project=rtmp_client">positionList</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(i);
<a class="hl" name="740" href="#740">740</a>			<a class="d" href="#keyframeMeta">keyframeMeta</a>.<a href="/source/s?defs=timestamps&amp;project=rtmp_client">timestamps</a>[i] = <a href="/source/s?defs=timestampList&amp;project=rtmp_client">timestampList</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(i);
<a class="l" name="741" href="#741">741</a>			<a class="d" href="#posTimeMap">posTimeMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>long</b>) <a href="/source/s?defs=positionList&amp;project=rtmp_client">positionList</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(i), (<b>long</b>) <a href="/source/s?defs=timestampList&amp;project=rtmp_client">timestampList</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(i));
<a class="l" name="742" href="#742">742</a>		}
<a class="l" name="743" href="#743">743</a>		<b>if</b> (<a href="/source/s?defs=keyframeCache&amp;project=rtmp_client">keyframeCache</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="744" href="#744">744</a>			<a href="/source/s?defs=keyframeCache&amp;project=rtmp_client">keyframeCache</a>.<a href="/source/s?defs=saveKeyFrameMeta&amp;project=rtmp_client">saveKeyFrameMeta</a>(<a class="d" href="#file">file</a>, <a class="d" href="#keyframeMeta">keyframeMeta</a>);
<a class="l" name="745" href="#745">745</a>		}
<a class="l" name="746" href="#746">746</a>		<b>return</b> <a class="d" href="#keyframeMeta">keyframeMeta</a>;
<a class="l" name="747" href="#747">747</a>	}
<a class="l" name="748" href="#748">748</a>
<a class="l" name="749" href="#749">749</a>	<span class="c">/**
<a class="hl" name="750" href="#750">750</a>	 * Put the current position to pos.
<a class="l" name="751" href="#751">751</a>	 * The caller must ensure the pos is a valid one
<a class="l" name="752" href="#752">752</a>	 * (eg. not sit in the middle of a frame).
<a class="l" name="753" href="#753">753</a>	 *
<a class="l" name="754" href="#754">754</a>	 * <strong>@param</strong> <em>pos</em>         New position in file. Pass &lt;code&gt;Long.MAX_VALUE&lt;/code&gt; to seek to end of file.
<a class="l" name="755" href="#755">755</a>	 */</span>
<a class="l" name="756" href="#756">756</a>	<b>public</b> <b>void</b> <a class="xmt" name="position"/><a href="/source/s?refs=position&amp;project=rtmp_client" class="xmt">position</a>(<b>long</b> <a class="xa" name="pos"/><a href="/source/s?refs=pos&amp;project=rtmp_client" class="xa">pos</a>) {
<a class="l" name="757" href="#757">757</a>		<a class="d" href="#setCurrentPosition">setCurrentPosition</a>(<a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a>);
<a class="l" name="758" href="#758">758</a>	}
<a class="l" name="759" href="#759">759</a>
<a class="hl" name="760" href="#760">760</a>	<span class="c">/**
<a class="l" name="761" href="#761">761</a>	 * Read only header part of a tag.
<a class="l" name="762" href="#762">762</a>	 *
<a class="l" name="763" href="#763">763</a>	 * <strong>@return</strong>              Tag header
<a class="l" name="764" href="#764">764</a>	 */</span>
<a class="l" name="765" href="#765">765</a>	<b>private</b> <a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a class="xmt" name="readTagHeader"/><a href="/source/s?refs=readTagHeader&amp;project=rtmp_client" class="xmt">readTagHeader</a>() {
<a class="l" name="766" href="#766">766</a>		<span class="c">// previous tag size (4 bytes) + flv tag header size (11 bytes)</span>
<a class="l" name="767" href="#767">767</a>		<a href="/source/s?defs=fillBuffer&amp;project=rtmp_client">fillBuffer</a>(<span class="n">15</span>);
<a class="l" name="768" href="#768">768</a><span class="c">//		if (log.isDebugEnabled()) {</span>
<a class="l" name="769" href="#769">769</a><span class="c">//			in.mark();</span>
<a class="hl" name="770" href="#770">770</a><span class="c">//			StringBuilder sb = new StringBuilder();</span>
<a class="l" name="771" href="#771">771</a><span class="c">//			HexDump.dumpHex(sb, in.array());</span>
<a class="l" name="772" href="#772">772</a><span class="c">//			log.debug("\n{}", sb);</span>
<a class="l" name="773" href="#773">773</a><span class="c">//			in.reset();</span>
<a class="l" name="774" href="#774">774</a><span class="c">//		}</span>
<a class="l" name="775" href="#775">775</a>		<span class="c">// previous tag's size</span>
<a class="l" name="776" href="#776">776</a>		<b>int</b> <a href="/source/s?defs=previousTagSize&amp;project=rtmp_client">previousTagSize</a> = <a class="d" href="#in">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>();
<a class="l" name="777" href="#777">777</a>		<span class="c">// start of the flv tag</span>
<a class="l" name="778" href="#778">778</a>		<b>byte</b> <a href="/source/s?defs=dataType&amp;project=rtmp_client">dataType</a> = <a class="d" href="#in">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="779" href="#779">779</a>		<b>if</b> (<a href="/source/s?defs=dataType&amp;project=rtmp_client">dataType</a> != <span class="n">8</span> &amp;&amp; <a href="/source/s?defs=dataType&amp;project=rtmp_client">dataType</a> != <span class="n">9</span> &amp;&amp; <a href="/source/s?defs=dataType&amp;project=rtmp_client">dataType</a> != <span class="n">18</span>) {
<a class="hl" name="780" href="#780">780</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Invalid data type detected, skipping crap-bytes"</span>);
<a class="l" name="781" href="#781">781</a>			<a class="d" href="#in">in</a>.<a href="/source/s?defs=skip&amp;project=rtmp_client">skip</a>(<span class="n">51</span>);
<a class="l" name="782" href="#782">782</a>			<a href="/source/s?defs=dataType&amp;project=rtmp_client">dataType</a> = <a class="d" href="#in">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="783" href="#783">783</a>		}
<a class="l" name="784" href="#784">784</a><span class="c">//		log.debug("dataType = {}", dataType);</span>
<a class="l" name="785" href="#785">785</a>		<b>int</b> <a href="/source/s?defs=bodySize&amp;project=rtmp_client">bodySize</a> = <a href="/source/s?defs=IOUtils&amp;project=rtmp_client">IOUtils</a>.<a href="/source/s?defs=readUnsignedMediumInt&amp;project=rtmp_client">readUnsignedMediumInt</a>(<a class="d" href="#in">in</a>);
<a class="l" name="786" href="#786">786</a>		<b>int</b> <a href="/source/s?defs=timestamp&amp;project=rtmp_client">timestamp</a> = <a href="/source/s?defs=IOUtils&amp;project=rtmp_client">IOUtils</a>.<a href="/source/s?defs=readExtendedMediumInt&amp;project=rtmp_client">readExtendedMediumInt</a>(<a class="d" href="#in">in</a>);
<a class="l" name="787" href="#787">787</a>		<b>if</b> (<a class="d" href="#log">log</a>.<a href="/source/s?defs=isDebugEnabled&amp;project=rtmp_client">isDebugEnabled</a>()) {
<a class="l" name="788" href="#788">788</a><span class="c">//			int streamId = IOUtils.readUnsignedMediumInt(in);</span>
<a class="l" name="789" href="#789">789</a><span class="c">//			log.debug("Data type: {} timestamp: {} stream id: {} body size: {} previous tag size: {}", new Object[]{dataType, timestamp, streamId, bodySize, previousTagSize});</span>
<a class="hl" name="790" href="#790">790</a>		} <b>else</b> {
<a class="l" name="791" href="#791">791</a>			<a class="d" href="#in">in</a>.<a href="/source/s?defs=skip&amp;project=rtmp_client">skip</a>(<span class="n">3</span>);
<a class="l" name="792" href="#792">792</a>		}
<a class="l" name="793" href="#793">793</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=Tag&amp;project=rtmp_client">Tag</a>(<a href="/source/s?defs=dataType&amp;project=rtmp_client">dataType</a>, <a href="/source/s?defs=timestamp&amp;project=rtmp_client">timestamp</a>, <a href="/source/s?defs=bodySize&amp;project=rtmp_client">bodySize</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a href="/source/s?defs=previousTagSize&amp;project=rtmp_client">previousTagSize</a>);
<a class="l" name="794" href="#794">794</a>	}
<a class="l" name="795" href="#795">795</a>
<a class="l" name="796" href="#796">796</a>	<b>public</b> <b>static</b> <b>long</b> <a class="xmt" name="getDuration"/><a href="/source/s?refs=getDuration&amp;project=rtmp_client" class="xmt">getDuration</a>(<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a class="xa" name="flvFile"/><a href="/source/s?refs=flvFile&amp;project=rtmp_client" class="xa">flvFile</a>) {
<a class="l" name="797" href="#797">797</a>		<a href="/source/s?defs=RandomAccessFile&amp;project=rtmp_client">RandomAccessFile</a> <a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="798" href="#798">798</a>		<b>try</b> {
<a class="l" name="799" href="#799">799</a>			<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a> = <b>new</b> <a href="/source/s?defs=RandomAccessFile&amp;project=rtmp_client">RandomAccessFile</a>(<a class="d" href="#flvFile">flvFile</a>, <span class="s">"r"</span>);
<a class="hl" name="800" href="#800">800</a>			<b>long</b> <a href="/source/s?defs=flvLength&amp;project=rtmp_client">flvLength</a> = <a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>();
<a class="l" name="801" href="#801">801</a>			<b>if</b> (<a href="/source/s?defs=flvLength&amp;project=rtmp_client">flvLength</a> &lt; <span class="n">13</span>) {
<a class="l" name="802" href="#802">802</a>				<b>return</b> <span class="n">0</span>;
<a class="l" name="803" href="#803">803</a>			}
<a class="l" name="804" href="#804">804</a>			<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>.<a href="/source/s?defs=seek&amp;project=rtmp_client">seek</a>(<a href="/source/s?defs=flvLength&amp;project=rtmp_client">flvLength</a> - <span class="n">4</span>);
<a class="l" name="805" href="#805">805</a>			<b>byte</b>[] <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> = <b>new</b> <b>byte</b>[<span class="n">4</span>];
<a class="l" name="806" href="#806">806</a>			<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>.<a href="/source/s?defs=read&amp;project=rtmp_client">read</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="807" href="#807">807</a>			<b>long</b> <a href="/source/s?defs=lastTagSize&amp;project=rtmp_client">lastTagSize</a> = <span class="n">0</span>;
<a class="l" name="808" href="#808">808</a>			<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <span class="n">4</span>; i++) {
<a class="l" name="809" href="#809">809</a>				<a href="/source/s?defs=lastTagSize&amp;project=rtmp_client">lastTagSize</a> += (<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>[i] &amp; <span class="n">0x0ff</span>) &lt;&lt; ((<span class="n">3</span> - i) * <span class="n">8</span>);
<a class="hl" name="810" href="#810">810</a>			}
<a class="l" name="811" href="#811">811</a>			<b>if</b> (<a href="/source/s?defs=lastTagSize&amp;project=rtmp_client">lastTagSize</a> == <span class="n">0</span>) {
<a class="l" name="812" href="#812">812</a>				<b>return</b> <span class="n">0</span>;
<a class="l" name="813" href="#813">813</a>			}
<a class="l" name="814" href="#814">814</a>			<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>.<a href="/source/s?defs=seek&amp;project=rtmp_client">seek</a>(<a href="/source/s?defs=flvLength&amp;project=rtmp_client">flvLength</a> - <a href="/source/s?defs=lastTagSize&amp;project=rtmp_client">lastTagSize</a>);
<a class="l" name="815" href="#815">815</a>			<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>.<a href="/source/s?defs=read&amp;project=rtmp_client">read</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="816" href="#816">816</a>			<b>long</b> <a class="d" href="#duration">duration</a> = <span class="n">0</span>;
<a class="l" name="817" href="#817">817</a>			<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <span class="n">3</span>; i++) {
<a class="l" name="818" href="#818">818</a>				<a class="d" href="#duration">duration</a> += (<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>[i] &amp; <span class="n">0x0ff</span>) &lt;&lt; ((<span class="n">2</span> - i) * <span class="n">8</span>);
<a class="l" name="819" href="#819">819</a>			}
<a class="hl" name="820" href="#820">820</a>			<a class="d" href="#duration">duration</a> += (<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>[<span class="n">3</span>] &amp; <span class="n">0x0ff</span>) &lt;&lt; <span class="n">24</span>; <span class="c">// extension byte</span>
<a class="l" name="821" href="#821">821</a>			<b>return</b> <a class="d" href="#duration">duration</a>;
<a class="l" name="822" href="#822">822</a>		} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> e) {
<a class="l" name="823" href="#823">823</a>			<b>return</b> <span class="n">0</span>;
<a class="l" name="824" href="#824">824</a>		} <b>finally</b> {
<a class="l" name="825" href="#825">825</a>			<b>try</b> {
<a class="l" name="826" href="#826">826</a>				<b>if</b> (<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="827" href="#827">827</a>					<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>.<a class="d" href="#close">close</a>();
<a class="l" name="828" href="#828">828</a>				}
<a class="l" name="829" href="#829">829</a>			} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> e) {
<a class="hl" name="830" href="#830">830</a>			}
<a class="l" name="831" href="#831">831</a>			<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="832" href="#832">832</a>		}
<a class="l" name="833" href="#833">833</a>	}
<a class="l" name="834" href="#834">834</a>}
<a class="l" name="835" href="#835">835</a>