<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["MP3Reader",61],["MetaData",632]]],["Package","xp",[["org.red5.io.mp3",1]]],["Method","xmt",[["MP3Reader",140],["MP3Reader",150],["analyzeKeyFrames",550],["checkValidHeader",289],["close",506],["createFileMeta",310],["decodeHeader",524],["getAlbum",649],["getArtist",657],["getBytesRead",377],["getComment",697],["getCovr",705],["getDuration",382],["getFile",367],["getGenre",665],["getOffset",372],["getSongName",673],["getTotalBytes",391],["getTrack",681],["getYear",689],["hasCoverImage",714],["hasMoreTags",396],["hasVideo",274],["position",528],["readHeader",429],["readTag",445],["searchNextFrame",351],["setAlbum",653],["setArtist",661],["setComment",701],["setCovr",709],["setFrameCache",278],["setGenre",669],["setSongName",677],["setTrack",685],["setYear",693]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=mp3&amp;project=rtmp_client">mp3</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=File&amp;project=rtmp_client">File</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=FileInputStream&amp;project=rtmp_client">FileInputStream</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=FileNotFoundException&amp;project=rtmp_client">FileNotFoundException</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=ByteOrder&amp;project=rtmp_client">ByteOrder</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=MappedByteBuffer&amp;project=rtmp_client">MappedByteBuffer</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=channels&amp;project=rtmp_client">channels</a>.<a href="/source/s?defs=FileChannel&amp;project=rtmp_client">FileChannel</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=LinkedList&amp;project=rtmp_client">LinkedList</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>;
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="36" href="#36">36</a><span class="c">//import org.jaudiotagger.audio.AudioFileIO;</span>
<a class="l" name="37" href="#37">37</a><span class="c">//import org.jaudiotagger.audio.mp3.MP3AudioHeader;</span>
<a class="l" name="38" href="#38">38</a><span class="c">//import org.jaudiotagger.audio.mp3.MP3File;</span>
<a class="l" name="39" href="#39">39</a><span class="c">//import org.jaudiotagger.tag.TagException;</span>
<a class="hl" name="40" href="#40">40</a><span class="c">//import org.jaudiotagger.tag.TagField;</span>
<a class="l" name="41" href="#41">41</a><span class="c">//import org.jaudiotagger.tag.FieldKey;</span>
<a class="l" name="42" href="#42">42</a><span class="c">//import org.jaudiotagger.tag.datatype.DataTypes;</span>
<a class="l" name="43" href="#43">43</a><span class="c">//import org.jaudiotagger.tag.id3.AbstractID3v2Frame;</span>
<a class="l" name="44" href="#44">44</a><span class="c">//import org.jaudiotagger.tag.id3.ID3v24Tag;</span>
<a class="l" name="45" href="#45">45</a><span class="c">//import org.jaudiotagger.tag.id3.framebody.FrameBodyAPIC;</span>
<a class="l" name="46" href="#46">46</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IKeyFrameMetaCache&amp;project=rtmp_client">IKeyFrameMetaCache</a>;
<a class="l" name="47" href="#47">47</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IStreamableFile&amp;project=rtmp_client">IStreamableFile</a>;
<a class="l" name="48" href="#48">48</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a>;
<a class="l" name="49" href="#49">49</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=ITagReader&amp;project=rtmp_client">ITagReader</a>;
<a class="hl" name="50" href="#50">50</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>;
<a class="l" name="51" href="#51">51</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>;
<a class="l" name="52" href="#52">52</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>.<a href="/source/s?defs=IKeyFrameDataAnalyzer&amp;project=rtmp_client">IKeyFrameDataAnalyzer</a>;
<a class="l" name="53" href="#53">53</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>.<a href="/source/s?defs=Tag&amp;project=rtmp_client">Tag</a>;
<a class="l" name="54" href="#54">54</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>;
<a class="l" name="55" href="#55">55</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="56" href="#56">56</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="57" href="#57">57</a>
<a class="l" name="58" href="#58">58</a><span class="c">/**
<a class="l" name="59" href="#59">59</a> * Read MP3 files
<a class="hl" name="60" href="#60">60</a> */</span>
<a class="l" name="61" href="#61">61</a><b>public</b> <b>class</b> <a class="xc" name="MP3Reader"/><a href="/source/s?refs=MP3Reader&amp;project=rtmp_client" class="xc">MP3Reader</a> <b>implements</b> <a href="/source/s?defs=ITagReader&amp;project=rtmp_client">ITagReader</a>, <a href="/source/s?defs=IKeyFrameDataAnalyzer&amp;project=rtmp_client">IKeyFrameDataAnalyzer</a> {
<a class="l" name="62" href="#62">62</a>	<span class="c">/**
<a class="l" name="63" href="#63">63</a>	 * Logger
<a class="l" name="64" href="#64">64</a>	 */</span>
<a class="l" name="65" href="#65">65</a>	<b>protected</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a href="/source/s?defs=MP3Reader&amp;project=rtmp_client">MP3Reader</a>.<b>class</b>);
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a>	<span class="c">/**
<a class="l" name="68" href="#68">68</a>	 * File
<a class="l" name="69" href="#69">69</a>	 */</span>
<a class="hl" name="70" href="#70">70</a>	<b>private</b> <a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a class="xfld" name="file"/><a href="/source/s?refs=file&amp;project=rtmp_client" class="xfld">file</a>;
<a class="l" name="71" href="#71">71</a>
<a class="l" name="72" href="#72">72</a>	<span class="c">/**
<a class="l" name="73" href="#73">73</a>	 * File input stream
<a class="l" name="74" href="#74">74</a>	 */</span>
<a class="l" name="75" href="#75">75</a>	<b>private</b> <a href="/source/s?defs=FileInputStream&amp;project=rtmp_client">FileInputStream</a> <a class="xfld" name="fis"/><a href="/source/s?refs=fis&amp;project=rtmp_client" class="xfld">fis</a>;
<a class="l" name="76" href="#76">76</a>
<a class="l" name="77" href="#77">77</a>	<span class="c">/**
<a class="l" name="78" href="#78">78</a>	 * File channel
<a class="l" name="79" href="#79">79</a>	 */</span>
<a class="hl" name="80" href="#80">80</a>	<b>private</b> <a href="/source/s?defs=FileChannel&amp;project=rtmp_client">FileChannel</a> <a class="xfld" name="channel"/><a href="/source/s?refs=channel&amp;project=rtmp_client" class="xfld">channel</a>;
<a class="l" name="81" href="#81">81</a>
<a class="l" name="82" href="#82">82</a>	<span class="c">/**
<a class="l" name="83" href="#83">83</a>	 * Memory-mapped buffer for file content
<a class="l" name="84" href="#84">84</a>	 */</span>
<a class="l" name="85" href="#85">85</a>	<b>private</b> <a href="/source/s?defs=MappedByteBuffer&amp;project=rtmp_client">MappedByteBuffer</a> <a class="xfld" name="mappedFile"/><a href="/source/s?refs=mappedFile&amp;project=rtmp_client" class="xfld">mappedFile</a>;
<a class="l" name="86" href="#86">86</a>
<a class="l" name="87" href="#87">87</a>	<span class="c">/**
<a class="l" name="88" href="#88">88</a>	 * Source byte buffer
<a class="l" name="89" href="#89">89</a>	 */</span>
<a class="hl" name="90" href="#90">90</a>	<b>private</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xfld" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xfld">in</a>;
<a class="l" name="91" href="#91">91</a>
<a class="l" name="92" href="#92">92</a>	<span class="c">/**
<a class="l" name="93" href="#93">93</a>	 * Last read tag object
<a class="l" name="94" href="#94">94</a>	 */</span>
<a class="l" name="95" href="#95">95</a>	<b>private</b> <a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a class="xfld" name="tag"/><a href="/source/s?refs=tag&amp;project=rtmp_client" class="xfld">tag</a>;
<a class="l" name="96" href="#96">96</a>
<a class="l" name="97" href="#97">97</a>	<span class="c">/**
<a class="l" name="98" href="#98">98</a>	 * Previous tag size
<a class="l" name="99" href="#99">99</a>	 */</span>
<a class="hl" name="100" href="#100">100</a>	<b>private</b> <b>int</b> <a class="xfld" name="prevSize"/><a href="/source/s?refs=prevSize&amp;project=rtmp_client" class="xfld">prevSize</a>;
<a class="l" name="101" href="#101">101</a>
<a class="l" name="102" href="#102">102</a>	<span class="c">/**
<a class="l" name="103" href="#103">103</a>	 * Current time
<a class="l" name="104" href="#104">104</a>	 */</span>
<a class="l" name="105" href="#105">105</a>	<b>private</b> <b>double</b> <a class="xfld" name="currentTime"/><a href="/source/s?refs=currentTime&amp;project=rtmp_client" class="xfld">currentTime</a>;
<a class="l" name="106" href="#106">106</a>
<a class="l" name="107" href="#107">107</a>	<span class="c">/**
<a class="l" name="108" href="#108">108</a>	 * Frame metadata
<a class="l" name="109" href="#109">109</a>	 */</span>
<a class="hl" name="110" href="#110">110</a>	<b>private</b> <a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a> <a class="xfld" name="frameMeta"/><a href="/source/s?refs=frameMeta&amp;project=rtmp_client" class="xfld">frameMeta</a>;
<a class="l" name="111" href="#111">111</a>
<a class="l" name="112" href="#112">112</a>	<span class="c">/**
<a class="l" name="113" href="#113">113</a>	 * Positions and time map
<a class="l" name="114" href="#114">114</a>	 */</span>
<a class="l" name="115" href="#115">115</a>	<b>private</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>&gt; <a class="xfld" name="posTimeMap"/><a href="/source/s?refs=posTimeMap&amp;project=rtmp_client" class="xfld">posTimeMap</a>;
<a class="l" name="116" href="#116">116</a>
<a class="l" name="117" href="#117">117</a>	<b>private</b> <b>int</b> <a class="xfld" name="dataRate"/><a href="/source/s?refs=dataRate&amp;project=rtmp_client" class="xfld">dataRate</a>;
<a class="l" name="118" href="#118">118</a>
<a class="l" name="119" href="#119">119</a>	<span class="c">/**
<a class="hl" name="120" href="#120">120</a>	 * File duration
<a class="l" name="121" href="#121">121</a>	 */</span>
<a class="l" name="122" href="#122">122</a>	<b>private</b> <b>long</b> <a class="xfld" name="duration"/><a href="/source/s?refs=duration&amp;project=rtmp_client" class="xfld">duration</a>;
<a class="l" name="123" href="#123">123</a>
<a class="l" name="124" href="#124">124</a>	<span class="c">/**
<a class="l" name="125" href="#125">125</a>	 * Frame cache
<a class="l" name="126" href="#126">126</a>	 */</span>
<a class="l" name="127" href="#127">127</a>	<b>static</b> <b>private</b> <a href="/source/s?defs=IKeyFrameMetaCache&amp;project=rtmp_client">IKeyFrameMetaCache</a> <a class="xfld" name="frameCache"/><a href="/source/s?refs=frameCache&amp;project=rtmp_client" class="xfld">frameCache</a>;
<a class="l" name="128" href="#128">128</a>
<a class="l" name="129" href="#129">129</a>	<span class="c">/**
<a class="hl" name="130" href="#130">130</a>	 * Holder for ID3 meta data
<a class="l" name="131" href="#131">131</a>	 */</span>
<a class="l" name="132" href="#132">132</a>	<b>private</b> <a class="d" href="#MetaData">MetaData</a> <a class="xfld" name="metaData"/><a href="/source/s?refs=metaData&amp;project=rtmp_client" class="xfld">metaData</a>;
<a class="l" name="133" href="#133">133</a>
<a class="l" name="134" href="#134">134</a>	<span class="c">/**
<a class="l" name="135" href="#135">135</a>	 * Container for metadata and any other tags that should
<a class="l" name="136" href="#136">136</a>	 * be sent prior to media data.
<a class="l" name="137" href="#137">137</a>	 */</span>
<a class="l" name="138" href="#138">138</a>	<b>private</b> <a href="/source/s?defs=LinkedList&amp;project=rtmp_client">LinkedList</a>&lt;<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a>&gt; <a class="xfld" name="firstTags"/><a href="/source/s?refs=firstTags&amp;project=rtmp_client" class="xfld">firstTags</a> = <b>new</b> <a href="/source/s?defs=LinkedList&amp;project=rtmp_client">LinkedList</a>&lt;<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a>&gt;();
<a class="l" name="139" href="#139">139</a>
<a class="hl" name="140" href="#140">140</a>	<a class="xmt" name="MP3Reader"/><a href="/source/s?refs=MP3Reader&amp;project=rtmp_client" class="xmt">MP3Reader</a>() {
<a class="l" name="141" href="#141">141</a>		<span class="c">// Only used by the bean startup code to initialize the frame cache</span>
<a class="l" name="142" href="#142">142</a>	}
<a class="l" name="143" href="#143">143</a>
<a class="l" name="144" href="#144">144</a>	<span class="c">/**
<a class="l" name="145" href="#145">145</a>	 * Creates reader from file input stream
<a class="l" name="146" href="#146">146</a>	 * <strong>@param</strong> <em>file</em> file input
<a class="l" name="147" href="#147">147</a>	 *
<a class="l" name="148" href="#148">148</a>	 * <strong>@throws</strong> <em>FileNotFoundException</em> if not found
<a class="l" name="149" href="#149">149</a>	 */</span>
<a class="hl" name="150" href="#150">150</a>	<b>public</b> <a class="xmt" name="MP3Reader"/><a href="/source/s?refs=MP3Reader&amp;project=rtmp_client" class="xmt">MP3Reader</a>(<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a class="xa" name="file"/><a href="/source/s?refs=file&amp;project=rtmp_client" class="xa">file</a>) <b>throws</b> <a href="/source/s?defs=FileNotFoundException&amp;project=rtmp_client">FileNotFoundException</a> {
<a class="l" name="151" href="#151">151</a>		<b>this</b>.<a href="/source/s?defs=file&amp;project=rtmp_client">file</a> = <a href="/source/s?defs=file&amp;project=rtmp_client">file</a>;
<a class="l" name="152" href="#152">152</a>
<a class="l" name="153" href="#153">153</a>		<span class="c">// parse the id3 info</span>
<a class="l" name="154" href="#154">154</a>		<span class="c">/*
<a class="l" name="155" href="#155">155</a>		try {
<a class="l" name="156" href="#156">156</a>			MP3File mp3file = (MP3File) AudioFileIO.read(file);
<a class="l" name="157" href="#157">157</a>			MP3AudioHeader audioHeader = (MP3AudioHeader) mp3file.getAudioHeader();
<a class="l" name="158" href="#158">158</a>			if (audioHeader != null) {
<a class="l" name="159" href="#159">159</a>				log.debug("Track length: {}", audioHeader.getTrackLength());
<a class="hl" name="160" href="#160">160</a>				log.debug("Sample rate: {}", audioHeader.getSampleRateAsNumber());
<a class="l" name="161" href="#161">161</a>				log.debug("Channels: {}", audioHeader.getChannels());
<a class="l" name="162" href="#162">162</a>				log.debug("Variable bit rate: {}", audioHeader.isVariableBitRate());
<a class="l" name="163" href="#163">163</a>				log.debug("Track length (2): {}", audioHeader.getTrackLengthAsString());
<a class="l" name="164" href="#164">164</a>				log.debug("Mpeg version: {}", audioHeader.getMpegVersion());
<a class="l" name="165" href="#165">165</a>				log.debug("Mpeg layer: {}", audioHeader.getMpegLayer());
<a class="l" name="166" href="#166">166</a>				log.debug("Original: {}", audioHeader.isOriginal());
<a class="l" name="167" href="#167">167</a>				log.debug("Copyrighted: {}", audioHeader.isCopyrighted());
<a class="l" name="168" href="#168">168</a>				log.debug("Private: {}", audioHeader.isPrivate());
<a class="l" name="169" href="#169">169</a>				log.debug("Protected: {}", audioHeader.isProtected());
<a class="hl" name="170" href="#170">170</a>				log.debug("Bitrate: {}", audioHeader.getBitRate());
<a class="l" name="171" href="#171">171</a>				log.debug("Encoding type: {}", audioHeader.getEncodingType());
<a class="l" name="172" href="#172">172</a>				log.debug("Encoder: {}", audioHeader.getEncoder());
<a class="l" name="173" href="#173">173</a>			}
<a class="l" name="174" href="#174">174</a>			ID3v24Tag idTag = mp3file.getID3v2TagAsv24();
<a class="l" name="175" href="#175">175</a>			if (idTag != null) {
<a class="l" name="176" href="#176">176</a>				// create meta data holder
<a class="l" name="177" href="#177">177</a>				metaData = new MetaData();
<a class="l" name="178" href="#178">178</a>//				metaData.setAlbum(idTag.getFirstAlbum());
<a class="l" name="179" href="#179">179</a>//				metaData.setArtist(idTag.getFirstArtist());
<a class="hl" name="180" href="#180">180</a>//				metaData.setComment(idTag.getFirstComment());
<a class="l" name="181" href="#181">181</a>//				metaData.setGenre(idTag.getFirstGenre());
<a class="l" name="182" href="#182">182</a>//				metaData.setSongName(idTag.getFirstTitle());
<a class="l" name="183" href="#183">183</a>//				metaData.setTrack(idTag.getFirstTrack());
<a class="l" name="184" href="#184">184</a>//				metaData.setYear(idTag.getFirstYear());
<a class="l" name="185" href="#185">185</a>				//send album image if included
<a class="l" name="186" href="#186">186</a>				List&lt;TagField&gt; tagFieldList = mp3file.getTag().getFields(FieldKey.COVER_ART);
<a class="l" name="187" href="#187">187</a>				//fix for APPSERVER-310
<a class="l" name="188" href="#188">188</a>				if (tagFieldList == null || tagFieldList.isEmpty()) {
<a class="l" name="189" href="#189">189</a>					log.debug("No cover art was found");
<a class="hl" name="190" href="#190">190</a>				} else {
<a class="l" name="191" href="#191">191</a>    				TagField imageField = tagFieldList.get(0);
<a class="l" name="192" href="#192">192</a>    				if (imageField instanceof AbstractID3v2Frame) {
<a class="l" name="193" href="#193">193</a>    				    FrameBodyAPIC imageFrameBody = (FrameBodyAPIC)((AbstractID3v2Frame)imageField).getBody();
<a class="l" name="194" href="#194">194</a>    				    if (!imageFrameBody.isImageUrl()) {
<a class="l" name="195" href="#195">195</a>    				        byte[] imageBuffer = (byte[]) imageFrameBody.getObjectValue(DataTypes.OBJ_PICTURE_DATA);
<a class="l" name="196" href="#196">196</a>    						//set the cover image on the metadata
<a class="l" name="197" href="#197">197</a>    						metaData.setCovr(imageBuffer);
<a class="l" name="198" href="#198">198</a>    						// Create tag for onImageData event
<a class="l" name="199" href="#199">199</a>    						IoBuffer buf = IoBuffer.allocate(imageBuffer.length);
<a class="hl" name="200" href="#200">200</a>    						buf.setAutoExpand(true);
<a class="l" name="201" href="#201">201</a>    						Output out = new Output(buf);
<a class="l" name="202" href="#202">202</a>    						out.writeString("onImageData");
<a class="l" name="203" href="#203">203</a>    						Map&lt;Object, Object&gt; props = new HashMap&lt;Object, Object&gt;();
<a class="l" name="204" href="#204">204</a>    						props.put("trackid", 1);
<a class="l" name="205" href="#205">205</a>    						props.put("data", imageBuffer);
<a class="l" name="206" href="#206">206</a>    						out.writeMap(props, new Serializer());
<a class="l" name="207" href="#207">207</a>    						buf.flip();
<a class="l" name="208" href="#208">208</a>    						//Ugh i hate flash sometimes!!
<a class="l" name="209" href="#209">209</a>    						//Error #2095: flash.net.NetStream was unable to invoke callback onImageData.
<a class="hl" name="210" href="#210">210</a>    						ITag result = new Tag(IoConstants.TYPE_METADATA, 0, buf.limit(), null, 0);
<a class="l" name="211" href="#211">211</a>    						result.setBody(buf);
<a class="l" name="212" href="#212">212</a>    						//add to first frames
<a class="l" name="213" href="#213">213</a>    						firstTags.add(result);
<a class="l" name="214" href="#214">214</a>    				    }
<a class="l" name="215" href="#215">215</a>    				}
<a class="l" name="216" href="#216">216</a>				}
<a class="l" name="217" href="#217">217</a>			} else {
<a class="l" name="218" href="#218">218</a>				log.info("File did not contain ID3v2 data: {}", file.getName());
<a class="l" name="219" href="#219">219</a>			}
<a class="hl" name="220" href="#220">220</a>			mp3file = null;
<a class="l" name="221" href="#221">221</a>		} catch (TagException e) {
<a class="l" name="222" href="#222">222</a>			log.error("MP3Reader (tag error) {}", e);
<a class="l" name="223" href="#223">223</a>		} catch (Exception e) {
<a class="l" name="224" href="#224">224</a>			log.error("MP3Reader {}", e);
<a class="l" name="225" href="#225">225</a>		}
<a class="l" name="226" href="#226">226</a>	*/</span>
<a class="l" name="227" href="#227">227</a>		<a class="d" href="#fis">fis</a> = <b>new</b> <a href="/source/s?defs=FileInputStream&amp;project=rtmp_client">FileInputStream</a>(<a href="/source/s?defs=file&amp;project=rtmp_client">file</a>);
<a class="l" name="228" href="#228">228</a>		<span class="c">// Grab file channel and map it to memory-mapped byte buffer in</span>
<a class="l" name="229" href="#229">229</a>		<span class="c">// read-only mode</span>
<a class="hl" name="230" href="#230">230</a>		<a class="d" href="#channel">channel</a> = <a class="d" href="#fis">fis</a>.<a href="/source/s?defs=getChannel&amp;project=rtmp_client">getChannel</a>();
<a class="l" name="231" href="#231">231</a>		<b>try</b> {
<a class="l" name="232" href="#232">232</a>			<a class="d" href="#mappedFile">mappedFile</a> = <a class="d" href="#channel">channel</a>.<a href="/source/s?defs=map&amp;project=rtmp_client">map</a>(<a href="/source/s?defs=FileChannel&amp;project=rtmp_client">FileChannel</a>.<a href="/source/s?defs=MapMode&amp;project=rtmp_client">MapMode</a>.<a href="/source/s?defs=READ_ONLY&amp;project=rtmp_client">READ_ONLY</a>, <span class="n">0</span>, <a class="d" href="#channel">channel</a>
<a class="l" name="233" href="#233">233</a>					.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>());
<a class="l" name="234" href="#234">234</a>		} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> e) {
<a class="l" name="235" href="#235">235</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"MP3Reader {}"</span>, e);
<a class="l" name="236" href="#236">236</a>		}
<a class="l" name="237" href="#237">237</a>
<a class="l" name="238" href="#238">238</a>		<span class="c">// Use Big Endian bytes order</span>
<a class="l" name="239" href="#239">239</a>		<a class="d" href="#mappedFile">mappedFile</a>.<a href="/source/s?defs=order&amp;project=rtmp_client">order</a>(<a href="/source/s?defs=ByteOrder&amp;project=rtmp_client">ByteOrder</a>.<a href="/source/s?defs=BIG_ENDIAN&amp;project=rtmp_client">BIG_ENDIAN</a>);
<a class="hl" name="240" href="#240">240</a>		<span class="c">// Wrap mapped byte buffer to MINA buffer</span>
<a class="l" name="241" href="#241">241</a>		<a class="d" href="#in">in</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=wrap&amp;project=rtmp_client">wrap</a>(<a class="d" href="#mappedFile">mappedFile</a>);
<a class="l" name="242" href="#242">242</a>		<span class="c">// Analyze keyframes data</span>
<a class="l" name="243" href="#243">243</a>		<a class="d" href="#analyzeKeyFrames">analyzeKeyFrames</a>();
<a class="l" name="244" href="#244">244</a>
<a class="l" name="245" href="#245">245</a>		<span class="c">// Create file metadata object</span>
<a class="l" name="246" href="#246">246</a>		<a class="d" href="#firstTags">firstTags</a>.<a href="/source/s?defs=addFirst&amp;project=rtmp_client">addFirst</a>(<a class="d" href="#createFileMeta">createFileMeta</a>());
<a class="l" name="247" href="#247">247</a>
<a class="l" name="248" href="#248">248</a>		<span class="c">// MP3 header is length of 32 bits, that is, 4 bytes</span>
<a class="l" name="249" href="#249">249</a>		<span class="c">// Read further if there's still data</span>
<a class="hl" name="250" href="#250">250</a>		<b>if</b> (<a class="d" href="#in">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>() &gt; <span class="n">4</span>) {
<a class="l" name="251" href="#251">251</a>			<span class="c">// Look to next frame</span>
<a class="l" name="252" href="#252">252</a>			<a class="d" href="#searchNextFrame">searchNextFrame</a>();
<a class="l" name="253" href="#253">253</a>			<span class="c">// Set position</span>
<a class="l" name="254" href="#254">254</a>			<b>int</b> <a class="d" href="#pos">pos</a> = <a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>();
<a class="l" name="255" href="#255">255</a>			<span class="c">// Read header...</span>
<a class="l" name="256" href="#256">256</a>			<span class="c">// Data in MP3 file goes header-data-header-data...header-data</span>
<a class="l" name="257" href="#257">257</a>			<a href="/source/s?defs=MP3Header&amp;project=rtmp_client">MP3Header</a> <a class="d" href="#header">header</a> = <a class="d" href="#readHeader">readHeader</a>();
<a class="l" name="258" href="#258">258</a>			<span class="c">// Set position</span>
<a class="l" name="259" href="#259">259</a>			<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>(<a class="d" href="#pos">pos</a>);
<a class="hl" name="260" href="#260">260</a>			<span class="c">// Check header</span>
<a class="l" name="261" href="#261">261</a>			<b>if</b> (<a class="d" href="#header">header</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="262" href="#262">262</a>				<a class="d" href="#checkValidHeader">checkValidHeader</a>(<a class="d" href="#header">header</a>);
<a class="l" name="263" href="#263">263</a>			} <b>else</b> {
<a class="l" name="264" href="#264">264</a>				<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"No initial header found."</span>);
<a class="l" name="265" href="#265">265</a>			}
<a class="l" name="266" href="#266">266</a>		}
<a class="l" name="267" href="#267">267</a>	}
<a class="l" name="268" href="#268">268</a>
<a class="l" name="269" href="#269">269</a>	<span class="c">/**
<a class="hl" name="270" href="#270">270</a>	 * A MP3 stream never has video.
<a class="l" name="271" href="#271">271</a>	 *
<a class="l" name="272" href="#272">272</a>	 * <strong>@return</strong> always returns &lt;code&gt;false&lt;/code&gt;
<a class="l" name="273" href="#273">273</a>	 */</span>
<a class="l" name="274" href="#274">274</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="hasVideo"/><a href="/source/s?refs=hasVideo&amp;project=rtmp_client" class="xmt">hasVideo</a>() {
<a class="l" name="275" href="#275">275</a>		<b>return</b> <b>false</b>;
<a class="l" name="276" href="#276">276</a>	}
<a class="l" name="277" href="#277">277</a>
<a class="l" name="278" href="#278">278</a>	<b>public</b> <b>void</b> <a class="xmt" name="setFrameCache"/><a href="/source/s?refs=setFrameCache&amp;project=rtmp_client" class="xmt">setFrameCache</a>(<a href="/source/s?defs=IKeyFrameMetaCache&amp;project=rtmp_client">IKeyFrameMetaCache</a> <a class="xa" name="frameCache"/><a href="/source/s?refs=frameCache&amp;project=rtmp_client" class="xa">frameCache</a>) {
<a class="l" name="279" href="#279">279</a>		<a href="/source/s?defs=MP3Reader&amp;project=rtmp_client">MP3Reader</a>.<a href="/source/s?defs=frameCache&amp;project=rtmp_client">frameCache</a> = <a href="/source/s?defs=frameCache&amp;project=rtmp_client">frameCache</a>;
<a class="hl" name="280" href="#280">280</a>	}
<a class="l" name="281" href="#281">281</a>
<a class="l" name="282" href="#282">282</a>	<span class="c">/**
<a class="l" name="283" href="#283">283</a>	 * Check if the file can be played back with Flash. Supported sample rates
<a class="l" name="284" href="#284">284</a>	 * are 44KHz, 22KHz, 11KHz and 5.5KHz
<a class="l" name="285" href="#285">285</a>	 *
<a class="l" name="286" href="#286">286</a>	 * <strong>@param</strong> <em>header</em>
<a class="l" name="287" href="#287">287</a>	 *            Header to check
<a class="l" name="288" href="#288">288</a>	 */</span>
<a class="l" name="289" href="#289">289</a>	<b>private</b> <b>void</b> <a class="xmt" name="checkValidHeader"/><a href="/source/s?refs=checkValidHeader&amp;project=rtmp_client" class="xmt">checkValidHeader</a>(<a href="/source/s?defs=MP3Header&amp;project=rtmp_client">MP3Header</a> <a class="xa" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xa">header</a>) {
<a class="hl" name="290" href="#290">290</a>		<b>switch</b> (<a class="d" href="#header">header</a>.<a href="/source/s?defs=getSampleRate&amp;project=rtmp_client">getSampleRate</a>()) {
<a class="l" name="291" href="#291">291</a>			<b>case</b> <span class="n">48000</span>:
<a class="l" name="292" href="#292">292</a>			<b>case</b> <span class="n">44100</span>:
<a class="l" name="293" href="#293">293</a>			<b>case</b> <span class="n">22050</span>:
<a class="l" name="294" href="#294">294</a>			<b>case</b> <span class="n">11025</span>:
<a class="l" name="295" href="#295">295</a>			<b>case</b> <span class="n">5513</span>:
<a class="l" name="296" href="#296">296</a>				<span class="c">// Supported sample rate</span>
<a class="l" name="297" href="#297">297</a>				<b>break</b>;
<a class="l" name="298" href="#298">298</a>
<a class="l" name="299" href="#299">299</a>			<b>default</b>:
<a class="hl" name="300" href="#300">300</a>				<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"Unsupported sample rate: "</span>
<a class="l" name="301" href="#301">301</a>						+ <a class="d" href="#header">header</a>.<a href="/source/s?defs=getSampleRate&amp;project=rtmp_client">getSampleRate</a>());
<a class="l" name="302" href="#302">302</a>		}
<a class="l" name="303" href="#303">303</a>	}
<a class="l" name="304" href="#304">304</a>
<a class="l" name="305" href="#305">305</a>	<span class="c">/**
<a class="l" name="306" href="#306">306</a>	 * Creates file metadata object
<a class="l" name="307" href="#307">307</a>	 *
<a class="l" name="308" href="#308">308</a>	 * <strong>@return</strong> Tag
<a class="l" name="309" href="#309">309</a>	 */</span>
<a class="hl" name="310" href="#310">310</a>	<b>private</b> <a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a class="xmt" name="createFileMeta"/><a href="/source/s?refs=createFileMeta&amp;project=rtmp_client" class="xmt">createFileMeta</a>() {
<a class="l" name="311" href="#311">311</a>		<span class="c">// Create tag for onMetaData event</span>
<a class="l" name="312" href="#312">312</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">1024</span>);
<a class="l" name="313" href="#313">313</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="314" href="#314">314</a>		<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <b>new</b> <a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="315" href="#315">315</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=writeString&amp;project=rtmp_client">writeString</a>(<span class="s">"onMetaData"</span>);
<a class="l" name="316" href="#316">316</a>		<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=props&amp;project=rtmp_client">props</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="l" name="317" href="#317">317</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"duration"</span>,
<a class="l" name="318" href="#318">318</a>				<a class="d" href="#frameMeta">frameMeta</a>.<a href="/source/s?defs=timestamps&amp;project=rtmp_client">timestamps</a>[<a class="d" href="#frameMeta">frameMeta</a>.<a href="/source/s?defs=timestamps&amp;project=rtmp_client">timestamps</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> - <span class="n">1</span>] / <span class="n">1000.0</span>);
<a class="l" name="319" href="#319">319</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"audiocodecid"</span>, <a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=FLAG_FORMAT_MP3&amp;project=rtmp_client">FLAG_FORMAT_MP3</a>);
<a class="hl" name="320" href="#320">320</a>		<b>if</b> (<a class="d" href="#dataRate">dataRate</a> &gt; <span class="n">0</span>) {
<a class="l" name="321" href="#321">321</a>			<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"audiodatarate"</span>, <a class="d" href="#dataRate">dataRate</a>);
<a class="l" name="322" href="#322">322</a>		}
<a class="l" name="323" href="#323">323</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"canSeekToEnd"</span>, <b>true</b>);
<a class="l" name="324" href="#324">324</a>		<span class="c">//set id3 meta data if it exists</span>
<a class="l" name="325" href="#325">325</a>		<b>if</b> (<a class="d" href="#metaData">metaData</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="326" href="#326">326</a>			<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"artist"</span>, <a class="d" href="#metaData">metaData</a>.<a class="d" href="#getArtist">getArtist</a>());
<a class="l" name="327" href="#327">327</a>			<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"album"</span>, <a class="d" href="#metaData">metaData</a>.<a class="d" href="#getAlbum">getAlbum</a>());
<a class="l" name="328" href="#328">328</a>			<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"songName"</span>, <a class="d" href="#metaData">metaData</a>.<a class="d" href="#getSongName">getSongName</a>());
<a class="l" name="329" href="#329">329</a>			<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"genre"</span>, <a class="d" href="#metaData">metaData</a>.<a class="d" href="#getGenre">getGenre</a>());
<a class="hl" name="330" href="#330">330</a>			<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"year"</span>, <a class="d" href="#metaData">metaData</a>.<a class="d" href="#getYear">getYear</a>());
<a class="l" name="331" href="#331">331</a>			<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"track"</span>, <a class="d" href="#metaData">metaData</a>.<a class="d" href="#getTrack">getTrack</a>());
<a class="l" name="332" href="#332">332</a>			<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"comment"</span>, <a class="d" href="#metaData">metaData</a>.<a class="d" href="#getComment">getComment</a>());
<a class="l" name="333" href="#333">333</a>			<b>if</b> (<a class="d" href="#metaData">metaData</a>.<a class="d" href="#hasCoverImage">hasCoverImage</a>()) {
<a class="l" name="334" href="#334">334</a>				<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=covr&amp;project=rtmp_client">covr</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;(<span class="n">1</span>);
<a class="l" name="335" href="#335">335</a>				<a href="/source/s?defs=covr&amp;project=rtmp_client">covr</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"covr"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[]{<a class="d" href="#metaData">metaData</a>.<a class="d" href="#getCovr">getCovr</a>()});
<a class="l" name="336" href="#336">336</a>				<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"tags"</span>, <a href="/source/s?defs=covr&amp;project=rtmp_client">covr</a>);
<a class="l" name="337" href="#337">337</a>			}
<a class="l" name="338" href="#338">338</a>			<span class="c">//clear meta for gc</span>
<a class="l" name="339" href="#339">339</a>			<a class="d" href="#metaData">metaData</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="hl" name="340" href="#340">340</a>		}
<a class="l" name="341" href="#341">341</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=writeMap&amp;project=rtmp_client">writeMap</a>(<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>, <b>new</b> <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>());
<a class="l" name="342" href="#342">342</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="343" href="#343">343</a>
<a class="l" name="344" href="#344">344</a>		<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>new</b> <a href="/source/s?defs=Tag&amp;project=rtmp_client">Tag</a>(<a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=TYPE_METADATA&amp;project=rtmp_client">TYPE_METADATA</a>, <span class="n">0</span>, <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(), <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>,
<a class="l" name="345" href="#345">345</a>				<a class="d" href="#prevSize">prevSize</a>);
<a class="l" name="346" href="#346">346</a>		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=setBody&amp;project=rtmp_client">setBody</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="347" href="#347">347</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="348" href="#348">348</a>	}
<a class="l" name="349" href="#349">349</a>
<a class="hl" name="350" href="#350">350</a>	<span class="c">/** Search for next frame sync word. Sync word identifies valid frame. */</span>
<a class="l" name="351" href="#351">351</a>	<b>public</b> <b>void</b> <a class="xmt" name="searchNextFrame"/><a href="/source/s?refs=searchNextFrame&amp;project=rtmp_client" class="xmt">searchNextFrame</a>() {
<a class="l" name="352" href="#352">352</a>		<b>while</b> (<a class="d" href="#in">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>() &gt; <span class="n">1</span>) {
<a class="l" name="353" href="#353">353</a>			<b>int</b> <a href="/source/s?defs=ch&amp;project=rtmp_client">ch</a> = <a class="d" href="#in">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xff</span>;
<a class="l" name="354" href="#354">354</a>			<b>if</b> (<a href="/source/s?defs=ch&amp;project=rtmp_client">ch</a> != <span class="n">0xff</span>) {
<a class="l" name="355" href="#355">355</a>				<b>continue</b>;
<a class="l" name="356" href="#356">356</a>			}
<a class="l" name="357" href="#357">357</a>
<a class="l" name="358" href="#358">358</a>			<b>if</b> ((<a class="d" href="#in">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xe0</span>) == <span class="n">0xe0</span>) {
<a class="l" name="359" href="#359">359</a>				<span class="c">// Found it</span>
<a class="hl" name="360" href="#360">360</a>				<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>(<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>() - <span class="n">2</span>);
<a class="l" name="361" href="#361">361</a>				<b>return</b>;
<a class="l" name="362" href="#362">362</a>			}
<a class="l" name="363" href="#363">363</a>		}
<a class="l" name="364" href="#364">364</a>	}
<a class="l" name="365" href="#365">365</a>
<a class="l" name="366" href="#366">366</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="367" href="#367">367</a>	<b>public</b> <a href="/source/s?defs=IStreamableFile&amp;project=rtmp_client">IStreamableFile</a> <a class="xmt" name="getFile"/><a href="/source/s?refs=getFile&amp;project=rtmp_client" class="xmt">getFile</a>() {
<a class="l" name="368" href="#368">368</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="369" href="#369">369</a>	}
<a class="hl" name="370" href="#370">370</a>
<a class="l" name="371" href="#371">371</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="372" href="#372">372</a>	<b>public</b> <b>int</b> <a class="xmt" name="getOffset"/><a href="/source/s?refs=getOffset&amp;project=rtmp_client" class="xmt">getOffset</a>() {
<a class="l" name="373" href="#373">373</a>		<b>return</b> <span class="n">0</span>;
<a class="l" name="374" href="#374">374</a>	}
<a class="l" name="375" href="#375">375</a>
<a class="l" name="376" href="#376">376</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="377" href="#377">377</a>	<b>public</b> <b>long</b> <a class="xmt" name="getBytesRead"/><a href="/source/s?refs=getBytesRead&amp;project=rtmp_client" class="xmt">getBytesRead</a>() {
<a class="l" name="378" href="#378">378</a>		<b>return</b> <a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>();
<a class="l" name="379" href="#379">379</a>	}
<a class="hl" name="380" href="#380">380</a>
<a class="l" name="381" href="#381">381</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="382" href="#382">382</a>	<b>public</b> <b>long</b> <a class="xmt" name="getDuration"/><a href="/source/s?refs=getDuration&amp;project=rtmp_client" class="xmt">getDuration</a>() {
<a class="l" name="383" href="#383">383</a>		<b>return</b> <a class="d" href="#duration">duration</a>;
<a class="l" name="384" href="#384">384</a>	}
<a class="l" name="385" href="#385">385</a>
<a class="l" name="386" href="#386">386</a>	<span class="c">/**
<a class="l" name="387" href="#387">387</a>	 * Get the total readable bytes in a file or ByteBuffer.
<a class="l" name="388" href="#388">388</a>	 *
<a class="l" name="389" href="#389">389</a>	 * <strong>@return</strong> Total readable bytes
<a class="hl" name="390" href="#390">390</a>	 */</span>
<a class="l" name="391" href="#391">391</a>	<b>public</b> <b>long</b> <a class="xmt" name="getTotalBytes"/><a href="/source/s?refs=getTotalBytes&amp;project=rtmp_client" class="xmt">getTotalBytes</a>() {
<a class="l" name="392" href="#392">392</a>		<b>return</b> <a class="d" href="#in">in</a>.<a href="/source/s?defs=capacity&amp;project=rtmp_client">capacity</a>();
<a class="l" name="393" href="#393">393</a>	}
<a class="l" name="394" href="#394">394</a>
<a class="l" name="395" href="#395">395</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="396" href="#396">396</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="hasMoreTags"/><a href="/source/s?refs=hasMoreTags&amp;project=rtmp_client" class="xmt">hasMoreTags</a>() {
<a class="l" name="397" href="#397">397</a>		<a href="/source/s?defs=MP3Header&amp;project=rtmp_client">MP3Header</a> <a class="d" href="#header">header</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="398" href="#398">398</a>		<b>while</b> (<a class="d" href="#header">header</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a class="d" href="#in">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>() &gt; <span class="n">4</span>) {
<a class="l" name="399" href="#399">399</a>			<b>try</b> {
<a class="hl" name="400" href="#400">400</a>				<a class="d" href="#header">header</a> = <b>new</b> <a href="/source/s?defs=MP3Header&amp;project=rtmp_client">MP3Header</a>(<a class="d" href="#in">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>());
<a class="l" name="401" href="#401">401</a>			} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> e) {
<a class="l" name="402" href="#402">402</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"MP3Reader :: hasMoreTags ::&gt;\n"</span>, e);
<a class="l" name="403" href="#403">403</a>				<b>break</b>;
<a class="l" name="404" href="#404">404</a>			} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="405" href="#405">405</a>				<a class="d" href="#searchNextFrame">searchNextFrame</a>();
<a class="l" name="406" href="#406">406</a>			}
<a class="l" name="407" href="#407">407</a>		}
<a class="l" name="408" href="#408">408</a>
<a class="l" name="409" href="#409">409</a>		<b>if</b> (<a class="d" href="#header">header</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="410" href="#410">410</a>			<b>return</b> <b>false</b>;
<a class="l" name="411" href="#411">411</a>		}
<a class="l" name="412" href="#412">412</a>
<a class="l" name="413" href="#413">413</a>		<b>if</b> (<a class="d" href="#header">header</a>.<a href="/source/s?defs=frameSize&amp;project=rtmp_client">frameSize</a>() == <span class="n">0</span>) {
<a class="l" name="414" href="#414">414</a>			<span class="c">// TODO find better solution how to deal with broken files...</span>
<a class="l" name="415" href="#415">415</a>			<span class="c">// See APPSERVER-62 for details</span>
<a class="l" name="416" href="#416">416</a>			<b>return</b> <b>false</b>;
<a class="l" name="417" href="#417">417</a>		}
<a class="l" name="418" href="#418">418</a>
<a class="l" name="419" href="#419">419</a>		<b>if</b> (<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>() + <a class="d" href="#header">header</a>.<a href="/source/s?defs=frameSize&amp;project=rtmp_client">frameSize</a>() - <span class="n">4</span> &gt; <a class="d" href="#in">in</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>()) {
<a class="hl" name="420" href="#420">420</a>			<span class="c">// Last frame is incomplete</span>
<a class="l" name="421" href="#421">421</a>			<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>(<a class="d" href="#in">in</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>());
<a class="l" name="422" href="#422">422</a>			<b>return</b> <b>false</b>;
<a class="l" name="423" href="#423">423</a>		}
<a class="l" name="424" href="#424">424</a>
<a class="l" name="425" href="#425">425</a>		<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>(<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>() - <span class="n">4</span>);
<a class="l" name="426" href="#426">426</a>		<b>return</b> <b>true</b>;
<a class="l" name="427" href="#427">427</a>	}
<a class="l" name="428" href="#428">428</a>
<a class="l" name="429" href="#429">429</a>	<b>private</b> <a href="/source/s?defs=MP3Header&amp;project=rtmp_client">MP3Header</a> <a class="xmt" name="readHeader"/><a href="/source/s?refs=readHeader&amp;project=rtmp_client" class="xmt">readHeader</a>() {
<a class="hl" name="430" href="#430">430</a>		<a href="/source/s?defs=MP3Header&amp;project=rtmp_client">MP3Header</a> <a class="d" href="#header">header</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="431" href="#431">431</a>		<b>while</b> (<a class="d" href="#header">header</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a class="d" href="#in">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>() &gt; <span class="n">4</span>) {
<a class="l" name="432" href="#432">432</a>			<b>try</b> {
<a class="l" name="433" href="#433">433</a>				<a class="d" href="#header">header</a> = <b>new</b> <a href="/source/s?defs=MP3Header&amp;project=rtmp_client">MP3Header</a>(<a class="d" href="#in">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>());
<a class="l" name="434" href="#434">434</a>			} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> e) {
<a class="l" name="435" href="#435">435</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"MP3Reader :: readTag ::&gt;\n"</span>, e);
<a class="l" name="436" href="#436">436</a>				<b>break</b>;
<a class="l" name="437" href="#437">437</a>			} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="438" href="#438">438</a>				<a class="d" href="#searchNextFrame">searchNextFrame</a>();
<a class="l" name="439" href="#439">439</a>			}
<a class="hl" name="440" href="#440">440</a>		}
<a class="l" name="441" href="#441">441</a>		<b>return</b> <a class="d" href="#header">header</a>;
<a class="l" name="442" href="#442">442</a>	}
<a class="l" name="443" href="#443">443</a>
<a class="l" name="444" href="#444">444</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="445" href="#445">445</a>	<b>public</b> <b>synchronized</b> <a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a class="xmt" name="readTag"/><a href="/source/s?refs=readTag&amp;project=rtmp_client" class="xmt">readTag</a>() {
<a class="l" name="446" href="#446">446</a>		<b>if</b> (!<a class="d" href="#firstTags">firstTags</a>.<a href="/source/s?defs=isEmpty&amp;project=rtmp_client">isEmpty</a>()) {
<a class="l" name="447" href="#447">447</a>			<span class="c">// Return first tags before media data</span>
<a class="l" name="448" href="#448">448</a>			<b>return</b> <a class="d" href="#firstTags">firstTags</a>.<a href="/source/s?defs=removeFirst&amp;project=rtmp_client">removeFirst</a>();
<a class="l" name="449" href="#449">449</a>		}
<a class="hl" name="450" href="#450">450</a>
<a class="l" name="451" href="#451">451</a>		<a href="/source/s?defs=MP3Header&amp;project=rtmp_client">MP3Header</a> <a class="d" href="#header">header</a> = <a class="d" href="#readHeader">readHeader</a>();
<a class="l" name="452" href="#452">452</a>		<b>if</b> (<a class="d" href="#header">header</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="453" href="#453">453</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="454" href="#454">454</a>		}
<a class="l" name="455" href="#455">455</a>
<a class="l" name="456" href="#456">456</a>		<b>int</b> <a href="/source/s?defs=frameSize&amp;project=rtmp_client">frameSize</a> = <a class="d" href="#header">header</a>.<a href="/source/s?defs=frameSize&amp;project=rtmp_client">frameSize</a>();
<a class="l" name="457" href="#457">457</a>		<b>if</b> (<a href="/source/s?defs=frameSize&amp;project=rtmp_client">frameSize</a> == <span class="n">0</span>) {
<a class="l" name="458" href="#458">458</a>			<span class="c">// TODO find better solution how to deal with broken files...</span>
<a class="l" name="459" href="#459">459</a>			<span class="c">// See APPSERVER-62 for details</span>
<a class="hl" name="460" href="#460">460</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="461" href="#461">461</a>		}
<a class="l" name="462" href="#462">462</a>
<a class="l" name="463" href="#463">463</a>		<b>if</b> (<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>() + <a href="/source/s?defs=frameSize&amp;project=rtmp_client">frameSize</a> - <span class="n">4</span> &gt; <a class="d" href="#in">in</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>()) {
<a class="l" name="464" href="#464">464</a>			<span class="c">// Last frame is incomplete</span>
<a class="l" name="465" href="#465">465</a>			<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>(<a class="d" href="#in">in</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>());
<a class="l" name="466" href="#466">466</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="467" href="#467">467</a>		}
<a class="l" name="468" href="#468">468</a>
<a class="l" name="469" href="#469">469</a>		<a class="d" href="#tag">tag</a> = <b>new</b> <a href="/source/s?defs=Tag&amp;project=rtmp_client">Tag</a>(<a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=TYPE_AUDIO&amp;project=rtmp_client">TYPE_AUDIO</a>, (<b>int</b>) <a class="d" href="#currentTime">currentTime</a>, <a href="/source/s?defs=frameSize&amp;project=rtmp_client">frameSize</a> + <span class="n">1</span>,
<a class="hl" name="470" href="#470">470</a>				<a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a class="d" href="#prevSize">prevSize</a>);
<a class="l" name="471" href="#471">471</a>		<a class="d" href="#prevSize">prevSize</a> = <a href="/source/s?defs=frameSize&amp;project=rtmp_client">frameSize</a> + <span class="n">1</span>;
<a class="l" name="472" href="#472">472</a>		<a class="d" href="#currentTime">currentTime</a> += <a class="d" href="#header">header</a>.<a href="/source/s?defs=frameDuration&amp;project=rtmp_client">frameDuration</a>();
<a class="l" name="473" href="#473">473</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=body&amp;project=rtmp_client">body</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<a class="d" href="#tag">tag</a>.<a href="/source/s?defs=getBodySize&amp;project=rtmp_client">getBodySize</a>());
<a class="l" name="474" href="#474">474</a>		<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="475" href="#475">475</a>		<b>byte</b> <a href="/source/s?defs=tagType&amp;project=rtmp_client">tagType</a> = (<a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=FLAG_FORMAT_MP3&amp;project=rtmp_client">FLAG_FORMAT_MP3</a> &lt;&lt; <span class="n">4</span>)
<a class="l" name="476" href="#476">476</a>				| (<a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=FLAG_SIZE_16_BIT&amp;project=rtmp_client">FLAG_SIZE_16_BIT</a> &lt;&lt; <span class="n">1</span>);
<a class="l" name="477" href="#477">477</a>		<b>switch</b> (<a class="d" href="#header">header</a>.<a href="/source/s?defs=getSampleRate&amp;project=rtmp_client">getSampleRate</a>()) {
<a class="l" name="478" href="#478">478</a>			<b>case</b> <span class="n">44100</span>:
<a class="l" name="479" href="#479">479</a>				<a href="/source/s?defs=tagType&amp;project=rtmp_client">tagType</a> |= <a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=FLAG_RATE_44_KHZ&amp;project=rtmp_client">FLAG_RATE_44_KHZ</a> &lt;&lt; <span class="n">2</span>;
<a class="hl" name="480" href="#480">480</a>				<b>break</b>;
<a class="l" name="481" href="#481">481</a>			<b>case</b> <span class="n">22050</span>:
<a class="l" name="482" href="#482">482</a>				<a href="/source/s?defs=tagType&amp;project=rtmp_client">tagType</a> |= <a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=FLAG_RATE_22_KHZ&amp;project=rtmp_client">FLAG_RATE_22_KHZ</a> &lt;&lt; <span class="n">2</span>;
<a class="l" name="483" href="#483">483</a>				<b>break</b>;
<a class="l" name="484" href="#484">484</a>			<b>case</b> <span class="n">11025</span>:
<a class="l" name="485" href="#485">485</a>				<a href="/source/s?defs=tagType&amp;project=rtmp_client">tagType</a> |= <a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=FLAG_RATE_11_KHZ&amp;project=rtmp_client">FLAG_RATE_11_KHZ</a> &lt;&lt; <span class="n">2</span>;
<a class="l" name="486" href="#486">486</a>				<b>break</b>;
<a class="l" name="487" href="#487">487</a>			<b>default</b>:
<a class="l" name="488" href="#488">488</a>				<a href="/source/s?defs=tagType&amp;project=rtmp_client">tagType</a> |= <a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=FLAG_RATE_5_5_KHZ&amp;project=rtmp_client">FLAG_RATE_5_5_KHZ</a> &lt;&lt; <span class="n">2</span>;
<a class="l" name="489" href="#489">489</a>		}
<a class="hl" name="490" href="#490">490</a>		<a href="/source/s?defs=tagType&amp;project=rtmp_client">tagType</a> |= (<a class="d" href="#header">header</a>.<a href="/source/s?defs=isStereo&amp;project=rtmp_client">isStereo</a>() ? <a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=FLAG_TYPE_STEREO&amp;project=rtmp_client">FLAG_TYPE_STEREO</a>
<a class="l" name="491" href="#491">491</a>				: <a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=FLAG_TYPE_MONO&amp;project=rtmp_client">FLAG_TYPE_MONO</a>);
<a class="l" name="492" href="#492">492</a>		<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=tagType&amp;project=rtmp_client">tagType</a>);
<a class="l" name="493" href="#493">493</a>		<b>final</b> <b>int</b> <a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a> = <a class="d" href="#in">in</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>();
<a class="l" name="494" href="#494">494</a>		<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a class="d" href="#header">header</a>.<a href="/source/s?defs=getData&amp;project=rtmp_client">getData</a>());
<a class="l" name="495" href="#495">495</a>		<a class="d" href="#in">in</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>() + <a href="/source/s?defs=frameSize&amp;project=rtmp_client">frameSize</a> - <span class="n">4</span>);
<a class="l" name="496" href="#496">496</a>		<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#in">in</a>);
<a class="l" name="497" href="#497">497</a>		<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="498" href="#498">498</a>		<a class="d" href="#in">in</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>);
<a class="l" name="499" href="#499">499</a>
<a class="hl" name="500" href="#500">500</a>		<a class="d" href="#tag">tag</a>.<a href="/source/s?defs=setBody&amp;project=rtmp_client">setBody</a>(<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>);
<a class="l" name="501" href="#501">501</a>
<a class="l" name="502" href="#502">502</a>		<b>return</b> <a class="d" href="#tag">tag</a>;
<a class="l" name="503" href="#503">503</a>	}
<a class="l" name="504" href="#504">504</a>
<a class="l" name="505" href="#505">505</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="506" href="#506">506</a>	<b>public</b> <b>void</b> <a class="xmt" name="close"/><a href="/source/s?refs=close&amp;project=rtmp_client" class="xmt">close</a>() {
<a class="l" name="507" href="#507">507</a>		<b>if</b> (<a class="d" href="#posTimeMap">posTimeMap</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="508" href="#508">508</a>			<a class="d" href="#posTimeMap">posTimeMap</a>.<a href="/source/s?defs=clear&amp;project=rtmp_client">clear</a>();
<a class="l" name="509" href="#509">509</a>		}
<a class="hl" name="510" href="#510">510</a>		<a class="d" href="#mappedFile">mappedFile</a>.<a href="/source/s?defs=clear&amp;project=rtmp_client">clear</a>();
<a class="l" name="511" href="#511">511</a>		<b>if</b> (<a class="d" href="#in">in</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="512" href="#512">512</a>			<a class="d" href="#in">in</a>.<a href="/source/s?defs=free&amp;project=rtmp_client">free</a>();
<a class="l" name="513" href="#513">513</a>			<a class="d" href="#in">in</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="514" href="#514">514</a>		}
<a class="l" name="515" href="#515">515</a>		<b>try</b> {
<a class="l" name="516" href="#516">516</a>			<a class="d" href="#fis">fis</a>.<a class="d" href="#close">close</a>();
<a class="l" name="517" href="#517">517</a>			<a class="d" href="#channel">channel</a>.<a class="d" href="#close">close</a>();
<a class="l" name="518" href="#518">518</a>		} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> e) {
<a class="l" name="519" href="#519">519</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"MP3Reader :: close ::&gt;\n"</span>, e);
<a class="hl" name="520" href="#520">520</a>		}
<a class="l" name="521" href="#521">521</a>	}
<a class="l" name="522" href="#522">522</a>
<a class="l" name="523" href="#523">523</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="524" href="#524">524</a>	<b>public</b> <b>void</b> <a class="xmt" name="decodeHeader"/><a href="/source/s?refs=decodeHeader&amp;project=rtmp_client" class="xmt">decodeHeader</a>() {
<a class="l" name="525" href="#525">525</a>	}
<a class="l" name="526" href="#526">526</a>
<a class="l" name="527" href="#527">527</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="528" href="#528">528</a>	<b>public</b> <b>void</b> <a class="xmt" name="position"/><a href="/source/s?refs=position&amp;project=rtmp_client" class="xmt">position</a>(<b>long</b> <a class="xa" name="pos"/><a href="/source/s?refs=pos&amp;project=rtmp_client" class="xa">pos</a>) {
<a class="l" name="529" href="#529">529</a>		<b>if</b> (<a class="d" href="#pos">pos</a> == <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>.<a href="/source/s?defs=MAX_VALUE&amp;project=rtmp_client">MAX_VALUE</a>) {
<a class="hl" name="530" href="#530">530</a>			<span class="c">// Seek at EOF</span>
<a class="l" name="531" href="#531">531</a>			<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>(<a class="d" href="#in">in</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>());
<a class="l" name="532" href="#532">532</a>			<a class="d" href="#currentTime">currentTime</a> = <a class="d" href="#duration">duration</a>;
<a class="l" name="533" href="#533">533</a>			<b>return</b>;
<a class="l" name="534" href="#534">534</a>		}
<a class="l" name="535" href="#535">535</a>		<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>((<b>int</b>) <a class="d" href="#pos">pos</a>);
<a class="l" name="536" href="#536">536</a>		<span class="c">// Advance to next frame</span>
<a class="l" name="537" href="#537">537</a>		<a class="d" href="#searchNextFrame">searchNextFrame</a>();
<a class="l" name="538" href="#538">538</a>		<span class="c">// Make sure we can resolve file positions to timestamps</span>
<a class="l" name="539" href="#539">539</a>		<a class="d" href="#analyzeKeyFrames">analyzeKeyFrames</a>();
<a class="hl" name="540" href="#540">540</a>		<a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a> <a href="/source/s?defs=time&amp;project=rtmp_client">time</a> = <a class="d" href="#posTimeMap">posTimeMap</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>());
<a class="l" name="541" href="#541">541</a>		<b>if</b> (<a href="/source/s?defs=time&amp;project=rtmp_client">time</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="542" href="#542">542</a>			<a class="d" href="#currentTime">currentTime</a> = <a href="/source/s?defs=time&amp;project=rtmp_client">time</a>;
<a class="l" name="543" href="#543">543</a>		} <b>else</b> {
<a class="l" name="544" href="#544">544</a>			<span class="c">// Unknown frame position - this should never happen</span>
<a class="l" name="545" href="#545">545</a>			<a class="d" href="#currentTime">currentTime</a> = <span class="n">0</span>;
<a class="l" name="546" href="#546">546</a>		}
<a class="l" name="547" href="#547">547</a>	}
<a class="l" name="548" href="#548">548</a>
<a class="l" name="549" href="#549">549</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="550" href="#550">550</a>	<b>public</b> <b>synchronized</b> <a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a> <a class="xmt" name="analyzeKeyFrames"/><a href="/source/s?refs=analyzeKeyFrames&amp;project=rtmp_client" class="xmt">analyzeKeyFrames</a>() {
<a class="l" name="551" href="#551">551</a>		<b>if</b> (<a class="d" href="#frameMeta">frameMeta</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="552" href="#552">552</a>			<b>return</b> <a class="d" href="#frameMeta">frameMeta</a>;
<a class="l" name="553" href="#553">553</a>		}
<a class="l" name="554" href="#554">554</a>
<a class="l" name="555" href="#555">555</a>		<span class="c">// check for cached frame informations</span>
<a class="l" name="556" href="#556">556</a>		<b>if</b> (<a href="/source/s?defs=frameCache&amp;project=rtmp_client">frameCache</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="557" href="#557">557</a>			<a class="d" href="#frameMeta">frameMeta</a> = <a href="/source/s?defs=frameCache&amp;project=rtmp_client">frameCache</a>.<a href="/source/s?defs=loadKeyFrameMeta&amp;project=rtmp_client">loadKeyFrameMeta</a>(<a href="/source/s?defs=file&amp;project=rtmp_client">file</a>);
<a class="l" name="558" href="#558">558</a>			<b>if</b> (<a class="d" href="#frameMeta">frameMeta</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a class="d" href="#frameMeta">frameMeta</a>.<a class="d" href="#duration">duration</a> &gt; <span class="n">0</span>) {
<a class="l" name="559" href="#559">559</a>				<span class="c">// Frame data loaded, create other mappings</span>
<a class="hl" name="560" href="#560">560</a>				<a class="d" href="#duration">duration</a> = <a class="d" href="#frameMeta">frameMeta</a>.<a class="d" href="#duration">duration</a>;
<a class="l" name="561" href="#561">561</a>				<a class="d" href="#frameMeta">frameMeta</a>.<a href="/source/s?defs=audioOnly&amp;project=rtmp_client">audioOnly</a> = <b>true</b>;
<a class="l" name="562" href="#562">562</a>				<a class="d" href="#posTimeMap">posTimeMap</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>&gt;();
<a class="l" name="563" href="#563">563</a>				<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#frameMeta">frameMeta</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>; i++) {
<a class="l" name="564" href="#564">564</a>					<a class="d" href="#posTimeMap">posTimeMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>int</b>) <a class="d" href="#frameMeta">frameMeta</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a>[i],
<a class="l" name="565" href="#565">565</a>							(<b>double</b>) <a class="d" href="#frameMeta">frameMeta</a>.<a href="/source/s?defs=timestamps&amp;project=rtmp_client">timestamps</a>[i]);
<a class="l" name="566" href="#566">566</a>				}
<a class="l" name="567" href="#567">567</a>				<b>return</b> <a class="d" href="#frameMeta">frameMeta</a>;
<a class="l" name="568" href="#568">568</a>			}
<a class="l" name="569" href="#569">569</a>		}
<a class="hl" name="570" href="#570">570</a>
<a class="l" name="571" href="#571">571</a>		<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt; <a href="/source/s?defs=positionList&amp;project=rtmp_client">positionList</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt;();
<a class="l" name="572" href="#572">572</a>		<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>&gt; <a href="/source/s?defs=timestampList&amp;project=rtmp_client">timestampList</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>&gt;();
<a class="l" name="573" href="#573">573</a>		<a class="d" href="#dataRate">dataRate</a> = <span class="n">0</span>;
<a class="l" name="574" href="#574">574</a>		<b>long</b> <a href="/source/s?defs=rate&amp;project=rtmp_client">rate</a> = <span class="n">0</span>;
<a class="l" name="575" href="#575">575</a>		<b>int</b> <a href="/source/s?defs=count&amp;project=rtmp_client">count</a> = <span class="n">0</span>;
<a class="l" name="576" href="#576">576</a>		<b>int</b> <a href="/source/s?defs=origPos&amp;project=rtmp_client">origPos</a> = <a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>();
<a class="l" name="577" href="#577">577</a>		<b>double</b> <a href="/source/s?defs=time&amp;project=rtmp_client">time</a> = <span class="n">0</span>;
<a class="l" name="578" href="#578">578</a>		<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>(<span class="n">0</span>);
<a class="l" name="579" href="#579">579</a>		<span class="c">// processID3v2Header();</span>
<a class="hl" name="580" href="#580">580</a>		<a class="d" href="#searchNextFrame">searchNextFrame</a>();
<a class="l" name="581" href="#581">581</a>		<b>while</b> (<b>this</b>.<a class="d" href="#hasMoreTags">hasMoreTags</a>()) {
<a class="l" name="582" href="#582">582</a>			<a href="/source/s?defs=MP3Header&amp;project=rtmp_client">MP3Header</a> <a class="d" href="#header">header</a> = <a class="d" href="#readHeader">readHeader</a>();
<a class="l" name="583" href="#583">583</a>			<b>if</b> (<a class="d" href="#header">header</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="584" href="#584">584</a>				<span class="c">// No more tags</span>
<a class="l" name="585" href="#585">585</a>				<b>break</b>;
<a class="l" name="586" href="#586">586</a>			}
<a class="l" name="587" href="#587">587</a>
<a class="l" name="588" href="#588">588</a>			<b>if</b> (<a class="d" href="#header">header</a>.<a href="/source/s?defs=frameSize&amp;project=rtmp_client">frameSize</a>() == <span class="n">0</span>) {
<a class="l" name="589" href="#589">589</a>				<span class="c">// TODO find better solution how to deal with broken files...</span>
<a class="hl" name="590" href="#590">590</a>				<span class="c">// See APPSERVER-62 for details</span>
<a class="l" name="591" href="#591">591</a>				<b>break</b>;
<a class="l" name="592" href="#592">592</a>			}
<a class="l" name="593" href="#593">593</a>
<a class="l" name="594" href="#594">594</a>			<b>int</b> <a class="d" href="#pos">pos</a> = <a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>() - <span class="n">4</span>;
<a class="l" name="595" href="#595">595</a>			<b>if</b> (<a class="d" href="#pos">pos</a> + <a class="d" href="#header">header</a>.<a href="/source/s?defs=frameSize&amp;project=rtmp_client">frameSize</a>() &gt; <a class="d" href="#in">in</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>()) {
<a class="l" name="596" href="#596">596</a>				<span class="c">// Last frame is incomplete</span>
<a class="l" name="597" href="#597">597</a>				<b>break</b>;
<a class="l" name="598" href="#598">598</a>			}
<a class="l" name="599" href="#599">599</a>
<a class="hl" name="600" href="#600">600</a>			<a href="/source/s?defs=positionList&amp;project=rtmp_client">positionList</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a class="d" href="#pos">pos</a>);
<a class="l" name="601" href="#601">601</a>			<a href="/source/s?defs=timestampList&amp;project=rtmp_client">timestampList</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=time&amp;project=rtmp_client">time</a>);
<a class="l" name="602" href="#602">602</a>			<a href="/source/s?defs=rate&amp;project=rtmp_client">rate</a> += <a class="d" href="#header">header</a>.<a href="/source/s?defs=getBitRate&amp;project=rtmp_client">getBitRate</a>() / <span class="n">1000</span>;
<a class="l" name="603" href="#603">603</a>			<a href="/source/s?defs=time&amp;project=rtmp_client">time</a> += <a class="d" href="#header">header</a>.<a href="/source/s?defs=frameDuration&amp;project=rtmp_client">frameDuration</a>();
<a class="l" name="604" href="#604">604</a>			<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>(<a class="d" href="#pos">pos</a> + <a class="d" href="#header">header</a>.<a href="/source/s?defs=frameSize&amp;project=rtmp_client">frameSize</a>());
<a class="l" name="605" href="#605">605</a>			<a href="/source/s?defs=count&amp;project=rtmp_client">count</a>++;
<a class="l" name="606" href="#606">606</a>		}
<a class="l" name="607" href="#607">607</a>		<span class="c">// restore the pos</span>
<a class="l" name="608" href="#608">608</a>		<a class="d" href="#in">in</a>.<a class="d" href="#position">position</a>(<a href="/source/s?defs=origPos&amp;project=rtmp_client">origPos</a>);
<a class="l" name="609" href="#609">609</a>
<a class="hl" name="610" href="#610">610</a>		<a class="d" href="#duration">duration</a> = (<b>long</b>) <a href="/source/s?defs=time&amp;project=rtmp_client">time</a>;
<a class="l" name="611" href="#611">611</a>		<a class="d" href="#dataRate">dataRate</a> = (<b>int</b>) (<a href="/source/s?defs=rate&amp;project=rtmp_client">rate</a> / <a href="/source/s?defs=count&amp;project=rtmp_client">count</a>);
<a class="l" name="612" href="#612">612</a>		<a class="d" href="#posTimeMap">posTimeMap</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>&gt;();
<a class="l" name="613" href="#613">613</a>		<a class="d" href="#frameMeta">frameMeta</a> = <b>new</b> <a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a>();
<a class="l" name="614" href="#614">614</a>		<a class="d" href="#frameMeta">frameMeta</a>.<a class="d" href="#duration">duration</a> = <a class="d" href="#duration">duration</a>;
<a class="l" name="615" href="#615">615</a>		<a class="d" href="#frameMeta">frameMeta</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a> = <b>new</b> <b>long</b>[<a href="/source/s?defs=positionList&amp;project=rtmp_client">positionList</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>()];
<a class="l" name="616" href="#616">616</a>		<a class="d" href="#frameMeta">frameMeta</a>.<a href="/source/s?defs=timestamps&amp;project=rtmp_client">timestamps</a> = <b>new</b> <b>int</b>[<a href="/source/s?defs=timestampList&amp;project=rtmp_client">timestampList</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>()];
<a class="l" name="617" href="#617">617</a>		<a class="d" href="#frameMeta">frameMeta</a>.<a href="/source/s?defs=audioOnly&amp;project=rtmp_client">audioOnly</a> = <b>true</b>;
<a class="l" name="618" href="#618">618</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#frameMeta">frameMeta</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>; i++) {
<a class="l" name="619" href="#619">619</a>			<a class="d" href="#frameMeta">frameMeta</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a>[i] = <a href="/source/s?defs=positionList&amp;project=rtmp_client">positionList</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(i);
<a class="hl" name="620" href="#620">620</a>			<a class="d" href="#frameMeta">frameMeta</a>.<a href="/source/s?defs=timestamps&amp;project=rtmp_client">timestamps</a>[i] = <a href="/source/s?defs=timestampList&amp;project=rtmp_client">timestampList</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(i).<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>();
<a class="l" name="621" href="#621">621</a>			<a class="d" href="#posTimeMap">posTimeMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=positionList&amp;project=rtmp_client">positionList</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(i), <a href="/source/s?defs=timestampList&amp;project=rtmp_client">timestampList</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(i));
<a class="l" name="622" href="#622">622</a>		}
<a class="l" name="623" href="#623">623</a>		<b>if</b> (<a href="/source/s?defs=frameCache&amp;project=rtmp_client">frameCache</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="624" href="#624">624</a>			<a href="/source/s?defs=frameCache&amp;project=rtmp_client">frameCache</a>.<a href="/source/s?defs=saveKeyFrameMeta&amp;project=rtmp_client">saveKeyFrameMeta</a>(<a href="/source/s?defs=file&amp;project=rtmp_client">file</a>, <a class="d" href="#frameMeta">frameMeta</a>);
<a class="l" name="625" href="#625">625</a>		}
<a class="l" name="626" href="#626">626</a>		<b>return</b> <a class="d" href="#frameMeta">frameMeta</a>;
<a class="l" name="627" href="#627">627</a>	}
<a class="l" name="628" href="#628">628</a>
<a class="l" name="629" href="#629">629</a>	<span class="c">/**
<a class="hl" name="630" href="#630">630</a>	 * Simple holder for id3 meta data
<a class="l" name="631" href="#631">631</a>	 */</span>
<a class="l" name="632" href="#632">632</a>	<b>static</b> <b>class</b> <a class="xc" name="MetaData"/><a href="/source/s?refs=MetaData&amp;project=rtmp_client" class="xc">MetaData</a> {
<a class="l" name="633" href="#633">633</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="album"/><a href="/source/s?refs=album&amp;project=rtmp_client" class="xfld">album</a> = <span class="s">""</span>;
<a class="l" name="634" href="#634">634</a>
<a class="l" name="635" href="#635">635</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="artist"/><a href="/source/s?refs=artist&amp;project=rtmp_client" class="xfld">artist</a> = <span class="s">""</span>;
<a class="l" name="636" href="#636">636</a>
<a class="l" name="637" href="#637">637</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="genre"/><a href="/source/s?refs=genre&amp;project=rtmp_client" class="xfld">genre</a> = <span class="s">""</span>;
<a class="l" name="638" href="#638">638</a>
<a class="l" name="639" href="#639">639</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="songName"/><a href="/source/s?refs=songName&amp;project=rtmp_client" class="xfld">songName</a> = <span class="s">""</span>;
<a class="hl" name="640" href="#640">640</a>
<a class="l" name="641" href="#641">641</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="track"/><a href="/source/s?refs=track&amp;project=rtmp_client" class="xfld">track</a> = <span class="s">""</span>;
<a class="l" name="642" href="#642">642</a>
<a class="l" name="643" href="#643">643</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="year"/><a href="/source/s?refs=year&amp;project=rtmp_client" class="xfld">year</a> = <span class="s">""</span>;
<a class="l" name="644" href="#644">644</a>
<a class="l" name="645" href="#645">645</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="comment"/><a href="/source/s?refs=comment&amp;project=rtmp_client" class="xfld">comment</a> = <span class="s">""</span>;
<a class="l" name="646" href="#646">646</a>
<a class="l" name="647" href="#647">647</a>		<b>byte</b>[] <a class="xfld" name="covr"/><a href="/source/s?refs=covr&amp;project=rtmp_client" class="xfld">covr</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="648" href="#648">648</a>
<a class="l" name="649" href="#649">649</a>		<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getAlbum"/><a href="/source/s?refs=getAlbum&amp;project=rtmp_client" class="xmt">getAlbum</a>() {
<a class="hl" name="650" href="#650">650</a>			<b>return</b> <a href="/source/s?defs=album&amp;project=rtmp_client">album</a>;
<a class="l" name="651" href="#651">651</a>		}
<a class="l" name="652" href="#652">652</a>
<a class="l" name="653" href="#653">653</a>		<b>public</b> <b>void</b> <a class="xmt" name="setAlbum"/><a href="/source/s?refs=setAlbum&amp;project=rtmp_client" class="xmt">setAlbum</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="album"/><a href="/source/s?refs=album&amp;project=rtmp_client" class="xa">album</a>) {
<a class="l" name="654" href="#654">654</a>			<b>this</b>.<a href="/source/s?defs=album&amp;project=rtmp_client">album</a> = <a href="/source/s?defs=album&amp;project=rtmp_client">album</a>;
<a class="l" name="655" href="#655">655</a>		}
<a class="l" name="656" href="#656">656</a>
<a class="l" name="657" href="#657">657</a>		<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getArtist"/><a href="/source/s?refs=getArtist&amp;project=rtmp_client" class="xmt">getArtist</a>() {
<a class="l" name="658" href="#658">658</a>			<b>return</b> <a href="/source/s?defs=artist&amp;project=rtmp_client">artist</a>;
<a class="l" name="659" href="#659">659</a>		}
<a class="hl" name="660" href="#660">660</a>
<a class="l" name="661" href="#661">661</a>		<b>public</b> <b>void</b> <a class="xmt" name="setArtist"/><a href="/source/s?refs=setArtist&amp;project=rtmp_client" class="xmt">setArtist</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="artist"/><a href="/source/s?refs=artist&amp;project=rtmp_client" class="xa">artist</a>) {
<a class="l" name="662" href="#662">662</a>			<b>this</b>.<a href="/source/s?defs=artist&amp;project=rtmp_client">artist</a> = <a href="/source/s?defs=artist&amp;project=rtmp_client">artist</a>;
<a class="l" name="663" href="#663">663</a>		}
<a class="l" name="664" href="#664">664</a>
<a class="l" name="665" href="#665">665</a>		<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getGenre"/><a href="/source/s?refs=getGenre&amp;project=rtmp_client" class="xmt">getGenre</a>() {
<a class="l" name="666" href="#666">666</a>			<b>return</b> <a href="/source/s?defs=genre&amp;project=rtmp_client">genre</a>;
<a class="l" name="667" href="#667">667</a>		}
<a class="l" name="668" href="#668">668</a>
<a class="l" name="669" href="#669">669</a>		<b>public</b> <b>void</b> <a class="xmt" name="setGenre"/><a href="/source/s?refs=setGenre&amp;project=rtmp_client" class="xmt">setGenre</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="genre"/><a href="/source/s?refs=genre&amp;project=rtmp_client" class="xa">genre</a>) {
<a class="hl" name="670" href="#670">670</a>			<b>this</b>.<a href="/source/s?defs=genre&amp;project=rtmp_client">genre</a> = <a href="/source/s?defs=genre&amp;project=rtmp_client">genre</a>;
<a class="l" name="671" href="#671">671</a>		}
<a class="l" name="672" href="#672">672</a>
<a class="l" name="673" href="#673">673</a>		<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getSongName"/><a href="/source/s?refs=getSongName&amp;project=rtmp_client" class="xmt">getSongName</a>() {
<a class="l" name="674" href="#674">674</a>			<b>return</b> <a href="/source/s?defs=songName&amp;project=rtmp_client">songName</a>;
<a class="l" name="675" href="#675">675</a>		}
<a class="l" name="676" href="#676">676</a>
<a class="l" name="677" href="#677">677</a>		<b>public</b> <b>void</b> <a class="xmt" name="setSongName"/><a href="/source/s?refs=setSongName&amp;project=rtmp_client" class="xmt">setSongName</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="songName"/><a href="/source/s?refs=songName&amp;project=rtmp_client" class="xa">songName</a>) {
<a class="l" name="678" href="#678">678</a>			<b>this</b>.<a href="/source/s?defs=songName&amp;project=rtmp_client">songName</a> = <a href="/source/s?defs=songName&amp;project=rtmp_client">songName</a>;
<a class="l" name="679" href="#679">679</a>		}
<a class="hl" name="680" href="#680">680</a>
<a class="l" name="681" href="#681">681</a>		<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getTrack"/><a href="/source/s?refs=getTrack&amp;project=rtmp_client" class="xmt">getTrack</a>() {
<a class="l" name="682" href="#682">682</a>			<b>return</b> <a href="/source/s?defs=track&amp;project=rtmp_client">track</a>;
<a class="l" name="683" href="#683">683</a>		}
<a class="l" name="684" href="#684">684</a>
<a class="l" name="685" href="#685">685</a>		<b>public</b> <b>void</b> <a class="xmt" name="setTrack"/><a href="/source/s?refs=setTrack&amp;project=rtmp_client" class="xmt">setTrack</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="track"/><a href="/source/s?refs=track&amp;project=rtmp_client" class="xa">track</a>) {
<a class="l" name="686" href="#686">686</a>			<b>this</b>.<a href="/source/s?defs=track&amp;project=rtmp_client">track</a> = <a href="/source/s?defs=track&amp;project=rtmp_client">track</a>;
<a class="l" name="687" href="#687">687</a>		}
<a class="l" name="688" href="#688">688</a>
<a class="l" name="689" href="#689">689</a>		<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getYear"/><a href="/source/s?refs=getYear&amp;project=rtmp_client" class="xmt">getYear</a>() {
<a class="hl" name="690" href="#690">690</a>			<b>return</b> <a href="/source/s?defs=year&amp;project=rtmp_client">year</a>;
<a class="l" name="691" href="#691">691</a>		}
<a class="l" name="692" href="#692">692</a>
<a class="l" name="693" href="#693">693</a>		<b>public</b> <b>void</b> <a class="xmt" name="setYear"/><a href="/source/s?refs=setYear&amp;project=rtmp_client" class="xmt">setYear</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="year"/><a href="/source/s?refs=year&amp;project=rtmp_client" class="xa">year</a>) {
<a class="l" name="694" href="#694">694</a>			<b>this</b>.<a href="/source/s?defs=year&amp;project=rtmp_client">year</a> = <a href="/source/s?defs=year&amp;project=rtmp_client">year</a>;
<a class="l" name="695" href="#695">695</a>		}
<a class="l" name="696" href="#696">696</a>
<a class="l" name="697" href="#697">697</a>		<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getComment"/><a href="/source/s?refs=getComment&amp;project=rtmp_client" class="xmt">getComment</a>() {
<a class="l" name="698" href="#698">698</a>			<b>return</b> <a href="/source/s?defs=comment&amp;project=rtmp_client">comment</a>;
<a class="l" name="699" href="#699">699</a>		}
<a class="hl" name="700" href="#700">700</a>
<a class="l" name="701" href="#701">701</a>		<b>public</b> <b>void</b> <a class="xmt" name="setComment"/><a href="/source/s?refs=setComment&amp;project=rtmp_client" class="xmt">setComment</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="comment"/><a href="/source/s?refs=comment&amp;project=rtmp_client" class="xa">comment</a>) {
<a class="l" name="702" href="#702">702</a>			<b>this</b>.<a href="/source/s?defs=comment&amp;project=rtmp_client">comment</a> = <a href="/source/s?defs=comment&amp;project=rtmp_client">comment</a>;
<a class="l" name="703" href="#703">703</a>		}
<a class="l" name="704" href="#704">704</a>
<a class="l" name="705" href="#705">705</a>		<b>public</b> <b>byte</b>[] <a class="xmt" name="getCovr"/><a href="/source/s?refs=getCovr&amp;project=rtmp_client" class="xmt">getCovr</a>() {
<a class="l" name="706" href="#706">706</a>			<b>return</b> <a href="/source/s?defs=covr&amp;project=rtmp_client">covr</a>;
<a class="l" name="707" href="#707">707</a>		}
<a class="l" name="708" href="#708">708</a>
<a class="l" name="709" href="#709">709</a>		<b>public</b> <b>void</b> <a class="xmt" name="setCovr"/><a href="/source/s?refs=setCovr&amp;project=rtmp_client" class="xmt">setCovr</a>(<b>byte</b>[] <a class="xa" name="covr"/><a href="/source/s?refs=covr&amp;project=rtmp_client" class="xa">covr</a>) {
<a class="hl" name="710" href="#710">710</a>			<b>this</b>.<a href="/source/s?defs=covr&amp;project=rtmp_client">covr</a> = <a href="/source/s?defs=covr&amp;project=rtmp_client">covr</a>;
<a class="l" name="711" href="#711">711</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Cover image array size: {}"</span>, <a href="/source/s?defs=covr&amp;project=rtmp_client">covr</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>);
<a class="l" name="712" href="#712">712</a>		}
<a class="l" name="713" href="#713">713</a>
<a class="l" name="714" href="#714">714</a>		<b>public</b> <b>boolean</b> <a class="xmt" name="hasCoverImage"/><a href="/source/s?refs=hasCoverImage&amp;project=rtmp_client" class="xmt">hasCoverImage</a>() {
<a class="l" name="715" href="#715">715</a>			<b>return</b> <a href="/source/s?defs=covr&amp;project=rtmp_client">covr</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="716" href="#716">716</a>		}
<a class="l" name="717" href="#717">717</a>
<a class="l" name="718" href="#718">718</a>	}
<a class="l" name="719" href="#719">719</a>
<a class="hl" name="720" href="#720">720</a>}
<a class="l" name="721" href="#721">721</a>