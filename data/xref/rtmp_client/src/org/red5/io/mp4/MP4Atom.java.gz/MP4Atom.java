<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["CompositionTimeSampleRecord",1025],["MP4Atom",60],["Record",980],["TimeSampleRecord",1006]]],["Package","xp",[["org.red5.io.mp4",1]]],["Method","xmt",[["CompositionTimeSampleRecord",1030],["MP4Atom",146],["Record",987],["TimeSampleRecord",1011],["createAtom",159],["createDate",932],["create_audio_sample_entry_atom",314],["create_avc_config_atom",824],["create_chunk_large_offset_atom",340],["create_chunk_offset_atom",362],["create_compact_sample_size_atom",535],["create_composite_atom",274],["create_composition_time_to_sample_atom",906],["create_esd_atom",887],["create_full_atom",261],["create_handler_atom",381],["create_media_header_atom",410],["create_movie_header_atom",445],["create_pasp_atom",869],["create_sample_description_atom",488],["create_sample_size_atom",506],["create_sample_to_chunk_atom",578],["create_sound_media_header_atom",649],["create_sync_sample_atom",602],["create_time_to_sample_atom",627],["create_track_header_atom",663],["create_video_media_header_atom",709],["create_video_sample_entry_atom",747],["create_visual_sample_entry_atom",726],["getAvcLevel",788],["getAvcProfile",792],["getChannelCount",304],["getChildren",954],["getChunks",353],["getCompositionTimeToSamplesRecords",923],["getConsecutiveSamples",1016],["getConsecutiveSamples",1035],["getDuration",431],["getEsd_descriptor",897],["getFirstChunk",993],["getHandlerType",400],["getHeight",780],["getRecords",569],["getSampleDescriptionIndex",1001],["getSampleDuration",1020],["getSampleOffset",1039],["getSampleSize",526],["getSamples",522],["getSamplesPerChunk",997],["getSize",962],["getSyncSamples",593],["getTimeScale",435],["getTimeToSamplesRecords",618],["getType",969],["getVideoConfigBytes",796],["getWidth",784],["intToType",941],["lookup",290],["setSampleOffset",1043],["toString",976],["typeToInt",936]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=mp4&amp;project=rtmp_client">mp4</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2007 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><span class="c">/**
<a class="l" name="23" href="#23">23</a>	This software module was originally developed by Apple Computer, Inc. in the
<a class="l" name="24" href="#24">24</a>	course of development of MPEG-4. This software module is an implementation of
<a class="l" name="25" href="#25">25</a>	a part of one or more MPEG-4 tools as specified by MPEG-4. <a href="/source/s?path=ISO/">ISO</a>/<a href="/source/s?path=ISO/IEC">IEC</a> gives users
<a class="l" name="26" href="#26">26</a>	of MPEG-4 free license to this software module or modifications thereof for
<a class="l" name="27" href="#27">27</a>	use in hardware or software products claiming conformance to MPEG-4. Those
<a class="l" name="28" href="#28">28</a>	intending to use this software module in hardware or software products are
<a class="l" name="29" href="#29">29</a>	advised that its use may infringe existing patents. The original developer of
<a class="hl" name="30" href="#30">30</a>	this software module and <a href="/source/s?path=his/">his</a>/<a href="/source/s?path=his/her">her</a> company, the subsequent editors and their
<a class="l" name="31" href="#31">31</a>	companies, and <a href="/source/s?path=ISO/">ISO</a>/<a href="/source/s?path=ISO/IEC">IEC</a> have no liability for use of this software module or
<a class="l" name="32" href="#32">32</a>	modifications thereof in an implementation. Copyright is not released for non
<a class="l" name="33" href="#33">33</a>	MPEG-4 conforming products. Apple Computer, Inc. retains full right to use the
<a class="l" name="34" href="#34">34</a>	code for its own purpose, assign or donate the code to a third party and to
<a class="l" name="35" href="#35">35</a>	inhibit third parties from using the code for non MPEG-4 conforming products.
<a class="l" name="36" href="#36">36</a>	This copyright notice must be included in all copies or	derivative works.
<a class="l" name="37" href="#37">37</a>	Copyright (c) 1999.
<a class="l" name="38" href="#38">38</a>*/</span>
<a class="l" name="39" href="#39">39</a>
<a class="hl" name="40" href="#40">40</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="41" href="#41">41</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>;
<a class="l" name="42" href="#42">42</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Date&amp;project=rtmp_client">Date</a>;
<a class="l" name="43" href="#43">43</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>;
<a class="l" name="44" href="#44">44</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>;
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="47" href="#47">47</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a><span class="c">/**
<a class="hl" name="50" href="#50">50</a> * The &lt;code&gt;MP4Atom&lt;/code&gt; object represents the smallest information block
<a class="l" name="51" href="#51">51</a> * of the MP4 file. It could contain other atoms as children.
<a class="l" name="52" href="#52">52</a> *
<a class="l" name="53" href="#53">53</a> * 01/29/2008 - Added support for avc1 atom (video sample)
<a class="l" name="54" href="#54">54</a> * 02/05/2008 - Added stss - sync sample atom and stts - time to sample atom
<a class="l" name="55" href="#55">55</a> * 10/2008    - Added pasp - pixel aspect ratio atom
<a class="l" name="56" href="#56">56</a> * 10/2010	  - Added ctts atom
<a class="l" name="57" href="#57">57</a> *
<a class="l" name="58" href="#58">58</a> * <strong>@author</strong> Paul Gregoire (mondain@gmail.com)
<a class="l" name="59" href="#59">59</a> */</span>
<a class="hl" name="60" href="#60">60</a><b>public</b> <b>class</b> <a class="xc" name="MP4Atom"/><a href="/source/s?refs=MP4Atom&amp;project=rtmp_client" class="xc">MP4Atom</a> {
<a class="l" name="61" href="#61">61</a>
<a class="l" name="62" href="#62">62</a>	<b>private</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<b>class</b>);
<a class="l" name="63" href="#63">63</a>
<a class="l" name="64" href="#64">64</a>	<span class="c">/** The size of the atom. */</span>
<a class="l" name="65" href="#65">65</a>	<b>protected</b> <b>long</b> <a class="xfld" name="size"/><a href="/source/s?refs=size&amp;project=rtmp_client" class="xfld">size</a>;
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a>	<span class="c">/** The type of the atom. */</span>
<a class="l" name="68" href="#68">68</a>	<b>protected</b> <b>int</b> <a class="xfld" name="type"/><a href="/source/s?refs=type&amp;project=rtmp_client" class="xfld">type</a>;
<a class="l" name="69" href="#69">69</a>
<a class="hl" name="70" href="#70">70</a>	<span class="c">/** The user's extended type of the atom. */</span>
<a class="l" name="71" href="#71">71</a>	<b>protected</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="uuid"/><a href="/source/s?refs=uuid&amp;project=rtmp_client" class="xfld">uuid</a>;
<a class="l" name="72" href="#72">72</a>
<a class="l" name="73" href="#73">73</a>	<span class="c">/** The amount of bytes that are read from the mpeg stream. */</span>
<a class="l" name="74" href="#74">74</a>	<b>protected</b> <b>long</b> <a class="xfld" name="readed"/><a href="/source/s?refs=readed&amp;project=rtmp_client" class="xfld">readed</a>;
<a class="l" name="75" href="#75">75</a>
<a class="l" name="76" href="#76">76</a>	<span class="c">/** The children of this atom. */</span>
<a class="l" name="77" href="#77">77</a>	<b>protected</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>&gt; <a class="xfld" name="children"/><a href="/source/s?refs=children&amp;project=rtmp_client" class="xfld">children</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>&gt;(<span class="n">3</span>);
<a class="l" name="78" href="#78">78</a>
<a class="l" name="79" href="#79">79</a>	<b>protected</b> <b>int</b> <a class="xfld" name="version"/><a href="/source/s?refs=version&amp;project=rtmp_client" class="xfld">version</a> = <span class="n">0</span>;
<a class="hl" name="80" href="#80">80</a>
<a class="l" name="81" href="#81">81</a>	<b>protected</b> <b>int</b> <a class="xfld" name="flags"/><a href="/source/s?refs=flags&amp;project=rtmp_client" class="xfld">flags</a> = <span class="n">0</span>;
<a class="l" name="82" href="#82">82</a>
<a class="l" name="83" href="#83">83</a>	<b>private</b> <b>int</b> <a class="xfld" name="channelCount"/><a href="/source/s?refs=channelCount&amp;project=rtmp_client" class="xfld">channelCount</a> = <span class="n">0</span>;
<a class="l" name="84" href="#84">84</a>
<a class="l" name="85" href="#85">85</a>	<b>protected</b> <b>int</b> <a class="xfld" name="entryCount"/><a href="/source/s?refs=entryCount&amp;project=rtmp_client" class="xfld">entryCount</a>;
<a class="l" name="86" href="#86">86</a>
<a class="l" name="87" href="#87">87</a>	<span class="c">/** The decoding time to sample table. */</span>
<a class="l" name="88" href="#88">88</a>	<b>protected</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt; <a class="xfld" name="chunks"/><a href="/source/s?refs=chunks&amp;project=rtmp_client" class="xfld">chunks</a>;
<a class="l" name="89" href="#89">89</a>
<a class="hl" name="90" href="#90">90</a>	<b>protected</b> <b>int</b> <a class="xfld" name="handlerType"/><a href="/source/s?refs=handlerType&amp;project=rtmp_client" class="xfld">handlerType</a>;
<a class="l" name="91" href="#91">91</a>
<a class="l" name="92" href="#92">92</a>	<b>protected</b> <a href="/source/s?defs=Date&amp;project=rtmp_client">Date</a> <a class="xfld" name="creationTime"/><a href="/source/s?refs=creationTime&amp;project=rtmp_client" class="xfld">creationTime</a>;
<a class="l" name="93" href="#93">93</a>
<a class="l" name="94" href="#94">94</a>	<b>protected</b> <a href="/source/s?defs=Date&amp;project=rtmp_client">Date</a> <a class="xfld" name="modificationTime"/><a href="/source/s?refs=modificationTime&amp;project=rtmp_client" class="xfld">modificationTime</a>;
<a class="l" name="95" href="#95">95</a>
<a class="l" name="96" href="#96">96</a>	<b>protected</b> <b>int</b> <a class="xfld" name="timeScale"/><a href="/source/s?refs=timeScale&amp;project=rtmp_client" class="xfld">timeScale</a>;
<a class="l" name="97" href="#97">97</a>
<a class="l" name="98" href="#98">98</a>	<b>protected</b> <b>long</b> <a class="xfld" name="duration"/><a href="/source/s?refs=duration&amp;project=rtmp_client" class="xfld">duration</a>;
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a>	<b>protected</b> <b>int</b> <a class="xfld" name="sampleSize"/><a href="/source/s?refs=sampleSize&amp;project=rtmp_client" class="xfld">sampleSize</a>;
<a class="l" name="101" href="#101">101</a>
<a class="l" name="102" href="#102">102</a>	<b>protected</b> <b>int</b> <a class="xfld" name="sampleCount"/><a href="/source/s?refs=sampleCount&amp;project=rtmp_client" class="xfld">sampleCount</a>;
<a class="l" name="103" href="#103">103</a>
<a class="l" name="104" href="#104">104</a>	<span class="c">/** The decoding time to sample table. */</span>
<a class="l" name="105" href="#105">105</a>	<b>protected</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt; <a class="xfld" name="samples"/><a href="/source/s?refs=samples&amp;project=rtmp_client" class="xfld">samples</a>;
<a class="l" name="106" href="#106">106</a>
<a class="l" name="107" href="#107">107</a>	<b>protected</b> <b>int</b> <a class="xfld" name="fieldSize"/><a href="/source/s?refs=fieldSize&amp;project=rtmp_client" class="xfld">fieldSize</a>;
<a class="l" name="108" href="#108">108</a>
<a class="l" name="109" href="#109">109</a>	<span class="c">/** The decoding time to sample table. */</span>
<a class="hl" name="110" href="#110">110</a>	<b>protected</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Record&amp;project=rtmp_client">Record</a>&gt; <a class="xfld" name="records"/><a href="/source/s?refs=records&amp;project=rtmp_client" class="xfld">records</a>;
<a class="l" name="111" href="#111">111</a>
<a class="l" name="112" href="#112">112</a>	<b>protected</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt; <a class="xfld" name="syncSamples"/><a href="/source/s?refs=syncSamples&amp;project=rtmp_client" class="xfld">syncSamples</a>;
<a class="l" name="113" href="#113">113</a>
<a class="l" name="114" href="#114">114</a>	<b>protected</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=TimeSampleRecord&amp;project=rtmp_client">TimeSampleRecord</a>&gt; <a class="xfld" name="timeToSamplesRecords"/><a href="/source/s?refs=timeToSamplesRecords&amp;project=rtmp_client" class="xfld">timeToSamplesRecords</a>;
<a class="l" name="115" href="#115">115</a>
<a class="l" name="116" href="#116">116</a>	<b>protected</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=CompositionTimeSampleRecord&amp;project=rtmp_client">CompositionTimeSampleRecord</a>&gt; <a class="xfld" name="comptimeToSamplesRecords"/><a href="/source/s?refs=comptimeToSamplesRecords&amp;project=rtmp_client" class="xfld">comptimeToSamplesRecords</a>;
<a class="l" name="117" href="#117">117</a>
<a class="l" name="118" href="#118">118</a>	<b>protected</b> <b>int</b> <a class="xfld" name="balance"/><a href="/source/s?refs=balance&amp;project=rtmp_client" class="xfld">balance</a>;
<a class="l" name="119" href="#119">119</a>
<a class="hl" name="120" href="#120">120</a>	<b>protected</b> <b>long</b> <a class="xfld" name="trackId"/><a href="/source/s?refs=trackId&amp;project=rtmp_client" class="xfld">trackId</a>;
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>	<b>protected</b> <b>int</b> <a class="xfld" name="qt_trackWidth"/><a href="/source/s?refs=qt_trackWidth&amp;project=rtmp_client" class="xfld">qt_trackWidth</a>;
<a class="l" name="123" href="#123">123</a>
<a class="l" name="124" href="#124">124</a>	<b>protected</b> <b>int</b> <a class="xfld" name="qt_trackHeight"/><a href="/source/s?refs=qt_trackHeight&amp;project=rtmp_client" class="xfld">qt_trackHeight</a>;
<a class="l" name="125" href="#125">125</a>
<a class="l" name="126" href="#126">126</a>	<b>protected</b> <b>int</b> <a class="xfld" name="graphicsMode"/><a href="/source/s?refs=graphicsMode&amp;project=rtmp_client" class="xfld">graphicsMode</a>;
<a class="l" name="127" href="#127">127</a>
<a class="l" name="128" href="#128">128</a>	<b>protected</b> <b>int</b> <a class="xfld" name="opColorRed"/><a href="/source/s?refs=opColorRed&amp;project=rtmp_client" class="xfld">opColorRed</a>;
<a class="l" name="129" href="#129">129</a>
<a class="hl" name="130" href="#130">130</a>	<b>protected</b> <b>int</b> <a class="xfld" name="opColorGreen"/><a href="/source/s?refs=opColorGreen&amp;project=rtmp_client" class="xfld">opColorGreen</a>;
<a class="l" name="131" href="#131">131</a>
<a class="l" name="132" href="#132">132</a>	<b>protected</b> <b>int</b> <a class="xfld" name="opColorBlue"/><a href="/source/s?refs=opColorBlue&amp;project=rtmp_client" class="xfld">opColorBlue</a>;
<a class="l" name="133" href="#133">133</a>
<a class="l" name="134" href="#134">134</a>	<b>protected</b> <b>int</b> <a class="xfld" name="width"/><a href="/source/s?refs=width&amp;project=rtmp_client" class="xfld">width</a>;
<a class="l" name="135" href="#135">135</a>
<a class="l" name="136" href="#136">136</a>	<b>protected</b> <b>int</b> <a class="xfld" name="height"/><a href="/source/s?refs=height&amp;project=rtmp_client" class="xfld">height</a>;
<a class="l" name="137" href="#137">137</a>
<a class="l" name="138" href="#138">138</a>	<b>protected</b> <b>int</b> <a class="xfld" name="avcLevel"/><a href="/source/s?refs=avcLevel&amp;project=rtmp_client" class="xfld">avcLevel</a>;
<a class="l" name="139" href="#139">139</a>
<a class="hl" name="140" href="#140">140</a>	<b>protected</b> <b>int</b> <a class="xfld" name="avcProfile"/><a href="/source/s?refs=avcProfile&amp;project=rtmp_client" class="xfld">avcProfile</a>;
<a class="l" name="141" href="#141">141</a>
<a class="l" name="142" href="#142">142</a>	<b>private</b> <b>byte</b>[] <a class="xfld" name="videoConfigBytes"/><a href="/source/s?refs=videoConfigBytes&amp;project=rtmp_client" class="xfld">videoConfigBytes</a>;
<a class="l" name="143" href="#143">143</a>
<a class="l" name="144" href="#144">144</a>	<b>protected</b> <a href="/source/s?defs=MP4Descriptor&amp;project=rtmp_client">MP4Descriptor</a> <a class="xfld" name="esd_descriptor"/><a href="/source/s?refs=esd_descriptor&amp;project=rtmp_client" class="xfld">esd_descriptor</a>;
<a class="l" name="145" href="#145">145</a>
<a class="l" name="146" href="#146">146</a>	<b>public</b> <a class="xmt" name="MP4Atom"/><a href="/source/s?refs=MP4Atom&amp;project=rtmp_client" class="xmt">MP4Atom</a>(<b>long</b> <a class="xa" name="size"/><a href="/source/s?refs=size&amp;project=rtmp_client" class="xa">size</a>, <b>int</b> <a class="xa" name="type"/><a href="/source/s?refs=type&amp;project=rtmp_client" class="xa">type</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="uuid"/><a href="/source/s?refs=uuid&amp;project=rtmp_client" class="xa">uuid</a>, <b>long</b> <a class="xa" name="readed"/><a href="/source/s?refs=readed&amp;project=rtmp_client" class="xa">readed</a>) {
<a class="l" name="147" href="#147">147</a>		<b>super</b>();
<a class="l" name="148" href="#148">148</a>		<b>this</b>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a> = <a href="/source/s?defs=size&amp;project=rtmp_client">size</a>;
<a class="l" name="149" href="#149">149</a>		<b>this</b>.<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <a href="/source/s?defs=type&amp;project=rtmp_client">type</a>;
<a class="hl" name="150" href="#150">150</a>		<b>this</b>.<a href="/source/s?defs=uuid&amp;project=rtmp_client">uuid</a> = <a href="/source/s?defs=uuid&amp;project=rtmp_client">uuid</a>;
<a class="l" name="151" href="#151">151</a>		<b>this</b>.<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="152" href="#152">152</a>	}
<a class="l" name="153" href="#153">153</a>
<a class="l" name="154" href="#154">154</a>	<span class="c">/**
<a class="l" name="155" href="#155">155</a>	 * Constructs an &lt;code&gt;Atom&lt;/code&gt; object from the data in the bitstream.
<a class="l" name="156" href="#156">156</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="157" href="#157">157</a>	 * <strong>@return</strong> the constructed atom.
<a class="l" name="158" href="#158">158</a>	 */</span>
<a class="l" name="159" href="#159">159</a>	<b>public</b> <b>final</b> <b>static</b> <a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a class="xmt" name="createAtom"/><a href="/source/s?refs=createAtom&amp;project=rtmp_client" class="xmt">createAtom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="hl" name="160" href="#160">160</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=uuid&amp;project=rtmp_client">uuid</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="161" href="#161">161</a>		<b>long</b> <a href="/source/s?defs=size&amp;project=rtmp_client">size</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="162" href="#162">162</a>		<b>if</b> (<a href="/source/s?defs=size&amp;project=rtmp_client">size</a> == <span class="n">0</span>) {
<a class="l" name="163" href="#163">163</a>			<b>throw</b> <b>new</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>(<span class="s">"Invalid size"</span>);
<a class="l" name="164" href="#164">164</a>		}
<a class="l" name="165" href="#165">165</a>		<b>int</b> <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="166" href="#166">166</a>		<b>long</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <span class="n">8</span>;
<a class="l" name="167" href="#167">167</a>		<span class="c">// if atom is 'uuid' (extended atom type) read the uuid</span>
<a class="l" name="168" href="#168">168</a>		<b>if</b> (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> == <span class="n">1970628964</span>) {
<a class="l" name="169" href="#169">169</a>			<a href="/source/s?defs=uuid&amp;project=rtmp_client">uuid</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readString&amp;project=rtmp_client">readString</a>(<span class="n">16</span>);
<a class="hl" name="170" href="#170">170</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">16</span>;
<a class="l" name="171" href="#171">171</a>		}
<a class="l" name="172" href="#172">172</a>		<span class="c">// large size</span>
<a class="l" name="173" href="#173">173</a>		<b>if</b> (<a href="/source/s?defs=size&amp;project=rtmp_client">size</a> == <span class="n">1</span>) {
<a class="l" name="174" href="#174">174</a>			<a href="/source/s?defs=size&amp;project=rtmp_client">size</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">8</span>);
<a class="l" name="175" href="#175">175</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">8</span>;
<a class="l" name="176" href="#176">176</a>		}
<a class="l" name="177" href="#177">177</a>		<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a> = <b>new</b> <a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>(<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>, <a href="/source/s?defs=type&amp;project=rtmp_client">type</a>, <a href="/source/s?defs=uuid&amp;project=rtmp_client">uuid</a>, <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>);
<a class="l" name="178" href="#178">178</a>		<b>switch</b> (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>) {
<a class="l" name="179" href="#179">179</a>			<b>case</b> <span class="n">1835297121</span>: <span class="c">// MP4MediaAtomType mdia</span>
<a class="hl" name="180" href="#180">180</a>			<b>case</b> <span class="n">1684631142</span>: <span class="c">// MP4DataInformationAtomType dinf</span>
<a class="l" name="181" href="#181">181</a>			<b>case</b> <span class="n">1836019574</span>: <span class="c">// MP4MovieAtomType moov</span>
<a class="l" name="182" href="#182">182</a>			<b>case</b> <span class="n">1835626086</span>: <span class="c">// MP4MediaInformationAtomType minf</span>
<a class="l" name="183" href="#183">183</a>			<b>case</b> <span class="n">1937007212</span>: <span class="c">// MP4SampleTableAtomType stbl</span>
<a class="l" name="184" href="#184">184</a>			<b>case</b> <span class="n">1953653099</span>: <span class="c">// MP4TrackAtomType trak</span>
<a class="l" name="185" href="#185">185</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_composite_atom">create_composite_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="186" href="#186">186</a>				<b>break</b>;
<a class="l" name="187" href="#187">187</a>			<b>case</b> <span class="n">1836069985</span>: <span class="c">// MP4AudioSampleEntryAtomType mp4a</span>
<a class="l" name="188" href="#188">188</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_audio_sample_entry_atom">create_audio_sample_entry_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="189" href="#189">189</a>				<b>break</b>;
<a class="hl" name="190" href="#190">190</a>			<b>case</b> <span class="n">1668232756</span>: <span class="c">// MP4ChunkLargeOffsetAtomType co64</span>
<a class="l" name="191" href="#191">191</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_chunk_large_offset_atom">create_chunk_large_offset_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="192" href="#192">192</a>				<b>break</b>;
<a class="l" name="193" href="#193">193</a>			<b>case</b> <span class="n">1937007471</span>: <span class="c">// MP4ChunkOffsetAtomType stco</span>
<a class="l" name="194" href="#194">194</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_chunk_offset_atom">create_chunk_offset_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="195" href="#195">195</a>				<b>break</b>;
<a class="l" name="196" href="#196">196</a>			<b>case</b> <span class="n">1751411826</span>: <span class="c">// MP4HandlerAtomType hdlr</span>
<a class="l" name="197" href="#197">197</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_handler_atom">create_handler_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="198" href="#198">198</a>				<b>break</b>;
<a class="l" name="199" href="#199">199</a>			<b>case</b> <span class="n">1835296868</span>: <span class="c">// MP4MediaHeaderAtomType hdhd</span>
<a class="hl" name="200" href="#200">200</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_media_header_atom">create_media_header_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="201" href="#201">201</a>				<b>break</b>;
<a class="l" name="202" href="#202">202</a>			<b>case</b> <span class="n">1836476516</span>: <span class="c">// MP4MovieHeaderAtomType mvhd</span>
<a class="l" name="203" href="#203">203</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_movie_header_atom">create_movie_header_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="204" href="#204">204</a>				<b>break</b>;
<a class="l" name="205" href="#205">205</a>			<b>case</b> <span class="n">1937011556</span>: <span class="c">// MP4SampleDescriptionAtomType stsd</span>
<a class="l" name="206" href="#206">206</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_sample_description_atom">create_sample_description_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="207" href="#207">207</a>				<b>break</b>;
<a class="l" name="208" href="#208">208</a>			<b>case</b> <span class="n">1937011578</span>: <span class="c">// MP4SampleSizeAtomType stsz</span>
<a class="l" name="209" href="#209">209</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_sample_size_atom">create_sample_size_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="hl" name="210" href="#210">210</a>				<b>break</b>;
<a class="l" name="211" href="#211">211</a>			<b>case</b> <span class="n">1937013298</span>: <span class="c">// MP4CompactSampleSizeAtomType stz2</span>
<a class="l" name="212" href="#212">212</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_compact_sample_size_atom">create_compact_sample_size_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="213" href="#213">213</a>				<b>break</b>;
<a class="l" name="214" href="#214">214</a>			<b>case</b> <span class="n">1937011555</span>: <span class="c">// MP4SampleToChunkAtomType stsc</span>
<a class="l" name="215" href="#215">215</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_sample_to_chunk_atom">create_sample_to_chunk_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="216" href="#216">216</a>				<b>break</b>;
<a class="l" name="217" href="#217">217</a>			<b>case</b> <span class="n">1937011571</span>: <span class="c">// MP4SyncSampleAtomType stss</span>
<a class="l" name="218" href="#218">218</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_sync_sample_atom">create_sync_sample_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="219" href="#219">219</a>				<b>break</b>;
<a class="hl" name="220" href="#220">220</a>			<b>case</b> <span class="n">1937011827</span>: <span class="c">// MP4TimeToSampleAtomType stts</span>
<a class="l" name="221" href="#221">221</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_time_to_sample_atom">create_time_to_sample_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="222" href="#222">222</a>				<b>break</b>;
<a class="l" name="223" href="#223">223</a>			<b>case</b> <span class="n">1936549988</span>: <span class="c">// MP4SoundMediaHeaderAtomType smhd</span>
<a class="l" name="224" href="#224">224</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_sound_media_header_atom">create_sound_media_header_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="225" href="#225">225</a>				<b>break</b>;
<a class="l" name="226" href="#226">226</a>			<b>case</b> <span class="n">1953196132</span>: <span class="c">// MP4TrackHeaderAtomType tkhd</span>
<a class="l" name="227" href="#227">227</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_track_header_atom">create_track_header_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="228" href="#228">228</a>				<b>break</b>;
<a class="l" name="229" href="#229">229</a>			<b>case</b> <span class="n">1986881636</span>: <span class="c">// MP4VideoMediaHeaderAtomType vmhd</span>
<a class="hl" name="230" href="#230">230</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_video_media_header_atom">create_video_media_header_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="231" href="#231">231</a>				<b>break</b>;
<a class="l" name="232" href="#232">232</a>			<b>case</b> <span class="n">1836070006</span>: <span class="c">// MP4VisualSampleEntryAtomType mp4v</span>
<a class="l" name="233" href="#233">233</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_visual_sample_entry_atom">create_visual_sample_entry_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="234" href="#234">234</a>				<b>break</b>;
<a class="l" name="235" href="#235">235</a>			<b>case</b> <span class="n">1635148593</span>: <span class="c">// MP4VideoSampleEntryAtomType avc1</span>
<a class="l" name="236" href="#236">236</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_video_sample_entry_atom">create_video_sample_entry_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="237" href="#237">237</a>				<b>break</b>;
<a class="l" name="238" href="#238">238</a>			<b>case</b> <span class="n">1702061171</span>: <span class="c">// MP4ESDAtomType esds</span>
<a class="l" name="239" href="#239">239</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_esd_atom">create_esd_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="hl" name="240" href="#240">240</a>				<b>break</b>;
<a class="l" name="241" href="#241">241</a>			<b>case</b> <span class="n">1635148611</span>: <span class="c">// MP4AVCAtomType avcC</span>
<a class="l" name="242" href="#242">242</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_avc_config_atom">create_avc_config_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="243" href="#243">243</a>				<b>break</b>;
<a class="l" name="244" href="#244">244</a>			<b>case</b> <span class="n">1885434736</span>: <span class="c">// MP4PixelAspectAtomType pasp</span>
<a class="l" name="245" href="#245">245</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_pasp_atom">create_pasp_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="246" href="#246">246</a>				<b>break</b>;
<a class="l" name="247" href="#247">247</a>			<b>case</b> <span class="n">1668576371</span>: <span class="c">// MP4CompositionTimeToSampleAtomType ctts</span>
<a class="l" name="248" href="#248">248</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#create_composition_time_to_sample_atom">create_composition_time_to_sample_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="249" href="#249">249</a>				<b>break</b>;
<a class="hl" name="250" href="#250">250</a>		}
<a class="l" name="251" href="#251">251</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Atom: type = {} size = {}"</span>, <a class="d" href="#intToType">intToType</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>), <a href="/source/s?defs=size&amp;project=rtmp_client">size</a>);
<a class="l" name="252" href="#252">252</a>		<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<a href="/source/s?defs=size&amp;project=rtmp_client">size</a> - <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>);
<a class="l" name="253" href="#253">253</a>		<b>return</b> <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>;
<a class="l" name="254" href="#254">254</a>	}
<a class="l" name="255" href="#255">255</a>
<a class="l" name="256" href="#256">256</a>	<span class="c">/**
<a class="l" name="257" href="#257">257</a>	 * Loads the version of the full atom from the input bitstream.
<a class="l" name="258" href="#258">258</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="259" href="#259">259</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="hl" name="260" href="#260">260</a>	 */</span>
<a class="l" name="261" href="#261">261</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_full_atom"/><a href="/source/s?refs=create_full_atom&amp;project=rtmp_client" class="xmt">create_full_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="262" href="#262">262</a>		<b>long</b> <a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="263" href="#263">263</a>		<a class="d" href="#version">version</a> = (<b>int</b>) <a href="/source/s?defs=value&amp;project=rtmp_client">value</a> &gt;&gt; <span class="n">24</span>;
<a class="l" name="264" href="#264">264</a>		<a class="d" href="#flags">flags</a> = (<b>int</b>) <a href="/source/s?defs=value&amp;project=rtmp_client">value</a> &amp; <span class="n">0xffffff</span>;
<a class="l" name="265" href="#265">265</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">4</span>;
<a class="l" name="266" href="#266">266</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="267" href="#267">267</a>	}
<a class="l" name="268" href="#268">268</a>
<a class="l" name="269" href="#269">269</a>	<span class="c">/**
<a class="hl" name="270" href="#270">270</a>	 * Loads the composite atom from the input bitstream.
<a class="l" name="271" href="#271">271</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="272" href="#272">272</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="273" href="#273">273</a>	 */</span>
<a class="l" name="274" href="#274">274</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_composite_atom"/><a href="/source/s?refs=create_composite_atom&amp;project=rtmp_client" class="xmt">create_composite_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="275" href="#275">275</a>		<b>while</b> (<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> &lt; <a href="/source/s?defs=size&amp;project=rtmp_client">size</a>) {
<a class="l" name="276" href="#276">276</a>			<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=child&amp;project=rtmp_client">child</a> = <a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a class="d" href="#createAtom">createAtom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="277" href="#277">277</a>			<b>this</b>.<a class="d" href="#children">children</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=child&amp;project=rtmp_client">child</a>);
<a class="l" name="278" href="#278">278</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <a href="/source/s?defs=child&amp;project=rtmp_client">child</a>.<a class="d" href="#getSize">getSize</a>();
<a class="l" name="279" href="#279">279</a>		}
<a class="hl" name="280" href="#280">280</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="281" href="#281">281</a>	}
<a class="l" name="282" href="#282">282</a>
<a class="l" name="283" href="#283">283</a>	<span class="c">/**
<a class="l" name="284" href="#284">284</a>	 * Lookups for a child atom with the specified &lt;code&gt;type&lt;/code&gt;, skips the &lt;code&gt;number&lt;/code&gt;
<a class="l" name="285" href="#285">285</a>	 * children with the same type before finding a result.
<a class="l" name="286" href="#286">286</a>	 * <strong>@param</strong> <em>type</em> the type of the atom.
<a class="l" name="287" href="#287">287</a>	 * <strong>@param</strong> <em>number</em> the number of atoms to skip
<a class="l" name="288" href="#288">288</a>	 * <strong>@return</strong> the atom which was being searched.
<a class="l" name="289" href="#289">289</a>	 */</span>
<a class="hl" name="290" href="#290">290</a>	<b>public</b> <a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a class="xmt" name="lookup"/><a href="/source/s?refs=lookup&amp;project=rtmp_client" class="xmt">lookup</a>(<b>long</b> <a class="xa" name="type"/><a href="/source/s?refs=type&amp;project=rtmp_client" class="xa">type</a>, <b>int</b> <a class="xa" name="number"/><a href="/source/s?refs=number&amp;project=rtmp_client" class="xa">number</a>) {
<a class="l" name="291" href="#291">291</a>		<b>int</b> <a href="/source/s?defs=position&amp;project=rtmp_client">position</a> = <span class="n">0</span>;
<a class="l" name="292" href="#292">292</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#children">children</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>(); i++) {
<a class="l" name="293" href="#293">293</a>			<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a> = <a class="d" href="#children">children</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(i);
<a class="l" name="294" href="#294">294</a>			<b>if</b> (<a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a class="d" href="#getType">getType</a>() == <a href="/source/s?defs=type&amp;project=rtmp_client">type</a>) {
<a class="l" name="295" href="#295">295</a>				<b>if</b> (<a href="/source/s?defs=position&amp;project=rtmp_client">position</a> &gt;= <a class="d" href="#number">number</a>) {
<a class="l" name="296" href="#296">296</a>					<b>return</b> <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>;
<a class="l" name="297" href="#297">297</a>				}
<a class="l" name="298" href="#298">298</a>				<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>++;
<a class="l" name="299" href="#299">299</a>			}
<a class="hl" name="300" href="#300">300</a>		}
<a class="l" name="301" href="#301">301</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="302" href="#302">302</a>	}
<a class="l" name="303" href="#303">303</a>
<a class="l" name="304" href="#304">304</a>	<b>public</b> <b>int</b> <a class="xmt" name="getChannelCount"/><a href="/source/s?refs=getChannelCount&amp;project=rtmp_client" class="xmt">getChannelCount</a>() {
<a class="l" name="305" href="#305">305</a>		<b>return</b> <a class="d" href="#channelCount">channelCount</a>;
<a class="l" name="306" href="#306">306</a>	}
<a class="l" name="307" href="#307">307</a>
<a class="l" name="308" href="#308">308</a>	<span class="c">/**
<a class="l" name="309" href="#309">309</a>	 * Loads AudioSampleEntry atom from the input bitstream.
<a class="hl" name="310" href="#310">310</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="311" href="#311">311</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="312" href="#312">312</a>	 */</span>
<a class="l" name="313" href="#313">313</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unused"</span>)
<a class="l" name="314" href="#314">314</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_audio_sample_entry_atom"/><a href="/source/s?refs=create_audio_sample_entry_atom&amp;project=rtmp_client" class="xmt">create_audio_sample_entry_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="315" href="#315">315</a>		<span class="c">//qtff page 117</span>
<a class="l" name="316" href="#316">316</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Audio sample entry"</span>);
<a class="l" name="317" href="#317">317</a>		<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">6</span>);
<a class="l" name="318" href="#318">318</a>		<b>int</b> <a href="/source/s?defs=dataReferenceIndex&amp;project=rtmp_client">dataReferenceIndex</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="319" href="#319">319</a>		<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">8</span>);
<a class="hl" name="320" href="#320">320</a>		<a class="d" href="#channelCount">channelCount</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="321" href="#321">321</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Channels: {}"</span>, <a class="d" href="#channelCount">channelCount</a>);
<a class="l" name="322" href="#322">322</a>		<a class="d" href="#sampleSize">sampleSize</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="323" href="#323">323</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Sample size (bits): {}"</span>, <a class="d" href="#sampleSize">sampleSize</a>);
<a class="l" name="324" href="#324">324</a>		<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">4</span>);
<a class="l" name="325" href="#325">325</a>		<a class="d" href="#timeScale">timeScale</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="326" href="#326">326</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Time scale: {}"</span>, <a class="d" href="#timeScale">timeScale</a>);
<a class="l" name="327" href="#327">327</a>		<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">2</span>);
<a class="l" name="328" href="#328">328</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">28</span>;
<a class="l" name="329" href="#329">329</a>		<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=child&amp;project=rtmp_client">child</a> = <a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a class="d" href="#createAtom">createAtom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="hl" name="330" href="#330">330</a>		<b>this</b>.<a class="d" href="#children">children</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=child&amp;project=rtmp_client">child</a>);
<a class="l" name="331" href="#331">331</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <a href="/source/s?defs=child&amp;project=rtmp_client">child</a>.<a class="d" href="#getSize">getSize</a>();
<a class="l" name="332" href="#332">332</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="333" href="#333">333</a>	}
<a class="l" name="334" href="#334">334</a>
<a class="l" name="335" href="#335">335</a>	<span class="c">/**
<a class="l" name="336" href="#336">336</a>	 * Loads ChunkLargeOffset atom from the input bitstream.
<a class="l" name="337" href="#337">337</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="338" href="#338">338</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="339" href="#339">339</a>	 */</span>
<a class="hl" name="340" href="#340">340</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_chunk_large_offset_atom"/><a href="/source/s?refs=create_chunk_large_offset_atom&amp;project=rtmp_client" class="xmt">create_chunk_large_offset_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="341" href="#341">341</a>		<a class="d" href="#create_full_atom">create_full_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="342" href="#342">342</a>		<a class="d" href="#chunks">chunks</a> = <b>new</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt;();
<a class="l" name="343" href="#343">343</a>		<a class="d" href="#entryCount">entryCount</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="344" href="#344">344</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">4</span>;
<a class="l" name="345" href="#345">345</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#entryCount">entryCount</a>; i++) {
<a class="l" name="346" href="#346">346</a>			<b>long</b> <a href="/source/s?defs=chunkOffset&amp;project=rtmp_client">chunkOffset</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">8</span>);
<a class="l" name="347" href="#347">347</a>			<a class="d" href="#chunks">chunks</a>.<a href="/source/s?defs=addElement&amp;project=rtmp_client">addElement</a>(<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=chunkOffset&amp;project=rtmp_client">chunkOffset</a>));
<a class="l" name="348" href="#348">348</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">8</span>;
<a class="l" name="349" href="#349">349</a>		}
<a class="hl" name="350" href="#350">350</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="351" href="#351">351</a>	}
<a class="l" name="352" href="#352">352</a>
<a class="l" name="353" href="#353">353</a>	<b>public</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt; <a class="xmt" name="getChunks"/><a href="/source/s?refs=getChunks&amp;project=rtmp_client" class="xmt">getChunks</a>() {
<a class="l" name="354" href="#354">354</a>		<b>return</b> <a class="d" href="#chunks">chunks</a>;
<a class="l" name="355" href="#355">355</a>	}
<a class="l" name="356" href="#356">356</a>
<a class="l" name="357" href="#357">357</a>	<span class="c">/**
<a class="l" name="358" href="#358">358</a>	 * Loads ChunkOffset atom from the input bitstream.
<a class="l" name="359" href="#359">359</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="hl" name="360" href="#360">360</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="361" href="#361">361</a>	 */</span>
<a class="l" name="362" href="#362">362</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_chunk_offset_atom"/><a href="/source/s?refs=create_chunk_offset_atom&amp;project=rtmp_client" class="xmt">create_chunk_offset_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="363" href="#363">363</a>		<a class="d" href="#create_full_atom">create_full_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="364" href="#364">364</a>		<a class="d" href="#chunks">chunks</a> = <b>new</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt;();
<a class="l" name="365" href="#365">365</a>		<a class="d" href="#entryCount">entryCount</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="366" href="#366">366</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">4</span>;
<a class="l" name="367" href="#367">367</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#entryCount">entryCount</a>; i++) {
<a class="l" name="368" href="#368">368</a>			<b>long</b> <a href="/source/s?defs=chunkOffset&amp;project=rtmp_client">chunkOffset</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="369" href="#369">369</a>			<a class="d" href="#chunks">chunks</a>.<a href="/source/s?defs=addElement&amp;project=rtmp_client">addElement</a>(<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=chunkOffset&amp;project=rtmp_client">chunkOffset</a>));
<a class="hl" name="370" href="#370">370</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">4</span>;
<a class="l" name="371" href="#371">371</a>		}
<a class="l" name="372" href="#372">372</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="373" href="#373">373</a>	}
<a class="l" name="374" href="#374">374</a>
<a class="l" name="375" href="#375">375</a>	<span class="c">/**
<a class="l" name="376" href="#376">376</a>	 * Loads Handler atom from the input bitstream.
<a class="l" name="377" href="#377">377</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="378" href="#378">378</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="379" href="#379">379</a>	 */</span>
<a class="hl" name="380" href="#380">380</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unused"</span>)
<a class="l" name="381" href="#381">381</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_handler_atom"/><a href="/source/s?refs=create_handler_atom&amp;project=rtmp_client" class="xmt">create_handler_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="382" href="#382">382</a>		<a class="d" href="#create_full_atom">create_full_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="383" href="#383">383</a>		<b>int</b> <a href="/source/s?defs=qt_componentType&amp;project=rtmp_client">qt_componentType</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="384" href="#384">384</a>		<a class="d" href="#handlerType">handlerType</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="385" href="#385">385</a>		<b>int</b> <a href="/source/s?defs=qt_componentManufacturer&amp;project=rtmp_client">qt_componentManufacturer</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="386" href="#386">386</a>		<b>int</b> <a href="/source/s?defs=qt_componentFlags&amp;project=rtmp_client">qt_componentFlags</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="387" href="#387">387</a>		<b>int</b> <a href="/source/s?defs=qt_componentFlagsMask&amp;project=rtmp_client">qt_componentFlagsMask</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="388" href="#388">388</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">20</span>;
<a class="l" name="389" href="#389">389</a>		<b>int</b> <a href="/source/s?defs=length&amp;project=rtmp_client">length</a> = (<b>int</b>) (<a href="/source/s?defs=size&amp;project=rtmp_client">size</a> - <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> - <span class="n">1</span>);
<a class="hl" name="390" href="#390">390</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=trackName&amp;project=rtmp_client">trackName</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readString&amp;project=rtmp_client">readString</a>(<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>);
<a class="l" name="391" href="#391">391</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Track name: {}"</span>, <a href="/source/s?defs=trackName&amp;project=rtmp_client">trackName</a>);
<a class="l" name="392" href="#392">392</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <a href="/source/s?defs=length&amp;project=rtmp_client">length</a>;
<a class="l" name="393" href="#393">393</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="394" href="#394">394</a>	}
<a class="l" name="395" href="#395">395</a>
<a class="l" name="396" href="#396">396</a>	<span class="c">/**
<a class="l" name="397" href="#397">397</a>	 * Gets the handler type.
<a class="l" name="398" href="#398">398</a>	 * <strong>@return</strong> the handler type.
<a class="l" name="399" href="#399">399</a>	 */</span>
<a class="hl" name="400" href="#400">400</a>	<b>public</b> <b>int</b> <a class="xmt" name="getHandlerType"/><a href="/source/s?refs=getHandlerType&amp;project=rtmp_client" class="xmt">getHandlerType</a>() {
<a class="l" name="401" href="#401">401</a>		<b>return</b> <a class="d" href="#handlerType">handlerType</a>;
<a class="l" name="402" href="#402">402</a>	}
<a class="l" name="403" href="#403">403</a>
<a class="l" name="404" href="#404">404</a>	<span class="c">/**
<a class="l" name="405" href="#405">405</a>	 * Loads MediaHeader atom from the input bitstream.
<a class="l" name="406" href="#406">406</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="407" href="#407">407</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="408" href="#408">408</a>	 */</span>
<a class="l" name="409" href="#409">409</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unused"</span>)
<a class="hl" name="410" href="#410">410</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_media_header_atom"/><a href="/source/s?refs=create_media_header_atom&amp;project=rtmp_client" class="xmt">create_media_header_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="411" href="#411">411</a>		<a class="d" href="#create_full_atom">create_full_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="412" href="#412">412</a>		<b>if</b> (<a class="d" href="#version">version</a> == <span class="n">1</span>) {
<a class="l" name="413" href="#413">413</a>			<a class="d" href="#creationTime">creationTime</a> = <a class="d" href="#createDate">createDate</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">8</span>));
<a class="l" name="414" href="#414">414</a>			<a class="d" href="#modificationTime">modificationTime</a> = <a class="d" href="#createDate">createDate</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">8</span>));
<a class="l" name="415" href="#415">415</a>			<a class="d" href="#timeScale">timeScale</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="416" href="#416">416</a>			<a class="d" href="#duration">duration</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">8</span>);
<a class="l" name="417" href="#417">417</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">28</span>;
<a class="l" name="418" href="#418">418</a>		} <b>else</b> {
<a class="l" name="419" href="#419">419</a>			<a class="d" href="#creationTime">creationTime</a> = <a class="d" href="#createDate">createDate</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>));
<a class="hl" name="420" href="#420">420</a>			<a class="d" href="#modificationTime">modificationTime</a> = <a class="d" href="#createDate">createDate</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>));
<a class="l" name="421" href="#421">421</a>			<a class="d" href="#timeScale">timeScale</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="422" href="#422">422</a>			<a class="d" href="#duration">duration</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="423" href="#423">423</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">16</span>;
<a class="l" name="424" href="#424">424</a>		}
<a class="l" name="425" href="#425">425</a>		<b>int</b> <a href="/source/s?defs=packedLanguage&amp;project=rtmp_client">packedLanguage</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="426" href="#426">426</a>		<b>int</b> <a href="/source/s?defs=qt_quality&amp;project=rtmp_client">qt_quality</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="427" href="#427">427</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">4</span>;
<a class="l" name="428" href="#428">428</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="429" href="#429">429</a>	}
<a class="hl" name="430" href="#430">430</a>
<a class="l" name="431" href="#431">431</a>	<b>public</b> <b>long</b> <a class="xmt" name="getDuration"/><a href="/source/s?refs=getDuration&amp;project=rtmp_client" class="xmt">getDuration</a>() {
<a class="l" name="432" href="#432">432</a>		<b>return</b> <a class="d" href="#duration">duration</a>;
<a class="l" name="433" href="#433">433</a>	}
<a class="l" name="434" href="#434">434</a>
<a class="l" name="435" href="#435">435</a>	<b>public</b> <b>int</b> <a class="xmt" name="getTimeScale"/><a href="/source/s?refs=getTimeScale&amp;project=rtmp_client" class="xmt">getTimeScale</a>() {
<a class="l" name="436" href="#436">436</a>		<b>return</b> <a class="d" href="#timeScale">timeScale</a>;
<a class="l" name="437" href="#437">437</a>	}
<a class="l" name="438" href="#438">438</a>
<a class="l" name="439" href="#439">439</a>	<span class="c">/**
<a class="hl" name="440" href="#440">440</a>	 * Loads MovieHeader atom from the input bitstream.
<a class="l" name="441" href="#441">441</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="442" href="#442">442</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="443" href="#443">443</a>	 */</span>
<a class="l" name="444" href="#444">444</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unused"</span>)
<a class="l" name="445" href="#445">445</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_movie_header_atom"/><a href="/source/s?refs=create_movie_header_atom&amp;project=rtmp_client" class="xmt">create_movie_header_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="446" href="#446">446</a>		<a class="d" href="#create_full_atom">create_full_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="447" href="#447">447</a>		<b>if</b> (<a class="d" href="#version">version</a> == <span class="n">1</span>) {
<a class="l" name="448" href="#448">448</a>			<a class="d" href="#creationTime">creationTime</a> = <a class="d" href="#createDate">createDate</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">8</span>));
<a class="l" name="449" href="#449">449</a>			<a class="d" href="#modificationTime">modificationTime</a> = <a class="d" href="#createDate">createDate</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">8</span>));
<a class="hl" name="450" href="#450">450</a>			<a class="d" href="#timeScale">timeScale</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="451" href="#451">451</a>			<a class="d" href="#duration">duration</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">8</span>);
<a class="l" name="452" href="#452">452</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">28</span>;
<a class="l" name="453" href="#453">453</a>		} <b>else</b> {
<a class="l" name="454" href="#454">454</a>			<a class="d" href="#creationTime">creationTime</a> = <a class="d" href="#createDate">createDate</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>));
<a class="l" name="455" href="#455">455</a>			<a class="d" href="#modificationTime">modificationTime</a> = <a class="d" href="#createDate">createDate</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>));
<a class="l" name="456" href="#456">456</a>			<a class="d" href="#timeScale">timeScale</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="457" href="#457">457</a>			<a class="d" href="#duration">duration</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="458" href="#458">458</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">16</span>;
<a class="l" name="459" href="#459">459</a>		}
<a class="hl" name="460" href="#460">460</a>		<b>int</b> <a href="/source/s?defs=qt_preferredRate&amp;project=rtmp_client">qt_preferredRate</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="461" href="#461">461</a>		<b>int</b> <a href="/source/s?defs=qt_preferredVolume&amp;project=rtmp_client">qt_preferredVolume</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="462" href="#462">462</a>		<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">10</span>);
<a class="l" name="463" href="#463">463</a>		<b>long</b> <a href="/source/s?defs=qt_matrixA&amp;project=rtmp_client">qt_matrixA</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="464" href="#464">464</a>		<b>long</b> <a href="/source/s?defs=qt_matrixB&amp;project=rtmp_client">qt_matrixB</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="465" href="#465">465</a>		<b>long</b> <a href="/source/s?defs=qt_matrixU&amp;project=rtmp_client">qt_matrixU</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="466" href="#466">466</a>		<b>long</b> <a href="/source/s?defs=qt_matrixC&amp;project=rtmp_client">qt_matrixC</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="467" href="#467">467</a>		<b>long</b> <a href="/source/s?defs=qt_matrixD&amp;project=rtmp_client">qt_matrixD</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="468" href="#468">468</a>		<b>long</b> <a href="/source/s?defs=qt_matrixV&amp;project=rtmp_client">qt_matrixV</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="469" href="#469">469</a>		<b>long</b> <a href="/source/s?defs=qt_matrixX&amp;project=rtmp_client">qt_matrixX</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="hl" name="470" href="#470">470</a>		<b>long</b> <a href="/source/s?defs=qt_matrixY&amp;project=rtmp_client">qt_matrixY</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="471" href="#471">471</a>		<b>long</b> <a href="/source/s?defs=qt_matrixW&amp;project=rtmp_client">qt_matrixW</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="472" href="#472">472</a>		<b>long</b> <a href="/source/s?defs=qt_previewTime&amp;project=rtmp_client">qt_previewTime</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="473" href="#473">473</a>		<b>long</b> <a href="/source/s?defs=qt_previewDuration&amp;project=rtmp_client">qt_previewDuration</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="474" href="#474">474</a>		<b>long</b> <a href="/source/s?defs=qt_posterTime&amp;project=rtmp_client">qt_posterTime</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="475" href="#475">475</a>		<b>long</b> <a href="/source/s?defs=qt_selectionTime&amp;project=rtmp_client">qt_selectionTime</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="476" href="#476">476</a>		<b>long</b> <a href="/source/s?defs=qt_selectionDuration&amp;project=rtmp_client">qt_selectionDuration</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="477" href="#477">477</a>		<b>long</b> <a href="/source/s?defs=qt_currentTime&amp;project=rtmp_client">qt_currentTime</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="478" href="#478">478</a>		<b>long</b> <a href="/source/s?defs=nextTrackID&amp;project=rtmp_client">nextTrackID</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="479" href="#479">479</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">80</span>;
<a class="hl" name="480" href="#480">480</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="481" href="#481">481</a>	}
<a class="l" name="482" href="#482">482</a>
<a class="l" name="483" href="#483">483</a>	<span class="c">/**
<a class="l" name="484" href="#484">484</a>	 * Loads SampleDescription atom from the input bitstream.
<a class="l" name="485" href="#485">485</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="486" href="#486">486</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="487" href="#487">487</a>	 */</span>
<a class="l" name="488" href="#488">488</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_sample_description_atom"/><a href="/source/s?refs=create_sample_description_atom&amp;project=rtmp_client" class="xmt">create_sample_description_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="489" href="#489">489</a>		<a class="d" href="#create_full_atom">create_full_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="hl" name="490" href="#490">490</a>		<a class="d" href="#entryCount">entryCount</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="491" href="#491">491</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"stsd entry count: {}"</span>, <a class="d" href="#entryCount">entryCount</a>);
<a class="l" name="492" href="#492">492</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">4</span>;
<a class="l" name="493" href="#493">493</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#entryCount">entryCount</a>; i++) {
<a class="l" name="494" href="#494">494</a>			<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=child&amp;project=rtmp_client">child</a> = <a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a class="d" href="#createAtom">createAtom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="495" href="#495">495</a>			<b>this</b>.<a class="d" href="#children">children</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=child&amp;project=rtmp_client">child</a>);
<a class="l" name="496" href="#496">496</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <a href="/source/s?defs=child&amp;project=rtmp_client">child</a>.<a class="d" href="#getSize">getSize</a>();
<a class="l" name="497" href="#497">497</a>		}
<a class="l" name="498" href="#498">498</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="499" href="#499">499</a>	}
<a class="hl" name="500" href="#500">500</a>
<a class="l" name="501" href="#501">501</a>	<span class="c">/**
<a class="l" name="502" href="#502">502</a>	 * Loads MP4SampleSizeAtom atom from the input bitstream.
<a class="l" name="503" href="#503">503</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="504" href="#504">504</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="505" href="#505">505</a>	 */</span>
<a class="l" name="506" href="#506">506</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_sample_size_atom"/><a href="/source/s?refs=create_sample_size_atom&amp;project=rtmp_client" class="xmt">create_sample_size_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="507" href="#507">507</a>		<a class="d" href="#create_full_atom">create_full_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="508" href="#508">508</a>		<a class="d" href="#samples">samples</a> = <b>new</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt;();
<a class="l" name="509" href="#509">509</a>		<a class="d" href="#sampleSize">sampleSize</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="hl" name="510" href="#510">510</a>		<a class="d" href="#sampleCount">sampleCount</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="511" href="#511">511</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">8</span>;
<a class="l" name="512" href="#512">512</a>		<b>if</b> (<a class="d" href="#sampleSize">sampleSize</a> == <span class="n">0</span>) {
<a class="l" name="513" href="#513">513</a>			<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#sampleCount">sampleCount</a>; i++) {
<a class="l" name="514" href="#514">514</a>				<b>int</b> <a href="/source/s?defs=size&amp;project=rtmp_client">size</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="515" href="#515">515</a>				<a class="d" href="#samples">samples</a>.<a href="/source/s?defs=addElement&amp;project=rtmp_client">addElement</a>(<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>));
<a class="l" name="516" href="#516">516</a>				<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">4</span>;
<a class="l" name="517" href="#517">517</a>			}
<a class="l" name="518" href="#518">518</a>		}
<a class="l" name="519" href="#519">519</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="hl" name="520" href="#520">520</a>	}
<a class="l" name="521" href="#521">521</a>
<a class="l" name="522" href="#522">522</a>	<b>public</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt; <a class="xmt" name="getSamples"/><a href="/source/s?refs=getSamples&amp;project=rtmp_client" class="xmt">getSamples</a>() {
<a class="l" name="523" href="#523">523</a>		<b>return</b> <a class="d" href="#samples">samples</a>;
<a class="l" name="524" href="#524">524</a>	}
<a class="l" name="525" href="#525">525</a>
<a class="l" name="526" href="#526">526</a>	<b>public</b> <b>int</b> <a class="xmt" name="getSampleSize"/><a href="/source/s?refs=getSampleSize&amp;project=rtmp_client" class="xmt">getSampleSize</a>() {
<a class="l" name="527" href="#527">527</a>		<b>return</b> <a class="d" href="#sampleSize">sampleSize</a>;
<a class="l" name="528" href="#528">528</a>	}
<a class="l" name="529" href="#529">529</a>
<a class="hl" name="530" href="#530">530</a>	<span class="c">/**
<a class="l" name="531" href="#531">531</a>	 * Loads CompactSampleSize atom from the input stream.
<a class="l" name="532" href="#532">532</a>	 * <strong>@param</strong> <em>stream</em> the input stream
<a class="l" name="533" href="#533">533</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="534" href="#534">534</a>	 */</span>
<a class="l" name="535" href="#535">535</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_compact_sample_size_atom"/><a href="/source/s?refs=create_compact_sample_size_atom&amp;project=rtmp_client" class="xmt">create_compact_sample_size_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="stream"/><a href="/source/s?refs=stream&amp;project=rtmp_client" class="xa">stream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="536" href="#536">536</a>		<a class="d" href="#create_full_atom">create_full_atom</a>(<a class="d" href="#stream">stream</a>);
<a class="l" name="537" href="#537">537</a>		<a class="d" href="#stream">stream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">3</span>);
<a class="l" name="538" href="#538">538</a>		<a class="d" href="#sampleSize">sampleSize</a> = <span class="n">0</span>;
<a class="l" name="539" href="#539">539</a>		<a class="d" href="#fieldSize">fieldSize</a> = (<b>int</b>) <a class="d" href="#stream">stream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">1</span>);
<a class="hl" name="540" href="#540">540</a>		<a class="d" href="#sampleCount">sampleCount</a> = (<b>int</b>) <a class="d" href="#stream">stream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="541" href="#541">541</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">8</span>;
<a class="l" name="542" href="#542">542</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#sampleCount">sampleCount</a>; i++) {
<a class="l" name="543" href="#543">543</a>			<b>int</b> <a href="/source/s?defs=size&amp;project=rtmp_client">size</a> = <span class="n">0</span>;
<a class="l" name="544" href="#544">544</a>			<b>switch</b> (<a class="d" href="#fieldSize">fieldSize</a>) {
<a class="l" name="545" href="#545">545</a>				<b>case</b> <span class="n">4</span>:
<a class="l" name="546" href="#546">546</a>					<a href="/source/s?defs=size&amp;project=rtmp_client">size</a> = (<b>int</b>) <a class="d" href="#stream">stream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">1</span>);
<a class="l" name="547" href="#547">547</a>					<span class="c">// TODO check the following code</span>
<a class="l" name="548" href="#548">548</a>					<a class="d" href="#samples">samples</a>.<a href="/source/s?defs=addElement&amp;project=rtmp_client">addElement</a>(<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=size&amp;project=rtmp_client">size</a> &amp; <span class="n">0x0f</span>));
<a class="l" name="549" href="#549">549</a>					<a href="/source/s?defs=size&amp;project=rtmp_client">size</a> = (<a href="/source/s?defs=size&amp;project=rtmp_client">size</a> &gt;&gt; <span class="n">4</span>) &amp; <span class="n">0x0f</span>;
<a class="hl" name="550" href="#550">550</a>					i++;
<a class="l" name="551" href="#551">551</a>					<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">1</span>;
<a class="l" name="552" href="#552">552</a>					<b>break</b>;
<a class="l" name="553" href="#553">553</a>				<b>case</b> <span class="n">8</span>:
<a class="l" name="554" href="#554">554</a>					<a href="/source/s?defs=size&amp;project=rtmp_client">size</a> = (<b>int</b>) <a class="d" href="#stream">stream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">1</span>);
<a class="l" name="555" href="#555">555</a>					<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">1</span>;
<a class="l" name="556" href="#556">556</a>					<b>break</b>;
<a class="l" name="557" href="#557">557</a>				<b>case</b> <span class="n">16</span>:
<a class="l" name="558" href="#558">558</a>					<a href="/source/s?defs=size&amp;project=rtmp_client">size</a> = (<b>int</b>) <a class="d" href="#stream">stream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="559" href="#559">559</a>					<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">2</span>;
<a class="hl" name="560" href="#560">560</a>					<b>break</b>;
<a class="l" name="561" href="#561">561</a>			}
<a class="l" name="562" href="#562">562</a>			<b>if</b> (i &lt; <a class="d" href="#sampleCount">sampleCount</a>) {
<a class="l" name="563" href="#563">563</a>				<a class="d" href="#samples">samples</a>.<a href="/source/s?defs=addElement&amp;project=rtmp_client">addElement</a>(<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>));
<a class="l" name="564" href="#564">564</a>			}
<a class="l" name="565" href="#565">565</a>		}
<a class="l" name="566" href="#566">566</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="567" href="#567">567</a>	}
<a class="l" name="568" href="#568">568</a>
<a class="l" name="569" href="#569">569</a>	<b>public</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Record&amp;project=rtmp_client">Record</a>&gt; <a class="xmt" name="getRecords"/><a href="/source/s?refs=getRecords&amp;project=rtmp_client" class="xmt">getRecords</a>() {
<a class="hl" name="570" href="#570">570</a>		<b>return</b> <a class="d" href="#records">records</a>;
<a class="l" name="571" href="#571">571</a>	}
<a class="l" name="572" href="#572">572</a>
<a class="l" name="573" href="#573">573</a>	<span class="c">/**
<a class="l" name="574" href="#574">574</a>	 * Loads MP4SampleToChunkAtom atom from the input bitstream.
<a class="l" name="575" href="#575">575</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="576" href="#576">576</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="577" href="#577">577</a>	 */</span>
<a class="l" name="578" href="#578">578</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_sample_to_chunk_atom"/><a href="/source/s?refs=create_sample_to_chunk_atom&amp;project=rtmp_client" class="xmt">create_sample_to_chunk_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="579" href="#579">579</a>		<a class="d" href="#create_full_atom">create_full_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="hl" name="580" href="#580">580</a>		<a class="d" href="#records">records</a> = <b>new</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Record&amp;project=rtmp_client">Record</a>&gt;();
<a class="l" name="581" href="#581">581</a>		<a class="d" href="#entryCount">entryCount</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="582" href="#582">582</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">4</span>;
<a class="l" name="583" href="#583">583</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#entryCount">entryCount</a>; i++) {
<a class="l" name="584" href="#584">584</a>			<b>int</b> <a href="/source/s?defs=firstChunk&amp;project=rtmp_client">firstChunk</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="585" href="#585">585</a>			<b>int</b> <a href="/source/s?defs=samplesPerChunk&amp;project=rtmp_client">samplesPerChunk</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="586" href="#586">586</a>			<b>int</b> <a href="/source/s?defs=sampleDescriptionIndex&amp;project=rtmp_client">sampleDescriptionIndex</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="587" href="#587">587</a>			<a class="d" href="#records">records</a>.<a href="/source/s?defs=addElement&amp;project=rtmp_client">addElement</a>(<b>new</b> <a href="/source/s?defs=Record&amp;project=rtmp_client">Record</a>(<a href="/source/s?defs=firstChunk&amp;project=rtmp_client">firstChunk</a>, <a href="/source/s?defs=samplesPerChunk&amp;project=rtmp_client">samplesPerChunk</a>, <a href="/source/s?defs=sampleDescriptionIndex&amp;project=rtmp_client">sampleDescriptionIndex</a>));
<a class="l" name="588" href="#588">588</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">12</span>;
<a class="l" name="589" href="#589">589</a>		}
<a class="hl" name="590" href="#590">590</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="591" href="#591">591</a>	}
<a class="l" name="592" href="#592">592</a>
<a class="l" name="593" href="#593">593</a>	<b>public</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt; <a class="xmt" name="getSyncSamples"/><a href="/source/s?refs=getSyncSamples&amp;project=rtmp_client" class="xmt">getSyncSamples</a>() {
<a class="l" name="594" href="#594">594</a>		<b>return</b> <a class="d" href="#syncSamples">syncSamples</a>;
<a class="l" name="595" href="#595">595</a>	}
<a class="l" name="596" href="#596">596</a>
<a class="l" name="597" href="#597">597</a>	<span class="c">/**
<a class="l" name="598" href="#598">598</a>	 * Loads MP4SyncSampleAtom atom from the input bitstream.
<a class="l" name="599" href="#599">599</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="hl" name="600" href="#600">600</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="601" href="#601">601</a>	 */</span>
<a class="l" name="602" href="#602">602</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_sync_sample_atom"/><a href="/source/s?refs=create_sync_sample_atom&amp;project=rtmp_client" class="xmt">create_sync_sample_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="603" href="#603">603</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Sync sample atom contains keyframe info"</span>);
<a class="l" name="604" href="#604">604</a>		<a class="d" href="#create_full_atom">create_full_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="605" href="#605">605</a>		<a class="d" href="#syncSamples">syncSamples</a> = <b>new</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt;();
<a class="l" name="606" href="#606">606</a>		<a class="d" href="#entryCount">entryCount</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="607" href="#607">607</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Sync entries: {}"</span>, <a class="d" href="#entryCount">entryCount</a>);
<a class="l" name="608" href="#608">608</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">4</span>;
<a class="l" name="609" href="#609">609</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#entryCount">entryCount</a>; i++) {
<a class="hl" name="610" href="#610">610</a>			<b>int</b> <a href="/source/s?defs=sample&amp;project=rtmp_client">sample</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="611" href="#611">611</a>			<span class="c">//log.trace("Sync entry: {}", sample);</span>
<a class="l" name="612" href="#612">612</a>			<a class="d" href="#syncSamples">syncSamples</a>.<a href="/source/s?defs=addElement&amp;project=rtmp_client">addElement</a>(<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=sample&amp;project=rtmp_client">sample</a>));
<a class="l" name="613" href="#613">613</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">4</span>;
<a class="l" name="614" href="#614">614</a>		}
<a class="l" name="615" href="#615">615</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="616" href="#616">616</a>	}
<a class="l" name="617" href="#617">617</a>
<a class="l" name="618" href="#618">618</a>	<b>public</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=TimeSampleRecord&amp;project=rtmp_client">TimeSampleRecord</a>&gt; <a class="xmt" name="getTimeToSamplesRecords"/><a href="/source/s?refs=getTimeToSamplesRecords&amp;project=rtmp_client" class="xmt">getTimeToSamplesRecords</a>() {
<a class="l" name="619" href="#619">619</a>		<b>return</b> <a class="d" href="#timeToSamplesRecords">timeToSamplesRecords</a>;
<a class="hl" name="620" href="#620">620</a>	}
<a class="l" name="621" href="#621">621</a>
<a class="l" name="622" href="#622">622</a>	<span class="c">/**
<a class="l" name="623" href="#623">623</a>	 * Loads MP4TimeToSampleAtom atom from the input bitstream.
<a class="l" name="624" href="#624">624</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="625" href="#625">625</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="626" href="#626">626</a>	 */</span>
<a class="l" name="627" href="#627">627</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_time_to_sample_atom"/><a href="/source/s?refs=create_time_to_sample_atom&amp;project=rtmp_client" class="xmt">create_time_to_sample_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="628" href="#628">628</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Time to sample atom"</span>);
<a class="l" name="629" href="#629">629</a>		<a class="d" href="#create_full_atom">create_full_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="hl" name="630" href="#630">630</a>		<a class="d" href="#timeToSamplesRecords">timeToSamplesRecords</a> = <b>new</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=TimeSampleRecord&amp;project=rtmp_client">TimeSampleRecord</a>&gt;();
<a class="l" name="631" href="#631">631</a>		<a class="d" href="#entryCount">entryCount</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="632" href="#632">632</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Time to sample entries: {}"</span>, <a class="d" href="#entryCount">entryCount</a>);
<a class="l" name="633" href="#633">633</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">4</span>;
<a class="l" name="634" href="#634">634</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#entryCount">entryCount</a>; i++) {
<a class="l" name="635" href="#635">635</a>			<b>int</b> <a class="d" href="#sampleCount">sampleCount</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="636" href="#636">636</a>			<b>int</b> <a href="/source/s?defs=sampleDuration&amp;project=rtmp_client">sampleDuration</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="637" href="#637">637</a>			<span class="c">//log.trace("Sync entry: {}", sample);</span>
<a class="l" name="638" href="#638">638</a>			<a class="d" href="#timeToSamplesRecords">timeToSamplesRecords</a>.<a href="/source/s?defs=addElement&amp;project=rtmp_client">addElement</a>(<b>new</b> <a href="/source/s?defs=TimeSampleRecord&amp;project=rtmp_client">TimeSampleRecord</a>(<a class="d" href="#sampleCount">sampleCount</a>, <a href="/source/s?defs=sampleDuration&amp;project=rtmp_client">sampleDuration</a>));
<a class="l" name="639" href="#639">639</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">8</span>;
<a class="hl" name="640" href="#640">640</a>		}
<a class="l" name="641" href="#641">641</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="642" href="#642">642</a>	}
<a class="l" name="643" href="#643">643</a>
<a class="l" name="644" href="#644">644</a>	<span class="c">/**
<a class="l" name="645" href="#645">645</a>	 * Loads MP4SoundMediaHeaderAtom atom from the input bitstream.
<a class="l" name="646" href="#646">646</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="647" href="#647">647</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="648" href="#648">648</a>	 */</span>
<a class="l" name="649" href="#649">649</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_sound_media_header_atom"/><a href="/source/s?refs=create_sound_media_header_atom&amp;project=rtmp_client" class="xmt">create_sound_media_header_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="hl" name="650" href="#650">650</a>		<a class="d" href="#create_full_atom">create_full_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="651" href="#651">651</a>		<a class="d" href="#balance">balance</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="652" href="#652">652</a>		<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">2</span>);
<a class="l" name="653" href="#653">653</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">4</span>;
<a class="l" name="654" href="#654">654</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="655" href="#655">655</a>	}
<a class="l" name="656" href="#656">656</a>
<a class="l" name="657" href="#657">657</a>	<span class="c">/**
<a class="l" name="658" href="#658">658</a>	 * Loads MP4TrackHeaderAtom atom from the input bitstream.
<a class="l" name="659" href="#659">659</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="hl" name="660" href="#660">660</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="661" href="#661">661</a>	 */</span>
<a class="l" name="662" href="#662">662</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unused"</span>)
<a class="l" name="663" href="#663">663</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_track_header_atom"/><a href="/source/s?refs=create_track_header_atom&amp;project=rtmp_client" class="xmt">create_track_header_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="664" href="#664">664</a>		<a class="d" href="#create_full_atom">create_full_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="665" href="#665">665</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Version: {}"</span>, <a class="d" href="#version">version</a>);
<a class="l" name="666" href="#666">666</a>		<b>if</b> (<a class="d" href="#version">version</a> == <span class="n">1</span>) {
<a class="l" name="667" href="#667">667</a>			<a class="d" href="#creationTime">creationTime</a> = <a class="d" href="#createDate">createDate</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">8</span>));
<a class="l" name="668" href="#668">668</a>			<a class="d" href="#modificationTime">modificationTime</a> = <a class="d" href="#createDate">createDate</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">8</span>));
<a class="l" name="669" href="#669">669</a>			<a class="d" href="#trackId">trackId</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="hl" name="670" href="#670">670</a>			<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">4</span>);
<a class="l" name="671" href="#671">671</a>			<a class="d" href="#duration">duration</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">8</span>);
<a class="l" name="672" href="#672">672</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">32</span>;
<a class="l" name="673" href="#673">673</a>		} <b>else</b> {
<a class="l" name="674" href="#674">674</a>			<a class="d" href="#creationTime">creationTime</a> = <a class="d" href="#createDate">createDate</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>));
<a class="l" name="675" href="#675">675</a>			<a class="d" href="#modificationTime">modificationTime</a> = <a class="d" href="#createDate">createDate</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>));
<a class="l" name="676" href="#676">676</a>			<a class="d" href="#trackId">trackId</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="677" href="#677">677</a>			<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">4</span>);
<a class="l" name="678" href="#678">678</a>			<a class="d" href="#duration">duration</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="679" href="#679">679</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">20</span>;
<a class="hl" name="680" href="#680">680</a>		}
<a class="l" name="681" href="#681">681</a>		<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">8</span>); <span class="c">//reserved by apple</span>
<a class="l" name="682" href="#682">682</a>		<b>int</b> <a href="/source/s?defs=qt_layer&amp;project=rtmp_client">qt_layer</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="683" href="#683">683</a>		<b>int</b> <a href="/source/s?defs=qt_alternateGroup&amp;project=rtmp_client">qt_alternateGroup</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="684" href="#684">684</a>		<b>int</b> <a href="/source/s?defs=qt_volume&amp;project=rtmp_client">qt_volume</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="685" href="#685">685</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Volume: {}"</span>, <a href="/source/s?defs=qt_volume&amp;project=rtmp_client">qt_volume</a>);
<a class="l" name="686" href="#686">686</a>		<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">2</span>); <span class="c">//reserved by apple</span>
<a class="l" name="687" href="#687">687</a>		<b>long</b> <a href="/source/s?defs=qt_matrixA&amp;project=rtmp_client">qt_matrixA</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="688" href="#688">688</a>		<b>long</b> <a href="/source/s?defs=qt_matrixB&amp;project=rtmp_client">qt_matrixB</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="689" href="#689">689</a>		<b>long</b> <a href="/source/s?defs=qt_matrixU&amp;project=rtmp_client">qt_matrixU</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="hl" name="690" href="#690">690</a>		<b>long</b> <a href="/source/s?defs=qt_matrixC&amp;project=rtmp_client">qt_matrixC</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="691" href="#691">691</a>		<b>long</b> <a href="/source/s?defs=qt_matrixD&amp;project=rtmp_client">qt_matrixD</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="692" href="#692">692</a>		<b>long</b> <a href="/source/s?defs=qt_matrixV&amp;project=rtmp_client">qt_matrixV</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="693" href="#693">693</a>		<b>long</b> <a href="/source/s?defs=qt_matrixX&amp;project=rtmp_client">qt_matrixX</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="694" href="#694">694</a>		<b>long</b> <a href="/source/s?defs=qt_matrixY&amp;project=rtmp_client">qt_matrixY</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="695" href="#695">695</a>		<b>long</b> <a href="/source/s?defs=qt_matrixW&amp;project=rtmp_client">qt_matrixW</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="696" href="#696">696</a>		<a class="d" href="#qt_trackWidth">qt_trackWidth</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="697" href="#697">697</a>		<a class="d" href="#width">width</a> = (<a class="d" href="#qt_trackWidth">qt_trackWidth</a> &gt;&gt; <span class="n">16</span>);
<a class="l" name="698" href="#698">698</a>		<a class="d" href="#qt_trackHeight">qt_trackHeight</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="699" href="#699">699</a>		<a class="d" href="#height">height</a> = (<a class="d" href="#qt_trackHeight">qt_trackHeight</a> &gt;&gt; <span class="n">16</span>);
<a class="hl" name="700" href="#700">700</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">60</span>;
<a class="l" name="701" href="#701">701</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="702" href="#702">702</a>	}
<a class="l" name="703" href="#703">703</a>
<a class="l" name="704" href="#704">704</a>	<span class="c">/**
<a class="l" name="705" href="#705">705</a>	 * Loads MP4VideoMediaHeaderAtom atom from the input bitstream.
<a class="l" name="706" href="#706">706</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="707" href="#707">707</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="708" href="#708">708</a>	 */</span>
<a class="l" name="709" href="#709">709</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_video_media_header_atom"/><a href="/source/s?refs=create_video_media_header_atom&amp;project=rtmp_client" class="xmt">create_video_media_header_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="hl" name="710" href="#710">710</a>		<a class="d" href="#create_full_atom">create_full_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="711" href="#711">711</a>		<b>if</b> ((<a href="/source/s?defs=size&amp;project=rtmp_client">size</a> - <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>) == <span class="n">8</span>) {
<a class="l" name="712" href="#712">712</a>			<a class="d" href="#graphicsMode">graphicsMode</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="713" href="#713">713</a>			<a class="d" href="#opColorRed">opColorRed</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="714" href="#714">714</a>			<a class="d" href="#opColorGreen">opColorGreen</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="715" href="#715">715</a>			<a class="d" href="#opColorBlue">opColorBlue</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="716" href="#716">716</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">8</span>;
<a class="l" name="717" href="#717">717</a>		}
<a class="l" name="718" href="#718">718</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="719" href="#719">719</a>	}
<a class="hl" name="720" href="#720">720</a>
<a class="l" name="721" href="#721">721</a>	<span class="c">/**
<a class="l" name="722" href="#722">722</a>	 * Loads MP4VisualSampleEntryAtom atom from the input bitstream.
<a class="l" name="723" href="#723">723</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="724" href="#724">724</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="725" href="#725">725</a>	 */</span>
<a class="l" name="726" href="#726">726</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_visual_sample_entry_atom"/><a href="/source/s?refs=create_visual_sample_entry_atom&amp;project=rtmp_client" class="xmt">create_visual_sample_entry_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="727" href="#727">727</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Visual entry atom contains wxh"</span>);
<a class="l" name="728" href="#728">728</a>		<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">24</span>);
<a class="l" name="729" href="#729">729</a>		<a class="d" href="#width">width</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="hl" name="730" href="#730">730</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Width: {}"</span>, <a class="d" href="#width">width</a>);
<a class="l" name="731" href="#731">731</a>		<a class="d" href="#height">height</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="732" href="#732">732</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Height: {}"</span>, <a class="d" href="#height">height</a>);
<a class="l" name="733" href="#733">733</a>		<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">50</span>);
<a class="l" name="734" href="#734">734</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">78</span>;
<a class="l" name="735" href="#735">735</a>		<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=child&amp;project=rtmp_client">child</a> = <a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a class="d" href="#createAtom">createAtom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="736" href="#736">736</a>		<b>this</b>.<a class="d" href="#children">children</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=child&amp;project=rtmp_client">child</a>);
<a class="l" name="737" href="#737">737</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <a href="/source/s?defs=child&amp;project=rtmp_client">child</a>.<a class="d" href="#getSize">getSize</a>();
<a class="l" name="738" href="#738">738</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="739" href="#739">739</a>	}
<a class="hl" name="740" href="#740">740</a>
<a class="l" name="741" href="#741">741</a>	<span class="c">/**
<a class="l" name="742" href="#742">742</a>	 * Loads MP4VideoSampleEntryAtom atom from the input bitstream.
<a class="l" name="743" href="#743">743</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="744" href="#744">744</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="745" href="#745">745</a>	 */</span>
<a class="l" name="746" href="#746">746</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unused"</span>)
<a class="l" name="747" href="#747">747</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_video_sample_entry_atom"/><a href="/source/s?refs=create_video_sample_entry_atom&amp;project=rtmp_client" class="xmt">create_video_sample_entry_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="748" href="#748">748</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Video entry atom contains wxh"</span>);
<a class="l" name="749" href="#749">749</a>		<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">6</span>);
<a class="hl" name="750" href="#750">750</a>		<b>int</b> <a href="/source/s?defs=dataReferenceIndex&amp;project=rtmp_client">dataReferenceIndex</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="751" href="#751">751</a>		<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">2</span>);
<a class="l" name="752" href="#752">752</a>		<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">2</span>);
<a class="l" name="753" href="#753">753</a>		<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">12</span>);
<a class="l" name="754" href="#754">754</a>		<a class="d" href="#width">width</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="755" href="#755">755</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Width: {}"</span>, <a class="d" href="#width">width</a>);
<a class="l" name="756" href="#756">756</a>		<a class="d" href="#height">height</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="757" href="#757">757</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Height: {}"</span>, <a class="d" href="#height">height</a>);
<a class="l" name="758" href="#758">758</a>		<b>int</b> <a href="/source/s?defs=horizontalRez&amp;project=rtmp_client">horizontalRez</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>) &gt;&gt; <span class="n">16</span>;
<a class="l" name="759" href="#759">759</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"H Resolution: {}"</span>, <a href="/source/s?defs=horizontalRez&amp;project=rtmp_client">horizontalRez</a>);
<a class="hl" name="760" href="#760">760</a>		<b>int</b> <a href="/source/s?defs=verticalRez&amp;project=rtmp_client">verticalRez</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>) &gt;&gt; <span class="n">16</span>;
<a class="l" name="761" href="#761">761</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"V Resolution: {}"</span>, <a href="/source/s?defs=verticalRez&amp;project=rtmp_client">verticalRez</a>);
<a class="l" name="762" href="#762">762</a>		<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">4</span>);
<a class="l" name="763" href="#763">763</a>		<b>int</b> <a href="/source/s?defs=frameCount&amp;project=rtmp_client">frameCount</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="l" name="764" href="#764">764</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Frame to sample count: {}"</span>, <a href="/source/s?defs=frameCount&amp;project=rtmp_client">frameCount</a>);
<a class="l" name="765" href="#765">765</a>		<b>int</b> <a href="/source/s?defs=stringLen&amp;project=rtmp_client">stringLen</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">1</span>);
<a class="l" name="766" href="#766">766</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"String length (cpname): {}"</span>, <a href="/source/s?defs=stringLen&amp;project=rtmp_client">stringLen</a>);
<a class="l" name="767" href="#767">767</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=compressorName&amp;project=rtmp_client">compressorName</a> = <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readString&amp;project=rtmp_client">readString</a>(<span class="n">31</span>);
<a class="l" name="768" href="#768">768</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Compressor name: {}"</span>, <a href="/source/s?defs=compressorName&amp;project=rtmp_client">compressorName</a>.<a href="/source/s?defs=trim&amp;project=rtmp_client">trim</a>());
<a class="l" name="769" href="#769">769</a>		<b>int</b> <a href="/source/s?defs=depth&amp;project=rtmp_client">depth</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">2</span>);
<a class="hl" name="770" href="#770">770</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Depth: {}"</span>, <a href="/source/s?defs=depth&amp;project=rtmp_client">depth</a>);
<a class="l" name="771" href="#771">771</a>		<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=skipBytes&amp;project=rtmp_client">skipBytes</a>(<span class="n">2</span>);
<a class="l" name="772" href="#772">772</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">78</span>;
<a class="l" name="773" href="#773">773</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Bytes read: {}"</span>, <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>);
<a class="l" name="774" href="#774">774</a>		<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=child&amp;project=rtmp_client">child</a> = <a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a class="d" href="#createAtom">createAtom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="775" href="#775">775</a>		<b>this</b>.<a class="d" href="#children">children</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=child&amp;project=rtmp_client">child</a>);
<a class="l" name="776" href="#776">776</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <a href="/source/s?defs=child&amp;project=rtmp_client">child</a>.<a class="d" href="#getSize">getSize</a>();
<a class="l" name="777" href="#777">777</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="778" href="#778">778</a>	}
<a class="l" name="779" href="#779">779</a>
<a class="hl" name="780" href="#780">780</a>	<b>public</b> <b>int</b> <a class="xmt" name="getHeight"/><a href="/source/s?refs=getHeight&amp;project=rtmp_client" class="xmt">getHeight</a>() {
<a class="l" name="781" href="#781">781</a>		<b>return</b> <a class="d" href="#height">height</a>;
<a class="l" name="782" href="#782">782</a>	}
<a class="l" name="783" href="#783">783</a>
<a class="l" name="784" href="#784">784</a>	<b>public</b> <b>int</b> <a class="xmt" name="getWidth"/><a href="/source/s?refs=getWidth&amp;project=rtmp_client" class="xmt">getWidth</a>() {
<a class="l" name="785" href="#785">785</a>		<b>return</b> <a class="d" href="#width">width</a>;
<a class="l" name="786" href="#786">786</a>	}
<a class="l" name="787" href="#787">787</a>
<a class="l" name="788" href="#788">788</a>	<b>public</b> <b>int</b> <a class="xmt" name="getAvcLevel"/><a href="/source/s?refs=getAvcLevel&amp;project=rtmp_client" class="xmt">getAvcLevel</a>() {
<a class="l" name="789" href="#789">789</a>		<b>return</b> <a class="d" href="#avcLevel">avcLevel</a>;
<a class="hl" name="790" href="#790">790</a>	}
<a class="l" name="791" href="#791">791</a>
<a class="l" name="792" href="#792">792</a>	<b>public</b> <b>int</b> <a class="xmt" name="getAvcProfile"/><a href="/source/s?refs=getAvcProfile&amp;project=rtmp_client" class="xmt">getAvcProfile</a>() {
<a class="l" name="793" href="#793">793</a>		<b>return</b> <a class="d" href="#avcProfile">avcProfile</a>;
<a class="l" name="794" href="#794">794</a>	}
<a class="l" name="795" href="#795">795</a>
<a class="l" name="796" href="#796">796</a>	<b>public</b> <b>byte</b>[] <a class="xmt" name="getVideoConfigBytes"/><a href="/source/s?refs=getVideoConfigBytes&amp;project=rtmp_client" class="xmt">getVideoConfigBytes</a>() {
<a class="l" name="797" href="#797">797</a>		<b>return</b> <a class="d" href="#videoConfigBytes">videoConfigBytes</a>;
<a class="l" name="798" href="#798">798</a>	}
<a class="l" name="799" href="#799">799</a>
<a class="hl" name="800" href="#800">800</a>	<span class="c">/**
<a class="l" name="801" href="#801">801</a>	 * Loads AVCC atom from the input bitstream.
<a class="l" name="802" href="#802">802</a>	 *
<a class="l" name="803" href="#803">803</a>	 * &lt;pre&gt;
<a class="l" name="804" href="#804">804</a>	              * 8+ bytes <a href="/source/s?path=ISO/">ISO</a>/<a href="/source/s?path=ISO/IEC">IEC</a> 14496-10 or 3GPP AVC decode config box
<a class="l" name="805" href="#805">805</a>	                  = long unsigned offset + long ASCII text string 'avcC'
<a class="l" name="806" href="#806">806</a>	                -&gt; 1 byte version = 8-bit hex version  (current = 1)
<a class="l" name="807" href="#807">807</a>	                -&gt; 1 byte H.264 profile = 8-bit unsigned stream profile
<a class="l" name="808" href="#808">808</a>	                -&gt; 1 byte H.264 compatible profiles = 8-bit hex flags
<a class="l" name="809" href="#809">809</a>	                -&gt; 1 byte H.264 level = 8-bit unsigned stream level
<a class="hl" name="810" href="#810">810</a>	                -&gt; 1 1/2 nibble reserved = 6-bit unsigned value set to 63
<a class="l" name="811" href="#811">811</a>	                -&gt; 1/2 nibble NAL length = 2-bit length byte size type
<a class="l" name="812" href="#812">812</a>	                  - 1 byte = 0 ; 2 bytes = 1 ; 4 bytes = 3
<a class="l" name="813" href="#813">813</a>	                -&gt; 1 byte number of SPS = 8-bit unsigned total
<a class="l" name="814" href="#814">814</a>	                -&gt; 2+ bytes SPS length = short unsigned length
<a class="l" name="815" href="#815">815</a>	                -&gt; + SPS NAL unit = hexdump
<a class="l" name="816" href="#816">816</a>	                -&gt; 1 byte number of PPS = 8-bit unsigned total
<a class="l" name="817" href="#817">817</a>	                -&gt; 2+ bytes PPS length = short unsigned length
<a class="l" name="818" href="#818">818</a>	                -&gt; + PPS NAL unit = hexdump
<a class="l" name="819" href="#819">819</a>	 * &lt;/pre&gt;
<a class="hl" name="820" href="#820">820</a>	 *
<a class="l" name="821" href="#821">821</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="822" href="#822">822</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="823" href="#823">823</a>	 */</span>
<a class="l" name="824" href="#824">824</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_avc_config_atom"/><a href="/source/s?refs=create_avc_config_atom&amp;project=rtmp_client" class="xmt">create_avc_config_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="825" href="#825">825</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"AVC config"</span>);
<a class="l" name="826" href="#826">826</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Offset: {}"</span>, <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=getOffset&amp;project=rtmp_client">getOffset</a>());
<a class="l" name="827" href="#827">827</a>		<span class="c">//store the decoder config bytes</span>
<a class="l" name="828" href="#828">828</a>		<a class="d" href="#videoConfigBytes">videoConfigBytes</a> = <b>new</b> <b>byte</b>[(<b>int</b>) <a href="/source/s?defs=size&amp;project=rtmp_client">size</a>];
<a class="l" name="829" href="#829">829</a>		<b>for</b> (<b>int</b> b = <span class="n">0</span>; b &lt; <a class="d" href="#videoConfigBytes">videoConfigBytes</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>; b++) {
<a class="hl" name="830" href="#830">830</a>			<a class="d" href="#videoConfigBytes">videoConfigBytes</a>[b] = (<b>byte</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">1</span>);
<a class="l" name="831" href="#831">831</a>
<a class="l" name="832" href="#832">832</a>			<b>switch</b> (b) {
<a class="l" name="833" href="#833">833</a>				<span class="c">//0 / version</span>
<a class="l" name="834" href="#834">834</a>				<b>case</b> <span class="n">1</span>: <span class="c">//profile</span>
<a class="l" name="835" href="#835">835</a>					<a class="d" href="#avcProfile">avcProfile</a> = <a class="d" href="#videoConfigBytes">videoConfigBytes</a>[b];
<a class="l" name="836" href="#836">836</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"AVC profile: {}"</span>, <a class="d" href="#avcProfile">avcProfile</a>);
<a class="l" name="837" href="#837">837</a>					<b>break</b>;
<a class="l" name="838" href="#838">838</a>				<b>case</b> <span class="n">2</span>: <span class="c">//compatible profile</span>
<a class="l" name="839" href="#839">839</a>					<b>int</b> <a href="/source/s?defs=avcCompatProfile&amp;project=rtmp_client">avcCompatProfile</a> = <a class="d" href="#videoConfigBytes">videoConfigBytes</a>[b];
<a class="hl" name="840" href="#840">840</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"AVC compatible profile: {}"</span>, <a href="/source/s?defs=avcCompatProfile&amp;project=rtmp_client">avcCompatProfile</a>);
<a class="l" name="841" href="#841">841</a>					<b>break</b>;
<a class="l" name="842" href="#842">842</a>				<b>case</b> <span class="n">3</span>: <span class="c">//avc level</span>
<a class="l" name="843" href="#843">843</a>					<a class="d" href="#avcLevel">avcLevel</a> = <a class="d" href="#videoConfigBytes">videoConfigBytes</a>[b];
<a class="l" name="844" href="#844">844</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"AVC level: {}"</span>, <a class="d" href="#avcLevel">avcLevel</a>);
<a class="l" name="845" href="#845">845</a>					<b>break</b>;
<a class="l" name="846" href="#846">846</a>				<b>case</b> <span class="n">4</span>: <span class="c">//NAL length</span>
<a class="l" name="847" href="#847">847</a>					<b>break</b>;
<a class="l" name="848" href="#848">848</a>				<b>case</b> <span class="n">5</span>: <span class="c">//SPS number</span>
<a class="l" name="849" href="#849">849</a>					<b>int</b> <a href="/source/s?defs=numberSPS&amp;project=rtmp_client">numberSPS</a> = <a class="d" href="#videoConfigBytes">videoConfigBytes</a>[b];
<a class="hl" name="850" href="#850">850</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Number of SPS: {}"</span>, <a href="/source/s?defs=numberSPS&amp;project=rtmp_client">numberSPS</a>);
<a class="l" name="851" href="#851">851</a>					<b>break</b>;
<a class="l" name="852" href="#852">852</a>				<b>default</b>:
<a class="l" name="853" href="#853">853</a>
<a class="l" name="854" href="#854">854</a>			}
<a class="l" name="855" href="#855">855</a>
<a class="l" name="856" href="#856">856</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>++;
<a class="l" name="857" href="#857">857</a>		}
<a class="l" name="858" href="#858">858</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="859" href="#859">859</a>	}
<a class="hl" name="860" href="#860">860</a>
<a class="l" name="861" href="#861">861</a>	<span class="c">/**
<a class="l" name="862" href="#862">862</a>	 * Creates the PASP atom or Pixel Aspect Ratio. It is created by Quicktime
<a class="l" name="863" href="#863">863</a>	 * when exporting an MP4 file. The atom is required for ipod's and acts as
<a class="l" name="864" href="#864">864</a>	 * a container for the avcC atom in these cases.
<a class="l" name="865" href="#865">865</a>	 *
<a class="l" name="866" href="#866">866</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="867" href="#867">867</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="868" href="#868">868</a>	 */</span>
<a class="l" name="869" href="#869">869</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_pasp_atom"/><a href="/source/s?refs=create_pasp_atom&amp;project=rtmp_client" class="xmt">create_pasp_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="hl" name="870" href="#870">870</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Pixel aspect ratio"</span>);
<a class="l" name="871" href="#871">871</a>		<b>int</b> <a href="/source/s?defs=hSpacing&amp;project=rtmp_client">hSpacing</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="872" href="#872">872</a>		<b>int</b> <a href="/source/s?defs=vSpacing&amp;project=rtmp_client">vSpacing</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="873" href="#873">873</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"hSpacing: {} vSpacing: {}"</span>, <a href="/source/s?defs=hSpacing&amp;project=rtmp_client">hSpacing</a>, <a href="/source/s?defs=vSpacing&amp;project=rtmp_client">vSpacing</a>);
<a class="l" name="874" href="#874">874</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">8</span>;
<a class="l" name="875" href="#875">875</a>		<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=child&amp;project=rtmp_client">child</a> = <a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a class="d" href="#createAtom">createAtom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="876" href="#876">876</a>		<b>this</b>.<a class="d" href="#children">children</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=child&amp;project=rtmp_client">child</a>);
<a class="l" name="877" href="#877">877</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <a href="/source/s?defs=child&amp;project=rtmp_client">child</a>.<a class="d" href="#getSize">getSize</a>();
<a class="l" name="878" href="#878">878</a>
<a class="l" name="879" href="#879">879</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="hl" name="880" href="#880">880</a>	}
<a class="l" name="881" href="#881">881</a>
<a class="l" name="882" href="#882">882</a>	<span class="c">/**
<a class="l" name="883" href="#883">883</a>	 * Loads M4ESDAtom atom from the input bitstream.
<a class="l" name="884" href="#884">884</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="885" href="#885">885</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="886" href="#886">886</a>	 */</span>
<a class="l" name="887" href="#887">887</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_esd_atom"/><a href="/source/s?refs=create_esd_atom&amp;project=rtmp_client" class="xmt">create_esd_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="888" href="#888">888</a>		<a class="d" href="#create_full_atom">create_full_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="889" href="#889">889</a>		<a class="d" href="#esd_descriptor">esd_descriptor</a> = <a href="/source/s?defs=MP4Descriptor&amp;project=rtmp_client">MP4Descriptor</a>.<a href="/source/s?defs=createDescriptor&amp;project=rtmp_client">createDescriptor</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="hl" name="890" href="#890">890</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <a class="d" href="#esd_descriptor">esd_descriptor</a>.<a href="/source/s?defs=getReaded&amp;project=rtmp_client">getReaded</a>();
<a class="l" name="891" href="#891">891</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="892" href="#892">892</a>	}
<a class="l" name="893" href="#893">893</a>
<a class="l" name="894" href="#894">894</a>	<span class="c">/**
<a class="l" name="895" href="#895">895</a>	 * Returns the ESD descriptor.
<a class="l" name="896" href="#896">896</a>	 */</span>
<a class="l" name="897" href="#897">897</a>	<b>public</b> <a href="/source/s?defs=MP4Descriptor&amp;project=rtmp_client">MP4Descriptor</a> <a class="xmt" name="getEsd_descriptor"/><a href="/source/s?refs=getEsd_descriptor&amp;project=rtmp_client" class="xmt">getEsd_descriptor</a>() {
<a class="l" name="898" href="#898">898</a>		<b>return</b> <a class="d" href="#esd_descriptor">esd_descriptor</a>;
<a class="l" name="899" href="#899">899</a>	}
<a class="hl" name="900" href="#900">900</a>
<a class="l" name="901" href="#901">901</a>	<span class="c">/**
<a class="l" name="902" href="#902">902</a>	 * Loads composition time to sample atom from the input bitstream.
<a class="l" name="903" href="#903">903</a>	 * <strong>@param</strong> <em>bitstream</em> the input bitstream
<a class="l" name="904" href="#904">904</a>	 * <strong>@return</strong> the number of bytes which was being loaded.
<a class="l" name="905" href="#905">905</a>	 */</span>
<a class="l" name="906" href="#906">906</a>	<b>public</b> <b>long</b> <a class="xmt" name="create_composition_time_to_sample_atom"/><a href="/source/s?refs=create_composition_time_to_sample_atom&amp;project=rtmp_client" class="xmt">create_composition_time_to_sample_atom</a>(<a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xa" name="bitstream"/><a href="/source/s?refs=bitstream&amp;project=rtmp_client" class="xa">bitstream</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="907" href="#907">907</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Composition time to sample atom"</span>);
<a class="l" name="908" href="#908">908</a>		<a class="d" href="#create_full_atom">create_full_atom</a>(<a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>);
<a class="l" name="909" href="#909">909</a>		<a class="d" href="#comptimeToSamplesRecords">comptimeToSamplesRecords</a> = <b>new</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=CompositionTimeSampleRecord&amp;project=rtmp_client">CompositionTimeSampleRecord</a>&gt;();
<a class="hl" name="910" href="#910">910</a>		<a class="d" href="#entryCount">entryCount</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="911" href="#911">911</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Composition time to sample entries: {}"</span>, <a class="d" href="#entryCount">entryCount</a>);
<a class="l" name="912" href="#912">912</a>		<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">4</span>;
<a class="l" name="913" href="#913">913</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#entryCount">entryCount</a>; i++) {
<a class="l" name="914" href="#914">914</a>			<b>int</b> <a class="d" href="#sampleCount">sampleCount</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="915" href="#915">915</a>			<b>int</b> <a href="/source/s?defs=sampleOffset&amp;project=rtmp_client">sampleOffset</a> = (<b>int</b>) <a href="/source/s?defs=bitstream&amp;project=rtmp_client">bitstream</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<span class="n">4</span>);
<a class="l" name="916" href="#916">916</a>			<span class="c">//log.trace("Sync entry: {}", sample);</span>
<a class="l" name="917" href="#917">917</a>			<a class="d" href="#comptimeToSamplesRecords">comptimeToSamplesRecords</a>.<a href="/source/s?defs=addElement&amp;project=rtmp_client">addElement</a>(<b>new</b> <a href="/source/s?defs=CompositionTimeSampleRecord&amp;project=rtmp_client">CompositionTimeSampleRecord</a>(<a class="d" href="#sampleCount">sampleCount</a>, <a href="/source/s?defs=sampleOffset&amp;project=rtmp_client">sampleOffset</a>));
<a class="l" name="918" href="#918">918</a>			<a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a> += <span class="n">8</span>;
<a class="l" name="919" href="#919">919</a>		}
<a class="hl" name="920" href="#920">920</a>		<b>return</b> <a href="/source/s?defs=readed&amp;project=rtmp_client">readed</a>;
<a class="l" name="921" href="#921">921</a>	}
<a class="l" name="922" href="#922">922</a>
<a class="l" name="923" href="#923">923</a>	<b>public</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=CompositionTimeSampleRecord&amp;project=rtmp_client">CompositionTimeSampleRecord</a>&gt; <a class="xmt" name="getCompositionTimeToSamplesRecords"/><a href="/source/s?refs=getCompositionTimeToSamplesRecords&amp;project=rtmp_client" class="xmt">getCompositionTimeToSamplesRecords</a>() {
<a class="l" name="924" href="#924">924</a>		<b>return</b> <a class="d" href="#comptimeToSamplesRecords">comptimeToSamplesRecords</a>;
<a class="l" name="925" href="#925">925</a>	}
<a class="l" name="926" href="#926">926</a>
<a class="l" name="927" href="#927">927</a>	<span class="c">/**
<a class="l" name="928" href="#928">928</a>	 * Converts the time in seconds since midnight 1 Jan 1904 to the &lt;code&gt;Date&lt;/code&gt;.
<a class="l" name="929" href="#929">929</a>	 * <strong>@param</strong> <em>movieTime</em> the time in milliseconds since midnight 1 Jan 1904.
<a class="hl" name="930" href="#930">930</a>	 * <strong>@return</strong> the &lt;code&gt;Date&lt;/code&gt; object.
<a class="l" name="931" href="#931">931</a>	 */</span>
<a class="l" name="932" href="#932">932</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=Date&amp;project=rtmp_client">Date</a> <a class="xmt" name="createDate"/><a href="/source/s?refs=createDate&amp;project=rtmp_client" class="xmt">createDate</a>(<b>long</b> <a class="xa" name="movieTime"/><a href="/source/s?refs=movieTime&amp;project=rtmp_client" class="xa">movieTime</a>) {
<a class="l" name="933" href="#933">933</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=Date&amp;project=rtmp_client">Date</a>(<a class="d" href="#movieTime">movieTime</a> * <span class="n">1000</span> - <span class="n">2082850791998L</span>);
<a class="l" name="934" href="#934">934</a>	}
<a class="l" name="935" href="#935">935</a>
<a class="l" name="936" href="#936">936</a>	<b>public</b> <b>static</b> <b>int</b> <a class="xmt" name="typeToInt"/><a href="/source/s?refs=typeToInt&amp;project=rtmp_client" class="xmt">typeToInt</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="type"/><a href="/source/s?refs=type&amp;project=rtmp_client" class="xa">type</a>) {
<a class="l" name="937" href="#937">937</a>		<b>int</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>.<a href="/source/s?defs=charAt&amp;project=rtmp_client">charAt</a>(<span class="n">0</span>) &lt;&lt; <span class="n">24</span>) + (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>.<a href="/source/s?defs=charAt&amp;project=rtmp_client">charAt</a>(<span class="n">1</span>) &lt;&lt; <span class="n">16</span>) + (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>.<a href="/source/s?defs=charAt&amp;project=rtmp_client">charAt</a>(<span class="n">2</span>) &lt;&lt; <span class="n">8</span>) + <a href="/source/s?defs=type&amp;project=rtmp_client">type</a>.<a href="/source/s?defs=charAt&amp;project=rtmp_client">charAt</a>(<span class="n">3</span>);
<a class="l" name="938" href="#938">938</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="939" href="#939">939</a>	}
<a class="hl" name="940" href="#940">940</a>
<a class="l" name="941" href="#941">941</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="intToType"/><a href="/source/s?refs=intToType&amp;project=rtmp_client" class="xmt">intToType</a>(<b>int</b> <a class="xa" name="type"/><a href="/source/s?refs=type&amp;project=rtmp_client" class="xa">type</a>) {
<a class="l" name="942" href="#942">942</a>		<a href="/source/s?defs=StringBuilder&amp;project=rtmp_client">StringBuilder</a> <a href="/source/s?defs=st&amp;project=rtmp_client">st</a> = <b>new</b> <a href="/source/s?defs=StringBuilder&amp;project=rtmp_client">StringBuilder</a>();
<a class="l" name="943" href="#943">943</a>		<a href="/source/s?defs=st&amp;project=rtmp_client">st</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>((<b>char</b>) ((<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt; <span class="n">24</span>) &amp; <span class="n">0xff</span>));
<a class="l" name="944" href="#944">944</a>		<a href="/source/s?defs=st&amp;project=rtmp_client">st</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>((<b>char</b>) ((<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt; <span class="n">16</span>) &amp; <span class="n">0xff</span>));
<a class="l" name="945" href="#945">945</a>		<a href="/source/s?defs=st&amp;project=rtmp_client">st</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>((<b>char</b>) ((<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt; <span class="n">8</span>) &amp; <span class="n">0xff</span>));
<a class="l" name="946" href="#946">946</a>		<a href="/source/s?defs=st&amp;project=rtmp_client">st</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>((<b>char</b>) (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &amp; <span class="n">0xff</span>));
<a class="l" name="947" href="#947">947</a>		<b>return</b> <a href="/source/s?defs=st&amp;project=rtmp_client">st</a>.<a class="d" href="#toString">toString</a>();
<a class="l" name="948" href="#948">948</a>	}
<a class="l" name="949" href="#949">949</a>
<a class="hl" name="950" href="#950">950</a>	<span class="c">/**
<a class="l" name="951" href="#951">951</a>	 * Gets children from this atom.
<a class="l" name="952" href="#952">952</a>	 * <strong>@return</strong> children from this atom.
<a class="l" name="953" href="#953">953</a>	 */</span>
<a class="l" name="954" href="#954">954</a>	<b>public</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>&gt; <a class="xmt" name="getChildren"/><a href="/source/s?refs=getChildren&amp;project=rtmp_client" class="xmt">getChildren</a>() {
<a class="l" name="955" href="#955">955</a>		<b>return</b> <a class="d" href="#children">children</a>;
<a class="l" name="956" href="#956">956</a>	}
<a class="l" name="957" href="#957">957</a>
<a class="l" name="958" href="#958">958</a>	<span class="c">/**
<a class="l" name="959" href="#959">959</a>	 * Gets the size of this atom.
<a class="hl" name="960" href="#960">960</a>	 * <strong>@return</strong> the size of this atom.
<a class="l" name="961" href="#961">961</a>	 */</span>
<a class="l" name="962" href="#962">962</a>	<b>public</b> <b>long</b> <a class="xmt" name="getSize"/><a href="/source/s?refs=getSize&amp;project=rtmp_client" class="xmt">getSize</a>() {
<a class="l" name="963" href="#963">963</a>		<b>return</b> <a href="/source/s?defs=size&amp;project=rtmp_client">size</a>;
<a class="l" name="964" href="#964">964</a>	}
<a class="l" name="965" href="#965">965</a>
<a class="l" name="966" href="#966">966</a>	<span class="c">/**
<a class="l" name="967" href="#967">967</a>	 * Returns the type of this atom.
<a class="l" name="968" href="#968">968</a>	 */</span>
<a class="l" name="969" href="#969">969</a>	<b>public</b> <b>int</b> <a class="xmt" name="getType"/><a href="/source/s?refs=getType&amp;project=rtmp_client" class="xmt">getType</a>() {
<a class="hl" name="970" href="#970">970</a>		<b>return</b> <a href="/source/s?defs=type&amp;project=rtmp_client">type</a>;
<a class="l" name="971" href="#971">971</a>	}
<a class="l" name="972" href="#972">972</a>
<a class="l" name="973" href="#973">973</a>	<span class="c">/**
<a class="l" name="974" href="#974">974</a>	 * Returns the name of this atom.
<a class="l" name="975" href="#975">975</a>	 */</span>
<a class="l" name="976" href="#976">976</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toString"/><a href="/source/s?refs=toString&amp;project=rtmp_client" class="xmt">toString</a>() {
<a class="l" name="977" href="#977">977</a>		<b>return</b> <a class="d" href="#intToType">intToType</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>);
<a class="l" name="978" href="#978">978</a>	}
<a class="l" name="979" href="#979">979</a>
<a class="hl" name="980" href="#980">980</a>	<b>public</b> <b>static</b> <b>class</b> <a class="xc" name="Record"/><a href="/source/s?refs=Record&amp;project=rtmp_client" class="xc">Record</a> {
<a class="l" name="981" href="#981">981</a>		<b>private</b> <b>int</b> <a class="xfld" name="firstChunk"/><a href="/source/s?refs=firstChunk&amp;project=rtmp_client" class="xfld">firstChunk</a>;
<a class="l" name="982" href="#982">982</a>
<a class="l" name="983" href="#983">983</a>		<b>private</b> <b>int</b> <a class="xfld" name="samplesPerChunk"/><a href="/source/s?refs=samplesPerChunk&amp;project=rtmp_client" class="xfld">samplesPerChunk</a>;
<a class="l" name="984" href="#984">984</a>
<a class="l" name="985" href="#985">985</a>		<b>private</b> <b>int</b> <a class="xfld" name="sampleDescriptionIndex"/><a href="/source/s?refs=sampleDescriptionIndex&amp;project=rtmp_client" class="xfld">sampleDescriptionIndex</a>;
<a class="l" name="986" href="#986">986</a>
<a class="l" name="987" href="#987">987</a>		<b>public</b> <a class="xmt" name="Record"/><a href="/source/s?refs=Record&amp;project=rtmp_client" class="xmt">Record</a>(<b>int</b> <a class="xa" name="firstChunk"/><a href="/source/s?refs=firstChunk&amp;project=rtmp_client" class="xa">firstChunk</a>, <b>int</b> <a class="xa" name="samplesPerChunk"/><a href="/source/s?refs=samplesPerChunk&amp;project=rtmp_client" class="xa">samplesPerChunk</a>, <b>int</b> <a class="xa" name="sampleDescriptionIndex"/><a href="/source/s?refs=sampleDescriptionIndex&amp;project=rtmp_client" class="xa">sampleDescriptionIndex</a>) {
<a class="l" name="988" href="#988">988</a>			<b>this</b>.<a href="/source/s?defs=firstChunk&amp;project=rtmp_client">firstChunk</a> = <a href="/source/s?defs=firstChunk&amp;project=rtmp_client">firstChunk</a>;
<a class="l" name="989" href="#989">989</a>			<b>this</b>.<a href="/source/s?defs=samplesPerChunk&amp;project=rtmp_client">samplesPerChunk</a> = <a href="/source/s?defs=samplesPerChunk&amp;project=rtmp_client">samplesPerChunk</a>;
<a class="hl" name="990" href="#990">990</a>			<b>this</b>.<a href="/source/s?defs=sampleDescriptionIndex&amp;project=rtmp_client">sampleDescriptionIndex</a> = <a href="/source/s?defs=sampleDescriptionIndex&amp;project=rtmp_client">sampleDescriptionIndex</a>;
<a class="l" name="991" href="#991">991</a>		}
<a class="l" name="992" href="#992">992</a>
<a class="l" name="993" href="#993">993</a>		<b>public</b> <b>int</b> <a class="xmt" name="getFirstChunk"/><a href="/source/s?refs=getFirstChunk&amp;project=rtmp_client" class="xmt">getFirstChunk</a>() {
<a class="l" name="994" href="#994">994</a>			<b>return</b> <a href="/source/s?defs=firstChunk&amp;project=rtmp_client">firstChunk</a>;
<a class="l" name="995" href="#995">995</a>		}
<a class="l" name="996" href="#996">996</a>
<a class="l" name="997" href="#997">997</a>		<b>public</b> <b>int</b> <a class="xmt" name="getSamplesPerChunk"/><a href="/source/s?refs=getSamplesPerChunk&amp;project=rtmp_client" class="xmt">getSamplesPerChunk</a>() {
<a class="l" name="998" href="#998">998</a>			<b>return</b> <a href="/source/s?defs=samplesPerChunk&amp;project=rtmp_client">samplesPerChunk</a>;
<a class="l" name="999" href="#999">999</a>		}
<a class="hl" name="1000" href="#1000">1000</a>
<a class="l" name="1001" href="#1001">1001</a>		<b>public</b> <b>int</b> <a class="xmt" name="getSampleDescriptionIndex"/><a href="/source/s?refs=getSampleDescriptionIndex&amp;project=rtmp_client" class="xmt">getSampleDescriptionIndex</a>() {
<a class="l" name="1002" href="#1002">1002</a>			<b>return</b> <a href="/source/s?defs=sampleDescriptionIndex&amp;project=rtmp_client">sampleDescriptionIndex</a>;
<a class="l" name="1003" href="#1003">1003</a>		}
<a class="l" name="1004" href="#1004">1004</a>	}
<a class="l" name="1005" href="#1005">1005</a>
<a class="l" name="1006" href="#1006">1006</a>	<b>public</b> <b>static</b> <b>class</b> <a class="xc" name="TimeSampleRecord"/><a href="/source/s?refs=TimeSampleRecord&amp;project=rtmp_client" class="xc">TimeSampleRecord</a> {
<a class="l" name="1007" href="#1007">1007</a>		<b>private</b> <b>int</b> <a class="xfld" name="consecutiveSamples"/><a href="/source/s?refs=consecutiveSamples&amp;project=rtmp_client" class="xfld">consecutiveSamples</a>;
<a class="l" name="1008" href="#1008">1008</a>
<a class="l" name="1009" href="#1009">1009</a>		<b>private</b> <b>int</b> <a class="xfld" name="sampleDuration"/><a href="/source/s?refs=sampleDuration&amp;project=rtmp_client" class="xfld">sampleDuration</a>;
<a class="hl" name="1010" href="#1010">1010</a>
<a class="l" name="1011" href="#1011">1011</a>		<b>public</b> <a class="xmt" name="TimeSampleRecord"/><a href="/source/s?refs=TimeSampleRecord&amp;project=rtmp_client" class="xmt">TimeSampleRecord</a>(<b>int</b> <a class="xa" name="consecutiveSamples"/><a href="/source/s?refs=consecutiveSamples&amp;project=rtmp_client" class="xa">consecutiveSamples</a>, <b>int</b> <a class="xa" name="sampleDuration"/><a href="/source/s?refs=sampleDuration&amp;project=rtmp_client" class="xa">sampleDuration</a>) {
<a class="l" name="1012" href="#1012">1012</a>			<b>this</b>.<a href="/source/s?defs=consecutiveSamples&amp;project=rtmp_client">consecutiveSamples</a> = <a href="/source/s?defs=consecutiveSamples&amp;project=rtmp_client">consecutiveSamples</a>;
<a class="l" name="1013" href="#1013">1013</a>			<b>this</b>.<a href="/source/s?defs=sampleDuration&amp;project=rtmp_client">sampleDuration</a> = <a href="/source/s?defs=sampleDuration&amp;project=rtmp_client">sampleDuration</a>;
<a class="l" name="1014" href="#1014">1014</a>		}
<a class="l" name="1015" href="#1015">1015</a>
<a class="l" name="1016" href="#1016">1016</a>		<b>public</b> <b>int</b> <a class="xmt" name="getConsecutiveSamples"/><a href="/source/s?refs=getConsecutiveSamples&amp;project=rtmp_client" class="xmt">getConsecutiveSamples</a>() {
<a class="l" name="1017" href="#1017">1017</a>			<b>return</b> <a href="/source/s?defs=consecutiveSamples&amp;project=rtmp_client">consecutiveSamples</a>;
<a class="l" name="1018" href="#1018">1018</a>		}
<a class="l" name="1019" href="#1019">1019</a>
<a class="hl" name="1020" href="#1020">1020</a>		<b>public</b> <b>int</b> <a class="xmt" name="getSampleDuration"/><a href="/source/s?refs=getSampleDuration&amp;project=rtmp_client" class="xmt">getSampleDuration</a>() {
<a class="l" name="1021" href="#1021">1021</a>			<b>return</b> <a href="/source/s?defs=sampleDuration&amp;project=rtmp_client">sampleDuration</a>;
<a class="l" name="1022" href="#1022">1022</a>		}
<a class="l" name="1023" href="#1023">1023</a>	}
<a class="l" name="1024" href="#1024">1024</a>
<a class="l" name="1025" href="#1025">1025</a>	<b>public</b> <b>static</b> <b>class</b> <a class="xc" name="CompositionTimeSampleRecord"/><a href="/source/s?refs=CompositionTimeSampleRecord&amp;project=rtmp_client" class="xc">CompositionTimeSampleRecord</a> {
<a class="l" name="1026" href="#1026">1026</a>		<b>private</b> <b>int</b> <a class="xfld" name="consecutiveSamples"/><a href="/source/s?refs=consecutiveSamples&amp;project=rtmp_client" class="xfld">consecutiveSamples</a>;
<a class="l" name="1027" href="#1027">1027</a>
<a class="l" name="1028" href="#1028">1028</a>		<b>private</b> <b>int</b> <a class="xfld" name="sampleOffset"/><a href="/source/s?refs=sampleOffset&amp;project=rtmp_client" class="xfld">sampleOffset</a>;
<a class="l" name="1029" href="#1029">1029</a>
<a class="hl" name="1030" href="#1030">1030</a>		<b>public</b> <a class="xmt" name="CompositionTimeSampleRecord"/><a href="/source/s?refs=CompositionTimeSampleRecord&amp;project=rtmp_client" class="xmt">CompositionTimeSampleRecord</a>(<b>int</b> <a class="xa" name="consecutiveSamples"/><a href="/source/s?refs=consecutiveSamples&amp;project=rtmp_client" class="xa">consecutiveSamples</a>, <b>int</b> <a class="xa" name="sampleOffset"/><a href="/source/s?refs=sampleOffset&amp;project=rtmp_client" class="xa">sampleOffset</a>) {
<a class="l" name="1031" href="#1031">1031</a>			<b>this</b>.<a href="/source/s?defs=consecutiveSamples&amp;project=rtmp_client">consecutiveSamples</a> = <a href="/source/s?defs=consecutiveSamples&amp;project=rtmp_client">consecutiveSamples</a>;
<a class="l" name="1032" href="#1032">1032</a>			<b>this</b>.<a href="/source/s?defs=sampleOffset&amp;project=rtmp_client">sampleOffset</a> = <a href="/source/s?defs=sampleOffset&amp;project=rtmp_client">sampleOffset</a>;
<a class="l" name="1033" href="#1033">1033</a>		}
<a class="l" name="1034" href="#1034">1034</a>
<a class="l" name="1035" href="#1035">1035</a>		<b>public</b> <b>int</b> <a class="xmt" name="getConsecutiveSamples"/><a href="/source/s?refs=getConsecutiveSamples&amp;project=rtmp_client" class="xmt">getConsecutiveSamples</a>() {
<a class="l" name="1036" href="#1036">1036</a>			<b>return</b> <a href="/source/s?defs=consecutiveSamples&amp;project=rtmp_client">consecutiveSamples</a>;
<a class="l" name="1037" href="#1037">1037</a>		}
<a class="l" name="1038" href="#1038">1038</a>
<a class="l" name="1039" href="#1039">1039</a>		<b>public</b> <b>int</b> <a class="xmt" name="getSampleOffset"/><a href="/source/s?refs=getSampleOffset&amp;project=rtmp_client" class="xmt">getSampleOffset</a>() {
<a class="hl" name="1040" href="#1040">1040</a>			<b>return</b> <a href="/source/s?defs=sampleOffset&amp;project=rtmp_client">sampleOffset</a>;
<a class="l" name="1041" href="#1041">1041</a>		}
<a class="l" name="1042" href="#1042">1042</a>
<a class="l" name="1043" href="#1043">1043</a>		<b>public</b> <b>void</b> <a class="xmt" name="setSampleOffset"/><a href="/source/s?refs=setSampleOffset&amp;project=rtmp_client" class="xmt">setSampleOffset</a>(<b>int</b> <a class="xa" name="offset"/><a href="/source/s?refs=offset&amp;project=rtmp_client" class="xa">offset</a>) {
<a class="l" name="1044" href="#1044">1044</a>			<a href="/source/s?defs=sampleOffset&amp;project=rtmp_client">sampleOffset</a> = <a class="d" href="#offset">offset</a>;
<a class="l" name="1045" href="#1045">1045</a>		}
<a class="l" name="1046" href="#1046">1046</a>	}
<a class="l" name="1047" href="#1047">1047</a>}
<a class="l" name="1048" href="#1048">1048</a>