<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["MP4Reader",75]]],["Package","xp",[["org.red5.io.mp4",1]]],["Method","xmt",[["MP4Reader",226],["MP4Reader",234],["analyzeFrames",1157],["analyzeKeyFrames",1371],["close",1340],["createFileMeta",892],["createPreStreamingTags",1004],["decodeHeader",256],["getAudioCodecId",827],["getBytesRead",812],["getCurrentPosition",764],["getDuration",819],["getFile",798],["getFileData",788],["getOffset",805],["getTotalBytes",745],["getVideoCodecId",823],["hasMoreTags",833],["hasVideo",779],["position",1311],["readTag",1070],["readTagHeader",1366],["setAudioCodecId",1362],["setVideoCodecId",1358]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=mp4&amp;project=rtmp_client">mp4</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2007 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=File&amp;project=rtmp_client">File</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=FileInputStream&amp;project=rtmp_client">FileInputStream</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="25" href="#25">25</a><span class="c">//import java.io.UnsupportedEncodingException;</span>
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=channels&amp;project=rtmp_client">channels</a>.<a href="/source/s?defs=FileChannel&amp;project=rtmp_client">FileChannel</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=text&amp;project=rtmp_client">text</a>.<a href="/source/s?defs=DecimalFormat&amp;project=rtmp_client">DecimalFormat</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=text&amp;project=rtmp_client">text</a>.<a href="/source/s?defs=NumberFormat&amp;project=rtmp_client">NumberFormat</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Collections&amp;project=rtmp_client">Collections</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>;
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=LinkedList&amp;project=rtmp_client">LinkedList</a>;
<a class="l" name="34" href="#34">34</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>;
<a class="l" name="35" href="#35">35</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="36" href="#36">36</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>;
<a class="l" name="37" href="#37">37</a>
<a class="l" name="38" href="#38">38</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=commons&amp;project=rtmp_client">commons</a>.<a href="/source/s?defs=lang&amp;project=rtmp_client">lang</a>.<a href="/source/s?defs=builder&amp;project=rtmp_client">builder</a>.<a href="/source/s?defs=ToStringBuilder&amp;project=rtmp_client">ToStringBuilder</a>;
<a class="l" name="39" href="#39">39</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="hl" name="40" href="#40">40</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IStreamableFile&amp;project=rtmp_client">IStreamableFile</a>;
<a class="l" name="41" href="#41">41</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a>;
<a class="l" name="42" href="#42">42</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=ITagReader&amp;project=rtmp_client">ITagReader</a>;
<a class="l" name="43" href="#43">43</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>;
<a class="l" name="44" href="#44">44</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>;
<a class="l" name="45" href="#45">45</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>.<a href="/source/s?defs=IKeyFrameDataAnalyzer&amp;project=rtmp_client">IKeyFrameDataAnalyzer</a>;
<a class="l" name="46" href="#46">46</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>.<a href="/source/s?defs=Tag&amp;project=rtmp_client">Tag</a>;
<a class="l" name="47" href="#47">47</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=mp4&amp;project=rtmp_client">mp4</a>.<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=CompositionTimeSampleRecord&amp;project=rtmp_client">CompositionTimeSampleRecord</a>;
<a class="l" name="48" href="#48">48</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>;
<a class="l" name="49" href="#49">49</a><span class="c">//import org.red5.io.utils.HexDump;</span>
<a class="hl" name="50" href="#50">50</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="51" href="#51">51</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a><span class="c">/**
<a class="l" name="54" href="#54">54</a> * This reader is used to read the contents of an MP4 file.
<a class="l" name="55" href="#55">55</a> *
<a class="l" name="56" href="#56">56</a> * NOTE: This class is not implemented as thread-safe, the caller
<a class="l" name="57" href="#57">57</a> * should ensure the thread-safety.
<a class="l" name="58" href="#58">58</a> * &lt;p&gt;
<a class="l" name="59" href="#59">59</a> * New NetStream notifications
<a class="hl" name="60" href="#60">60</a> * &lt;br /&gt;
<a class="l" name="61" href="#61">61</a> * Two new notifications facilitate the implementation of the playback components:
<a class="l" name="62" href="#62">62</a> * &lt;ul&gt;
<a class="l" name="63" href="#63">63</a> * &lt;li&gt;NetStream.Play.FileStructureInvalid: This event is sent if the player detects
<a class="l" name="64" href="#64">64</a> * an MP4 with an invalid file structure. Flash Player cannot play files that have
<a class="l" name="65" href="#65">65</a> * invalid file structures.&lt;/li&gt;
<a class="l" name="66" href="#66">66</a> * &lt;li&gt;NetStream.Play.NoSupportedTrackFound: This event is sent if the player does not
<a class="l" name="67" href="#67">67</a> * detect any supported tracks. If there aren't any supported video, audio or data
<a class="l" name="68" href="#68">68</a> * tracks found, Flash Player does not play the file.&lt;/li&gt;
<a class="l" name="69" href="#69">69</a> * &lt;/ul&gt;
<a class="hl" name="70" href="#70">70</a> * &lt;/p&gt;
<a class="l" name="71" href="#71">71</a> *
<a class="l" name="72" href="#72">72</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="73" href="#73">73</a> * <strong>@author</strong> Paul Gregoire (mondain@gmail.com)
<a class="l" name="74" href="#74">74</a> */</span>
<a class="l" name="75" href="#75">75</a><b>public</b> <b>class</b> <a class="xc" name="MP4Reader"/><a href="/source/s?refs=MP4Reader&amp;project=rtmp_client" class="xc">MP4Reader</a> <b>implements</b> <a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>, <a href="/source/s?defs=ITagReader&amp;project=rtmp_client">ITagReader</a>, <a href="/source/s?defs=IKeyFrameDataAnalyzer&amp;project=rtmp_client">IKeyFrameDataAnalyzer</a> {
<a class="l" name="76" href="#76">76</a>
<a class="l" name="77" href="#77">77</a>	<span class="c">/**
<a class="l" name="78" href="#78">78</a>	 * Logger
<a class="l" name="79" href="#79">79</a>	 */</span>
<a class="hl" name="80" href="#80">80</a>	<b>private</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a href="/source/s?defs=MP4Reader&amp;project=rtmp_client">MP4Reader</a>.<b>class</b>);
<a class="l" name="81" href="#81">81</a>
<a class="l" name="82" href="#82">82</a>	<span class="c">/** Audio packet prefix */</span>
<a class="l" name="83" href="#83">83</a>	<b>public</b> <b>final</b> <b>static</b> <b>byte</b>[] <a class="xfld" name="PREFIX_AUDIO_FRAME"/><a href="/source/s?refs=PREFIX_AUDIO_FRAME&amp;project=rtmp_client" class="xfld">PREFIX_AUDIO_FRAME</a> = <b>new</b> <b>byte</b>[] { (<b>byte</b>) <span class="n">0xaf</span>, (<b>byte</b>) <span class="n">0x01</span> };
<a class="l" name="84" href="#84">84</a>
<a class="l" name="85" href="#85">85</a>	<span class="c">/** Audio config aac main */</span>
<a class="l" name="86" href="#86">86</a>	<b>public</b> <b>final</b> <b>static</b> <b>byte</b>[] <a class="xfld" name="AUDIO_CONFIG_FRAME_AAC_MAIN"/><a href="/source/s?refs=AUDIO_CONFIG_FRAME_AAC_MAIN&amp;project=rtmp_client" class="xfld">AUDIO_CONFIG_FRAME_AAC_MAIN</a> = <b>new</b> <b>byte</b>[] { (<b>byte</b>) <span class="n">0x0a</span>, (<b>byte</b>) <span class="n">0x10</span> };
<a class="l" name="87" href="#87">87</a>
<a class="l" name="88" href="#88">88</a>	<span class="c">/** Audio config aac lc */</span>
<a class="l" name="89" href="#89">89</a>	<b>public</b> <b>final</b> <b>static</b> <b>byte</b>[] <a class="xfld" name="AUDIO_CONFIG_FRAME_AAC_LC"/><a href="/source/s?refs=AUDIO_CONFIG_FRAME_AAC_LC&amp;project=rtmp_client" class="xfld">AUDIO_CONFIG_FRAME_AAC_LC</a> = <b>new</b> <b>byte</b>[] { (<b>byte</b>) <span class="n">0x12</span>, (<b>byte</b>) <span class="n">0x10</span> };
<a class="hl" name="90" href="#90">90</a>
<a class="l" name="91" href="#91">91</a>	<span class="c">/** Audio config sbr */</span>
<a class="l" name="92" href="#92">92</a>	<b>public</b> <b>final</b> <b>static</b> <b>byte</b>[] <a class="xfld" name="AUDIO_CONFIG_FRAME_SBR"/><a href="/source/s?refs=AUDIO_CONFIG_FRAME_SBR&amp;project=rtmp_client" class="xfld">AUDIO_CONFIG_FRAME_SBR</a> = <b>new</b> <b>byte</b>[] { (<b>byte</b>) <span class="n">0x13</span>, (<b>byte</b>) <span class="n">0x90</span>, (<b>byte</b>) <span class="n">0x56</span>, (<b>byte</b>) <span class="n">0xe5</span>, (<b>byte</b>) <span class="n">0xa5</span>, (<b>byte</b>) <span class="n">0x48</span>, (<b>byte</b>) <span class="n">0x00</span> };
<a class="l" name="93" href="#93">93</a>
<a class="l" name="94" href="#94">94</a>	<span class="c">/** Video packet prefix for the decoder frame */</span>
<a class="l" name="95" href="#95">95</a>	<b>public</b> <b>final</b> <b>static</b> <b>byte</b>[] <a class="xfld" name="PREFIX_VIDEO_CONFIG_FRAME"/><a href="/source/s?refs=PREFIX_VIDEO_CONFIG_FRAME&amp;project=rtmp_client" class="xfld">PREFIX_VIDEO_CONFIG_FRAME</a> = <b>new</b> <b>byte</b>[] { (<b>byte</b>) <span class="n">0x17</span>, (<b>byte</b>) <span class="n">0x00</span>, (<b>byte</b>) <span class="n">0x00</span>, (<b>byte</b>) <span class="n">0x00</span>, (<b>byte</b>) <span class="n">0x00</span> };
<a class="l" name="96" href="#96">96</a>
<a class="l" name="97" href="#97">97</a>	<span class="c">/** Video packet prefix for key frames */</span>
<a class="l" name="98" href="#98">98</a>	<b>public</b> <b>final</b> <b>static</b> <b>byte</b>[] <a class="xfld" name="PREFIX_VIDEO_KEYFRAME"/><a href="/source/s?refs=PREFIX_VIDEO_KEYFRAME&amp;project=rtmp_client" class="xfld">PREFIX_VIDEO_KEYFRAME</a> = <b>new</b> <b>byte</b>[] { (<b>byte</b>) <span class="n">0x17</span>, (<b>byte</b>) <span class="n">0x01</span> };
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a>	<span class="c">/** Video packet prefix for standard frames (interframe) */</span>
<a class="l" name="101" href="#101">101</a>	<b>public</b> <b>final</b> <b>static</b> <b>byte</b>[] <a class="xfld" name="PREFIX_VIDEO_FRAME"/><a href="/source/s?refs=PREFIX_VIDEO_FRAME&amp;project=rtmp_client" class="xfld">PREFIX_VIDEO_FRAME</a> = <b>new</b> <b>byte</b>[] { (<b>byte</b>) <span class="n">0x27</span>, (<b>byte</b>) <span class="n">0x01</span> };
<a class="l" name="102" href="#102">102</a>
<a class="l" name="103" href="#103">103</a>	<span class="c">/**
<a class="l" name="104" href="#104">104</a>	 * File
<a class="l" name="105" href="#105">105</a>	 */</span>
<a class="l" name="106" href="#106">106</a>	<b>private</b> <a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a class="xfld" name="file"/><a href="/source/s?refs=file&amp;project=rtmp_client" class="xfld">file</a>;
<a class="l" name="107" href="#107">107</a>
<a class="l" name="108" href="#108">108</a>	<span class="c">/**
<a class="l" name="109" href="#109">109</a>	 * Input stream
<a class="hl" name="110" href="#110">110</a>	 */</span>
<a class="l" name="111" href="#111">111</a>	<b>private</b> <a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a> <a class="xfld" name="fis"/><a href="/source/s?refs=fis&amp;project=rtmp_client" class="xfld">fis</a>;
<a class="l" name="112" href="#112">112</a>
<a class="l" name="113" href="#113">113</a>	<span class="c">/**
<a class="l" name="114" href="#114">114</a>	 * File channel
<a class="l" name="115" href="#115">115</a>	 */</span>
<a class="l" name="116" href="#116">116</a>	<b>private</b> <a href="/source/s?defs=FileChannel&amp;project=rtmp_client">FileChannel</a> <a class="xfld" name="channel"/><a href="/source/s?refs=channel&amp;project=rtmp_client" class="xfld">channel</a>;
<a class="l" name="117" href="#117">117</a>
<a class="l" name="118" href="#118">118</a>	<span class="c">/** Mapping between file position and timestamp in ms. */</span>
<a class="l" name="119" href="#119">119</a>	<b>private</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt; <a class="xfld" name="timePosMap"/><a href="/source/s?refs=timePosMap&amp;project=rtmp_client" class="xfld">timePosMap</a>;
<a class="hl" name="120" href="#120">120</a>
<a class="l" name="121" href="#121">121</a>	<b>private</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt; <a class="xfld" name="samplePosMap"/><a href="/source/s?refs=samplePosMap&amp;project=rtmp_client" class="xfld">samplePosMap</a>;
<a class="l" name="122" href="#122">122</a>
<a class="l" name="123" href="#123">123</a>	<span class="c">/** Whether or not the clip contains a video track */</span>
<a class="l" name="124" href="#124">124</a>	<b>private</b> <b>boolean</b> <a class="xfld" name="hasVideo"/><a href="/source/s?refs=hasVideo&amp;project=rtmp_client" class="xfld">hasVideo</a> = <b>false</b>;
<a class="l" name="125" href="#125">125</a>
<a class="l" name="126" href="#126">126</a>	<span class="c">/** Whether or not the clip contains an audio track */</span>
<a class="l" name="127" href="#127">127</a>	<b>private</b> <b>boolean</b> <a class="xfld" name="hasAudio"/><a href="/source/s?refs=hasAudio&amp;project=rtmp_client" class="xfld">hasAudio</a> = <b>false</b>;
<a class="l" name="128" href="#128">128</a>
<a class="l" name="129" href="#129">129</a>	<span class="c">//default video codec</span>
<a class="hl" name="130" href="#130">130</a>	<b>private</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="videoCodecId"/><a href="/source/s?refs=videoCodecId&amp;project=rtmp_client" class="xfld">videoCodecId</a> = <span class="s">"avc1"</span>;
<a class="l" name="131" href="#131">131</a>
<a class="l" name="132" href="#132">132</a>	<span class="c">//default audio codec</span>
<a class="l" name="133" href="#133">133</a>	<b>private</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="audioCodecId"/><a href="/source/s?refs=audioCodecId&amp;project=rtmp_client" class="xfld">audioCodecId</a> = <span class="s">"mp4a"</span>;
<a class="l" name="134" href="#134">134</a>
<a class="l" name="135" href="#135">135</a>	<span class="c">//decoder bytes / configs</span>
<a class="l" name="136" href="#136">136</a>	<b>private</b> <b>byte</b>[] <a class="xfld" name="audioDecoderBytes"/><a href="/source/s?refs=audioDecoderBytes&amp;project=rtmp_client" class="xfld">audioDecoderBytes</a>;
<a class="l" name="137" href="#137">137</a>
<a class="l" name="138" href="#138">138</a>	<b>private</b> <b>byte</b>[] <a class="xfld" name="videoDecoderBytes"/><a href="/source/s?refs=videoDecoderBytes&amp;project=rtmp_client" class="xfld">videoDecoderBytes</a>;
<a class="l" name="139" href="#139">139</a>
<a class="hl" name="140" href="#140">140</a>	<span class="c">// duration in milliseconds</span>
<a class="l" name="141" href="#141">141</a>	<b>private</b> <b>long</b> <a class="xfld" name="duration"/><a href="/source/s?refs=duration&amp;project=rtmp_client" class="xfld">duration</a>;
<a class="l" name="142" href="#142">142</a>
<a class="l" name="143" href="#143">143</a>	<span class="c">// movie time scale</span>
<a class="l" name="144" href="#144">144</a>	<b>private</b> <b>int</b> <a class="xfld" name="timeScale"/><a href="/source/s?refs=timeScale&amp;project=rtmp_client" class="xfld">timeScale</a>;
<a class="l" name="145" href="#145">145</a>
<a class="l" name="146" href="#146">146</a>	<b>private</b> <b>int</b> <a class="xfld" name="width"/><a href="/source/s?refs=width&amp;project=rtmp_client" class="xfld">width</a>;
<a class="l" name="147" href="#147">147</a>
<a class="l" name="148" href="#148">148</a>	<b>private</b> <b>int</b> <a class="xfld" name="height"/><a href="/source/s?refs=height&amp;project=rtmp_client" class="xfld">height</a>;
<a class="l" name="149" href="#149">149</a>
<a class="hl" name="150" href="#150">150</a>	<span class="c">//audio sample rate kHz</span>
<a class="l" name="151" href="#151">151</a>	<b>private</b> <b>double</b> <a class="xfld" name="audioTimeScale"/><a href="/source/s?refs=audioTimeScale&amp;project=rtmp_client" class="xfld">audioTimeScale</a>;
<a class="l" name="152" href="#152">152</a>
<a class="l" name="153" href="#153">153</a>	<b>private</b> <b>int</b> <a class="xfld" name="audioChannels"/><a href="/source/s?refs=audioChannels&amp;project=rtmp_client" class="xfld">audioChannels</a>;
<a class="l" name="154" href="#154">154</a>
<a class="l" name="155" href="#155">155</a>	<span class="c">//default to aac lc</span>
<a class="l" name="156" href="#156">156</a>	<b>private</b> <b>int</b> <a class="xfld" name="audioCodecType"/><a href="/source/s?refs=audioCodecType&amp;project=rtmp_client" class="xfld">audioCodecType</a> = <span class="n">1</span>;
<a class="l" name="157" href="#157">157</a>
<a class="l" name="158" href="#158">158</a>	<b>private</b> <b>int</b> <a class="xfld" name="videoSampleCount"/><a href="/source/s?refs=videoSampleCount&amp;project=rtmp_client" class="xfld">videoSampleCount</a>;
<a class="l" name="159" href="#159">159</a>
<a class="hl" name="160" href="#160">160</a>	<b>private</b> <b>double</b> <a class="xfld" name="fps"/><a href="/source/s?refs=fps&amp;project=rtmp_client" class="xfld">fps</a>;
<a class="l" name="161" href="#161">161</a>
<a class="l" name="162" href="#162">162</a>	<b>private</b> <b>double</b> <a class="xfld" name="videoTimeScale"/><a href="/source/s?refs=videoTimeScale&amp;project=rtmp_client" class="xfld">videoTimeScale</a>;
<a class="l" name="163" href="#163">163</a>
<a class="l" name="164" href="#164">164</a>	<b>private</b> <b>int</b> <a class="xfld" name="avcLevel"/><a href="/source/s?refs=avcLevel&amp;project=rtmp_client" class="xfld">avcLevel</a>;
<a class="l" name="165" href="#165">165</a>
<a class="l" name="166" href="#166">166</a>	<b>private</b> <b>int</b> <a class="xfld" name="avcProfile"/><a href="/source/s?refs=avcProfile&amp;project=rtmp_client" class="xfld">avcProfile</a>;
<a class="l" name="167" href="#167">167</a>
<a class="l" name="168" href="#168">168</a>	<b>private</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="formattedDuration"/><a href="/source/s?refs=formattedDuration&amp;project=rtmp_client" class="xfld">formattedDuration</a>;
<a class="l" name="169" href="#169">169</a>
<a class="hl" name="170" href="#170">170</a>	<b>private</b> <b>long</b> <a class="xfld" name="moovOffset"/><a href="/source/s?refs=moovOffset&amp;project=rtmp_client" class="xfld">moovOffset</a>;
<a class="l" name="171" href="#171">171</a>
<a class="l" name="172" href="#172">172</a>	<b>private</b> <b>long</b> <a class="xfld" name="mdatOffset"/><a href="/source/s?refs=mdatOffset&amp;project=rtmp_client" class="xfld">mdatOffset</a>;
<a class="l" name="173" href="#173">173</a>
<a class="l" name="174" href="#174">174</a>	<span class="c">//samples to chunk mappings</span>
<a class="l" name="175" href="#175">175</a>	<b>private</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=Record&amp;project=rtmp_client">Record</a>&gt; <a class="xfld" name="videoSamplesToChunks"/><a href="/source/s?refs=videoSamplesToChunks&amp;project=rtmp_client" class="xfld">videoSamplesToChunks</a>;
<a class="l" name="176" href="#176">176</a>
<a class="l" name="177" href="#177">177</a>	<b>private</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=Record&amp;project=rtmp_client">Record</a>&gt; <a class="xfld" name="audioSamplesToChunks"/><a href="/source/s?refs=audioSamplesToChunks&amp;project=rtmp_client" class="xfld">audioSamplesToChunks</a>;
<a class="l" name="178" href="#178">178</a>
<a class="l" name="179" href="#179">179</a>	<span class="c">//keyframe - sample numbers</span>
<a class="hl" name="180" href="#180">180</a>	<b>private</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt; <a class="xfld" name="syncSamples"/><a href="/source/s?refs=syncSamples&amp;project=rtmp_client" class="xfld">syncSamples</a>;
<a class="l" name="181" href="#181">181</a>
<a class="l" name="182" href="#182">182</a>	<span class="c">//samples</span>
<a class="l" name="183" href="#183">183</a>	<b>private</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt; <a class="xfld" name="videoSamples"/><a href="/source/s?refs=videoSamples&amp;project=rtmp_client" class="xfld">videoSamples</a>;
<a class="l" name="184" href="#184">184</a>
<a class="l" name="185" href="#185">185</a>	<b>private</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt; <a class="xfld" name="audioSamples"/><a href="/source/s?refs=audioSamples&amp;project=rtmp_client" class="xfld">audioSamples</a>;
<a class="l" name="186" href="#186">186</a>
<a class="l" name="187" href="#187">187</a>	<span class="c">//chunk offsets</span>
<a class="l" name="188" href="#188">188</a>	<b>private</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt; <a class="xfld" name="videoChunkOffsets"/><a href="/source/s?refs=videoChunkOffsets&amp;project=rtmp_client" class="xfld">videoChunkOffsets</a>;
<a class="l" name="189" href="#189">189</a>
<a class="hl" name="190" href="#190">190</a>	<b>private</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt; <a class="xfld" name="audioChunkOffsets"/><a href="/source/s?refs=audioChunkOffsets&amp;project=rtmp_client" class="xfld">audioChunkOffsets</a>;
<a class="l" name="191" href="#191">191</a>
<a class="l" name="192" href="#192">192</a>	<span class="c">//sample duration</span>
<a class="l" name="193" href="#193">193</a>	<b>private</b> <b>int</b> <a class="xfld" name="videoSampleDuration"/><a href="/source/s?refs=videoSampleDuration&amp;project=rtmp_client" class="xfld">videoSampleDuration</a> = <span class="n">125</span>;
<a class="l" name="194" href="#194">194</a>
<a class="l" name="195" href="#195">195</a>	<b>private</b> <b>int</b> <a class="xfld" name="audioSampleDuration"/><a href="/source/s?refs=audioSampleDuration&amp;project=rtmp_client" class="xfld">audioSampleDuration</a> = <span class="n">1024</span>;
<a class="l" name="196" href="#196">196</a>
<a class="l" name="197" href="#197">197</a>	<span class="c">//keep track of current frame / sample</span>
<a class="l" name="198" href="#198">198</a>	<b>private</b> <b>int</b> <a class="xfld" name="currentFrame"/><a href="/source/s?refs=currentFrame&amp;project=rtmp_client" class="xfld">currentFrame</a> = <span class="n">0</span>;
<a class="l" name="199" href="#199">199</a>
<a class="hl" name="200" href="#200">200</a>	<b>private</b> <b>int</b> <a class="xfld" name="prevFrameSize"/><a href="/source/s?refs=prevFrameSize&amp;project=rtmp_client" class="xfld">prevFrameSize</a> = <span class="n">0</span>;
<a class="l" name="201" href="#201">201</a>
<a class="l" name="202" href="#202">202</a>	<b>private</b> <b>int</b> <a class="xfld" name="prevVideoTS"/><a href="/source/s?refs=prevVideoTS&amp;project=rtmp_client" class="xfld">prevVideoTS</a> = -<span class="n">1</span>;
<a class="l" name="203" href="#203">203</a>
<a class="l" name="204" href="#204">204</a>	<b>private</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=MP4Frame&amp;project=rtmp_client">MP4Frame</a>&gt; <a class="xfld" name="frames"/><a href="/source/s?refs=frames&amp;project=rtmp_client" class="xfld">frames</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=MP4Frame&amp;project=rtmp_client">MP4Frame</a>&gt;();
<a class="l" name="205" href="#205">205</a>
<a class="l" name="206" href="#206">206</a>	<b>private</b> <b>long</b> <a class="xfld" name="audioCount"/><a href="/source/s?refs=audioCount&amp;project=rtmp_client" class="xfld">audioCount</a>;
<a class="l" name="207" href="#207">207</a>
<a class="l" name="208" href="#208">208</a>	<b>private</b> <b>long</b> <a class="xfld" name="videoCount"/><a href="/source/s?refs=videoCount&amp;project=rtmp_client" class="xfld">videoCount</a>;
<a class="l" name="209" href="#209">209</a>
<a class="hl" name="210" href="#210">210</a>	<span class="c">// composition time to sample entries</span>
<a class="l" name="211" href="#211">211</a>	<b>private</b> <a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=CompositionTimeSampleRecord&amp;project=rtmp_client">CompositionTimeSampleRecord</a>&gt; <a class="xfld" name="compositionTimes"/><a href="/source/s?refs=compositionTimes&amp;project=rtmp_client" class="xfld">compositionTimes</a>;
<a class="l" name="212" href="#212">212</a>
<a class="l" name="213" href="#213">213</a>	<span class="c">/**
<a class="l" name="214" href="#214">214</a>	 * Container for metadata and any other tags that should
<a class="l" name="215" href="#215">215</a>	 * be sent prior to media data.
<a class="l" name="216" href="#216">216</a>	 */</span>
<a class="l" name="217" href="#217">217</a>	<b>private</b> <a href="/source/s?defs=LinkedList&amp;project=rtmp_client">LinkedList</a>&lt;<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a>&gt; <a class="xfld" name="firstTags"/><a href="/source/s?refs=firstTags&amp;project=rtmp_client" class="xfld">firstTags</a> = <b>new</b> <a href="/source/s?defs=LinkedList&amp;project=rtmp_client">LinkedList</a>&lt;<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a>&gt;();
<a class="l" name="218" href="#218">218</a>
<a class="l" name="219" href="#219">219</a>	<span class="c">/**
<a class="hl" name="220" href="#220">220</a>	 * Container for seek points in the video. These are the time stamps
<a class="l" name="221" href="#221">221</a>	 * for the key frames.
<a class="l" name="222" href="#222">222</a>	 */</span>
<a class="l" name="223" href="#223">223</a>	<b>private</b> <a href="/source/s?defs=LinkedList&amp;project=rtmp_client">LinkedList</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt; <a class="xfld" name="seekPoints"/><a href="/source/s?refs=seekPoints&amp;project=rtmp_client" class="xfld">seekPoints</a>;
<a class="l" name="224" href="#224">224</a>
<a class="l" name="225" href="#225">225</a>	<span class="c">/** Constructs a new MP4Reader. */</span>
<a class="l" name="226" href="#226">226</a>	<a class="xmt" name="MP4Reader"/><a href="/source/s?refs=MP4Reader&amp;project=rtmp_client" class="xmt">MP4Reader</a>() {
<a class="l" name="227" href="#227">227</a>	}
<a class="l" name="228" href="#228">228</a>
<a class="l" name="229" href="#229">229</a>	<span class="c">/**
<a class="hl" name="230" href="#230">230</a>	 * Creates MP4 reader from file input stream, sets up metadata generation flag.
<a class="l" name="231" href="#231">231</a>	 *
<a class="l" name="232" href="#232">232</a>	 * <strong>@param</strong> f                    File input stream
<a class="l" name="233" href="#233">233</a>	 */</span>
<a class="l" name="234" href="#234">234</a>	<b>public</b> <a class="xmt" name="MP4Reader"/><a href="/source/s?refs=MP4Reader&amp;project=rtmp_client" class="xmt">MP4Reader</a>(<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> f) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="235" href="#235">235</a>		<b>if</b> (<a href="/source/s?defs=null&amp;project=rtmp_client">null</a> == f) {
<a class="l" name="236" href="#236">236</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Reader was passed a null file"</span>);
<a class="l" name="237" href="#237">237</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"{}"</span>, <a href="/source/s?defs=ToStringBuilder&amp;project=rtmp_client">ToStringBuilder</a>.<a href="/source/s?defs=reflectionToString&amp;project=rtmp_client">reflectionToString</a>(<b>this</b>));
<a class="l" name="238" href="#238">238</a>		}
<a class="l" name="239" href="#239">239</a>		<b>this</b>.<a class="d" href="#file">file</a> = f;
<a class="hl" name="240" href="#240">240</a>		<b>this</b>.<a class="d" href="#fis">fis</a> = <b>new</b> <a href="/source/s?defs=MP4DataStream&amp;project=rtmp_client">MP4DataStream</a>(<b>new</b> <a href="/source/s?defs=FileInputStream&amp;project=rtmp_client">FileInputStream</a>(f));
<a class="l" name="241" href="#241">241</a>		<a class="d" href="#channel">channel</a> = <a class="d" href="#fis">fis</a>.<a href="/source/s?defs=getChannel&amp;project=rtmp_client">getChannel</a>();
<a class="l" name="242" href="#242">242</a>		<span class="c">//decode all the info that we want from the atoms</span>
<a class="l" name="243" href="#243">243</a>		<a class="d" href="#decodeHeader">decodeHeader</a>();
<a class="l" name="244" href="#244">244</a>		<span class="c">//analyze the <a href="/source/s?path=samples/">samples</a>/<a href="/source/s?path=samples/chunks">chunks</a> and build the keyframe meta data</span>
<a class="l" name="245" href="#245">245</a>		<a class="d" href="#analyzeFrames">analyzeFrames</a>();
<a class="l" name="246" href="#246">246</a>		<span class="c">//add meta data</span>
<a class="l" name="247" href="#247">247</a>		<a class="d" href="#firstTags">firstTags</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a class="d" href="#createFileMeta">createFileMeta</a>());
<a class="l" name="248" href="#248">248</a>		<span class="c">//create / add the pre-streaming (decoder config) tags</span>
<a class="l" name="249" href="#249">249</a>		<a class="d" href="#createPreStreamingTags">createPreStreamingTags</a>(<span class="n">0</span>, <b>false</b>);
<a class="hl" name="250" href="#250">250</a>	}
<a class="l" name="251" href="#251">251</a>
<a class="l" name="252" href="#252">252</a>	<span class="c">/**
<a class="l" name="253" href="#253">253</a>	 * This handles the moov atom being at the beginning or end of the file, so the mdat may also
<a class="l" name="254" href="#254">254</a>	 * be before or after the moov atom.
<a class="l" name="255" href="#255">255</a>	 */</span>
<a class="l" name="256" href="#256">256</a>	<b>public</b> <b>void</b> <a class="xmt" name="decodeHeader"/><a href="/source/s?refs=decodeHeader&amp;project=rtmp_client" class="xmt">decodeHeader</a>() {
<a class="l" name="257" href="#257">257</a>		<b>try</b> {
<a class="l" name="258" href="#258">258</a>			<span class="c">// the first atom <a href="/source/s?path=will/">will</a>/<a href="/source/s?path=will/should">should</a> be the type</span>
<a class="l" name="259" href="#259">259</a>			<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=createAtom&amp;project=rtmp_client">createAtom</a>(<a class="d" href="#fis">fis</a>);
<a class="hl" name="260" href="#260">260</a>			<span class="c">// expect ftyp</span>
<a class="l" name="261" href="#261">261</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Type {}"</span>, <a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=intToType&amp;project=rtmp_client">intToType</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>.<a href="/source/s?defs=getType&amp;project=rtmp_client">getType</a>()));
<a class="l" name="262" href="#262">262</a>			<span class="c">//log.debug("Atom int types - free={} wide={}", MP4Atom.typeToInt("free"), MP4Atom.typeToInt("wide"));</span>
<a class="l" name="263" href="#263">263</a>			<span class="c">// keep a running count of the number of atoms found at the "top" levels</span>
<a class="l" name="264" href="#264">264</a>			<b>int</b> <a href="/source/s?defs=topAtoms&amp;project=rtmp_client">topAtoms</a> = <span class="n">0</span>;
<a class="l" name="265" href="#265">265</a>			<span class="c">// we want a moov and an mdat, anything else throw the invalid file type error</span>
<a class="l" name="266" href="#266">266</a>			<b>while</b> (<a href="/source/s?defs=topAtoms&amp;project=rtmp_client">topAtoms</a> &lt; <span class="n">2</span>) {
<a class="l" name="267" href="#267">267</a>				<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a> = <a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=createAtom&amp;project=rtmp_client">createAtom</a>(<a class="d" href="#fis">fis</a>);
<a class="l" name="268" href="#268">268</a>				<b>switch</b> (<a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a href="/source/s?defs=getType&amp;project=rtmp_client">getType</a>()) {
<a class="l" name="269" href="#269">269</a>					<b>case</b> <span class="n">1836019574</span>: <span class="c">//moov</span>
<a class="hl" name="270" href="#270">270</a>						<a href="/source/s?defs=topAtoms&amp;project=rtmp_client">topAtoms</a>++;
<a class="l" name="271" href="#271">271</a>						<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=moov&amp;project=rtmp_client">moov</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>;
<a class="l" name="272" href="#272">272</a>						<span class="c">// expect moov</span>
<a class="l" name="273" href="#273">273</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Type {}"</span>, <a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=intToType&amp;project=rtmp_client">intToType</a>(<a href="/source/s?defs=moov&amp;project=rtmp_client">moov</a>.<a href="/source/s?defs=getType&amp;project=rtmp_client">getType</a>()));
<a class="l" name="274" href="#274">274</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"moov children: {}"</span>, <a href="/source/s?defs=moov&amp;project=rtmp_client">moov</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>());
<a class="l" name="275" href="#275">275</a>						<a class="d" href="#moovOffset">moovOffset</a> = <a class="d" href="#fis">fis</a>.<a class="d" href="#getOffset">getOffset</a>() - <a href="/source/s?defs=moov&amp;project=rtmp_client">moov</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>();
<a class="l" name="276" href="#276">276</a>
<a class="l" name="277" href="#277">277</a>						<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=mvhd&amp;project=rtmp_client">mvhd</a> = <a href="/source/s?defs=moov&amp;project=rtmp_client">moov</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"mvhd"</span>), <span class="n">0</span>);
<a class="l" name="278" href="#278">278</a>						<b>if</b> (<a href="/source/s?defs=mvhd&amp;project=rtmp_client">mvhd</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="279" href="#279">279</a>							<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Movie header atom found"</span>);
<a class="hl" name="280" href="#280">280</a>							<span class="c">//get the initial timescale</span>
<a class="l" name="281" href="#281">281</a>							<a class="d" href="#timeScale">timeScale</a> = <a href="/source/s?defs=mvhd&amp;project=rtmp_client">mvhd</a>.<a href="/source/s?defs=getTimeScale&amp;project=rtmp_client">getTimeScale</a>();
<a class="l" name="282" href="#282">282</a>							<a class="d" href="#duration">duration</a> = <a href="/source/s?defs=mvhd&amp;project=rtmp_client">mvhd</a>.<a class="d" href="#getDuration">getDuration</a>();
<a class="l" name="283" href="#283">283</a>							<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Time scale {} Duration {}"</span>, <a class="d" href="#timeScale">timeScale</a>, <a class="d" href="#duration">duration</a>);
<a class="l" name="284" href="#284">284</a>						}
<a class="l" name="285" href="#285">285</a>
<a class="l" name="286" href="#286">286</a>						<span class="c">/* nothing needed here yet
<a class="l" name="287" href="#287">287</a>						MP4Atom meta = moov.lookup(MP4Atom.typeToInt("meta"), 0);
<a class="l" name="288" href="#288">288</a>						if (meta != null) {
<a class="l" name="289" href="#289">289</a>							log.debug("Meta atom found");
<a class="hl" name="290" href="#290">290</a>							log.debug("{}", ToStringBuilder.reflectionToString(meta));
<a class="l" name="291" href="#291">291</a>						}
<a class="l" name="292" href="#292">292</a>						*/</span>
<a class="l" name="293" href="#293">293</a>
<a class="l" name="294" href="#294">294</a>						<span class="c">//we would like to have two tracks, but it shouldn't be a requirement</span>
<a class="l" name="295" href="#295">295</a>						<b>int</b> <a href="/source/s?defs=loops&amp;project=rtmp_client">loops</a> = <span class="n">0</span>;
<a class="l" name="296" href="#296">296</a>						<b>int</b> <a href="/source/s?defs=tracks&amp;project=rtmp_client">tracks</a> = <span class="n">0</span>;
<a class="l" name="297" href="#297">297</a>						<b>do</b> {
<a class="l" name="298" href="#298">298</a>
<a class="l" name="299" href="#299">299</a>							<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=trak&amp;project=rtmp_client">trak</a> = <a href="/source/s?defs=moov&amp;project=rtmp_client">moov</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"trak"</span>), <a href="/source/s?defs=loops&amp;project=rtmp_client">loops</a>);
<a class="hl" name="300" href="#300">300</a>							<b>if</b> (<a href="/source/s?defs=trak&amp;project=rtmp_client">trak</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="301" href="#301">301</a>								<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Track atom found"</span>);
<a class="l" name="302" href="#302">302</a>								<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"trak children: {}"</span>, <a href="/source/s?defs=trak&amp;project=rtmp_client">trak</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>());
<a class="l" name="303" href="#303">303</a>								<span class="c">// trak: tkhd, edts, mdia</span>
<a class="l" name="304" href="#304">304</a>								<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=tkhd&amp;project=rtmp_client">tkhd</a> = <a href="/source/s?defs=trak&amp;project=rtmp_client">trak</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"tkhd"</span>), <span class="n">0</span>);
<a class="l" name="305" href="#305">305</a>								<b>if</b> (<a href="/source/s?defs=tkhd&amp;project=rtmp_client">tkhd</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="306" href="#306">306</a>									<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Track header atom found"</span>);
<a class="l" name="307" href="#307">307</a>									<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"tkhd children: {}"</span>, <a href="/source/s?defs=tkhd&amp;project=rtmp_client">tkhd</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>());
<a class="l" name="308" href="#308">308</a>									<b>if</b> (<a href="/source/s?defs=tkhd&amp;project=rtmp_client">tkhd</a>.<a href="/source/s?defs=getWidth&amp;project=rtmp_client">getWidth</a>() &gt; <span class="n">0</span>) {
<a class="l" name="309" href="#309">309</a>										<a class="d" href="#width">width</a> = <a href="/source/s?defs=tkhd&amp;project=rtmp_client">tkhd</a>.<a href="/source/s?defs=getWidth&amp;project=rtmp_client">getWidth</a>();
<a class="hl" name="310" href="#310">310</a>										<a class="d" href="#height">height</a> = <a href="/source/s?defs=tkhd&amp;project=rtmp_client">tkhd</a>.<a href="/source/s?defs=getHeight&amp;project=rtmp_client">getHeight</a>();
<a class="l" name="311" href="#311">311</a>										<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Width {} x Height {}"</span>, <a class="d" href="#width">width</a>, <a class="d" href="#height">height</a>);
<a class="l" name="312" href="#312">312</a>									}
<a class="l" name="313" href="#313">313</a>								}
<a class="l" name="314" href="#314">314</a>
<a class="l" name="315" href="#315">315</a>								<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=edts&amp;project=rtmp_client">edts</a> = <a href="/source/s?defs=trak&amp;project=rtmp_client">trak</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"edts"</span>), <span class="n">0</span>);
<a class="l" name="316" href="#316">316</a>								<b>if</b> (<a href="/source/s?defs=edts&amp;project=rtmp_client">edts</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="317" href="#317">317</a>									<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Edit atom found"</span>);
<a class="l" name="318" href="#318">318</a>									<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"edts children: {}"</span>, <a href="/source/s?defs=edts&amp;project=rtmp_client">edts</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>());
<a class="l" name="319" href="#319">319</a>									<span class="c">//log.debug("Width {} x Height {}", edts.getWidth(), edts.getHeight());</span>
<a class="hl" name="320" href="#320">320</a>								}
<a class="l" name="321" href="#321">321</a>
<a class="l" name="322" href="#322">322</a>								<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=mdia&amp;project=rtmp_client">mdia</a> = <a href="/source/s?defs=trak&amp;project=rtmp_client">trak</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"mdia"</span>), <span class="n">0</span>);
<a class="l" name="323" href="#323">323</a>								<b>if</b> (<a href="/source/s?defs=mdia&amp;project=rtmp_client">mdia</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="324" href="#324">324</a>									<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Media atom found"</span>);
<a class="l" name="325" href="#325">325</a>									<span class="c">// mdia: mdhd, hdlr, minf</span>
<a class="l" name="326" href="#326">326</a>
<a class="l" name="327" href="#327">327</a>									<b>int</b> <a href="/source/s?defs=scale&amp;project=rtmp_client">scale</a> = <span class="n">0</span>;
<a class="l" name="328" href="#328">328</a>									<span class="c">//get the media header atom</span>
<a class="l" name="329" href="#329">329</a>									<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=mdhd&amp;project=rtmp_client">mdhd</a> = <a href="/source/s?defs=mdia&amp;project=rtmp_client">mdia</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"mdhd"</span>), <span class="n">0</span>);
<a class="hl" name="330" href="#330">330</a>									<b>if</b> (<a href="/source/s?defs=mdhd&amp;project=rtmp_client">mdhd</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="331" href="#331">331</a>										<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Media data header atom found"</span>);
<a class="l" name="332" href="#332">332</a>										<span class="c">//this will be for either video or audio depending media info</span>
<a class="l" name="333" href="#333">333</a>										<a href="/source/s?defs=scale&amp;project=rtmp_client">scale</a> = <a href="/source/s?defs=mdhd&amp;project=rtmp_client">mdhd</a>.<a href="/source/s?defs=getTimeScale&amp;project=rtmp_client">getTimeScale</a>();
<a class="l" name="334" href="#334">334</a>										<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Time scale {}"</span>, <a href="/source/s?defs=scale&amp;project=rtmp_client">scale</a>);
<a class="l" name="335" href="#335">335</a>									}
<a class="l" name="336" href="#336">336</a>
<a class="l" name="337" href="#337">337</a>									<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=hdlr&amp;project=rtmp_client">hdlr</a> = <a href="/source/s?defs=mdia&amp;project=rtmp_client">mdia</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"hdlr"</span>), <span class="n">0</span>);
<a class="l" name="338" href="#338">338</a>									<b>if</b> (<a href="/source/s?defs=hdlr&amp;project=rtmp_client">hdlr</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="339" href="#339">339</a>										<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Handler ref atom found"</span>);
<a class="hl" name="340" href="#340">340</a>										<span class="c">// soun or vide</span>
<a class="l" name="341" href="#341">341</a>										<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Handler type: {}"</span>, <a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=intToType&amp;project=rtmp_client">intToType</a>(<a href="/source/s?defs=hdlr&amp;project=rtmp_client">hdlr</a>.<a href="/source/s?defs=getHandlerType&amp;project=rtmp_client">getHandlerType</a>()));
<a class="l" name="342" href="#342">342</a>										<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=hdlrType&amp;project=rtmp_client">hdlrType</a> = <a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=intToType&amp;project=rtmp_client">intToType</a>(<a href="/source/s?defs=hdlr&amp;project=rtmp_client">hdlr</a>.<a href="/source/s?defs=getHandlerType&amp;project=rtmp_client">getHandlerType</a>());
<a class="l" name="343" href="#343">343</a>										<b>if</b> (<span class="s">"vide"</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=hdlrType&amp;project=rtmp_client">hdlrType</a>)) {
<a class="l" name="344" href="#344">344</a>											<a href="/source/s?defs=hasVideo&amp;project=rtmp_client">hasVideo</a> = <b>true</b>;
<a class="l" name="345" href="#345">345</a>											<b>if</b> (<a href="/source/s?defs=scale&amp;project=rtmp_client">scale</a> &gt; <span class="n">0</span>) {
<a class="l" name="346" href="#346">346</a>												<a class="d" href="#videoTimeScale">videoTimeScale</a> = <a href="/source/s?defs=scale&amp;project=rtmp_client">scale</a> * <span class="n">1.0</span>;
<a class="l" name="347" href="#347">347</a>												<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Video time scale: {}"</span>, <a class="d" href="#videoTimeScale">videoTimeScale</a>);
<a class="l" name="348" href="#348">348</a>											}
<a class="l" name="349" href="#349">349</a>										} <b>else</b> <b>if</b> (<span class="s">"soun"</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=hdlrType&amp;project=rtmp_client">hdlrType</a>)) {
<a class="hl" name="350" href="#350">350</a>											<a class="d" href="#hasAudio">hasAudio</a> = <b>true</b>;
<a class="l" name="351" href="#351">351</a>											<b>if</b> (<a href="/source/s?defs=scale&amp;project=rtmp_client">scale</a> &gt; <span class="n">0</span>) {
<a class="l" name="352" href="#352">352</a>												<a class="d" href="#audioTimeScale">audioTimeScale</a> = <a href="/source/s?defs=scale&amp;project=rtmp_client">scale</a> * <span class="n">1.0</span>;
<a class="l" name="353" href="#353">353</a>												<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Audio time scale: {}"</span>, <a class="d" href="#audioTimeScale">audioTimeScale</a>);
<a class="l" name="354" href="#354">354</a>											}
<a class="l" name="355" href="#355">355</a>										}
<a class="l" name="356" href="#356">356</a>										<a href="/source/s?defs=tracks&amp;project=rtmp_client">tracks</a>++;
<a class="l" name="357" href="#357">357</a>									}
<a class="l" name="358" href="#358">358</a>
<a class="l" name="359" href="#359">359</a>									<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=minf&amp;project=rtmp_client">minf</a> = <a href="/source/s?defs=mdia&amp;project=rtmp_client">mdia</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"minf"</span>), <span class="n">0</span>);
<a class="hl" name="360" href="#360">360</a>									<b>if</b> (<a href="/source/s?defs=minf&amp;project=rtmp_client">minf</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="361" href="#361">361</a>										<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Media info atom found"</span>);
<a class="l" name="362" href="#362">362</a>										<span class="c">// minf: (audio) smhd, dinf, stbl / (video) vmhd,</span>
<a class="l" name="363" href="#363">363</a>										<span class="c">// dinf, stbl</span>
<a class="l" name="364" href="#364">364</a>
<a class="l" name="365" href="#365">365</a>										<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=smhd&amp;project=rtmp_client">smhd</a> = <a href="/source/s?defs=minf&amp;project=rtmp_client">minf</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"smhd"</span>), <span class="n">0</span>);
<a class="l" name="366" href="#366">366</a>										<b>if</b> (<a href="/source/s?defs=smhd&amp;project=rtmp_client">smhd</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="367" href="#367">367</a>											<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sound header atom found"</span>);
<a class="l" name="368" href="#368">368</a>											<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=dinf&amp;project=rtmp_client">dinf</a> = <a href="/source/s?defs=minf&amp;project=rtmp_client">minf</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"dinf"</span>), <span class="n">0</span>);
<a class="l" name="369" href="#369">369</a>											<b>if</b> (<a href="/source/s?defs=dinf&amp;project=rtmp_client">dinf</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="370" href="#370">370</a>												<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Data info atom found"</span>);
<a class="l" name="371" href="#371">371</a>												<span class="c">// dinf: dref</span>
<a class="l" name="372" href="#372">372</a>												<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sound dinf children: {}"</span>, <a href="/source/s?defs=dinf&amp;project=rtmp_client">dinf</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>());
<a class="l" name="373" href="#373">373</a>												<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=dref&amp;project=rtmp_client">dref</a> = <a href="/source/s?defs=dinf&amp;project=rtmp_client">dinf</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"dref"</span>), <span class="n">0</span>);
<a class="l" name="374" href="#374">374</a>												<b>if</b> (<a href="/source/s?defs=dref&amp;project=rtmp_client">dref</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="375" href="#375">375</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Data reference atom found"</span>);
<a class="l" name="376" href="#376">376</a>												}
<a class="l" name="377" href="#377">377</a>
<a class="l" name="378" href="#378">378</a>											}
<a class="l" name="379" href="#379">379</a>											<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a> = <a href="/source/s?defs=minf&amp;project=rtmp_client">minf</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"stbl"</span>), <span class="n">0</span>);
<a class="hl" name="380" href="#380">380</a>											<b>if</b> (<a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="381" href="#381">381</a>												<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sample table atom found"</span>);
<a class="l" name="382" href="#382">382</a>												<span class="c">// stbl: stsd, stts, stss, stsc, stsz, stco,</span>
<a class="l" name="383" href="#383">383</a>												<span class="c">// stsh</span>
<a class="l" name="384" href="#384">384</a>												<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sound stbl children: {}"</span>, <a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>());
<a class="l" name="385" href="#385">385</a>												<span class="c">// stsd - sample description</span>
<a class="l" name="386" href="#386">386</a>												<span class="c">// stts - time to sample</span>
<a class="l" name="387" href="#387">387</a>												<span class="c">// stsc - sample to chunk</span>
<a class="l" name="388" href="#388">388</a>												<span class="c">// stsz - sample size</span>
<a class="l" name="389" href="#389">389</a>												<span class="c">// stco - chunk offset</span>
<a class="hl" name="390" href="#390">390</a>
<a class="l" name="391" href="#391">391</a>												<span class="c">//stsd - has codec child</span>
<a class="l" name="392" href="#392">392</a>												<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=stsd&amp;project=rtmp_client">stsd</a> = <a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"stsd"</span>), <span class="n">0</span>);
<a class="l" name="393" href="#393">393</a>												<b>if</b> (<a href="/source/s?defs=stsd&amp;project=rtmp_client">stsd</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="394" href="#394">394</a>													<span class="c">//stsd: mp4a</span>
<a class="l" name="395" href="#395">395</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sample description atom found"</span>);
<a class="l" name="396" href="#396">396</a>													<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=mp4a&amp;project=rtmp_client">mp4a</a> = <a href="/source/s?defs=stsd&amp;project=rtmp_client">stsd</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>().<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<span class="n">0</span>);
<a class="l" name="397" href="#397">397</a>													<span class="c">//could set the audio codec here</span>
<a class="l" name="398" href="#398">398</a>													<a class="d" href="#setAudioCodecId">setAudioCodecId</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=intToType&amp;project=rtmp_client">intToType</a>(<a href="/source/s?defs=mp4a&amp;project=rtmp_client">mp4a</a>.<a href="/source/s?defs=getType&amp;project=rtmp_client">getType</a>()));
<a class="l" name="399" href="#399">399</a>													<span class="c">//log.debug("{}", ToStringBuilder.reflectionToString(mp4a));</span>
<a class="hl" name="400" href="#400">400</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sample size: {}"</span>, <a href="/source/s?defs=mp4a&amp;project=rtmp_client">mp4a</a>.<a href="/source/s?defs=getSampleSize&amp;project=rtmp_client">getSampleSize</a>());
<a class="l" name="401" href="#401">401</a>													<b>int</b> <a href="/source/s?defs=ats&amp;project=rtmp_client">ats</a> = <a href="/source/s?defs=mp4a&amp;project=rtmp_client">mp4a</a>.<a href="/source/s?defs=getTimeScale&amp;project=rtmp_client">getTimeScale</a>();
<a class="l" name="402" href="#402">402</a>													<span class="c">//skip invalid audio time scale</span>
<a class="l" name="403" href="#403">403</a>													<b>if</b> (<a href="/source/s?defs=ats&amp;project=rtmp_client">ats</a> &gt; <span class="n">0</span>) {
<a class="l" name="404" href="#404">404</a>														<a class="d" href="#audioTimeScale">audioTimeScale</a> = <a href="/source/s?defs=ats&amp;project=rtmp_client">ats</a> * <span class="n">1.0</span>;
<a class="l" name="405" href="#405">405</a>													}
<a class="l" name="406" href="#406">406</a>													<a class="d" href="#audioChannels">audioChannels</a> = <a href="/source/s?defs=mp4a&amp;project=rtmp_client">mp4a</a>.<a href="/source/s?defs=getChannelCount&amp;project=rtmp_client">getChannelCount</a>();
<a class="l" name="407" href="#407">407</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sample rate (audio time scale): {}"</span>, <a class="d" href="#audioTimeScale">audioTimeScale</a>);
<a class="l" name="408" href="#408">408</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Channels: {}"</span>, <a class="d" href="#audioChannels">audioChannels</a>);
<a class="l" name="409" href="#409">409</a>													<span class="c">//mp4a: esds</span>
<a class="hl" name="410" href="#410">410</a>													<b>if</b> (<a href="/source/s?defs=mp4a&amp;project=rtmp_client">mp4a</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>().<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>() &gt; <span class="n">0</span>) {
<a class="l" name="411" href="#411">411</a>														<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Elementary stream descriptor atom found"</span>);
<a class="l" name="412" href="#412">412</a>														<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=esds&amp;project=rtmp_client">esds</a> = <a href="/source/s?defs=mp4a&amp;project=rtmp_client">mp4a</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>().<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<span class="n">0</span>);
<a class="l" name="413" href="#413">413</a>														<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"{}"</span>, <a href="/source/s?defs=ToStringBuilder&amp;project=rtmp_client">ToStringBuilder</a>.<a href="/source/s?defs=reflectionToString&amp;project=rtmp_client">reflectionToString</a>(<a href="/source/s?defs=esds&amp;project=rtmp_client">esds</a>));
<a class="l" name="414" href="#414">414</a>														<a href="/source/s?defs=MP4Descriptor&amp;project=rtmp_client">MP4Descriptor</a> <a href="/source/s?defs=descriptor&amp;project=rtmp_client">descriptor</a> = <a href="/source/s?defs=esds&amp;project=rtmp_client">esds</a>.<a href="/source/s?defs=getEsd_descriptor&amp;project=rtmp_client">getEsd_descriptor</a>();
<a class="l" name="415" href="#415">415</a>														<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"{}"</span>, <a href="/source/s?defs=ToStringBuilder&amp;project=rtmp_client">ToStringBuilder</a>.<a href="/source/s?defs=reflectionToString&amp;project=rtmp_client">reflectionToString</a>(<a href="/source/s?defs=descriptor&amp;project=rtmp_client">descriptor</a>));
<a class="l" name="416" href="#416">416</a>														<b>if</b> (<a href="/source/s?defs=descriptor&amp;project=rtmp_client">descriptor</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="417" href="#417">417</a>															<a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=MP4Descriptor&amp;project=rtmp_client">MP4Descriptor</a>&gt; <a href="/source/s?defs=children&amp;project=rtmp_client">children</a> = <a href="/source/s?defs=descriptor&amp;project=rtmp_client">descriptor</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>();
<a class="l" name="418" href="#418">418</a>															<b>for</b> (<b>int</b> e = <span class="n">0</span>; e &lt; <a href="/source/s?defs=children&amp;project=rtmp_client">children</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>(); e++) {
<a class="l" name="419" href="#419">419</a>																<a href="/source/s?defs=MP4Descriptor&amp;project=rtmp_client">MP4Descriptor</a> <a href="/source/s?defs=descr&amp;project=rtmp_client">descr</a> = <a href="/source/s?defs=children&amp;project=rtmp_client">children</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(e);
<a class="hl" name="420" href="#420">420</a>																<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"{}"</span>, <a href="/source/s?defs=ToStringBuilder&amp;project=rtmp_client">ToStringBuilder</a>.<a href="/source/s?defs=reflectionToString&amp;project=rtmp_client">reflectionToString</a>(<a href="/source/s?defs=descr&amp;project=rtmp_client">descr</a>));
<a class="l" name="421" href="#421">421</a>																<b>if</b> (<a href="/source/s?defs=descr&amp;project=rtmp_client">descr</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>().<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>() &gt; <span class="n">0</span>) {
<a class="l" name="422" href="#422">422</a>																	<a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=MP4Descriptor&amp;project=rtmp_client">MP4Descriptor</a>&gt; <a href="/source/s?defs=children2&amp;project=rtmp_client">children2</a> = <a href="/source/s?defs=descr&amp;project=rtmp_client">descr</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>();
<a class="l" name="423" href="#423">423</a>																	<b>for</b> (<b>int</b> <a href="/source/s?defs=e2&amp;project=rtmp_client">e2</a> = <span class="n">0</span>; <a href="/source/s?defs=e2&amp;project=rtmp_client">e2</a> &lt; <a href="/source/s?defs=children2&amp;project=rtmp_client">children2</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>(); <a href="/source/s?defs=e2&amp;project=rtmp_client">e2</a>++) {
<a class="l" name="424" href="#424">424</a>																		<a href="/source/s?defs=MP4Descriptor&amp;project=rtmp_client">MP4Descriptor</a> <a href="/source/s?defs=descr2&amp;project=rtmp_client">descr2</a> = <a href="/source/s?defs=children2&amp;project=rtmp_client">children2</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=e2&amp;project=rtmp_client">e2</a>);
<a class="l" name="425" href="#425">425</a>																		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"{}"</span>, <a href="/source/s?defs=ToStringBuilder&amp;project=rtmp_client">ToStringBuilder</a>.<a href="/source/s?defs=reflectionToString&amp;project=rtmp_client">reflectionToString</a>(<a href="/source/s?defs=descr2&amp;project=rtmp_client">descr2</a>));
<a class="l" name="426" href="#426">426</a>																		<b>if</b> (<a href="/source/s?defs=descr2&amp;project=rtmp_client">descr2</a>.<a href="/source/s?defs=getType&amp;project=rtmp_client">getType</a>() == <a href="/source/s?defs=MP4Descriptor&amp;project=rtmp_client">MP4Descriptor</a>.<a href="/source/s?defs=MP4DecSpecificInfoDescriptorTag&amp;project=rtmp_client">MP4DecSpecificInfoDescriptorTag</a>) {
<a class="l" name="427" href="#427">427</a>																			<span class="c">//we only want the MP4DecSpecificInfoDescriptorTag</span>
<a class="l" name="428" href="#428">428</a>																			<a class="d" href="#audioDecoderBytes">audioDecoderBytes</a> = <a href="/source/s?defs=descr2&amp;project=rtmp_client">descr2</a>.<a href="/source/s?defs=getDSID&amp;project=rtmp_client">getDSID</a>();
<a class="l" name="429" href="#429">429</a>																			<span class="c">//compare the bytes to get the <a href="/source/s?path=aacaot/">aacaot</a>/<a href="/source/s?path=aacaot/aottype">aottype</a></span>
<a class="hl" name="430" href="#430">430</a>																			<span class="c">//match first byte</span>
<a class="l" name="431" href="#431">431</a>																			<b>switch</b> (<a class="d" href="#audioDecoderBytes">audioDecoderBytes</a>[<span class="n">0</span>]) {
<a class="l" name="432" href="#432">432</a>																				<b>case</b> <span class="n">0x12</span>:
<a class="l" name="433" href="#433">433</a>																				<b>default</b>:
<a class="l" name="434" href="#434">434</a>																					<span class="c">//AAC LC - 12 10</span>
<a class="l" name="435" href="#435">435</a>																					<a class="d" href="#audioCodecType">audioCodecType</a> = <span class="n">1</span>;
<a class="l" name="436" href="#436">436</a>																					<b>break</b>;
<a class="l" name="437" href="#437">437</a>																				<b>case</b> <span class="n">0x0a</span>:
<a class="l" name="438" href="#438">438</a>																					<span class="c">//AAC Main - 0A 10</span>
<a class="l" name="439" href="#439">439</a>																					<a class="d" href="#audioCodecType">audioCodecType</a> = <span class="n">0</span>;
<a class="hl" name="440" href="#440">440</a>																					<b>break</b>;
<a class="l" name="441" href="#441">441</a>																				<b>case</b> <span class="n">0x11</span>:
<a class="l" name="442" href="#442">442</a>																				<b>case</b> <span class="n">0x13</span>:
<a class="l" name="443" href="#443">443</a>																					<span class="c">//AAC LC SBR - 11 90 &amp; 13 xx</span>
<a class="l" name="444" href="#444">444</a>																					<a class="d" href="#audioCodecType">audioCodecType</a> = <span class="n">2</span>;
<a class="l" name="445" href="#445">445</a>																					<b>break</b>;
<a class="l" name="446" href="#446">446</a>																			}
<a class="l" name="447" href="#447">447</a>																			<span class="c">//we want to break out of top level for loop</span>
<a class="l" name="448" href="#448">448</a>																			e = <span class="n">99</span>;
<a class="l" name="449" href="#449">449</a>																			<b>break</b>;
<a class="hl" name="450" href="#450">450</a>																		}
<a class="l" name="451" href="#451">451</a>																	}
<a class="l" name="452" href="#452">452</a>																}
<a class="l" name="453" href="#453">453</a>															}
<a class="l" name="454" href="#454">454</a>														}
<a class="l" name="455" href="#455">455</a>													}
<a class="l" name="456" href="#456">456</a>												}
<a class="l" name="457" href="#457">457</a>												<span class="c">//stsc - has Records</span>
<a class="l" name="458" href="#458">458</a>												<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=stsc&amp;project=rtmp_client">stsc</a> = <a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"stsc"</span>), <span class="n">0</span>);
<a class="l" name="459" href="#459">459</a>												<b>if</b> (<a href="/source/s?defs=stsc&amp;project=rtmp_client">stsc</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="460" href="#460">460</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sample to chunk atom found"</span>);
<a class="l" name="461" href="#461">461</a>													<a class="d" href="#audioSamplesToChunks">audioSamplesToChunks</a> = <a href="/source/s?defs=stsc&amp;project=rtmp_client">stsc</a>.<a href="/source/s?defs=getRecords&amp;project=rtmp_client">getRecords</a>();
<a class="l" name="462" href="#462">462</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Record count: {}"</span>, <a class="d" href="#audioSamplesToChunks">audioSamplesToChunks</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>());
<a class="l" name="463" href="#463">463</a>													<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=Record&amp;project=rtmp_client">Record</a> <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a> = <a class="d" href="#audioSamplesToChunks">audioSamplesToChunks</a>.<a href="/source/s?defs=firstElement&amp;project=rtmp_client">firstElement</a>();
<a class="l" name="464" href="#464">464</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Record data: Description index={} Samples per chunk={}"</span>, <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a>.<a href="/source/s?defs=getSampleDescriptionIndex&amp;project=rtmp_client">getSampleDescriptionIndex</a>(), <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a>.<a href="/source/s?defs=getSamplesPerChunk&amp;project=rtmp_client">getSamplesPerChunk</a>());
<a class="l" name="465" href="#465">465</a>												}
<a class="l" name="466" href="#466">466</a>												<span class="c">//stsz - has Samples</span>
<a class="l" name="467" href="#467">467</a>												<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=stsz&amp;project=rtmp_client">stsz</a> = <a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"stsz"</span>), <span class="n">0</span>);
<a class="l" name="468" href="#468">468</a>												<b>if</b> (<a href="/source/s?defs=stsz&amp;project=rtmp_client">stsz</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="469" href="#469">469</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sample size atom found"</span>);
<a class="hl" name="470" href="#470">470</a>													<a class="d" href="#audioSamples">audioSamples</a> = <a href="/source/s?defs=stsz&amp;project=rtmp_client">stsz</a>.<a href="/source/s?defs=getSamples&amp;project=rtmp_client">getSamples</a>();
<a class="l" name="471" href="#471">471</a>													<span class="c">//vector full of integers</span>
<a class="l" name="472" href="#472">472</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sample size: {}"</span>, <a href="/source/s?defs=stsz&amp;project=rtmp_client">stsz</a>.<a href="/source/s?defs=getSampleSize&amp;project=rtmp_client">getSampleSize</a>());
<a class="l" name="473" href="#473">473</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sample count: {}"</span>, <a class="d" href="#audioSamples">audioSamples</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>());
<a class="l" name="474" href="#474">474</a>												}
<a class="l" name="475" href="#475">475</a>												<span class="c">//stco - has Chunks</span>
<a class="l" name="476" href="#476">476</a>												<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=stco&amp;project=rtmp_client">stco</a> = <a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"stco"</span>), <span class="n">0</span>);
<a class="l" name="477" href="#477">477</a>												<b>if</b> (<a href="/source/s?defs=stco&amp;project=rtmp_client">stco</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="478" href="#478">478</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Chunk offset atom found"</span>);
<a class="l" name="479" href="#479">479</a>													<span class="c">//vector full of integers</span>
<a class="hl" name="480" href="#480">480</a>													<a class="d" href="#audioChunkOffsets">audioChunkOffsets</a> = <a href="/source/s?defs=stco&amp;project=rtmp_client">stco</a>.<a href="/source/s?defs=getChunks&amp;project=rtmp_client">getChunks</a>();
<a class="l" name="481" href="#481">481</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Chunk count: {}"</span>, <a class="d" href="#audioChunkOffsets">audioChunkOffsets</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>());
<a class="l" name="482" href="#482">482</a>												}
<a class="l" name="483" href="#483">483</a>												<span class="c">//stts - has TimeSampleRecords</span>
<a class="l" name="484" href="#484">484</a>												<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=stts&amp;project=rtmp_client">stts</a> = <a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"stts"</span>), <span class="n">0</span>);
<a class="l" name="485" href="#485">485</a>												<b>if</b> (<a href="/source/s?defs=stts&amp;project=rtmp_client">stts</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="486" href="#486">486</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Time to sample atom found"</span>);
<a class="l" name="487" href="#487">487</a>													<a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=TimeSampleRecord&amp;project=rtmp_client">TimeSampleRecord</a>&gt; <a href="/source/s?defs=records&amp;project=rtmp_client">records</a> = <a href="/source/s?defs=stts&amp;project=rtmp_client">stts</a>.<a href="/source/s?defs=getTimeToSamplesRecords&amp;project=rtmp_client">getTimeToSamplesRecords</a>();
<a class="l" name="488" href="#488">488</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Record count: {}"</span>, <a href="/source/s?defs=records&amp;project=rtmp_client">records</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>());
<a class="l" name="489" href="#489">489</a>													<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=TimeSampleRecord&amp;project=rtmp_client">TimeSampleRecord</a> <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a> = <a href="/source/s?defs=records&amp;project=rtmp_client">records</a>.<a href="/source/s?defs=firstElement&amp;project=rtmp_client">firstElement</a>();
<a class="hl" name="490" href="#490">490</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Record data: Consecutive samples={} Duration={}"</span>, <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a>.<a href="/source/s?defs=getConsecutiveSamples&amp;project=rtmp_client">getConsecutiveSamples</a>(), <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a>.<a href="/source/s?defs=getSampleDuration&amp;project=rtmp_client">getSampleDuration</a>());
<a class="l" name="491" href="#491">491</a>													<span class="c">//if we have 1 record then all samples have the same duration</span>
<a class="l" name="492" href="#492">492</a>													<b>if</b> (<a href="/source/s?defs=records&amp;project=rtmp_client">records</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>() &gt; <span class="n">1</span>) {
<a class="l" name="493" href="#493">493</a>														<span class="c">//TODO: handle audio samples with varying durations</span>
<a class="l" name="494" href="#494">494</a>														<a class="d" href="#log">log</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"Audio samples have differing durations, audio playback may fail"</span>);
<a class="l" name="495" href="#495">495</a>													}
<a class="l" name="496" href="#496">496</a>													<a class="d" href="#audioSampleDuration">audioSampleDuration</a> = <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a>.<a href="/source/s?defs=getSampleDuration&amp;project=rtmp_client">getSampleDuration</a>();
<a class="l" name="497" href="#497">497</a>												}
<a class="l" name="498" href="#498">498</a>											}
<a class="l" name="499" href="#499">499</a>										}
<a class="hl" name="500" href="#500">500</a>										<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=vmhd&amp;project=rtmp_client">vmhd</a> = <a href="/source/s?defs=minf&amp;project=rtmp_client">minf</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"vmhd"</span>), <span class="n">0</span>);
<a class="l" name="501" href="#501">501</a>										<b>if</b> (<a href="/source/s?defs=vmhd&amp;project=rtmp_client">vmhd</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="502" href="#502">502</a>											<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Video header atom found"</span>);
<a class="l" name="503" href="#503">503</a>											<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=dinf&amp;project=rtmp_client">dinf</a> = <a href="/source/s?defs=minf&amp;project=rtmp_client">minf</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"dinf"</span>), <span class="n">0</span>);
<a class="l" name="504" href="#504">504</a>											<b>if</b> (<a href="/source/s?defs=dinf&amp;project=rtmp_client">dinf</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="505" href="#505">505</a>												<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Data info atom found"</span>);
<a class="l" name="506" href="#506">506</a>												<span class="c">// dinf: dref</span>
<a class="l" name="507" href="#507">507</a>												<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Video dinf children: {}"</span>, <a href="/source/s?defs=dinf&amp;project=rtmp_client">dinf</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>());
<a class="l" name="508" href="#508">508</a>												<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=dref&amp;project=rtmp_client">dref</a> = <a href="/source/s?defs=dinf&amp;project=rtmp_client">dinf</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"dref"</span>), <span class="n">0</span>);
<a class="l" name="509" href="#509">509</a>												<b>if</b> (<a href="/source/s?defs=dref&amp;project=rtmp_client">dref</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="510" href="#510">510</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Data reference atom found"</span>);
<a class="l" name="511" href="#511">511</a>												}
<a class="l" name="512" href="#512">512</a>											}
<a class="l" name="513" href="#513">513</a>											<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a> = <a href="/source/s?defs=minf&amp;project=rtmp_client">minf</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"stbl"</span>), <span class="n">0</span>);
<a class="l" name="514" href="#514">514</a>											<b>if</b> (<a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="515" href="#515">515</a>												<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sample table atom found"</span>);
<a class="l" name="516" href="#516">516</a>												<span class="c">// stbl: stsd, stts, stss, stsc, stsz, stco,</span>
<a class="l" name="517" href="#517">517</a>												<span class="c">// stsh</span>
<a class="l" name="518" href="#518">518</a>												<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Video stbl children: {}"</span>, <a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>());
<a class="l" name="519" href="#519">519</a>												<span class="c">// stsd - sample description</span>
<a class="hl" name="520" href="#520">520</a>												<span class="c">// stts - (decoding) time to sample</span>
<a class="l" name="521" href="#521">521</a>												<span class="c">// stsc - sample to chunk</span>
<a class="l" name="522" href="#522">522</a>												<span class="c">// stsz - sample size</span>
<a class="l" name="523" href="#523">523</a>												<span class="c">// stco - chunk offset</span>
<a class="l" name="524" href="#524">524</a>												<span class="c">// ctts - (composition) time to sample</span>
<a class="l" name="525" href="#525">525</a>												<span class="c">// stss - sync sample</span>
<a class="l" name="526" href="#526">526</a>												<span class="c">// sdtp - independent and disposable samples</span>
<a class="l" name="527" href="#527">527</a>
<a class="l" name="528" href="#528">528</a>												<span class="c">//stsd - has codec child</span>
<a class="l" name="529" href="#529">529</a>												<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=stsd&amp;project=rtmp_client">stsd</a> = <a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"stsd"</span>), <span class="n">0</span>);
<a class="hl" name="530" href="#530">530</a>												<b>if</b> (<a href="/source/s?defs=stsd&amp;project=rtmp_client">stsd</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="531" href="#531">531</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sample description atom found"</span>);
<a class="l" name="532" href="#532">532</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sample description (video) stsd children: {}"</span>, <a href="/source/s?defs=stsd&amp;project=rtmp_client">stsd</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>());
<a class="l" name="533" href="#533">533</a>													<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=avc1&amp;project=rtmp_client">avc1</a> = <a href="/source/s?defs=stsd&amp;project=rtmp_client">stsd</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"avc1"</span>), <span class="n">0</span>);
<a class="l" name="534" href="#534">534</a>													<b>if</b> (<a href="/source/s?defs=avc1&amp;project=rtmp_client">avc1</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="535" href="#535">535</a>														<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"AVC1 children: {}"</span>, <a href="/source/s?defs=avc1&amp;project=rtmp_client">avc1</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>());
<a class="l" name="536" href="#536">536</a>														<span class="c">//set the video codec here - may be avc1 or mp4v</span>
<a class="l" name="537" href="#537">537</a>														<a class="d" href="#setVideoCodecId">setVideoCodecId</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=intToType&amp;project=rtmp_client">intToType</a>(<a href="/source/s?defs=avc1&amp;project=rtmp_client">avc1</a>.<a href="/source/s?defs=getType&amp;project=rtmp_client">getType</a>()));
<a class="l" name="538" href="#538">538</a>														<span class="c">//video decoder config</span>
<a class="l" name="539" href="#539">539</a>														<span class="c">//TODO may need to be generic later</span>
<a class="hl" name="540" href="#540">540</a>														<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=codecChild&amp;project=rtmp_client">codecChild</a> = <a href="/source/s?defs=avc1&amp;project=rtmp_client">avc1</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"avcC"</span>), <span class="n">0</span>);
<a class="l" name="541" href="#541">541</a>														<b>if</b> (<a href="/source/s?defs=codecChild&amp;project=rtmp_client">codecChild</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="542" href="#542">542</a>															<a class="d" href="#avcLevel">avcLevel</a> = <a href="/source/s?defs=codecChild&amp;project=rtmp_client">codecChild</a>.<a href="/source/s?defs=getAvcLevel&amp;project=rtmp_client">getAvcLevel</a>();
<a class="l" name="543" href="#543">543</a>															<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"AVC level: {}"</span>, <a class="d" href="#avcLevel">avcLevel</a>);
<a class="l" name="544" href="#544">544</a>															<a class="d" href="#avcProfile">avcProfile</a> = <a href="/source/s?defs=codecChild&amp;project=rtmp_client">codecChild</a>.<a href="/source/s?defs=getAvcProfile&amp;project=rtmp_client">getAvcProfile</a>();
<a class="l" name="545" href="#545">545</a>															<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"AVC Profile: {}"</span>, <a class="d" href="#avcProfile">avcProfile</a>);
<a class="l" name="546" href="#546">546</a>															<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"AVCC size: {}"</span>, <a href="/source/s?defs=codecChild&amp;project=rtmp_client">codecChild</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>());
<a class="l" name="547" href="#547">547</a>															<a class="d" href="#videoDecoderBytes">videoDecoderBytes</a> = <a href="/source/s?defs=codecChild&amp;project=rtmp_client">codecChild</a>.<a href="/source/s?defs=getVideoConfigBytes&amp;project=rtmp_client">getVideoConfigBytes</a>();
<a class="l" name="548" href="#548">548</a>															<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Video config bytes: {}"</span>, <a href="/source/s?defs=ToStringBuilder&amp;project=rtmp_client">ToStringBuilder</a>.<a href="/source/s?defs=reflectionToString&amp;project=rtmp_client">reflectionToString</a>(<a class="d" href="#videoDecoderBytes">videoDecoderBytes</a>));
<a class="l" name="549" href="#549">549</a>														} <b>else</b> {
<a class="hl" name="550" href="#550">550</a>															<span class="c">//quicktime and ipods use a pixel aspect atom</span>
<a class="l" name="551" href="#551">551</a>															<span class="c">//since we have no avcC check for this and avcC may</span>
<a class="l" name="552" href="#552">552</a>															<span class="c">//be a child</span>
<a class="l" name="553" href="#553">553</a>															<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=pasp&amp;project=rtmp_client">pasp</a> = <a href="/source/s?defs=avc1&amp;project=rtmp_client">avc1</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"pasp"</span>), <span class="n">0</span>);
<a class="l" name="554" href="#554">554</a>															<b>if</b> (<a href="/source/s?defs=pasp&amp;project=rtmp_client">pasp</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="555" href="#555">555</a>																<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"PASP children: {}"</span>, <a href="/source/s?defs=pasp&amp;project=rtmp_client">pasp</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>());
<a class="l" name="556" href="#556">556</a>																<a href="/source/s?defs=codecChild&amp;project=rtmp_client">codecChild</a> = <a href="/source/s?defs=pasp&amp;project=rtmp_client">pasp</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"avcC"</span>), <span class="n">0</span>);
<a class="l" name="557" href="#557">557</a>																<b>if</b> (<a href="/source/s?defs=codecChild&amp;project=rtmp_client">codecChild</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="558" href="#558">558</a>																	<a class="d" href="#avcLevel">avcLevel</a> = <a href="/source/s?defs=codecChild&amp;project=rtmp_client">codecChild</a>.<a href="/source/s?defs=getAvcLevel&amp;project=rtmp_client">getAvcLevel</a>();
<a class="l" name="559" href="#559">559</a>																	<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"AVC level: {}"</span>, <a class="d" href="#avcLevel">avcLevel</a>);
<a class="hl" name="560" href="#560">560</a>																	<a class="d" href="#avcProfile">avcProfile</a> = <a href="/source/s?defs=codecChild&amp;project=rtmp_client">codecChild</a>.<a href="/source/s?defs=getAvcProfile&amp;project=rtmp_client">getAvcProfile</a>();
<a class="l" name="561" href="#561">561</a>																	<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"AVC Profile: {}"</span>, <a class="d" href="#avcProfile">avcProfile</a>);
<a class="l" name="562" href="#562">562</a>																	<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"AVCC size: {}"</span>, <a href="/source/s?defs=codecChild&amp;project=rtmp_client">codecChild</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>());
<a class="l" name="563" href="#563">563</a>																	<a class="d" href="#videoDecoderBytes">videoDecoderBytes</a> = <a href="/source/s?defs=codecChild&amp;project=rtmp_client">codecChild</a>.<a href="/source/s?defs=getVideoConfigBytes&amp;project=rtmp_client">getVideoConfigBytes</a>();
<a class="l" name="564" href="#564">564</a>																	<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Video config bytes: {}"</span>, <a href="/source/s?defs=ToStringBuilder&amp;project=rtmp_client">ToStringBuilder</a>.<a href="/source/s?defs=reflectionToString&amp;project=rtmp_client">reflectionToString</a>(<a class="d" href="#videoDecoderBytes">videoDecoderBytes</a>));
<a class="l" name="565" href="#565">565</a>																}
<a class="l" name="566" href="#566">566</a>															}
<a class="l" name="567" href="#567">567</a>														}
<a class="l" name="568" href="#568">568</a>													} <b>else</b> {
<a class="l" name="569" href="#569">569</a>														<span class="c">//look for mp4v</span>
<a class="hl" name="570" href="#570">570</a>														<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=mp4v&amp;project=rtmp_client">mp4v</a> = <a href="/source/s?defs=stsd&amp;project=rtmp_client">stsd</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"mp4v"</span>), <span class="n">0</span>);
<a class="l" name="571" href="#571">571</a>														<b>if</b> (<a href="/source/s?defs=mp4v&amp;project=rtmp_client">mp4v</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="572" href="#572">572</a>															<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"MP4V children: {}"</span>, <a href="/source/s?defs=mp4v&amp;project=rtmp_client">mp4v</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>());
<a class="l" name="573" href="#573">573</a>															<span class="c">//set the video codec here - may be avc1 or mp4v</span>
<a class="l" name="574" href="#574">574</a>															<a class="d" href="#setVideoCodecId">setVideoCodecId</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=intToType&amp;project=rtmp_client">intToType</a>(<a href="/source/s?defs=mp4v&amp;project=rtmp_client">mp4v</a>.<a href="/source/s?defs=getType&amp;project=rtmp_client">getType</a>()));
<a class="l" name="575" href="#575">575</a>															<span class="c">//look for esds</span>
<a class="l" name="576" href="#576">576</a>															<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=codecChild&amp;project=rtmp_client">codecChild</a> = <a href="/source/s?defs=mp4v&amp;project=rtmp_client">mp4v</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"esds"</span>), <span class="n">0</span>);
<a class="l" name="577" href="#577">577</a>															<b>if</b> (<a href="/source/s?defs=codecChild&amp;project=rtmp_client">codecChild</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="578" href="#578">578</a>																<span class="c">//look for descriptors</span>
<a class="l" name="579" href="#579">579</a>																<a href="/source/s?defs=MP4Descriptor&amp;project=rtmp_client">MP4Descriptor</a> <a href="/source/s?defs=descriptor&amp;project=rtmp_client">descriptor</a> = <a href="/source/s?defs=codecChild&amp;project=rtmp_client">codecChild</a>.<a href="/source/s?defs=getEsd_descriptor&amp;project=rtmp_client">getEsd_descriptor</a>();
<a class="hl" name="580" href="#580">580</a>																<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"{}"</span>, <a href="/source/s?defs=ToStringBuilder&amp;project=rtmp_client">ToStringBuilder</a>.<a href="/source/s?defs=reflectionToString&amp;project=rtmp_client">reflectionToString</a>(<a href="/source/s?defs=descriptor&amp;project=rtmp_client">descriptor</a>));
<a class="l" name="581" href="#581">581</a>																<b>if</b> (<a href="/source/s?defs=descriptor&amp;project=rtmp_client">descriptor</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="582" href="#582">582</a>																	<a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=MP4Descriptor&amp;project=rtmp_client">MP4Descriptor</a>&gt; <a href="/source/s?defs=children&amp;project=rtmp_client">children</a> = <a href="/source/s?defs=descriptor&amp;project=rtmp_client">descriptor</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>();
<a class="l" name="583" href="#583">583</a>																	<b>for</b> (<b>int</b> e = <span class="n">0</span>; e &lt; <a href="/source/s?defs=children&amp;project=rtmp_client">children</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>(); e++) {
<a class="l" name="584" href="#584">584</a>																		<a href="/source/s?defs=MP4Descriptor&amp;project=rtmp_client">MP4Descriptor</a> <a href="/source/s?defs=descr&amp;project=rtmp_client">descr</a> = <a href="/source/s?defs=children&amp;project=rtmp_client">children</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(e);
<a class="l" name="585" href="#585">585</a>																		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"{}"</span>, <a href="/source/s?defs=ToStringBuilder&amp;project=rtmp_client">ToStringBuilder</a>.<a href="/source/s?defs=reflectionToString&amp;project=rtmp_client">reflectionToString</a>(<a href="/source/s?defs=descr&amp;project=rtmp_client">descr</a>));
<a class="l" name="586" href="#586">586</a>																		<b>if</b> (<a href="/source/s?defs=descr&amp;project=rtmp_client">descr</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>().<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>() &gt; <span class="n">0</span>) {
<a class="l" name="587" href="#587">587</a>																			<a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=MP4Descriptor&amp;project=rtmp_client">MP4Descriptor</a>&gt; <a href="/source/s?defs=children2&amp;project=rtmp_client">children2</a> = <a href="/source/s?defs=descr&amp;project=rtmp_client">descr</a>.<a href="/source/s?defs=getChildren&amp;project=rtmp_client">getChildren</a>();
<a class="l" name="588" href="#588">588</a>																			<b>for</b> (<b>int</b> <a href="/source/s?defs=e2&amp;project=rtmp_client">e2</a> = <span class="n">0</span>; <a href="/source/s?defs=e2&amp;project=rtmp_client">e2</a> &lt; <a href="/source/s?defs=children2&amp;project=rtmp_client">children2</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>(); <a href="/source/s?defs=e2&amp;project=rtmp_client">e2</a>++) {
<a class="l" name="589" href="#589">589</a>																				<a href="/source/s?defs=MP4Descriptor&amp;project=rtmp_client">MP4Descriptor</a> <a href="/source/s?defs=descr2&amp;project=rtmp_client">descr2</a> = <a href="/source/s?defs=children2&amp;project=rtmp_client">children2</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=e2&amp;project=rtmp_client">e2</a>);
<a class="hl" name="590" href="#590">590</a>																				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"{}"</span>, <a href="/source/s?defs=ToStringBuilder&amp;project=rtmp_client">ToStringBuilder</a>.<a href="/source/s?defs=reflectionToString&amp;project=rtmp_client">reflectionToString</a>(<a href="/source/s?defs=descr2&amp;project=rtmp_client">descr2</a>));
<a class="l" name="591" href="#591">591</a>																				<b>if</b> (<a href="/source/s?defs=descr2&amp;project=rtmp_client">descr2</a>.<a href="/source/s?defs=getType&amp;project=rtmp_client">getType</a>() == <a href="/source/s?defs=MP4Descriptor&amp;project=rtmp_client">MP4Descriptor</a>.<a href="/source/s?defs=MP4DecSpecificInfoDescriptorTag&amp;project=rtmp_client">MP4DecSpecificInfoDescriptorTag</a>) {
<a class="l" name="592" href="#592">592</a>																					<span class="c">//we only want the MP4DecSpecificInfoDescriptorTag</span>
<a class="l" name="593" href="#593">593</a>																					<a class="d" href="#videoDecoderBytes">videoDecoderBytes</a> = <b>new</b> <b>byte</b>[<a href="/source/s?defs=descr2&amp;project=rtmp_client">descr2</a>.<a href="/source/s?defs=getDSID&amp;project=rtmp_client">getDSID</a>().<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> - <span class="n">8</span>];
<a class="l" name="594" href="#594">594</a>																					<a href="/source/s?defs=System&amp;project=rtmp_client">System</a>.<a href="/source/s?defs=arraycopy&amp;project=rtmp_client">arraycopy</a>(<a href="/source/s?defs=descr2&amp;project=rtmp_client">descr2</a>.<a href="/source/s?defs=getDSID&amp;project=rtmp_client">getDSID</a>(), <span class="n">8</span>, <a class="d" href="#videoDecoderBytes">videoDecoderBytes</a>, <span class="n">0</span>, <a class="d" href="#videoDecoderBytes">videoDecoderBytes</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>);
<a class="l" name="595" href="#595">595</a>																					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Video config bytes: {}"</span>, <a href="/source/s?defs=ToStringBuilder&amp;project=rtmp_client">ToStringBuilder</a>.<a href="/source/s?defs=reflectionToString&amp;project=rtmp_client">reflectionToString</a>(<a class="d" href="#videoDecoderBytes">videoDecoderBytes</a>));
<a class="l" name="596" href="#596">596</a>																					<span class="c">//we want to break out of top level for loop</span>
<a class="l" name="597" href="#597">597</a>																					e = <span class="n">99</span>;
<a class="l" name="598" href="#598">598</a>																					<b>break</b>;
<a class="l" name="599" href="#599">599</a>																				}
<a class="hl" name="600" href="#600">600</a>																			}
<a class="l" name="601" href="#601">601</a>																		}
<a class="l" name="602" href="#602">602</a>																	}
<a class="l" name="603" href="#603">603</a>																}
<a class="l" name="604" href="#604">604</a>															}
<a class="l" name="605" href="#605">605</a>														}
<a class="l" name="606" href="#606">606</a>
<a class="l" name="607" href="#607">607</a>													}
<a class="l" name="608" href="#608">608</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"{}"</span>, <a href="/source/s?defs=ToStringBuilder&amp;project=rtmp_client">ToStringBuilder</a>.<a href="/source/s?defs=reflectionToString&amp;project=rtmp_client">reflectionToString</a>(<a href="/source/s?defs=avc1&amp;project=rtmp_client">avc1</a>));
<a class="l" name="609" href="#609">609</a>												}
<a class="hl" name="610" href="#610">610</a>												<span class="c">//stsc - has Records</span>
<a class="l" name="611" href="#611">611</a>												<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=stsc&amp;project=rtmp_client">stsc</a> = <a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"stsc"</span>), <span class="n">0</span>);
<a class="l" name="612" href="#612">612</a>												<b>if</b> (<a href="/source/s?defs=stsc&amp;project=rtmp_client">stsc</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="613" href="#613">613</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sample to chunk atom found"</span>);
<a class="l" name="614" href="#614">614</a>													<a class="d" href="#videoSamplesToChunks">videoSamplesToChunks</a> = <a href="/source/s?defs=stsc&amp;project=rtmp_client">stsc</a>.<a href="/source/s?defs=getRecords&amp;project=rtmp_client">getRecords</a>();
<a class="l" name="615" href="#615">615</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Record count: {}"</span>, <a class="d" href="#videoSamplesToChunks">videoSamplesToChunks</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>());
<a class="l" name="616" href="#616">616</a>													<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=Record&amp;project=rtmp_client">Record</a> <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a> = <a class="d" href="#videoSamplesToChunks">videoSamplesToChunks</a>.<a href="/source/s?defs=firstElement&amp;project=rtmp_client">firstElement</a>();
<a class="l" name="617" href="#617">617</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Record data: Description index={} Samples per chunk={}"</span>, <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a>.<a href="/source/s?defs=getSampleDescriptionIndex&amp;project=rtmp_client">getSampleDescriptionIndex</a>(), <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a>.<a href="/source/s?defs=getSamplesPerChunk&amp;project=rtmp_client">getSamplesPerChunk</a>());
<a class="l" name="618" href="#618">618</a>												}
<a class="l" name="619" href="#619">619</a>												<span class="c">//stsz - has Samples</span>
<a class="hl" name="620" href="#620">620</a>												<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=stsz&amp;project=rtmp_client">stsz</a> = <a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"stsz"</span>), <span class="n">0</span>);
<a class="l" name="621" href="#621">621</a>												<b>if</b> (<a href="/source/s?defs=stsz&amp;project=rtmp_client">stsz</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="622" href="#622">622</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sample size atom found"</span>);
<a class="l" name="623" href="#623">623</a>													<span class="c">//vector full of integers</span>
<a class="l" name="624" href="#624">624</a>													<a class="d" href="#videoSamples">videoSamples</a> = <a href="/source/s?defs=stsz&amp;project=rtmp_client">stsz</a>.<a href="/source/s?defs=getSamples&amp;project=rtmp_client">getSamples</a>();
<a class="l" name="625" href="#625">625</a>													<span class="c">//if sample size is 0 then the table must be checked due</span>
<a class="l" name="626" href="#626">626</a>													<span class="c">//to variable sample sizes</span>
<a class="l" name="627" href="#627">627</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sample size: {}"</span>, <a href="/source/s?defs=stsz&amp;project=rtmp_client">stsz</a>.<a href="/source/s?defs=getSampleSize&amp;project=rtmp_client">getSampleSize</a>());
<a class="l" name="628" href="#628">628</a>													<a class="d" href="#videoSampleCount">videoSampleCount</a> = <a class="d" href="#videoSamples">videoSamples</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>();
<a class="l" name="629" href="#629">629</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sample count: {}"</span>, <a class="d" href="#videoSampleCount">videoSampleCount</a>);
<a class="hl" name="630" href="#630">630</a>												}
<a class="l" name="631" href="#631">631</a>												<span class="c">//stco - has Chunks</span>
<a class="l" name="632" href="#632">632</a>												<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=stco&amp;project=rtmp_client">stco</a> = <a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"stco"</span>), <span class="n">0</span>);
<a class="l" name="633" href="#633">633</a>												<b>if</b> (<a href="/source/s?defs=stco&amp;project=rtmp_client">stco</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="634" href="#634">634</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Chunk offset atom found"</span>);
<a class="l" name="635" href="#635">635</a>													<span class="c">//vector full of integers</span>
<a class="l" name="636" href="#636">636</a>													<a class="d" href="#videoChunkOffsets">videoChunkOffsets</a> = <a href="/source/s?defs=stco&amp;project=rtmp_client">stco</a>.<a href="/source/s?defs=getChunks&amp;project=rtmp_client">getChunks</a>();
<a class="l" name="637" href="#637">637</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Chunk count: {}"</span>, <a class="d" href="#videoChunkOffsets">videoChunkOffsets</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>());
<a class="l" name="638" href="#638">638</a>												}
<a class="l" name="639" href="#639">639</a>												<span class="c">//stss - has Sync - no sync means all samples are keyframes</span>
<a class="hl" name="640" href="#640">640</a>												<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=stss&amp;project=rtmp_client">stss</a> = <a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"stss"</span>), <span class="n">0</span>);
<a class="l" name="641" href="#641">641</a>												<b>if</b> (<a href="/source/s?defs=stss&amp;project=rtmp_client">stss</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="642" href="#642">642</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sync sample atom found"</span>);
<a class="l" name="643" href="#643">643</a>													<span class="c">//vector full of integers</span>
<a class="l" name="644" href="#644">644</a>													<a class="d" href="#syncSamples">syncSamples</a> = <a href="/source/s?defs=stss&amp;project=rtmp_client">stss</a>.<a href="/source/s?defs=getSyncSamples&amp;project=rtmp_client">getSyncSamples</a>();
<a class="l" name="645" href="#645">645</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Keyframes: {}"</span>, <a class="d" href="#syncSamples">syncSamples</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>());
<a class="l" name="646" href="#646">646</a>												}
<a class="l" name="647" href="#647">647</a>												<span class="c">//stts - has TimeSampleRecords</span>
<a class="l" name="648" href="#648">648</a>												<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=stts&amp;project=rtmp_client">stts</a> = <a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"stts"</span>), <span class="n">0</span>);
<a class="l" name="649" href="#649">649</a>												<b>if</b> (<a href="/source/s?defs=stts&amp;project=rtmp_client">stts</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="650" href="#650">650</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Time to sample atom found"</span>);
<a class="l" name="651" href="#651">651</a>													<a href="/source/s?defs=Vector&amp;project=rtmp_client">Vector</a>&lt;<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=TimeSampleRecord&amp;project=rtmp_client">TimeSampleRecord</a>&gt; <a href="/source/s?defs=records&amp;project=rtmp_client">records</a> = <a href="/source/s?defs=stts&amp;project=rtmp_client">stts</a>.<a href="/source/s?defs=getTimeToSamplesRecords&amp;project=rtmp_client">getTimeToSamplesRecords</a>();
<a class="l" name="652" href="#652">652</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Record count: {}"</span>, <a href="/source/s?defs=records&amp;project=rtmp_client">records</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>());
<a class="l" name="653" href="#653">653</a>													<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=TimeSampleRecord&amp;project=rtmp_client">TimeSampleRecord</a> <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a> = <a href="/source/s?defs=records&amp;project=rtmp_client">records</a>.<a href="/source/s?defs=firstElement&amp;project=rtmp_client">firstElement</a>();
<a class="l" name="654" href="#654">654</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Record data: Consecutive samples={} Duration={}"</span>, <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a>.<a href="/source/s?defs=getConsecutiveSamples&amp;project=rtmp_client">getConsecutiveSamples</a>(), <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a>.<a href="/source/s?defs=getSampleDuration&amp;project=rtmp_client">getSampleDuration</a>());
<a class="l" name="655" href="#655">655</a>													<span class="c">//if we have 1 record then all samples have the same duration</span>
<a class="l" name="656" href="#656">656</a>													<b>if</b> (<a href="/source/s?defs=records&amp;project=rtmp_client">records</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>() &gt; <span class="n">1</span>) {
<a class="l" name="657" href="#657">657</a>														<span class="c">//TODO: handle video samples with varying durations</span>
<a class="l" name="658" href="#658">658</a>														<a class="d" href="#log">log</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"Video samples have differing durations, video playback may fail"</span>);
<a class="l" name="659" href="#659">659</a>													}
<a class="hl" name="660" href="#660">660</a>													<a class="d" href="#videoSampleDuration">videoSampleDuration</a> = <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a>.<a href="/source/s?defs=getSampleDuration&amp;project=rtmp_client">getSampleDuration</a>();
<a class="l" name="661" href="#661">661</a>												}
<a class="l" name="662" href="#662">662</a>												<span class="c">//ctts - (composition) time to sample</span>
<a class="l" name="663" href="#663">663</a>												<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=ctts&amp;project=rtmp_client">ctts</a> = <a href="/source/s?defs=stbl&amp;project=rtmp_client">stbl</a>.<a href="/source/s?defs=lookup&amp;project=rtmp_client">lookup</a>(<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=typeToInt&amp;project=rtmp_client">typeToInt</a>(<span class="s">"ctts"</span>), <span class="n">0</span>);
<a class="l" name="664" href="#664">664</a>												<b>if</b> (<a href="/source/s?defs=ctts&amp;project=rtmp_client">ctts</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="665" href="#665">665</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Composition time to sample atom found"</span>);
<a class="l" name="666" href="#666">666</a>													<span class="c">//vector full of integers</span>
<a class="l" name="667" href="#667">667</a>													<a class="d" href="#compositionTimes">compositionTimes</a> = <a href="/source/s?defs=ctts&amp;project=rtmp_client">ctts</a>.<a href="/source/s?defs=getCompositionTimeToSamplesRecords&amp;project=rtmp_client">getCompositionTimeToSamplesRecords</a>();
<a class="l" name="668" href="#668">668</a>													<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Record count: {}"</span>, <a class="d" href="#compositionTimes">compositionTimes</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>());
<a class="l" name="669" href="#669">669</a>													<b>if</b> (<a class="d" href="#log">log</a>.<a href="/source/s?defs=isTraceEnabled&amp;project=rtmp_client">isTraceEnabled</a>()) {
<a class="hl" name="670" href="#670">670</a>														<b>for</b> (<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=CompositionTimeSampleRecord&amp;project=rtmp_client">CompositionTimeSampleRecord</a> <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a> : <a class="d" href="#compositionTimes">compositionTimes</a>) {
<a class="l" name="671" href="#671">671</a>															<b>double</b> <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> = <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a>.<a href="/source/s?defs=getSampleOffset&amp;project=rtmp_client">getSampleOffset</a>();
<a class="l" name="672" href="#672">672</a>															<b>if</b> (<a href="/source/s?defs=scale&amp;project=rtmp_client">scale</a> &gt; <span class="n">0d</span>) {
<a class="l" name="673" href="#673">673</a>																<a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> = (<a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> / (<b>double</b>) <a href="/source/s?defs=scale&amp;project=rtmp_client">scale</a>) * <span class="n">1000.0</span>;
<a class="l" name="674" href="#674">674</a>																<a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a>.<a href="/source/s?defs=setSampleOffset&amp;project=rtmp_client">setSampleOffset</a>((<b>int</b>) <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>);
<a class="l" name="675" href="#675">675</a>															}
<a class="l" name="676" href="#676">676</a>															<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Record data: Consecutive samples={} Offset={}"</span>, <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a>.<a href="/source/s?defs=getConsecutiveSamples&amp;project=rtmp_client">getConsecutiveSamples</a>(), <a href="/source/s?defs=rec&amp;project=rtmp_client">rec</a>.<a href="/source/s?defs=getSampleOffset&amp;project=rtmp_client">getSampleOffset</a>());
<a class="l" name="677" href="#677">677</a>														}
<a class="l" name="678" href="#678">678</a>													}
<a class="l" name="679" href="#679">679</a>												}
<a class="hl" name="680" href="#680">680</a>											}
<a class="l" name="681" href="#681">681</a>										}
<a class="l" name="682" href="#682">682</a>
<a class="l" name="683" href="#683">683</a>									}
<a class="l" name="684" href="#684">684</a>
<a class="l" name="685" href="#685">685</a>								}
<a class="l" name="686" href="#686">686</a>							}
<a class="l" name="687" href="#687">687</a>							<a href="/source/s?defs=loops&amp;project=rtmp_client">loops</a>++;
<a class="l" name="688" href="#688">688</a>						} <b>while</b> (<a href="/source/s?defs=loops&amp;project=rtmp_client">loops</a> &lt; <span class="n">3</span>);
<a class="l" name="689" href="#689">689</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Busted out of track loop with {} tracks after {} loops"</span>, <a href="/source/s?defs=tracks&amp;project=rtmp_client">tracks</a>, <a href="/source/s?defs=loops&amp;project=rtmp_client">loops</a>);
<a class="hl" name="690" href="#690">690</a>						<span class="c">//calculate FPS</span>
<a class="l" name="691" href="#691">691</a>						<a class="d" href="#fps">fps</a> = (<a class="d" href="#videoSampleCount">videoSampleCount</a> * <a class="d" href="#timeScale">timeScale</a>) / (<b>double</b>) <a class="d" href="#duration">duration</a>;
<a class="l" name="692" href="#692">692</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"FPS calc: ({} * {}) / {}"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <a class="d" href="#videoSampleCount">videoSampleCount</a>, <a class="d" href="#timeScale">timeScale</a>, <a class="d" href="#duration">duration</a> });
<a class="l" name="693" href="#693">693</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"FPS: {}"</span>, <a class="d" href="#fps">fps</a>);
<a class="l" name="694" href="#694">694</a>
<a class="l" name="695" href="#695">695</a>						<span class="c">//real duration</span>
<a class="l" name="696" href="#696">696</a>						<a href="/source/s?defs=StringBuilder&amp;project=rtmp_client">StringBuilder</a> <a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a> = <b>new</b> <a href="/source/s?defs=StringBuilder&amp;project=rtmp_client">StringBuilder</a>();
<a class="l" name="697" href="#697">697</a>						<b>double</b> <a href="/source/s?defs=videoTime&amp;project=rtmp_client">videoTime</a> = ((<b>double</b>) <a class="d" href="#duration">duration</a> / (<b>double</b>) <a class="d" href="#timeScale">timeScale</a>);
<a class="l" name="698" href="#698">698</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Video time: {}"</span>, <a href="/source/s?defs=videoTime&amp;project=rtmp_client">videoTime</a>);
<a class="l" name="699" href="#699">699</a>						<b>int</b> <a href="/source/s?defs=minutes&amp;project=rtmp_client">minutes</a> = (<b>int</b>) (<a href="/source/s?defs=videoTime&amp;project=rtmp_client">videoTime</a> / <span class="n">60</span>);
<a class="hl" name="700" href="#700">700</a>						<b>if</b> (<a href="/source/s?defs=minutes&amp;project=rtmp_client">minutes</a> &gt; <span class="n">0</span>) {
<a class="l" name="701" href="#701">701</a>							<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a href="/source/s?defs=minutes&amp;project=rtmp_client">minutes</a>);
<a class="l" name="702" href="#702">702</a>							<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">'.'</span>);
<a class="l" name="703" href="#703">703</a>						}
<a class="l" name="704" href="#704">704</a>						<span class="c">//formatter for seconds / millis</span>
<a class="l" name="705" href="#705">705</a>						<a href="/source/s?defs=NumberFormat&amp;project=rtmp_client">NumberFormat</a> <a href="/source/s?defs=df&amp;project=rtmp_client">df</a> = <a href="/source/s?defs=DecimalFormat&amp;project=rtmp_client">DecimalFormat</a>.<a href="/source/s?defs=getInstance&amp;project=rtmp_client">getInstance</a>();
<a class="l" name="706" href="#706">706</a>						<a href="/source/s?defs=df&amp;project=rtmp_client">df</a>.<a href="/source/s?defs=setMaximumFractionDigits&amp;project=rtmp_client">setMaximumFractionDigits</a>(<span class="n">2</span>);
<a class="l" name="707" href="#707">707</a>						<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a href="/source/s?defs=df&amp;project=rtmp_client">df</a>.<a href="/source/s?defs=format&amp;project=rtmp_client">format</a>((<a href="/source/s?defs=videoTime&amp;project=rtmp_client">videoTime</a> % <span class="n">60</span>)));
<a class="l" name="708" href="#708">708</a>						<a class="d" href="#formattedDuration">formattedDuration</a> = <a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>();
<a class="l" name="709" href="#709">709</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Time: {}"</span>, <a class="d" href="#formattedDuration">formattedDuration</a>);
<a class="hl" name="710" href="#710">710</a>
<a class="l" name="711" href="#711">711</a>						<b>break</b>;
<a class="l" name="712" href="#712">712</a>					<b>case</b> <span class="n">1835295092</span>: <span class="c">//mdat</span>
<a class="l" name="713" href="#713">713</a>						<a href="/source/s?defs=topAtoms&amp;project=rtmp_client">topAtoms</a>++;
<a class="l" name="714" href="#714">714</a>						<b>long</b> <a href="/source/s?defs=dataSize&amp;project=rtmp_client">dataSize</a> = <span class="n">0L</span>;
<a class="l" name="715" href="#715">715</a>						<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a> <a href="/source/s?defs=mdat&amp;project=rtmp_client">mdat</a> = <a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>;
<a class="l" name="716" href="#716">716</a>						<a href="/source/s?defs=dataSize&amp;project=rtmp_client">dataSize</a> = <a href="/source/s?defs=mdat&amp;project=rtmp_client">mdat</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>();
<a class="l" name="717" href="#717">717</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"{}"</span>, <a href="/source/s?defs=ToStringBuilder&amp;project=rtmp_client">ToStringBuilder</a>.<a href="/source/s?defs=reflectionToString&amp;project=rtmp_client">reflectionToString</a>(<a href="/source/s?defs=mdat&amp;project=rtmp_client">mdat</a>));
<a class="l" name="718" href="#718">718</a>						<a class="d" href="#mdatOffset">mdatOffset</a> = <a class="d" href="#fis">fis</a>.<a class="d" href="#getOffset">getOffset</a>() - <a href="/source/s?defs=dataSize&amp;project=rtmp_client">dataSize</a>;
<a class="l" name="719" href="#719">719</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"File size: {} mdat size: {}"</span>, <a class="d" href="#file">file</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>(), <a href="/source/s?defs=dataSize&amp;project=rtmp_client">dataSize</a>);
<a class="hl" name="720" href="#720">720</a>
<a class="l" name="721" href="#721">721</a>						<b>break</b>;
<a class="l" name="722" href="#722">722</a>					<b>case</b> <span class="n">1718773093</span>: <span class="c">//free</span>
<a class="l" name="723" href="#723">723</a>					<b>case</b> <span class="n">2003395685</span>: <span class="c">//wide</span>
<a class="l" name="724" href="#724">724</a>						<b>break</b>;
<a class="l" name="725" href="#725">725</a>					<b>default</b>:
<a class="l" name="726" href="#726">726</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Unexpected atom: {}"</span>, <a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=intToType&amp;project=rtmp_client">intToType</a>(<a href="/source/s?defs=atom&amp;project=rtmp_client">atom</a>.<a href="/source/s?defs=getType&amp;project=rtmp_client">getType</a>()));
<a class="l" name="727" href="#727">727</a>				}
<a class="l" name="728" href="#728">728</a>			}
<a class="l" name="729" href="#729">729</a>
<a class="hl" name="730" href="#730">730</a>			<span class="c">//add the tag name (size) to the offsets</span>
<a class="l" name="731" href="#731">731</a>			<a class="d" href="#moovOffset">moovOffset</a> += <span class="n">8</span>;
<a class="l" name="732" href="#732">732</a>			<a class="d" href="#mdatOffset">mdatOffset</a> += <span class="n">8</span>;
<a class="l" name="733" href="#733">733</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Offsets moov: {} mdat: {}"</span>, <a class="d" href="#moovOffset">moovOffset</a>, <a class="d" href="#mdatOffset">mdatOffset</a>);
<a class="l" name="734" href="#734">734</a>
<a class="l" name="735" href="#735">735</a>		} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> e) {
<a class="l" name="736" href="#736">736</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Exception decoding header / atoms"</span>, e);
<a class="l" name="737" href="#737">737</a>		}
<a class="l" name="738" href="#738">738</a>	}
<a class="l" name="739" href="#739">739</a>
<a class="hl" name="740" href="#740">740</a>	<span class="c">/**
<a class="l" name="741" href="#741">741</a>	 * Get the total readable bytes in a file or IoBuffer.
<a class="l" name="742" href="#742">742</a>	 *
<a class="l" name="743" href="#743">743</a>	 * <strong>@return</strong>          Total readable bytes
<a class="l" name="744" href="#744">744</a>	 */</span>
<a class="l" name="745" href="#745">745</a>	<b>public</b> <b>long</b> <a class="xmt" name="getTotalBytes"/><a href="/source/s?refs=getTotalBytes&amp;project=rtmp_client" class="xmt">getTotalBytes</a>() {
<a class="l" name="746" href="#746">746</a>		<b>try</b> {
<a class="l" name="747" href="#747">747</a>			<b>return</b> <a class="d" href="#channel">channel</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>();
<a class="l" name="748" href="#748">748</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="749" href="#749">749</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error getTotalBytes"</span>, e);
<a class="hl" name="750" href="#750">750</a>		}
<a class="l" name="751" href="#751">751</a>		<b>if</b> (<a class="d" href="#file">file</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="752" href="#752">752</a>			<span class="c">//just return the file size</span>
<a class="l" name="753" href="#753">753</a>			<b>return</b> <a class="d" href="#file">file</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>();
<a class="l" name="754" href="#754">754</a>		} <b>else</b> {
<a class="l" name="755" href="#755">755</a>			<b>return</b> <span class="n">0</span>;
<a class="l" name="756" href="#756">756</a>		}
<a class="l" name="757" href="#757">757</a>	}
<a class="l" name="758" href="#758">758</a>
<a class="l" name="759" href="#759">759</a>	<span class="c">/**
<a class="hl" name="760" href="#760">760</a>	 * Get the current position in a file or IoBuffer.
<a class="l" name="761" href="#761">761</a>	 *
<a class="l" name="762" href="#762">762</a>	 * <strong>@return</strong>           Current position in a file
<a class="l" name="763" href="#763">763</a>	 */</span>
<a class="l" name="764" href="#764">764</a>	<b>private</b> <b>long</b> <a class="xmt" name="getCurrentPosition"/><a href="/source/s?refs=getCurrentPosition&amp;project=rtmp_client" class="xmt">getCurrentPosition</a>() {
<a class="l" name="765" href="#765">765</a>		<b>try</b> {
<a class="l" name="766" href="#766">766</a>			<span class="c">//if we are at the end of the file drop back to mdat offset</span>
<a class="l" name="767" href="#767">767</a>			<b>if</b> (<a class="d" href="#channel">channel</a>.<a class="d" href="#position">position</a>() == <a class="d" href="#channel">channel</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>()) {
<a class="l" name="768" href="#768">768</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Reached end of file, going back to data offset"</span>);
<a class="l" name="769" href="#769">769</a>				<a class="d" href="#channel">channel</a>.<a class="d" href="#position">position</a>(<a class="d" href="#mdatOffset">mdatOffset</a>);
<a class="hl" name="770" href="#770">770</a>			}
<a class="l" name="771" href="#771">771</a>			<b>return</b> <a class="d" href="#channel">channel</a>.<a class="d" href="#position">position</a>();
<a class="l" name="772" href="#772">772</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="773" href="#773">773</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error getCurrentPosition"</span>, e);
<a class="l" name="774" href="#774">774</a>			<b>return</b> <span class="n">0</span>;
<a class="l" name="775" href="#775">775</a>		}
<a class="l" name="776" href="#776">776</a>	}
<a class="l" name="777" href="#777">777</a>
<a class="l" name="778" href="#778">778</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="779" href="#779">779</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="hasVideo"/><a href="/source/s?refs=hasVideo&amp;project=rtmp_client" class="xmt">hasVideo</a>() {
<a class="hl" name="780" href="#780">780</a>		<b>return</b> <a href="/source/s?defs=hasVideo&amp;project=rtmp_client">hasVideo</a>;
<a class="l" name="781" href="#781">781</a>	}
<a class="l" name="782" href="#782">782</a>
<a class="l" name="783" href="#783">783</a>	<span class="c">/**
<a class="l" name="784" href="#784">784</a>	 * Returns the file buffer.
<a class="l" name="785" href="#785">785</a>	 *
<a class="l" name="786" href="#786">786</a>	 * <strong>@return</strong>  File contents as byte buffer
<a class="l" name="787" href="#787">787</a>	 */</span>
<a class="l" name="788" href="#788">788</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="getFileData"/><a href="/source/s?refs=getFileData&amp;project=rtmp_client" class="xmt">getFileData</a>() {
<a class="l" name="789" href="#789">789</a>		<span class="c">// TODO as of now, return null will disable cache</span>
<a class="hl" name="790" href="#790">790</a>		<span class="c">// we need to redesign the cache architecture so that</span>
<a class="l" name="791" href="#791">791</a>		<span class="c">// the cache is layered underneath FLVReader not above it,</span>
<a class="l" name="792" href="#792">792</a>		<span class="c">// thus both tag cache and file cache are feasible.</span>
<a class="l" name="793" href="#793">793</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="794" href="#794">794</a>	}
<a class="l" name="795" href="#795">795</a>
<a class="l" name="796" href="#796">796</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="l" name="797" href="#797">797</a>	 */</span>
<a class="l" name="798" href="#798">798</a>	<b>public</b> <a href="/source/s?defs=IStreamableFile&amp;project=rtmp_client">IStreamableFile</a> <a class="xmt" name="getFile"/><a href="/source/s?refs=getFile&amp;project=rtmp_client" class="xmt">getFile</a>() {
<a class="l" name="799" href="#799">799</a>		<span class="c">// TODO wondering if we need to have a reference</span>
<a class="hl" name="800" href="#800">800</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="801" href="#801">801</a>	}
<a class="l" name="802" href="#802">802</a>
<a class="l" name="803" href="#803">803</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="l" name="804" href="#804">804</a>	 */</span>
<a class="l" name="805" href="#805">805</a>	<b>public</b> <b>int</b> <a class="xmt" name="getOffset"/><a href="/source/s?refs=getOffset&amp;project=rtmp_client" class="xmt">getOffset</a>() {
<a class="l" name="806" href="#806">806</a>		<span class="c">// XXX what's the difference from getBytesRead</span>
<a class="l" name="807" href="#807">807</a>		<b>return</b> <span class="n">0</span>;
<a class="l" name="808" href="#808">808</a>	}
<a class="l" name="809" href="#809">809</a>
<a class="hl" name="810" href="#810">810</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="l" name="811" href="#811">811</a>	 */</span>
<a class="l" name="812" href="#812">812</a>	<b>public</b> <b>long</b> <a class="xmt" name="getBytesRead"/><a href="/source/s?refs=getBytesRead&amp;project=rtmp_client" class="xmt">getBytesRead</a>() {
<a class="l" name="813" href="#813">813</a>		<span class="c">// XXX should summarize the total bytes read or</span>
<a class="l" name="814" href="#814">814</a>		<span class="c">// just the current position?</span>
<a class="l" name="815" href="#815">815</a>		<b>return</b> <a class="d" href="#getCurrentPosition">getCurrentPosition</a>();
<a class="l" name="816" href="#816">816</a>	}
<a class="l" name="817" href="#817">817</a>
<a class="l" name="818" href="#818">818</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="819" href="#819">819</a>	<b>public</b> <b>long</b> <a class="xmt" name="getDuration"/><a href="/source/s?refs=getDuration&amp;project=rtmp_client" class="xmt">getDuration</a>() {
<a class="hl" name="820" href="#820">820</a>		<b>return</b> <a class="d" href="#duration">duration</a>;
<a class="l" name="821" href="#821">821</a>	}
<a class="l" name="822" href="#822">822</a>
<a class="l" name="823" href="#823">823</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getVideoCodecId"/><a href="/source/s?refs=getVideoCodecId&amp;project=rtmp_client" class="xmt">getVideoCodecId</a>() {
<a class="l" name="824" href="#824">824</a>		<b>return</b> <a href="/source/s?defs=videoCodecId&amp;project=rtmp_client">videoCodecId</a>;
<a class="l" name="825" href="#825">825</a>	}
<a class="l" name="826" href="#826">826</a>
<a class="l" name="827" href="#827">827</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getAudioCodecId"/><a href="/source/s?refs=getAudioCodecId&amp;project=rtmp_client" class="xmt">getAudioCodecId</a>() {
<a class="l" name="828" href="#828">828</a>		<b>return</b> <a href="/source/s?defs=audioCodecId&amp;project=rtmp_client">audioCodecId</a>;
<a class="l" name="829" href="#829">829</a>	}
<a class="hl" name="830" href="#830">830</a>
<a class="l" name="831" href="#831">831</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="l" name="832" href="#832">832</a>	 */</span>
<a class="l" name="833" href="#833">833</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="hasMoreTags"/><a href="/source/s?refs=hasMoreTags&amp;project=rtmp_client" class="xmt">hasMoreTags</a>() {
<a class="l" name="834" href="#834">834</a>		<b>return</b> <a class="d" href="#currentFrame">currentFrame</a> &lt; <a class="d" href="#frames">frames</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>();
<a class="l" name="835" href="#835">835</a>	}
<a class="l" name="836" href="#836">836</a>
<a class="l" name="837" href="#837">837</a>	<span class="c">/**
<a class="l" name="838" href="#838">838</a>	 * Create tag for metadata event.
<a class="l" name="839" href="#839">839</a>	 *
<a class="hl" name="840" href="#840">840</a>	 * Info from <a href="http://www.kaourantin.net/2007/08/what-just-happened-to-video-on-web_20.html">http://www.kaourantin.net/2007/08/what-just-happened-to-video-on-web_20.html</a>
<a class="l" name="841" href="#841">841</a>	 * &lt;pre&gt;
<a class="l" name="842" href="#842">842</a>		duration - Obvious. But unlike for FLV files this field will always be present.
<a class="l" name="843" href="#843">843</a>		videocodecid - For H.264 we report 'avc1'.
<a class="l" name="844" href="#844">844</a>	    audiocodecid - For AAC we report 'mp4a', for MP3 we report '.mp3'.
<a class="l" name="845" href="#845">845</a>	    avcprofile - 66, 77, 88, 100, 110, 122 or 144 which corresponds to the H.264 profiles.
<a class="l" name="846" href="#846">846</a>	    avclevel - A number between 10 and 51. Consult this list to find out more.
<a class="l" name="847" href="#847">847</a>	    aottype - Either 0, 1 or 2. This corresponds to AAC Main, AAC LC and SBR audio types.
<a class="l" name="848" href="#848">848</a>	    moovposition - The offset in bytes of the moov atom in a file.
<a class="l" name="849" href="#849">849</a>	    trackinfo - An array of objects containing various infomation about all the tracks in a file
<a class="hl" name="850" href="#850">850</a>	      ex.
<a class="l" name="851" href="#851">851</a>	    	trackinfo[0].length: 7081
<a class="l" name="852" href="#852">852</a>	    	trackinfo[0].timescale: 600
<a class="l" name="853" href="#853">853</a>	    	trackinfo[0].sampledescription.sampletype: avc1
<a class="l" name="854" href="#854">854</a>	    	trackinfo[0].language: und
<a class="l" name="855" href="#855">855</a>	    	trackinfo[1].length: 525312
<a class="l" name="856" href="#856">856</a>	    	trackinfo[1].timescale: 44100
<a class="l" name="857" href="#857">857</a>	    	trackinfo[1].sampledescription.sampletype: mp4a
<a class="l" name="858" href="#858">858</a>	    	trackinfo[1].language: und
<a class="l" name="859" href="#859">859</a>
<a class="hl" name="860" href="#860">860</a>	    chapters - As mentioned above information about chapters in audiobooks.
<a class="l" name="861" href="#861">861</a>	    seekpoints - As mentioned above times you can directly feed into NetStream.seek();
<a class="l" name="862" href="#862">862</a>	    videoframerate - The frame rate of the video if a monotone frame rate is used.
<a class="l" name="863" href="#863">863</a>	    		Most videos will have a monotone frame rate.
<a class="l" name="864" href="#864">864</a>	    audiosamplerate - The original sampling rate of the audio track.
<a class="l" name="865" href="#865">865</a>	    audiochannels - The original number of channels of the audio track.
<a class="l" name="866" href="#866">866</a>	    tags - As mentioned above ID3 like tag information.
<a class="l" name="867" href="#867">867</a>	 * &lt;/pre&gt;
<a class="l" name="868" href="#868">868</a>	 * Info from
<a class="l" name="869" href="#869">869</a>	 * &lt;pre&gt;
<a class="hl" name="870" href="#870">870</a>		width: Display width in pixels.
<a class="l" name="871" href="#871">871</a>		height: Display height in pixels.
<a class="l" name="872" href="#872">872</a>		duration: Duration in seconds.
<a class="l" name="873" href="#873">873</a>		avcprofile: AVC profile number such as 55, 77, 100 etc.
<a class="l" name="874" href="#874">874</a>		avclevel: AVC IDC level number such as 10, 11, 20, 21 etc.
<a class="l" name="875" href="#875">875</a>		aacaot: AAC audio object type; 0, 1 or 2 are supported.
<a class="l" name="876" href="#876">876</a>		videoframerate: Frame rate of the video in this MP4.
<a class="l" name="877" href="#877">877</a>		seekpoints: Array that lists the available keyframes in a file as time stamps in milliseconds.
<a class="l" name="878" href="#878">878</a>				This is optional as the MP4 file might not contain this information. Generally speaking,
<a class="l" name="879" href="#879">879</a>				most MP4 files will include this by default.
<a class="hl" name="880" href="#880">880</a>		videocodecid: Usually a string such as "avc1" or "VP6F."
<a class="l" name="881" href="#881">881</a>		audiocodecid: Usually a string such as ".mp3" or "mp4a."
<a class="l" name="882" href="#882">882</a>		progressivedownloadinfo: Object that provides information from the "pdin" atom. This is optional
<a class="l" name="883" href="#883">883</a>				and many files will not have this field.
<a class="l" name="884" href="#884">884</a>		trackinfo: Object that provides information on all the tracks in the MP4 file, including their
<a class="l" name="885" href="#885">885</a>				sample description ID.
<a class="l" name="886" href="#886">886</a>		tags: Array of key value pairs representing the information present in the "ilst" atom, which is
<a class="l" name="887" href="#887">887</a>				the equivalent of ID3 tags for MP4 files. These tags are mostly used by iTunes.
<a class="l" name="888" href="#888">888</a>	 * &lt;/pre&gt;
<a class="l" name="889" href="#889">889</a>	 *
<a class="hl" name="890" href="#890">890</a>	 * <strong>@return</strong>         Metadata event tag
<a class="l" name="891" href="#891">891</a>	 */</span>
<a class="l" name="892" href="#892">892</a>	<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a class="xmt" name="createFileMeta"/><a href="/source/s?refs=createFileMeta&amp;project=rtmp_client" class="xmt">createFileMeta</a>() {
<a class="l" name="893" href="#893">893</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Creating onMetaData"</span>);
<a class="l" name="894" href="#894">894</a>		<span class="c">// Create tag for onMetaData event</span>
<a class="l" name="895" href="#895">895</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">1024</span>);
<a class="l" name="896" href="#896">896</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="897" href="#897">897</a>		<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <b>new</b> <a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="898" href="#898">898</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=writeString&amp;project=rtmp_client">writeString</a>(<span class="s">"onMetaData"</span>);
<a class="l" name="899" href="#899">899</a>		<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=props&amp;project=rtmp_client">props</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="hl" name="900" href="#900">900</a>		<span class="c">// Duration property</span>
<a class="l" name="901" href="#901">901</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"duration"</span>, ((<b>double</b>) <a class="d" href="#duration">duration</a> / (<b>double</b>) <a class="d" href="#timeScale">timeScale</a>));
<a class="l" name="902" href="#902">902</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"width"</span>, <a class="d" href="#width">width</a>);
<a class="l" name="903" href="#903">903</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"height"</span>, <a class="d" href="#height">height</a>);
<a class="l" name="904" href="#904">904</a>
<a class="l" name="905" href="#905">905</a>		<span class="c">// Video codec id</span>
<a class="l" name="906" href="#906">906</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"videocodecid"</span>, <a href="/source/s?defs=videoCodecId&amp;project=rtmp_client">videoCodecId</a>);
<a class="l" name="907" href="#907">907</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"avcprofile"</span>, <a class="d" href="#avcProfile">avcProfile</a>);
<a class="l" name="908" href="#908">908</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"avclevel"</span>, <a class="d" href="#avcLevel">avcLevel</a>);
<a class="l" name="909" href="#909">909</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"videoframerate"</span>, <a class="d" href="#fps">fps</a>);
<a class="hl" name="910" href="#910">910</a>		<span class="c">// Audio codec id - watch for mp3 instead of aac</span>
<a class="l" name="911" href="#911">911</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"audiocodecid"</span>, <a href="/source/s?defs=audioCodecId&amp;project=rtmp_client">audioCodecId</a>);
<a class="l" name="912" href="#912">912</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"aacaot"</span>, <a class="d" href="#audioCodecType">audioCodecType</a>);
<a class="l" name="913" href="#913">913</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"audiosamplerate"</span>, <a class="d" href="#audioTimeScale">audioTimeScale</a>);
<a class="l" name="914" href="#914">914</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"audiochannels"</span>, <a class="d" href="#audioChannels">audioChannels</a>);
<a class="l" name="915" href="#915">915</a>
<a class="l" name="916" href="#916">916</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"moovposition"</span>, <a class="d" href="#moovOffset">moovOffset</a>);
<a class="l" name="917" href="#917">917</a>		<span class="c">//props.put("chapters", ""); //this is for f4b - books</span>
<a class="l" name="918" href="#918">918</a>		<b>if</b> (<a class="d" href="#seekPoints">seekPoints</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="919" href="#919">919</a>			<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"seekpoints"</span>, <a class="d" href="#seekPoints">seekPoints</a>);
<a class="hl" name="920" href="#920">920</a>		}
<a class="l" name="921" href="#921">921</a>		<span class="c">//tags will only appear if there is an "ilst" atom in the file</span>
<a class="l" name="922" href="#922">922</a>		<span class="c">//props.put("tags", "");</span>
<a class="l" name="923" href="#923">923</a>
<a class="l" name="924" href="#924">924</a>		<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;&gt; <a href="/source/s?defs=arr&amp;project=rtmp_client">arr</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;&gt;(<span class="n">2</span>);
<a class="l" name="925" href="#925">925</a>		<b>if</b> (<a class="d" href="#hasAudio">hasAudio</a>) {
<a class="l" name="926" href="#926">926</a>			<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=audioMap&amp;project=rtmp_client">audioMap</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;(<span class="n">4</span>);
<a class="l" name="927" href="#927">927</a>			<a href="/source/s?defs=audioMap&amp;project=rtmp_client">audioMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"timescale"</span>, <a class="d" href="#audioTimeScale">audioTimeScale</a>);
<a class="l" name="928" href="#928">928</a>			<a href="/source/s?defs=audioMap&amp;project=rtmp_client">audioMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"language"</span>, <span class="s">"und"</span>);
<a class="l" name="929" href="#929">929</a>
<a class="hl" name="930" href="#930">930</a>			<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt;&gt; <a href="/source/s?defs=desc&amp;project=rtmp_client">desc</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt;&gt;(<span class="n">1</span>);
<a class="l" name="931" href="#931">931</a>			<a href="/source/s?defs=audioMap&amp;project=rtmp_client">audioMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"sampledescription"</span>, <a href="/source/s?defs=desc&amp;project=rtmp_client">desc</a>);
<a class="l" name="932" href="#932">932</a>
<a class="l" name="933" href="#933">933</a>			<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt; <a href="/source/s?defs=sampleMap&amp;project=rtmp_client">sampleMap</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt;(<span class="n">1</span>);
<a class="l" name="934" href="#934">934</a>			<a href="/source/s?defs=sampleMap&amp;project=rtmp_client">sampleMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"sampletype"</span>, <a href="/source/s?defs=audioCodecId&amp;project=rtmp_client">audioCodecId</a>);
<a class="l" name="935" href="#935">935</a>			<a href="/source/s?defs=desc&amp;project=rtmp_client">desc</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=sampleMap&amp;project=rtmp_client">sampleMap</a>);
<a class="l" name="936" href="#936">936</a>
<a class="l" name="937" href="#937">937</a>			<b>if</b> (<a class="d" href="#audioSamples">audioSamples</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="938" href="#938">938</a>				<a href="/source/s?defs=audioMap&amp;project=rtmp_client">audioMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"length_property"</span>, <a class="d" href="#audioSampleDuration">audioSampleDuration</a> * <a class="d" href="#audioSamples">audioSamples</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>());
<a class="l" name="939" href="#939">939</a>				<span class="c">//release some memory, since we're done with the vectors</span>
<a class="hl" name="940" href="#940">940</a>				<a class="d" href="#audioSamples">audioSamples</a>.<a class="d" href="#clear">clear</a>();
<a class="l" name="941" href="#941">941</a>				<a class="d" href="#audioSamples">audioSamples</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="942" href="#942">942</a>			}
<a class="l" name="943" href="#943">943</a>
<a class="l" name="944" href="#944">944</a>			<a href="/source/s?defs=arr&amp;project=rtmp_client">arr</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=audioMap&amp;project=rtmp_client">audioMap</a>);
<a class="l" name="945" href="#945">945</a>
<a class="l" name="946" href="#946">946</a>		}
<a class="l" name="947" href="#947">947</a>		<b>if</b> (<a href="/source/s?defs=hasVideo&amp;project=rtmp_client">hasVideo</a>) {
<a class="l" name="948" href="#948">948</a>			<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=videoMap&amp;project=rtmp_client">videoMap</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;(<span class="n">3</span>);
<a class="l" name="949" href="#949">949</a>			<a href="/source/s?defs=videoMap&amp;project=rtmp_client">videoMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"timescale"</span>, <a class="d" href="#videoTimeScale">videoTimeScale</a>);
<a class="hl" name="950" href="#950">950</a>			<a href="/source/s?defs=videoMap&amp;project=rtmp_client">videoMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"language"</span>, <span class="s">"und"</span>);
<a class="l" name="951" href="#951">951</a>
<a class="l" name="952" href="#952">952</a>			<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt;&gt; <a href="/source/s?defs=desc&amp;project=rtmp_client">desc</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt;&gt;(<span class="n">1</span>);
<a class="l" name="953" href="#953">953</a>			<a href="/source/s?defs=videoMap&amp;project=rtmp_client">videoMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"sampledescription"</span>, <a href="/source/s?defs=desc&amp;project=rtmp_client">desc</a>);
<a class="l" name="954" href="#954">954</a>
<a class="l" name="955" href="#955">955</a>			<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt; <a href="/source/s?defs=sampleMap&amp;project=rtmp_client">sampleMap</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt;(<span class="n">1</span>);
<a class="l" name="956" href="#956">956</a>			<a href="/source/s?defs=sampleMap&amp;project=rtmp_client">sampleMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"sampletype"</span>, <a href="/source/s?defs=videoCodecId&amp;project=rtmp_client">videoCodecId</a>);
<a class="l" name="957" href="#957">957</a>			<a href="/source/s?defs=desc&amp;project=rtmp_client">desc</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=sampleMap&amp;project=rtmp_client">sampleMap</a>);
<a class="l" name="958" href="#958">958</a>
<a class="l" name="959" href="#959">959</a>			<b>if</b> (<a class="d" href="#videoSamples">videoSamples</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="960" href="#960">960</a>				<a href="/source/s?defs=videoMap&amp;project=rtmp_client">videoMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"length_property"</span>, <a class="d" href="#videoSampleDuration">videoSampleDuration</a> * <a class="d" href="#videoSamples">videoSamples</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>());
<a class="l" name="961" href="#961">961</a>				<span class="c">//release some memory, since we're done with the vectors</span>
<a class="l" name="962" href="#962">962</a>				<a class="d" href="#videoSamples">videoSamples</a>.<a class="d" href="#clear">clear</a>();
<a class="l" name="963" href="#963">963</a>				<a class="d" href="#videoSamples">videoSamples</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="964" href="#964">964</a>			}
<a class="l" name="965" href="#965">965</a>
<a class="l" name="966" href="#966">966</a>			<a href="/source/s?defs=arr&amp;project=rtmp_client">arr</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=videoMap&amp;project=rtmp_client">videoMap</a>);
<a class="l" name="967" href="#967">967</a>
<a class="l" name="968" href="#968">968</a>		}
<a class="l" name="969" href="#969">969</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"trackinfo"</span>, <a href="/source/s?defs=arr&amp;project=rtmp_client">arr</a>);
<a class="hl" name="970" href="#970">970</a>		<span class="c">//set this based on existence of seekpoints</span>
<a class="l" name="971" href="#971">971</a>		<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"canSeekToEnd"</span>, (<a class="d" href="#seekPoints">seekPoints</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>));
<a class="l" name="972" href="#972">972</a>
<a class="l" name="973" href="#973">973</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=writeMap&amp;project=rtmp_client">writeMap</a>(<a href="/source/s?defs=props&amp;project=rtmp_client">props</a>, <b>new</b> <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>());
<a class="l" name="974" href="#974">974</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="975" href="#975">975</a>
<a class="l" name="976" href="#976">976</a>		<span class="c">//now that all the meta properties are done, update the duration</span>
<a class="l" name="977" href="#977">977</a>		<a class="d" href="#duration">duration</a> = <a href="/source/s?defs=Math&amp;project=rtmp_client">Math</a>.<a href="/source/s?defs=round&amp;project=rtmp_client">round</a>(<a class="d" href="#duration">duration</a> * <span class="n">1000d</span>);
<a class="l" name="978" href="#978">978</a>
<a class="l" name="979" href="#979">979</a>		<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>new</b> <a href="/source/s?defs=Tag&amp;project=rtmp_client">Tag</a>(<a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=TYPE_METADATA&amp;project=rtmp_client">TYPE_METADATA</a>, <span class="n">0</span>, <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(), <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <span class="n">0</span>);
<a class="hl" name="980" href="#980">980</a>		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=setBody&amp;project=rtmp_client">setBody</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="981" href="#981">981</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="982" href="#982">982</a>	}
<a class="l" name="983" href="#983">983</a>
<a class="l" name="984" href="#984">984</a>	<span class="c">/**
<a class="l" name="985" href="#985">985</a>	 * Tag sequence
<a class="l" name="986" href="#986">986</a>	 * MetaData, Video config, Audio config, remaining audio and video
<a class="l" name="987" href="#987">987</a>	 *
<a class="l" name="988" href="#988">988</a>	 * Packet prefixes:
<a class="l" name="989" href="#989">989</a>	 * 17 00 00 00 00 = Video extra data (first video packet)
<a class="hl" name="990" href="#990">990</a>	 * 17 01 00 00 00 = Video keyframe
<a class="l" name="991" href="#991">991</a>	 * 27 01 00 00 00 = Video interframe
<a class="l" name="992" href="#992">992</a>	 * af 00 ...   06 = Audio extra data (first audio packet)
<a class="l" name="993" href="#993">993</a>	 * af 01          = Audio frame
<a class="l" name="994" href="#994">994</a>	 *
<a class="l" name="995" href="#995">995</a>	 * Audio extra data(s):
<a class="l" name="996" href="#996">996</a>	 * af 00                = Prefix
<a class="l" name="997" href="#997">997</a>	 * 11 90 4f 14          = AAC Main   = aottype 0
<a class="l" name="998" href="#998">998</a>	 * 12 10                = AAC LC     = aottype 1
<a class="l" name="999" href="#999">999</a>	 * 13 90 56 e5 a5 48 00 = HE-AAC SBR = aottype 2
<a class="hl" name="1000" href="#1000">1000</a>	 * 06                   = Suffix
<a class="l" name="1001" href="#1001">1001</a>	 *
<a class="l" name="1002" href="#1002">1002</a>	 * Still not absolutely certain about this order or the bytes - need to verify later
<a class="l" name="1003" href="#1003">1003</a>	 */</span>
<a class="l" name="1004" href="#1004">1004</a>	<b>private</b> <b>void</b> <a class="xmt" name="createPreStreamingTags"/><a href="/source/s?refs=createPreStreamingTags&amp;project=rtmp_client" class="xmt">createPreStreamingTags</a>(<b>int</b> <a class="xa" name="timestamp"/><a href="/source/s?refs=timestamp&amp;project=rtmp_client" class="xa">timestamp</a>, <b>boolean</b> <a class="xa" name="clear"/><a href="/source/s?refs=clear&amp;project=rtmp_client" class="xa">clear</a>) {
<a class="l" name="1005" href="#1005">1005</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Creating pre-streaming tags"</span>);
<a class="l" name="1006" href="#1006">1006</a>		<b>if</b> (<a class="d" href="#clear">clear</a>) {
<a class="l" name="1007" href="#1007">1007</a>			<a class="d" href="#firstTags">firstTags</a>.<a class="d" href="#clear">clear</a>();
<a class="l" name="1008" href="#1008">1008</a>		}
<a class="l" name="1009" href="#1009">1009</a>		<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="hl" name="1010" href="#1010">1010</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=body&amp;project=rtmp_client">body</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="1011" href="#1011">1011</a>
<a class="l" name="1012" href="#1012">1012</a>		<b>if</b> (<a href="/source/s?defs=hasVideo&amp;project=rtmp_client">hasVideo</a>) {
<a class="l" name="1013" href="#1013">1013</a>			<span class="c">//video tag #1</span>
<a class="l" name="1014" href="#1014">1014</a>			<span class="c">//TODO: this data is only for backcountry bombshells - make this dynamic</span>
<a class="l" name="1015" href="#1015">1015</a>			<a href="/source/s?defs=body&amp;project=rtmp_client">body</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">41</span>);
<a class="l" name="1016" href="#1016">1016</a>			<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="1017" href="#1017">1017</a>			<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#PREFIX_VIDEO_CONFIG_FRAME">PREFIX_VIDEO_CONFIG_FRAME</a>); <span class="c">//prefix</span>
<a class="l" name="1018" href="#1018">1018</a>			<b>if</b> (<a class="d" href="#videoDecoderBytes">videoDecoderBytes</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="1019" href="#1019">1019</a>				<span class="c">//because of other processing we do this check</span>
<a class="hl" name="1020" href="#1020">1020</a><span class="c">//				if (log.isDebugEnabled()) {</span>
<a class="l" name="1021" href="#1021">1021</a><span class="c">//					log.debug("Video decoder bytes: {}", HexDump.byteArrayToHexString(videoDecoderBytes));</span>
<a class="l" name="1022" href="#1022">1022</a><span class="c">//					try {</span>
<a class="l" name="1023" href="#1023">1023</a><span class="c">//						log.debug("Video bytes data: {}", new String(videoDecoderBytes, "UTF-8"));</span>
<a class="l" name="1024" href="#1024">1024</a><span class="c">//					} catch (UnsupportedEncodingException e) {</span>
<a class="l" name="1025" href="#1025">1025</a><span class="c">//						log.error("", e);</span>
<a class="l" name="1026" href="#1026">1026</a><span class="c">//					}</span>
<a class="l" name="1027" href="#1027">1027</a><span class="c">//				}</span>
<a class="l" name="1028" href="#1028">1028</a>				<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#videoDecoderBytes">videoDecoderBytes</a>);
<a class="l" name="1029" href="#1029">1029</a>			}
<a class="hl" name="1030" href="#1030">1030</a>			<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a> = <b>new</b> <a href="/source/s?defs=Tag&amp;project=rtmp_client">Tag</a>(<a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=TYPE_VIDEO&amp;project=rtmp_client">TYPE_VIDEO</a>, <a class="d" href="#timestamp">timestamp</a>, <a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a class="d" href="#position">position</a>(), <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <span class="n">0</span>);
<a class="l" name="1031" href="#1031">1031</a>			<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="1032" href="#1032">1032</a>			<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=setBody&amp;project=rtmp_client">setBody</a>(<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>);
<a class="l" name="1033" href="#1033">1033</a>			<span class="c">//add tag</span>
<a class="l" name="1034" href="#1034">1034</a>			<a class="d" href="#firstTags">firstTags</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>);
<a class="l" name="1035" href="#1035">1035</a>		}
<a class="l" name="1036" href="#1036">1036</a>
<a class="l" name="1037" href="#1037">1037</a>		<b>if</b> (<a class="d" href="#hasAudio">hasAudio</a>) {
<a class="l" name="1038" href="#1038">1038</a>			<span class="c">//audio tag #1</span>
<a class="l" name="1039" href="#1039">1039</a>			<span class="c">//TODO: this data is only for backcountry bombshells - make this dynamic</span>
<a class="hl" name="1040" href="#1040">1040</a>			<a href="/source/s?defs=body&amp;project=rtmp_client">body</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">7</span>);
<a class="l" name="1041" href="#1041">1041</a>			<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="1042" href="#1042">1042</a>			<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<b>new</b> <b>byte</b>[] { (<b>byte</b>) <span class="n">0xaf</span>, (<b>byte</b>) <span class="n">0</span> }); <span class="c">//prefix</span>
<a class="l" name="1043" href="#1043">1043</a>			<b>if</b> (<a class="d" href="#audioDecoderBytes">audioDecoderBytes</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="1044" href="#1044">1044</a>				<span class="c">//because of other processing we do this check</span>
<a class="l" name="1045" href="#1045">1045</a><span class="c">//				if (log.isDebugEnabled()) {</span>
<a class="l" name="1046" href="#1046">1046</a><span class="c">//					log.debug("Audio decoder bytes: {}", HexDump.byteArrayToHexString(audioDecoderBytes));</span>
<a class="l" name="1047" href="#1047">1047</a><span class="c">//					try {</span>
<a class="l" name="1048" href="#1048">1048</a><span class="c">//						log.debug("Audio bytes data: {}", new String(audioDecoderBytes, "UTF-8"));</span>
<a class="l" name="1049" href="#1049">1049</a><span class="c">//					} catch (UnsupportedEncodingException e) {</span>
<a class="hl" name="1050" href="#1050">1050</a><span class="c">//						log.error("", e);</span>
<a class="l" name="1051" href="#1051">1051</a><span class="c">//					}</span>
<a class="l" name="1052" href="#1052">1052</a><span class="c">//				}</span>
<a class="l" name="1053" href="#1053">1053</a>				<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#audioDecoderBytes">audioDecoderBytes</a>);
<a class="l" name="1054" href="#1054">1054</a>			} <b>else</b> {
<a class="l" name="1055" href="#1055">1055</a>				<span class="c">//default to aac-lc when the esds doesnt contain descripter bytes</span>
<a class="l" name="1056" href="#1056">1056</a>				<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#AUDIO_CONFIG_FRAME_AAC_LC">AUDIO_CONFIG_FRAME_AAC_LC</a>);
<a class="l" name="1057" href="#1057">1057</a>			}
<a class="l" name="1058" href="#1058">1058</a>			<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) <span class="n">0x06</span>); <span class="c">//suffix</span>
<a class="l" name="1059" href="#1059">1059</a>			<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a> = <b>new</b> <a href="/source/s?defs=Tag&amp;project=rtmp_client">Tag</a>(<a href="/source/s?defs=IoConstants&amp;project=rtmp_client">IoConstants</a>.<a href="/source/s?defs=TYPE_AUDIO&amp;project=rtmp_client">TYPE_AUDIO</a>, <a class="d" href="#timestamp">timestamp</a>, <a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a class="d" href="#position">position</a>(), <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getBodySize&amp;project=rtmp_client">getBodySize</a>());
<a class="hl" name="1060" href="#1060">1060</a>			<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="1061" href="#1061">1061</a>			<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=setBody&amp;project=rtmp_client">setBody</a>(<a href="/source/s?defs=body&amp;project=rtmp_client">body</a>);
<a class="l" name="1062" href="#1062">1062</a>			<span class="c">//add tag</span>
<a class="l" name="1063" href="#1063">1063</a>			<a class="d" href="#firstTags">firstTags</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>);
<a class="l" name="1064" href="#1064">1064</a>		}
<a class="l" name="1065" href="#1065">1065</a>	}
<a class="l" name="1066" href="#1066">1066</a>
<a class="l" name="1067" href="#1067">1067</a>	<span class="c">/**
<a class="l" name="1068" href="#1068">1068</a>	 * Packages media data for return to providers
<a class="l" name="1069" href="#1069">1069</a>	 */</span>
<a class="hl" name="1070" href="#1070">1070</a>	<b>public</b> <b>synchronized</b> <a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a class="xmt" name="readTag"/><a href="/source/s?refs=readTag&amp;project=rtmp_client" class="xmt">readTag</a>() {
<a class="l" name="1071" href="#1071">1071</a>		<span class="c">//log.debug("Read tag");</span>
<a class="l" name="1072" href="#1072">1072</a>		<span class="c">//empty-out the pre-streaming tags first</span>
<a class="l" name="1073" href="#1073">1073</a>		<b>if</b> (!<a class="d" href="#firstTags">firstTags</a>.<a href="/source/s?defs=isEmpty&amp;project=rtmp_client">isEmpty</a>()) {
<a class="l" name="1074" href="#1074">1074</a>			<span class="c">//log.debug("Returning pre-tag");</span>
<a class="l" name="1075" href="#1075">1075</a>			<span class="c">// Return first tags before media data</span>
<a class="l" name="1076" href="#1076">1076</a>			<b>return</b> <a class="d" href="#firstTags">firstTags</a>.<a href="/source/s?defs=removeFirst&amp;project=rtmp_client">removeFirst</a>();
<a class="l" name="1077" href="#1077">1077</a>		}
<a class="l" name="1078" href="#1078">1078</a>		<span class="c">//log.debug("Read tag - sample {} prevFrameSize {} audio: {} video: {}", new Object[]{currentSample, prevFrameSize, audioCount, videoCount});</span>
<a class="l" name="1079" href="#1079">1079</a>
<a class="hl" name="1080" href="#1080">1080</a>		<span class="c">//get the current frame</span>
<a class="l" name="1081" href="#1081">1081</a>		<a href="/source/s?defs=MP4Frame&amp;project=rtmp_client">MP4Frame</a> <a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a> = <a class="d" href="#frames">frames</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a class="d" href="#currentFrame">currentFrame</a>);
<a class="l" name="1082" href="#1082">1082</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Playback #{} {}"</span>, <a class="d" href="#currentFrame">currentFrame</a>, <a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>);
<a class="l" name="1083" href="#1083">1083</a>
<a class="l" name="1084" href="#1084">1084</a>		<b>int</b> <a href="/source/s?defs=sampleSize&amp;project=rtmp_client">sampleSize</a> = <a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>();
<a class="l" name="1085" href="#1085">1085</a>
<a class="l" name="1086" href="#1086">1086</a>		<b>int</b> <a href="/source/s?defs=time&amp;project=rtmp_client">time</a> = (<b>int</b>) <a href="/source/s?defs=Math&amp;project=rtmp_client">Math</a>.<a href="/source/s?defs=round&amp;project=rtmp_client">round</a>(<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=getTime&amp;project=rtmp_client">getTime</a>() * <span class="n">1000.0</span>);
<a class="l" name="1087" href="#1087">1087</a>		<span class="c">//log.debug("Read tag - dst: {} base: {} time: {}", new Object[]{frameTs, baseTs, time});</span>
<a class="l" name="1088" href="#1088">1088</a>
<a class="l" name="1089" href="#1089">1089</a>		<b>long</b> <a href="/source/s?defs=samplePos&amp;project=rtmp_client">samplePos</a> = <a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a class="d" href="#getOffset">getOffset</a>();
<a class="hl" name="1090" href="#1090">1090</a>		<span class="c">//log.debug("Read tag - samplePos {}", samplePos);</span>
<a class="l" name="1091" href="#1091">1091</a>
<a class="l" name="1092" href="#1092">1092</a>		<span class="c">//determine frame type and packet body padding</span>
<a class="l" name="1093" href="#1093">1093</a>		<b>byte</b> <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=getType&amp;project=rtmp_client">getType</a>();
<a class="l" name="1094" href="#1094">1094</a>		<span class="c">//assume video type</span>
<a class="l" name="1095" href="#1095">1095</a>		<b>int</b> <a href="/source/s?defs=pad&amp;project=rtmp_client">pad</a> = <span class="n">5</span>;
<a class="l" name="1096" href="#1096">1096</a>		<b>if</b> (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> == <a href="/source/s?defs=TYPE_AUDIO&amp;project=rtmp_client">TYPE_AUDIO</a>) {
<a class="l" name="1097" href="#1097">1097</a>			<a href="/source/s?defs=pad&amp;project=rtmp_client">pad</a> = <span class="n">2</span>;
<a class="l" name="1098" href="#1098">1098</a>		}
<a class="l" name="1099" href="#1099">1099</a>
<a class="hl" name="1100" href="#1100">1100</a>		<span class="c">//create a byte buffer of the size of the sample</span>
<a class="l" name="1101" href="#1101">1101</a>		<a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a> <a href="/source/s?defs=data&amp;project=rtmp_client">data</a> = <a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<a href="/source/s?defs=sampleSize&amp;project=rtmp_client">sampleSize</a> + <a href="/source/s?defs=pad&amp;project=rtmp_client">pad</a>);
<a class="l" name="1102" href="#1102">1102</a>		<b>try</b> {
<a class="l" name="1103" href="#1103">1103</a>			<span class="c">//prefix is different for keyframes</span>
<a class="l" name="1104" href="#1104">1104</a>			<b>if</b> (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> == <a href="/source/s?defs=TYPE_VIDEO&amp;project=rtmp_client">TYPE_VIDEO</a>) {
<a class="l" name="1105" href="#1105">1105</a>				<b>if</b> (<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=isKeyFrame&amp;project=rtmp_client">isKeyFrame</a>()) {
<a class="l" name="1106" href="#1106">1106</a>					<span class="c">//log.debug("Writing keyframe prefix");</span>
<a class="l" name="1107" href="#1107">1107</a>					<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#PREFIX_VIDEO_KEYFRAME">PREFIX_VIDEO_KEYFRAME</a>);
<a class="l" name="1108" href="#1108">1108</a>				} <b>else</b> {
<a class="l" name="1109" href="#1109">1109</a>					<span class="c">//log.debug("Writing interframe prefix");</span>
<a class="hl" name="1110" href="#1110">1110</a>					<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#PREFIX_VIDEO_FRAME">PREFIX_VIDEO_FRAME</a>);
<a class="l" name="1111" href="#1111">1111</a>				}
<a class="l" name="1112" href="#1112">1112</a>				<span class="c">// match the sample with its ctts / mdhd adjustment time</span>
<a class="l" name="1113" href="#1113">1113</a>				<b>int</b> <a href="/source/s?defs=timeOffset&amp;project=rtmp_client">timeOffset</a> = <a class="d" href="#prevVideoTS">prevVideoTS</a> != -<span class="n">1</span> ? <a href="/source/s?defs=time&amp;project=rtmp_client">time</a> - <a class="d" href="#prevVideoTS">prevVideoTS</a> : <span class="n">0</span>;
<a class="l" name="1114" href="#1114">1114</a>				<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) ((<a href="/source/s?defs=timeOffset&amp;project=rtmp_client">timeOffset</a> &gt;&gt;&gt; <span class="n">16</span>) &amp; <span class="n">0xff</span>));
<a class="l" name="1115" href="#1115">1115</a>				<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) ((<a href="/source/s?defs=timeOffset&amp;project=rtmp_client">timeOffset</a> &gt;&gt;&gt; <span class="n">8</span>) &amp; <span class="n">0xff</span>));
<a class="l" name="1116" href="#1116">1116</a>				<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) (<a href="/source/s?defs=timeOffset&amp;project=rtmp_client">timeOffset</a> &amp; <span class="n">0xff</span>));
<a class="l" name="1117" href="#1117">1117</a>				<b>if</b> (<a class="d" href="#log">log</a>.<a href="/source/s?defs=isTraceEnabled&amp;project=rtmp_client">isTraceEnabled</a>()) {
<a class="l" name="1118" href="#1118">1118</a>					<b>byte</b>[] <a href="/source/s?defs=prefix&amp;project=rtmp_client">prefix</a> = <b>new</b> <b>byte</b>[<span class="n">5</span>];
<a class="l" name="1119" href="#1119">1119</a>					<b>int</b> p = <a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a class="d" href="#position">position</a>();
<a class="hl" name="1120" href="#1120">1120</a>					<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a class="d" href="#position">position</a>(<span class="n">0</span>);
<a class="l" name="1121" href="#1121">1121</a>					<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=prefix&amp;project=rtmp_client">prefix</a>);
<a class="l" name="1122" href="#1122">1122</a>					<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a class="d" href="#position">position</a>(p);
<a class="l" name="1123" href="#1123">1123</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"{}"</span>, <a href="/source/s?defs=prefix&amp;project=rtmp_client">prefix</a>);
<a class="l" name="1124" href="#1124">1124</a>				}
<a class="l" name="1125" href="#1125">1125</a>				<span class="c">// track video frame count</span>
<a class="l" name="1126" href="#1126">1126</a>				<a class="d" href="#videoCount">videoCount</a>++;
<a class="l" name="1127" href="#1127">1127</a>				<a class="d" href="#prevVideoTS">prevVideoTS</a> = <a href="/source/s?defs=time&amp;project=rtmp_client">time</a>;
<a class="l" name="1128" href="#1128">1128</a>			} <b>else</b> {
<a class="l" name="1129" href="#1129">1129</a>				<span class="c">//log.debug("Writing audio prefix");</span>
<a class="hl" name="1130" href="#1130">1130</a>				<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#PREFIX_AUDIO_FRAME">PREFIX_AUDIO_FRAME</a>);
<a class="l" name="1131" href="#1131">1131</a>				<span class="c">// track audio frame count</span>
<a class="l" name="1132" href="#1132">1132</a>				<a class="d" href="#audioCount">audioCount</a>++;
<a class="l" name="1133" href="#1133">1133</a>			}
<a class="l" name="1134" href="#1134">1134</a>			<span class="c">//do we need to add the mdat offset to the sample position?</span>
<a class="l" name="1135" href="#1135">1135</a>			<a class="d" href="#channel">channel</a>.<a class="d" href="#position">position</a>(<a href="/source/s?defs=samplePos&amp;project=rtmp_client">samplePos</a>);
<a class="l" name="1136" href="#1136">1136</a>			<a class="d" href="#channel">channel</a>.<a href="/source/s?defs=read&amp;project=rtmp_client">read</a>(<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>);
<a class="l" name="1137" href="#1137">1137</a>		} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> e) {
<a class="l" name="1138" href="#1138">1138</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error on channel position / read"</span>, e);
<a class="l" name="1139" href="#1139">1139</a>		}
<a class="hl" name="1140" href="#1140">1140</a>		<span class="c">//chunk the data</span>
<a class="l" name="1141" href="#1141">1141</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=payload&amp;project=rtmp_client">payload</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=wrap&amp;project=rtmp_client">wrap</a>(<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>());
<a class="l" name="1142" href="#1142">1142</a>		<span class="c">//create the tag</span>
<a class="l" name="1143" href="#1143">1143</a>		<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a> = <b>new</b> <a href="/source/s?defs=Tag&amp;project=rtmp_client">Tag</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>, <a href="/source/s?defs=time&amp;project=rtmp_client">time</a>, <a href="/source/s?defs=payload&amp;project=rtmp_client">payload</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(), <a href="/source/s?defs=payload&amp;project=rtmp_client">payload</a>, <a class="d" href="#prevFrameSize">prevFrameSize</a>);
<a class="l" name="1144" href="#1144">1144</a>		<span class="c">//log.debug("Read tag - type: {} body size: {}", (type == TYPE_AUDIO ? "Audio" : "Video"), tag.getBodySize());</span>
<a class="l" name="1145" href="#1145">1145</a>		<span class="c">//increment the frame number</span>
<a class="l" name="1146" href="#1146">1146</a>		<a class="d" href="#currentFrame">currentFrame</a>++;
<a class="l" name="1147" href="#1147">1147</a>		<span class="c">//set the frame / tag size</span>
<a class="l" name="1148" href="#1148">1148</a>		<a class="d" href="#prevFrameSize">prevFrameSize</a> = <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getBodySize&amp;project=rtmp_client">getBodySize</a>();
<a class="l" name="1149" href="#1149">1149</a>		<span class="c">//log.debug("Tag: {}", tag);</span>
<a class="hl" name="1150" href="#1150">1150</a>		<b>return</b> <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>;
<a class="l" name="1151" href="#1151">1151</a>	}
<a class="l" name="1152" href="#1152">1152</a>
<a class="l" name="1153" href="#1153">1153</a>	<span class="c">/**
<a class="l" name="1154" href="#1154">1154</a>	 * Performs frame analysis and generates metadata for use in seeking. All the frames
<a class="l" name="1155" href="#1155">1155</a>	 * are analyzed and sorted together based on time and offset.
<a class="l" name="1156" href="#1156">1156</a>	 */</span>
<a class="l" name="1157" href="#1157">1157</a>	<b>public</b> <b>void</b> <a class="xmt" name="analyzeFrames"/><a href="/source/s?refs=analyzeFrames&amp;project=rtmp_client" class="xmt">analyzeFrames</a>() {
<a class="l" name="1158" href="#1158">1158</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Analyzing frames"</span>);
<a class="l" name="1159" href="#1159">1159</a>		<span class="c">// Maps positions, samples, timestamps to one another</span>
<a class="hl" name="1160" href="#1160">1160</a>		<a class="d" href="#timePosMap">timePosMap</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt;();
<a class="l" name="1161" href="#1161">1161</a>		<a class="d" href="#samplePosMap">samplePosMap</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt;();
<a class="l" name="1162" href="#1162">1162</a>		<span class="c">// tag == sample</span>
<a class="l" name="1163" href="#1163">1163</a>		<b>int</b> <a href="/source/s?defs=sample&amp;project=rtmp_client">sample</a> = <span class="n">1</span>;
<a class="l" name="1164" href="#1164">1164</a>		<span class="c">// position</span>
<a class="l" name="1165" href="#1165">1165</a>		<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a> <a class="d" href="#pos">pos</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="1166" href="#1166">1166</a>		<span class="c">// if audio-only, skip this</span>
<a class="l" name="1167" href="#1167">1167</a>		<b>if</b> (<a class="d" href="#videoSamplesToChunks">videoSamplesToChunks</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="1168" href="#1168">1168</a>			<span class="c">// handle composite times</span>
<a class="l" name="1169" href="#1169">1169</a>			<b>int</b> <a href="/source/s?defs=compositeIndex&amp;project=rtmp_client">compositeIndex</a> = <span class="n">0</span>;
<a class="hl" name="1170" href="#1170">1170</a>			<a href="/source/s?defs=CompositionTimeSampleRecord&amp;project=rtmp_client">CompositionTimeSampleRecord</a> <a href="/source/s?defs=compositeTimeEntry&amp;project=rtmp_client">compositeTimeEntry</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="1171" href="#1171">1171</a>			<b>if</b> (<a class="d" href="#compositionTimes">compositionTimes</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; !<a class="d" href="#compositionTimes">compositionTimes</a>.<a href="/source/s?defs=isEmpty&amp;project=rtmp_client">isEmpty</a>()) {
<a class="l" name="1172" href="#1172">1172</a>				<a href="/source/s?defs=compositeTimeEntry&amp;project=rtmp_client">compositeTimeEntry</a> = <a class="d" href="#compositionTimes">compositionTimes</a>.<a href="/source/s?defs=remove&amp;project=rtmp_client">remove</a>(<span class="n">0</span>);
<a class="l" name="1173" href="#1173">1173</a>			}
<a class="l" name="1174" href="#1174">1174</a>			<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#videoSamplesToChunks">videoSamplesToChunks</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>(); i++) {
<a class="l" name="1175" href="#1175">1175</a>				<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=Record&amp;project=rtmp_client">Record</a> <a href="/source/s?defs=record&amp;project=rtmp_client">record</a> = <a class="d" href="#videoSamplesToChunks">videoSamplesToChunks</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(i);
<a class="l" name="1176" href="#1176">1176</a>				<b>int</b> <a href="/source/s?defs=firstChunk&amp;project=rtmp_client">firstChunk</a> = <a href="/source/s?defs=record&amp;project=rtmp_client">record</a>.<a href="/source/s?defs=getFirstChunk&amp;project=rtmp_client">getFirstChunk</a>();
<a class="l" name="1177" href="#1177">1177</a>				<b>int</b> <a href="/source/s?defs=lastChunk&amp;project=rtmp_client">lastChunk</a> = <a class="d" href="#videoChunkOffsets">videoChunkOffsets</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>();
<a class="l" name="1178" href="#1178">1178</a>				<b>if</b> (i &lt; <a class="d" href="#videoSamplesToChunks">videoSamplesToChunks</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>() - <span class="n">1</span>) {
<a class="l" name="1179" href="#1179">1179</a>					<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=Record&amp;project=rtmp_client">Record</a> <a href="/source/s?defs=nextRecord&amp;project=rtmp_client">nextRecord</a> = <a class="d" href="#videoSamplesToChunks">videoSamplesToChunks</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(i + <span class="n">1</span>);
<a class="hl" name="1180" href="#1180">1180</a>					<a href="/source/s?defs=lastChunk&amp;project=rtmp_client">lastChunk</a> = <a href="/source/s?defs=nextRecord&amp;project=rtmp_client">nextRecord</a>.<a href="/source/s?defs=getFirstChunk&amp;project=rtmp_client">getFirstChunk</a>() - <span class="n">1</span>;
<a class="l" name="1181" href="#1181">1181</a>				}
<a class="l" name="1182" href="#1182">1182</a>				<b>for</b> (<b>int</b> <a href="/source/s?defs=chunk&amp;project=rtmp_client">chunk</a> = <a href="/source/s?defs=firstChunk&amp;project=rtmp_client">firstChunk</a>; <a href="/source/s?defs=chunk&amp;project=rtmp_client">chunk</a> &lt;= <a href="/source/s?defs=lastChunk&amp;project=rtmp_client">lastChunk</a>; <a href="/source/s?defs=chunk&amp;project=rtmp_client">chunk</a>++) {
<a class="l" name="1183" href="#1183">1183</a>					<b>int</b> <a href="/source/s?defs=sampleCount&amp;project=rtmp_client">sampleCount</a> = <a href="/source/s?defs=record&amp;project=rtmp_client">record</a>.<a href="/source/s?defs=getSamplesPerChunk&amp;project=rtmp_client">getSamplesPerChunk</a>();
<a class="l" name="1184" href="#1184">1184</a>					<a class="d" href="#pos">pos</a> = <a class="d" href="#videoChunkOffsets">videoChunkOffsets</a>.<a href="/source/s?defs=elementAt&amp;project=rtmp_client">elementAt</a>(<a href="/source/s?defs=chunk&amp;project=rtmp_client">chunk</a> - <span class="n">1</span>);
<a class="l" name="1185" href="#1185">1185</a>					<b>while</b> (<a href="/source/s?defs=sampleCount&amp;project=rtmp_client">sampleCount</a> &gt; <span class="n">0</span>) {
<a class="l" name="1186" href="#1186">1186</a>						<span class="c">//log.debug("Position: {}", pos);</span>
<a class="l" name="1187" href="#1187">1187</a>						<a class="d" href="#samplePosMap">samplePosMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=sample&amp;project=rtmp_client">sample</a>, <a class="d" href="#pos">pos</a>);
<a class="l" name="1188" href="#1188">1188</a>						<span class="c">//calculate ts</span>
<a class="l" name="1189" href="#1189">1189</a>						<b>double</b> <a href="/source/s?defs=ts&amp;project=rtmp_client">ts</a> = (<a class="d" href="#videoSampleDuration">videoSampleDuration</a> * (<a href="/source/s?defs=sample&amp;project=rtmp_client">sample</a> - <span class="n">1</span>)) / <a class="d" href="#videoTimeScale">videoTimeScale</a>;
<a class="hl" name="1190" href="#1190">1190</a>						<span class="c">//check to see if the sample is a keyframe</span>
<a class="l" name="1191" href="#1191">1191</a>						<b>boolean</b> <a href="/source/s?defs=keyframe&amp;project=rtmp_client">keyframe</a> = <b>false</b>;
<a class="l" name="1192" href="#1192">1192</a>						<span class="c">//some files appear not to have sync samples</span>
<a class="l" name="1193" href="#1193">1193</a>						<b>if</b> (<a class="d" href="#syncSamples">syncSamples</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="1194" href="#1194">1194</a>							<a href="/source/s?defs=keyframe&amp;project=rtmp_client">keyframe</a> = <a class="d" href="#syncSamples">syncSamples</a>.<a href="/source/s?defs=contains&amp;project=rtmp_client">contains</a>(<a href="/source/s?defs=sample&amp;project=rtmp_client">sample</a>);
<a class="l" name="1195" href="#1195">1195</a>							<b>if</b> (<a class="d" href="#seekPoints">seekPoints</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="1196" href="#1196">1196</a>								<a class="d" href="#seekPoints">seekPoints</a> = <b>new</b> <a href="/source/s?defs=LinkedList&amp;project=rtmp_client">LinkedList</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt;();
<a class="l" name="1197" href="#1197">1197</a>							}
<a class="l" name="1198" href="#1198">1198</a>							<b>int</b> <a href="/source/s?defs=keyframeTs&amp;project=rtmp_client">keyframeTs</a> = (<b>int</b>) <a href="/source/s?defs=Math&amp;project=rtmp_client">Math</a>.<a href="/source/s?defs=round&amp;project=rtmp_client">round</a>(<a href="/source/s?defs=ts&amp;project=rtmp_client">ts</a> * <span class="n">1000.0</span>);
<a class="l" name="1199" href="#1199">1199</a>							<a class="d" href="#seekPoints">seekPoints</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=keyframeTs&amp;project=rtmp_client">keyframeTs</a>);
<a class="hl" name="1200" href="#1200">1200</a>							<a class="d" href="#timePosMap">timePosMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=keyframeTs&amp;project=rtmp_client">keyframeTs</a>, <a class="d" href="#pos">pos</a>);
<a class="l" name="1201" href="#1201">1201</a>						}
<a class="l" name="1202" href="#1202">1202</a>						<span class="c">//size of the sample</span>
<a class="l" name="1203" href="#1203">1203</a>						<b>int</b> <a href="/source/s?defs=size&amp;project=rtmp_client">size</a> = (<a class="d" href="#videoSamples">videoSamples</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=sample&amp;project=rtmp_client">sample</a> - <span class="n">1</span>)).<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>();
<a class="l" name="1204" href="#1204">1204</a>
<a class="l" name="1205" href="#1205">1205</a>						<span class="c">//create a frame</span>
<a class="l" name="1206" href="#1206">1206</a>						<a href="/source/s?defs=MP4Frame&amp;project=rtmp_client">MP4Frame</a> <a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a> = <b>new</b> <a href="/source/s?defs=MP4Frame&amp;project=rtmp_client">MP4Frame</a>();
<a class="l" name="1207" href="#1207">1207</a>						<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=setKeyFrame&amp;project=rtmp_client">setKeyFrame</a>(<a href="/source/s?defs=keyframe&amp;project=rtmp_client">keyframe</a>);
<a class="l" name="1208" href="#1208">1208</a>						<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=setOffset&amp;project=rtmp_client">setOffset</a>(<a class="d" href="#pos">pos</a>);
<a class="l" name="1209" href="#1209">1209</a>						<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=setSize&amp;project=rtmp_client">setSize</a>(<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>);
<a class="hl" name="1210" href="#1210">1210</a>						<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=setTime&amp;project=rtmp_client">setTime</a>(<a href="/source/s?defs=ts&amp;project=rtmp_client">ts</a>);
<a class="l" name="1211" href="#1211">1211</a>						<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=setType&amp;project=rtmp_client">setType</a>(<a href="/source/s?defs=TYPE_VIDEO&amp;project=rtmp_client">TYPE_VIDEO</a>);
<a class="l" name="1212" href="#1212">1212</a>						<span class="c">//set time offset value from composition records</span>
<a class="l" name="1213" href="#1213">1213</a>						<b>if</b> (<a href="/source/s?defs=compositeTimeEntry&amp;project=rtmp_client">compositeTimeEntry</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="1214" href="#1214">1214</a>							<span class="c">// how many samples have this offset</span>
<a class="l" name="1215" href="#1215">1215</a>							<b>int</b> <a href="/source/s?defs=consecutiveSamples&amp;project=rtmp_client">consecutiveSamples</a> = <a href="/source/s?defs=compositeTimeEntry&amp;project=rtmp_client">compositeTimeEntry</a>.<a href="/source/s?defs=getConsecutiveSamples&amp;project=rtmp_client">getConsecutiveSamples</a>();
<a class="l" name="1216" href="#1216">1216</a>							<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=setTimeOffset&amp;project=rtmp_client">setTimeOffset</a>(<a href="/source/s?defs=compositeTimeEntry&amp;project=rtmp_client">compositeTimeEntry</a>.<a href="/source/s?defs=getSampleOffset&amp;project=rtmp_client">getSampleOffset</a>());
<a class="l" name="1217" href="#1217">1217</a>							<span class="c">// increment our count</span>
<a class="l" name="1218" href="#1218">1218</a>							<a href="/source/s?defs=compositeIndex&amp;project=rtmp_client">compositeIndex</a>++;
<a class="l" name="1219" href="#1219">1219</a>							<b>if</b> (<a href="/source/s?defs=compositeIndex&amp;project=rtmp_client">compositeIndex</a> - <a href="/source/s?defs=consecutiveSamples&amp;project=rtmp_client">consecutiveSamples</a> == <span class="n">0</span>) {
<a class="hl" name="1220" href="#1220">1220</a>								<span class="c">// ensure there are still times available</span>
<a class="l" name="1221" href="#1221">1221</a>								<b>if</b> (!<a class="d" href="#compositionTimes">compositionTimes</a>.<a href="/source/s?defs=isEmpty&amp;project=rtmp_client">isEmpty</a>()) {
<a class="l" name="1222" href="#1222">1222</a>									<span class="c">// get the next one</span>
<a class="l" name="1223" href="#1223">1223</a>									<a href="/source/s?defs=compositeTimeEntry&amp;project=rtmp_client">compositeTimeEntry</a> = <a class="d" href="#compositionTimes">compositionTimes</a>.<a href="/source/s?defs=remove&amp;project=rtmp_client">remove</a>(<span class="n">0</span>);
<a class="l" name="1224" href="#1224">1224</a>								}
<a class="l" name="1225" href="#1225">1225</a>								<span class="c">// reset</span>
<a class="l" name="1226" href="#1226">1226</a>								<a href="/source/s?defs=compositeIndex&amp;project=rtmp_client">compositeIndex</a> = <span class="n">0</span>;
<a class="l" name="1227" href="#1227">1227</a>							}
<a class="l" name="1228" href="#1228">1228</a>						}
<a class="l" name="1229" href="#1229">1229</a>						<span class="c">// add the frame</span>
<a class="hl" name="1230" href="#1230">1230</a>						<a class="d" href="#frames">frames</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>);
<a class="l" name="1231" href="#1231">1231</a>						<span class="c">//log.debug("Sample #{} {}", sample, frame);</span>
<a class="l" name="1232" href="#1232">1232</a>
<a class="l" name="1233" href="#1233">1233</a>						<span class="c">//inc and dec stuff</span>
<a class="l" name="1234" href="#1234">1234</a>						<a class="d" href="#pos">pos</a> += <a href="/source/s?defs=size&amp;project=rtmp_client">size</a>;
<a class="l" name="1235" href="#1235">1235</a>						<a href="/source/s?defs=sampleCount&amp;project=rtmp_client">sampleCount</a>--;
<a class="l" name="1236" href="#1236">1236</a>						<a href="/source/s?defs=sample&amp;project=rtmp_client">sample</a>++;
<a class="l" name="1237" href="#1237">1237</a>					}
<a class="l" name="1238" href="#1238">1238</a>				}
<a class="l" name="1239" href="#1239">1239</a>			}
<a class="hl" name="1240" href="#1240">1240</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sample position map (video): {}"</span>, <a class="d" href="#samplePosMap">samplePosMap</a>);
<a class="l" name="1241" href="#1241">1241</a>		}
<a class="l" name="1242" href="#1242">1242</a>
<a class="l" name="1243" href="#1243">1243</a>		<span class="c">// if video-only, skip this</span>
<a class="l" name="1244" href="#1244">1244</a>		<b>if</b> (<a class="d" href="#audioSamplesToChunks">audioSamplesToChunks</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="1245" href="#1245">1245</a>			<span class="c">//add the audio frames / samples / chunks</span>
<a class="l" name="1246" href="#1246">1246</a>			<a href="/source/s?defs=sample&amp;project=rtmp_client">sample</a> = <span class="n">1</span>;
<a class="l" name="1247" href="#1247">1247</a>			<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#audioSamplesToChunks">audioSamplesToChunks</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>(); i++) {
<a class="l" name="1248" href="#1248">1248</a>				<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=Record&amp;project=rtmp_client">Record</a> <a href="/source/s?defs=record&amp;project=rtmp_client">record</a> = <a class="d" href="#audioSamplesToChunks">audioSamplesToChunks</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(i);
<a class="l" name="1249" href="#1249">1249</a>				<b>int</b> <a href="/source/s?defs=firstChunk&amp;project=rtmp_client">firstChunk</a> = <a href="/source/s?defs=record&amp;project=rtmp_client">record</a>.<a href="/source/s?defs=getFirstChunk&amp;project=rtmp_client">getFirstChunk</a>();
<a class="hl" name="1250" href="#1250">1250</a>				<b>int</b> <a href="/source/s?defs=lastChunk&amp;project=rtmp_client">lastChunk</a> = <a class="d" href="#audioChunkOffsets">audioChunkOffsets</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>();
<a class="l" name="1251" href="#1251">1251</a>				<b>if</b> (i &lt; <a class="d" href="#audioSamplesToChunks">audioSamplesToChunks</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>() - <span class="n">1</span>) {
<a class="l" name="1252" href="#1252">1252</a>					<a href="/source/s?defs=MP4Atom&amp;project=rtmp_client">MP4Atom</a>.<a href="/source/s?defs=Record&amp;project=rtmp_client">Record</a> <a href="/source/s?defs=nextRecord&amp;project=rtmp_client">nextRecord</a> = <a class="d" href="#audioSamplesToChunks">audioSamplesToChunks</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(i + <span class="n">1</span>);
<a class="l" name="1253" href="#1253">1253</a>					<a href="/source/s?defs=lastChunk&amp;project=rtmp_client">lastChunk</a> = <a href="/source/s?defs=nextRecord&amp;project=rtmp_client">nextRecord</a>.<a href="/source/s?defs=getFirstChunk&amp;project=rtmp_client">getFirstChunk</a>() - <span class="n">1</span>;
<a class="l" name="1254" href="#1254">1254</a>				}
<a class="l" name="1255" href="#1255">1255</a>				<b>for</b> (<b>int</b> <a href="/source/s?defs=chunk&amp;project=rtmp_client">chunk</a> = <a href="/source/s?defs=firstChunk&amp;project=rtmp_client">firstChunk</a>; <a href="/source/s?defs=chunk&amp;project=rtmp_client">chunk</a> &lt;= <a href="/source/s?defs=lastChunk&amp;project=rtmp_client">lastChunk</a>; <a href="/source/s?defs=chunk&amp;project=rtmp_client">chunk</a>++) {
<a class="l" name="1256" href="#1256">1256</a>					<b>int</b> <a href="/source/s?defs=sampleCount&amp;project=rtmp_client">sampleCount</a> = <a href="/source/s?defs=record&amp;project=rtmp_client">record</a>.<a href="/source/s?defs=getSamplesPerChunk&amp;project=rtmp_client">getSamplesPerChunk</a>();
<a class="l" name="1257" href="#1257">1257</a>					<a class="d" href="#pos">pos</a> = <a class="d" href="#audioChunkOffsets">audioChunkOffsets</a>.<a href="/source/s?defs=elementAt&amp;project=rtmp_client">elementAt</a>(<a href="/source/s?defs=chunk&amp;project=rtmp_client">chunk</a> - <span class="n">1</span>);
<a class="l" name="1258" href="#1258">1258</a>					<b>while</b> (<a href="/source/s?defs=sampleCount&amp;project=rtmp_client">sampleCount</a> &gt; <span class="n">0</span>) {
<a class="l" name="1259" href="#1259">1259</a>						<span class="c">//calculate ts</span>
<a class="hl" name="1260" href="#1260">1260</a>						<b>double</b> <a href="/source/s?defs=ts&amp;project=rtmp_client">ts</a> = (<a class="d" href="#audioSampleDuration">audioSampleDuration</a> * (<a href="/source/s?defs=sample&amp;project=rtmp_client">sample</a> - <span class="n">1</span>)) / <a class="d" href="#audioTimeScale">audioTimeScale</a>;
<a class="l" name="1261" href="#1261">1261</a>						<span class="c">//sample size</span>
<a class="l" name="1262" href="#1262">1262</a>						<b>int</b> <a href="/source/s?defs=size&amp;project=rtmp_client">size</a> = (<a class="d" href="#audioSamples">audioSamples</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=sample&amp;project=rtmp_client">sample</a> - <span class="n">1</span>)).<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>();
<a class="l" name="1263" href="#1263">1263</a>						<span class="c">//create a frame</span>
<a class="l" name="1264" href="#1264">1264</a>						<a href="/source/s?defs=MP4Frame&amp;project=rtmp_client">MP4Frame</a> <a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a> = <b>new</b> <a href="/source/s?defs=MP4Frame&amp;project=rtmp_client">MP4Frame</a>();
<a class="l" name="1265" href="#1265">1265</a>						<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=setOffset&amp;project=rtmp_client">setOffset</a>(<a class="d" href="#pos">pos</a>);
<a class="l" name="1266" href="#1266">1266</a>						<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=setSize&amp;project=rtmp_client">setSize</a>(<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>);
<a class="l" name="1267" href="#1267">1267</a>						<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=setTime&amp;project=rtmp_client">setTime</a>(<a href="/source/s?defs=ts&amp;project=rtmp_client">ts</a>);
<a class="l" name="1268" href="#1268">1268</a>						<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=setType&amp;project=rtmp_client">setType</a>(<a href="/source/s?defs=TYPE_AUDIO&amp;project=rtmp_client">TYPE_AUDIO</a>);
<a class="l" name="1269" href="#1269">1269</a>						<a class="d" href="#frames">frames</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>);
<a class="hl" name="1270" href="#1270">1270</a>						<span class="c">//log.debug("Sample #{} {}", sample, frame);</span>
<a class="l" name="1271" href="#1271">1271</a>
<a class="l" name="1272" href="#1272">1272</a>						<span class="c">//inc and dec stuff</span>
<a class="l" name="1273" href="#1273">1273</a>						<a class="d" href="#pos">pos</a> += <a href="/source/s?defs=size&amp;project=rtmp_client">size</a>;
<a class="l" name="1274" href="#1274">1274</a>						<a href="/source/s?defs=sampleCount&amp;project=rtmp_client">sampleCount</a>--;
<a class="l" name="1275" href="#1275">1275</a>						<a href="/source/s?defs=sample&amp;project=rtmp_client">sample</a>++;
<a class="l" name="1276" href="#1276">1276</a>					}
<a class="l" name="1277" href="#1277">1277</a>				}
<a class="l" name="1278" href="#1278">1278</a>			}
<a class="l" name="1279" href="#1279">1279</a>		}
<a class="hl" name="1280" href="#1280">1280</a>		<span class="c">//sort the frames</span>
<a class="l" name="1281" href="#1281">1281</a>		<a href="/source/s?defs=Collections&amp;project=rtmp_client">Collections</a>.<a href="/source/s?defs=sort&amp;project=rtmp_client">sort</a>(<a class="d" href="#frames">frames</a>);
<a class="l" name="1282" href="#1282">1282</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Frames count: {}"</span>, <a class="d" href="#frames">frames</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>());
<a class="l" name="1283" href="#1283">1283</a>		<span class="c">//log.debug("Frames: {}", frames);</span>
<a class="l" name="1284" href="#1284">1284</a>
<a class="l" name="1285" href="#1285">1285</a>		<span class="c">//release some memory, since we're done with the vectors</span>
<a class="l" name="1286" href="#1286">1286</a>		<b>if</b> (<a class="d" href="#audioSamplesToChunks">audioSamplesToChunks</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="1287" href="#1287">1287</a>			<a class="d" href="#audioChunkOffsets">audioChunkOffsets</a>.<a class="d" href="#clear">clear</a>();
<a class="l" name="1288" href="#1288">1288</a>			<a class="d" href="#audioChunkOffsets">audioChunkOffsets</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="1289" href="#1289">1289</a>			<a class="d" href="#audioSamplesToChunks">audioSamplesToChunks</a>.<a class="d" href="#clear">clear</a>();
<a class="hl" name="1290" href="#1290">1290</a>			<a class="d" href="#audioSamplesToChunks">audioSamplesToChunks</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="1291" href="#1291">1291</a>		}
<a class="l" name="1292" href="#1292">1292</a>
<a class="l" name="1293" href="#1293">1293</a>		<b>if</b> (<a class="d" href="#videoSamplesToChunks">videoSamplesToChunks</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="1294" href="#1294">1294</a>			<a class="d" href="#videoChunkOffsets">videoChunkOffsets</a>.<a class="d" href="#clear">clear</a>();
<a class="l" name="1295" href="#1295">1295</a>			<a class="d" href="#videoChunkOffsets">videoChunkOffsets</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="1296" href="#1296">1296</a>			<a class="d" href="#videoSamplesToChunks">videoSamplesToChunks</a>.<a class="d" href="#clear">clear</a>();
<a class="l" name="1297" href="#1297">1297</a>			<a class="d" href="#videoSamplesToChunks">videoSamplesToChunks</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="1298" href="#1298">1298</a>		}
<a class="l" name="1299" href="#1299">1299</a>
<a class="hl" name="1300" href="#1300">1300</a>		<b>if</b> (<a class="d" href="#syncSamples">syncSamples</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="1301" href="#1301">1301</a>			<a class="d" href="#syncSamples">syncSamples</a>.<a class="d" href="#clear">clear</a>();
<a class="l" name="1302" href="#1302">1302</a>			<a class="d" href="#syncSamples">syncSamples</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="1303" href="#1303">1303</a>		}
<a class="l" name="1304" href="#1304">1304</a>	}
<a class="l" name="1305" href="#1305">1305</a>
<a class="l" name="1306" href="#1306">1306</a>	<span class="c">/**
<a class="l" name="1307" href="#1307">1307</a>	 * Put the current position to pos. The caller must ensure the pos is a valid one.
<a class="l" name="1308" href="#1308">1308</a>	 *
<a class="l" name="1309" href="#1309">1309</a>	 * <strong>@param</strong> <em>pos</em> position to move to in file / channel
<a class="hl" name="1310" href="#1310">1310</a>	 */</span>
<a class="l" name="1311" href="#1311">1311</a>	<b>public</b> <b>void</b> <a class="xmt" name="position"/><a href="/source/s?refs=position&amp;project=rtmp_client" class="xmt">position</a>(<b>long</b> <a class="xa" name="pos"/><a href="/source/s?refs=pos&amp;project=rtmp_client" class="xa">pos</a>) {
<a class="l" name="1312" href="#1312">1312</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Position: {}"</span>, <a class="d" href="#pos">pos</a>);
<a class="l" name="1313" href="#1313">1313</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Current frame: {}"</span>, <a class="d" href="#currentFrame">currentFrame</a>);
<a class="l" name="1314" href="#1314">1314</a>		<b>int</b> <a href="/source/s?defs=len&amp;project=rtmp_client">len</a> = <a class="d" href="#frames">frames</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>();
<a class="l" name="1315" href="#1315">1315</a>		<a href="/source/s?defs=MP4Frame&amp;project=rtmp_client">MP4Frame</a> <a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="1316" href="#1316">1316</a>		<b>for</b> (<b>int</b> f = <span class="n">0</span>; f &lt; <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>; f++) {
<a class="l" name="1317" href="#1317">1317</a>			<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a> = <a class="d" href="#frames">frames</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(f);
<a class="l" name="1318" href="#1318">1318</a>			<b>long</b> <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> = <a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a class="d" href="#getOffset">getOffset</a>();
<a class="l" name="1319" href="#1319">1319</a>			<span class="c">//look for pos to match frame offset or grab the first keyframe</span>
<a class="hl" name="1320" href="#1320">1320</a>			<span class="c">//beyond the offset</span>
<a class="l" name="1321" href="#1321">1321</a>			<b>if</b> (<a class="d" href="#pos">pos</a> == <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> || (<a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> &gt; <a class="d" href="#pos">pos</a> &amp;&amp; <a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=isKeyFrame&amp;project=rtmp_client">isKeyFrame</a>())) {
<a class="l" name="1322" href="#1322">1322</a>				<span class="c">//ensure that it is a keyframe</span>
<a class="l" name="1323" href="#1323">1323</a>				<b>if</b> (!<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=isKeyFrame&amp;project=rtmp_client">isKeyFrame</a>()) {
<a class="l" name="1324" href="#1324">1324</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Frame #{} was not a key frame, so trying again.."</span>, f);
<a class="l" name="1325" href="#1325">1325</a>					<b>continue</b>;
<a class="l" name="1326" href="#1326">1326</a>				}
<a class="l" name="1327" href="#1327">1327</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"Frame #{} found for seek: {}"</span>, f, <a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>);
<a class="l" name="1328" href="#1328">1328</a>				<a class="d" href="#createPreStreamingTags">createPreStreamingTags</a>((<b>int</b>) (<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=getTime&amp;project=rtmp_client">getTime</a>() * <span class="n">1000</span>), <b>true</b>);
<a class="l" name="1329" href="#1329">1329</a>				<a class="d" href="#currentFrame">currentFrame</a> = f;
<a class="hl" name="1330" href="#1330">1330</a>				<b>break</b>;
<a class="l" name="1331" href="#1331">1331</a>			}
<a class="l" name="1332" href="#1332">1332</a>			<a class="d" href="#prevVideoTS">prevVideoTS</a> = (<b>int</b>) (<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>.<a href="/source/s?defs=getTime&amp;project=rtmp_client">getTime</a>() * <span class="n">1000</span>);
<a class="l" name="1333" href="#1333">1333</a>		}
<a class="l" name="1334" href="#1334">1334</a>		<span class="c">//</span>
<a class="l" name="1335" href="#1335">1335</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Setting current frame: {}"</span>, <a class="d" href="#currentFrame">currentFrame</a>);
<a class="l" name="1336" href="#1336">1336</a>	}
<a class="l" name="1337" href="#1337">1337</a>
<a class="l" name="1338" href="#1338">1338</a>	<span class="c">/** {<strong>@inheritDoc</strong>}
<a class="l" name="1339" href="#1339">1339</a>	 */</span>
<a class="hl" name="1340" href="#1340">1340</a>	<b>public</b> <b>void</b> <a class="xmt" name="close"/><a href="/source/s?refs=close&amp;project=rtmp_client" class="xmt">close</a>() {
<a class="l" name="1341" href="#1341">1341</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Close"</span>);
<a class="l" name="1342" href="#1342">1342</a>		<b>if</b> (<a class="d" href="#channel">channel</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="1343" href="#1343">1343</a>			<b>try</b> {
<a class="l" name="1344" href="#1344">1344</a>				<a class="d" href="#channel">channel</a>.<a class="d" href="#close">close</a>();
<a class="l" name="1345" href="#1345">1345</a>				<a class="d" href="#fis">fis</a>.<a class="d" href="#close">close</a>();
<a class="l" name="1346" href="#1346">1346</a>				<a class="d" href="#fis">fis</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="1347" href="#1347">1347</a>			} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> e) {
<a class="l" name="1348" href="#1348">1348</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Channel close {}"</span>, e);
<a class="l" name="1349" href="#1349">1349</a>			} <b>finally</b> {
<a class="hl" name="1350" href="#1350">1350</a>				<b>if</b> (<a class="d" href="#frames">frames</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="1351" href="#1351">1351</a>					<a class="d" href="#frames">frames</a>.<a class="d" href="#clear">clear</a>();
<a class="l" name="1352" href="#1352">1352</a>					<a class="d" href="#frames">frames</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="1353" href="#1353">1353</a>				}
<a class="l" name="1354" href="#1354">1354</a>			}
<a class="l" name="1355" href="#1355">1355</a>		}
<a class="l" name="1356" href="#1356">1356</a>	}
<a class="l" name="1357" href="#1357">1357</a>
<a class="l" name="1358" href="#1358">1358</a>	<b>public</b> <b>void</b> <a class="xmt" name="setVideoCodecId"/><a href="/source/s?refs=setVideoCodecId&amp;project=rtmp_client" class="xmt">setVideoCodecId</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="videoCodecId"/><a href="/source/s?refs=videoCodecId&amp;project=rtmp_client" class="xa">videoCodecId</a>) {
<a class="l" name="1359" href="#1359">1359</a>		<b>this</b>.<a href="/source/s?defs=videoCodecId&amp;project=rtmp_client">videoCodecId</a> = <a href="/source/s?defs=videoCodecId&amp;project=rtmp_client">videoCodecId</a>;
<a class="hl" name="1360" href="#1360">1360</a>	}
<a class="l" name="1361" href="#1361">1361</a>
<a class="l" name="1362" href="#1362">1362</a>	<b>public</b> <b>void</b> <a class="xmt" name="setAudioCodecId"/><a href="/source/s?refs=setAudioCodecId&amp;project=rtmp_client" class="xmt">setAudioCodecId</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="audioCodecId"/><a href="/source/s?refs=audioCodecId&amp;project=rtmp_client" class="xa">audioCodecId</a>) {
<a class="l" name="1363" href="#1363">1363</a>		<b>this</b>.<a href="/source/s?defs=audioCodecId&amp;project=rtmp_client">audioCodecId</a> = <a href="/source/s?defs=audioCodecId&amp;project=rtmp_client">audioCodecId</a>;
<a class="l" name="1364" href="#1364">1364</a>	}
<a class="l" name="1365" href="#1365">1365</a>
<a class="l" name="1366" href="#1366">1366</a>	<b>public</b> <a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a class="xmt" name="readTagHeader"/><a href="/source/s?refs=readTagHeader&amp;project=rtmp_client" class="xmt">readTagHeader</a>() {
<a class="l" name="1367" href="#1367">1367</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="1368" href="#1368">1368</a>	}
<a class="l" name="1369" href="#1369">1369</a>
<a class="hl" name="1370" href="#1370">1370</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="1371" href="#1371">1371</a>	<b>public</b> <a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a> <a class="xmt" name="analyzeKeyFrames"/><a href="/source/s?refs=analyzeKeyFrames&amp;project=rtmp_client" class="xmt">analyzeKeyFrames</a>() {
<a class="l" name="1372" href="#1372">1372</a>		<a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>new</b> <a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a>();
<a class="l" name="1373" href="#1373">1373</a>		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=audioOnly&amp;project=rtmp_client">audioOnly</a> = <a class="d" href="#hasAudio">hasAudio</a> &amp;&amp; !<a href="/source/s?defs=hasVideo&amp;project=rtmp_client">hasVideo</a>;
<a class="l" name="1374" href="#1374">1374</a>		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a class="d" href="#duration">duration</a> = <a class="d" href="#duration">duration</a>;
<a class="l" name="1375" href="#1375">1375</a>		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a> = <b>new</b> <b>long</b>[<a class="d" href="#seekPoints">seekPoints</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>()];
<a class="l" name="1376" href="#1376">1376</a>		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=timestamps&amp;project=rtmp_client">timestamps</a> = <b>new</b> <b>int</b>[<a class="d" href="#seekPoints">seekPoints</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>()];
<a class="l" name="1377" href="#1377">1377</a>		<b>for</b> (<b>int</b> <a href="/source/s?defs=idx&amp;project=rtmp_client">idx</a>=<span class="n">0</span>; <a href="/source/s?defs=idx&amp;project=rtmp_client">idx</a>&lt;<a class="d" href="#seekPoints">seekPoints</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>(); <a href="/source/s?defs=idx&amp;project=rtmp_client">idx</a>++) {
<a class="l" name="1378" href="#1378">1378</a>			<b>final</b> <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a> <a href="/source/s?defs=ts&amp;project=rtmp_client">ts</a> = <a class="d" href="#seekPoints">seekPoints</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=idx&amp;project=rtmp_client">idx</a>);
<a class="l" name="1379" href="#1379">1379</a>			<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a>[<a href="/source/s?defs=idx&amp;project=rtmp_client">idx</a>] = <a class="d" href="#timePosMap">timePosMap</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=ts&amp;project=rtmp_client">ts</a>);
<a class="hl" name="1380" href="#1380">1380</a>			<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=timestamps&amp;project=rtmp_client">timestamps</a>[<a href="/source/s?defs=idx&amp;project=rtmp_client">idx</a>] = <a href="/source/s?defs=ts&amp;project=rtmp_client">ts</a>;
<a class="l" name="1381" href="#1381">1381</a>		}
<a class="l" name="1382" href="#1382">1382</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="1383" href="#1383">1383</a>	}
<a class="l" name="1384" href="#1384">1384</a>
<a class="l" name="1385" href="#1385">1385</a>}
<a class="l" name="1386" href="#1386">1386</a>