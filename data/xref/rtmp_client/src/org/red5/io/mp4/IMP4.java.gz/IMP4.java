<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.red5.io.mp4",1]]],["Interface","xi",[["IMP4",37]]],["Method","xmt",[["flushHeaders",104],["getKeyFrameData",90],["getMetaData",69],["hasKeyFrameData",76],["hasMetaData",44],["readerFromNearestKeyFrame",112],["refreshHeaders",97],["setKeyFrameData",83],["setMetaData",53],["setMetaService",61],["writerFromNearestKeyFrame",120]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=mp4&amp;project=rtmp_client">mp4</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2007 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=FileNotFoundException&amp;project=rtmp_client">FileNotFoundException</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IStreamableFile&amp;project=rtmp_client">IStreamableFile</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=ITagReader&amp;project=rtmp_client">ITagReader</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=ITagWriter&amp;project=rtmp_client">ITagWriter</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>.<a href="/source/s?defs=IMetaData&amp;project=rtmp_client">IMetaData</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>.<a href="/source/s?defs=IMetaService&amp;project=rtmp_client">IMetaService</a>;
<a class="l" name="31" href="#31">31</a>
<a class="l" name="32" href="#32">32</a><span class="c">/**
<a class="l" name="33" href="#33">33</a> * Represents MP4 file
<a class="l" name="34" href="#34">34</a> *
<a class="l" name="35" href="#35">35</a> * <strong>@author</strong> Paul Gregoire (mondain@gmail.com)
<a class="l" name="36" href="#36">36</a> */</span>
<a class="l" name="37" href="#37">37</a><b>public</b> <b>interface</b> <a class="xi" name="IMP4"/><a href="/source/s?refs=IMP4&amp;project=rtmp_client" class="xi">IMP4</a> <b>extends</b> <a href="/source/s?defs=IStreamableFile&amp;project=rtmp_client">IStreamableFile</a> {
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>	<span class="c">/**
<a class="hl" name="40" href="#40">40</a>	 * Returns a boolean stating whether the mp4 has metadata
<a class="l" name="41" href="#41">41</a>	 *
<a class="l" name="42" href="#42">42</a>	 * <strong>@return</strong> boolean        &lt;code&gt;true&lt;/code&gt; if file has injected metadata, &lt;code&gt;false&lt;/code&gt; otherwise
<a class="l" name="43" href="#43">43</a>	 */</span>
<a class="l" name="44" href="#44">44</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="hasMetaData"/><a href="/source/s?refs=hasMetaData&amp;project=rtmp_client" class="xmt">hasMetaData</a>();
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a>	<span class="c">/**
<a class="l" name="47" href="#47">47</a>	 * Sets the metadata
<a class="l" name="48" href="#48">48</a>	 *
<a class="l" name="49" href="#49">49</a>	 * <strong>@param</strong> <em>metadata</em>                   Metadata object
<a class="hl" name="50" href="#50">50</a>	 * <strong>@throws</strong> <em>FileNotFoundException</em>     File not found
<a class="l" name="51" href="#51">51</a>	 * <strong>@throws</strong> <em>IOException</em>               Any other I/O exception
<a class="l" name="52" href="#52">52</a>	 */</span>
<a class="l" name="53" href="#53">53</a>	<b>public</b> <b>void</b> <a class="xmt" name="setMetaData"/><a href="/source/s?refs=setMetaData&amp;project=rtmp_client" class="xmt">setMetaData</a>(<a href="/source/s?defs=IMetaData&amp;project=rtmp_client">IMetaData</a>&lt;?, ?&gt; <a class="xa" name="metadata"/><a href="/source/s?refs=metadata&amp;project=rtmp_client" class="xa">metadata</a>) <b>throws</b> <a href="/source/s?defs=FileNotFoundException&amp;project=rtmp_client">FileNotFoundException</a>,
<a class="l" name="54" href="#54">54</a>			<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a>	<span class="c">/**
<a class="l" name="57" href="#57">57</a>	 * Sets the MetaService through Spring
<a class="l" name="58" href="#58">58</a>	 *
<a class="l" name="59" href="#59">59</a>	 * <strong>@param</strong> <em>service</em>                    Metadata service
<a class="hl" name="60" href="#60">60</a>	 */</span>
<a class="l" name="61" href="#61">61</a>	<b>public</b> <b>void</b> <a class="xmt" name="setMetaService"/><a href="/source/s?refs=setMetaService&amp;project=rtmp_client" class="xmt">setMetaService</a>(<a href="/source/s?defs=IMetaService&amp;project=rtmp_client">IMetaService</a> <a class="xa" name="service"/><a href="/source/s?refs=service&amp;project=rtmp_client" class="xa">service</a>);
<a class="l" name="62" href="#62">62</a>
<a class="l" name="63" href="#63">63</a>	<span class="c">/**
<a class="l" name="64" href="#64">64</a>	 * Returns a map of the metadata
<a class="l" name="65" href="#65">65</a>	 *
<a class="l" name="66" href="#66">66</a>	 * <strong>@return</strong> metadata                  File metadata
<a class="l" name="67" href="#67">67</a>	 * <strong>@throws</strong> <em>FileNotFoundException</em>     File not found
<a class="l" name="68" href="#68">68</a>	 */</span>
<a class="l" name="69" href="#69">69</a>	<b>public</b> <a href="/source/s?defs=IMetaData&amp;project=rtmp_client">IMetaData</a>&lt;?, ?&gt; <a class="xmt" name="getMetaData"/><a href="/source/s?refs=getMetaData&amp;project=rtmp_client" class="xmt">getMetaData</a>() <b>throws</b> <a href="/source/s?defs=FileNotFoundException&amp;project=rtmp_client">FileNotFoundException</a>;
<a class="hl" name="70" href="#70">70</a>
<a class="l" name="71" href="#71">71</a>	<span class="c">/**
<a class="l" name="72" href="#72">72</a>	 * Returns a boolean stating whether a mp4 has keyframedata
<a class="l" name="73" href="#73">73</a>	 *
<a class="l" name="74" href="#74">74</a>	 * <strong>@return</strong> boolean                   &lt;code&gt;true&lt;/code&gt; if file has keyframe metadata, &lt;code&gt;false&lt;/code&gt; otherwise
<a class="l" name="75" href="#75">75</a>	 */</span>
<a class="l" name="76" href="#76">76</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="hasKeyFrameData"/><a href="/source/s?refs=hasKeyFrameData&amp;project=rtmp_client" class="xmt">hasKeyFrameData</a>();
<a class="l" name="77" href="#77">77</a>
<a class="l" name="78" href="#78">78</a>	<span class="c">/**
<a class="l" name="79" href="#79">79</a>	 * Sets the keyframe data of a mp4 file
<a class="hl" name="80" href="#80">80</a>	 *
<a class="l" name="81" href="#81">81</a>	 * <strong>@param</strong> <em>keyframedata</em>              Keyframe metadata
<a class="l" name="82" href="#82">82</a>	 */</span>
<a class="l" name="83" href="#83">83</a>	<b>public</b> <b>void</b> <a class="xmt" name="setKeyFrameData"/><a href="/source/s?refs=setKeyFrameData&amp;project=rtmp_client" class="xmt">setKeyFrameData</a>(<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;?, ?&gt; <a class="xa" name="keyframedata"/><a href="/source/s?refs=keyframedata&amp;project=rtmp_client" class="xa">keyframedata</a>);
<a class="l" name="84" href="#84">84</a>
<a class="l" name="85" href="#85">85</a>	<span class="c">/**
<a class="l" name="86" href="#86">86</a>	 * Gets the keyframe data
<a class="l" name="87" href="#87">87</a>	 *
<a class="l" name="88" href="#88">88</a>	 * <strong>@return</strong> keyframedata             Keyframe metadata
<a class="l" name="89" href="#89">89</a>	 */</span>
<a class="hl" name="90" href="#90">90</a>	<b>public</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;?, ?&gt; <a class="xmt" name="getKeyFrameData"/><a href="/source/s?refs=getKeyFrameData&amp;project=rtmp_client" class="xmt">getKeyFrameData</a>();
<a class="l" name="91" href="#91">91</a>
<a class="l" name="92" href="#92">92</a>	<span class="c">/**
<a class="l" name="93" href="#93">93</a>	 * Refreshes the headers. Usually used after data is added to the mp4 file
<a class="l" name="94" href="#94">94</a>	 *
<a class="l" name="95" href="#95">95</a>	 * <strong>@throws</strong> <em>IOException</em>              Any I/O exception
<a class="l" name="96" href="#96">96</a>	 */</span>
<a class="l" name="97" href="#97">97</a>	<b>public</b> <b>void</b> <a class="xmt" name="refreshHeaders"/><a href="/source/s?refs=refreshHeaders&amp;project=rtmp_client" class="xmt">refreshHeaders</a>() <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="98" href="#98">98</a>
<a class="l" name="99" href="#99">99</a>	<span class="c">/**
<a class="hl" name="100" href="#100">100</a>	 * Flushes Header
<a class="l" name="101" href="#101">101</a>	 *
<a class="l" name="102" href="#102">102</a>	 * <strong>@throws</strong> <em>IOException</em>              Any I/O exception
<a class="l" name="103" href="#103">103</a>	 */</span>
<a class="l" name="104" href="#104">104</a>	<b>public</b> <b>void</b> <a class="xmt" name="flushHeaders"/><a href="/source/s?refs=flushHeaders&amp;project=rtmp_client" class="xmt">flushHeaders</a>() <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="105" href="#105">105</a>
<a class="l" name="106" href="#106">106</a>	<span class="c">/**
<a class="l" name="107" href="#107">107</a>	 * Returns a Reader closest to the nearest keyframe
<a class="l" name="108" href="#108">108</a>	 *
<a class="l" name="109" href="#109">109</a>	 * <strong>@param</strong> <em>seekPoint</em>                Point in file we are seeking around
<a class="hl" name="110" href="#110">110</a>	 * <strong>@return</strong> reader                  Tag reader closest to that point
<a class="l" name="111" href="#111">111</a>	 */</span>
<a class="l" name="112" href="#112">112</a>	<b>public</b> <a href="/source/s?defs=ITagReader&amp;project=rtmp_client">ITagReader</a> <a class="xmt" name="readerFromNearestKeyFrame"/><a href="/source/s?refs=readerFromNearestKeyFrame&amp;project=rtmp_client" class="xmt">readerFromNearestKeyFrame</a>(<b>int</b> <a class="xa" name="seekPoint"/><a href="/source/s?refs=seekPoint&amp;project=rtmp_client" class="xa">seekPoint</a>);
<a class="l" name="113" href="#113">113</a>
<a class="l" name="114" href="#114">114</a>	<span class="c">/**
<a class="l" name="115" href="#115">115</a>	 * Returns a Writer based on the nearest key frame
<a class="l" name="116" href="#116">116</a>	 *
<a class="l" name="117" href="#117">117</a>	 * <strong>@param</strong> <em>seekPoint</em>                Point in file we are seeking around
<a class="l" name="118" href="#118">118</a>	 * <strong>@return</strong> writer                  Tag writer closest to that point
<a class="l" name="119" href="#119">119</a>	 */</span>
<a class="hl" name="120" href="#120">120</a>	<b>public</b> <a href="/source/s?defs=ITagWriter&amp;project=rtmp_client">ITagWriter</a> <a class="xmt" name="writerFromNearestKeyFrame"/><a href="/source/s?refs=writerFromNearestKeyFrame&amp;project=rtmp_client" class="xmt">writerFromNearestKeyFrame</a>(<b>int</b> <a class="xa" name="seekPoint"/><a href="/source/s?refs=seekPoint&amp;project=rtmp_client" class="xa">seekPoint</a>);
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>}
<a class="l" name="123" href="#123">123</a>