<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["MP4Frame",27]]],["Package","xp",[["org.red5.io.mp4",1]]],["Method","xmt",[["compareTo",166],["equals",131],["getOffset",60],["getSize",73],["getTime",86],["getTimeOffset",97],["getType",47],["hashCode",122],["isKeyFrame",113],["setKeyFrame",117],["setOffset",64],["setSize",77],["setTime",90],["setTimeOffset",104],["setType",51],["toString",147]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=mp4&amp;project=rtmp_client">mp4</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2007 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><span class="c">/**
<a class="l" name="23" href="#23">23</a> * Represents an MP4 frame / chunk sample
<a class="l" name="24" href="#24">24</a> *
<a class="l" name="25" href="#25">25</a> * <strong>@author</strong> Paul Gregoire (mondain@gmail.com)
<a class="l" name="26" href="#26">26</a> */</span>
<a class="l" name="27" href="#27">27</a><b>public</b> <b>class</b> <a class="xc" name="MP4Frame"/><a href="/source/s?refs=MP4Frame&amp;project=rtmp_client" class="xc">MP4Frame</a> <b>implements</b> <a href="/source/s?defs=Comparable&amp;project=rtmp_client">Comparable</a>&lt;<a class="xc" name="MP4Frame"/><a href="/source/s?refs=MP4Frame&amp;project=rtmp_client" class="xc">MP4Frame</a>&gt; {
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a>	<b>private</b> <b>byte</b> <a class="xfld" name="type"/><a href="/source/s?refs=type&amp;project=rtmp_client" class="xfld">type</a>;
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a>	<b>private</b> <b>long</b> <a class="xfld" name="offset"/><a href="/source/s?refs=offset&amp;project=rtmp_client" class="xfld">offset</a>;
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a>	<b>private</b> <b>int</b> <a class="xfld" name="size"/><a href="/source/s?refs=size&amp;project=rtmp_client" class="xfld">size</a>;
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a>	<b>private</b> <b>double</b> <a class="xfld" name="time"/><a href="/source/s?refs=time&amp;project=rtmp_client" class="xfld">time</a>;
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a>	<span class="c">//this value originates from the ctts atom</span>
<a class="l" name="38" href="#38">38</a>	<b>private</b> <b>int</b> <a class="xfld" name="timeOffset"/><a href="/source/s?refs=timeOffset&amp;project=rtmp_client" class="xfld">timeOffset</a>;
<a class="l" name="39" href="#39">39</a>
<a class="hl" name="40" href="#40">40</a>	<b>private</b> <b>boolean</b> <a class="xfld" name="keyFrame"/><a href="/source/s?refs=keyFrame&amp;project=rtmp_client" class="xfld">keyFrame</a>;
<a class="l" name="41" href="#41">41</a>
<a class="l" name="42" href="#42">42</a>	<span class="c">/**
<a class="l" name="43" href="#43">43</a>	 * Returns the data type, being audio or video.
<a class="l" name="44" href="#44">44</a>	 *
<a class="l" name="45" href="#45">45</a>	 * <strong>@return</strong> the data type
<a class="l" name="46" href="#46">46</a>	 */</span>
<a class="l" name="47" href="#47">47</a>	<b>public</b> <b>byte</b> <a class="xmt" name="getType"/><a href="/source/s?refs=getType&amp;project=rtmp_client" class="xmt">getType</a>() {
<a class="l" name="48" href="#48">48</a>		<b>return</b> <a href="/source/s?defs=type&amp;project=rtmp_client">type</a>;
<a class="l" name="49" href="#49">49</a>	}
<a class="hl" name="50" href="#50">50</a>
<a class="l" name="51" href="#51">51</a>	<b>public</b> <b>void</b> <a class="xmt" name="setType"/><a href="/source/s?refs=setType&amp;project=rtmp_client" class="xmt">setType</a>(<b>byte</b> <a class="xa" name="type"/><a href="/source/s?refs=type&amp;project=rtmp_client" class="xa">type</a>) {
<a class="l" name="52" href="#52">52</a>		<b>this</b>.<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <a href="/source/s?defs=type&amp;project=rtmp_client">type</a>;
<a class="l" name="53" href="#53">53</a>	}
<a class="l" name="54" href="#54">54</a>
<a class="l" name="55" href="#55">55</a>	<span class="c">/**
<a class="l" name="56" href="#56">56</a>	 * Returns the offset of the data chunk in the media source.
<a class="l" name="57" href="#57">57</a>	 *
<a class="l" name="58" href="#58">58</a>	 * <strong>@return</strong> the offset in bytes
<a class="l" name="59" href="#59">59</a>	 */</span>
<a class="hl" name="60" href="#60">60</a>	<b>public</b> <b>long</b> <a class="xmt" name="getOffset"/><a href="/source/s?refs=getOffset&amp;project=rtmp_client" class="xmt">getOffset</a>() {
<a class="l" name="61" href="#61">61</a>		<b>return</b> <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>;
<a class="l" name="62" href="#62">62</a>	}
<a class="l" name="63" href="#63">63</a>
<a class="l" name="64" href="#64">64</a>	<b>public</b> <b>void</b> <a class="xmt" name="setOffset"/><a href="/source/s?refs=setOffset&amp;project=rtmp_client" class="xmt">setOffset</a>(<b>long</b> <a class="xa" name="offset"/><a href="/source/s?refs=offset&amp;project=rtmp_client" class="xa">offset</a>) {
<a class="l" name="65" href="#65">65</a>		<b>this</b>.<a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> = <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>;
<a class="l" name="66" href="#66">66</a>	}
<a class="l" name="67" href="#67">67</a>
<a class="l" name="68" href="#68">68</a>	<span class="c">/**
<a class="l" name="69" href="#69">69</a>	 * Returns the size of the data chunk.
<a class="hl" name="70" href="#70">70</a>	 *
<a class="l" name="71" href="#71">71</a>	 * <strong>@return</strong> the size in bytes
<a class="l" name="72" href="#72">72</a>	 */</span>
<a class="l" name="73" href="#73">73</a>	<b>public</b> <b>int</b> <a class="xmt" name="getSize"/><a href="/source/s?refs=getSize&amp;project=rtmp_client" class="xmt">getSize</a>() {
<a class="l" name="74" href="#74">74</a>		<b>return</b> <a href="/source/s?defs=size&amp;project=rtmp_client">size</a>;
<a class="l" name="75" href="#75">75</a>	}
<a class="l" name="76" href="#76">76</a>
<a class="l" name="77" href="#77">77</a>	<b>public</b> <b>void</b> <a class="xmt" name="setSize"/><a href="/source/s?refs=setSize&amp;project=rtmp_client" class="xmt">setSize</a>(<b>int</b> <a class="xa" name="size"/><a href="/source/s?refs=size&amp;project=rtmp_client" class="xa">size</a>) {
<a class="l" name="78" href="#78">78</a>		<b>this</b>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a> = <a href="/source/s?defs=size&amp;project=rtmp_client">size</a>;
<a class="l" name="79" href="#79">79</a>	}
<a class="hl" name="80" href="#80">80</a>
<a class="l" name="81" href="#81">81</a>	<span class="c">/**
<a class="l" name="82" href="#82">82</a>	 * Returns the timestamp.
<a class="l" name="83" href="#83">83</a>	 *
<a class="l" name="84" href="#84">84</a>	 * <strong>@return</strong> the timestamp
<a class="l" name="85" href="#85">85</a>	 */</span>
<a class="l" name="86" href="#86">86</a>	<b>public</b> <b>double</b> <a class="xmt" name="getTime"/><a href="/source/s?refs=getTime&amp;project=rtmp_client" class="xmt">getTime</a>() {
<a class="l" name="87" href="#87">87</a>		<b>return</b> <a href="/source/s?defs=time&amp;project=rtmp_client">time</a>;
<a class="l" name="88" href="#88">88</a>	}
<a class="l" name="89" href="#89">89</a>
<a class="hl" name="90" href="#90">90</a>	<b>public</b> <b>void</b> <a class="xmt" name="setTime"/><a href="/source/s?refs=setTime&amp;project=rtmp_client" class="xmt">setTime</a>(<b>double</b> <a class="xa" name="time"/><a href="/source/s?refs=time&amp;project=rtmp_client" class="xa">time</a>) {
<a class="l" name="91" href="#91">91</a>		<b>this</b>.<a href="/source/s?defs=time&amp;project=rtmp_client">time</a> = <a href="/source/s?defs=time&amp;project=rtmp_client">time</a>;
<a class="l" name="92" href="#92">92</a>	}
<a class="l" name="93" href="#93">93</a>
<a class="l" name="94" href="#94">94</a>	<span class="c">/**
<a class="l" name="95" href="#95">95</a>	 * <strong>@return</strong> the timeOffset
<a class="l" name="96" href="#96">96</a>	 */</span>
<a class="l" name="97" href="#97">97</a>	<b>public</b> <b>int</b> <a class="xmt" name="getTimeOffset"/><a href="/source/s?refs=getTimeOffset&amp;project=rtmp_client" class="xmt">getTimeOffset</a>() {
<a class="l" name="98" href="#98">98</a>		<b>return</b> <a href="/source/s?defs=timeOffset&amp;project=rtmp_client">timeOffset</a>;
<a class="l" name="99" href="#99">99</a>	}
<a class="hl" name="100" href="#100">100</a>
<a class="l" name="101" href="#101">101</a>	<span class="c">/**
<a class="l" name="102" href="#102">102</a>	 * <strong>@param</strong> <em>timeOffset</em> the timeOffset to set
<a class="l" name="103" href="#103">103</a>	 */</span>
<a class="l" name="104" href="#104">104</a>	<b>public</b> <b>void</b> <a class="xmt" name="setTimeOffset"/><a href="/source/s?refs=setTimeOffset&amp;project=rtmp_client" class="xmt">setTimeOffset</a>(<b>int</b> <a class="xa" name="timeOffset"/><a href="/source/s?refs=timeOffset&amp;project=rtmp_client" class="xa">timeOffset</a>) {
<a class="l" name="105" href="#105">105</a>		<b>this</b>.<a href="/source/s?defs=timeOffset&amp;project=rtmp_client">timeOffset</a> = <a href="/source/s?defs=timeOffset&amp;project=rtmp_client">timeOffset</a>;
<a class="l" name="106" href="#106">106</a>	}
<a class="l" name="107" href="#107">107</a>
<a class="l" name="108" href="#108">108</a>	<span class="c">/**
<a class="l" name="109" href="#109">109</a>	 * Returns whether or not this chunk represents a key frame.
<a class="hl" name="110" href="#110">110</a>	 *
<a class="l" name="111" href="#111">111</a>	 * <strong>@return</strong> true if a key frame
<a class="l" name="112" href="#112">112</a>	 */</span>
<a class="l" name="113" href="#113">113</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="isKeyFrame"/><a href="/source/s?refs=isKeyFrame&amp;project=rtmp_client" class="xmt">isKeyFrame</a>() {
<a class="l" name="114" href="#114">114</a>		<b>return</b> <a href="/source/s?defs=keyFrame&amp;project=rtmp_client">keyFrame</a>;
<a class="l" name="115" href="#115">115</a>	}
<a class="l" name="116" href="#116">116</a>
<a class="l" name="117" href="#117">117</a>	<b>public</b> <b>void</b> <a class="xmt" name="setKeyFrame"/><a href="/source/s?refs=setKeyFrame&amp;project=rtmp_client" class="xmt">setKeyFrame</a>(<b>boolean</b> <a class="xa" name="keyFrame"/><a href="/source/s?refs=keyFrame&amp;project=rtmp_client" class="xa">keyFrame</a>) {
<a class="l" name="118" href="#118">118</a>		<b>this</b>.<a href="/source/s?defs=keyFrame&amp;project=rtmp_client">keyFrame</a> = <a href="/source/s?defs=keyFrame&amp;project=rtmp_client">keyFrame</a>;
<a class="l" name="119" href="#119">119</a>	}
<a class="hl" name="120" href="#120">120</a>
<a class="l" name="121" href="#121">121</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="122" href="#122">122</a>	<b>public</b> <b>int</b> <a class="xmt" name="hashCode"/><a href="/source/s?refs=hashCode&amp;project=rtmp_client" class="xmt">hashCode</a>() {
<a class="l" name="123" href="#123">123</a>		<b>final</b> <b>int</b> <a href="/source/s?defs=prime&amp;project=rtmp_client">prime</a> = <span class="n">31</span>;
<a class="l" name="124" href="#124">124</a>		<b>int</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <span class="n">1</span>;
<a class="l" name="125" href="#125">125</a>		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=prime&amp;project=rtmp_client">prime</a> * <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> + (<b>int</b>) (<a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> ^ (<a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> &gt;&gt;&gt; <span class="n">32</span>));
<a class="l" name="126" href="#126">126</a>		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=prime&amp;project=rtmp_client">prime</a> * <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> + <a href="/source/s?defs=type&amp;project=rtmp_client">type</a>;
<a class="l" name="127" href="#127">127</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="128" href="#128">128</a>	}
<a class="l" name="129" href="#129">129</a>
<a class="hl" name="130" href="#130">130</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="131" href="#131">131</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="equals"/><a href="/source/s?refs=equals&amp;project=rtmp_client" class="xmt">equals</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="obj"/><a href="/source/s?refs=obj&amp;project=rtmp_client" class="xa">obj</a>) {
<a class="l" name="132" href="#132">132</a>		<b>if</b> (<b>this</b> == <a class="d" href="#obj">obj</a>)
<a class="l" name="133" href="#133">133</a>			<b>return</b> <b>true</b>;
<a class="l" name="134" href="#134">134</a>		<b>if</b> (<a class="d" href="#obj">obj</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>)
<a class="l" name="135" href="#135">135</a>			<b>return</b> <b>false</b>;
<a class="l" name="136" href="#136">136</a>		<b>if</b> (<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>() != <a class="d" href="#obj">obj</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>())
<a class="l" name="137" href="#137">137</a>			<b>return</b> <b>false</b>;
<a class="l" name="138" href="#138">138</a>		<a class="d" href="#MP4Frame">MP4Frame</a> <a href="/source/s?defs=other&amp;project=rtmp_client">other</a> = (<a class="d" href="#MP4Frame">MP4Frame</a>) <a class="d" href="#obj">obj</a>;
<a class="l" name="139" href="#139">139</a>		<b>if</b> (<a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> != <a href="/source/s?defs=other&amp;project=rtmp_client">other</a>.<a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>)
<a class="hl" name="140" href="#140">140</a>			<b>return</b> <b>false</b>;
<a class="l" name="141" href="#141">141</a>		<b>if</b> (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> != <a href="/source/s?defs=other&amp;project=rtmp_client">other</a>.<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>)
<a class="l" name="142" href="#142">142</a>			<b>return</b> <b>false</b>;
<a class="l" name="143" href="#143">143</a>		<b>return</b> <b>true</b>;
<a class="l" name="144" href="#144">144</a>	}
<a class="l" name="145" href="#145">145</a>
<a class="l" name="146" href="#146">146</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="147" href="#147">147</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toString"/><a href="/source/s?refs=toString&amp;project=rtmp_client" class="xmt">toString</a>() {
<a class="l" name="148" href="#148">148</a>		<a href="/source/s?defs=StringBuilder&amp;project=rtmp_client">StringBuilder</a> <a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a> = <b>new</b> <a href="/source/s?defs=StringBuilder&amp;project=rtmp_client">StringBuilder</a>(<span class="s">"MP4Frame type="</span>);
<a class="l" name="149" href="#149">149</a>		<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>);
<a class="hl" name="150" href="#150">150</a>		<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">", time="</span>);
<a class="l" name="151" href="#151">151</a>		<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a href="/source/s?defs=time&amp;project=rtmp_client">time</a>);
<a class="l" name="152" href="#152">152</a>		<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">", timeOffset="</span>);
<a class="l" name="153" href="#153">153</a>		<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a href="/source/s?defs=timeOffset&amp;project=rtmp_client">timeOffset</a>);
<a class="l" name="154" href="#154">154</a>		<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">", size="</span>);
<a class="l" name="155" href="#155">155</a>		<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>);
<a class="l" name="156" href="#156">156</a>		<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">", offset="</span>);
<a class="l" name="157" href="#157">157</a>		<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>);
<a class="l" name="158" href="#158">158</a>		<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<span class="s">", keyframe="</span>);
<a class="l" name="159" href="#159">159</a>		<a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a href="/source/s?defs=append&amp;project=rtmp_client">append</a>(<a href="/source/s?defs=keyFrame&amp;project=rtmp_client">keyFrame</a>);
<a class="hl" name="160" href="#160">160</a>		<b>return</b> <a href="/source/s?defs=sb&amp;project=rtmp_client">sb</a>.<a class="d" href="#toString">toString</a>();
<a class="l" name="161" href="#161">161</a>	}
<a class="l" name="162" href="#162">162</a>
<a class="l" name="163" href="#163">163</a>	<span class="c">/**
<a class="l" name="164" href="#164">164</a>	 * The frames are expected to be sorted by their timestamp
<a class="l" name="165" href="#165">165</a>	 */</span>
<a class="l" name="166" href="#166">166</a>	<b>public</b> <b>int</b> <a class="xmt" name="compareTo"/><a href="/source/s?refs=compareTo&amp;project=rtmp_client" class="xmt">compareTo</a>(<a class="d" href="#MP4Frame">MP4Frame</a> <a class="xa" name="that"/><a href="/source/s?refs=that&amp;project=rtmp_client" class="xa">that</a>) {
<a class="l" name="167" href="#167">167</a>		<b>int</b> <a href="/source/s?defs=ret&amp;project=rtmp_client">ret</a> = <span class="n">0</span>;
<a class="l" name="168" href="#168">168</a>		<b>if</b> (<b>this</b>.<a href="/source/s?defs=time&amp;project=rtmp_client">time</a> &gt; <a class="d" href="#that">that</a>.<a class="d" href="#getTime">getTime</a>()) {
<a class="l" name="169" href="#169">169</a>			<a href="/source/s?defs=ret&amp;project=rtmp_client">ret</a> = <span class="n">1</span>;
<a class="hl" name="170" href="#170">170</a>		} <b>else</b> <b>if</b> (<b>this</b>.<a href="/source/s?defs=time&amp;project=rtmp_client">time</a> &lt; <a class="d" href="#that">that</a>.<a class="d" href="#getTime">getTime</a>()) {
<a class="l" name="171" href="#171">171</a>			<a href="/source/s?defs=ret&amp;project=rtmp_client">ret</a> = -<span class="n">1</span>;
<a class="l" name="172" href="#172">172</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>.<a href="/source/s?defs=doubleToLongBits&amp;project=rtmp_client">doubleToLongBits</a>(<a href="/source/s?defs=time&amp;project=rtmp_client">time</a>) == <a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>.<a href="/source/s?defs=doubleToLongBits&amp;project=rtmp_client">doubleToLongBits</a>(<a class="d" href="#that">that</a>.<a class="d" href="#getTime">getTime</a>()) &amp;&amp; <b>this</b>.<a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> &gt; <a class="d" href="#that">that</a>.<a class="d" href="#getOffset">getOffset</a>()) {
<a class="l" name="173" href="#173">173</a>			<a href="/source/s?defs=ret&amp;project=rtmp_client">ret</a> = <span class="n">1</span>;
<a class="l" name="174" href="#174">174</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>.<a href="/source/s?defs=doubleToLongBits&amp;project=rtmp_client">doubleToLongBits</a>(<a href="/source/s?defs=time&amp;project=rtmp_client">time</a>) == <a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>.<a href="/source/s?defs=doubleToLongBits&amp;project=rtmp_client">doubleToLongBits</a>(<a class="d" href="#that">that</a>.<a class="d" href="#getTime">getTime</a>()) &amp;&amp; <b>this</b>.<a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> &lt; <a class="d" href="#that">that</a>.<a class="d" href="#getOffset">getOffset</a>()) {
<a class="l" name="175" href="#175">175</a>			<a href="/source/s?defs=ret&amp;project=rtmp_client">ret</a> = -<span class="n">1</span>;
<a class="l" name="176" href="#176">176</a>		}
<a class="l" name="177" href="#177">177</a>		<b>return</b> <a href="/source/s?defs=ret&amp;project=rtmp_client">ret</a>;
<a class="l" name="178" href="#178">178</a>	}
<a class="l" name="179" href="#179">179</a>
<a class="hl" name="180" href="#180">180</a>}
<a class="l" name="181" href="#181">181</a>