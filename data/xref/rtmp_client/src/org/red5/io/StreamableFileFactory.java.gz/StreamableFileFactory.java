<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["StreamableFileFactory",32]]],["Package","xp",[["org.red5.io",1]]],["Method","xmt",[["getService",50],["getServices",63],["setServices",44]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=File&amp;project=rtmp_client">File</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashSet&amp;project=rtmp_client">HashSet</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>;
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a><span class="c">/**
<a class="hl" name="30" href="#30">30</a> * Creates streamable file services
<a class="l" name="31" href="#31">31</a> */</span>
<a class="l" name="32" href="#32">32</a><b>public</b> <b>class</b> <a class="xc" name="StreamableFileFactory"/><a href="/source/s?refs=StreamableFileFactory&amp;project=rtmp_client" class="xc">StreamableFileFactory</a> <b>implements</b> <a href="/source/s?defs=IStreamableFileFactory&amp;project=rtmp_client">IStreamableFileFactory</a> {
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a>	<span class="c">// Initialize Logging</span>
<a class="l" name="35" href="#35">35</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="logger"/><a href="/source/s?refs=logger&amp;project=rtmp_client" class="xfld">logger</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a class="d" href="#StreamableFileFactory">StreamableFileFactory</a>.<b>class</b>);
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a>	<b>private</b> <a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>&lt;<a href="/source/s?defs=IStreamableFileService&amp;project=rtmp_client">IStreamableFileService</a>&gt; <a class="xfld" name="services"/><a href="/source/s?refs=services&amp;project=rtmp_client" class="xfld">services</a> = <b>new</b> <a href="/source/s?defs=HashSet&amp;project=rtmp_client">HashSet</a>&lt;<a href="/source/s?defs=IStreamableFileService&amp;project=rtmp_client">IStreamableFileService</a>&gt;();
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>	<span class="c">/**
<a class="hl" name="40" href="#40">40</a>	 * Setter for services
<a class="l" name="41" href="#41">41</a>	 *
<a class="l" name="42" href="#42">42</a>	 * <strong>@param</strong> <em>services</em> Set of streamable file services
<a class="l" name="43" href="#43">43</a>	 */</span>
<a class="l" name="44" href="#44">44</a>	<b>public</b> <b>void</b> <a class="xmt" name="setServices"/><a href="/source/s?refs=setServices&amp;project=rtmp_client" class="xmt">setServices</a>(<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>&lt;<a href="/source/s?defs=IStreamableFileService&amp;project=rtmp_client">IStreamableFileService</a>&gt; <a class="xa" name="services"/><a href="/source/s?refs=services&amp;project=rtmp_client" class="xa">services</a>) {
<a class="l" name="45" href="#45">45</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"StreamableFileFactory set services"</span>);
<a class="l" name="46" href="#46">46</a>		<b>this</b>.<a href="/source/s?defs=services&amp;project=rtmp_client">services</a> = <a href="/source/s?defs=services&amp;project=rtmp_client">services</a>;
<a class="l" name="47" href="#47">47</a>	}
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="50" href="#50">50</a>	<b>public</b> <a href="/source/s?defs=IStreamableFileService&amp;project=rtmp_client">IStreamableFileService</a> <a class="xmt" name="getService"/><a href="/source/s?refs=getService&amp;project=rtmp_client" class="xmt">getService</a>(<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a class="xa" name="fp"/><a href="/source/s?refs=fp&amp;project=rtmp_client" class="xa">fp</a>) {
<a class="l" name="51" href="#51">51</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Get service for file: "</span> + <a class="d" href="#fp">fp</a>.<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>());
<a class="l" name="52" href="#52">52</a>		<span class="c">// Return first service that can handle the passed file</span>
<a class="l" name="53" href="#53">53</a>		<b>for</b> (<a href="/source/s?defs=IStreamableFileService&amp;project=rtmp_client">IStreamableFileService</a> <a href="/source/s?defs=service&amp;project=rtmp_client">service</a> : <b>this</b>.<a href="/source/s?defs=services&amp;project=rtmp_client">services</a>) {
<a class="l" name="54" href="#54">54</a>			<b>if</b> (<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=canHandle&amp;project=rtmp_client">canHandle</a>(<a class="d" href="#fp">fp</a>)) {
<a class="l" name="55" href="#55">55</a>				<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Found service"</span>);
<a class="l" name="56" href="#56">56</a>				<b>return</b> <a href="/source/s?defs=service&amp;project=rtmp_client">service</a>;
<a class="l" name="57" href="#57">57</a>			}
<a class="l" name="58" href="#58">58</a>		}
<a class="l" name="59" href="#59">59</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="hl" name="60" href="#60">60</a>	}
<a class="l" name="61" href="#61">61</a>
<a class="l" name="62" href="#62">62</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="63" href="#63">63</a>	<b>public</b> <a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>&lt;<a href="/source/s?defs=IStreamableFileService&amp;project=rtmp_client">IStreamableFileService</a>&gt; <a class="xmt" name="getServices"/><a href="/source/s?refs=getServices&amp;project=rtmp_client" class="xmt">getServices</a>() {
<a class="l" name="64" href="#64">64</a>		<a class="d" href="#logger">logger</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"StreamableFileFactory get services"</span>);
<a class="l" name="65" href="#65">65</a>		<b>return</b> <a href="/source/s?defs=services&amp;project=rtmp_client">services</a>;
<a class="l" name="66" href="#66">66</a>	}
<a class="l" name="67" href="#67">67</a>}
<a class="l" name="68" href="#68">68</a>