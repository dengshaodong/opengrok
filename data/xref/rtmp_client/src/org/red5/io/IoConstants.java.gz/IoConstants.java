<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.red5.io",1]]],["Interface","xi",[["IoConstants",26]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><span class="c">/**
<a class="l" name="23" href="#23">23</a> * Constants found in FLV files / streams.
<a class="l" name="24" href="#24">24</a> *
<a class="l" name="25" href="#25">25</a> */</span>
<a class="l" name="26" href="#26">26</a><b>public</b> <b>interface</b> <a class="xi" name="IoConstants"/><a href="/source/s?refs=IoConstants&amp;project=rtmp_client" class="xi">IoConstants</a> {
<a class="l" name="27" href="#27">27</a>	<span class="c">/**
<a class="l" name="28" href="#28">28</a>	 * Video data
<a class="l" name="29" href="#29">29</a>	 */</span>
<a class="hl" name="30" href="#30">30</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_VIDEO"/><a href="/source/s?refs=TYPE_VIDEO&amp;project=rtmp_client" class="xfld">TYPE_VIDEO</a> = <span class="n">0x09</span>;
<a class="l" name="31" href="#31">31</a>
<a class="l" name="32" href="#32">32</a>	<span class="c">/**
<a class="l" name="33" href="#33">33</a>	 * Audio data
<a class="l" name="34" href="#34">34</a>	 */</span>
<a class="l" name="35" href="#35">35</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_AUDIO"/><a href="/source/s?refs=TYPE_AUDIO&amp;project=rtmp_client" class="xfld">TYPE_AUDIO</a> = <span class="n">0x08</span>;
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a>	<span class="c">/**
<a class="l" name="38" href="#38">38</a>	 * Metadata
<a class="l" name="39" href="#39">39</a>	 */</span>
<a class="hl" name="40" href="#40">40</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_METADATA"/><a href="/source/s?refs=TYPE_METADATA&amp;project=rtmp_client" class="xfld">TYPE_METADATA</a> = <span class="n">0x12</span>;
<a class="l" name="41" href="#41">41</a>
<a class="l" name="42" href="#42">42</a>	<span class="c">/**
<a class="l" name="43" href="#43">43</a>	 * Encryption
<a class="l" name="44" href="#44">44</a>	 */</span>
<a class="l" name="45" href="#45">45</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_ENCRYPTED"/><a href="/source/s?refs=TYPE_ENCRYPTED&amp;project=rtmp_client" class="xfld">TYPE_ENCRYPTED</a> = <span class="n">0x20</span>;
<a class="l" name="46" href="#46">46</a>
<a class="l" name="47" href="#47">47</a>	<span class="c">/**
<a class="l" name="48" href="#48">48</a>	 * Encrypted audio data
<a class="l" name="49" href="#49">49</a>	 */</span>
<a class="hl" name="50" href="#50">50</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_ENCRYPTED_AUDIO"/><a href="/source/s?refs=TYPE_ENCRYPTED_AUDIO&amp;project=rtmp_client" class="xfld">TYPE_ENCRYPTED_AUDIO</a> = <a class="d" href="#TYPE_AUDIO">TYPE_AUDIO</a> + <a class="d" href="#TYPE_ENCRYPTED">TYPE_ENCRYPTED</a>;
<a class="l" name="51" href="#51">51</a>
<a class="l" name="52" href="#52">52</a>	<span class="c">/**
<a class="l" name="53" href="#53">53</a>	 * Encrypted video data
<a class="l" name="54" href="#54">54</a>	 */</span>
<a class="l" name="55" href="#55">55</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_ENCRYPTED_VIDEO"/><a href="/source/s?refs=TYPE_ENCRYPTED_VIDEO&amp;project=rtmp_client" class="xfld">TYPE_ENCRYPTED_VIDEO</a> = <a class="d" href="#TYPE_VIDEO">TYPE_VIDEO</a> + <a class="d" href="#TYPE_ENCRYPTED">TYPE_ENCRYPTED</a>;
<a class="l" name="56" href="#56">56</a>
<a class="l" name="57" href="#57">57</a>	<span class="c">/**
<a class="l" name="58" href="#58">58</a>	 * Encrypted meta data
<a class="l" name="59" href="#59">59</a>	 */</span>
<a class="hl" name="60" href="#60">60</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_ENCRYPTED_METADATA"/><a href="/source/s?refs=TYPE_ENCRYPTED_METADATA&amp;project=rtmp_client" class="xfld">TYPE_ENCRYPTED_METADATA</a> = <a class="d" href="#TYPE_METADATA">TYPE_METADATA</a> + <a class="d" href="#TYPE_ENCRYPTED">TYPE_ENCRYPTED</a>;
<a class="l" name="61" href="#61">61</a>
<a class="l" name="62" href="#62">62</a>	<span class="c">/**
<a class="l" name="63" href="#63">63</a>	 * Mask sound type
<a class="l" name="64" href="#64">64</a>	 */</span>
<a class="l" name="65" href="#65">65</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="MASK_SOUND_TYPE"/><a href="/source/s?refs=MASK_SOUND_TYPE&amp;project=rtmp_client" class="xfld">MASK_SOUND_TYPE</a> = <span class="n">0x01</span>;
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a>	<span class="c">/**
<a class="l" name="68" href="#68">68</a>	 * Mono mode
<a class="l" name="69" href="#69">69</a>	 */</span>
<a class="hl" name="70" href="#70">70</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_TYPE_MONO"/><a href="/source/s?refs=FLAG_TYPE_MONO&amp;project=rtmp_client" class="xfld">FLAG_TYPE_MONO</a> = <span class="n">0x00</span>;
<a class="l" name="71" href="#71">71</a>
<a class="l" name="72" href="#72">72</a>	<span class="c">/**
<a class="l" name="73" href="#73">73</a>	 * Stereo mode
<a class="l" name="74" href="#74">74</a>	 */</span>
<a class="l" name="75" href="#75">75</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_TYPE_STEREO"/><a href="/source/s?refs=FLAG_TYPE_STEREO&amp;project=rtmp_client" class="xfld">FLAG_TYPE_STEREO</a> = <span class="n">0x01</span>;
<a class="l" name="76" href="#76">76</a>
<a class="l" name="77" href="#77">77</a>	<span class="c">/**
<a class="l" name="78" href="#78">78</a>	 * Mask sound size
<a class="l" name="79" href="#79">79</a>	 */</span>
<a class="hl" name="80" href="#80">80</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="MASK_SOUND_SIZE"/><a href="/source/s?refs=MASK_SOUND_SIZE&amp;project=rtmp_client" class="xfld">MASK_SOUND_SIZE</a> = <span class="n">0x02</span>;
<a class="l" name="81" href="#81">81</a>
<a class="l" name="82" href="#82">82</a>	<span class="c">/**
<a class="l" name="83" href="#83">83</a>	 * 8 bit flag size
<a class="l" name="84" href="#84">84</a>	 */</span>
<a class="l" name="85" href="#85">85</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_SIZE_8_BIT"/><a href="/source/s?refs=FLAG_SIZE_8_BIT&amp;project=rtmp_client" class="xfld">FLAG_SIZE_8_BIT</a> = <span class="n">0x00</span>;
<a class="l" name="86" href="#86">86</a>
<a class="l" name="87" href="#87">87</a>	<span class="c">/**
<a class="l" name="88" href="#88">88</a>	 * 16 bit flag size
<a class="l" name="89" href="#89">89</a>	 */</span>
<a class="hl" name="90" href="#90">90</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_SIZE_16_BIT"/><a href="/source/s?refs=FLAG_SIZE_16_BIT&amp;project=rtmp_client" class="xfld">FLAG_SIZE_16_BIT</a> = <span class="n">0x01</span>;
<a class="l" name="91" href="#91">91</a>
<a class="l" name="92" href="#92">92</a>	<span class="c">/**
<a class="l" name="93" href="#93">93</a>	 * Mask sound rate
<a class="l" name="94" href="#94">94</a>	 */</span>
<a class="l" name="95" href="#95">95</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="MASK_SOUND_RATE"/><a href="/source/s?refs=MASK_SOUND_RATE&amp;project=rtmp_client" class="xfld">MASK_SOUND_RATE</a> = <span class="n">0x0C</span>;
<a class="l" name="96" href="#96">96</a>
<a class="l" name="97" href="#97">97</a>	<span class="c">/**
<a class="l" name="98" href="#98">98</a>	 * 5.5 KHz rate flag
<a class="l" name="99" href="#99">99</a>	 */</span>
<a class="hl" name="100" href="#100">100</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_RATE_5_5_KHZ"/><a href="/source/s?refs=FLAG_RATE_5_5_KHZ&amp;project=rtmp_client" class="xfld">FLAG_RATE_5_5_KHZ</a> = <span class="n">0x00</span>;
<a class="l" name="101" href="#101">101</a>
<a class="l" name="102" href="#102">102</a>	<span class="c">/**
<a class="l" name="103" href="#103">103</a>	 * 11 KHz rate flag
<a class="l" name="104" href="#104">104</a>	 */</span>
<a class="l" name="105" href="#105">105</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_RATE_11_KHZ"/><a href="/source/s?refs=FLAG_RATE_11_KHZ&amp;project=rtmp_client" class="xfld">FLAG_RATE_11_KHZ</a> = <span class="n">0x01</span>;
<a class="l" name="106" href="#106">106</a>
<a class="l" name="107" href="#107">107</a>	<span class="c">/**
<a class="l" name="108" href="#108">108</a>	 * 22 KHz rate flag
<a class="l" name="109" href="#109">109</a>	 */</span>
<a class="hl" name="110" href="#110">110</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_RATE_22_KHZ"/><a href="/source/s?refs=FLAG_RATE_22_KHZ&amp;project=rtmp_client" class="xfld">FLAG_RATE_22_KHZ</a> = <span class="n">0x02</span>;
<a class="l" name="111" href="#111">111</a>
<a class="l" name="112" href="#112">112</a>	<span class="c">/**
<a class="l" name="113" href="#113">113</a>	 * 44 KHz rate flag
<a class="l" name="114" href="#114">114</a>	 */</span>
<a class="l" name="115" href="#115">115</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_RATE_44_KHZ"/><a href="/source/s?refs=FLAG_RATE_44_KHZ&amp;project=rtmp_client" class="xfld">FLAG_RATE_44_KHZ</a> = <span class="n">0x03</span>;
<a class="l" name="116" href="#116">116</a>
<a class="l" name="117" href="#117">117</a>	<span class="c">/**
<a class="l" name="118" href="#118">118</a>	 * Mask sound format (unsigned)
<a class="l" name="119" href="#119">119</a>	 */</span>
<a class="hl" name="120" href="#120">120</a>	<b>public</b> <b>static</b> <b>final</b> <b>int</b> <a class="xfld" name="MASK_SOUND_FORMAT"/><a href="/source/s?refs=MASK_SOUND_FORMAT&amp;project=rtmp_client" class="xfld">MASK_SOUND_FORMAT</a> = <span class="n">0xf0</span>;
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>	<span class="c">/**
<a class="l" name="123" href="#123">123</a>	 * Raw data format flag
<a class="l" name="124" href="#124">124</a>	 */</span>
<a class="l" name="125" href="#125">125</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_FORMAT_RAW"/><a href="/source/s?refs=FLAG_FORMAT_RAW&amp;project=rtmp_client" class="xfld">FLAG_FORMAT_RAW</a> = <span class="n">0x00</span>;
<a class="l" name="126" href="#126">126</a>
<a class="l" name="127" href="#127">127</a>	<span class="c">/**
<a class="l" name="128" href="#128">128</a>	 * ADPCM format flag
<a class="l" name="129" href="#129">129</a>	 */</span>
<a class="hl" name="130" href="#130">130</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_FORMAT_ADPCM"/><a href="/source/s?refs=FLAG_FORMAT_ADPCM&amp;project=rtmp_client" class="xfld">FLAG_FORMAT_ADPCM</a> = <span class="n">0x01</span>;
<a class="l" name="131" href="#131">131</a>
<a class="l" name="132" href="#132">132</a>	<span class="c">/**
<a class="l" name="133" href="#133">133</a>	 * MP3 format flag
<a class="l" name="134" href="#134">134</a>	 */</span>
<a class="l" name="135" href="#135">135</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_FORMAT_MP3"/><a href="/source/s?refs=FLAG_FORMAT_MP3&amp;project=rtmp_client" class="xfld">FLAG_FORMAT_MP3</a> = <span class="n">0x02</span>;
<a class="l" name="136" href="#136">136</a>
<a class="l" name="137" href="#137">137</a>	<span class="c">/**
<a class="l" name="138" href="#138">138</a>	 * 8 KHz NellyMoser audio format flag
<a class="l" name="139" href="#139">139</a>	 */</span>
<a class="hl" name="140" href="#140">140</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_FORMAT_NELLYMOSER_8_KHZ"/><a href="/source/s?refs=FLAG_FORMAT_NELLYMOSER_8_KHZ&amp;project=rtmp_client" class="xfld">FLAG_FORMAT_NELLYMOSER_8_KHZ</a> = <span class="n">0x05</span>;
<a class="l" name="141" href="#141">141</a>
<a class="l" name="142" href="#142">142</a>	<span class="c">/**
<a class="l" name="143" href="#143">143</a>	 * NellyMoser-encoded audio format flag
<a class="l" name="144" href="#144">144</a>	 */</span>
<a class="l" name="145" href="#145">145</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_FORMAT_NELLYMOSER"/><a href="/source/s?refs=FLAG_FORMAT_NELLYMOSER&amp;project=rtmp_client" class="xfld">FLAG_FORMAT_NELLYMOSER</a> = <span class="n">0x06</span>;
<a class="l" name="146" href="#146">146</a>
<a class="l" name="147" href="#147">147</a>
<a class="l" name="148" href="#148">148</a>	<span class="c">/**
<a class="l" name="149" href="#149">149</a>	 * aac-encoded audio format flag by dsd
<a class="hl" name="150" href="#150">150</a>	 */</span>
<a class="l" name="151" href="#151">151</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_FORMAT_AAC"/><a href="/source/s?refs=FLAG_FORMAT_AAC&amp;project=rtmp_client" class="xfld">FLAG_FORMAT_AAC</a> = <span class="n">0x0a</span>;
<a class="l" name="152" href="#152">152</a>
<a class="l" name="153" href="#153">153</a>
<a class="l" name="154" href="#154">154</a>	<span class="c">/**
<a class="l" name="155" href="#155">155</a>	 * speex-encoded audio format flag
<a class="l" name="156" href="#156">156</a>	 */</span>
<a class="l" name="157" href="#157">157</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_FORMAT_SPEEX"/><a href="/source/s?refs=FLAG_FORMAT_SPEEX&amp;project=rtmp_client" class="xfld">FLAG_FORMAT_SPEEX</a> = <span class="n">0x0b</span>;
<a class="l" name="158" href="#158">158</a>
<a class="l" name="159" href="#159">159</a>	<span class="c">/**
<a class="hl" name="160" href="#160">160</a>	 * Mask video codec
<a class="l" name="161" href="#161">161</a>	 */</span>
<a class="l" name="162" href="#162">162</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="MASK_VIDEO_CODEC"/><a href="/source/s?refs=MASK_VIDEO_CODEC&amp;project=rtmp_client" class="xfld">MASK_VIDEO_CODEC</a> = <span class="n">0x0F</span>;
<a class="l" name="163" href="#163">163</a>
<a class="l" name="164" href="#164">164</a>	<span class="c">/**
<a class="l" name="165" href="#165">165</a>	 * H263 codec flag
<a class="l" name="166" href="#166">166</a>	 */</span>
<a class="l" name="167" href="#167">167</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_CODEC_H263"/><a href="/source/s?refs=FLAG_CODEC_H263&amp;project=rtmp_client" class="xfld">FLAG_CODEC_H263</a> = <span class="n">0x02</span>;
<a class="l" name="168" href="#168">168</a>
<a class="l" name="169" href="#169">169</a>	<span class="c">/**
<a class="hl" name="170" href="#170">170</a>	 * Screen codec flag
<a class="l" name="171" href="#171">171</a>	 */</span>
<a class="l" name="172" href="#172">172</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_CODEC_SCREEN"/><a href="/source/s?refs=FLAG_CODEC_SCREEN&amp;project=rtmp_client" class="xfld">FLAG_CODEC_SCREEN</a> = <span class="n">0x03</span>;
<a class="l" name="173" href="#173">173</a>
<a class="l" name="174" href="#174">174</a>	<span class="c">/**
<a class="l" name="175" href="#175">175</a>	 * On2 VP6 codec flag
<a class="l" name="176" href="#176">176</a>	 */</span>
<a class="l" name="177" href="#177">177</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_CODEC_VP6"/><a href="/source/s?refs=FLAG_CODEC_VP6&amp;project=rtmp_client" class="xfld">FLAG_CODEC_VP6</a> = <span class="n">0x04</span>;
<a class="l" name="178" href="#178">178</a>
<a class="l" name="179" href="#179">179</a>	<span class="c">/**
<a class="hl" name="180" href="#180">180</a>	 * H264 codec flag
<a class="l" name="181" href="#181">181</a>	 */</span>
<a class="l" name="182" href="#182">182</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_CODEC_H264"/><a href="/source/s?refs=FLAG_CODEC_H264&amp;project=rtmp_client" class="xfld">FLAG_CODEC_H264</a> = <span class="n">0x07</span>;
<a class="l" name="183" href="#183">183</a>
<a class="l" name="184" href="#184">184</a>	<span class="c">/**
<a class="l" name="185" href="#185">185</a>	 * Video frametype flag
<a class="l" name="186" href="#186">186</a>	 */</span>
<a class="l" name="187" href="#187">187</a>	<b>public</b> <b>static</b> <b>final</b> <b>int</b> <a class="xfld" name="MASK_VIDEO_FRAMETYPE"/><a href="/source/s?refs=MASK_VIDEO_FRAMETYPE&amp;project=rtmp_client" class="xfld">MASK_VIDEO_FRAMETYPE</a> = <span class="n">0xf0</span>;
<a class="l" name="188" href="#188">188</a>
<a class="l" name="189" href="#189">189</a>	<span class="c">/**
<a class="hl" name="190" href="#190">190</a>	 * Keyframe type flag
<a class="l" name="191" href="#191">191</a>	 */</span>
<a class="l" name="192" href="#192">192</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_FRAMETYPE_KEYFRAME"/><a href="/source/s?refs=FLAG_FRAMETYPE_KEYFRAME&amp;project=rtmp_client" class="xfld">FLAG_FRAMETYPE_KEYFRAME</a> = <span class="n">0x01</span>;
<a class="l" name="193" href="#193">193</a>
<a class="l" name="194" href="#194">194</a>	<span class="c">/**
<a class="l" name="195" href="#195">195</a>	 * Interframe flag. Interframes are created from keyframes rather than independent image
<a class="l" name="196" href="#196">196</a>	 */</span>
<a class="l" name="197" href="#197">197</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_FRAMETYPE_INTERFRAME"/><a href="/source/s?refs=FLAG_FRAMETYPE_INTERFRAME&amp;project=rtmp_client" class="xfld">FLAG_FRAMETYPE_INTERFRAME</a> = <span class="n">0x02</span>;
<a class="l" name="198" href="#198">198</a>
<a class="l" name="199" href="#199">199</a>	<span class="c">/**
<a class="hl" name="200" href="#200">200</a>	 * Disposable frame type flag
<a class="l" name="201" href="#201">201</a>	 */</span>
<a class="l" name="202" href="#202">202</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_FRAMETYPE_DISPOSABLE"/><a href="/source/s?refs=FLAG_FRAMETYPE_DISPOSABLE&amp;project=rtmp_client" class="xfld">FLAG_FRAMETYPE_DISPOSABLE</a> = <span class="n">0x03</span>;
<a class="l" name="203" href="#203">203</a>
<a class="l" name="204" href="#204">204</a>	<span class="c">/**
<a class="l" name="205" href="#205">205</a>	 * Generated keyframe type flag
<a class="l" name="206" href="#206">206</a>	 */</span>
<a class="l" name="207" href="#207">207</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_FRAMETYPE_GENERATED_KEYFRAME"/><a href="/source/s?refs=FLAG_FRAMETYPE_GENERATED_KEYFRAME&amp;project=rtmp_client" class="xfld">FLAG_FRAMETYPE_GENERATED_KEYFRAME</a> = <span class="n">0x04</span>;
<a class="l" name="208" href="#208">208</a>
<a class="l" name="209" href="#209">209</a>	<span class="c">/**
<a class="hl" name="210" href="#210">210</a>	 * Info frame type flag
<a class="l" name="211" href="#211">211</a>	 */</span>
<a class="l" name="212" href="#212">212</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="FLAG_FRAMETYPE_INFO"/><a href="/source/s?refs=FLAG_FRAMETYPE_INFO&amp;project=rtmp_client" class="xfld">FLAG_FRAMETYPE_INFO</a> = <span class="n">0x05</span>;
<a class="l" name="213" href="#213">213</a>
<a class="l" name="214" href="#214">214</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="AVC_PACKET_TYPE_SEQUENCE_HEADER"/><a href="/source/s?refs=AVC_PACKET_TYPE_SEQUENCE_HEADER&amp;project=rtmp_client" class="xfld">AVC_PACKET_TYPE_SEQUENCE_HEADER</a> = <span class="n">0x00</span>;
<a class="l" name="215" href="#215">215</a>
<a class="l" name="216" href="#216">216</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="AVC_PACKET_TYPE_NALU"/><a href="/source/s?refs=AVC_PACKET_TYPE_NALU&amp;project=rtmp_client" class="xfld">AVC_PACKET_TYPE_NALU</a> = <span class="n">0x01</span>;
<a class="l" name="217" href="#217">217</a>
<a class="l" name="218" href="#218">218</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="AVC_PACKET_TYPE_END_OF_SEQUENCE"/><a href="/source/s?refs=AVC_PACKET_TYPE_END_OF_SEQUENCE&amp;project=rtmp_client" class="xfld">AVC_PACKET_TYPE_END_OF_SEQUENCE</a> = <span class="n">0x02</span>;
<a class="l" name="219" href="#219">219</a>
<a class="hl" name="220" href="#220">220</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="INFO_PACKET_SEEK_START"/><a href="/source/s?refs=INFO_PACKET_SEEK_START&amp;project=rtmp_client" class="xfld">INFO_PACKET_SEEK_START</a> = <span class="n">0x00</span>;
<a class="l" name="221" href="#221">221</a>
<a class="l" name="222" href="#222">222</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="INFO_PACKET_SEEK_END"/><a href="/source/s?refs=INFO_PACKET_SEEK_END&amp;project=rtmp_client" class="xfld">INFO_PACKET_SEEK_END</a> = <span class="n">0x01</span>;
<a class="l" name="223" href="#223">223</a>
<a class="l" name="224" href="#224">224</a>}
<a class="l" name="225" href="#225">225</a>