<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["Output",59]]],["Package","xp",[["org.red5.io.amf",1]]],["Method","xmt",[["Output",117],["buf",592],["checkWriteReference",127],["encodeString",542],["getField",393],["isCustom",123],["putString",560],["putString",567],["reset",596],["serializeField",368],["supportsDataType",268],["writeArbitraryObject",475],["writeArray",136],["writeArray",149],["writeArray",167],["writeBoolean",273],["writeByteArray",532],["writeCustom",279],["writeDate",284],["writeMap",184],["writeMap",222],["writeNull",291],["writeNumber",297],["writeObject",311],["writeObject",449],["writeRecordSet",247],["writeReference",303],["writeString",518],["writeXML",572],["writeXML",583]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><span class="c">//import java.io.File;</span>
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=lang&amp;project=rtmp_client">lang</a>.<a href="/source/s?defs=reflect&amp;project=rtmp_client">reflect</a>.<a href="/source/s?defs=Array&amp;project=rtmp_client">Array</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=lang&amp;project=rtmp_client">lang</a>.<a href="/source/s?defs=reflect&amp;project=rtmp_client">reflect</a>.<a href="/source/s?defs=Field&amp;project=rtmp_client">Field</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=lang&amp;project=rtmp_client">lang</a>.<a href="/source/s?defs=reflect&amp;project=rtmp_client">reflect</a>.<a href="/source/s?defs=Method&amp;project=rtmp_client">Method</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Collection&amp;project=rtmp_client">Collection</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Date&amp;project=rtmp_client">Date</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="31" href="#31">31</a><span class="c">//import java.util.Set;</span>
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=TimeZone&amp;project=rtmp_client">TimeZone</a>;
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a><span class="c">//import net.sf.ehcache.Cache;</span>
<a class="l" name="35" href="#35">35</a><span class="c">//import net.sf.ehcache.CacheException;</span>
<a class="l" name="36" href="#36">36</a><span class="c">//import net.sf.ehcache.CacheManager;</span>
<a class="l" name="37" href="#37">37</a><span class="c">//import net.sf.ehcache.Element;</span>
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a><span class="c">//import org.apache.commons.beanutils.BeanMap;</span>
<a class="hl" name="40" href="#40">40</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="41" href="#41">41</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=annotations&amp;project=rtmp_client">annotations</a>.<a href="/source/s?defs=Anonymous&amp;project=rtmp_client">Anonymous</a>;
<a class="l" name="42" href="#42">42</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>.<a href="/source/s?defs=ByteArray&amp;project=rtmp_client">ByteArray</a>;
<a class="l" name="43" href="#43">43</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=BaseOutput&amp;project=rtmp_client">BaseOutput</a>;
<a class="l" name="44" href="#44">44</a><span class="c">//import org.red5.io.object.ICustomSerializable;</span>
<a class="l" name="45" href="#45">45</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=RecordSet&amp;project=rtmp_client">RecordSet</a>;
<a class="l" name="46" href="#46">46</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>;
<a class="l" name="47" href="#47">47</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>.<a href="/source/s?defs=XMLUtils&amp;project=rtmp_client">XMLUtils</a>;
<a class="l" name="48" href="#48">48</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="49" href="#49">49</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="hl" name="50" href="#50">50</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=w3c&amp;project=rtmp_client">w3c</a>.<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a>;
<a class="l" name="51" href="#51">51</a>
<a class="l" name="52" href="#52">52</a><span class="c">/**
<a class="l" name="53" href="#53">53</a> *
<a class="l" name="54" href="#54">54</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="55" href="#55">55</a> * <strong>@author</strong> Luke Hubbard, Codegent Ltd (luke@codegent.com)
<a class="l" name="56" href="#56">56</a> * <strong>@author</strong> Paul Gregoire (mondain@gmail.com)
<a class="l" name="57" href="#57">57</a> * <strong>@author</strong> Harald Radi (harald.radi@nme.at)
<a class="l" name="58" href="#58">58</a> */</span>
<a class="l" name="59" href="#59">59</a><b>public</b> <b>class</b> <a class="xc" name="Output"/><a href="/source/s?refs=Output&amp;project=rtmp_client" class="xc">Output</a> <b>extends</b> <a href="/source/s?defs=BaseOutput&amp;project=rtmp_client">BaseOutput</a> <b>implements</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a class="xc" name="Output"/><a href="/source/s?refs=Output&amp;project=rtmp_client" class="xc">Output</a> {
<a class="hl" name="60" href="#60">60</a>
<a class="l" name="61" href="#61">61</a>	<b>protected</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>.<b>class</b>);
<a class="l" name="62" href="#62">62</a>
<a class="l" name="63" href="#63">63</a>	<span class="c">/**
<a class="l" name="64" href="#64">64</a>	 * Cache encoded strings... the TK way...
<a class="l" name="65" href="#65">65</a>	 */</span>
<a class="l" name="66" href="#66">66</a><span class="c">//	private static Cache stringCache;</span>
<a class="l" name="67" href="#67">67</a><span class="c">//</span>
<a class="l" name="68" href="#68">68</a><span class="c">//	private static Cache serializeCache;</span>
<a class="l" name="69" href="#69">69</a><span class="c">//</span>
<a class="hl" name="70" href="#70">70</a><span class="c">//	private static Cache fieldCache;</span>
<a class="l" name="71" href="#71">71</a><span class="c">//</span>
<a class="l" name="72" href="#72">72</a><span class="c">//	private static Cache getterCache;</span>
<a class="l" name="73" href="#73">73</a><span class="c">//</span>
<a class="l" name="74" href="#74">74</a><span class="c">//	private static CacheManager cacheManager;</span>
<a class="l" name="75" href="#75">75</a>
<a class="l" name="76" href="#76">76</a><span class="c">//	private static CacheManager getCacheManager() {</span>
<a class="l" name="77" href="#77">77</a><span class="c">//		if (cacheManager == null) {</span>
<a class="l" name="78" href="#78">78</a><span class="c">//			if (System.getProperty("red5.root") != null) {</span>
<a class="l" name="79" href="#79">79</a><span class="c">//				//    			we're running Red5 as a server.</span>
<a class="hl" name="80" href="#80">80</a><span class="c">//				try {</span>
<a class="l" name="81" href="#81">81</a><span class="c">//					cacheManager = new CacheManager(System.getProperty("red5.root") + File.separator + "conf"</span>
<a class="l" name="82" href="#82">82</a><span class="c">//							+ File.separator + "<a href="/source/s?path=ehcache.xml&amp;project=rtmp_client">ehcache.xml</a>");</span>
<a class="l" name="83" href="#83">83</a><span class="c">//				} catch (CacheException e) {</span>
<a class="l" name="84" href="#84">84</a><span class="c">//					cacheManager = constructDefault();</span>
<a class="l" name="85" href="#85">85</a><span class="c">//				}</span>
<a class="l" name="86" href="#86">86</a><span class="c">//			} else {</span>
<a class="l" name="87" href="#87">87</a><span class="c">//				//    			not a server, maybe running tests?</span>
<a class="l" name="88" href="#88">88</a><span class="c">//				cacheManager = constructDefault();</span>
<a class="l" name="89" href="#89">89</a><span class="c">//			}</span>
<a class="hl" name="90" href="#90">90</a><span class="c">//		}</span>
<a class="l" name="91" href="#91">91</a><span class="c">//</span>
<a class="l" name="92" href="#92">92</a><span class="c">//		return cacheManager;</span>
<a class="l" name="93" href="#93">93</a><span class="c">//	}</span>
<a class="l" name="94" href="#94">94</a>
<a class="l" name="95" href="#95">95</a><span class="c">//	private static CacheManager constructDefault() {</span>
<a class="l" name="96" href="#96">96</a><span class="c">//		CacheManager manager = new CacheManager();</span>
<a class="l" name="97" href="#97">97</a><span class="c">//		if (!manager.cacheExists("org.red5.io.amf.Output.stringCache"))</span>
<a class="l" name="98" href="#98">98</a><span class="c">//			manager.addCache("org.red5.io.amf.Output.stringCache");</span>
<a class="l" name="99" href="#99">99</a><span class="c">//		if (!manager.cacheExists("org.red5.io.amf.Output.getterCache"))</span>
<a class="hl" name="100" href="#100">100</a><span class="c">//			manager.addCache("org.red5.io.amf.Output.getterCache");</span>
<a class="l" name="101" href="#101">101</a><span class="c">//		if (!manager.cacheExists("org.red5.io.amf.Output.fieldCache"))</span>
<a class="l" name="102" href="#102">102</a><span class="c">//			manager.addCache("org.red5.io.amf.Output.fieldCache");</span>
<a class="l" name="103" href="#103">103</a><span class="c">//		if (!manager.cacheExists("org.red5.io.amf.Output.serializeCache"))</span>
<a class="l" name="104" href="#104">104</a><span class="c">//			manager.addCache("org.red5.io.amf.Output.serializeCache");</span>
<a class="l" name="105" href="#105">105</a><span class="c">//		return manager;</span>
<a class="l" name="106" href="#106">106</a><span class="c">//	}</span>
<a class="l" name="107" href="#107">107</a>
<a class="l" name="108" href="#108">108</a>	<span class="c">/**
<a class="l" name="109" href="#109">109</a>	 * Output buffer
<a class="hl" name="110" href="#110">110</a>	 */</span>
<a class="l" name="111" href="#111">111</a>	<b>protected</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xfld" name="buf"/><a href="/source/s?refs=buf&amp;project=rtmp_client" class="xfld">buf</a>;
<a class="l" name="112" href="#112">112</a>
<a class="l" name="113" href="#113">113</a>	<span class="c">/**
<a class="l" name="114" href="#114">114</a>	 * Creates output with given byte buffer
<a class="l" name="115" href="#115">115</a>	 * <strong>@param</strong> <em>buf</em>         Bute buffer
<a class="l" name="116" href="#116">116</a>	 */</span>
<a class="l" name="117" href="#117">117</a>	<b>public</b> <a class="xmt" name="Output"/><a href="/source/s?refs=Output&amp;project=rtmp_client" class="xmt">Output</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="buf"/><a href="/source/s?refs=buf&amp;project=rtmp_client" class="xa">buf</a>) {
<a class="l" name="118" href="#118">118</a>		<b>super</b>();
<a class="l" name="119" href="#119">119</a>		<b>this</b>.<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>;
<a class="hl" name="120" href="#120">120</a>	}
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="123" href="#123">123</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="isCustom"/><a href="/source/s?refs=isCustom&amp;project=rtmp_client" class="xmt">isCustom</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="custom"/><a href="/source/s?refs=custom&amp;project=rtmp_client" class="xa">custom</a>) {
<a class="l" name="124" href="#124">124</a>		<b>return</b> <b>false</b>;
<a class="l" name="125" href="#125">125</a>	}
<a class="l" name="126" href="#126">126</a>
<a class="l" name="127" href="#127">127</a>	<b>protected</b> <b>boolean</b> <a class="xmt" name="checkWriteReference"/><a href="/source/s?refs=checkWriteReference&amp;project=rtmp_client" class="xmt">checkWriteReference</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="obj"/><a href="/source/s?refs=obj&amp;project=rtmp_client" class="xa">obj</a>) {
<a class="l" name="128" href="#128">128</a>		<b>if</b> (<a href="/source/s?defs=hasReference&amp;project=rtmp_client">hasReference</a>(<a href="/source/s?defs=obj&amp;project=rtmp_client">obj</a>)) {
<a class="l" name="129" href="#129">129</a>			<a class="d" href="#writeReference">writeReference</a>(<a href="/source/s?defs=obj&amp;project=rtmp_client">obj</a>);
<a class="hl" name="130" href="#130">130</a>			<b>return</b> <b>true</b>;
<a class="l" name="131" href="#131">131</a>		} <b>else</b>
<a class="l" name="132" href="#132">132</a>			<b>return</b> <b>false</b>;
<a class="l" name="133" href="#133">133</a>	}
<a class="l" name="134" href="#134">134</a>
<a class="l" name="135" href="#135">135</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="136" href="#136">136</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeArray"/><a href="/source/s?refs=writeArray&amp;project=rtmp_client" class="xmt">writeArray</a>(<a href="/source/s?defs=Collection&amp;project=rtmp_client">Collection</a>&lt;?&gt; <a class="xa" name="array"/><a href="/source/s?refs=array&amp;project=rtmp_client" class="xa">array</a>, <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xa" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xa">serializer</a>) {
<a class="l" name="137" href="#137">137</a>		<b>if</b> (<a class="d" href="#checkWriteReference">checkWriteReference</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>)) {
<a class="l" name="138" href="#138">138</a>			<b>return</b>;
<a class="l" name="139" href="#139">139</a>		}
<a class="hl" name="140" href="#140">140</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>);
<a class="l" name="141" href="#141">141</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_ARRAY&amp;project=rtmp_client">TYPE_ARRAY</a>);
<a class="l" name="142" href="#142">142</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>());
<a class="l" name="143" href="#143">143</a>		<b>for</b> (<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=item&amp;project=rtmp_client">item</a> : <a href="/source/s?defs=array&amp;project=rtmp_client">array</a>) {
<a class="l" name="144" href="#144">144</a>			<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<b>this</b>, <a href="/source/s?defs=item&amp;project=rtmp_client">item</a>);
<a class="l" name="145" href="#145">145</a>		}
<a class="l" name="146" href="#146">146</a>	}
<a class="l" name="147" href="#147">147</a>
<a class="l" name="148" href="#148">148</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="149" href="#149">149</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeArray"/><a href="/source/s?refs=writeArray&amp;project=rtmp_client" class="xmt">writeArray</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xa" name="array"/><a href="/source/s?refs=array&amp;project=rtmp_client" class="xa">array</a>, <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xa" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xa">serializer</a>) {
<a class="hl" name="150" href="#150">150</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"writeArray - array: {} serializer: {}"</span>, <a href="/source/s?defs=array&amp;project=rtmp_client">array</a>, <a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>);
<a class="l" name="151" href="#151">151</a>		<b>if</b> (<a href="/source/s?defs=array&amp;project=rtmp_client">array</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="152" href="#152">152</a>			<b>if</b> (<a class="d" href="#checkWriteReference">checkWriteReference</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>)) {
<a class="l" name="153" href="#153">153</a>				<b>return</b>;
<a class="l" name="154" href="#154">154</a>			}
<a class="l" name="155" href="#155">155</a>			<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>);
<a class="l" name="156" href="#156">156</a>			<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_ARRAY&amp;project=rtmp_client">TYPE_ARRAY</a>);
<a class="l" name="157" href="#157">157</a>			<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>);
<a class="l" name="158" href="#158">158</a>			<b>for</b> (<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=item&amp;project=rtmp_client">item</a> : <a href="/source/s?defs=array&amp;project=rtmp_client">array</a>) {
<a class="l" name="159" href="#159">159</a>				<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<b>this</b>, <a href="/source/s?defs=item&amp;project=rtmp_client">item</a>);
<a class="hl" name="160" href="#160">160</a>			}
<a class="l" name="161" href="#161">161</a>		} <b>else</b> {
<a class="l" name="162" href="#162">162</a>			<a class="d" href="#writeNull">writeNull</a>();
<a class="l" name="163" href="#163">163</a>		}
<a class="l" name="164" href="#164">164</a>	}
<a class="l" name="165" href="#165">165</a>
<a class="l" name="166" href="#166">166</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="167" href="#167">167</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeArray"/><a href="/source/s?refs=writeArray&amp;project=rtmp_client" class="xmt">writeArray</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="array"/><a href="/source/s?refs=array&amp;project=rtmp_client" class="xa">array</a>, <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xa" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xa">serializer</a>) {
<a class="l" name="168" href="#168">168</a>		<b>if</b> (<a href="/source/s?defs=array&amp;project=rtmp_client">array</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="169" href="#169">169</a>			<b>if</b> (<a class="d" href="#checkWriteReference">checkWriteReference</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>)) {
<a class="hl" name="170" href="#170">170</a>				<b>return</b>;
<a class="l" name="171" href="#171">171</a>			}
<a class="l" name="172" href="#172">172</a>			<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>);
<a class="l" name="173" href="#173">173</a>			<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_ARRAY&amp;project=rtmp_client">TYPE_ARRAY</a>);
<a class="l" name="174" href="#174">174</a>			<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=Array&amp;project=rtmp_client">Array</a>.<a href="/source/s?defs=getLength&amp;project=rtmp_client">getLength</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>));
<a class="l" name="175" href="#175">175</a>			<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=Array&amp;project=rtmp_client">Array</a>.<a href="/source/s?defs=getLength&amp;project=rtmp_client">getLength</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>); i++) {
<a class="l" name="176" href="#176">176</a>				<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<b>this</b>, <a href="/source/s?defs=Array&amp;project=rtmp_client">Array</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>, i));
<a class="l" name="177" href="#177">177</a>			}
<a class="l" name="178" href="#178">178</a>		} <b>else</b> {
<a class="l" name="179" href="#179">179</a>			<a class="d" href="#writeNull">writeNull</a>();
<a class="hl" name="180" href="#180">180</a>		}
<a class="l" name="181" href="#181">181</a>	}
<a class="l" name="182" href="#182">182</a>
<a class="l" name="183" href="#183">183</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="184" href="#184">184</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeMap"/><a href="/source/s?refs=writeMap&amp;project=rtmp_client" class="xmt">writeMap</a>(<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xa" name="map"/><a href="/source/s?refs=map&amp;project=rtmp_client" class="xa">map</a>, <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xa" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xa">serializer</a>) {
<a class="l" name="185" href="#185">185</a>		<b>if</b> (<a class="d" href="#checkWriteReference">checkWriteReference</a>(<a href="/source/s?defs=map&amp;project=rtmp_client">map</a>)) {
<a class="l" name="186" href="#186">186</a>			<b>return</b>;
<a class="l" name="187" href="#187">187</a>		}
<a class="l" name="188" href="#188">188</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=map&amp;project=rtmp_client">map</a>);
<a class="l" name="189" href="#189">189</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_MIXED_ARRAY&amp;project=rtmp_client">TYPE_MIXED_ARRAY</a>);
<a class="hl" name="190" href="#190">190</a>		<b>int</b> <a href="/source/s?defs=maxInt&amp;project=rtmp_client">maxInt</a> = -<span class="n">1</span>;
<a class="l" name="191" href="#191">191</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=map&amp;project=rtmp_client">map</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>(); i++) {
<a class="l" name="192" href="#192">192</a>			<b>try</b> {
<a class="l" name="193" href="#193">193</a>				<b>if</b> (!<a href="/source/s?defs=map&amp;project=rtmp_client">map</a>.<a href="/source/s?defs=containsKey&amp;project=rtmp_client">containsKey</a>(i))
<a class="l" name="194" href="#194">194</a>					<b>break</b>;
<a class="l" name="195" href="#195">195</a>			} <b>catch</b> (<a href="/source/s?defs=ClassCastException&amp;project=rtmp_client">ClassCastException</a> <a href="/source/s?defs=err&amp;project=rtmp_client">err</a>) {
<a class="l" name="196" href="#196">196</a>				<span class="c">// Map has non-number keys.</span>
<a class="l" name="197" href="#197">197</a>				<b>break</b>;
<a class="l" name="198" href="#198">198</a>			}
<a class="l" name="199" href="#199">199</a>
<a class="hl" name="200" href="#200">200</a>			<a href="/source/s?defs=maxInt&amp;project=rtmp_client">maxInt</a> = i;
<a class="l" name="201" href="#201">201</a>		}
<a class="l" name="202" href="#202">202</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=maxInt&amp;project=rtmp_client">maxInt</a> + <span class="n">1</span>);
<a class="l" name="203" href="#203">203</a>
<a class="l" name="204" href="#204">204</a>		<b>for</b> (<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>.<a href="/source/s?defs=Entry&amp;project=rtmp_client">Entry</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a> : <a href="/source/s?defs=map&amp;project=rtmp_client">map</a>.<a href="/source/s?defs=entrySet&amp;project=rtmp_client">entrySet</a>()) {
<a class="l" name="205" href="#205">205</a>			<b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=key&amp;project=rtmp_client">key</a> = <a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a>.<a href="/source/s?defs=getKey&amp;project=rtmp_client">getKey</a>().<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>();
<a class="l" name="206" href="#206">206</a>			<b>if</b> (<span class="s">"length"</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=key&amp;project=rtmp_client">key</a>)) {
<a class="l" name="207" href="#207">207</a>				<b>continue</b>;
<a class="l" name="208" href="#208">208</a>			}
<a class="l" name="209" href="#209">209</a>			<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<a href="/source/s?defs=key&amp;project=rtmp_client">key</a>);
<a class="hl" name="210" href="#210">210</a>			<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<b>this</b>, <a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a>.<a href="/source/s?defs=getValue&amp;project=rtmp_client">getValue</a>());
<a class="l" name="211" href="#211">211</a>		}
<a class="l" name="212" href="#212">212</a>		<b>if</b> (<a href="/source/s?defs=maxInt&amp;project=rtmp_client">maxInt</a> &gt;= <span class="n">0</span>) {
<a class="l" name="213" href="#213">213</a>			<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<span class="s">"length"</span>);
<a class="l" name="214" href="#214">214</a>			<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<b>this</b>, <a href="/source/s?defs=maxInt&amp;project=rtmp_client">maxInt</a> + <span class="n">1</span>);
<a class="l" name="215" href="#215">215</a>		}
<a class="l" name="216" href="#216">216</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) <span class="n">0x00</span>);
<a class="l" name="217" href="#217">217</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) <span class="n">0x00</span>);
<a class="l" name="218" href="#218">218</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_END_OF_OBJECT&amp;project=rtmp_client">TYPE_END_OF_OBJECT</a>);
<a class="l" name="219" href="#219">219</a>	}
<a class="hl" name="220" href="#220">220</a>
<a class="l" name="221" href="#221">221</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="222" href="#222">222</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeMap"/><a href="/source/s?refs=writeMap&amp;project=rtmp_client" class="xmt">writeMap</a>(<a href="/source/s?defs=Collection&amp;project=rtmp_client">Collection</a>&lt;?&gt; <a class="xa" name="array"/><a href="/source/s?refs=array&amp;project=rtmp_client" class="xa">array</a>, <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xa" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xa">serializer</a>) {
<a class="l" name="223" href="#223">223</a>		<b>if</b> (<a class="d" href="#checkWriteReference">checkWriteReference</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>)) {
<a class="l" name="224" href="#224">224</a>			<b>return</b>;
<a class="l" name="225" href="#225">225</a>		}
<a class="l" name="226" href="#226">226</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>);
<a class="l" name="227" href="#227">227</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_MIXED_ARRAY&amp;project=rtmp_client">TYPE_MIXED_ARRAY</a>);
<a class="l" name="228" href="#228">228</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>() + <span class="n">1</span>);
<a class="l" name="229" href="#229">229</a>		<b>int</b> <a href="/source/s?defs=idx&amp;project=rtmp_client">idx</a> = <span class="n">0</span>;
<a class="hl" name="230" href="#230">230</a>		<b>for</b> (<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=item&amp;project=rtmp_client">item</a> : <a href="/source/s?defs=array&amp;project=rtmp_client">array</a>) {
<a class="l" name="231" href="#231">231</a>			<b>if</b> (<a href="/source/s?defs=item&amp;project=rtmp_client">item</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="232" href="#232">232</a>				<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=idx&amp;project=rtmp_client">idx</a>++));
<a class="l" name="233" href="#233">233</a>				<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<b>this</b>, <a href="/source/s?defs=item&amp;project=rtmp_client">item</a>);
<a class="l" name="234" href="#234">234</a>			} <b>else</b> {
<a class="l" name="235" href="#235">235</a>				<a href="/source/s?defs=idx&amp;project=rtmp_client">idx</a>++;
<a class="l" name="236" href="#236">236</a>			}
<a class="l" name="237" href="#237">237</a>		}
<a class="l" name="238" href="#238">238</a>		<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<span class="s">"length"</span>);
<a class="l" name="239" href="#239">239</a>		<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<b>this</b>, <a href="/source/s?defs=array&amp;project=rtmp_client">array</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>() + <span class="n">1</span>);
<a class="hl" name="240" href="#240">240</a>
<a class="l" name="241" href="#241">241</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) <span class="n">0x00</span>);
<a class="l" name="242" href="#242">242</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) <span class="n">0x00</span>);
<a class="l" name="243" href="#243">243</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_END_OF_OBJECT&amp;project=rtmp_client">TYPE_END_OF_OBJECT</a>);
<a class="l" name="244" href="#244">244</a>	}
<a class="l" name="245" href="#245">245</a>
<a class="l" name="246" href="#246">246</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="247" href="#247">247</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeRecordSet"/><a href="/source/s?refs=writeRecordSet&amp;project=rtmp_client" class="xmt">writeRecordSet</a>(<a href="/source/s?defs=RecordSet&amp;project=rtmp_client">RecordSet</a> <a class="xa" name="recordset"/><a href="/source/s?refs=recordset&amp;project=rtmp_client" class="xa">recordset</a>, <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xa" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xa">serializer</a>) {
<a class="l" name="248" href="#248">248</a>		<b>if</b> (<a class="d" href="#checkWriteReference">checkWriteReference</a>(<a class="d" href="#recordset">recordset</a>)) {
<a class="l" name="249" href="#249">249</a>			<b>return</b>;
<a class="hl" name="250" href="#250">250</a>		}
<a class="l" name="251" href="#251">251</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a class="d" href="#recordset">recordset</a>);
<a class="l" name="252" href="#252">252</a>		<span class="c">// Write out start of object marker</span>
<a class="l" name="253" href="#253">253</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_CLASS_OBJECT&amp;project=rtmp_client">TYPE_CLASS_OBJECT</a>);
<a class="l" name="254" href="#254">254</a>		<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<span class="s">"RecordSet"</span>);
<a class="l" name="255" href="#255">255</a>		<span class="c">// Serialize</span>
<a class="l" name="256" href="#256">256</a>		<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=info&amp;project=rtmp_client">info</a> = <a class="d" href="#recordset">recordset</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>();
<a class="l" name="257" href="#257">257</a>		<span class="c">// Write out serverInfo key</span>
<a class="l" name="258" href="#258">258</a>		<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<span class="s">"serverInfo"</span>);
<a class="l" name="259" href="#259">259</a>		<span class="c">// Serialize</span>
<a class="hl" name="260" href="#260">260</a>		<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<b>this</b>, <a href="/source/s?defs=info&amp;project=rtmp_client">info</a>);
<a class="l" name="261" href="#261">261</a>		<span class="c">// Write out end of object marker</span>
<a class="l" name="262" href="#262">262</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) <span class="n">0x00</span>);
<a class="l" name="263" href="#263">263</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) <span class="n">0x00</span>);
<a class="l" name="264" href="#264">264</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_END_OF_OBJECT&amp;project=rtmp_client">TYPE_END_OF_OBJECT</a>);
<a class="l" name="265" href="#265">265</a>	}
<a class="l" name="266" href="#266">266</a>
<a class="l" name="267" href="#267">267</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="268" href="#268">268</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="supportsDataType"/><a href="/source/s?refs=supportsDataType&amp;project=rtmp_client" class="xmt">supportsDataType</a>(<b>byte</b> <a class="xa" name="type"/><a href="/source/s?refs=type&amp;project=rtmp_client" class="xa">type</a>) {
<a class="l" name="269" href="#269">269</a>		<b>return</b> <b>false</b>;
<a class="hl" name="270" href="#270">270</a>	}
<a class="l" name="271" href="#271">271</a>
<a class="l" name="272" href="#272">272</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="273" href="#273">273</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeBoolean"/><a href="/source/s?refs=writeBoolean&amp;project=rtmp_client" class="xmt">writeBoolean</a>(<a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a> <a class="xa" name="bol"/><a href="/source/s?refs=bol&amp;project=rtmp_client" class="xa">bol</a>) {
<a class="l" name="274" href="#274">274</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_BOOLEAN&amp;project=rtmp_client">TYPE_BOOLEAN</a>);
<a class="l" name="275" href="#275">275</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#bol">bol</a> ? <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=VALUE_TRUE&amp;project=rtmp_client">VALUE_TRUE</a> : <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=VALUE_FALSE&amp;project=rtmp_client">VALUE_FALSE</a>);
<a class="l" name="276" href="#276">276</a>	}
<a class="l" name="277" href="#277">277</a>
<a class="l" name="278" href="#278">278</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="279" href="#279">279</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeCustom"/><a href="/source/s?refs=writeCustom&amp;project=rtmp_client" class="xmt">writeCustom</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="custom"/><a href="/source/s?refs=custom&amp;project=rtmp_client" class="xa">custom</a>) {
<a class="hl" name="280" href="#280">280</a>
<a class="l" name="281" href="#281">281</a>	}
<a class="l" name="282" href="#282">282</a>
<a class="l" name="283" href="#283">283</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="284" href="#284">284</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeDate"/><a href="/source/s?refs=writeDate&amp;project=rtmp_client" class="xmt">writeDate</a>(<a href="/source/s?defs=Date&amp;project=rtmp_client">Date</a> <a class="xa" name="date"/><a href="/source/s?refs=date&amp;project=rtmp_client" class="xa">date</a>) {
<a class="l" name="285" href="#285">285</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_DATE&amp;project=rtmp_client">TYPE_DATE</a>);
<a class="l" name="286" href="#286">286</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=putDouble&amp;project=rtmp_client">putDouble</a>(<a class="d" href="#date">date</a>.<a href="/source/s?defs=getTime&amp;project=rtmp_client">getTime</a>());
<a class="l" name="287" href="#287">287</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=putShort&amp;project=rtmp_client">putShort</a>((<b>short</b>) (<a href="/source/s?defs=TimeZone&amp;project=rtmp_client">TimeZone</a>.<a href="/source/s?defs=getDefault&amp;project=rtmp_client">getDefault</a>().<a href="/source/s?defs=getRawOffset&amp;project=rtmp_client">getRawOffset</a>() / <span class="n">60</span> / <span class="n">1000</span>));
<a class="l" name="288" href="#288">288</a>	}
<a class="l" name="289" href="#289">289</a>
<a class="hl" name="290" href="#290">290</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="291" href="#291">291</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeNull"/><a href="/source/s?refs=writeNull&amp;project=rtmp_client" class="xmt">writeNull</a>() {
<a class="l" name="292" href="#292">292</a>		<span class="c">// System.err.println("Write null");</span>
<a class="l" name="293" href="#293">293</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_NULL&amp;project=rtmp_client">TYPE_NULL</a>);
<a class="l" name="294" href="#294">294</a>	}
<a class="l" name="295" href="#295">295</a>
<a class="l" name="296" href="#296">296</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="297" href="#297">297</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeNumber"/><a href="/source/s?refs=writeNumber&amp;project=rtmp_client" class="xmt">writeNumber</a>(<a href="/source/s?defs=Number&amp;project=rtmp_client">Number</a> <a class="xa" name="num"/><a href="/source/s?refs=num&amp;project=rtmp_client" class="xa">num</a>) {
<a class="l" name="298" href="#298">298</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_NUMBER&amp;project=rtmp_client">TYPE_NUMBER</a>);
<a class="l" name="299" href="#299">299</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=putDouble&amp;project=rtmp_client">putDouble</a>(<a class="d" href="#num">num</a>.<a href="/source/s?defs=doubleValue&amp;project=rtmp_client">doubleValue</a>());
<a class="hl" name="300" href="#300">300</a>	}
<a class="l" name="301" href="#301">301</a>
<a class="l" name="302" href="#302">302</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="303" href="#303">303</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeReference"/><a href="/source/s?refs=writeReference&amp;project=rtmp_client" class="xmt">writeReference</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="obj"/><a href="/source/s?refs=obj&amp;project=rtmp_client" class="xa">obj</a>) {
<a class="l" name="304" href="#304">304</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Write reference"</span>);
<a class="l" name="305" href="#305">305</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_REFERENCE&amp;project=rtmp_client">TYPE_REFERENCE</a>);
<a class="l" name="306" href="#306">306</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=putShort&amp;project=rtmp_client">putShort</a>(<a href="/source/s?defs=getReferenceId&amp;project=rtmp_client">getReferenceId</a>(<a href="/source/s?defs=obj&amp;project=rtmp_client">obj</a>));
<a class="l" name="307" href="#307">307</a>	}
<a class="l" name="308" href="#308">308</a>
<a class="l" name="309" href="#309">309</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="310" href="#310">310</a><span class="c">//	@SuppressWarnings({ "rawtypes" })</span>
<a class="l" name="311" href="#311">311</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeObject"/><a href="/source/s?refs=writeObject&amp;project=rtmp_client" class="xmt">writeObject</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="object"/><a href="/source/s?refs=object&amp;project=rtmp_client" class="xa">object</a>, <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xa" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xa">serializer</a>) {
<a class="l" name="312" href="#312">312</a>	<span class="c">/*
<a class="l" name="313" href="#313">313</a>		if (checkWriteReference(object)) {
<a class="l" name="314" href="#314">314</a>			return;
<a class="l" name="315" href="#315">315</a>		}
<a class="l" name="316" href="#316">316</a>		storeReference(object);
<a class="l" name="317" href="#317">317</a>		// Create new map out of bean properties
<a class="l" name="318" href="#318">318</a>		BeanMap beanMap = new BeanMap(object);
<a class="l" name="319" href="#319">319</a>		// Set of bean attributes
<a class="hl" name="320" href="#320">320</a>		Set set = beanMap.keySet();
<a class="l" name="321" href="#321">321</a>		if ((set.size() == 0) || (set.size() == 1 &amp;&amp; beanMap.containsKey("class"))) {
<a class="l" name="322" href="#322">322</a>			// BeanMap is empty or can only access "class" attribute, skip it
<a class="l" name="323" href="#323">323</a>			writeArbitraryObject(object, serializer);
<a class="l" name="324" href="#324">324</a>			return;
<a class="l" name="325" href="#325">325</a>		}
<a class="l" name="326" href="#326">326</a>
<a class="l" name="327" href="#327">327</a>		// Write out either start of object marker for class name or "empty" start of object marker
<a class="l" name="328" href="#328">328</a>		Class&lt;?&gt; objectClass = object.getClass();
<a class="l" name="329" href="#329">329</a>		if (!objectClass.isAnnotationPresent(Anonymous.class)) {
<a class="hl" name="330" href="#330">330</a>			buf.put(AMF.TYPE_CLASS_OBJECT);
<a class="l" name="331" href="#331">331</a>			putString(buf, serializer.getClassName(objectClass));
<a class="l" name="332" href="#332">332</a>		} else {
<a class="l" name="333" href="#333">333</a>			buf.put(AMF.TYPE_OBJECT);
<a class="l" name="334" href="#334">334</a>		}
<a class="l" name="335" href="#335">335</a>
<a class="l" name="336" href="#336">336</a>		if (object instanceof ICustomSerializable) {
<a class="l" name="337" href="#337">337</a>			((ICustomSerializable) object).serialize(this, serializer);
<a class="l" name="338" href="#338">338</a>			buf.put((byte) 0x00);
<a class="l" name="339" href="#339">339</a>			buf.put((byte) 0x00);
<a class="hl" name="340" href="#340">340</a>			buf.put(AMF.TYPE_END_OF_OBJECT);
<a class="l" name="341" href="#341">341</a>			return;
<a class="l" name="342" href="#342">342</a>		}
<a class="l" name="343" href="#343">343</a>
<a class="l" name="344" href="#344">344</a>		// Iterate thru entries and write out property names with separators
<a class="l" name="345" href="#345">345</a>		for (Object key : set) {
<a class="l" name="346" href="#346">346</a>			String fieldName = key.toString();
<a class="l" name="347" href="#347">347</a>			log.debug("Field name: {} class: {}", fieldName, objectClass);
<a class="l" name="348" href="#348">348</a>
<a class="l" name="349" href="#349">349</a>			Field field = getField(objectClass, fieldName);
<a class="hl" name="350" href="#350">350</a>			Method getter = getGetter(objectClass, beanMap, fieldName);
<a class="l" name="351" href="#351">351</a>
<a class="l" name="352" href="#352">352</a>			// Check if the Field corresponding to the <a href="/source/s?path=getter/">getter</a>/<a href="/source/s?path=getter/setter">setter</a> pair is transient
<a class="l" name="353" href="#353">353</a>			if (!serializeField(serializer, objectClass, fieldName, field, getter)) {
<a class="l" name="354" href="#354">354</a>				continue;
<a class="l" name="355" href="#355">355</a>			}
<a class="l" name="356" href="#356">356</a>
<a class="l" name="357" href="#357">357</a>			putString(buf, fieldName);
<a class="l" name="358" href="#358">358</a>			serializer.serialize(this, field, getter, object, beanMap.get(key));
<a class="l" name="359" href="#359">359</a>		}
<a class="hl" name="360" href="#360">360</a>		// Write out end of object mark
<a class="l" name="361" href="#361">361</a>		buf.put((byte) 0x00);
<a class="l" name="362" href="#362">362</a>		buf.put((byte) 0x00);
<a class="l" name="363" href="#363">363</a>		buf.put(AMF.TYPE_END_OF_OBJECT);
<a class="l" name="364" href="#364">364</a>		*/</span>
<a class="l" name="365" href="#365">365</a>	}
<a class="l" name="366" href="#366">366</a>
<a class="l" name="367" href="#367">367</a><span class="c">//	@SuppressWarnings("unchecked")</span>
<a class="l" name="368" href="#368">368</a>	<b>protected</b> <b>boolean</b> <a class="xmt" name="serializeField"/><a href="/source/s?refs=serializeField&amp;project=rtmp_client" class="xmt">serializeField</a>(<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xa" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xa">serializer</a>, <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a class="xa" name="objectClass"/><a href="/source/s?refs=objectClass&amp;project=rtmp_client" class="xa">objectClass</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="keyName"/><a href="/source/s?refs=keyName&amp;project=rtmp_client" class="xa">keyName</a>, <a href="/source/s?defs=Field&amp;project=rtmp_client">Field</a> <a class="xa" name="field"/><a href="/source/s?refs=field&amp;project=rtmp_client" class="xa">field</a>,
<a class="l" name="369" href="#369">369</a>			<a href="/source/s?defs=Method&amp;project=rtmp_client">Method</a> <a class="d" href="#getter">getter</a>) {
<a class="hl" name="370" href="#370">370</a>		<span class="c">//		to prevent, NullPointerExceptions, get the element first and check if it's null.</span>
<a class="l" name="371" href="#371">371</a>		<span class="c">//Element element = getSerializeCache().get(objectClass);</span>
<a class="l" name="372" href="#372">372</a>		<span class="c">//Map&lt;String, Boolean&gt; serializeMap = (element == null ? null : (Map&lt;String, Boolean&gt;) element.getObjectValue());</span>
<a class="l" name="373" href="#373">373</a>
<a class="l" name="374" href="#374">374</a>		<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a>&gt; <a href="/source/s?defs=serializeMap&amp;project=rtmp_client">serializeMap</a> =  <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> ;
<a class="l" name="375" href="#375">375</a>		<b>if</b> (<a href="/source/s?defs=serializeMap&amp;project=rtmp_client">serializeMap</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="376" href="#376">376</a>			<a href="/source/s?defs=serializeMap&amp;project=rtmp_client">serializeMap</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a>&gt;();
<a class="l" name="377" href="#377">377</a>			<span class="c">//getSerializeCache().put(new Element(objectClass, serializeMap));</span>
<a class="l" name="378" href="#378">378</a>		}
<a class="l" name="379" href="#379">379</a>
<a class="hl" name="380" href="#380">380</a>		<a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a> <a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>;
<a class="l" name="381" href="#381">381</a><span class="c">//		if (getSerializeCache().isKeyInCache(keyName)) {</span>
<a class="l" name="382" href="#382">382</a><span class="c">//			serialize = serializeMap.get(keyName);</span>
<a class="l" name="383" href="#383">383</a><span class="c">//		} else</span>
<a class="l" name="384" href="#384">384</a>		{
<a class="l" name="385" href="#385">385</a>			<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a> = <a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a class="d" href="#serializeField">serializeField</a>(<a href="/source/s?defs=keyName&amp;project=rtmp_client">keyName</a>, <a class="d" href="#field">field</a>, <a class="d" href="#getter">getter</a>);
<a class="l" name="386" href="#386">386</a>			<a href="/source/s?defs=serializeMap&amp;project=rtmp_client">serializeMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=keyName&amp;project=rtmp_client">keyName</a>, <a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>);
<a class="l" name="387" href="#387">387</a>		}
<a class="l" name="388" href="#388">388</a>
<a class="l" name="389" href="#389">389</a>		<b>return</b> <a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>;
<a class="hl" name="390" href="#390">390</a>	}
<a class="l" name="391" href="#391">391</a>
<a class="l" name="392" href="#392">392</a><span class="c">//	@SuppressWarnings("unchecked")</span>
<a class="l" name="393" href="#393">393</a>	<b>protected</b> <a href="/source/s?defs=Field&amp;project=rtmp_client">Field</a> <a class="xmt" name="getField"/><a href="/source/s?refs=getField&amp;project=rtmp_client" class="xmt">getField</a>(<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a class="xa" name="objectClass"/><a href="/source/s?refs=objectClass&amp;project=rtmp_client" class="xa">objectClass</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="keyName"/><a href="/source/s?refs=keyName&amp;project=rtmp_client" class="xa">keyName</a>) {
<a class="l" name="394" href="#394">394</a>		<span class="c">//again, to prevent null pointers, check if the element exists first.</span>
<a class="l" name="395" href="#395">395</a><span class="c">//		Element element = getFieldCache().get(objectClass);</span>
<a class="l" name="396" href="#396">396</a><span class="c">//		Map&lt;String, Field&gt; fieldMap = (element == null ? null : (Map&lt;String, Field&gt;) element.getObjectValue());</span>
<a class="l" name="397" href="#397">397</a>		<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Field&amp;project=rtmp_client">Field</a>&gt; <a href="/source/s?defs=fieldMap&amp;project=rtmp_client">fieldMap</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="398" href="#398">398</a>		<b>if</b> (<a href="/source/s?defs=fieldMap&amp;project=rtmp_client">fieldMap</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="399" href="#399">399</a>			<a href="/source/s?defs=fieldMap&amp;project=rtmp_client">fieldMap</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Field&amp;project=rtmp_client">Field</a>&gt;();
<a class="hl" name="400" href="#400">400</a>			<span class="c">//getFieldCache().put(new Element(objectClass, fieldMap));</span>
<a class="l" name="401" href="#401">401</a>		}
<a class="l" name="402" href="#402">402</a>
<a class="l" name="403" href="#403">403</a>		<a href="/source/s?defs=Field&amp;project=rtmp_client">Field</a> <a class="d" href="#field">field</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="404" href="#404">404</a>
<a class="l" name="405" href="#405">405</a>		<b>if</b> (<a href="/source/s?defs=fieldMap&amp;project=rtmp_client">fieldMap</a>.<a href="/source/s?defs=containsKey&amp;project=rtmp_client">containsKey</a>(<a href="/source/s?defs=keyName&amp;project=rtmp_client">keyName</a>)) {
<a class="l" name="406" href="#406">406</a>			<a class="d" href="#field">field</a> = <a href="/source/s?defs=fieldMap&amp;project=rtmp_client">fieldMap</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=keyName&amp;project=rtmp_client">keyName</a>);
<a class="l" name="407" href="#407">407</a>		} <b>else</b> {
<a class="l" name="408" href="#408">408</a>			<b>for</b> (<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a href="/source/s?defs=clazz&amp;project=rtmp_client">clazz</a> = <a href="/source/s?defs=objectClass&amp;project=rtmp_client">objectClass</a>; !<a href="/source/s?defs=clazz&amp;project=rtmp_client">clazz</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>.<b>class</b>); <a href="/source/s?defs=clazz&amp;project=rtmp_client">clazz</a> = <a href="/source/s?defs=clazz&amp;project=rtmp_client">clazz</a>.<a href="/source/s?defs=getSuperclass&amp;project=rtmp_client">getSuperclass</a>()) {
<a class="l" name="409" href="#409">409</a>				<a href="/source/s?defs=Field&amp;project=rtmp_client">Field</a>[] <a href="/source/s?defs=fields&amp;project=rtmp_client">fields</a> = <a href="/source/s?defs=clazz&amp;project=rtmp_client">clazz</a>.<a href="/source/s?defs=getDeclaredFields&amp;project=rtmp_client">getDeclaredFields</a>();
<a class="hl" name="410" href="#410">410</a>				<b>if</b> (<a href="/source/s?defs=fields&amp;project=rtmp_client">fields</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> &gt; <span class="n">0</span>) {
<a class="l" name="411" href="#411">411</a>					<b>for</b> (<a href="/source/s?defs=Field&amp;project=rtmp_client">Field</a> <a href="/source/s?defs=fld&amp;project=rtmp_client">fld</a> : <a href="/source/s?defs=fields&amp;project=rtmp_client">fields</a>) {
<a class="l" name="412" href="#412">412</a>						<b>if</b> (<a href="/source/s?defs=fld&amp;project=rtmp_client">fld</a>.<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>().<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=keyName&amp;project=rtmp_client">keyName</a>)) {
<a class="l" name="413" href="#413">413</a>							<a class="d" href="#field">field</a> = <a href="/source/s?defs=fld&amp;project=rtmp_client">fld</a>;
<a class="l" name="414" href="#414">414</a>							<b>break</b>;
<a class="l" name="415" href="#415">415</a>						}
<a class="l" name="416" href="#416">416</a>					}
<a class="l" name="417" href="#417">417</a>				}
<a class="l" name="418" href="#418">418</a>			}
<a class="l" name="419" href="#419">419</a>
<a class="hl" name="420" href="#420">420</a>			<a href="/source/s?defs=fieldMap&amp;project=rtmp_client">fieldMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=keyName&amp;project=rtmp_client">keyName</a>, <a class="d" href="#field">field</a>);
<a class="l" name="421" href="#421">421</a>		}
<a class="l" name="422" href="#422">422</a>
<a class="l" name="423" href="#423">423</a>		<b>return</b> <a class="d" href="#field">field</a>;
<a class="l" name="424" href="#424">424</a>	}
<a class="l" name="425" href="#425">425</a>
<a class="l" name="426" href="#426">426</a><span class="c">//	@SuppressWarnings("unchecked")</span>
<a class="l" name="427" href="#427">427</a><span class="c">//	protected Method getGetter(Class&lt;?&gt; objectClass, BeanMap beanMap, String keyName) {</span>
<a class="l" name="428" href="#428">428</a>		<span class="c">//check element to prevent null pointer</span>
<a class="l" name="429" href="#429">429</a><span class="c">//		Element element = getGetterCache().get(objectClass);</span>
<a class="hl" name="430" href="#430">430</a><span class="c">//		Map&lt;String, Method&gt; getterMap = (element == null ? null : (Map&lt;String, Method&gt;) element.getObjectValue());</span>
<a class="l" name="431" href="#431">431</a><span class="c">//		if (getterMap == null) {</span>
<a class="l" name="432" href="#432">432</a><span class="c">//			getterMap = new HashMap&lt;String, Method&gt;();</span>
<a class="l" name="433" href="#433">433</a><span class="c">//			getGetterCache().put(new Element(objectClass, getterMap));</span>
<a class="l" name="434" href="#434">434</a><span class="c">//		}</span>
<a class="l" name="435" href="#435">435</a><span class="c">//</span>
<a class="l" name="436" href="#436">436</a><span class="c">//		Method getter;</span>
<a class="l" name="437" href="#437">437</a><span class="c">//		if (getterMap.containsKey(keyName)) {</span>
<a class="l" name="438" href="#438">438</a><span class="c">//			getter = getterMap.get(keyName);</span>
<a class="l" name="439" href="#439">439</a><span class="c">//		} else {</span>
<a class="hl" name="440" href="#440">440</a><span class="c">//			getter = beanMap.getReadMethod(keyName);</span>
<a class="l" name="441" href="#441">441</a><span class="c">//			getterMap.put(keyName, getter);</span>
<a class="l" name="442" href="#442">442</a><span class="c">//		}</span>
<a class="l" name="443" href="#443">443</a>
<a class="l" name="444" href="#444">444</a><span class="c">//		return getter;</span>
<a class="l" name="445" href="#445">445</a><span class="c">//		return null;</span>
<a class="l" name="446" href="#446">446</a><span class="c">//	}</span>
<a class="l" name="447" href="#447">447</a>
<a class="l" name="448" href="#448">448</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="449" href="#449">449</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeObject"/><a href="/source/s?refs=writeObject&amp;project=rtmp_client" class="xmt">writeObject</a>(<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xa" name="map"/><a href="/source/s?refs=map&amp;project=rtmp_client" class="xa">map</a>, <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xa" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xa">serializer</a>) {
<a class="hl" name="450" href="#450">450</a>		<b>if</b> (<a class="d" href="#checkWriteReference">checkWriteReference</a>(<a href="/source/s?defs=map&amp;project=rtmp_client">map</a>)) {
<a class="l" name="451" href="#451">451</a>			<b>return</b>;
<a class="l" name="452" href="#452">452</a>		}
<a class="l" name="453" href="#453">453</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=map&amp;project=rtmp_client">map</a>);
<a class="l" name="454" href="#454">454</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_OBJECT&amp;project=rtmp_client">TYPE_OBJECT</a>);
<a class="l" name="455" href="#455">455</a><span class="c">//		boolean isBeanMap = (map instanceof BeanMap);</span>
<a class="l" name="456" href="#456">456</a>		<b>for</b> (<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>.<a href="/source/s?defs=Entry&amp;project=rtmp_client">Entry</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a> : <a href="/source/s?defs=map&amp;project=rtmp_client">map</a>.<a href="/source/s?defs=entrySet&amp;project=rtmp_client">entrySet</a>()) {
<a class="l" name="457" href="#457">457</a>			<span class="c">//if (isBeanMap &amp;&amp; "class".equals(entry.getKey())) {</span>
<a class="l" name="458" href="#458">458</a>			<b>if</b> (<span class="s">"class"</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a>.<a href="/source/s?defs=getKey&amp;project=rtmp_client">getKey</a>())) {
<a class="l" name="459" href="#459">459</a>				<b>continue</b>;
<a class="hl" name="460" href="#460">460</a>			}
<a class="l" name="461" href="#461">461</a>			<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a>.<a href="/source/s?defs=getKey&amp;project=rtmp_client">getKey</a>().<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>());
<a class="l" name="462" href="#462">462</a>			<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<b>this</b>, <a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a>.<a href="/source/s?defs=getValue&amp;project=rtmp_client">getValue</a>());
<a class="l" name="463" href="#463">463</a>		}
<a class="l" name="464" href="#464">464</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) <span class="n">0x00</span>);
<a class="l" name="465" href="#465">465</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) <span class="n">0x00</span>);
<a class="l" name="466" href="#466">466</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_END_OF_OBJECT&amp;project=rtmp_client">TYPE_END_OF_OBJECT</a>);
<a class="l" name="467" href="#467">467</a>	}
<a class="l" name="468" href="#468">468</a>
<a class="l" name="469" href="#469">469</a>	<span class="c">/**
<a class="hl" name="470" href="#470">470</a>	 * Writes an arbitrary object to the output.
<a class="l" name="471" href="#471">471</a>	 *
<a class="l" name="472" href="#472">472</a>	 * <strong>@param</strong> <em>serializer</em>    Output writer
<a class="l" name="473" href="#473">473</a>	 * <strong>@param</strong> <em>object</em>        Object to write
<a class="l" name="474" href="#474">474</a>	 */</span>
<a class="l" name="475" href="#475">475</a>	<b>protected</b> <b>void</b> <a class="xmt" name="writeArbitraryObject"/><a href="/source/s?refs=writeArbitraryObject&amp;project=rtmp_client" class="xmt">writeArbitraryObject</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="object"/><a href="/source/s?refs=object&amp;project=rtmp_client" class="xa">object</a>, <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xa" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xa">serializer</a>) {
<a class="l" name="476" href="#476">476</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"writeObject"</span>);
<a class="l" name="477" href="#477">477</a>		<span class="c">// If we need to serialize class information...</span>
<a class="l" name="478" href="#478">478</a>		<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a href="/source/s?defs=objectClass&amp;project=rtmp_client">objectClass</a> = <a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>();
<a class="l" name="479" href="#479">479</a>		<b>if</b> (!<a href="/source/s?defs=objectClass&amp;project=rtmp_client">objectClass</a>.<a href="/source/s?defs=isAnnotationPresent&amp;project=rtmp_client">isAnnotationPresent</a>(<a href="/source/s?defs=Anonymous&amp;project=rtmp_client">Anonymous</a>.<b>class</b>)) {
<a class="hl" name="480" href="#480">480</a>			<span class="c">// Write out start object marker for class name</span>
<a class="l" name="481" href="#481">481</a>			<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_CLASS_OBJECT&amp;project=rtmp_client">TYPE_CLASS_OBJECT</a>);
<a class="l" name="482" href="#482">482</a>			<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>, <a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=getClassName&amp;project=rtmp_client">getClassName</a>(<a href="/source/s?defs=objectClass&amp;project=rtmp_client">objectClass</a>));
<a class="l" name="483" href="#483">483</a>		} <b>else</b> {
<a class="l" name="484" href="#484">484</a>			<span class="c">// Write out start object marker without class name</span>
<a class="l" name="485" href="#485">485</a>			<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_OBJECT&amp;project=rtmp_client">TYPE_OBJECT</a>);
<a class="l" name="486" href="#486">486</a>		}
<a class="l" name="487" href="#487">487</a>
<a class="l" name="488" href="#488">488</a>		<span class="c">// Iterate thru fields of an object to build "name-value" map from it</span>
<a class="l" name="489" href="#489">489</a>		<b>for</b> (<a href="/source/s?defs=Field&amp;project=rtmp_client">Field</a> <a class="d" href="#field">field</a> : <a href="/source/s?defs=objectClass&amp;project=rtmp_client">objectClass</a>.<a href="/source/s?defs=getFields&amp;project=rtmp_client">getFields</a>()) {
<a class="hl" name="490" href="#490">490</a>			<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=fieldName&amp;project=rtmp_client">fieldName</a> = <a class="d" href="#field">field</a>.<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>();
<a class="l" name="491" href="#491">491</a>
<a class="l" name="492" href="#492">492</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Field: {} class: {}"</span>, <a class="d" href="#field">field</a>, <a href="/source/s?defs=objectClass&amp;project=rtmp_client">objectClass</a>);
<a class="l" name="493" href="#493">493</a>			<span class="c">// Check if the Field corresponding to the <a href="/source/s?path=getter/">getter</a>/<a href="/source/s?path=getter/setter">setter</a> pair is transient</span>
<a class="l" name="494" href="#494">494</a>			<b>if</b> (!<a class="d" href="#serializeField">serializeField</a>(<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>, <a href="/source/s?defs=objectClass&amp;project=rtmp_client">objectClass</a>, <a href="/source/s?defs=fieldName&amp;project=rtmp_client">fieldName</a>, <a class="d" href="#field">field</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>)) {
<a class="l" name="495" href="#495">495</a>				<b>continue</b>;
<a class="l" name="496" href="#496">496</a>			}
<a class="l" name="497" href="#497">497</a>
<a class="l" name="498" href="#498">498</a>			<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>;
<a class="l" name="499" href="#499">499</a>			<b>try</b> {
<a class="hl" name="500" href="#500">500</a>				<span class="c">// Get field value</span>
<a class="l" name="501" href="#501">501</a>				<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a class="d" href="#field">field</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>);
<a class="l" name="502" href="#502">502</a>			} <b>catch</b> (<a href="/source/s?defs=IllegalAccessException&amp;project=rtmp_client">IllegalAccessException</a> <a href="/source/s?defs=err&amp;project=rtmp_client">err</a>) {
<a class="l" name="503" href="#503">503</a>				<span class="c">// Swallow on private and protected properties access exception</span>
<a class="l" name="504" href="#504">504</a>				<b>continue</b>;
<a class="l" name="505" href="#505">505</a>			}
<a class="l" name="506" href="#506">506</a>			<span class="c">// Write out prop name</span>
<a class="l" name="507" href="#507">507</a>			<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>, <a href="/source/s?defs=fieldName&amp;project=rtmp_client">fieldName</a>);
<a class="l" name="508" href="#508">508</a>			<span class="c">// Write out</span>
<a class="l" name="509" href="#509">509</a>			<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<b>this</b>, <a class="d" href="#field">field</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a href="/source/s?defs=object&amp;project=rtmp_client">object</a>, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="hl" name="510" href="#510">510</a>		}
<a class="l" name="511" href="#511">511</a>		<span class="c">// Write out end of object marker</span>
<a class="l" name="512" href="#512">512</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) <span class="n">0x00</span>);
<a class="l" name="513" href="#513">513</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) <span class="n">0x00</span>);
<a class="l" name="514" href="#514">514</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_END_OF_OBJECT&amp;project=rtmp_client">TYPE_END_OF_OBJECT</a>);
<a class="l" name="515" href="#515">515</a>	}
<a class="l" name="516" href="#516">516</a>
<a class="l" name="517" href="#517">517</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="518" href="#518">518</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeString"/><a href="/source/s?refs=writeString&amp;project=rtmp_client" class="xmt">writeString</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="string"/><a href="/source/s?refs=string&amp;project=rtmp_client" class="xa">string</a>) {
<a class="l" name="519" href="#519">519</a>		<b>final</b> <b>byte</b>[] <a href="/source/s?defs=encoded&amp;project=rtmp_client">encoded</a> = <a class="d" href="#encodeString">encodeString</a>(<a href="/source/s?defs=string&amp;project=rtmp_client">string</a>);
<a class="hl" name="520" href="#520">520</a>		<b>final</b> <b>int</b> <a href="/source/s?defs=len&amp;project=rtmp_client">len</a> = <a href="/source/s?defs=encoded&amp;project=rtmp_client">encoded</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>;
<a class="l" name="521" href="#521">521</a>		<b>if</b> (<a href="/source/s?defs=len&amp;project=rtmp_client">len</a> &lt; <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=LONG_STRING_LENGTH&amp;project=rtmp_client">LONG_STRING_LENGTH</a>) {
<a class="l" name="522" href="#522">522</a>			<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_STRING&amp;project=rtmp_client">TYPE_STRING</a>);
<a class="l" name="523" href="#523">523</a>			<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=putShort&amp;project=rtmp_client">putShort</a>((<b>short</b>) <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>);
<a class="l" name="524" href="#524">524</a>		} <b>else</b> {
<a class="l" name="525" href="#525">525</a>			<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_LONG_STRING&amp;project=rtmp_client">TYPE_LONG_STRING</a>);
<a class="l" name="526" href="#526">526</a>			<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=len&amp;project=rtmp_client">len</a>);
<a class="l" name="527" href="#527">527</a>		}
<a class="l" name="528" href="#528">528</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=encoded&amp;project=rtmp_client">encoded</a>);
<a class="l" name="529" href="#529">529</a>	}
<a class="hl" name="530" href="#530">530</a>
<a class="l" name="531" href="#531">531</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="532" href="#532">532</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeByteArray"/><a href="/source/s?refs=writeByteArray&amp;project=rtmp_client" class="xmt">writeByteArray</a>(<a href="/source/s?defs=ByteArray&amp;project=rtmp_client">ByteArray</a> <a class="xa" name="array"/><a href="/source/s?refs=array&amp;project=rtmp_client" class="xa">array</a>) {
<a class="l" name="533" href="#533">533</a>		<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"ByteArray objects not supported with AMF0"</span>);
<a class="l" name="534" href="#534">534</a>	}
<a class="l" name="535" href="#535">535</a>
<a class="l" name="536" href="#536">536</a>	<span class="c">/**
<a class="l" name="537" href="#537">537</a>	 * Encode string.
<a class="l" name="538" href="#538">538</a>	 *
<a class="l" name="539" href="#539">539</a>	 * <strong>@param</strong> <em>string</em>
<a class="hl" name="540" href="#540">540</a>	 * <strong>@return</strong> encoded string
<a class="l" name="541" href="#541">541</a>	 */</span>
<a class="l" name="542" href="#542">542</a>	<b>protected</b> <b>static</b> <b>byte</b>[] <a class="xmt" name="encodeString"/><a href="/source/s?refs=encodeString&amp;project=rtmp_client" class="xmt">encodeString</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="string"/><a href="/source/s?refs=string&amp;project=rtmp_client" class="xa">string</a>) {
<a class="l" name="543" href="#543">543</a>		<span class="c">//Element element = getStringCache().get(string);</span>
<a class="l" name="544" href="#544">544</a>		<span class="c">//byte[] encoded = (element == null ? null : (byte[]) element.getObjectValue());</span>
<a class="l" name="545" href="#545">545</a>		<b>byte</b>[] <a href="/source/s?defs=encoded&amp;project=rtmp_client">encoded</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="546" href="#546">546</a>		<b>if</b> (<a href="/source/s?defs=encoded&amp;project=rtmp_client">encoded</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="547" href="#547">547</a>			<a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a> <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> = <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=CHARSET&amp;project=rtmp_client">CHARSET</a>.<a href="/source/s?defs=encode&amp;project=rtmp_client">encode</a>(<a href="/source/s?defs=string&amp;project=rtmp_client">string</a>);
<a class="l" name="548" href="#548">548</a>			<a href="/source/s?defs=encoded&amp;project=rtmp_client">encoded</a> = <b>new</b> <b>byte</b>[<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>()];
<a class="l" name="549" href="#549">549</a>			<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=encoded&amp;project=rtmp_client">encoded</a>);
<a class="hl" name="550" href="#550">550</a>			<span class="c">//getStringCache().put(new Element(string, encoded));</span>
<a class="l" name="551" href="#551">551</a>		}
<a class="l" name="552" href="#552">552</a>		<b>return</b> <a href="/source/s?defs=encoded&amp;project=rtmp_client">encoded</a>;
<a class="l" name="553" href="#553">553</a>	}
<a class="l" name="554" href="#554">554</a>
<a class="l" name="555" href="#555">555</a>	<span class="c">/**
<a class="l" name="556" href="#556">556</a>	 * Write out string
<a class="l" name="557" href="#557">557</a>	 * <strong>@param</strong> <em>buf</em>         Byte buffer to write to
<a class="l" name="558" href="#558">558</a>	 * <strong>@param</strong> <em>string</em>      String to write
<a class="l" name="559" href="#559">559</a>	 */</span>
<a class="hl" name="560" href="#560">560</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="putString"/><a href="/source/s?refs=putString&amp;project=rtmp_client" class="xmt">putString</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="buf"/><a href="/source/s?refs=buf&amp;project=rtmp_client" class="xa">buf</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="string"/><a href="/source/s?refs=string&amp;project=rtmp_client" class="xa">string</a>) {
<a class="l" name="561" href="#561">561</a>		<b>final</b> <b>byte</b>[] <a href="/source/s?defs=encoded&amp;project=rtmp_client">encoded</a> = <a class="d" href="#encodeString">encodeString</a>(<a href="/source/s?defs=string&amp;project=rtmp_client">string</a>);
<a class="l" name="562" href="#562">562</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=putShort&amp;project=rtmp_client">putShort</a>((<b>short</b>) <a href="/source/s?defs=encoded&amp;project=rtmp_client">encoded</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>);
<a class="l" name="563" href="#563">563</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=encoded&amp;project=rtmp_client">encoded</a>);
<a class="l" name="564" href="#564">564</a>	}
<a class="l" name="565" href="#565">565</a>
<a class="l" name="566" href="#566">566</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="567" href="#567">567</a>	<b>public</b> <b>void</b> <a class="xmt" name="putString"/><a href="/source/s?refs=putString&amp;project=rtmp_client" class="xmt">putString</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="string"/><a href="/source/s?refs=string&amp;project=rtmp_client" class="xa">string</a>) {
<a class="l" name="568" href="#568">568</a>		<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>, <a href="/source/s?defs=string&amp;project=rtmp_client">string</a>);
<a class="l" name="569" href="#569">569</a>	}
<a class="hl" name="570" href="#570">570</a>
<a class="l" name="571" href="#571">571</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="572" href="#572">572</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeXML"/><a href="/source/s?refs=writeXML&amp;project=rtmp_client" class="xmt">writeXML</a>(<a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a> <a class="xa" name="xml"/><a href="/source/s?refs=xml&amp;project=rtmp_client" class="xa">xml</a>) {
<a class="l" name="573" href="#573">573</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_XML&amp;project=rtmp_client">TYPE_XML</a>);
<a class="l" name="574" href="#574">574</a>		<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<a href="/source/s?defs=XMLUtils&amp;project=rtmp_client">XMLUtils</a>.<a href="/source/s?defs=docToString&amp;project=rtmp_client">docToString</a>(<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>));
<a class="l" name="575" href="#575">575</a>	}
<a class="l" name="576" href="#576">576</a>
<a class="l" name="577" href="#577">577</a>	<span class="c">/**
<a class="l" name="578" href="#578">578</a>	 * Convenience method to allow XML text to be used, instead
<a class="l" name="579" href="#579">579</a>	 * of requiring an XML Document.
<a class="hl" name="580" href="#580">580</a>	 *
<a class="l" name="581" href="#581">581</a>	 * <strong>@param</strong> <em>xml</em> xml to write
<a class="l" name="582" href="#582">582</a>	 */</span>
<a class="l" name="583" href="#583">583</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeXML"/><a href="/source/s?refs=writeXML&amp;project=rtmp_client" class="xmt">writeXML</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="xml"/><a href="/source/s?refs=xml&amp;project=rtmp_client" class="xa">xml</a>) {
<a class="l" name="584" href="#584">584</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_XML&amp;project=rtmp_client">TYPE_XML</a>);
<a class="l" name="585" href="#585">585</a>		<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<a href="/source/s?defs=xml&amp;project=rtmp_client">xml</a>);
<a class="l" name="586" href="#586">586</a>	}
<a class="l" name="587" href="#587">587</a>
<a class="l" name="588" href="#588">588</a>	<span class="c">/**
<a class="l" name="589" href="#589">589</a>	 * Return buffer of this Output object
<a class="hl" name="590" href="#590">590</a>	 * <strong>@return</strong>        Byte buffer of this Output object
<a class="l" name="591" href="#591">591</a>	 */</span>
<a class="l" name="592" href="#592">592</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="buf"/><a href="/source/s?refs=buf&amp;project=rtmp_client" class="xmt">buf</a>() {
<a class="l" name="593" href="#593">593</a>		<b>return</b> <b>this</b>.<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>;
<a class="l" name="594" href="#594">594</a>	}
<a class="l" name="595" href="#595">595</a>
<a class="l" name="596" href="#596">596</a>	<b>public</b> <b>void</b> <a class="xmt" name="reset"/><a href="/source/s?refs=reset&amp;project=rtmp_client" class="xmt">reset</a>() {
<a class="l" name="597" href="#597">597</a>		<a href="/source/s?defs=clearReferences&amp;project=rtmp_client">clearReferences</a>();
<a class="l" name="598" href="#598">598</a>	}
<a class="l" name="599" href="#599">599</a>
<a class="hl" name="600" href="#600">600</a><span class="c">//	protected static Cache getStringCache() {</span>
<a class="l" name="601" href="#601">601</a><span class="c">//		if (stringCache == null) {</span>
<a class="l" name="602" href="#602">602</a><span class="c">//			stringCache = getCacheManager().getCache("org.red5.io.amf.Output.stringCache");</span>
<a class="l" name="603" href="#603">603</a><span class="c">//		}</span>
<a class="l" name="604" href="#604">604</a><span class="c">//</span>
<a class="l" name="605" href="#605">605</a><span class="c">//		return stringCache;</span>
<a class="l" name="606" href="#606">606</a><span class="c">//	}</span>
<a class="l" name="607" href="#607">607</a><span class="c">//</span>
<a class="l" name="608" href="#608">608</a><span class="c">//	protected static Cache getSerializeCache() {</span>
<a class="l" name="609" href="#609">609</a><span class="c">//		if (serializeCache == null) {</span>
<a class="hl" name="610" href="#610">610</a><span class="c">//			serializeCache = getCacheManager().getCache("org.red5.io.amf.Output.serializeCache");</span>
<a class="l" name="611" href="#611">611</a><span class="c">//		}</span>
<a class="l" name="612" href="#612">612</a><span class="c">//</span>
<a class="l" name="613" href="#613">613</a><span class="c">//		return serializeCache;</span>
<a class="l" name="614" href="#614">614</a><span class="c">//	}</span>
<a class="l" name="615" href="#615">615</a><span class="c">//</span>
<a class="l" name="616" href="#616">616</a><span class="c">//	protected static Cache getFieldCache() {</span>
<a class="l" name="617" href="#617">617</a><span class="c">//		if (fieldCache == null) {</span>
<a class="l" name="618" href="#618">618</a><span class="c">//			fieldCache = getCacheManager().getCache("org.red5.io.amf.Output.fieldCache");</span>
<a class="l" name="619" href="#619">619</a><span class="c">//		}</span>
<a class="hl" name="620" href="#620">620</a><span class="c">//</span>
<a class="l" name="621" href="#621">621</a><span class="c">//		return fieldCache;</span>
<a class="l" name="622" href="#622">622</a><span class="c">//	}</span>
<a class="l" name="623" href="#623">623</a><span class="c">//</span>
<a class="l" name="624" href="#624">624</a><span class="c">//	protected static Cache getGetterCache() {</span>
<a class="l" name="625" href="#625">625</a><span class="c">//		if (getterCache == null) {</span>
<a class="l" name="626" href="#626">626</a><span class="c">//			getterCache = getCacheManager().getCache("org.red5.io.amf.Output.getterCache");</span>
<a class="l" name="627" href="#627">627</a><span class="c">//		}</span>
<a class="l" name="628" href="#628">628</a><span class="c">//</span>
<a class="l" name="629" href="#629">629</a><span class="c">//		return getterCache;</span>
<a class="hl" name="630" href="#630">630</a><span class="c">//	}</span>
<a class="l" name="631" href="#631">631</a>}