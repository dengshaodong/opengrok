<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["Input",59]]],["Package","xp",[["org.red5.io.amf",1]]],["Method","xmt",[["Input",80],["bufferToString",269],["getPropertyType",674],["getString",219],["getString",253],["hasMoreProperties",547],["newInstance",419],["readArray",308],["readBean",452],["readBoolean",191],["readByteArray",617],["readCustom",607],["readDataType",90],["readDataType",108],["readDate",289],["readKeyValues",338],["readKeyValues",349],["readMap",363],["readNull",182],["readNumber",202],["readObject",512],["readPropertyName",564],["readReference",662],["readSimpleObject",498],["readString",228],["readVectorInt",626],["readVectorNumber",644],["readVectorObject",653],["readVectorUInt",635],["readXML",590],["reset",670],["skipEndObject",578],["skipPropertySeparator",571]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><span class="c">//import java.beans.PropertyDescriptor;</span>
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=lang&amp;project=rtmp_client">lang</a>.<a href="/source/s?defs=reflect&amp;project=rtmp_client">reflect</a>.<a href="/source/s?defs=Field&amp;project=rtmp_client">Field</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=lang&amp;project=rtmp_client">lang</a>.<a href="/source/s?defs=reflect&amp;project=rtmp_client">reflect</a>.<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Collection&amp;project=rtmp_client">Collection</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Date&amp;project=rtmp_client">Date</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=LinkedHashMap&amp;project=rtmp_client">LinkedHashMap</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a><span class="c">//import org.apache.commons.beanutils.BeanUtils;</span>
<a class="l" name="35" href="#35">35</a><span class="c">//import org.apache.commons.beanutils.BeanUtilsBean;</span>
<a class="l" name="36" href="#36">36</a><span class="c">//import org.apache.commons.beanutils.PropertyUtilsBean;</span>
<a class="l" name="37" href="#37">37</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="38" href="#38">38</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>.<a href="/source/s?defs=ByteArray&amp;project=rtmp_client">ByteArray</a>;
<a class="l" name="39" href="#39">39</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=BaseInput&amp;project=rtmp_client">BaseInput</a>;
<a class="hl" name="40" href="#40">40</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>;
<a class="l" name="41" href="#41">41</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a>;
<a class="l" name="42" href="#42">42</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=RecordSet&amp;project=rtmp_client">RecordSet</a>;
<a class="l" name="43" href="#43">43</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=RecordSetPage&amp;project=rtmp_client">RecordSetPage</a>;
<a class="l" name="44" href="#44">44</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>.<a href="/source/s?defs=ArrayUtils&amp;project=rtmp_client">ArrayUtils</a>;
<a class="l" name="45" href="#45">45</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>.<a href="/source/s?defs=ObjectMap&amp;project=rtmp_client">ObjectMap</a>;
<a class="l" name="46" href="#46">46</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>.<a href="/source/s?defs=XMLUtils&amp;project=rtmp_client">XMLUtils</a>;
<a class="l" name="47" href="#47">47</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=ConversionUtils&amp;project=rtmp_client">ConversionUtils</a>;
<a class="l" name="48" href="#48">48</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="49" href="#49">49</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="hl" name="50" href="#50">50</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=w3c&amp;project=rtmp_client">w3c</a>.<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a>;
<a class="l" name="51" href="#51">51</a>
<a class="l" name="52" href="#52">52</a><span class="c">/**
<a class="l" name="53" href="#53">53</a> * Input for Red5 data types
<a class="l" name="54" href="#54">54</a> *
<a class="l" name="55" href="#55">55</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="56" href="#56">56</a> * <strong>@author</strong> Luke Hubbard, Codegent Ltd (luke@codegent.com)
<a class="l" name="57" href="#57">57</a> */</span>
<a class="l" name="58" href="#58">58</a>@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"serial"</span>)
<a class="l" name="59" href="#59">59</a><b>public</b> <b>class</b> <a class="xc" name="Input"/><a href="/source/s?refs=Input&amp;project=rtmp_client" class="xc">Input</a> <b>extends</b> <a href="/source/s?defs=BaseInput&amp;project=rtmp_client">BaseInput</a> <b>implements</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a class="xc" name="Input"/><a href="/source/s?refs=Input&amp;project=rtmp_client" class="xc">Input</a> {
<a class="hl" name="60" href="#60">60</a>
<a class="l" name="61" href="#61">61</a>	<b>protected</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>.<b>class</b>);
<a class="l" name="62" href="#62">62</a>
<a class="l" name="63" href="#63">63</a>	<b>protected</b> <b>static</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt; <a class="xfld" name="classAliases"/><a href="/source/s?refs=classAliases&amp;project=rtmp_client" class="xfld">classAliases</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt;(<span class="n">3</span>) {
<a class="l" name="64" href="#64">64</a>		{
<a class="l" name="65" href="#65">65</a>			<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"DSA"</span>, <span class="s">"org.red5.compatibility.flex.messaging.messages.AsyncMessageExt"</span>);
<a class="l" name="66" href="#66">66</a>			<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"DSC"</span>, <span class="s">"org.red5.compatibility.flex.messaging.messages.CommandMessageExt"</span>);
<a class="l" name="67" href="#67">67</a>			<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"DSK"</span>, <span class="s">"org.red5.compatibility.flex.messaging.messages.AcknowledgeMessageExt"</span>);
<a class="l" name="68" href="#68">68</a>		}
<a class="l" name="69" href="#69">69</a>	};
<a class="hl" name="70" href="#70">70</a>
<a class="l" name="71" href="#71">71</a>	<b>protected</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xfld" name="buf"/><a href="/source/s?refs=buf&amp;project=rtmp_client" class="xfld">buf</a>;
<a class="l" name="72" href="#72">72</a>
<a class="l" name="73" href="#73">73</a>	<b>protected</b> <b>byte</b> <a class="xfld" name="currentDataType"/><a href="/source/s?refs=currentDataType&amp;project=rtmp_client" class="xfld">currentDataType</a>;
<a class="l" name="74" href="#74">74</a>
<a class="l" name="75" href="#75">75</a>	<span class="c">/**
<a class="l" name="76" href="#76">76</a>	 * Creates Input object from byte buffer
<a class="l" name="77" href="#77">77</a>	 *
<a class="l" name="78" href="#78">78</a>	 * <strong>@param</strong> <em>buf</em>           Byte buffer
<a class="l" name="79" href="#79">79</a>	 */</span>
<a class="hl" name="80" href="#80">80</a>	<b>public</b> <a class="xmt" name="Input"/><a href="/source/s?refs=Input&amp;project=rtmp_client" class="xmt">Input</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="buf"/><a href="/source/s?refs=buf&amp;project=rtmp_client" class="xa">buf</a>) {
<a class="l" name="81" href="#81">81</a>		<b>super</b>();
<a class="l" name="82" href="#82">82</a>		<b>this</b>.<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>;
<a class="l" name="83" href="#83">83</a>	}
<a class="l" name="84" href="#84">84</a>
<a class="l" name="85" href="#85">85</a>	<span class="c">/**
<a class="l" name="86" href="#86">86</a>	 * Reads the data type.
<a class="l" name="87" href="#87">87</a>	 *
<a class="l" name="88" href="#88">88</a>	 * <strong>@return</strong> byte         Data type
<a class="l" name="89" href="#89">89</a>	 */</span>
<a class="hl" name="90" href="#90">90</a>	<b>public</b> <b>byte</b> <a class="xmt" name="readDataType"/><a href="/source/s?refs=readDataType&amp;project=rtmp_client" class="xmt">readDataType</a>() {
<a class="l" name="91" href="#91">91</a>		<b>if</b> (<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="92" href="#92">92</a>			<span class="c">// XXX Paul: prevent an NPE here by returning the current data type</span>
<a class="l" name="93" href="#93">93</a>			<span class="c">// when there is a null buffer</span>
<a class="l" name="94" href="#94">94</a>			<a class="d" href="#currentDataType">currentDataType</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="95" href="#95">95</a>		} <b>else</b> {
<a class="l" name="96" href="#96">96</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Why is buf null?"</span>);
<a class="l" name="97" href="#97">97</a>		}
<a class="l" name="98" href="#98">98</a>		<b>return</b> <a href="/source/s?defs=readDataType&amp;project=rtmp_client">readDataType</a>(<a class="d" href="#currentDataType">currentDataType</a>);
<a class="l" name="99" href="#99">99</a>	}
<a class="hl" name="100" href="#100">100</a>
<a class="l" name="101" href="#101">101</a>	<span class="c">/**
<a class="l" name="102" href="#102">102</a>	 * Reads the data type.
<a class="l" name="103" href="#103">103</a>	 *
<a class="l" name="104" href="#104">104</a>	 * <strong>@param</strong> <em>dataType</em>       Data type as byte
<a class="l" name="105" href="#105">105</a>	 * <strong>@return</strong>               One of AMF class constants with type
<a class="l" name="106" href="#106">106</a>	 * <strong>@see</strong>                  org.red5.io.amf.AMF
<a class="l" name="107" href="#107">107</a>	 */</span>
<a class="l" name="108" href="#108">108</a>	<b>protected</b> <b>byte</b> <a class="xmt" name="readDataType"/><a href="/source/s?refs=readDataType&amp;project=rtmp_client" class="xmt">readDataType</a>(<b>byte</b> <a class="xa" name="dataType"/><a href="/source/s?refs=dataType&amp;project=rtmp_client" class="xa">dataType</a>) {
<a class="l" name="109" href="#109">109</a>		<b>byte</b> <a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a>;
<a class="hl" name="110" href="#110">110</a>
<a class="l" name="111" href="#111">111</a>		<b>switch</b> (<a class="d" href="#currentDataType">currentDataType</a>) {
<a class="l" name="112" href="#112">112</a>
<a class="l" name="113" href="#113">113</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_NULL&amp;project=rtmp_client">TYPE_NULL</a>:
<a class="l" name="114" href="#114">114</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_UNDEFINED&amp;project=rtmp_client">TYPE_UNDEFINED</a>:
<a class="l" name="115" href="#115">115</a>				<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_NULL&amp;project=rtmp_client">CORE_NULL</a>;
<a class="l" name="116" href="#116">116</a>				<b>break</b>;
<a class="l" name="117" href="#117">117</a>
<a class="l" name="118" href="#118">118</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_NUMBER&amp;project=rtmp_client">TYPE_NUMBER</a>:
<a class="l" name="119" href="#119">119</a>				<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_NUMBER&amp;project=rtmp_client">CORE_NUMBER</a>;
<a class="hl" name="120" href="#120">120</a>				<b>break</b>;
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_BOOLEAN&amp;project=rtmp_client">TYPE_BOOLEAN</a>:
<a class="l" name="123" href="#123">123</a>				<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_BOOLEAN&amp;project=rtmp_client">CORE_BOOLEAN</a>;
<a class="l" name="124" href="#124">124</a>				<b>break</b>;
<a class="l" name="125" href="#125">125</a>
<a class="l" name="126" href="#126">126</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_STRING&amp;project=rtmp_client">TYPE_STRING</a>:
<a class="l" name="127" href="#127">127</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_LONG_STRING&amp;project=rtmp_client">TYPE_LONG_STRING</a>:
<a class="l" name="128" href="#128">128</a>				<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_STRING&amp;project=rtmp_client">CORE_STRING</a>;
<a class="l" name="129" href="#129">129</a>				<b>break</b>;
<a class="hl" name="130" href="#130">130</a>
<a class="l" name="131" href="#131">131</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_CLASS_OBJECT&amp;project=rtmp_client">TYPE_CLASS_OBJECT</a>:
<a class="l" name="132" href="#132">132</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_OBJECT&amp;project=rtmp_client">TYPE_OBJECT</a>:
<a class="l" name="133" href="#133">133</a>				<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_OBJECT&amp;project=rtmp_client">CORE_OBJECT</a>;
<a class="l" name="134" href="#134">134</a>				<b>break</b>;
<a class="l" name="135" href="#135">135</a>
<a class="l" name="136" href="#136">136</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_MIXED_ARRAY&amp;project=rtmp_client">TYPE_MIXED_ARRAY</a>:
<a class="l" name="137" href="#137">137</a>				<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_MAP&amp;project=rtmp_client">CORE_MAP</a>;
<a class="l" name="138" href="#138">138</a>				<b>break</b>;
<a class="l" name="139" href="#139">139</a>
<a class="hl" name="140" href="#140">140</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_ARRAY&amp;project=rtmp_client">TYPE_ARRAY</a>:
<a class="l" name="141" href="#141">141</a>				<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_ARRAY&amp;project=rtmp_client">CORE_ARRAY</a>;
<a class="l" name="142" href="#142">142</a>				<b>break</b>;
<a class="l" name="143" href="#143">143</a>
<a class="l" name="144" href="#144">144</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_DATE&amp;project=rtmp_client">TYPE_DATE</a>:
<a class="l" name="145" href="#145">145</a>				<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_DATE&amp;project=rtmp_client">CORE_DATE</a>;
<a class="l" name="146" href="#146">146</a>				<b>break</b>;
<a class="l" name="147" href="#147">147</a>
<a class="l" name="148" href="#148">148</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_XML&amp;project=rtmp_client">TYPE_XML</a>:
<a class="l" name="149" href="#149">149</a>				<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_XML&amp;project=rtmp_client">CORE_XML</a>;
<a class="hl" name="150" href="#150">150</a>				<b>break</b>;
<a class="l" name="151" href="#151">151</a>
<a class="l" name="152" href="#152">152</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_REFERENCE&amp;project=rtmp_client">TYPE_REFERENCE</a>:
<a class="l" name="153" href="#153">153</a>				<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=OPT_REFERENCE&amp;project=rtmp_client">OPT_REFERENCE</a>;
<a class="l" name="154" href="#154">154</a>				<b>break</b>;
<a class="l" name="155" href="#155">155</a>
<a class="l" name="156" href="#156">156</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_UNSUPPORTED&amp;project=rtmp_client">TYPE_UNSUPPORTED</a>:
<a class="l" name="157" href="#157">157</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_MOVIECLIP&amp;project=rtmp_client">TYPE_MOVIECLIP</a>:
<a class="l" name="158" href="#158">158</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_RECORDSET&amp;project=rtmp_client">TYPE_RECORDSET</a>:
<a class="l" name="159" href="#159">159</a>				<span class="c">// These types are not handled by core datatypes</span>
<a class="hl" name="160" href="#160">160</a>				<span class="c">// So add the amf mask to them, this way the deserializer</span>
<a class="l" name="161" href="#161">161</a>				<span class="c">// will call back to readCustom, we can then handle or return null</span>
<a class="l" name="162" href="#162">162</a>				<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = (<b>byte</b>) (<a class="d" href="#currentDataType">currentDataType</a> + <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CUSTOM_AMF_MASK&amp;project=rtmp_client">CUSTOM_AMF_MASK</a>);
<a class="l" name="163" href="#163">163</a>				<b>break</b>;
<a class="l" name="164" href="#164">164</a>
<a class="l" name="165" href="#165">165</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_END_OF_OBJECT&amp;project=rtmp_client">TYPE_END_OF_OBJECT</a>:
<a class="l" name="166" href="#166">166</a>			<b>default</b>:
<a class="l" name="167" href="#167">167</a>				<span class="c">// End of object, and anything else lets just skip</span>
<a class="l" name="168" href="#168">168</a>				<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_SKIP&amp;project=rtmp_client">CORE_SKIP</a>;
<a class="l" name="169" href="#169">169</a>				<b>break</b>;
<a class="hl" name="170" href="#170">170</a>		}
<a class="l" name="171" href="#171">171</a>
<a class="l" name="172" href="#172">172</a>		<b>return</b> <a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a>;
<a class="l" name="173" href="#173">173</a>	}
<a class="l" name="174" href="#174">174</a>
<a class="l" name="175" href="#175">175</a>	<span class="c">// Basic</span>
<a class="l" name="176" href="#176">176</a>
<a class="l" name="177" href="#177">177</a>	<span class="c">/**
<a class="l" name="178" href="#178">178</a>	 * Reads a null.
<a class="l" name="179" href="#179">179</a>	 *
<a class="hl" name="180" href="#180">180</a>	 * <strong>@return</strong> Object
<a class="l" name="181" href="#181">181</a>	 */</span>
<a class="l" name="182" href="#182">182</a>	<b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="readNull"/><a href="/source/s?refs=readNull&amp;project=rtmp_client" class="xmt">readNull</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="183" href="#183">183</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="184" href="#184">184</a>	}
<a class="l" name="185" href="#185">185</a>
<a class="l" name="186" href="#186">186</a>	<span class="c">/**
<a class="l" name="187" href="#187">187</a>	 * Reads a boolean.
<a class="l" name="188" href="#188">188</a>	 *
<a class="l" name="189" href="#189">189</a>	 * <strong>@return</strong> boolean
<a class="hl" name="190" href="#190">190</a>	 */</span>
<a class="l" name="191" href="#191">191</a>	<b>public</b> <a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a> <a class="xmt" name="readBoolean"/><a href="/source/s?refs=readBoolean&amp;project=rtmp_client" class="xmt">readBoolean</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="192" href="#192">192</a>		<span class="c">// TODO: check values</span>
<a class="l" name="193" href="#193">193</a>		<b>return</b> (<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() == <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=VALUE_TRUE&amp;project=rtmp_client">VALUE_TRUE</a>) ? <a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a>.<a href="/source/s?defs=TRUE&amp;project=rtmp_client">TRUE</a> : <a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a>.<a href="/source/s?defs=FALSE&amp;project=rtmp_client">FALSE</a>;
<a class="l" name="194" href="#194">194</a>	}
<a class="l" name="195" href="#195">195</a>
<a class="l" name="196" href="#196">196</a>	<span class="c">/**
<a class="l" name="197" href="#197">197</a>	 * Reads a Number. In ActionScript 1 and 2 Number type represents all numbers,
<a class="l" name="198" href="#198">198</a>	 * both floats and integers.
<a class="l" name="199" href="#199">199</a>	 *
<a class="hl" name="200" href="#200">200</a>	 * <strong>@return</strong> Number
<a class="l" name="201" href="#201">201</a>	 */</span>
<a class="l" name="202" href="#202">202</a>	<b>public</b> <a href="/source/s?defs=Number&amp;project=rtmp_client">Number</a> <a class="xmt" name="readNumber"/><a href="/source/s?refs=readNumber&amp;project=rtmp_client" class="xmt">readNumber</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="203" href="#203">203</a>		<b>double</b> <a href="/source/s?defs=num&amp;project=rtmp_client">num</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=getDouble&amp;project=rtmp_client">getDouble</a>();
<a class="l" name="204" href="#204">204</a>		<b>if</b> (<a href="/source/s?defs=num&amp;project=rtmp_client">num</a> == <a href="/source/s?defs=Math&amp;project=rtmp_client">Math</a>.<a href="/source/s?defs=round&amp;project=rtmp_client">round</a>(<a href="/source/s?defs=num&amp;project=rtmp_client">num</a>)) {
<a class="l" name="205" href="#205">205</a>			<b>if</b> (<a href="/source/s?defs=num&amp;project=rtmp_client">num</a> &lt; <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=MAX_VALUE&amp;project=rtmp_client">MAX_VALUE</a>) {
<a class="l" name="206" href="#206">206</a>				<b>return</b> (<b>int</b>) <a href="/source/s?defs=num&amp;project=rtmp_client">num</a>;
<a class="l" name="207" href="#207">207</a>			} <b>else</b> {
<a class="l" name="208" href="#208">208</a>				<b>return</b> <a href="/source/s?defs=Math&amp;project=rtmp_client">Math</a>.<a href="/source/s?defs=round&amp;project=rtmp_client">round</a>(<a href="/source/s?defs=num&amp;project=rtmp_client">num</a>);
<a class="l" name="209" href="#209">209</a>			}
<a class="hl" name="210" href="#210">210</a>		} <b>else</b> {
<a class="l" name="211" href="#211">211</a>			<b>return</b> <a href="/source/s?defs=num&amp;project=rtmp_client">num</a>;
<a class="l" name="212" href="#212">212</a>		}
<a class="l" name="213" href="#213">213</a>	}
<a class="l" name="214" href="#214">214</a>
<a class="l" name="215" href="#215">215</a>	<span class="c">/**
<a class="l" name="216" href="#216">216</a>	 * Reads string from buffer
<a class="l" name="217" href="#217">217</a>	 * <strong>@return</strong>             String
<a class="l" name="218" href="#218">218</a>	 */</span>
<a class="l" name="219" href="#219">219</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getString"/><a href="/source/s?refs=getString&amp;project=rtmp_client" class="xmt">getString</a>() {
<a class="hl" name="220" href="#220">220</a>		<b>return</b> <a href="/source/s?defs=getString&amp;project=rtmp_client">getString</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="221" href="#221">221</a>	}
<a class="l" name="222" href="#222">222</a>
<a class="l" name="223" href="#223">223</a>	<span class="c">/**
<a class="l" name="224" href="#224">224</a>	 * Reads a string
<a class="l" name="225" href="#225">225</a>	 *
<a class="l" name="226" href="#226">226</a>	 * <strong>@return</strong> String
<a class="l" name="227" href="#227">227</a>	 */</span>
<a class="l" name="228" href="#228">228</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="readString"/><a href="/source/s?refs=readString&amp;project=rtmp_client" class="xmt">readString</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="229" href="#229">229</a>		<b>int</b> <a class="d" href="#len">len</a> = <span class="n">0</span>;
<a class="hl" name="230" href="#230">230</a>		<b>switch</b> (<a class="d" href="#currentDataType">currentDataType</a>) {
<a class="l" name="231" href="#231">231</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_LONG_STRING&amp;project=rtmp_client">TYPE_LONG_STRING</a>:
<a class="l" name="232" href="#232">232</a>				<a class="d" href="#len">len</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>();
<a class="l" name="233" href="#233">233</a>				<b>break</b>;
<a class="l" name="234" href="#234">234</a>			<b>case</b> <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_STRING&amp;project=rtmp_client">TYPE_STRING</a>:
<a class="l" name="235" href="#235">235</a>				<a class="d" href="#len">len</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=getUnsignedShort&amp;project=rtmp_client">getUnsignedShort</a>();
<a class="l" name="236" href="#236">236</a>				<b>break</b>;
<a class="l" name="237" href="#237">237</a>			<b>default</b>:
<a class="l" name="238" href="#238">238</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Unknown AMF type: {}"</span>, <a class="d" href="#currentDataType">currentDataType</a>);
<a class="l" name="239" href="#239">239</a>		}
<a class="hl" name="240" href="#240">240</a>		<b>int</b> <a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>();
<a class="l" name="241" href="#241">241</a><span class="c">//		log.debug("Limit: {}", limit);</span>
<a class="l" name="242" href="#242">242</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=string&amp;project=rtmp_client">string</a> = <a class="d" href="#bufferToString">bufferToString</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>(), <a class="d" href="#len">len</a>);
<a class="l" name="243" href="#243">243</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>); <span class="c">// Reset the limit</span>
<a class="l" name="244" href="#244">244</a>		<b>return</b> <a href="/source/s?defs=string&amp;project=rtmp_client">string</a>;
<a class="l" name="245" href="#245">245</a>	}
<a class="l" name="246" href="#246">246</a>
<a class="l" name="247" href="#247">247</a>	<span class="c">/**
<a class="l" name="248" href="#248">248</a>	 * Returns a string based on the buffer
<a class="l" name="249" href="#249">249</a>	 *
<a class="hl" name="250" href="#250">250</a>	 * <strong>@param</strong> <em>buf</em>       Byte buffer with data
<a class="l" name="251" href="#251">251</a>	 * <strong>@return</strong> String   Decoded string
<a class="l" name="252" href="#252">252</a>	 */</span>
<a class="l" name="253" href="#253">253</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getString"/><a href="/source/s?refs=getString&amp;project=rtmp_client" class="xmt">getString</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="buf"/><a href="/source/s?refs=buf&amp;project=rtmp_client" class="xa">buf</a>) {
<a class="l" name="254" href="#254">254</a>		<b>int</b> <a class="d" href="#len">len</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=getUnsignedShort&amp;project=rtmp_client">getUnsignedShort</a>();
<a class="l" name="255" href="#255">255</a><span class="c">//		log.debug("Length: {}", len);</span>
<a class="l" name="256" href="#256">256</a>		<b>int</b> <a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>();
<a class="l" name="257" href="#257">257</a><span class="c">//		log.debug("Limit: {}", limit);</span>
<a class="l" name="258" href="#258">258</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=string&amp;project=rtmp_client">string</a> = <a class="d" href="#bufferToString">bufferToString</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>(), <a class="d" href="#len">len</a>);
<a class="l" name="259" href="#259">259</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>); <span class="c">// Reset the limit</span>
<a class="hl" name="260" href="#260">260</a>		<b>return</b> <a href="/source/s?defs=string&amp;project=rtmp_client">string</a>;
<a class="l" name="261" href="#261">261</a>	}
<a class="l" name="262" href="#262">262</a>
<a class="l" name="263" href="#263">263</a>	<span class="c">/**
<a class="l" name="264" href="#264">264</a>	 * Converts the bytes into a string.
<a class="l" name="265" href="#265">265</a>	 *
<a class="l" name="266" href="#266">266</a>	 * <strong>@param</strong> <em>strBuf</em>
<a class="l" name="267" href="#267">267</a>	 * <strong>@return</strong> contents of the ByteBuffer as a String
<a class="l" name="268" href="#268">268</a>	 */</span>
<a class="l" name="269" href="#269">269</a>	<b>private</b> <b>final</b> <b>static</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="bufferToString"/><a href="/source/s?refs=bufferToString&amp;project=rtmp_client" class="xmt">bufferToString</a>(<b>final</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a> <a class="xa" name="strBuf"/><a href="/source/s?refs=strBuf&amp;project=rtmp_client" class="xa">strBuf</a>, <b>int</b> <a class="xa" name="len"/><a href="/source/s?refs=len&amp;project=rtmp_client" class="xa">len</a>) {
<a class="hl" name="270" href="#270">270</a>		<span class="c">//Trac #601 - part of the problem seems to be a null byte buffer</span>
<a class="l" name="271" href="#271">271</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=string&amp;project=rtmp_client">string</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="272" href="#272">272</a>		<b>if</b> (<a class="d" href="#strBuf">strBuf</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="273" href="#273">273</a>			<b>int</b> <a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a> = <a class="d" href="#strBuf">strBuf</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>();
<a class="l" name="274" href="#274">274</a><span class="c">//			log.debug("String buf - position: {} limit: {}", pos, (pos + len));</span>
<a class="l" name="275" href="#275">275</a>			<a class="d" href="#strBuf">strBuf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(<a href="/source/s?defs=pos&amp;project=rtmp_client">pos</a> + <a class="d" href="#len">len</a>);
<a class="l" name="276" href="#276">276</a>			<a href="/source/s?defs=string&amp;project=rtmp_client">string</a> = <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=CHARSET&amp;project=rtmp_client">CHARSET</a>.<a href="/source/s?defs=decode&amp;project=rtmp_client">decode</a>(<a class="d" href="#strBuf">strBuf</a>).<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>();
<a class="l" name="277" href="#277">277</a><span class="c">//			log.debug("String: {}", string);</span>
<a class="l" name="278" href="#278">278</a>		} <b>else</b> {
<a class="l" name="279" href="#279">279</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"ByteBuffer was null attempting to read String"</span>);
<a class="hl" name="280" href="#280">280</a>		}
<a class="l" name="281" href="#281">281</a>		<b>return</b> <a href="/source/s?defs=string&amp;project=rtmp_client">string</a>;
<a class="l" name="282" href="#282">282</a>	}
<a class="l" name="283" href="#283">283</a>
<a class="l" name="284" href="#284">284</a>	<span class="c">/**
<a class="l" name="285" href="#285">285</a>	 * Returns a date
<a class="l" name="286" href="#286">286</a>	 *
<a class="l" name="287" href="#287">287</a>	 * <strong>@return</strong> Date      Decoded string object
<a class="l" name="288" href="#288">288</a>	 */</span>
<a class="l" name="289" href="#289">289</a>	<b>public</b> <a href="/source/s?defs=Date&amp;project=rtmp_client">Date</a> <a class="xmt" name="readDate"/><a href="/source/s?refs=readDate&amp;project=rtmp_client" class="xmt">readDate</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="hl" name="290" href="#290">290</a>		<span class="c">/*
<a class="l" name="291" href="#291">291</a>		 * Date: 0x0B T7 T6 .. T0 Z1 Z2 T7 to T0 form a 64 bit Big Endian number
<a class="l" name="292" href="#292">292</a>		 * that specifies the number of nanoseconds that have passed since
<a class="l" name="293" href="#293">293</a>		 * 1/1/1970 0:00 to the specified time. This format is UTC 1970. Z1 an
<a class="l" name="294" href="#294">294</a>		 * Z0 for a 16 bit Big Endian number indicating the indicated time's
<a class="l" name="295" href="#295">295</a>		 * timezone in minutes.
<a class="l" name="296" href="#296">296</a>		 */</span>
<a class="l" name="297" href="#297">297</a>		<b>long</b> <a href="/source/s?defs=ms&amp;project=rtmp_client">ms</a> = (<b>long</b>) <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=getDouble&amp;project=rtmp_client">getDouble</a>();
<a class="l" name="298" href="#298">298</a>		<span class="c">// The timezone can be ignored as the date always is encoded in UTC</span>
<a class="l" name="299" href="#299">299</a>		@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unused"</span>)
<a class="hl" name="300" href="#300">300</a>		<b>short</b> <a href="/source/s?defs=timeZoneMins&amp;project=rtmp_client">timeZoneMins</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=getShort&amp;project=rtmp_client">getShort</a>();
<a class="l" name="301" href="#301">301</a>		<a href="/source/s?defs=Date&amp;project=rtmp_client">Date</a> <a href="/source/s?defs=date&amp;project=rtmp_client">date</a> = <b>new</b> <a href="/source/s?defs=Date&amp;project=rtmp_client">Date</a>(<a href="/source/s?defs=ms&amp;project=rtmp_client">ms</a>);
<a class="l" name="302" href="#302">302</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=date&amp;project=rtmp_client">date</a>);
<a class="l" name="303" href="#303">303</a>		<b>return</b> <a href="/source/s?defs=date&amp;project=rtmp_client">date</a>;
<a class="l" name="304" href="#304">304</a>	}
<a class="l" name="305" href="#305">305</a>
<a class="l" name="306" href="#306">306</a>	<span class="c">// Array</span>
<a class="l" name="307" href="#307">307</a>
<a class="l" name="308" href="#308">308</a>	<b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="readArray"/><a href="/source/s?refs=readArray&amp;project=rtmp_client" class="xmt">readArray</a>(<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xa" name="deserializer"/><a href="/source/s?refs=deserializer&amp;project=rtmp_client" class="xa">deserializer</a>, <a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="309" href="#309">309</a><span class="c">//		log.debug("readArray - deserializer: {} target: {}", deserializer, target);</span>
<a class="hl" name="310" href="#310">310</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="d" href="#result">result</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="311" href="#311">311</a>		<b>int</b> <a href="/source/s?defs=count&amp;project=rtmp_client">count</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>();
<a class="l" name="312" href="#312">312</a><span class="c">//		log.debug("Count: {}", count);</span>
<a class="l" name="313" href="#313">313</a>		<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=resultCollection&amp;project=rtmp_client">resultCollection</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;(<a href="/source/s?defs=count&amp;project=rtmp_client">count</a>);
<a class="l" name="314" href="#314">314</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a class="d" href="#result">result</a>);
<a class="l" name="315" href="#315">315</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=count&amp;project=rtmp_client">count</a>; i++) {
<a class="l" name="316" href="#316">316</a>			<a href="/source/s?defs=resultCollection&amp;project=rtmp_client">resultCollection</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<b>this</b>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>.<b>class</b>));
<a class="l" name="317" href="#317">317</a>		}
<a class="l" name="318" href="#318">318</a>		<span class="c">// To maintain conformance to the Input API, we should convert the output</span>
<a class="l" name="319" href="#319">319</a>		<span class="c">// into an Array if the Type asks us to.</span>
<a class="hl" name="320" href="#320">320</a>		<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a href="/source/s?defs=collection&amp;project=rtmp_client">collection</a> = <a href="/source/s?defs=Collection&amp;project=rtmp_client">Collection</a>.<b>class</b>;
<a class="l" name="321" href="#321">321</a>		<b>if</b> (<a href="/source/s?defs=target&amp;project=rtmp_client">target</a> <b>instanceof</b> <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;) {
<a class="l" name="322" href="#322">322</a>			<a href="/source/s?defs=collection&amp;project=rtmp_client">collection</a> = (<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;) <a href="/source/s?defs=target&amp;project=rtmp_client">target</a>;
<a class="l" name="323" href="#323">323</a>		}
<a class="l" name="324" href="#324">324</a>		<b>if</b> (<a href="/source/s?defs=collection&amp;project=rtmp_client">collection</a>.<a href="/source/s?defs=isArray&amp;project=rtmp_client">isArray</a>()) {
<a class="l" name="325" href="#325">325</a>			<a class="d" href="#result">result</a> = <a href="/source/s?defs=ArrayUtils&amp;project=rtmp_client">ArrayUtils</a>.<a href="/source/s?defs=toArray&amp;project=rtmp_client">toArray</a>(<a href="/source/s?defs=collection&amp;project=rtmp_client">collection</a>.<a href="/source/s?defs=getComponentType&amp;project=rtmp_client">getComponentType</a>(), <a href="/source/s?defs=resultCollection&amp;project=rtmp_client">resultCollection</a>);
<a class="l" name="326" href="#326">326</a>		} <b>else</b> {
<a class="l" name="327" href="#327">327</a>			<a class="d" href="#result">result</a> = <a href="/source/s?defs=resultCollection&amp;project=rtmp_client">resultCollection</a>;
<a class="l" name="328" href="#328">328</a>		}
<a class="l" name="329" href="#329">329</a>		<b>return</b> <a class="d" href="#result">result</a>;
<a class="hl" name="330" href="#330">330</a>	}
<a class="l" name="331" href="#331">331</a>
<a class="l" name="332" href="#332">332</a>	<span class="c">// Map</span>
<a class="l" name="333" href="#333">333</a>
<a class="l" name="334" href="#334">334</a>	<span class="c">/**
<a class="l" name="335" href="#335">335</a>	 * Read key - value pairs. This is required for the RecordSet
<a class="l" name="336" href="#336">336</a>	 * deserializer.
<a class="l" name="337" href="#337">337</a>	 */</span>
<a class="l" name="338" href="#338">338</a>	<b>public</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xmt" name="readKeyValues"/><a href="/source/s?refs=readKeyValues&amp;project=rtmp_client" class="xmt">readKeyValues</a>(<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xa" name="deserializer"/><a href="/source/s?refs=deserializer&amp;project=rtmp_client" class="xa">deserializer</a>) {
<a class="l" name="339" href="#339">339</a>		<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="d" href="#result">result</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="hl" name="340" href="#340">340</a>		<a href="/source/s?defs=readKeyValues&amp;project=rtmp_client">readKeyValues</a>(<a class="d" href="#result">result</a>, <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>);
<a class="l" name="341" href="#341">341</a>		<b>return</b> <a class="d" href="#result">result</a>;
<a class="l" name="342" href="#342">342</a>	}
<a class="l" name="343" href="#343">343</a>
<a class="l" name="344" href="#344">344</a>	<span class="c">/**
<a class="l" name="345" href="#345">345</a>	 * Read key - value pairs into Map object
<a class="l" name="346" href="#346">346</a>	 * <strong>@param</strong> <em>result</em>            Map to put resulting pair to
<a class="l" name="347" href="#347">347</a>	 * <strong>@param</strong> <em>deserializer</em>      Deserializer used
<a class="l" name="348" href="#348">348</a>	 */</span>
<a class="l" name="349" href="#349">349</a>	<b>protected</b> <b>void</b> <a class="xmt" name="readKeyValues"/><a href="/source/s?refs=readKeyValues&amp;project=rtmp_client" class="xmt">readKeyValues</a>(<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xa" name="result"/><a href="/source/s?refs=result&amp;project=rtmp_client" class="xa">result</a>, <a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xa" name="deserializer"/><a href="/source/s?refs=deserializer&amp;project=rtmp_client" class="xa">deserializer</a>) {
<a class="hl" name="350" href="#350">350</a>		<b>while</b> (<a class="d" href="#hasMoreProperties">hasMoreProperties</a>()) {
<a class="l" name="351" href="#351">351</a>			<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=name&amp;project=rtmp_client">name</a> = <a class="d" href="#readPropertyName">readPropertyName</a>();
<a class="l" name="352" href="#352">352</a><span class="c">//			log.debug("property: {}", name);</span>
<a class="l" name="353" href="#353">353</a>			<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=property&amp;project=rtmp_client">property</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<b>this</b>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>.<b>class</b>);
<a class="l" name="354" href="#354">354</a><span class="c">//			log.debug("val: {}", property);</span>
<a class="l" name="355" href="#355">355</a>			<a class="d" href="#result">result</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=property&amp;project=rtmp_client">property</a>);
<a class="l" name="356" href="#356">356</a>			<b>if</b> (<a class="d" href="#hasMoreProperties">hasMoreProperties</a>()) {
<a class="l" name="357" href="#357">357</a>				<a class="d" href="#skipPropertySeparator">skipPropertySeparator</a>();
<a class="l" name="358" href="#358">358</a>			}
<a class="l" name="359" href="#359">359</a>		}
<a class="hl" name="360" href="#360">360</a>		<a class="d" href="#skipEndObject">skipEndObject</a>();
<a class="l" name="361" href="#361">361</a>	}
<a class="l" name="362" href="#362">362</a>
<a class="l" name="363" href="#363">363</a>	<b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="readMap"/><a href="/source/s?refs=readMap&amp;project=rtmp_client" class="xmt">readMap</a>(<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xa" name="deserializer"/><a href="/source/s?refs=deserializer&amp;project=rtmp_client" class="xa">deserializer</a>, <a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="364" href="#364">364</a>		<span class="c">// The maximum number used in this mixed array.</span>
<a class="l" name="365" href="#365">365</a>		<b>int</b> <a href="/source/s?defs=maxNumber&amp;project=rtmp_client">maxNumber</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>();
<a class="l" name="366" href="#366">366</a><span class="c">//		log.debug("Read start mixed array: {}", maxNumber);</span>
<a class="l" name="367" href="#367">367</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="d" href="#result">result</a>;
<a class="l" name="368" href="#368">368</a>		<b>final</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=mixedResult&amp;project=rtmp_client">mixedResult</a> = <b>new</b> <a href="/source/s?defs=LinkedHashMap&amp;project=rtmp_client">LinkedHashMap</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;(<a href="/source/s?defs=maxNumber&amp;project=rtmp_client">maxNumber</a>);
<a class="l" name="369" href="#369">369</a>		<span class="c">// we must store the reference before we deserialize any items in it to ensure</span>
<a class="hl" name="370" href="#370">370</a>		<span class="c">// that reference IDs are correct</span>
<a class="l" name="371" href="#371">371</a>		<b>int</b> <a href="/source/s?defs=reference&amp;project=rtmp_client">reference</a> = <a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=mixedResult&amp;project=rtmp_client">mixedResult</a>);
<a class="l" name="372" href="#372">372</a>		<a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a> <a href="/source/s?defs=normalArray&amp;project=rtmp_client">normalArray</a> = <b>true</b>;
<a class="l" name="373" href="#373">373</a>		<b>while</b> (<a class="d" href="#hasMoreProperties">hasMoreProperties</a>()) {
<a class="l" name="374" href="#374">374</a>			<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=key&amp;project=rtmp_client">key</a> = <a href="/source/s?defs=getString&amp;project=rtmp_client">getString</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="375" href="#375">375</a><span class="c">//			log.debug("key: {}", key);</span>
<a class="l" name="376" href="#376">376</a>			<b>try</b> {
<a class="l" name="377" href="#377">377</a>				<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=parseInt&amp;project=rtmp_client">parseInt</a>(<a href="/source/s?defs=key&amp;project=rtmp_client">key</a>);
<a class="l" name="378" href="#378">378</a>			} <b>catch</b> (<a href="/source/s?defs=NumberFormatException&amp;project=rtmp_client">NumberFormatException</a> e) {
<a class="l" name="379" href="#379">379</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"key {} is causing non normal array"</span>, <a href="/source/s?defs=key&amp;project=rtmp_client">key</a>);
<a class="hl" name="380" href="#380">380</a>				<a href="/source/s?defs=normalArray&amp;project=rtmp_client">normalArray</a> = <b>false</b>;
<a class="l" name="381" href="#381">381</a>			}
<a class="l" name="382" href="#382">382</a>			<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=item&amp;project=rtmp_client">item</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<b>this</b>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>.<b>class</b>);
<a class="l" name="383" href="#383">383</a><span class="c">//			log.debug("item: {}", item);</span>
<a class="l" name="384" href="#384">384</a>			<a href="/source/s?defs=mixedResult&amp;project=rtmp_client">mixedResult</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=key&amp;project=rtmp_client">key</a>, <a href="/source/s?defs=item&amp;project=rtmp_client">item</a>);
<a class="l" name="385" href="#385">385</a>		}
<a class="l" name="386" href="#386">386</a>
<a class="l" name="387" href="#387">387</a>		<b>if</b> (<a href="/source/s?defs=mixedResult&amp;project=rtmp_client">mixedResult</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>() &lt;= <a href="/source/s?defs=maxNumber&amp;project=rtmp_client">maxNumber</a> + <span class="n">1</span> &amp;&amp; <a href="/source/s?defs=normalArray&amp;project=rtmp_client">normalArray</a>) {
<a class="l" name="388" href="#388">388</a>			<span class="c">// MixedArray actually is a regular array</span>
<a class="l" name="389" href="#389">389</a><span class="c">//			log.debug("mixed array is a regular array");</span>
<a class="hl" name="390" href="#390">390</a>			<b>final</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=listResult&amp;project=rtmp_client">listResult</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;(<a href="/source/s?defs=maxNumber&amp;project=rtmp_client">maxNumber</a>);
<a class="l" name="391" href="#391">391</a>			<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=maxNumber&amp;project=rtmp_client">maxNumber</a>; i++) {
<a class="l" name="392" href="#392">392</a>				<a href="/source/s?defs=listResult&amp;project=rtmp_client">listResult</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(i, <a href="/source/s?defs=mixedResult&amp;project=rtmp_client">mixedResult</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(i)));
<a class="l" name="393" href="#393">393</a>			}
<a class="l" name="394" href="#394">394</a>			<a class="d" href="#result">result</a> = <a href="/source/s?defs=listResult&amp;project=rtmp_client">listResult</a>;
<a class="l" name="395" href="#395">395</a>		} <b>else</b> {
<a class="l" name="396" href="#396">396</a>			<span class="c">// Convert initial indexes</span>
<a class="l" name="397" href="#397">397</a>			<a href="/source/s?defs=mixedResult&amp;project=rtmp_client">mixedResult</a>.<a href="/source/s?defs=remove&amp;project=rtmp_client">remove</a>(<span class="s">"length"</span>);
<a class="l" name="398" href="#398">398</a>			<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=maxNumber&amp;project=rtmp_client">maxNumber</a>; i++) {
<a class="l" name="399" href="#399">399</a>				<b>final</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a href="/source/s?defs=mixedResult&amp;project=rtmp_client">mixedResult</a>.<a href="/source/s?defs=remove&amp;project=rtmp_client">remove</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(i));
<a class="hl" name="400" href="#400">400</a>				<a href="/source/s?defs=mixedResult&amp;project=rtmp_client">mixedResult</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(i, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="401" href="#401">401</a>			}
<a class="l" name="402" href="#402">402</a>			<a class="d" href="#result">result</a> = <a href="/source/s?defs=mixedResult&amp;project=rtmp_client">mixedResult</a>;
<a class="l" name="403" href="#403">403</a>		}
<a class="l" name="404" href="#404">404</a>		<span class="c">// Replace the original reference with the final result</span>
<a class="l" name="405" href="#405">405</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=reference&amp;project=rtmp_client">reference</a>, <a class="d" href="#result">result</a>);
<a class="l" name="406" href="#406">406</a>		<a class="d" href="#skipEndObject">skipEndObject</a>();
<a class="l" name="407" href="#407">407</a>		<b>return</b> <a class="d" href="#result">result</a>;
<a class="l" name="408" href="#408">408</a>	}
<a class="l" name="409" href="#409">409</a>
<a class="hl" name="410" href="#410">410</a>	<span class="c">// Object</span>
<a class="l" name="411" href="#411">411</a>
<a class="l" name="412" href="#412">412</a>	<span class="c">/**
<a class="l" name="413" href="#413">413</a>	 * Creates a new instance of the className parameter and
<a class="l" name="414" href="#414">414</a>	 * returns as an Object
<a class="l" name="415" href="#415">415</a>	 *
<a class="l" name="416" href="#416">416</a>	 * <strong>@param</strong> <em>className</em>        Class name as String
<a class="l" name="417" href="#417">417</a>	 * <strong>@return</strong> Object          New object instance (for given class)
<a class="l" name="418" href="#418">418</a>	 */</span>
<a class="l" name="419" href="#419">419</a>	<b>protected</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="newInstance"/><a href="/source/s?refs=newInstance&amp;project=rtmp_client" class="xmt">newInstance</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="className"/><a href="/source/s?refs=className&amp;project=rtmp_client" class="xa">className</a>) {
<a class="hl" name="420" href="#420">420</a><span class="c">//		log.debug("Loading class: {}", className);</span>
<a class="l" name="421" href="#421">421</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="d" href="#instance">instance</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="422" href="#422">422</a>		<span class="c">//fix for Trac #604</span>
<a class="l" name="423" href="#423">423</a>		<b>if</b> (<span class="s">""</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a class="d" href="#className">className</a>) || <a class="d" href="#className">className</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>)
<a class="l" name="424" href="#424">424</a>			<b>return</b> <a class="d" href="#instance">instance</a>;
<a class="l" name="425" href="#425">425</a>		<b>try</b> {
<a class="l" name="426" href="#426">426</a>			<span class="c">//check for special DS class aliases</span>
<a class="l" name="427" href="#427">427</a>			<b>if</b> (<a class="d" href="#className">className</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>() == <span class="n">3</span>) {
<a class="l" name="428" href="#428">428</a>				<a class="d" href="#className">className</a> = <a class="d" href="#classAliases">classAliases</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a class="d" href="#className">className</a>);
<a class="l" name="429" href="#429">429</a>			}
<a class="hl" name="430" href="#430">430</a>			<b>if</b> (<a class="d" href="#className">className</a>.<a href="/source/s?defs=startsWith&amp;project=rtmp_client">startsWith</a>(<span class="s">"flex."</span>)) {
<a class="l" name="431" href="#431">431</a>				<span class="c">// Use Red5 compatibility class instead</span>
<a class="l" name="432" href="#432">432</a>				<a class="d" href="#className">className</a> = <span class="s">"org.red5.compatibility."</span> + <a class="d" href="#className">className</a>;
<a class="l" name="433" href="#433">433</a><span class="c">//				log.debug("Modified classname: {}", className);</span>
<a class="l" name="434" href="#434">434</a>			}
<a class="l" name="435" href="#435">435</a>			<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a href="/source/s?defs=clazz&amp;project=rtmp_client">clazz</a> = <a href="/source/s?defs=Thread&amp;project=rtmp_client">Thread</a>.<a href="/source/s?defs=currentThread&amp;project=rtmp_client">currentThread</a>().<a href="/source/s?defs=getContextClassLoader&amp;project=rtmp_client">getContextClassLoader</a>().<a href="/source/s?defs=loadClass&amp;project=rtmp_client">loadClass</a>(<a class="d" href="#className">className</a>);
<a class="l" name="436" href="#436">436</a>			<a class="d" href="#instance">instance</a> = <a href="/source/s?defs=clazz&amp;project=rtmp_client">clazz</a>.<a class="d" href="#newInstance">newInstance</a>();
<a class="l" name="437" href="#437">437</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> <a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>) {
<a class="l" name="438" href="#438">438</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error loading class: {}"</span>, <a class="d" href="#className">className</a>);
<a class="l" name="439" href="#439">439</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Exception was: {}"</span>, <a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>);
<a class="hl" name="440" href="#440">440</a>		}
<a class="l" name="441" href="#441">441</a>		<b>return</b> <a class="d" href="#instance">instance</a>;
<a class="l" name="442" href="#442">442</a>	}
<a class="l" name="443" href="#443">443</a>
<a class="l" name="444" href="#444">444</a>	<span class="c">/**
<a class="l" name="445" href="#445">445</a>	 * Reads the input as a bean and returns an object
<a class="l" name="446" href="#446">446</a>	 *
<a class="l" name="447" href="#447">447</a>	 * <strong>@param</strong> <em>deserializer</em>       Deserializer used
<a class="l" name="448" href="#448">448</a>	 * <strong>@param</strong> <em>bean</em>               Input as bean
<a class="l" name="449" href="#449">449</a>	 * <strong>@return</strong>                   Decoded object
<a class="hl" name="450" href="#450">450</a>	 */</span>
<a class="l" name="451" href="#451">451</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>({ <span class="s">"unchecked"</span>, <span class="s">"rawtypes"</span> })
<a class="l" name="452" href="#452">452</a>	<b>protected</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="readBean"/><a href="/source/s?refs=readBean&amp;project=rtmp_client" class="xmt">readBean</a>(<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xa" name="deserializer"/><a href="/source/s?refs=deserializer&amp;project=rtmp_client" class="xa">deserializer</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="bean"/><a href="/source/s?refs=bean&amp;project=rtmp_client" class="xa">bean</a>) {
<a class="l" name="453" href="#453">453</a><span class="c">//		log.debug("read bean");</span>
<a class="l" name="454" href="#454">454</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a class="d" href="#bean">bean</a>);
<a class="l" name="455" href="#455">455</a>		<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a> <a href="/source/s?defs=theClass&amp;project=rtmp_client">theClass</a> = <a class="d" href="#bean">bean</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>();
<a class="l" name="456" href="#456">456</a>		<b>while</b> (<a class="d" href="#hasMoreProperties">hasMoreProperties</a>()) {
<a class="l" name="457" href="#457">457</a>			<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=name&amp;project=rtmp_client">name</a> = <a class="d" href="#readPropertyName">readPropertyName</a>();
<a class="l" name="458" href="#458">458</a>			<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <a class="d" href="#getPropertyType">getPropertyType</a>(<a class="d" href="#bean">bean</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>);
<a class="l" name="459" href="#459">459</a><span class="c">//			log.debug("property: {}", name);</span>
<a class="hl" name="460" href="#460">460</a>			<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=property&amp;project=rtmp_client">property</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<b>this</b>, <a href="/source/s?defs=type&amp;project=rtmp_client">type</a>);
<a class="l" name="461" href="#461">461</a><span class="c">//			log.debug("val: {}", property);</span>
<a class="l" name="462" href="#462">462</a>			<span class="c">//log.debug("val: "+property.getClass().getName());</span>
<a class="l" name="463" href="#463">463</a>			<b>if</b> (<a href="/source/s?defs=property&amp;project=rtmp_client">property</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="464" href="#464">464</a>				<b>try</b> {
<a class="l" name="465" href="#465">465</a>					<b>if</b> (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> <b>instanceof</b> <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>) {
<a class="l" name="466" href="#466">466</a>						<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a> t = (<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>) <a href="/source/s?defs=type&amp;project=rtmp_client">type</a>;
<a class="l" name="467" href="#467">467</a>						<b>if</b> (!t.<a href="/source/s?defs=isAssignableFrom&amp;project=rtmp_client">isAssignableFrom</a>(<a href="/source/s?defs=property&amp;project=rtmp_client">property</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>())) {
<a class="l" name="468" href="#468">468</a>							<a href="/source/s?defs=property&amp;project=rtmp_client">property</a> = <a href="/source/s?defs=ConversionUtils&amp;project=rtmp_client">ConversionUtils</a>.<a href="/source/s?defs=convert&amp;project=rtmp_client">convert</a>(<a href="/source/s?defs=property&amp;project=rtmp_client">property</a>, t);
<a class="l" name="469" href="#469">469</a>						}
<a class="hl" name="470" href="#470">470</a>					}
<a class="l" name="471" href="#471">471</a>					<b>final</b> <a href="/source/s?defs=Field&amp;project=rtmp_client">Field</a> <a href="/source/s?defs=field&amp;project=rtmp_client">field</a> = <a href="/source/s?defs=theClass&amp;project=rtmp_client">theClass</a>.<a href="/source/s?defs=getField&amp;project=rtmp_client">getField</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>);
<a class="l" name="472" href="#472">472</a>					<a href="/source/s?defs=field&amp;project=rtmp_client">field</a>.<a href="/source/s?defs=set&amp;project=rtmp_client">set</a>(<a class="d" href="#bean">bean</a>, <a href="/source/s?defs=property&amp;project=rtmp_client">property</a>);
<a class="l" name="473" href="#473">473</a>				} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> <a href="/source/s?defs=ex2&amp;project=rtmp_client">ex2</a>) {
<a class="l" name="474" href="#474">474</a>					<b>try</b> {
<a class="l" name="475" href="#475">475</a>						<span class="c">//BeanUtils.setProperty(bean, name, property);</span>
<a class="l" name="476" href="#476">476</a>					} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> <a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>) {
<a class="l" name="477" href="#477">477</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error mapping property: {} ({})"</span>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=property&amp;project=rtmp_client">property</a>);
<a class="l" name="478" href="#478">478</a>					}
<a class="l" name="479" href="#479">479</a>				}
<a class="hl" name="480" href="#480">480</a>			} <b>else</b> {
<a class="l" name="481" href="#481">481</a><span class="c">//				log.debug("Skipping null property: {}", name);</span>
<a class="l" name="482" href="#482">482</a>			}
<a class="l" name="483" href="#483">483</a>
<a class="l" name="484" href="#484">484</a>			<b>if</b> (<a class="d" href="#hasMoreProperties">hasMoreProperties</a>()) {
<a class="l" name="485" href="#485">485</a>				<a class="d" href="#skipPropertySeparator">skipPropertySeparator</a>();
<a class="l" name="486" href="#486">486</a>			}
<a class="l" name="487" href="#487">487</a>		}
<a class="l" name="488" href="#488">488</a>		<a class="d" href="#skipEndObject">skipEndObject</a>();
<a class="l" name="489" href="#489">489</a>		<b>return</b> <a class="d" href="#bean">bean</a>;
<a class="hl" name="490" href="#490">490</a>	}
<a class="l" name="491" href="#491">491</a>
<a class="l" name="492" href="#492">492</a>	<span class="c">/**
<a class="l" name="493" href="#493">493</a>	 * Reads the input as a map and returns a Map
<a class="l" name="494" href="#494">494</a>	 *
<a class="l" name="495" href="#495">495</a>	 * <strong>@param</strong> <em>deserializer</em>     Deserializer to use
<a class="l" name="496" href="#496">496</a>	 * <strong>@return</strong>                 Read map
<a class="l" name="497" href="#497">497</a>	 */</span>
<a class="l" name="498" href="#498">498</a>	<b>protected</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xmt" name="readSimpleObject"/><a href="/source/s?refs=readSimpleObject&amp;project=rtmp_client" class="xmt">readSimpleObject</a>(<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xa" name="deserializer"/><a href="/source/s?refs=deserializer&amp;project=rtmp_client" class="xa">deserializer</a>) {
<a class="l" name="499" href="#499">499</a><span class="c">//		log.debug("read map");</span>
<a class="hl" name="500" href="#500">500</a>		<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="d" href="#result">result</a> = <b>new</b> <a href="/source/s?defs=ObjectMap&amp;project=rtmp_client">ObjectMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="l" name="501" href="#501">501</a>		<a href="/source/s?defs=readKeyValues&amp;project=rtmp_client">readKeyValues</a>(<a class="d" href="#result">result</a>, <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>);
<a class="l" name="502" href="#502">502</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a class="d" href="#result">result</a>);
<a class="l" name="503" href="#503">503</a>		<b>return</b> <a class="d" href="#result">result</a>;
<a class="l" name="504" href="#504">504</a>	}
<a class="l" name="505" href="#505">505</a>
<a class="l" name="506" href="#506">506</a>	<span class="c">/**
<a class="l" name="507" href="#507">507</a>	 * Reads start object
<a class="l" name="508" href="#508">508</a>	 *
<a class="l" name="509" href="#509">509</a>	 * <strong>@param</strong> <em>deserializer</em>    Deserializer to use
<a class="hl" name="510" href="#510">510</a>	 * <strong>@return</strong>                Read object
<a class="l" name="511" href="#511">511</a>	 */</span>
<a class="l" name="512" href="#512">512</a>	<b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="readObject"/><a href="/source/s?refs=readObject&amp;project=rtmp_client" class="xmt">readObject</a>(<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xa" name="deserializer"/><a href="/source/s?refs=deserializer&amp;project=rtmp_client" class="xa">deserializer</a>, <a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="513" href="#513">513</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="d" href="#className">className</a>;
<a class="l" name="514" href="#514">514</a>		<b>if</b> (<a class="d" href="#currentDataType">currentDataType</a> == <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_CLASS_OBJECT&amp;project=rtmp_client">TYPE_CLASS_OBJECT</a>) {
<a class="l" name="515" href="#515">515</a>			<a class="d" href="#className">className</a> = <a href="/source/s?defs=getString&amp;project=rtmp_client">getString</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="516" href="#516">516</a>		} <b>else</b> {
<a class="l" name="517" href="#517">517</a>			<a class="d" href="#className">className</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="518" href="#518">518</a>		}
<a class="l" name="519" href="#519">519</a><span class="c">//		log.debug("readObject: {}", className);</span>
<a class="hl" name="520" href="#520">520</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="d" href="#result">result</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="521" href="#521">521</a>		<b>if</b> (<a class="d" href="#className">className</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="522" href="#522">522</a><span class="c">//			log.debug("read class object");</span>
<a class="l" name="523" href="#523">523</a>			<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="d" href="#instance">instance</a>;
<a class="l" name="524" href="#524">524</a>			<b>if</b> (<a class="d" href="#className">className</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<span class="s">"RecordSet"</span>)) {
<a class="l" name="525" href="#525">525</a>				<a class="d" href="#result">result</a> = <b>new</b> <a href="/source/s?defs=RecordSet&amp;project=rtmp_client">RecordSet</a>(<b>this</b>);
<a class="l" name="526" href="#526">526</a>				<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a class="d" href="#result">result</a>);
<a class="l" name="527" href="#527">527</a>			} <b>else</b> <b>if</b> (<a class="d" href="#className">className</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<span class="s">"RecordSetPage"</span>)) {
<a class="l" name="528" href="#528">528</a>				<a class="d" href="#result">result</a> = <b>new</b> <a href="/source/s?defs=RecordSetPage&amp;project=rtmp_client">RecordSetPage</a>(<b>this</b>);
<a class="l" name="529" href="#529">529</a>				<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a class="d" href="#result">result</a>);
<a class="hl" name="530" href="#530">530</a>			} <b>else</b> {
<a class="l" name="531" href="#531">531</a>				<a class="d" href="#instance">instance</a> = <a class="d" href="#newInstance">newInstance</a>(<a class="d" href="#className">className</a>);
<a class="l" name="532" href="#532">532</a>				<b>if</b> (<a class="d" href="#instance">instance</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="533" href="#533">533</a>					<a class="d" href="#result">result</a> = <a class="d" href="#readBean">readBean</a>(<a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>, <a class="d" href="#instance">instance</a>);
<a class="l" name="534" href="#534">534</a>				} <span class="c">// else fall through</span>
<a class="l" name="535" href="#535">535</a>			}
<a class="l" name="536" href="#536">536</a>		} <b>else</b> {
<a class="l" name="537" href="#537">537</a>			<a class="d" href="#result">result</a> = <a class="d" href="#readSimpleObject">readSimpleObject</a>(<a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>);
<a class="l" name="538" href="#538">538</a>		}
<a class="l" name="539" href="#539">539</a>		<b>return</b> <a class="d" href="#result">result</a>;
<a class="hl" name="540" href="#540">540</a>	}
<a class="l" name="541" href="#541">541</a>
<a class="l" name="542" href="#542">542</a>	<span class="c">/**
<a class="l" name="543" href="#543">543</a>	 * Returns a boolean stating whether there are more properties
<a class="l" name="544" href="#544">544</a>	 *
<a class="l" name="545" href="#545">545</a>	 * <strong>@return</strong> boolean       &lt;code&gt;true&lt;/code&gt; if there are more properties to read, &lt;code&gt;false&lt;/code&gt; otherwise
<a class="l" name="546" href="#546">546</a>	 */</span>
<a class="l" name="547" href="#547">547</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="hasMoreProperties"/><a href="/source/s?refs=hasMoreProperties&amp;project=rtmp_client" class="xmt">hasMoreProperties</a>() {
<a class="l" name="548" href="#548">548</a>		<b>byte</b> <a href="/source/s?defs=pad&amp;project=rtmp_client">pad</a> = <span class="n">0x00</span>;
<a class="l" name="549" href="#549">549</a>		<b>byte</b> <a href="/source/s?defs=pad0&amp;project=rtmp_client">pad0</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="hl" name="550" href="#550">550</a>		<b>byte</b> <a href="/source/s?defs=pad1&amp;project=rtmp_client">pad1</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="551" href="#551">551</a>		<b>byte</b> <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="552" href="#552">552</a>
<a class="l" name="553" href="#553">553</a>		<b>boolean</b> <a href="/source/s?defs=isEndOfObject&amp;project=rtmp_client">isEndOfObject</a> = (<a href="/source/s?defs=pad0&amp;project=rtmp_client">pad0</a> == <a href="/source/s?defs=pad&amp;project=rtmp_client">pad</a> &amp;&amp; <a href="/source/s?defs=pad1&amp;project=rtmp_client">pad1</a> == <a href="/source/s?defs=pad&amp;project=rtmp_client">pad</a> &amp;&amp; <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> == <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_END_OF_OBJECT&amp;project=rtmp_client">TYPE_END_OF_OBJECT</a>);
<a class="l" name="554" href="#554">554</a><span class="c">//		log.debug("End of object: ? {}", isEndOfObject);</span>
<a class="l" name="555" href="#555">555</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() - <span class="n">3</span>);
<a class="l" name="556" href="#556">556</a>		<b>return</b> !<a href="/source/s?defs=isEndOfObject&amp;project=rtmp_client">isEndOfObject</a>;
<a class="l" name="557" href="#557">557</a>	}
<a class="l" name="558" href="#558">558</a>
<a class="l" name="559" href="#559">559</a>	<span class="c">/**
<a class="hl" name="560" href="#560">560</a>	 * Reads property name
<a class="l" name="561" href="#561">561</a>	 *
<a class="l" name="562" href="#562">562</a>	 * <strong>@return</strong> String        Object property name
<a class="l" name="563" href="#563">563</a>	 */</span>
<a class="l" name="564" href="#564">564</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="readPropertyName"/><a href="/source/s?refs=readPropertyName&amp;project=rtmp_client" class="xmt">readPropertyName</a>() {
<a class="l" name="565" href="#565">565</a>		<b>return</b> <a href="/source/s?defs=getString&amp;project=rtmp_client">getString</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="566" href="#566">566</a>	}
<a class="l" name="567" href="#567">567</a>
<a class="l" name="568" href="#568">568</a>	<span class="c">/**
<a class="l" name="569" href="#569">569</a>	 * Skips property seperator
<a class="hl" name="570" href="#570">570</a>	 */</span>
<a class="l" name="571" href="#571">571</a>	<b>public</b> <b>void</b> <a class="xmt" name="skipPropertySeparator"/><a href="/source/s?refs=skipPropertySeparator&amp;project=rtmp_client" class="xmt">skipPropertySeparator</a>() {
<a class="l" name="572" href="#572">572</a>		<span class="c">// SKIP</span>
<a class="l" name="573" href="#573">573</a>	}
<a class="l" name="574" href="#574">574</a>
<a class="l" name="575" href="#575">575</a>	<span class="c">/**
<a class="l" name="576" href="#576">576</a>	 * Skips end object
<a class="l" name="577" href="#577">577</a>	 */</span>
<a class="l" name="578" href="#578">578</a>	<b>public</b> <b>void</b> <a class="xmt" name="skipEndObject"/><a href="/source/s?refs=skipEndObject&amp;project=rtmp_client" class="xmt">skipEndObject</a>() {
<a class="l" name="579" href="#579">579</a>		<span class="c">// skip two marker bytes</span>
<a class="hl" name="580" href="#580">580</a>		<span class="c">// then end of object byte</span>
<a class="l" name="581" href="#581">581</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=skip&amp;project=rtmp_client">skip</a>(<span class="n">3</span>);
<a class="l" name="582" href="#582">582</a>	}
<a class="l" name="583" href="#583">583</a>
<a class="l" name="584" href="#584">584</a>	<span class="c">// Others</span>
<a class="l" name="585" href="#585">585</a>	<span class="c">/**
<a class="l" name="586" href="#586">586</a>	 * Reads XML
<a class="l" name="587" href="#587">587</a>	 *
<a class="l" name="588" href="#588">588</a>	 * <strong>@return</strong> String       XML as string
<a class="l" name="589" href="#589">589</a>	 */</span>
<a class="hl" name="590" href="#590">590</a>	<b>public</b> <a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a> <a class="xmt" name="readXML"/><a href="/source/s?refs=readXML&amp;project=rtmp_client" class="xmt">readXML</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="591" href="#591">591</a>		<b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=xmlString&amp;project=rtmp_client">xmlString</a> = <a class="d" href="#readString">readString</a>(<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>);
<a class="l" name="592" href="#592">592</a>		<a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a> <a href="/source/s?defs=doc&amp;project=rtmp_client">doc</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="593" href="#593">593</a>		<b>try</b> {
<a class="l" name="594" href="#594">594</a>			<a href="/source/s?defs=doc&amp;project=rtmp_client">doc</a> = <a href="/source/s?defs=XMLUtils&amp;project=rtmp_client">XMLUtils</a>.<a href="/source/s?defs=stringToDoc&amp;project=rtmp_client">stringToDoc</a>(<a href="/source/s?defs=xmlString&amp;project=rtmp_client">xmlString</a>);
<a class="l" name="595" href="#595">595</a>		} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> <a href="/source/s?defs=ioex&amp;project=rtmp_client">ioex</a>) {
<a class="l" name="596" href="#596">596</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"IOException converting xml to dom"</span>, <a href="/source/s?defs=ioex&amp;project=rtmp_client">ioex</a>);
<a class="l" name="597" href="#597">597</a>		}
<a class="l" name="598" href="#598">598</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=doc&amp;project=rtmp_client">doc</a>);
<a class="l" name="599" href="#599">599</a>		<b>return</b> <a href="/source/s?defs=doc&amp;project=rtmp_client">doc</a>;
<a class="hl" name="600" href="#600">600</a>	}
<a class="l" name="601" href="#601">601</a>
<a class="l" name="602" href="#602">602</a>	<span class="c">/**
<a class="l" name="603" href="#603">603</a>	 * Reads Custom
<a class="l" name="604" href="#604">604</a>	 *
<a class="l" name="605" href="#605">605</a>	 * <strong>@return</strong> Object       Custom type object
<a class="l" name="606" href="#606">606</a>	 */</span>
<a class="l" name="607" href="#607">607</a>	<b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="readCustom"/><a href="/source/s?refs=readCustom&amp;project=rtmp_client" class="xmt">readCustom</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="608" href="#608">608</a>		<span class="c">// Return null for now</span>
<a class="l" name="609" href="#609">609</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="hl" name="610" href="#610">610</a>	}
<a class="l" name="611" href="#611">611</a>
<a class="l" name="612" href="#612">612</a>	<span class="c">/**
<a class="l" name="613" href="#613">613</a>	 * Read ByteArray object. This is not supported by the AMF0 deserializer.
<a class="l" name="614" href="#614">614</a>	 *
<a class="l" name="615" href="#615">615</a>	 * <strong>@return</strong>	ByteArray object
<a class="l" name="616" href="#616">616</a>	 */</span>
<a class="l" name="617" href="#617">617</a>	<b>public</b> <a href="/source/s?defs=ByteArray&amp;project=rtmp_client">ByteArray</a> <a class="xmt" name="readByteArray"/><a href="/source/s?refs=readByteArray&amp;project=rtmp_client" class="xmt">readByteArray</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="618" href="#618">618</a>		<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"ByteArray objects not supported with AMF0"</span>);
<a class="l" name="619" href="#619">619</a>	}
<a class="hl" name="620" href="#620">620</a>
<a class="l" name="621" href="#621">621</a>	<span class="c">/**
<a class="l" name="622" href="#622">622</a>	 * Read Vector&lt;int&gt; object. This is not supported by the AMF0 deserializer.
<a class="l" name="623" href="#623">623</a>	 *
<a class="l" name="624" href="#624">624</a>	 * <strong>@return</strong>	List&lt;Integer&gt; object
<a class="l" name="625" href="#625">625</a>	 */</span>
<a class="l" name="626" href="#626">626</a>	<b>public</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt; <a class="xmt" name="readVectorInt"/><a href="/source/s?refs=readVectorInt&amp;project=rtmp_client" class="xmt">readVectorInt</a>() {
<a class="l" name="627" href="#627">627</a>		<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"Vector objects not supported with AMF0"</span>);
<a class="l" name="628" href="#628">628</a>	}
<a class="l" name="629" href="#629">629</a>
<a class="hl" name="630" href="#630">630</a>	<span class="c">/**
<a class="l" name="631" href="#631">631</a>	 * Read Vector&lt;Long&gt; object. This is not supported by the AMF0 deserializer.
<a class="l" name="632" href="#632">632</a>	 *
<a class="l" name="633" href="#633">633</a>	 * <strong>@return</strong>	List&lt;Long&gt; object
<a class="l" name="634" href="#634">634</a>	 */</span>
<a class="l" name="635" href="#635">635</a>	<b>public</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt; <a class="xmt" name="readVectorUInt"/><a href="/source/s?refs=readVectorUInt&amp;project=rtmp_client" class="xmt">readVectorUInt</a>() {
<a class="l" name="636" href="#636">636</a>		<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"Vector objects not supported with AMF0"</span>);
<a class="l" name="637" href="#637">637</a>	}
<a class="l" name="638" href="#638">638</a>
<a class="l" name="639" href="#639">639</a>	<span class="c">/**
<a class="hl" name="640" href="#640">640</a>	 * Read Vector&lt;Number&gt; object. This is not supported by the AMF0 deserializer.
<a class="l" name="641" href="#641">641</a>	 *
<a class="l" name="642" href="#642">642</a>	 * <strong>@return</strong>	List&lt;Double&gt; object
<a class="l" name="643" href="#643">643</a>	 */</span>
<a class="l" name="644" href="#644">644</a>	<b>public</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>&gt; <a class="xmt" name="readVectorNumber"/><a href="/source/s?refs=readVectorNumber&amp;project=rtmp_client" class="xmt">readVectorNumber</a>() {
<a class="l" name="645" href="#645">645</a>		<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"Vector objects not supported with AMF0"</span>);
<a class="l" name="646" href="#646">646</a>	}
<a class="l" name="647" href="#647">647</a>
<a class="l" name="648" href="#648">648</a>	<span class="c">/**
<a class="l" name="649" href="#649">649</a>	 * Read Vector&lt;Object&gt; object. This is not supported by the AMF0 deserializer.
<a class="hl" name="650" href="#650">650</a>	 *
<a class="l" name="651" href="#651">651</a>	 * <strong>@return</strong>	List&lt;Object&gt; object
<a class="l" name="652" href="#652">652</a>	 */</span>
<a class="l" name="653" href="#653">653</a>	<b>public</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xmt" name="readVectorObject"/><a href="/source/s?refs=readVectorObject&amp;project=rtmp_client" class="xmt">readVectorObject</a>() {
<a class="l" name="654" href="#654">654</a>		<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"Vector objects not supported with AMF0"</span>);
<a class="l" name="655" href="#655">655</a>	}
<a class="l" name="656" href="#656">656</a>
<a class="l" name="657" href="#657">657</a>	<span class="c">/**
<a class="l" name="658" href="#658">658</a>	 * Reads Reference
<a class="l" name="659" href="#659">659</a>	 *
<a class="hl" name="660" href="#660">660</a>	 * <strong>@return</strong> Object       Read reference to object
<a class="l" name="661" href="#661">661</a>	 */</span>
<a class="l" name="662" href="#662">662</a>	<b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="readReference"/><a href="/source/s?refs=readReference&amp;project=rtmp_client" class="xmt">readReference</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="663" href="#663">663</a>		<b>return</b> <a href="/source/s?defs=getReference&amp;project=rtmp_client">getReference</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=getUnsignedShort&amp;project=rtmp_client">getUnsignedShort</a>());
<a class="l" name="664" href="#664">664</a>	}
<a class="l" name="665" href="#665">665</a>
<a class="l" name="666" href="#666">666</a>	<span class="c">/**
<a class="l" name="667" href="#667">667</a>	 * Resets map
<a class="l" name="668" href="#668">668</a>	 *
<a class="l" name="669" href="#669">669</a>	 */</span>
<a class="hl" name="670" href="#670">670</a>	<b>public</b> <b>void</b> <a class="xmt" name="reset"/><a href="/source/s?refs=reset&amp;project=rtmp_client" class="xmt">reset</a>() {
<a class="l" name="671" href="#671">671</a>		<b>this</b>.<a href="/source/s?defs=clearReferences&amp;project=rtmp_client">clearReferences</a>();
<a class="l" name="672" href="#672">672</a>	}
<a class="l" name="673" href="#673">673</a>
<a class="l" name="674" href="#674">674</a>	<b>protected</b> <a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xmt" name="getPropertyType"/><a href="/source/s?refs=getPropertyType&amp;project=rtmp_client" class="xmt">getPropertyType</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="instance"/><a href="/source/s?refs=instance&amp;project=rtmp_client" class="xa">instance</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="propertyName"/><a href="/source/s?refs=propertyName&amp;project=rtmp_client" class="xa">propertyName</a>) {
<a class="l" name="675" href="#675">675</a>		<b>try</b> {
<a class="l" name="676" href="#676">676</a>			<b>if</b> (<a class="d" href="#instance">instance</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="677" href="#677">677</a>				<a href="/source/s?defs=Field&amp;project=rtmp_client">Field</a> <a href="/source/s?defs=field&amp;project=rtmp_client">field</a> = <a class="d" href="#instance">instance</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>().<a href="/source/s?defs=getField&amp;project=rtmp_client">getField</a>(<a class="d" href="#propertyName">propertyName</a>);
<a class="l" name="678" href="#678">678</a>				<b>return</b> <a href="/source/s?defs=field&amp;project=rtmp_client">field</a>.<a href="/source/s?defs=getGenericType&amp;project=rtmp_client">getGenericType</a>();
<a class="l" name="679" href="#679">679</a>			} <b>else</b> {
<a class="hl" name="680" href="#680">680</a>				<span class="c">// instance is null for anonymous class, use default type</span>
<a class="l" name="681" href="#681">681</a>			}
<a class="l" name="682" href="#682">682</a>		} <b>catch</b> (<a href="/source/s?defs=NoSuchFieldException&amp;project=rtmp_client">NoSuchFieldException</a> <a href="/source/s?defs=e1&amp;project=rtmp_client">e1</a>) {
<a class="l" name="683" href="#683">683</a>			<b>try</b> {
<a class="l" name="684" href="#684">684</a><span class="c">//				BeanUtilsBean beanUtilsBean = BeanUtilsBean.getInstance();</span>
<a class="l" name="685" href="#685">685</a><span class="c">//				PropertyUtilsBean propertyUtils = beanUtilsBean.getPropertyUtils();</span>
<a class="l" name="686" href="#686">686</a><span class="c">//				PropertyDescriptor propertyDescriptor = propertyUtils.getPropertyDescriptor(instance, propertyName);</span>
<a class="l" name="687" href="#687">687</a><span class="c">//				return propertyDescriptor.getReadMethod().getGenericReturnType();</span>
<a class="l" name="688" href="#688">688</a>			} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> <a href="/source/s?defs=e2&amp;project=rtmp_client">e2</a>) {
<a class="l" name="689" href="#689">689</a>				<span class="c">// nothing</span>
<a class="hl" name="690" href="#690">690</a>			}
<a class="l" name="691" href="#691">691</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="692" href="#692">692</a>			<span class="c">// ignore other exceptions</span>
<a class="l" name="693" href="#693">693</a>		}
<a class="l" name="694" href="#694">694</a>		<span class="c">// return Object class type by default</span>
<a class="l" name="695" href="#695">695</a>		<b>return</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>.<b>class</b>;
<a class="l" name="696" href="#696">696</a>	}
<a class="l" name="697" href="#697">697</a>}
<a class="l" name="698" href="#698">698</a>