<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["ClassReference",72],["Input",65],["PendingObject",98],["PendingProperty",100],["RefStorage",147]]],["Package","xp",[["org.red5.io.amf3",1]]],["Method","xmt",[["ClassReference",87],["Input",180],["Input",193],["PendingProperty",107],["addPendingProperty",116],["enforceAMF3",204],["getBuffer",213],["getString",410],["readAMF3Integer",942],["readAMF3IntegerNew",973],["readArray",441],["readBoolean",322],["readByteArray",805],["readCustom",916],["readDataType",223],["readDate",420],["readMap",550],["readNull",312],["readNumber",333],["readObject",557],["readReference",922],["readString",359],["readString",394],["readVectorInt",819],["readVectorNumber",865],["readVectorObject",886],["readVectorUInt",840],["readXML",994],["reset",930],["resolveProperties",123]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=lang&amp;project=rtmp_client">lang</a>.<a href="/source/s?defs=reflect&amp;project=rtmp_client">reflect</a>.<a href="/source/s?defs=Array&amp;project=rtmp_client">Array</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=lang&amp;project=rtmp_client">lang</a>.<a href="/source/s?defs=reflect&amp;project=rtmp_client">reflect</a>.<a href="/source/s?defs=Field&amp;project=rtmp_client">Field</a>;
<a class="l" name="25" href="#25">25</a><span class="c">//import java.lang.reflect.InvocationTargetException;</span>
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=lang&amp;project=rtmp_client">lang</a>.<a href="/source/s?defs=reflect&amp;project=rtmp_client">reflect</a>.<a href="/source/s?defs=ParameterizedType&amp;project=rtmp_client">ParameterizedType</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=lang&amp;project=rtmp_client">lang</a>.<a href="/source/s?defs=reflect&amp;project=rtmp_client">reflect</a>.<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Collection&amp;project=rtmp_client">Collection</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Date&amp;project=rtmp_client">Date</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>;
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashSet&amp;project=rtmp_client">HashSet</a>;
<a class="l" name="34" href="#34">34</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=LinkedList&amp;project=rtmp_client">LinkedList</a>;
<a class="l" name="35" href="#35">35</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>;
<a class="l" name="36" href="#36">36</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="37" href="#37">37</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>;
<a class="l" name="38" href="#38">38</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=SortedMap&amp;project=rtmp_client">SortedMap</a>;
<a class="l" name="39" href="#39">39</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=SortedSet&amp;project=rtmp_client">SortedSet</a>;
<a class="hl" name="40" href="#40">40</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=TreeMap&amp;project=rtmp_client">TreeMap</a>;
<a class="l" name="41" href="#41">41</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=TreeSet&amp;project=rtmp_client">TreeSet</a>;
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a><span class="c">//import org.apache.commons.beanutils.BeanUtils;</span>
<a class="l" name="44" href="#44">44</a><span class="c">//import org.apache.commons.beanutils.BeanUtilsBean;</span>
<a class="l" name="45" href="#45">45</a><span class="c">//import org.apache.commons.beanutils.ConvertUtilsBean;</span>
<a class="l" name="46" href="#46">46</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="47" href="#47">47</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>;
<a class="l" name="48" href="#48">48</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>;
<a class="l" name="49" href="#49">49</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a>;
<a class="hl" name="50" href="#50">50</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>.<a href="/source/s?defs=ArrayUtils&amp;project=rtmp_client">ArrayUtils</a>;
<a class="l" name="51" href="#51">51</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>.<a href="/source/s?defs=ObjectMap&amp;project=rtmp_client">ObjectMap</a>;
<a class="l" name="52" href="#52">52</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>.<a href="/source/s?defs=XMLUtils&amp;project=rtmp_client">XMLUtils</a>;
<a class="l" name="53" href="#53">53</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=ConversionUtils&amp;project=rtmp_client">ConversionUtils</a>;
<a class="l" name="54" href="#54">54</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="55" href="#55">55</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="56" href="#56">56</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=w3c&amp;project=rtmp_client">w3c</a>.<a href="/source/s?defs=dom&amp;project=rtmp_client">dom</a>.<a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a>;
<a class="l" name="57" href="#57">57</a>
<a class="l" name="58" href="#58">58</a><span class="c">/**
<a class="l" name="59" href="#59">59</a> * Input for Red5 data (AMF3) types
<a class="hl" name="60" href="#60">60</a> *
<a class="l" name="61" href="#61">61</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="62" href="#62">62</a> * <strong>@author</strong> Luke Hubbard, Codegent Ltd (luke@codegent.com)
<a class="l" name="63" href="#63">63</a> * <strong>@author</strong> Joachim Bauch (jojo@struktur.de)
<a class="l" name="64" href="#64">64</a> */</span>
<a class="l" name="65" href="#65">65</a><b>public</b> <b>class</b> <a class="xc" name="Input"/><a href="/source/s?refs=Input&amp;project=rtmp_client" class="xc">Input</a> <b>extends</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a class="xc" name="Input"/><a href="/source/s?refs=Input&amp;project=rtmp_client" class="xc">Input</a> <b>implements</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a class="xc" name="Input"/><a href="/source/s?refs=Input&amp;project=rtmp_client" class="xc">Input</a> {
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a><span class="c">//	private static ConvertUtilsBean convertUtilsBean = BeanUtilsBean.getInstance().getConvertUtils();</span>
<a class="l" name="68" href="#68">68</a>
<a class="l" name="69" href="#69">69</a>	<span class="c">/**
<a class="hl" name="70" href="#70">70</a>	 * Holds informations about already deserialized classes.
<a class="l" name="71" href="#71">71</a>	 */</span>
<a class="l" name="72" href="#72">72</a>	<b>protected</b> <b>static</b> <b>class</b> <a class="xc" name="ClassReference"/><a href="/source/s?refs=ClassReference&amp;project=rtmp_client" class="xc">ClassReference</a> {
<a class="l" name="73" href="#73">73</a>		<span class="c">/** Name of the deserialized class. */</span>
<a class="l" name="74" href="#74">74</a>		<b>protected</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="className"/><a href="/source/s?refs=className&amp;project=rtmp_client" class="xfld">className</a>;
<a class="l" name="75" href="#75">75</a>
<a class="l" name="76" href="#76">76</a>		<span class="c">/** Type of the class. */</span>
<a class="l" name="77" href="#77">77</a>		<b>protected</b> <b>int</b> <a class="xfld" name="type"/><a href="/source/s?refs=type&amp;project=rtmp_client" class="xfld">type</a>;
<a class="l" name="78" href="#78">78</a>
<a class="l" name="79" href="#79">79</a>		<span class="c">/** Names of the attributes of the class. */</span>
<a class="hl" name="80" href="#80">80</a>		<b>protected</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt; <a class="xfld" name="attributeNames"/><a href="/source/s?refs=attributeNames&amp;project=rtmp_client" class="xfld">attributeNames</a>;
<a class="l" name="81" href="#81">81</a>
<a class="l" name="82" href="#82">82</a>		<span class="c">/** Create new informations about a class.
<a class="l" name="83" href="#83">83</a>		 * <strong>@param</strong> <em>className</em> class name
<a class="l" name="84" href="#84">84</a>		 * <strong>@param</strong> <em>type</em> type
<a class="l" name="85" href="#85">85</a>		 * <strong>@param</strong> <em>attributeNames</em> attributes
<a class="l" name="86" href="#86">86</a>		 */</span>
<a class="l" name="87" href="#87">87</a>		<b>public</b> <a class="xmt" name="ClassReference"/><a href="/source/s?refs=ClassReference&amp;project=rtmp_client" class="xmt">ClassReference</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="className"/><a href="/source/s?refs=className&amp;project=rtmp_client" class="xa">className</a>, <b>int</b> <a class="xa" name="type"/><a href="/source/s?refs=type&amp;project=rtmp_client" class="xa">type</a>, <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt; <a class="xa" name="attributeNames"/><a href="/source/s?refs=attributeNames&amp;project=rtmp_client" class="xa">attributeNames</a>) {
<a class="l" name="88" href="#88">88</a>			<b>this</b>.<a href="/source/s?defs=className&amp;project=rtmp_client">className</a> = <a href="/source/s?defs=className&amp;project=rtmp_client">className</a>;
<a class="l" name="89" href="#89">89</a>			<b>this</b>.<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <a href="/source/s?defs=type&amp;project=rtmp_client">type</a>;
<a class="hl" name="90" href="#90">90</a>			<b>this</b>.<a href="/source/s?defs=attributeNames&amp;project=rtmp_client">attributeNames</a> = <a href="/source/s?defs=attributeNames&amp;project=rtmp_client">attributeNames</a>;
<a class="l" name="91" href="#91">91</a>		}
<a class="l" name="92" href="#92">92</a>	}
<a class="l" name="93" href="#93">93</a>
<a class="l" name="94" href="#94">94</a>	<span class="c">/**
<a class="l" name="95" href="#95">95</a>	 * Dummy class that is stored as reference for objects currently
<a class="l" name="96" href="#96">96</a>	 * being deserialized that reference themselves.
<a class="l" name="97" href="#97">97</a>	 */</span>
<a class="l" name="98" href="#98">98</a>	<b>protected</b> <b>static</b> <b>class</b> <a class="xc" name="PendingObject"/><a href="/source/s?refs=PendingObject&amp;project=rtmp_client" class="xc">PendingObject</a> {
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a>		<b>static</b> <b>final</b> <b>class</b> <a class="xc" name="PendingProperty"/><a href="/source/s?refs=PendingProperty&amp;project=rtmp_client" class="xc">PendingProperty</a> {
<a class="l" name="101" href="#101">101</a>			<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xfld" name="obj"/><a href="/source/s?refs=obj&amp;project=rtmp_client" class="xfld">obj</a>;
<a class="l" name="102" href="#102">102</a>
<a class="l" name="103" href="#103">103</a>			<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a class="xfld" name="klass"/><a href="/source/s?refs=klass&amp;project=rtmp_client" class="xfld">klass</a>;
<a class="l" name="104" href="#104">104</a>
<a class="l" name="105" href="#105">105</a>			<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xfld">name</a>;
<a class="l" name="106" href="#106">106</a>
<a class="l" name="107" href="#107">107</a>			<a class="xmt" name="PendingProperty"/><a href="/source/s?refs=PendingProperty&amp;project=rtmp_client" class="xmt">PendingProperty</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="obj"/><a href="/source/s?refs=obj&amp;project=rtmp_client" class="xa">obj</a>, <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a class="xa" name="klass"/><a href="/source/s?refs=klass&amp;project=rtmp_client" class="xa">klass</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="l" name="108" href="#108">108</a>				<b>this</b>.<a href="/source/s?defs=obj&amp;project=rtmp_client">obj</a> = <a href="/source/s?defs=obj&amp;project=rtmp_client">obj</a>;
<a class="l" name="109" href="#109">109</a>				<b>this</b>.<a href="/source/s?defs=klass&amp;project=rtmp_client">klass</a> = <a href="/source/s?defs=klass&amp;project=rtmp_client">klass</a>;
<a class="hl" name="110" href="#110">110</a>				<b>this</b>.<a href="/source/s?defs=name&amp;project=rtmp_client">name</a> = <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>;
<a class="l" name="111" href="#111">111</a>			}
<a class="l" name="112" href="#112">112</a>		}
<a class="l" name="113" href="#113">113</a>
<a class="l" name="114" href="#114">114</a>		<b>private</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=PendingProperty&amp;project=rtmp_client">PendingProperty</a>&gt; <a class="xfld" name="properties"/><a href="/source/s?refs=properties&amp;project=rtmp_client" class="xfld">properties</a>;
<a class="l" name="115" href="#115">115</a>
<a class="l" name="116" href="#116">116</a>		<b>public</b> <b>void</b> <a class="xmt" name="addPendingProperty"/><a href="/source/s?refs=addPendingProperty&amp;project=rtmp_client" class="xmt">addPendingProperty</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="obj"/><a href="/source/s?refs=obj&amp;project=rtmp_client" class="xa">obj</a>, <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a class="xa" name="klass"/><a href="/source/s?refs=klass&amp;project=rtmp_client" class="xa">klass</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="l" name="117" href="#117">117</a>			<b>if</b> (<a class="d" href="#properties">properties</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="118" href="#118">118</a>				<a class="d" href="#properties">properties</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=PendingProperty&amp;project=rtmp_client">PendingProperty</a>&gt;();
<a class="l" name="119" href="#119">119</a>			}
<a class="hl" name="120" href="#120">120</a>			<a class="d" href="#properties">properties</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<b>new</b> <a href="/source/s?defs=PendingProperty&amp;project=rtmp_client">PendingProperty</a>(<a href="/source/s?defs=obj&amp;project=rtmp_client">obj</a>, <a href="/source/s?defs=klass&amp;project=rtmp_client">klass</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>));
<a class="l" name="121" href="#121">121</a>		}
<a class="l" name="122" href="#122">122</a>
<a class="l" name="123" href="#123">123</a>		<b>public</b> <b>void</b> <a class="xmt" name="resolveProperties"/><a href="/source/s?refs=resolveProperties&amp;project=rtmp_client" class="xmt">resolveProperties</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="result"/><a href="/source/s?refs=result&amp;project=rtmp_client" class="xa">result</a>) {
<a class="l" name="124" href="#124">124</a>			<b>if</b> (<a class="d" href="#properties">properties</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>)
<a class="l" name="125" href="#125">125</a>				<span class="c">// No pending properties</span>
<a class="l" name="126" href="#126">126</a>				<b>return</b>;
<a class="l" name="127" href="#127">127</a>
<a class="l" name="128" href="#128">128</a>			<b>for</b> (<a href="/source/s?defs=PendingProperty&amp;project=rtmp_client">PendingProperty</a> <a href="/source/s?defs=prop&amp;project=rtmp_client">prop</a> : <a class="d" href="#properties">properties</a>) {
<a class="l" name="129" href="#129">129</a>				<b>try</b> {
<a class="hl" name="130" href="#130">130</a>					<a href="/source/s?defs=prop&amp;project=rtmp_client">prop</a>.<a href="/source/s?defs=klass&amp;project=rtmp_client">klass</a>.<a href="/source/s?defs=getField&amp;project=rtmp_client">getField</a>(<a href="/source/s?defs=prop&amp;project=rtmp_client">prop</a>.<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>).<a href="/source/s?defs=set&amp;project=rtmp_client">set</a>(<a href="/source/s?defs=prop&amp;project=rtmp_client">prop</a>.<a href="/source/s?defs=obj&amp;project=rtmp_client">obj</a>, <a class="d" href="#result">result</a>);
<a class="l" name="131" href="#131">131</a>				} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="132" href="#132">132</a>					<b>try</b> {
<a class="l" name="133" href="#133">133</a><span class="c">//						BeanUtils.setProperty(prop.obj, prop.name, result);</span>
<a class="l" name="134" href="#134">134</a>					} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> <a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>) {
<a class="l" name="135" href="#135">135</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error mapping property: {} ({})"</span>, <a href="/source/s?defs=prop&amp;project=rtmp_client">prop</a>.<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a class="d" href="#result">result</a>);
<a class="l" name="136" href="#136">136</a>					}
<a class="l" name="137" href="#137">137</a>				}
<a class="l" name="138" href="#138">138</a>			}
<a class="l" name="139" href="#139">139</a>			<a class="d" href="#properties">properties</a>.<a href="/source/s?defs=clear&amp;project=rtmp_client">clear</a>();
<a class="hl" name="140" href="#140">140</a>		}
<a class="l" name="141" href="#141">141</a>	}
<a class="l" name="142" href="#142">142</a>
<a class="l" name="143" href="#143">143</a>	<span class="c">/**
<a class="l" name="144" href="#144">144</a>	 * Class used to collect AMF3 references.
<a class="l" name="145" href="#145">145</a>	 * In AMF3 references should be collected through the whole "body" (across several Input objects).
<a class="l" name="146" href="#146">146</a>	 */</span>
<a class="l" name="147" href="#147">147</a>	<b>public</b> <b>static</b> <b>class</b> <a class="xc" name="RefStorage"/><a href="/source/s?refs=RefStorage&amp;project=rtmp_client" class="xc">RefStorage</a> {
<a class="l" name="148" href="#148">148</a>		<b>private</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=ClassReference&amp;project=rtmp_client">ClassReference</a>&gt; <a class="xfld" name="classReferences"/><a href="/source/s?refs=classReferences&amp;project=rtmp_client" class="xfld">classReferences</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=ClassReference&amp;project=rtmp_client">ClassReference</a>&gt;();
<a class="l" name="149" href="#149">149</a>
<a class="hl" name="150" href="#150">150</a>		<b>private</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt; <a class="xfld" name="stringReferences"/><a href="/source/s?refs=stringReferences&amp;project=rtmp_client" class="xfld">stringReferences</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt;();
<a class="l" name="151" href="#151">151</a>
<a class="l" name="152" href="#152">152</a>		<b>private</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xfld" name="refMap"/><a href="/source/s?refs=refMap&amp;project=rtmp_client" class="xfld">refMap</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="l" name="153" href="#153">153</a>	}
<a class="l" name="154" href="#154">154</a>
<a class="l" name="155" href="#155">155</a>	<span class="c">/**
<a class="l" name="156" href="#156">156</a>	 * Logger
<a class="l" name="157" href="#157">157</a>	 */</span>
<a class="l" name="158" href="#158">158</a>	<b>protected</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>.<b>class</b>);
<a class="l" name="159" href="#159">159</a>
<a class="hl" name="160" href="#160">160</a>	<span class="c">/**
<a class="l" name="161" href="#161">161</a>	 * Set to a value above &lt;tt&gt;0&lt;/tt&gt; to enforce AMF3 decoding mode.
<a class="l" name="162" href="#162">162</a>	 */</span>
<a class="l" name="163" href="#163">163</a>	<b>private</b> <b>int</b> <a class="xfld" name="amf3_mode"/><a href="/source/s?refs=amf3_mode&amp;project=rtmp_client" class="xfld">amf3_mode</a>;
<a class="l" name="164" href="#164">164</a>
<a class="l" name="165" href="#165">165</a>	<span class="c">/**
<a class="l" name="166" href="#166">166</a>	 * List of string values found in the input stream.
<a class="l" name="167" href="#167">167</a>	 */</span>
<a class="l" name="168" href="#168">168</a>	<b>private</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt; <a class="xfld" name="stringReferences"/><a href="/source/s?refs=stringReferences&amp;project=rtmp_client" class="xfld">stringReferences</a>;
<a class="l" name="169" href="#169">169</a>
<a class="hl" name="170" href="#170">170</a>	<span class="c">/**
<a class="l" name="171" href="#171">171</a>	 * Informations about already deserialized classes.
<a class="l" name="172" href="#172">172</a>	 */</span>
<a class="l" name="173" href="#173">173</a>	<b>private</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=ClassReference&amp;project=rtmp_client">ClassReference</a>&gt; <a class="xfld" name="classReferences"/><a href="/source/s?refs=classReferences&amp;project=rtmp_client" class="xfld">classReferences</a>;
<a class="l" name="174" href="#174">174</a>
<a class="l" name="175" href="#175">175</a>	<span class="c">/**
<a class="l" name="176" href="#176">176</a>	 * Creates Input object for AMF3 from byte buffer
<a class="l" name="177" href="#177">177</a>	 *
<a class="l" name="178" href="#178">178</a>	 * <strong>@param</strong> <em>buf</em>        Byte buffer
<a class="l" name="179" href="#179">179</a>	 */</span>
<a class="hl" name="180" href="#180">180</a>	<b>public</b> <a class="xmt" name="Input"/><a href="/source/s?refs=Input&amp;project=rtmp_client" class="xmt">Input</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="buf"/><a href="/source/s?refs=buf&amp;project=rtmp_client" class="xa">buf</a>) {
<a class="l" name="181" href="#181">181</a>		<b>super</b>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="182" href="#182">182</a>		<a class="d" href="#amf3_mode">amf3_mode</a> = <span class="n">0</span>;
<a class="l" name="183" href="#183">183</a>		<a href="/source/s?defs=stringReferences&amp;project=rtmp_client">stringReferences</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt;();
<a class="l" name="184" href="#184">184</a>		<a href="/source/s?defs=classReferences&amp;project=rtmp_client">classReferences</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=ClassReference&amp;project=rtmp_client">ClassReference</a>&gt;();
<a class="l" name="185" href="#185">185</a>	}
<a class="l" name="186" href="#186">186</a>
<a class="l" name="187" href="#187">187</a>	<span class="c">/**
<a class="l" name="188" href="#188">188</a>	 * Creates Input object for AMF3 from byte buffer and initializes references
<a class="l" name="189" href="#189">189</a>	 * from passed RefStorage
<a class="hl" name="190" href="#190">190</a>	 * <strong>@param</strong> <em>buf</em> buffer
<a class="l" name="191" href="#191">191</a>	 * <strong>@param</strong> <em>refStorage</em> ref storage
<a class="l" name="192" href="#192">192</a>	 */</span>
<a class="l" name="193" href="#193">193</a>	<b>public</b> <a class="xmt" name="Input"/><a href="/source/s?refs=Input&amp;project=rtmp_client" class="xmt">Input</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="buf"/><a href="/source/s?refs=buf&amp;project=rtmp_client" class="xa">buf</a>, <a class="d" href="#RefStorage">RefStorage</a> <a class="xa" name="refStorage"/><a href="/source/s?refs=refStorage&amp;project=rtmp_client" class="xa">refStorage</a>) {
<a class="l" name="194" href="#194">194</a>		<b>super</b>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="195" href="#195">195</a>		<b>this</b>.<a href="/source/s?defs=stringReferences&amp;project=rtmp_client">stringReferences</a> = <a class="d" href="#refStorage">refStorage</a>.<a href="/source/s?defs=stringReferences&amp;project=rtmp_client">stringReferences</a>;
<a class="l" name="196" href="#196">196</a>		<b>this</b>.<a href="/source/s?defs=classReferences&amp;project=rtmp_client">classReferences</a> = <a class="d" href="#refStorage">refStorage</a>.<a href="/source/s?defs=classReferences&amp;project=rtmp_client">classReferences</a>;
<a class="l" name="197" href="#197">197</a>		<b>this</b>.<a class="d" href="#refMap">refMap</a> = <a class="d" href="#refStorage">refStorage</a>.<a class="d" href="#refMap">refMap</a>;
<a class="l" name="198" href="#198">198</a>		<a class="d" href="#amf3_mode">amf3_mode</a> = <span class="n">0</span>;
<a class="l" name="199" href="#199">199</a>	}
<a class="hl" name="200" href="#200">200</a>
<a class="l" name="201" href="#201">201</a>	<span class="c">/**
<a class="l" name="202" href="#202">202</a>	 * Force using AMF3 everywhere
<a class="l" name="203" href="#203">203</a>	 */</span>
<a class="l" name="204" href="#204">204</a>	<b>public</b> <b>void</b> <a class="xmt" name="enforceAMF3"/><a href="/source/s?refs=enforceAMF3&amp;project=rtmp_client" class="xmt">enforceAMF3</a>() {
<a class="l" name="205" href="#205">205</a>		<a class="d" href="#amf3_mode">amf3_mode</a>++;
<a class="l" name="206" href="#206">206</a>	}
<a class="l" name="207" href="#207">207</a>
<a class="l" name="208" href="#208">208</a>	<span class="c">/**
<a class="l" name="209" href="#209">209</a>	 * Provide access to raw data.
<a class="hl" name="210" href="#210">210</a>	 *
<a class="l" name="211" href="#211">211</a>	 * <strong>@return</strong> IoBuffer
<a class="l" name="212" href="#212">212</a>	 */</span>
<a class="l" name="213" href="#213">213</a>	<b>protected</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="getBuffer"/><a href="/source/s?refs=getBuffer&amp;project=rtmp_client" class="xmt">getBuffer</a>() {
<a class="l" name="214" href="#214">214</a>		<b>return</b> <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>;
<a class="l" name="215" href="#215">215</a>	}
<a class="l" name="216" href="#216">216</a>
<a class="l" name="217" href="#217">217</a>	<span class="c">/**
<a class="l" name="218" href="#218">218</a>	 * Reads the data type
<a class="l" name="219" href="#219">219</a>	 *
<a class="hl" name="220" href="#220">220</a>	 * <strong>@return</strong> byte      Data type
<a class="l" name="221" href="#221">221</a>	 */</span>
<a class="l" name="222" href="#222">222</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="223" href="#223">223</a>	<b>public</b> <b>byte</b> <a class="xmt" name="readDataType"/><a href="/source/s?refs=readDataType&amp;project=rtmp_client" class="xmt">readDataType</a>() {
<a class="l" name="224" href="#224">224</a>		<b>byte</b> <a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_UNDEFINED&amp;project=rtmp_client">TYPE_UNDEFINED</a>;
<a class="l" name="225" href="#225">225</a>		<b>if</b> (<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="226" href="#226">226</a>			<a href="/source/s?defs=currentDataType&amp;project=rtmp_client">currentDataType</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="227" href="#227">227</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Current data type: {}"</span>, <a href="/source/s?defs=currentDataType&amp;project=rtmp_client">currentDataType</a>);
<a class="l" name="228" href="#228">228</a>
<a class="l" name="229" href="#229">229</a>			<b>if</b> (<a href="/source/s?defs=currentDataType&amp;project=rtmp_client">currentDataType</a> == <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_AMF3_OBJECT&amp;project=rtmp_client">TYPE_AMF3_OBJECT</a>) {
<a class="hl" name="230" href="#230">230</a>				<a href="/source/s?defs=currentDataType&amp;project=rtmp_client">currentDataType</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="231" href="#231">231</a>			} <b>else</b> <b>if</b> (<a class="d" href="#amf3_mode">amf3_mode</a> == <span class="n">0</span>) {
<a class="l" name="232" href="#232">232</a>				<span class="c">// AMF0 object</span>
<a class="l" name="233" href="#233">233</a>				<b>return</b> <a class="d" href="#readDataType">readDataType</a>(<a href="/source/s?defs=currentDataType&amp;project=rtmp_client">currentDataType</a>);
<a class="l" name="234" href="#234">234</a>			}
<a class="l" name="235" href="#235">235</a>
<a class="l" name="236" href="#236">236</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Current data type (after amf checks): {}"</span>, <a href="/source/s?defs=currentDataType&amp;project=rtmp_client">currentDataType</a>);
<a class="l" name="237" href="#237">237</a>
<a class="l" name="238" href="#238">238</a>			<b>switch</b> (<a href="/source/s?defs=currentDataType&amp;project=rtmp_client">currentDataType</a>) {
<a class="l" name="239" href="#239">239</a>				<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_UNDEFINED&amp;project=rtmp_client">TYPE_UNDEFINED</a>:
<a class="hl" name="240" href="#240">240</a>				<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_NULL&amp;project=rtmp_client">TYPE_NULL</a>:
<a class="l" name="241" href="#241">241</a>					<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_NULL&amp;project=rtmp_client">CORE_NULL</a>;
<a class="l" name="242" href="#242">242</a>					<b>break</b>;
<a class="l" name="243" href="#243">243</a>				<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_INTEGER&amp;project=rtmp_client">TYPE_INTEGER</a>:
<a class="l" name="244" href="#244">244</a>				<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_NUMBER&amp;project=rtmp_client">TYPE_NUMBER</a>:
<a class="l" name="245" href="#245">245</a>					<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_NUMBER&amp;project=rtmp_client">CORE_NUMBER</a>;
<a class="l" name="246" href="#246">246</a>					<b>break</b>;
<a class="l" name="247" href="#247">247</a>
<a class="l" name="248" href="#248">248</a>				<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_BOOLEAN_TRUE&amp;project=rtmp_client">TYPE_BOOLEAN_TRUE</a>:
<a class="l" name="249" href="#249">249</a>				<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_BOOLEAN_FALSE&amp;project=rtmp_client">TYPE_BOOLEAN_FALSE</a>:
<a class="hl" name="250" href="#250">250</a>					<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_BOOLEAN&amp;project=rtmp_client">CORE_BOOLEAN</a>;
<a class="l" name="251" href="#251">251</a>					<b>break</b>;
<a class="l" name="252" href="#252">252</a>
<a class="l" name="253" href="#253">253</a>				<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_STRING&amp;project=rtmp_client">TYPE_STRING</a>:
<a class="l" name="254" href="#254">254</a>					<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_STRING&amp;project=rtmp_client">CORE_STRING</a>;
<a class="l" name="255" href="#255">255</a>					<b>break</b>;
<a class="l" name="256" href="#256">256</a>				<span class="c">// TODO check XML_SPECIAL</span>
<a class="l" name="257" href="#257">257</a>				<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_XML&amp;project=rtmp_client">TYPE_XML</a>:
<a class="l" name="258" href="#258">258</a>				<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_XML_DOCUMENT&amp;project=rtmp_client">TYPE_XML_DOCUMENT</a>:
<a class="l" name="259" href="#259">259</a>					<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_XML&amp;project=rtmp_client">CORE_XML</a>;
<a class="hl" name="260" href="#260">260</a>					<b>break</b>;
<a class="l" name="261" href="#261">261</a>				<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_OBJECT&amp;project=rtmp_client">TYPE_OBJECT</a>:
<a class="l" name="262" href="#262">262</a>					<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_OBJECT&amp;project=rtmp_client">CORE_OBJECT</a>;
<a class="l" name="263" href="#263">263</a>					<b>break</b>;
<a class="l" name="264" href="#264">264</a>
<a class="l" name="265" href="#265">265</a>				<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_ARRAY&amp;project=rtmp_client">TYPE_ARRAY</a>:
<a class="l" name="266" href="#266">266</a>					<span class="c">// should we map this to list or array?</span>
<a class="l" name="267" href="#267">267</a>					<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_ARRAY&amp;project=rtmp_client">CORE_ARRAY</a>;
<a class="l" name="268" href="#268">268</a>					<b>break</b>;
<a class="l" name="269" href="#269">269</a>
<a class="hl" name="270" href="#270">270</a>				<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_DATE&amp;project=rtmp_client">TYPE_DATE</a>:
<a class="l" name="271" href="#271">271</a>					<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_DATE&amp;project=rtmp_client">CORE_DATE</a>;
<a class="l" name="272" href="#272">272</a>					<b>break</b>;
<a class="l" name="273" href="#273">273</a>
<a class="l" name="274" href="#274">274</a>				<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_BYTEARRAY&amp;project=rtmp_client">TYPE_BYTEARRAY</a>:
<a class="l" name="275" href="#275">275</a>					<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_BYTEARRAY&amp;project=rtmp_client">CORE_BYTEARRAY</a>;
<a class="l" name="276" href="#276">276</a>					<b>break</b>;
<a class="l" name="277" href="#277">277</a>
<a class="l" name="278" href="#278">278</a>				<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_VECTOR_INT&amp;project=rtmp_client">TYPE_VECTOR_INT</a>:
<a class="l" name="279" href="#279">279</a>					<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_VECTOR_INT&amp;project=rtmp_client">CORE_VECTOR_INT</a>;
<a class="hl" name="280" href="#280">280</a>					<b>break</b>;
<a class="l" name="281" href="#281">281</a>				<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_VECTOR_UINT&amp;project=rtmp_client">TYPE_VECTOR_UINT</a>:
<a class="l" name="282" href="#282">282</a>					<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_VECTOR_UINT&amp;project=rtmp_client">CORE_VECTOR_UINT</a>;
<a class="l" name="283" href="#283">283</a>					<b>break</b>;
<a class="l" name="284" href="#284">284</a>				<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_VECTOR_NUMBER&amp;project=rtmp_client">TYPE_VECTOR_NUMBER</a>:
<a class="l" name="285" href="#285">285</a>					<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_VECTOR_NUMBER&amp;project=rtmp_client">CORE_VECTOR_NUMBER</a>;
<a class="l" name="286" href="#286">286</a>					<b>break</b>;
<a class="l" name="287" href="#287">287</a>				<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_VECTOR_OBJECT&amp;project=rtmp_client">TYPE_VECTOR_OBJECT</a>:
<a class="l" name="288" href="#288">288</a>					<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_VECTOR_OBJECT&amp;project=rtmp_client">CORE_VECTOR_OBJECT</a>;
<a class="l" name="289" href="#289">289</a>					<b>break</b>;
<a class="hl" name="290" href="#290">290</a>
<a class="l" name="291" href="#291">291</a>				<b>default</b>:
<a class="l" name="292" href="#292">292</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"Unknown datatype: {}"</span>, <a href="/source/s?defs=currentDataType&amp;project=rtmp_client">currentDataType</a>);
<a class="l" name="293" href="#293">293</a>					<span class="c">// End of object, and anything else lets just skip</span>
<a class="l" name="294" href="#294">294</a>					<a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a> = <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_SKIP&amp;project=rtmp_client">CORE_SKIP</a>;
<a class="l" name="295" href="#295">295</a>					<b>break</b>;
<a class="l" name="296" href="#296">296</a>			}
<a class="l" name="297" href="#297">297</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Core type: {}"</span>, <a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a>);
<a class="l" name="298" href="#298">298</a>		} <b>else</b> {
<a class="l" name="299" href="#299">299</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Why is buf null?"</span>);
<a class="hl" name="300" href="#300">300</a>		}
<a class="l" name="301" href="#301">301</a>		<b>return</b> <a href="/source/s?defs=coreType&amp;project=rtmp_client">coreType</a>;
<a class="l" name="302" href="#302">302</a>	}
<a class="l" name="303" href="#303">303</a>
<a class="l" name="304" href="#304">304</a>	<span class="c">// Basic</span>
<a class="l" name="305" href="#305">305</a>
<a class="l" name="306" href="#306">306</a>	<span class="c">/**
<a class="l" name="307" href="#307">307</a>	 * Reads a null (value)
<a class="l" name="308" href="#308">308</a>	 *
<a class="l" name="309" href="#309">309</a>	 * <strong>@return</strong> Object    null
<a class="hl" name="310" href="#310">310</a>	 */</span>
<a class="l" name="311" href="#311">311</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="312" href="#312">312</a>	<b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="readNull"/><a href="/source/s?refs=readNull&amp;project=rtmp_client" class="xmt">readNull</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="313" href="#313">313</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="314" href="#314">314</a>	}
<a class="l" name="315" href="#315">315</a>
<a class="l" name="316" href="#316">316</a>	<span class="c">/**
<a class="l" name="317" href="#317">317</a>	 * Reads a boolean
<a class="l" name="318" href="#318">318</a>	 *
<a class="l" name="319" href="#319">319</a>	 * <strong>@return</strong> boolean     Boolean value
<a class="hl" name="320" href="#320">320</a>	 */</span>
<a class="l" name="321" href="#321">321</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="322" href="#322">322</a>	<b>public</b> <a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a> <a class="xmt" name="readBoolean"/><a href="/source/s?refs=readBoolean&amp;project=rtmp_client" class="xmt">readBoolean</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="323" href="#323">323</a>		<b>return</b> (<a href="/source/s?defs=currentDataType&amp;project=rtmp_client">currentDataType</a> == <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_BOOLEAN_TRUE&amp;project=rtmp_client">TYPE_BOOLEAN_TRUE</a>) ? <a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a>.<a href="/source/s?defs=TRUE&amp;project=rtmp_client">TRUE</a> : <a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a>.<a href="/source/s?defs=FALSE&amp;project=rtmp_client">FALSE</a>;
<a class="l" name="324" href="#324">324</a>	}
<a class="l" name="325" href="#325">325</a>
<a class="l" name="326" href="#326">326</a>	<span class="c">/**
<a class="l" name="327" href="#327">327</a>	 * Reads a Number
<a class="l" name="328" href="#328">328</a>	 *
<a class="l" name="329" href="#329">329</a>	 * <strong>@return</strong> Number      Number
<a class="hl" name="330" href="#330">330</a>	 */</span>
<a class="l" name="331" href="#331">331</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>({ <span class="s">"unchecked"</span>, <span class="s">"rawtypes"</span> })
<a class="l" name="332" href="#332">332</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="333" href="#333">333</a>	<b>public</b> <a href="/source/s?defs=Number&amp;project=rtmp_client">Number</a> <a class="xmt" name="readNumber"/><a href="/source/s?refs=readNumber&amp;project=rtmp_client" class="xmt">readNumber</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="334" href="#334">334</a>		<a href="/source/s?defs=Number&amp;project=rtmp_client">Number</a> v;
<a class="l" name="335" href="#335">335</a>
<a class="l" name="336" href="#336">336</a>		<b>if</b> (<a href="/source/s?defs=currentDataType&amp;project=rtmp_client">currentDataType</a> == <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_NUMBER&amp;project=rtmp_client">TYPE_NUMBER</a>) {
<a class="l" name="337" href="#337">337</a>			v = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=getDouble&amp;project=rtmp_client">getDouble</a>();
<a class="l" name="338" href="#338">338</a>		} <b>else</b> {
<a class="l" name="339" href="#339">339</a>			<span class="c">// we are decoding an int</span>
<a class="hl" name="340" href="#340">340</a>			v = <a class="d" href="#readAMF3Integer">readAMF3Integer</a>();
<a class="l" name="341" href="#341">341</a>		}
<a class="l" name="342" href="#342">342</a>
<a class="l" name="343" href="#343">343</a>		<b>if</b> (<a href="/source/s?defs=target&amp;project=rtmp_client">target</a> <b>instanceof</b> <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a> &amp;&amp; <a href="/source/s?defs=Number&amp;project=rtmp_client">Number</a>.<b>class</b>.<a href="/source/s?defs=isAssignableFrom&amp;project=rtmp_client">isAssignableFrom</a>((<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;) <a href="/source/s?defs=target&amp;project=rtmp_client">target</a>)) {
<a class="l" name="344" href="#344">344</a>			<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a> <a href="/source/s?defs=cls&amp;project=rtmp_client">cls</a> = (<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>) <a href="/source/s?defs=target&amp;project=rtmp_client">target</a>;
<a class="l" name="345" href="#345">345</a>			<b>if</b> (!<a href="/source/s?defs=cls&amp;project=rtmp_client">cls</a>.<a href="/source/s?defs=isAssignableFrom&amp;project=rtmp_client">isAssignableFrom</a>(v.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>())) {
<a class="l" name="346" href="#346">346</a><span class="c">//				v = (Number) convertUtilsBean.convert(v.toString(), cls);</span>
<a class="l" name="347" href="#347">347</a>			}
<a class="l" name="348" href="#348">348</a>		}
<a class="l" name="349" href="#349">349</a>
<a class="hl" name="350" href="#350">350</a>		<b>return</b> v;
<a class="l" name="351" href="#351">351</a>	}
<a class="l" name="352" href="#352">352</a>
<a class="l" name="353" href="#353">353</a>	<span class="c">/**
<a class="l" name="354" href="#354">354</a>	 * Reads a string
<a class="l" name="355" href="#355">355</a>	 *
<a class="l" name="356" href="#356">356</a>	 * <strong>@return</strong> String       String
<a class="l" name="357" href="#357">357</a>	 */</span>
<a class="l" name="358" href="#358">358</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="359" href="#359">359</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="readString"/><a href="/source/s?refs=readString&amp;project=rtmp_client" class="xmt">readString</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="hl" name="360" href="#360">360</a>		<b>int</b> <a href="/source/s?defs=len&amp;project=rtmp_client">len</a> = <a class="d" href="#readAMF3Integer">readAMF3Integer</a>();
<a class="l" name="361" href="#361">361</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"readString - length: {}"</span>, <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>);
<a class="l" name="362" href="#362">362</a>		<b>if</b> (<a href="/source/s?defs=len&amp;project=rtmp_client">len</a> == <span class="n">1</span>) {
<a class="l" name="363" href="#363">363</a>			<span class="c">// Empty string</span>
<a class="l" name="364" href="#364">364</a>			<b>return</b> <span class="s">""</span>;
<a class="l" name="365" href="#365">365</a>		}
<a class="l" name="366" href="#366">366</a>		<b>if</b> ((<a href="/source/s?defs=len&amp;project=rtmp_client">len</a> &amp; <span class="n">1</span>) == <span class="n">0</span>) {
<a class="l" name="367" href="#367">367</a>			<span class="c">//if the refs are empty an IndexOutOfBoundsEx will be thrown</span>
<a class="l" name="368" href="#368">368</a>			<b>if</b> (<a href="/source/s?defs=stringReferences&amp;project=rtmp_client">stringReferences</a>.<a href="/source/s?defs=isEmpty&amp;project=rtmp_client">isEmpty</a>()) {
<a class="l" name="369" href="#369">369</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"String reference list is empty"</span>);
<a class="hl" name="370" href="#370">370</a>			}
<a class="l" name="371" href="#371">371</a>			<span class="c">// Reference</span>
<a class="l" name="372" href="#372">372</a>			<b>return</b> <a href="/source/s?defs=stringReferences&amp;project=rtmp_client">stringReferences</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=len&amp;project=rtmp_client">len</a> &gt;&gt; <span class="n">1</span>);
<a class="l" name="373" href="#373">373</a>		}
<a class="l" name="374" href="#374">374</a>		<a href="/source/s?defs=len&amp;project=rtmp_client">len</a> &gt;&gt;= <span class="n">1</span>;
<a class="l" name="375" href="#375">375</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"readString - new length: {}"</span>, <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>);
<a class="l" name="376" href="#376">376</a>		<b>int</b> <a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>();
<a class="l" name="377" href="#377">377</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"readString - limit: {}"</span>, <a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>);
<a class="l" name="378" href="#378">378</a>		<b>final</b> <a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a> <a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>();
<a class="l" name="379" href="#379">379</a>		<a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(<a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() + <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>);
<a class="hl" name="380" href="#380">380</a>		<b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=string&amp;project=rtmp_client">string</a> = <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=CHARSET&amp;project=rtmp_client">CHARSET</a>.<a href="/source/s?defs=decode&amp;project=rtmp_client">decode</a>(<a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a>).<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>();
<a class="l" name="381" href="#381">381</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"String: {}"</span>, <a href="/source/s?defs=string&amp;project=rtmp_client">string</a>);
<a class="l" name="382" href="#382">382</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>); <span class="c">// Reset the limit</span>
<a class="l" name="383" href="#383">383</a>		<a href="/source/s?defs=stringReferences&amp;project=rtmp_client">stringReferences</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=string&amp;project=rtmp_client">string</a>);
<a class="l" name="384" href="#384">384</a>		<b>return</b> <a href="/source/s?defs=string&amp;project=rtmp_client">string</a>;
<a class="l" name="385" href="#385">385</a>	}
<a class="l" name="386" href="#386">386</a>
<a class="l" name="387" href="#387">387</a>	<span class="c">/**
<a class="l" name="388" href="#388">388</a>	 * Reads a string of a set length. This does not use
<a class="l" name="389" href="#389">389</a>	 * the string reference table.
<a class="hl" name="390" href="#390">390</a>	 *
<a class="l" name="391" href="#391">391</a>	 * <strong>@param</strong> <em>length</em> the length of the string
<a class="l" name="392" href="#392">392</a>	 * <strong>@return</strong> String
<a class="l" name="393" href="#393">393</a>	 */</span>
<a class="l" name="394" href="#394">394</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="readString"/><a href="/source/s?refs=readString&amp;project=rtmp_client" class="xmt">readString</a>(<b>int</b> <a class="xa" name="length"/><a href="/source/s?refs=length&amp;project=rtmp_client" class="xa">length</a>) {
<a class="l" name="395" href="#395">395</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"readString - length: {}"</span>, <a class="d" href="#length">length</a>);
<a class="l" name="396" href="#396">396</a>		<b>int</b> <a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>();
<a class="l" name="397" href="#397">397</a>		<b>final</b> <a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a> <a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>();
<a class="l" name="398" href="#398">398</a>		<a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(<a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() + <a class="d" href="#length">length</a>);
<a class="l" name="399" href="#399">399</a>		<b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=string&amp;project=rtmp_client">string</a> = <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=CHARSET&amp;project=rtmp_client">CHARSET</a>.<a href="/source/s?defs=decode&amp;project=rtmp_client">decode</a>(<a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a>).<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>();
<a class="hl" name="400" href="#400">400</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"String: {}"</span>, <a href="/source/s?defs=string&amp;project=rtmp_client">string</a>);
<a class="l" name="401" href="#401">401</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>);
<a class="l" name="402" href="#402">402</a>		<span class="c">//check for null termination</span>
<a class="l" name="403" href="#403">403</a>		<b>byte</b> b = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="404" href="#404">404</a>		<b>if</b> (b != <span class="n">0</span>) {
<a class="l" name="405" href="#405">405</a>			<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() - <span class="n">1</span>);
<a class="l" name="406" href="#406">406</a>		}
<a class="l" name="407" href="#407">407</a>		<b>return</b> <a href="/source/s?defs=string&amp;project=rtmp_client">string</a>;
<a class="l" name="408" href="#408">408</a>	}
<a class="l" name="409" href="#409">409</a>
<a class="hl" name="410" href="#410">410</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getString"/><a href="/source/s?refs=getString&amp;project=rtmp_client" class="xmt">getString</a>() {
<a class="l" name="411" href="#411">411</a>		<b>return</b> <a href="/source/s?defs=readString&amp;project=rtmp_client">readString</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>);
<a class="l" name="412" href="#412">412</a>	}
<a class="l" name="413" href="#413">413</a>
<a class="l" name="414" href="#414">414</a>	<span class="c">/**
<a class="l" name="415" href="#415">415</a>	 * Returns a date
<a class="l" name="416" href="#416">416</a>	 *
<a class="l" name="417" href="#417">417</a>	 * <strong>@return</strong> Date        Date object
<a class="l" name="418" href="#418">418</a>	 */</span>
<a class="l" name="419" href="#419">419</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="hl" name="420" href="#420">420</a>	<b>public</b> <a href="/source/s?defs=Date&amp;project=rtmp_client">Date</a> <a class="xmt" name="readDate"/><a href="/source/s?refs=readDate&amp;project=rtmp_client" class="xmt">readDate</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="421" href="#421">421</a>		<b>int</b> <a href="/source/s?defs=ref&amp;project=rtmp_client">ref</a> = <a class="d" href="#readAMF3Integer">readAMF3Integer</a>();
<a class="l" name="422" href="#422">422</a>		<b>if</b> ((<a href="/source/s?defs=ref&amp;project=rtmp_client">ref</a> &amp; <span class="n">1</span>) == <span class="n">0</span>) {
<a class="l" name="423" href="#423">423</a>			<span class="c">// Reference to previously found date</span>
<a class="l" name="424" href="#424">424</a>			<b>return</b> (<a href="/source/s?defs=Date&amp;project=rtmp_client">Date</a>) <a href="/source/s?defs=getReference&amp;project=rtmp_client">getReference</a>(<a href="/source/s?defs=ref&amp;project=rtmp_client">ref</a> &gt;&gt; <span class="n">1</span>);
<a class="l" name="425" href="#425">425</a>		}
<a class="l" name="426" href="#426">426</a>
<a class="l" name="427" href="#427">427</a>		<b>long</b> <a href="/source/s?defs=ms&amp;project=rtmp_client">ms</a> = (<b>long</b>) <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=getDouble&amp;project=rtmp_client">getDouble</a>();
<a class="l" name="428" href="#428">428</a>		<a href="/source/s?defs=Date&amp;project=rtmp_client">Date</a> <a href="/source/s?defs=date&amp;project=rtmp_client">date</a> = <b>new</b> <a href="/source/s?defs=Date&amp;project=rtmp_client">Date</a>(<a href="/source/s?defs=ms&amp;project=rtmp_client">ms</a>);
<a class="l" name="429" href="#429">429</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=date&amp;project=rtmp_client">date</a>);
<a class="hl" name="430" href="#430">430</a>		<b>return</b> <a href="/source/s?defs=date&amp;project=rtmp_client">date</a>;
<a class="l" name="431" href="#431">431</a>	}
<a class="l" name="432" href="#432">432</a>
<a class="l" name="433" href="#433">433</a>	<span class="c">// Array</span>
<a class="l" name="434" href="#434">434</a>
<a class="l" name="435" href="#435">435</a>	<span class="c">/**
<a class="l" name="436" href="#436">436</a>	 * Returns an array
<a class="l" name="437" href="#437">437</a>	 *
<a class="l" name="438" href="#438">438</a>	 * <strong>@return</strong> int        Length of array
<a class="l" name="439" href="#439">439</a>	 */</span>
<a class="hl" name="440" href="#440">440</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>({ <span class="s">"unchecked"</span>, <span class="s">"rawtypes"</span> })
<a class="l" name="441" href="#441">441</a>	<b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="readArray"/><a href="/source/s?refs=readArray&amp;project=rtmp_client" class="xmt">readArray</a>(<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xa" name="deserializer"/><a href="/source/s?refs=deserializer&amp;project=rtmp_client" class="xa">deserializer</a>, <a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="442" href="#442">442</a>		<b>int</b> <a href="/source/s?defs=count&amp;project=rtmp_client">count</a> = <a class="d" href="#readAMF3Integer">readAMF3Integer</a>();
<a class="l" name="443" href="#443">443</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Count: {} and {} ref {}"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <a href="/source/s?defs=count&amp;project=rtmp_client">count</a>, (<a href="/source/s?defs=count&amp;project=rtmp_client">count</a> &amp; <span class="n">1</span>), (<a href="/source/s?defs=count&amp;project=rtmp_client">count</a> &gt;&gt; <span class="n">1</span>) });
<a class="l" name="444" href="#444">444</a>		<b>if</b> ((<a href="/source/s?defs=count&amp;project=rtmp_client">count</a> &amp; <span class="n">1</span>) == <span class="n">0</span>) {
<a class="l" name="445" href="#445">445</a>			<span class="c">//Reference</span>
<a class="l" name="446" href="#446">446</a>			<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=ref&amp;project=rtmp_client">ref</a> = <a href="/source/s?defs=getReference&amp;project=rtmp_client">getReference</a>(<a href="/source/s?defs=count&amp;project=rtmp_client">count</a> &gt;&gt; <span class="n">1</span>);
<a class="l" name="447" href="#447">447</a>			<b>if</b> (<a href="/source/s?defs=ref&amp;project=rtmp_client">ref</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="448" href="#448">448</a>				<b>return</b> <a href="/source/s?defs=ref&amp;project=rtmp_client">ref</a>;
<a class="l" name="449" href="#449">449</a>			}
<a class="hl" name="450" href="#450">450</a>		}
<a class="l" name="451" href="#451">451</a>
<a class="l" name="452" href="#452">452</a>		<a href="/source/s?defs=count&amp;project=rtmp_client">count</a> = (<a href="/source/s?defs=count&amp;project=rtmp_client">count</a> &gt;&gt; <span class="n">1</span>);
<a class="l" name="453" href="#453">453</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=key&amp;project=rtmp_client">key</a> = <a href="/source/s?defs=readString&amp;project=rtmp_client">readString</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>);
<a class="l" name="454" href="#454">454</a>		<a class="d" href="#amf3_mode">amf3_mode</a> += <span class="n">1</span>;
<a class="l" name="455" href="#455">455</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="d" href="#result">result</a>;
<a class="l" name="456" href="#456">456</a>		<b>if</b> (<a href="/source/s?defs=key&amp;project=rtmp_client">key</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<span class="s">""</span>)) {
<a class="l" name="457" href="#457">457</a>			<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a href="/source/s?defs=nested&amp;project=rtmp_client">nested</a> = <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>.<b>class</b>;
<a class="l" name="458" href="#458">458</a>			<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a href="/source/s?defs=collection&amp;project=rtmp_client">collection</a> = <a href="/source/s?defs=Collection&amp;project=rtmp_client">Collection</a>.<b>class</b>;
<a class="l" name="459" href="#459">459</a>			<a href="/source/s?defs=Collection&amp;project=rtmp_client">Collection</a> <a href="/source/s?defs=resultCollection&amp;project=rtmp_client">resultCollection</a>;
<a class="hl" name="460" href="#460">460</a>
<a class="l" name="461" href="#461">461</a>			<b>if</b> (<a href="/source/s?defs=target&amp;project=rtmp_client">target</a> <b>instanceof</b> <a href="/source/s?defs=ParameterizedType&amp;project=rtmp_client">ParameterizedType</a>) {
<a class="l" name="462" href="#462">462</a>				<a href="/source/s?defs=ParameterizedType&amp;project=rtmp_client">ParameterizedType</a> t = (<a href="/source/s?defs=ParameterizedType&amp;project=rtmp_client">ParameterizedType</a>) <a href="/source/s?defs=target&amp;project=rtmp_client">target</a>;
<a class="l" name="463" href="#463">463</a>				<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>[] <a href="/source/s?defs=actualTypeArguments&amp;project=rtmp_client">actualTypeArguments</a> = t.<a href="/source/s?defs=getActualTypeArguments&amp;project=rtmp_client">getActualTypeArguments</a>();
<a class="l" name="464" href="#464">464</a>				<b>if</b> (<a href="/source/s?defs=actualTypeArguments&amp;project=rtmp_client">actualTypeArguments</a>.<a class="d" href="#length">length</a> == <span class="n">1</span>) {
<a class="l" name="465" href="#465">465</a>					<a href="/source/s?defs=nested&amp;project=rtmp_client">nested</a> = (<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;) <a href="/source/s?defs=actualTypeArguments&amp;project=rtmp_client">actualTypeArguments</a>[<span class="n">0</span>];
<a class="l" name="466" href="#466">466</a>				}
<a class="l" name="467" href="#467">467</a>				<a href="/source/s?defs=target&amp;project=rtmp_client">target</a> = t.<a href="/source/s?defs=getRawType&amp;project=rtmp_client">getRawType</a>();
<a class="l" name="468" href="#468">468</a>			}
<a class="l" name="469" href="#469">469</a>
<a class="hl" name="470" href="#470">470</a>			<b>if</b> (<a href="/source/s?defs=target&amp;project=rtmp_client">target</a> <b>instanceof</b> <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>) {
<a class="l" name="471" href="#471">471</a>				<a href="/source/s?defs=collection&amp;project=rtmp_client">collection</a> = (<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>) <a href="/source/s?defs=target&amp;project=rtmp_client">target</a>;
<a class="l" name="472" href="#472">472</a>			}
<a class="l" name="473" href="#473">473</a>
<a class="l" name="474" href="#474">474</a>			<b>if</b> (<a href="/source/s?defs=collection&amp;project=rtmp_client">collection</a>.<a href="/source/s?defs=isArray&amp;project=rtmp_client">isArray</a>()) {
<a class="l" name="475" href="#475">475</a>				<a href="/source/s?defs=nested&amp;project=rtmp_client">nested</a> = <a href="/source/s?defs=ArrayUtils&amp;project=rtmp_client">ArrayUtils</a>.<a href="/source/s?defs=getGenericType&amp;project=rtmp_client">getGenericType</a>(<a href="/source/s?defs=collection&amp;project=rtmp_client">collection</a>.<a href="/source/s?defs=getComponentType&amp;project=rtmp_client">getComponentType</a>());
<a class="l" name="476" href="#476">476</a>				<a class="d" href="#result">result</a> = <a href="/source/s?defs=Array&amp;project=rtmp_client">Array</a>.<a href="/source/s?defs=newInstance&amp;project=rtmp_client">newInstance</a>(<a href="/source/s?defs=nested&amp;project=rtmp_client">nested</a>, <a href="/source/s?defs=count&amp;project=rtmp_client">count</a>);
<a class="l" name="477" href="#477">477</a>				<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a class="d" href="#result">result</a>);
<a class="l" name="478" href="#478">478</a>				<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=count&amp;project=rtmp_client">count</a>; i++) {
<a class="l" name="479" href="#479">479</a>					<b>final</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<b>this</b>, <a href="/source/s?defs=nested&amp;project=rtmp_client">nested</a>);
<a class="hl" name="480" href="#480">480</a>					<a href="/source/s?defs=Array&amp;project=rtmp_client">Array</a>.<a href="/source/s?defs=set&amp;project=rtmp_client">set</a>(<a class="d" href="#result">result</a>, i, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="481" href="#481">481</a>				}
<a class="l" name="482" href="#482">482</a>			} <b>else</b> {
<a class="l" name="483" href="#483">483</a>				<b>if</b> (<a href="/source/s?defs=SortedSet&amp;project=rtmp_client">SortedSet</a>.<b>class</b>.<a href="/source/s?defs=isAssignableFrom&amp;project=rtmp_client">isAssignableFrom</a>(<a href="/source/s?defs=collection&amp;project=rtmp_client">collection</a>)) {
<a class="l" name="484" href="#484">484</a>					<a href="/source/s?defs=resultCollection&amp;project=rtmp_client">resultCollection</a> = <b>new</b> <a href="/source/s?defs=TreeSet&amp;project=rtmp_client">TreeSet</a>();
<a class="l" name="485" href="#485">485</a>				} <b>else</b> <b>if</b> (<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>.<b>class</b>.<a href="/source/s?defs=isAssignableFrom&amp;project=rtmp_client">isAssignableFrom</a>(<a href="/source/s?defs=collection&amp;project=rtmp_client">collection</a>)) {
<a class="l" name="486" href="#486">486</a>					<a href="/source/s?defs=resultCollection&amp;project=rtmp_client">resultCollection</a> = <b>new</b> <a href="/source/s?defs=HashSet&amp;project=rtmp_client">HashSet</a>(<a href="/source/s?defs=count&amp;project=rtmp_client">count</a>);
<a class="l" name="487" href="#487">487</a>				} <b>else</b> {
<a class="l" name="488" href="#488">488</a>					<a href="/source/s?defs=resultCollection&amp;project=rtmp_client">resultCollection</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>(<a href="/source/s?defs=count&amp;project=rtmp_client">count</a>);
<a class="l" name="489" href="#489">489</a>				}
<a class="hl" name="490" href="#490">490</a>
<a class="l" name="491" href="#491">491</a>				<a class="d" href="#result">result</a> = <a href="/source/s?defs=resultCollection&amp;project=rtmp_client">resultCollection</a>;
<a class="l" name="492" href="#492">492</a>				<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a class="d" href="#result">result</a>);
<a class="l" name="493" href="#493">493</a>
<a class="l" name="494" href="#494">494</a>				<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=count&amp;project=rtmp_client">count</a>; i++) {
<a class="l" name="495" href="#495">495</a>					<b>final</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<b>this</b>, <a href="/source/s?defs=nested&amp;project=rtmp_client">nested</a>);
<a class="l" name="496" href="#496">496</a>					<a href="/source/s?defs=resultCollection&amp;project=rtmp_client">resultCollection</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="497" href="#497">497</a>				}
<a class="l" name="498" href="#498">498</a>
<a class="l" name="499" href="#499">499</a>			}
<a class="hl" name="500" href="#500">500</a>		} <b>else</b> {
<a class="l" name="501" href="#501">501</a>			<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; k = <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>.<b>class</b>;
<a class="l" name="502" href="#502">502</a>			<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; v = <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>.<b>class</b>;
<a class="l" name="503" href="#503">503</a>			<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a href="/source/s?defs=collection&amp;project=rtmp_client">collection</a> = <a href="/source/s?defs=Collection&amp;project=rtmp_client">Collection</a>.<b>class</b>;
<a class="l" name="504" href="#504">504</a>
<a class="l" name="505" href="#505">505</a>			<b>if</b> (<a href="/source/s?defs=target&amp;project=rtmp_client">target</a> <b>instanceof</b> <a href="/source/s?defs=ParameterizedType&amp;project=rtmp_client">ParameterizedType</a>) {
<a class="l" name="506" href="#506">506</a>				<a href="/source/s?defs=ParameterizedType&amp;project=rtmp_client">ParameterizedType</a> t = (<a href="/source/s?defs=ParameterizedType&amp;project=rtmp_client">ParameterizedType</a>) <a href="/source/s?defs=target&amp;project=rtmp_client">target</a>;
<a class="l" name="507" href="#507">507</a>				<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>[] <a href="/source/s?defs=actualTypeArguments&amp;project=rtmp_client">actualTypeArguments</a> = t.<a href="/source/s?defs=getActualTypeArguments&amp;project=rtmp_client">getActualTypeArguments</a>();
<a class="l" name="508" href="#508">508</a>				<b>if</b> (<a href="/source/s?defs=actualTypeArguments&amp;project=rtmp_client">actualTypeArguments</a>.<a class="d" href="#length">length</a> == <span class="n">2</span>) {
<a class="l" name="509" href="#509">509</a>					k = (<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;) <a href="/source/s?defs=actualTypeArguments&amp;project=rtmp_client">actualTypeArguments</a>[<span class="n">0</span>];
<a class="hl" name="510" href="#510">510</a>					v = (<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;) <a href="/source/s?defs=actualTypeArguments&amp;project=rtmp_client">actualTypeArguments</a>[<span class="n">1</span>];
<a class="l" name="511" href="#511">511</a>				}
<a class="l" name="512" href="#512">512</a>				<a href="/source/s?defs=target&amp;project=rtmp_client">target</a> = t.<a href="/source/s?defs=getRawType&amp;project=rtmp_client">getRawType</a>();
<a class="l" name="513" href="#513">513</a>			}
<a class="l" name="514" href="#514">514</a>
<a class="l" name="515" href="#515">515</a>			<b>if</b> (<a href="/source/s?defs=target&amp;project=rtmp_client">target</a> <b>instanceof</b> <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>) {
<a class="l" name="516" href="#516">516</a>				<a href="/source/s?defs=collection&amp;project=rtmp_client">collection</a> = (<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>) <a href="/source/s?defs=target&amp;project=rtmp_client">target</a>;
<a class="l" name="517" href="#517">517</a>			}
<a class="l" name="518" href="#518">518</a>
<a class="l" name="519" href="#519">519</a>			<b>if</b> (<a href="/source/s?defs=SortedMap&amp;project=rtmp_client">SortedMap</a>.<b>class</b>.<a href="/source/s?defs=isAssignableFrom&amp;project=rtmp_client">isAssignableFrom</a>(<a href="/source/s?defs=collection&amp;project=rtmp_client">collection</a>)) {
<a class="hl" name="520" href="#520">520</a>				<a href="/source/s?defs=collection&amp;project=rtmp_client">collection</a> = <a href="/source/s?defs=TreeMap&amp;project=rtmp_client">TreeMap</a>.<b>class</b>;
<a class="l" name="521" href="#521">521</a>			} <b>else</b> {
<a class="l" name="522" href="#522">522</a>				<a href="/source/s?defs=collection&amp;project=rtmp_client">collection</a> = <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>.<b>class</b>;
<a class="l" name="523" href="#523">523</a>			}
<a class="l" name="524" href="#524">524</a>
<a class="l" name="525" href="#525">525</a>			<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a> <a href="/source/s?defs=resultMap&amp;project=rtmp_client">resultMap</a>;
<a class="l" name="526" href="#526">526</a>
<a class="l" name="527" href="#527">527</a>			<b>try</b> {
<a class="l" name="528" href="#528">528</a>				<a href="/source/s?defs=resultMap&amp;project=rtmp_client">resultMap</a> = (<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>) <a href="/source/s?defs=collection&amp;project=rtmp_client">collection</a>.<a href="/source/s?defs=newInstance&amp;project=rtmp_client">newInstance</a>();
<a class="l" name="529" href="#529">529</a>			} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="hl" name="530" href="#530">530</a>				<a href="/source/s?defs=resultMap&amp;project=rtmp_client">resultMap</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>(<a href="/source/s?defs=count&amp;project=rtmp_client">count</a>);
<a class="l" name="531" href="#531">531</a>			}
<a class="l" name="532" href="#532">532</a>
<a class="l" name="533" href="#533">533</a>			<span class="c">// associative array</span>
<a class="l" name="534" href="#534">534</a>			<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=resultMap&amp;project=rtmp_client">resultMap</a>);
<a class="l" name="535" href="#535">535</a>			<b>while</b> (!<a href="/source/s?defs=key&amp;project=rtmp_client">key</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<span class="s">""</span>)) {
<a class="l" name="536" href="#536">536</a>				<b>final</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<b>this</b>, v);
<a class="l" name="537" href="#537">537</a>				<a href="/source/s?defs=resultMap&amp;project=rtmp_client">resultMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=key&amp;project=rtmp_client">key</a>, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="538" href="#538">538</a>				<a href="/source/s?defs=key&amp;project=rtmp_client">key</a> = <a href="/source/s?defs=readString&amp;project=rtmp_client">readString</a>(k);
<a class="l" name="539" href="#539">539</a>			}
<a class="hl" name="540" href="#540">540</a>			<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=count&amp;project=rtmp_client">count</a>; i++) {
<a class="l" name="541" href="#541">541</a>				<b>final</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<b>this</b>, v);
<a class="l" name="542" href="#542">542</a>				<a href="/source/s?defs=resultMap&amp;project=rtmp_client">resultMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(i, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="543" href="#543">543</a>			}
<a class="l" name="544" href="#544">544</a>			<a class="d" href="#result">result</a> = <a href="/source/s?defs=resultMap&amp;project=rtmp_client">resultMap</a>;
<a class="l" name="545" href="#545">545</a>		}
<a class="l" name="546" href="#546">546</a>		<a class="d" href="#amf3_mode">amf3_mode</a> -= <span class="n">1</span>;
<a class="l" name="547" href="#547">547</a>		<b>return</b> <a class="d" href="#result">result</a>;
<a class="l" name="548" href="#548">548</a>	}
<a class="l" name="549" href="#549">549</a>
<a class="hl" name="550" href="#550">550</a>	<b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="readMap"/><a href="/source/s?refs=readMap&amp;project=rtmp_client" class="xmt">readMap</a>(<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xa" name="deserializer"/><a href="/source/s?refs=deserializer&amp;project=rtmp_client" class="xa">deserializer</a>, <a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="551" href="#551">551</a>		<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"AMF3 doesn't support maps."</span>);
<a class="l" name="552" href="#552">552</a>	}
<a class="l" name="553" href="#553">553</a>
<a class="l" name="554" href="#554">554</a>	<span class="c">// Object</span>
<a class="l" name="555" href="#555">555</a>
<a class="l" name="556" href="#556">556</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>({ <span class="s">"unchecked"</span>, <span class="s">"rawtypes"</span>, <span class="s">"serial"</span> })
<a class="l" name="557" href="#557">557</a>	<b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="readObject"/><a href="/source/s?refs=readObject&amp;project=rtmp_client" class="xmt">readObject</a>(<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xa" name="deserializer"/><a href="/source/s?refs=deserializer&amp;project=rtmp_client" class="xa">deserializer</a>, <a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="558" href="#558">558</a>		<b>int</b> <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <a class="d" href="#readAMF3Integer">readAMF3Integer</a>();
<a class="l" name="559" href="#559">559</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Type: {} and {} ref {}"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <a href="/source/s?defs=type&amp;project=rtmp_client">type</a>, (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &amp; <span class="n">1</span>), (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt; <span class="n">1</span>) });
<a class="hl" name="560" href="#560">560</a>		<b>if</b> ((<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &amp; <span class="n">1</span>) == <span class="n">0</span>) {
<a class="l" name="561" href="#561">561</a>			<span class="c">//Reference</span>
<a class="l" name="562" href="#562">562</a>			<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=ref&amp;project=rtmp_client">ref</a> = <a href="/source/s?defs=getReference&amp;project=rtmp_client">getReference</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt; <span class="n">1</span>);
<a class="l" name="563" href="#563">563</a>			<b>if</b> (<a href="/source/s?defs=ref&amp;project=rtmp_client">ref</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="564" href="#564">564</a>				<b>return</b> <a href="/source/s?defs=ref&amp;project=rtmp_client">ref</a>;
<a class="l" name="565" href="#565">565</a>			}
<a class="l" name="566" href="#566">566</a>			<b>byte</b> b = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="567" href="#567">567</a>			<b>if</b> (b == <span class="n">7</span>) {
<a class="l" name="568" href="#568">568</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"BEL: {}"</span>, b); <span class="c">//7</span>
<a class="l" name="569" href="#569">569</a>			} <b>else</b> {
<a class="hl" name="570" href="#570">570</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Non-BEL byte: {}"</span>, b);
<a class="l" name="571" href="#571">571</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Extra byte: {}"</span>, <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>());
<a class="l" name="572" href="#572">572</a>			}
<a class="l" name="573" href="#573">573</a>		}
<a class="l" name="574" href="#574">574</a>
<a class="l" name="575" href="#575">575</a>		<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt;= <span class="n">1</span>;
<a class="l" name="576" href="#576">576</a>		<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt; <a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="577" href="#577">577</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=className&amp;project=rtmp_client">className</a>;
<a class="l" name="578" href="#578">578</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="d" href="#result">result</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="579" href="#579">579</a>		<b>boolean</b> <a href="/source/s?defs=inlineClass&amp;project=rtmp_client">inlineClass</a> = (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &amp; <span class="n">1</span>) == <span class="n">1</span>;
<a class="hl" name="580" href="#580">580</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Class is in-line? {}"</span>, <a href="/source/s?defs=inlineClass&amp;project=rtmp_client">inlineClass</a>);
<a class="l" name="581" href="#581">581</a>		<b>if</b> (!<a href="/source/s?defs=inlineClass&amp;project=rtmp_client">inlineClass</a>) {
<a class="l" name="582" href="#582">582</a>			<a href="/source/s?defs=ClassReference&amp;project=rtmp_client">ClassReference</a> <a href="/source/s?defs=info&amp;project=rtmp_client">info</a> = <a href="/source/s?defs=classReferences&amp;project=rtmp_client">classReferences</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt; <span class="n">1</span>);
<a class="l" name="583" href="#583">583</a>			<a href="/source/s?defs=className&amp;project=rtmp_client">className</a> = <a href="/source/s?defs=info&amp;project=rtmp_client">info</a>.<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>;
<a class="l" name="584" href="#584">584</a>			<a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a> = <a href="/source/s?defs=info&amp;project=rtmp_client">info</a>.<a href="/source/s?defs=attributeNames&amp;project=rtmp_client">attributeNames</a>;
<a class="l" name="585" href="#585">585</a>			<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <a href="/source/s?defs=info&amp;project=rtmp_client">info</a>.<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>;
<a class="l" name="586" href="#586">586</a>			<b>if</b> (<a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="587" href="#587">587</a>				<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> |= <a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>() &lt;&lt; <span class="n">2</span>;
<a class="l" name="588" href="#588">588</a>			}
<a class="l" name="589" href="#589">589</a>		} <b>else</b> {
<a class="hl" name="590" href="#590">590</a>			<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt;= <span class="n">1</span>;
<a class="l" name="591" href="#591">591</a>			<a href="/source/s?defs=className&amp;project=rtmp_client">className</a> = <a href="/source/s?defs=readString&amp;project=rtmp_client">readString</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>);
<a class="l" name="592" href="#592">592</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Type: {} classname: {}"</span>, <a href="/source/s?defs=type&amp;project=rtmp_client">type</a>, <a href="/source/s?defs=className&amp;project=rtmp_client">className</a>);
<a class="l" name="593" href="#593">593</a>			<span class="c">//check for flex class alias since these wont be detected as externalizable</span>
<a class="l" name="594" href="#594">594</a>			<b>if</b> (<a href="/source/s?defs=classAliases&amp;project=rtmp_client">classAliases</a>.<a href="/source/s?defs=containsKey&amp;project=rtmp_client">containsKey</a>(<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>)) {
<a class="l" name="595" href="#595">595</a>				<span class="c">//make sure type is externalizable</span>
<a class="l" name="596" href="#596">596</a>				<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <span class="n">1</span>;
<a class="l" name="597" href="#597">597</a>			} <b>else</b> <b>if</b> (<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>.<a href="/source/s?defs=startsWith&amp;project=rtmp_client">startsWith</a>(<span class="s">"flex"</span>)) {
<a class="l" name="598" href="#598">598</a>				<span class="c">//set the attributes for messaging classes</span>
<a class="l" name="599" href="#599">599</a>				<b>if</b> (<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>.<a href="/source/s?defs=endsWith&amp;project=rtmp_client">endsWith</a>(<span class="s">"CommandMessage"</span>)) {
<a class="hl" name="600" href="#600">600</a>					<a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a> = <b>new</b> <a href="/source/s?defs=LinkedList&amp;project=rtmp_client">LinkedList</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt;() {
<a class="l" name="601" href="#601">601</a>						{
<a class="l" name="602" href="#602">602</a>							<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<span class="s">"timestamp"</span>);
<a class="l" name="603" href="#603">603</a>							<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<span class="s">"headers"</span>);
<a class="l" name="604" href="#604">604</a>							<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<span class="s">"operation"</span>);
<a class="l" name="605" href="#605">605</a>							<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<span class="s">"body"</span>);
<a class="l" name="606" href="#606">606</a>							<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<span class="s">"correlationId"</span>);
<a class="l" name="607" href="#607">607</a>							<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<span class="s">"messageId"</span>);
<a class="l" name="608" href="#608">608</a>							<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<span class="s">"timeToLive"</span>);
<a class="l" name="609" href="#609">609</a>							<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<span class="s">"clientId"</span>);
<a class="hl" name="610" href="#610">610</a>							<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<span class="s">"destination"</span>);
<a class="l" name="611" href="#611">611</a>						}
<a class="l" name="612" href="#612">612</a>					};
<a class="l" name="613" href="#613">613</a>				} <b>else</b> {
<a class="l" name="614" href="#614">614</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Attributes for {} were not set"</span>, <a href="/source/s?defs=className&amp;project=rtmp_client">className</a>);
<a class="l" name="615" href="#615">615</a>				}
<a class="l" name="616" href="#616">616</a>			}
<a class="l" name="617" href="#617">617</a>		}
<a class="l" name="618" href="#618">618</a>		<a class="d" href="#amf3_mode">amf3_mode</a> += <span class="n">1</span>;
<a class="l" name="619" href="#619">619</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=instance&amp;project=rtmp_client">instance</a> = <a href="/source/s?defs=newInstance&amp;project=rtmp_client">newInstance</a>(<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>);
<a class="hl" name="620" href="#620">620</a>		<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="d" href="#properties">properties</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="621" href="#621">621</a>		<a class="d" href="#PendingObject">PendingObject</a> <a href="/source/s?defs=pending&amp;project=rtmp_client">pending</a> = <b>new</b> <a class="d" href="#PendingObject">PendingObject</a>();
<a class="l" name="622" href="#622">622</a>		<b>int</b> <a href="/source/s?defs=tempRefId&amp;project=rtmp_client">tempRefId</a> = <a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=pending&amp;project=rtmp_client">pending</a>);
<a class="l" name="623" href="#623">623</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Object type: {}"</span>, (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &amp; <span class="n">0x03</span>));
<a class="l" name="624" href="#624">624</a>		<b>switch</b> (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &amp; <span class="n">0x03</span>) {
<a class="l" name="625" href="#625">625</a>			<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_OBJECT_PROPERTY&amp;project=rtmp_client">TYPE_OBJECT_PROPERTY</a>:
<a class="l" name="626" href="#626">626</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Detected: Object property type"</span>);
<a class="l" name="627" href="#627">627</a>				<span class="c">// Load object properties into map</span>
<a class="l" name="628" href="#628">628</a>				<b>int</b> <a href="/source/s?defs=count&amp;project=rtmp_client">count</a> = <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt; <span class="n">2</span>;
<a class="l" name="629" href="#629">629</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Count: {}"</span>, <a href="/source/s?defs=count&amp;project=rtmp_client">count</a>);
<a class="hl" name="630" href="#630">630</a>				<b>if</b> (<a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="631" href="#631">631</a>					<a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt;(<a href="/source/s?defs=count&amp;project=rtmp_client">count</a>);
<a class="l" name="632" href="#632">632</a>					<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=count&amp;project=rtmp_client">count</a>; i++) {
<a class="l" name="633" href="#633">633</a>						<a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=readString&amp;project=rtmp_client">readString</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>));
<a class="l" name="634" href="#634">634</a>					}
<a class="l" name="635" href="#635">635</a>					<a href="/source/s?defs=classReferences&amp;project=rtmp_client">classReferences</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<b>new</b> <a href="/source/s?defs=ClassReference&amp;project=rtmp_client">ClassReference</a>(<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>, <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_OBJECT_PROPERTY&amp;project=rtmp_client">TYPE_OBJECT_PROPERTY</a>, <a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a>));
<a class="l" name="636" href="#636">636</a>				}
<a class="l" name="637" href="#637">637</a>				<a class="d" href="#properties">properties</a> = <b>new</b> <a href="/source/s?defs=ObjectMap&amp;project=rtmp_client">ObjectMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="l" name="638" href="#638">638</a>				<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=count&amp;project=rtmp_client">count</a>; i++) {
<a class="l" name="639" href="#639">639</a>					<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=name&amp;project=rtmp_client">name</a> = <a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(i);
<a class="hl" name="640" href="#640">640</a>					<a class="d" href="#properties">properties</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<b>this</b>, <a href="/source/s?defs=getPropertyType&amp;project=rtmp_client">getPropertyType</a>(<a href="/source/s?defs=instance&amp;project=rtmp_client">instance</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>)));
<a class="l" name="641" href="#641">641</a>				}
<a class="l" name="642" href="#642">642</a>				<b>break</b>;
<a class="l" name="643" href="#643">643</a>			<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_OBJECT_EXTERNALIZABLE&amp;project=rtmp_client">TYPE_OBJECT_EXTERNALIZABLE</a>:
<a class="l" name="644" href="#644">644</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Detected: Externalizable type"</span>);
<a class="l" name="645" href="#645">645</a>				<span class="c">// Use custom class to deserialize the object</span>
<a class="l" name="646" href="#646">646</a>				<b>if</b> (<span class="s">""</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>)) {
<a class="l" name="647" href="#647">647</a>					<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"Classname is required to load an Externalizable object"</span>);
<a class="l" name="648" href="#648">648</a>				}
<a class="l" name="649" href="#649">649</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Externalizable class: {}"</span>, <a href="/source/s?defs=className&amp;project=rtmp_client">className</a>);
<a class="hl" name="650" href="#650">650</a>				<b>if</b> (<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>.<a class="d" href="#length">length</a>() == <span class="n">3</span>) {
<a class="l" name="651" href="#651">651</a>					<span class="c">//check for special DS class aliases</span>
<a class="l" name="652" href="#652">652</a>					<a href="/source/s?defs=className&amp;project=rtmp_client">className</a> = <a href="/source/s?defs=classAliases&amp;project=rtmp_client">classAliases</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>);
<a class="l" name="653" href="#653">653</a>				}
<a class="l" name="654" href="#654">654</a>				<a class="d" href="#result">result</a> = <a href="/source/s?defs=newInstance&amp;project=rtmp_client">newInstance</a>(<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>);
<a class="l" name="655" href="#655">655</a>				<b>if</b> (<a class="d" href="#result">result</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="656" href="#656">656</a>					<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<a href="/source/s?defs=format&amp;project=rtmp_client">format</a>(<span class="s">"Could not instantiate class: %s"</span>, <a href="/source/s?defs=className&amp;project=rtmp_client">className</a>));
<a class="l" name="657" href="#657">657</a>				}
<a class="l" name="658" href="#658">658</a>				<b>if</b> (!(<a class="d" href="#result">result</a> <b>instanceof</b> <a href="/source/s?defs=IExternalizable&amp;project=rtmp_client">IExternalizable</a>)) {
<a class="l" name="659" href="#659">659</a>					<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<a href="/source/s?defs=format&amp;project=rtmp_client">format</a>(<span class="s">"Class must implement the IExternalizable interface: %s"</span>,
<a class="hl" name="660" href="#660">660</a>							<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>));
<a class="l" name="661" href="#661">661</a>				}
<a class="l" name="662" href="#662">662</a>				<a href="/source/s?defs=classReferences&amp;project=rtmp_client">classReferences</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<b>new</b> <a href="/source/s?defs=ClassReference&amp;project=rtmp_client">ClassReference</a>(<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>, <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_OBJECT_EXTERNALIZABLE&amp;project=rtmp_client">TYPE_OBJECT_EXTERNALIZABLE</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>));
<a class="l" name="663" href="#663">663</a>				<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=tempRefId&amp;project=rtmp_client">tempRefId</a>, <a class="d" href="#result">result</a>);
<a class="l" name="664" href="#664">664</a>				((<a href="/source/s?defs=IExternalizable&amp;project=rtmp_client">IExternalizable</a>) <a class="d" href="#result">result</a>).<a href="/source/s?defs=readExternal&amp;project=rtmp_client">readExternal</a>(<b>new</b> <a href="/source/s?defs=DataInput&amp;project=rtmp_client">DataInput</a>(<b>this</b>, <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>));
<a class="l" name="665" href="#665">665</a>				<b>break</b>;
<a class="l" name="666" href="#666">666</a>			<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_OBJECT_VALUE&amp;project=rtmp_client">TYPE_OBJECT_VALUE</a>:
<a class="l" name="667" href="#667">667</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Detected: Object value type"</span>);
<a class="l" name="668" href="#668">668</a>				<span class="c">// First, we should read typed (non-dynamic) properties ("sealed traits" according to AMF3 specification).</span>
<a class="l" name="669" href="#669">669</a>				<span class="c">// Property names are stored in the beginning, then values are stored.</span>
<a class="hl" name="670" href="#670">670</a>				<a href="/source/s?defs=count&amp;project=rtmp_client">count</a> = <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt; <span class="n">2</span>;
<a class="l" name="671" href="#671">671</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Count: {}"</span>, <a href="/source/s?defs=count&amp;project=rtmp_client">count</a>);
<a class="l" name="672" href="#672">672</a>				<b>if</b> (<a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="673" href="#673">673</a>					<a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt;(<a href="/source/s?defs=count&amp;project=rtmp_client">count</a>);
<a class="l" name="674" href="#674">674</a>					<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=count&amp;project=rtmp_client">count</a>; i++) {
<a class="l" name="675" href="#675">675</a>						<a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=readString&amp;project=rtmp_client">readString</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>));
<a class="l" name="676" href="#676">676</a>					}
<a class="l" name="677" href="#677">677</a>					<a href="/source/s?defs=classReferences&amp;project=rtmp_client">classReferences</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<b>new</b> <a href="/source/s?defs=ClassReference&amp;project=rtmp_client">ClassReference</a>(<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>, <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_OBJECT_VALUE&amp;project=rtmp_client">TYPE_OBJECT_VALUE</a>, <a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a>));
<a class="l" name="678" href="#678">678</a>				}
<a class="l" name="679" href="#679">679</a>				<span class="c">//use the size of the attributes if we have no count</span>
<a class="hl" name="680" href="#680">680</a>				<b>if</b> (<a href="/source/s?defs=count&amp;project=rtmp_client">count</a> == <span class="n">0</span> &amp;&amp; <a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="681" href="#681">681</a>					<a href="/source/s?defs=count&amp;project=rtmp_client">count</a> = <a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>();
<a class="l" name="682" href="#682">682</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Using class attribute size for property count: {}"</span>, <a href="/source/s?defs=count&amp;project=rtmp_client">count</a>);
<a class="l" name="683" href="#683">683</a>					<span class="c">//read the attributes from the stream and log if count doesnt match</span>
<a class="l" name="684" href="#684">684</a>					<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt; <a href="/source/s?defs=tmpAttributes&amp;project=rtmp_client">tmpAttributes</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt;(<a href="/source/s?defs=count&amp;project=rtmp_client">count</a>);
<a class="l" name="685" href="#685">685</a>					<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=count&amp;project=rtmp_client">count</a>; i++) {
<a class="l" name="686" href="#686">686</a>						<a href="/source/s?defs=tmpAttributes&amp;project=rtmp_client">tmpAttributes</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=readString&amp;project=rtmp_client">readString</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>));
<a class="l" name="687" href="#687">687</a>					}
<a class="l" name="688" href="#688">688</a>					<b>if</b> (<a href="/source/s?defs=count&amp;project=rtmp_client">count</a> != <a href="/source/s?defs=tmpAttributes&amp;project=rtmp_client">tmpAttributes</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>()) {
<a class="l" name="689" href="#689">689</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Count and attributes length does not match!"</span>);
<a class="hl" name="690" href="#690">690</a>					}
<a class="l" name="691" href="#691">691</a>					<a href="/source/s?defs=classReferences&amp;project=rtmp_client">classReferences</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<b>new</b> <a href="/source/s?defs=ClassReference&amp;project=rtmp_client">ClassReference</a>(<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>, <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_OBJECT_VALUE&amp;project=rtmp_client">TYPE_OBJECT_VALUE</a>, <a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a>));
<a class="l" name="692" href="#692">692</a>				}
<a class="l" name="693" href="#693">693</a>
<a class="l" name="694" href="#694">694</a>				<a class="d" href="#properties">properties</a> = <b>new</b> <a href="/source/s?defs=ObjectMap&amp;project=rtmp_client">ObjectMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="l" name="695" href="#695">695</a>				<b>for</b> (<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=key&amp;project=rtmp_client">key</a> : <a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a>) {
<a class="l" name="696" href="#696">696</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Looking for property: {}"</span>, <a href="/source/s?defs=key&amp;project=rtmp_client">key</a>);
<a class="l" name="697" href="#697">697</a>					<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<b>this</b>, <a href="/source/s?defs=getPropertyType&amp;project=rtmp_client">getPropertyType</a>(<a href="/source/s?defs=instance&amp;project=rtmp_client">instance</a>, <a href="/source/s?defs=key&amp;project=rtmp_client">key</a>));
<a class="l" name="698" href="#698">698</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Key: {} Value: {}"</span>, <a href="/source/s?defs=key&amp;project=rtmp_client">key</a>, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="699" href="#699">699</a>					<a class="d" href="#properties">properties</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=key&amp;project=rtmp_client">key</a>, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="hl" name="700" href="#700">700</a>				}
<a class="l" name="701" href="#701">701</a>
<a class="l" name="702" href="#702">702</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Buffer - position: {} limit: {}"</span>, <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(), <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>());
<a class="l" name="703" href="#703">703</a>				<span class="c">//no more items to read if we are at the end of the buffer</span>
<a class="l" name="704" href="#704">704</a>				<b>if</b> (<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() &lt; <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>()) {
<a class="l" name="705" href="#705">705</a>					<span class="c">// Now we should read dynamic properties which are stored as name-value pairs.</span>
<a class="l" name="706" href="#706">706</a>					<span class="c">// Dynamic properties are NOT remembered in 'classReferences'.</span>
<a class="l" name="707" href="#707">707</a>					<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=key&amp;project=rtmp_client">key</a> = <a href="/source/s?defs=readString&amp;project=rtmp_client">readString</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>);
<a class="l" name="708" href="#708">708</a>					<b>while</b> (!<span class="s">""</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=key&amp;project=rtmp_client">key</a>)) {
<a class="l" name="709" href="#709">709</a>						<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<b>this</b>, <a href="/source/s?defs=getPropertyType&amp;project=rtmp_client">getPropertyType</a>(<a href="/source/s?defs=instance&amp;project=rtmp_client">instance</a>, <a href="/source/s?defs=key&amp;project=rtmp_client">key</a>));
<a class="hl" name="710" href="#710">710</a>						<a class="d" href="#properties">properties</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=key&amp;project=rtmp_client">key</a>, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="711" href="#711">711</a>						<a href="/source/s?defs=key&amp;project=rtmp_client">key</a> = <a href="/source/s?defs=readString&amp;project=rtmp_client">readString</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>);
<a class="l" name="712" href="#712">712</a>					}
<a class="l" name="713" href="#713">713</a>				}
<a class="l" name="714" href="#714">714</a>				<b>break</b>;
<a class="l" name="715" href="#715">715</a>			<b>default</b>:
<a class="l" name="716" href="#716">716</a>			<b>case</b> <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_OBJECT_PROXY&amp;project=rtmp_client">TYPE_OBJECT_PROXY</a>:
<a class="l" name="717" href="#717">717</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Detected: Object proxy type"</span>);
<a class="l" name="718" href="#718">718</a>				<b>if</b> (<span class="s">""</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>)) {
<a class="l" name="719" href="#719">719</a>					<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"Classname is required to load an Externalizable object"</span>);
<a class="hl" name="720" href="#720">720</a>				}
<a class="l" name="721" href="#721">721</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Externalizable class: {}"</span>, <a href="/source/s?defs=className&amp;project=rtmp_client">className</a>);
<a class="l" name="722" href="#722">722</a>				<a class="d" href="#result">result</a> = <a href="/source/s?defs=newInstance&amp;project=rtmp_client">newInstance</a>(<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>);
<a class="l" name="723" href="#723">723</a>				<b>if</b> (<a class="d" href="#result">result</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="724" href="#724">724</a>					<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<a href="/source/s?defs=format&amp;project=rtmp_client">format</a>(<span class="s">"Could not instantiate class: %s"</span>, <a href="/source/s?defs=className&amp;project=rtmp_client">className</a>));
<a class="l" name="725" href="#725">725</a>				}
<a class="l" name="726" href="#726">726</a>				<b>if</b> (!(<a class="d" href="#result">result</a> <b>instanceof</b> <a href="/source/s?defs=IExternalizable&amp;project=rtmp_client">IExternalizable</a>)) {
<a class="l" name="727" href="#727">727</a>					<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<a href="/source/s?defs=format&amp;project=rtmp_client">format</a>(<span class="s">"Class must implement the IExternalizable interface: %s"</span>,
<a class="l" name="728" href="#728">728</a>							<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>));
<a class="l" name="729" href="#729">729</a>				}
<a class="hl" name="730" href="#730">730</a>				<a href="/source/s?defs=classReferences&amp;project=rtmp_client">classReferences</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<b>new</b> <a href="/source/s?defs=ClassReference&amp;project=rtmp_client">ClassReference</a>(<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>, <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=TYPE_OBJECT_PROXY&amp;project=rtmp_client">TYPE_OBJECT_PROXY</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>));
<a class="l" name="731" href="#731">731</a>				<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=tempRefId&amp;project=rtmp_client">tempRefId</a>, <a class="d" href="#result">result</a>);
<a class="l" name="732" href="#732">732</a>				((<a href="/source/s?defs=IExternalizable&amp;project=rtmp_client">IExternalizable</a>) <a class="d" href="#result">result</a>).<a href="/source/s?defs=readExternal&amp;project=rtmp_client">readExternal</a>(<b>new</b> <a href="/source/s?defs=DataInput&amp;project=rtmp_client">DataInput</a>(<b>this</b>, <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>));
<a class="l" name="733" href="#733">733</a>		}
<a class="l" name="734" href="#734">734</a>		<a class="d" href="#amf3_mode">amf3_mode</a> -= <span class="n">1</span>;
<a class="l" name="735" href="#735">735</a>
<a class="l" name="736" href="#736">736</a>		<b>if</b> (<a class="d" href="#result">result</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="737" href="#737">737</a>			<span class="c">// Create result object based on classname</span>
<a class="l" name="738" href="#738">738</a>			<b>if</b> (<span class="s">""</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>)) {
<a class="l" name="739" href="#739">739</a>				<span class="c">// "anonymous" object, load as Map</span>
<a class="hl" name="740" href="#740">740</a>				<span class="c">// Resolve circular references</span>
<a class="l" name="741" href="#741">741</a>				<b>for</b> (<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>.<a href="/source/s?defs=Entry&amp;project=rtmp_client">Entry</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a> : <a class="d" href="#properties">properties</a>.<a href="/source/s?defs=entrySet&amp;project=rtmp_client">entrySet</a>()) {
<a class="l" name="742" href="#742">742</a>					<b>if</b> (<a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a>.<a href="/source/s?defs=getValue&amp;project=rtmp_client">getValue</a>() == <a href="/source/s?defs=pending&amp;project=rtmp_client">pending</a>) {
<a class="l" name="743" href="#743">743</a>						<a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a>.<a href="/source/s?defs=setValue&amp;project=rtmp_client">setValue</a>(<a class="d" href="#properties">properties</a>);
<a class="l" name="744" href="#744">744</a>					}
<a class="l" name="745" href="#745">745</a>				}
<a class="l" name="746" href="#746">746</a>
<a class="l" name="747" href="#747">747</a>				<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=tempRefId&amp;project=rtmp_client">tempRefId</a>, <a class="d" href="#properties">properties</a>);
<a class="l" name="748" href="#748">748</a>				<a class="d" href="#result">result</a> = <a class="d" href="#properties">properties</a>;
<a class="l" name="749" href="#749">749</a>			} <b>else</b> <b>if</b> (<span class="s">"RecordSet"</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>)) {
<a class="hl" name="750" href="#750">750</a>				<span class="c">// TODO: how are RecordSet objects encoded?</span>
<a class="l" name="751" href="#751">751</a>				<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"Objects of type RecordSet not supported yet."</span>);
<a class="l" name="752" href="#752">752</a>			} <b>else</b> <b>if</b> (<span class="s">"RecordSetPage"</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>)) {
<a class="l" name="753" href="#753">753</a>				<span class="c">// TODO: how are RecordSetPage objects encoded?</span>
<a class="l" name="754" href="#754">754</a>				<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"Objects of type RecordSetPage not supported yet."</span>);
<a class="l" name="755" href="#755">755</a>			} <b>else</b> {
<a class="l" name="756" href="#756">756</a>				<span class="c">// Apply properties to object</span>
<a class="l" name="757" href="#757">757</a>				<a class="d" href="#result">result</a> = <a href="/source/s?defs=newInstance&amp;project=rtmp_client">newInstance</a>(<a href="/source/s?defs=className&amp;project=rtmp_client">className</a>);
<a class="l" name="758" href="#758">758</a>				<b>if</b> (<a class="d" href="#result">result</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="759" href="#759">759</a>					<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=tempRefId&amp;project=rtmp_client">tempRefId</a>, <a class="d" href="#result">result</a>);
<a class="hl" name="760" href="#760">760</a>					<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a> <a href="/source/s?defs=resultClass&amp;project=rtmp_client">resultClass</a> = <a class="d" href="#result">result</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>();
<a class="l" name="761" href="#761">761</a>					<a href="/source/s?defs=pending&amp;project=rtmp_client">pending</a>.<a class="d" href="#resolveProperties">resolveProperties</a>(<a class="d" href="#result">result</a>);
<a class="l" name="762" href="#762">762</a>					<b>for</b> (<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>.<a href="/source/s?defs=Entry&amp;project=rtmp_client">Entry</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a> : <a class="d" href="#properties">properties</a>.<a href="/source/s?defs=entrySet&amp;project=rtmp_client">entrySet</a>()) {
<a class="l" name="763" href="#763">763</a>						<span class="c">// Resolve circular references</span>
<a class="l" name="764" href="#764">764</a>						<b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=key&amp;project=rtmp_client">key</a> = <a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a>.<a href="/source/s?defs=getKey&amp;project=rtmp_client">getKey</a>();
<a class="l" name="765" href="#765">765</a>						<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a>.<a href="/source/s?defs=getValue&amp;project=rtmp_client">getValue</a>();
<a class="l" name="766" href="#766">766</a>						<b>if</b> (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> == <a href="/source/s?defs=pending&amp;project=rtmp_client">pending</a>) {
<a class="l" name="767" href="#767">767</a>							<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a class="d" href="#result">result</a>;
<a class="l" name="768" href="#768">768</a>						}
<a class="l" name="769" href="#769">769</a>
<a class="hl" name="770" href="#770">770</a>						<b>if</b> (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> <b>instanceof</b> <a class="d" href="#PendingObject">PendingObject</a>) {
<a class="l" name="771" href="#771">771</a>							<span class="c">// Defer setting of value until real object is created</span>
<a class="l" name="772" href="#772">772</a>							((<a class="d" href="#PendingObject">PendingObject</a>) <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>).<a class="d" href="#addPendingProperty">addPendingProperty</a>(<a class="d" href="#result">result</a>, <a href="/source/s?defs=resultClass&amp;project=rtmp_client">resultClass</a>, <a href="/source/s?defs=key&amp;project=rtmp_client">key</a>);
<a class="l" name="773" href="#773">773</a>							<b>continue</b>;
<a class="l" name="774" href="#774">774</a>						}
<a class="l" name="775" href="#775">775</a>
<a class="l" name="776" href="#776">776</a>						<b>if</b> (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="777" href="#777">777</a>							<b>try</b> {
<a class="l" name="778" href="#778">778</a>								<b>final</b> <a href="/source/s?defs=Field&amp;project=rtmp_client">Field</a> <a href="/source/s?defs=field&amp;project=rtmp_client">field</a> = <a href="/source/s?defs=resultClass&amp;project=rtmp_client">resultClass</a>.<a href="/source/s?defs=getField&amp;project=rtmp_client">getField</a>(<a href="/source/s?defs=key&amp;project=rtmp_client">key</a>);
<a class="l" name="779" href="#779">779</a>								<b>final</b> <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a> <a href="/source/s?defs=fieldType&amp;project=rtmp_client">fieldType</a> = <a href="/source/s?defs=field&amp;project=rtmp_client">field</a>.<a href="/source/s?defs=getType&amp;project=rtmp_client">getType</a>();
<a class="hl" name="780" href="#780">780</a>								<b>if</b> (!<a href="/source/s?defs=fieldType&amp;project=rtmp_client">fieldType</a>.<a href="/source/s?defs=isAssignableFrom&amp;project=rtmp_client">isAssignableFrom</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>())) {
<a class="l" name="781" href="#781">781</a>									<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a href="/source/s?defs=ConversionUtils&amp;project=rtmp_client">ConversionUtils</a>.<a href="/source/s?defs=convert&amp;project=rtmp_client">convert</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>, <a href="/source/s?defs=fieldType&amp;project=rtmp_client">fieldType</a>);
<a class="l" name="782" href="#782">782</a>								} <b>else</b> <b>if</b> (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> <b>instanceof</b> <a href="/source/s?defs=Enum&amp;project=rtmp_client">Enum</a>) {
<a class="l" name="783" href="#783">783</a>									<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a href="/source/s?defs=Enum&amp;project=rtmp_client">Enum</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=fieldType&amp;project=rtmp_client">fieldType</a>, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>());
<a class="l" name="784" href="#784">784</a>								}
<a class="l" name="785" href="#785">785</a>								<a href="/source/s?defs=field&amp;project=rtmp_client">field</a>.<a href="/source/s?defs=set&amp;project=rtmp_client">set</a>(<a class="d" href="#result">result</a>, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="786" href="#786">786</a>							} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="787" href="#787">787</a><span class="c">//								try {</span>
<a class="l" name="788" href="#788">788</a><span class="c">////									BeanUtils.setProperty(result, key, value);</span>
<a class="l" name="789" href="#789">789</a><span class="c">////								} catch (IllegalAccessException ex) {</span>
<a class="hl" name="790" href="#790">790</a><span class="c">////									log.warn("Error mapping key: {} value: {}", key, value);</span>
<a class="l" name="791" href="#791">791</a><span class="c">//								} catch (InvocationTargetException ex) {</span>
<a class="l" name="792" href="#792">792</a><span class="c">//									log.warn("Error mapping key: {} value: {}", key, value);</span>
<a class="l" name="793" href="#793">793</a><span class="c">//								}</span>
<a class="l" name="794" href="#794">794</a>							}
<a class="l" name="795" href="#795">795</a>						} <b>else</b> {
<a class="l" name="796" href="#796">796</a>							<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Skipping null property: {}"</span>, <a href="/source/s?defs=key&amp;project=rtmp_client">key</a>);
<a class="l" name="797" href="#797">797</a>						}
<a class="l" name="798" href="#798">798</a>					}
<a class="l" name="799" href="#799">799</a>				} <span class="c">// else fall through</span>
<a class="hl" name="800" href="#800">800</a>			}
<a class="l" name="801" href="#801">801</a>		}
<a class="l" name="802" href="#802">802</a>		<b>return</b> <a class="d" href="#result">result</a>;
<a class="l" name="803" href="#803">803</a>	}
<a class="l" name="804" href="#804">804</a>
<a class="l" name="805" href="#805">805</a>	<b>public</b> <a href="/source/s?defs=ByteArray&amp;project=rtmp_client">ByteArray</a> <a class="xmt" name="readByteArray"/><a href="/source/s?refs=readByteArray&amp;project=rtmp_client" class="xmt">readByteArray</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="806" href="#806">806</a>		<b>int</b> <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <a class="d" href="#readAMF3Integer">readAMF3Integer</a>();
<a class="l" name="807" href="#807">807</a>		<b>if</b> ((<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &amp; <span class="n">1</span>) == <span class="n">0</span>) {
<a class="l" name="808" href="#808">808</a>			<span class="c">// Reference</span>
<a class="l" name="809" href="#809">809</a>			<b>return</b> (<a href="/source/s?defs=ByteArray&amp;project=rtmp_client">ByteArray</a>) <a href="/source/s?defs=getReference&amp;project=rtmp_client">getReference</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt; <span class="n">1</span>);
<a class="hl" name="810" href="#810">810</a>		}
<a class="l" name="811" href="#811">811</a>
<a class="l" name="812" href="#812">812</a>		<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt;= <span class="n">1</span>;
<a class="l" name="813" href="#813">813</a>		<a href="/source/s?defs=ByteArray&amp;project=rtmp_client">ByteArray</a> <a class="d" href="#result">result</a> = <b>new</b> <a href="/source/s?defs=ByteArray&amp;project=rtmp_client">ByteArray</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>, <a href="/source/s?defs=type&amp;project=rtmp_client">type</a>);
<a class="l" name="814" href="#814">814</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a class="d" href="#result">result</a>);
<a class="l" name="815" href="#815">815</a>		<b>return</b> <a class="d" href="#result">result</a>;
<a class="l" name="816" href="#816">816</a>	}
<a class="l" name="817" href="#817">817</a>
<a class="l" name="818" href="#818">818</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unchecked"</span>)
<a class="l" name="819" href="#819">819</a>	<b>public</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt; <a class="xmt" name="readVectorInt"/><a href="/source/s?refs=readVectorInt&amp;project=rtmp_client" class="xmt">readVectorInt</a>() {
<a class="hl" name="820" href="#820">820</a>		<b>int</b> <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <a class="d" href="#readAMF3Integer">readAMF3Integer</a>();
<a class="l" name="821" href="#821">821</a>		<b>if</b> ((<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &amp; <span class="n">1</span>) == <span class="n">0</span>) {
<a class="l" name="822" href="#822">822</a>			<b>return</b> (<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt;) <a href="/source/s?defs=getReference&amp;project=rtmp_client">getReference</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt; <span class="n">1</span>);
<a class="l" name="823" href="#823">823</a>		}
<a class="l" name="824" href="#824">824</a>
<a class="l" name="825" href="#825">825</a>		<b>int</b> <a href="/source/s?defs=len&amp;project=rtmp_client">len</a> = <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt; <span class="n">1</span>;
<a class="l" name="826" href="#826">826</a>		<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt; <a href="/source/s?defs=array&amp;project=rtmp_client">array</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt;(<a href="/source/s?defs=len&amp;project=rtmp_client">len</a>);
<a class="l" name="827" href="#827">827</a>
<a class="l" name="828" href="#828">828</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>);
<a class="l" name="829" href="#829">829</a>
<a class="hl" name="830" href="#830">830</a>		@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unused"</span>)
<a class="l" name="831" href="#831">831</a>		<b>int</b> <a href="/source/s?defs=ref2&amp;project=rtmp_client">ref2</a> = <a class="d" href="#readAMF3Integer">readAMF3Integer</a>();
<a class="l" name="832" href="#832">832</a>		<b>for</b> (<b>int</b> j = <span class="n">0</span>; j &lt; <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>; ++j) {
<a class="l" name="833" href="#833">833</a>			<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>());
<a class="l" name="834" href="#834">834</a>		}
<a class="l" name="835" href="#835">835</a>
<a class="l" name="836" href="#836">836</a>		<b>return</b> <a href="/source/s?defs=array&amp;project=rtmp_client">array</a>;
<a class="l" name="837" href="#837">837</a>	}
<a class="l" name="838" href="#838">838</a>
<a class="l" name="839" href="#839">839</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unchecked"</span>)
<a class="hl" name="840" href="#840">840</a>	<b>public</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt; <a class="xmt" name="readVectorUInt"/><a href="/source/s?refs=readVectorUInt&amp;project=rtmp_client" class="xmt">readVectorUInt</a>() {
<a class="l" name="841" href="#841">841</a>		<b>int</b> <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <a class="d" href="#readAMF3Integer">readAMF3Integer</a>();
<a class="l" name="842" href="#842">842</a>		<b>if</b> ((<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &amp; <span class="n">1</span>) == <span class="n">0</span>) {
<a class="l" name="843" href="#843">843</a>			<b>return</b> (<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt;) <a href="/source/s?defs=getReference&amp;project=rtmp_client">getReference</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt; <span class="n">1</span>);
<a class="l" name="844" href="#844">844</a>		}
<a class="l" name="845" href="#845">845</a>
<a class="l" name="846" href="#846">846</a>		<b>int</b> <a href="/source/s?defs=len&amp;project=rtmp_client">len</a> = <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt; <span class="n">1</span>;
<a class="l" name="847" href="#847">847</a>		<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt; <a href="/source/s?defs=array&amp;project=rtmp_client">array</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>&gt;(<a href="/source/s?defs=len&amp;project=rtmp_client">len</a>);
<a class="l" name="848" href="#848">848</a>
<a class="l" name="849" href="#849">849</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>);
<a class="hl" name="850" href="#850">850</a>
<a class="l" name="851" href="#851">851</a>		@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unused"</span>)
<a class="l" name="852" href="#852">852</a>		<b>int</b> <a href="/source/s?defs=ref2&amp;project=rtmp_client">ref2</a> = <a class="d" href="#readAMF3Integer">readAMF3Integer</a>();
<a class="l" name="853" href="#853">853</a>		<b>for</b> (<b>int</b> j = <span class="n">0</span>; j &lt; <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>; ++j) {
<a class="l" name="854" href="#854">854</a>			<b>long</b> <a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = (<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xff</span>) &lt;&lt; <span class="n">24L</span>;
<a class="l" name="855" href="#855">855</a>			<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> += (<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xff</span>) &lt;&lt; <span class="n">16L</span>;
<a class="l" name="856" href="#856">856</a>			<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> += (<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xff</span>) &lt;&lt; <span class="n">8L</span>;
<a class="l" name="857" href="#857">857</a>			<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> += (<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xff</span>);
<a class="l" name="858" href="#858">858</a>			<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="859" href="#859">859</a>		}
<a class="hl" name="860" href="#860">860</a>
<a class="l" name="861" href="#861">861</a>		<b>return</b> <a href="/source/s?defs=array&amp;project=rtmp_client">array</a>;
<a class="l" name="862" href="#862">862</a>	}
<a class="l" name="863" href="#863">863</a>
<a class="l" name="864" href="#864">864</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unchecked"</span>)
<a class="l" name="865" href="#865">865</a>	<b>public</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>&gt; <a class="xmt" name="readVectorNumber"/><a href="/source/s?refs=readVectorNumber&amp;project=rtmp_client" class="xmt">readVectorNumber</a>() {
<a class="l" name="866" href="#866">866</a>		<b>int</b> <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <a class="d" href="#readAMF3Integer">readAMF3Integer</a>();
<a class="l" name="867" href="#867">867</a>		<b>if</b> ((<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &amp; <span class="n">1</span>) == <span class="n">0</span>) {
<a class="l" name="868" href="#868">868</a>			<b>return</b> (<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>&gt;) <a href="/source/s?defs=getReference&amp;project=rtmp_client">getReference</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt; <span class="n">1</span>);
<a class="l" name="869" href="#869">869</a>		}
<a class="hl" name="870" href="#870">870</a>
<a class="l" name="871" href="#871">871</a>		<b>int</b> <a href="/source/s?defs=len&amp;project=rtmp_client">len</a> = <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt; <span class="n">1</span>;
<a class="l" name="872" href="#872">872</a>		<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>&gt; <a href="/source/s?defs=array&amp;project=rtmp_client">array</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>&gt;(<a href="/source/s?defs=len&amp;project=rtmp_client">len</a>);
<a class="l" name="873" href="#873">873</a>
<a class="l" name="874" href="#874">874</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>);
<a class="l" name="875" href="#875">875</a>
<a class="l" name="876" href="#876">876</a>		@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unused"</span>)
<a class="l" name="877" href="#877">877</a>		<b>int</b> <a href="/source/s?defs=ref2&amp;project=rtmp_client">ref2</a> = <a class="d" href="#readAMF3Integer">readAMF3Integer</a>();
<a class="l" name="878" href="#878">878</a>		<b>for</b> (<b>int</b> j = <span class="n">0</span>; j &lt; <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>; ++j) {
<a class="l" name="879" href="#879">879</a>			<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=getDouble&amp;project=rtmp_client">getDouble</a>());
<a class="hl" name="880" href="#880">880</a>		}
<a class="l" name="881" href="#881">881</a>
<a class="l" name="882" href="#882">882</a>		<b>return</b> <a href="/source/s?defs=array&amp;project=rtmp_client">array</a>;
<a class="l" name="883" href="#883">883</a>	}
<a class="l" name="884" href="#884">884</a>
<a class="l" name="885" href="#885">885</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unchecked"</span>)
<a class="l" name="886" href="#886">886</a>	<b>public</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xmt" name="readVectorObject"/><a href="/source/s?refs=readVectorObject&amp;project=rtmp_client" class="xmt">readVectorObject</a>() {
<a class="l" name="887" href="#887">887</a>		<b>int</b> <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <a class="d" href="#readAMF3Integer">readAMF3Integer</a>();
<a class="l" name="888" href="#888">888</a>		<b>if</b> ((<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &amp; <span class="n">1</span>) == <span class="n">0</span>) {
<a class="l" name="889" href="#889">889</a>			<b>return</b> (<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;) <a href="/source/s?defs=getReference&amp;project=rtmp_client">getReference</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt; <span class="n">1</span>);
<a class="hl" name="890" href="#890">890</a>		}
<a class="l" name="891" href="#891">891</a>
<a class="l" name="892" href="#892">892</a>		<b>int</b> <a href="/source/s?defs=len&amp;project=rtmp_client">len</a> = <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> &gt;&gt; <span class="n">1</span>;
<a class="l" name="893" href="#893">893</a>		<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=array&amp;project=rtmp_client">array</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;(<a href="/source/s?defs=len&amp;project=rtmp_client">len</a>);
<a class="l" name="894" href="#894">894</a>
<a class="l" name="895" href="#895">895</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>);
<a class="l" name="896" href="#896">896</a>
<a class="l" name="897" href="#897">897</a>		<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a> = <b>new</b> <a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a>();
<a class="l" name="898" href="#898">898</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=object&amp;project=rtmp_client">object</a>;
<a class="l" name="899" href="#899">899</a>
<a class="hl" name="900" href="#900">900</a>		<b>for</b> (<b>int</b> j = <span class="n">0</span>; j &lt; <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>; ++j) {
<a class="l" name="901" href="#901">901</a>			<a href="/source/s?defs=object&amp;project=rtmp_client">object</a> = <a class="d" href="#readObject">readObject</a>(<a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="902" href="#902">902</a>			<a href="/source/s?defs=array&amp;project=rtmp_client">array</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>);
<a class="l" name="903" href="#903">903</a>		}
<a class="l" name="904" href="#904">904</a>
<a class="l" name="905" href="#905">905</a>		<b>return</b> <a href="/source/s?defs=array&amp;project=rtmp_client">array</a>;
<a class="l" name="906" href="#906">906</a>	}
<a class="l" name="907" href="#907">907</a>
<a class="l" name="908" href="#908">908</a>	<span class="c">// Others</span>
<a class="l" name="909" href="#909">909</a>
<a class="hl" name="910" href="#910">910</a>	<span class="c">/**
<a class="l" name="911" href="#911">911</a>	 * Reads Custom
<a class="l" name="912" href="#912">912</a>	 *
<a class="l" name="913" href="#913">913</a>	 * <strong>@return</strong> Object     Custom type object
<a class="l" name="914" href="#914">914</a>	 */</span>
<a class="l" name="915" href="#915">915</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="916" href="#916">916</a>	<b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="readCustom"/><a href="/source/s?refs=readCustom&amp;project=rtmp_client" class="xmt">readCustom</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="917" href="#917">917</a>		<span class="c">// Return null for now</span>
<a class="l" name="918" href="#918">918</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="919" href="#919">919</a>	}
<a class="hl" name="920" href="#920">920</a>
<a class="l" name="921" href="#921">921</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="922" href="#922">922</a>	<b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="readReference"/><a href="/source/s?refs=readReference&amp;project=rtmp_client" class="xmt">readReference</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="923" href="#923">923</a>		<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"AMF3 doesn't support direct references."</span>);
<a class="l" name="924" href="#924">924</a>	}
<a class="l" name="925" href="#925">925</a>
<a class="l" name="926" href="#926">926</a>	<span class="c">/**
<a class="l" name="927" href="#927">927</a>	 * Resets map
<a class="l" name="928" href="#928">928</a>	 */</span>
<a class="l" name="929" href="#929">929</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="hl" name="930" href="#930">930</a>	<b>public</b> <b>void</b> <a class="xmt" name="reset"/><a href="/source/s?refs=reset&amp;project=rtmp_client" class="xmt">reset</a>() {
<a class="l" name="931" href="#931">931</a>		<b>super</b>.<a class="d" href="#reset">reset</a>();
<a class="l" name="932" href="#932">932</a>		<a href="/source/s?defs=stringReferences&amp;project=rtmp_client">stringReferences</a>.<a href="/source/s?defs=clear&amp;project=rtmp_client">clear</a>();
<a class="l" name="933" href="#933">933</a>	}
<a class="l" name="934" href="#934">934</a>
<a class="l" name="935" href="#935">935</a>	<span class="c">/**
<a class="l" name="936" href="#936">936</a>	 * Parser of AMF3 "compressed" integer data type
<a class="l" name="937" href="#937">937</a>	 *
<a class="l" name="938" href="#938">938</a>	 * <strong>@return</strong> a converted integer value
<a class="l" name="939" href="#939">939</a>	 * <strong>@see</strong> &lt;a href="<a href="http://osflash.org/amf3/parsing_integers">http://osflash.org/amf3/parsing_integers</a>"&gt;parsing AMF3
<a class="hl" name="940" href="#940">940</a>	 *      integers (external)&lt;/a&gt;
<a class="l" name="941" href="#941">941</a>	 */</span>
<a class="l" name="942" href="#942">942</a>	<b>private</b> <b>int</b> <a class="xmt" name="readAMF3Integer"/><a href="/source/s?refs=readAMF3Integer&amp;project=rtmp_client" class="xmt">readAMF3Integer</a>() {
<a class="l" name="943" href="#943">943</a>		<b>int</b> n = <span class="n">0</span>;
<a class="l" name="944" href="#944">944</a>		<b>int</b> b = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="945" href="#945">945</a>		<b>int</b> <a class="d" href="#result">result</a> = <span class="n">0</span>;
<a class="l" name="946" href="#946">946</a>
<a class="l" name="947" href="#947">947</a>		<b>while</b> ((b &amp; <span class="n">0x80</span>) != <span class="n">0</span> &amp;&amp; n &lt; <span class="n">3</span>) {
<a class="l" name="948" href="#948">948</a>			<a class="d" href="#result">result</a> &lt;&lt;= <span class="n">7</span>;
<a class="l" name="949" href="#949">949</a>			<a class="d" href="#result">result</a> |= (b &amp; <span class="n">0x7f</span>);
<a class="hl" name="950" href="#950">950</a>			b = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="951" href="#951">951</a>			n++;
<a class="l" name="952" href="#952">952</a>		}
<a class="l" name="953" href="#953">953</a>		<b>if</b> (n &lt; <span class="n">3</span>) {
<a class="l" name="954" href="#954">954</a>			<a class="d" href="#result">result</a> &lt;&lt;= <span class="n">7</span>;
<a class="l" name="955" href="#955">955</a>			<a class="d" href="#result">result</a> |= b;
<a class="l" name="956" href="#956">956</a>		} <b>else</b> {
<a class="l" name="957" href="#957">957</a>			<span class="c">/* Use all 8 bits from the 4th byte */</span>
<a class="l" name="958" href="#958">958</a>			<a class="d" href="#result">result</a> &lt;&lt;= <span class="n">8</span>;
<a class="l" name="959" href="#959">959</a>			<a class="d" href="#result">result</a> |= b &amp; <span class="n">0x0ff</span>;
<a class="hl" name="960" href="#960">960</a>
<a class="l" name="961" href="#961">961</a>			<span class="c">/* Check if the integer should be negative */</span>
<a class="l" name="962" href="#962">962</a>			<b>if</b> ((<a class="d" href="#result">result</a> &amp; <span class="n">0x10000000</span>) != <span class="n">0</span>) {
<a class="l" name="963" href="#963">963</a>				<span class="c">/* and extend the sign bit */</span>
<a class="l" name="964" href="#964">964</a>				<a class="d" href="#result">result</a> |= <span class="n">0xe0000000</span>;
<a class="l" name="965" href="#965">965</a>			}
<a class="l" name="966" href="#966">966</a>		}
<a class="l" name="967" href="#967">967</a>
<a class="l" name="968" href="#968">968</a>		<b>return</b> <a class="d" href="#result">result</a>;
<a class="l" name="969" href="#969">969</a>	}
<a class="hl" name="970" href="#970">970</a>
<a class="l" name="971" href="#971">971</a>	<span class="c">//Read UInt29 style</span>
<a class="l" name="972" href="#972">972</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unused"</span>)
<a class="l" name="973" href="#973">973</a>	<b>private</b> <b>int</b> <a class="xmt" name="readAMF3IntegerNew"/><a href="/source/s?refs=readAMF3IntegerNew&amp;project=rtmp_client" class="xmt">readAMF3IntegerNew</a>() {
<a class="l" name="974" href="#974">974</a>		<b>int</b> b = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xFF</span>;
<a class="l" name="975" href="#975">975</a>		<b>if</b> (b &lt; <span class="n">128</span>) {
<a class="l" name="976" href="#976">976</a>			<b>return</b> b;
<a class="l" name="977" href="#977">977</a>		}
<a class="l" name="978" href="#978">978</a>		<b>int</b> <a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = (b &amp; <span class="n">0x7F</span>) &lt;&lt; <span class="n">7</span>;
<a class="l" name="979" href="#979">979</a>		b = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xFF</span>;
<a class="hl" name="980" href="#980">980</a>		<b>if</b> (b &lt; <span class="n">128</span>) {
<a class="l" name="981" href="#981">981</a>			<b>return</b> (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> | b);
<a class="l" name="982" href="#982">982</a>		}
<a class="l" name="983" href="#983">983</a>		<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> | b &amp; <span class="n">0x7F</span>) &lt;&lt; <span class="n">7</span>;
<a class="l" name="984" href="#984">984</a>		b = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xFF</span>;
<a class="l" name="985" href="#985">985</a>		<b>if</b> (b &lt; <span class="n">128</span>) {
<a class="l" name="986" href="#986">986</a>			<b>return</b> (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> | b);
<a class="l" name="987" href="#987">987</a>		}
<a class="l" name="988" href="#988">988</a>		<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> | b &amp; <span class="n">0x7F</span>) &lt;&lt; <span class="n">8</span>;
<a class="l" name="989" href="#989">989</a>		b = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xFF</span>;
<a class="hl" name="990" href="#990">990</a>		<b>return</b> (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> | b);
<a class="l" name="991" href="#991">991</a>	}
<a class="l" name="992" href="#992">992</a>
<a class="l" name="993" href="#993">993</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="994" href="#994">994</a>	<b>public</b> <a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a> <a class="xmt" name="readXML"/><a href="/source/s?refs=readXML&amp;project=rtmp_client" class="xmt">readXML</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>) {
<a class="l" name="995" href="#995">995</a>		<b>int</b> <a href="/source/s?defs=len&amp;project=rtmp_client">len</a> = <a class="d" href="#readAMF3Integer">readAMF3Integer</a>();
<a class="l" name="996" href="#996">996</a>		<b>if</b> (<a href="/source/s?defs=len&amp;project=rtmp_client">len</a> == <span class="n">1</span>) {
<a class="l" name="997" href="#997">997</a>			<span class="c">// Empty string, should not happen</span>
<a class="l" name="998" href="#998">998</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="999" href="#999">999</a>		}
<a class="hl" name="1000" href="#1000">1000</a>		<b>if</b> ((<a href="/source/s?defs=len&amp;project=rtmp_client">len</a> &amp; <span class="n">1</span>) == <span class="n">0</span>) {
<a class="l" name="1001" href="#1001">1001</a>			<span class="c">// Reference</span>
<a class="l" name="1002" href="#1002">1002</a>			<b>return</b> (<a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a>) <a href="/source/s?defs=getReference&amp;project=rtmp_client">getReference</a>(<a href="/source/s?defs=len&amp;project=rtmp_client">len</a> &gt;&gt; <span class="n">1</span>);
<a class="l" name="1003" href="#1003">1003</a>		}
<a class="l" name="1004" href="#1004">1004</a>		<a href="/source/s?defs=len&amp;project=rtmp_client">len</a> &gt;&gt;= <span class="n">1</span>;
<a class="l" name="1005" href="#1005">1005</a>		<b>int</b> <a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>();
<a class="l" name="1006" href="#1006">1006</a>		<b>final</b> <a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a> <a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>();
<a class="l" name="1007" href="#1007">1007</a>		<a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(<a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() + <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>);
<a class="l" name="1008" href="#1008">1008</a>		<b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=xmlString&amp;project=rtmp_client">xmlString</a> = <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=CHARSET&amp;project=rtmp_client">CHARSET</a>.<a href="/source/s?defs=decode&amp;project=rtmp_client">decode</a>(<a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a>).<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>();
<a class="l" name="1009" href="#1009">1009</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>(<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>); <span class="c">// Reset the limit</span>
<a class="hl" name="1010" href="#1010">1010</a>		<a href="/source/s?defs=Document&amp;project=rtmp_client">Document</a> <a href="/source/s?defs=doc&amp;project=rtmp_client">doc</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="1011" href="#1011">1011</a>		<b>try</b> {
<a class="l" name="1012" href="#1012">1012</a>			<a href="/source/s?defs=doc&amp;project=rtmp_client">doc</a> = <a href="/source/s?defs=XMLUtils&amp;project=rtmp_client">XMLUtils</a>.<a href="/source/s?defs=stringToDoc&amp;project=rtmp_client">stringToDoc</a>(<a href="/source/s?defs=xmlString&amp;project=rtmp_client">xmlString</a>);
<a class="l" name="1013" href="#1013">1013</a>		} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> <a href="/source/s?defs=ioex&amp;project=rtmp_client">ioex</a>) {
<a class="l" name="1014" href="#1014">1014</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"IOException converting xml to dom"</span>, <a href="/source/s?defs=ioex&amp;project=rtmp_client">ioex</a>);
<a class="l" name="1015" href="#1015">1015</a>		}
<a class="l" name="1016" href="#1016">1016</a>		<a href="/source/s?defs=storeReference&amp;project=rtmp_client">storeReference</a>(<a href="/source/s?defs=doc&amp;project=rtmp_client">doc</a>);
<a class="l" name="1017" href="#1017">1017</a>		<b>return</b> <a href="/source/s?defs=doc&amp;project=rtmp_client">doc</a>;
<a class="l" name="1018" href="#1018">1018</a>	}
<a class="l" name="1019" href="#1019">1019</a>
<a class="hl" name="1020" href="#1020">1020</a>}
<a class="l" name="1021" href="#1021">1021</a>