<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["AMF3",37]]],["Package","xp",[["org.red5.io.amf3",1]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=charset&amp;project=rtmp_client">charset</a>.<a href="/source/s?defs=Charset&amp;project=rtmp_client">Charset</a>;
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a><span class="c">/**
<a class="l" name="25" href="#25">25</a> * AMF3 data type definitions.
<a class="l" name="26" href="#26">26</a> *
<a class="l" name="27" href="#27">27</a> * For detailed specification please see the link below.
<a class="l" name="28" href="#28">28</a> *
<a class="l" name="29" href="#29">29</a> * <strong>@see</strong> &lt;a href="<a href="http://osflash.org/amf3/index">http://osflash.org/amf3/index</a>"&gt;AMF3 specification (external)&lt;/a&gt;
<a class="hl" name="30" href="#30">30</a> * <strong>@see</strong> &lt;a href="<a href="http://download.macromedia.com/pub/labs/amf/amf3_spec_121207.pdf">http://download.macromedia.com/pub/labs/amf/amf3_spec_121207.pdf</a>"&gt;Official Adobe AMF3 Specification&lt;/a&gt;
<a class="l" name="31" href="#31">31</a> *
<a class="l" name="32" href="#32">32</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="33" href="#33">33</a> * <strong>@author</strong> Luke Hubbard, Codegent Ltd (luke@codegent.com)
<a class="l" name="34" href="#34">34</a> * <strong>@author</strong> Joachim Bauch (jojo@struktur.de)
<a class="l" name="35" href="#35">35</a> * <strong>@author</strong> Paul Gregoire (mondain@gmail.com)
<a class="l" name="36" href="#36">36</a> */</span>
<a class="l" name="37" href="#37">37</a><b>public</b> <b>class</b> <a class="xc" name="AMF3"/><a href="/source/s?refs=AMF3&amp;project=rtmp_client" class="xc">AMF3</a> {
<a class="l" name="38" href="#38">38</a>    <span class="c">/**
<a class="l" name="39" href="#39">39</a>     * UTF-8 is used
<a class="hl" name="40" href="#40">40</a>     */</span>
<a class="l" name="41" href="#41">41</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=Charset&amp;project=rtmp_client">Charset</a> <a class="xfld" name="CHARSET"/><a href="/source/s?refs=CHARSET&amp;project=rtmp_client" class="xfld">CHARSET</a> = <a href="/source/s?defs=Charset&amp;project=rtmp_client">Charset</a>.<a href="/source/s?defs=forName&amp;project=rtmp_client">forName</a>(<span class="s">"UTF-8"</span>);
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a>	<span class="c">/**
<a class="l" name="44" href="#44">44</a>	 * Minimum possible value for integer number encoding.
<a class="l" name="45" href="#45">45</a>	 */</span>
<a class="l" name="46" href="#46">46</a>	<b>public</b> <b>static</b> <b>final</b> <b>long</b> <a class="xfld" name="MIN_INTEGER_VALUE"/><a href="/source/s?refs=MIN_INTEGER_VALUE&amp;project=rtmp_client" class="xfld">MIN_INTEGER_VALUE</a> = -<span class="n">268435456</span>;
<a class="l" name="47" href="#47">47</a>
<a class="l" name="48" href="#48">48</a>	<span class="c">/**
<a class="l" name="49" href="#49">49</a>	 * Maximum possible value for integer number encoding.
<a class="hl" name="50" href="#50">50</a>	 */</span>
<a class="l" name="51" href="#51">51</a>	<b>public</b> <b>static</b> <b>final</b> <b>long</b> <a class="xfld" name="MAX_INTEGER_VALUE"/><a href="/source/s?refs=MAX_INTEGER_VALUE&amp;project=rtmp_client" class="xfld">MAX_INTEGER_VALUE</a> = <span class="n">268435455</span>;
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>    <span class="c">/**
<a class="l" name="54" href="#54">54</a>     * Max string length
<a class="l" name="55" href="#55">55</a>     */</span>
<a class="l" name="56" href="#56">56</a>    <b>public</b> <b>static</b> <b>final</b> <b>int</b> <a class="xfld" name="LONG_STRING_LENGTH"/><a href="/source/s?refs=LONG_STRING_LENGTH&amp;project=rtmp_client" class="xfld">LONG_STRING_LENGTH</a> = <span class="n">65535</span>;
<a class="l" name="57" href="#57">57</a>
<a class="l" name="58" href="#58">58</a>    <span class="c">/**
<a class="l" name="59" href="#59">59</a>     * Undefined marker
<a class="hl" name="60" href="#60">60</a>     */</span>
<a class="l" name="61" href="#61">61</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_UNDEFINED"/><a href="/source/s?refs=TYPE_UNDEFINED&amp;project=rtmp_client" class="xfld">TYPE_UNDEFINED</a> = <span class="n">0x00</span>;
<a class="l" name="62" href="#62">62</a>
<a class="l" name="63" href="#63">63</a>    <span class="c">/**
<a class="l" name="64" href="#64">64</a>     * Null marker
<a class="l" name="65" href="#65">65</a>     */</span>
<a class="l" name="66" href="#66">66</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_NULL"/><a href="/source/s?refs=TYPE_NULL&amp;project=rtmp_client" class="xfld">TYPE_NULL</a> = <span class="n">0x01</span>;
<a class="l" name="67" href="#67">67</a>
<a class="l" name="68" href="#68">68</a>    <span class="c">/**
<a class="l" name="69" href="#69">69</a>     * Boolean false marker
<a class="hl" name="70" href="#70">70</a>     */</span>
<a class="l" name="71" href="#71">71</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_BOOLEAN_FALSE"/><a href="/source/s?refs=TYPE_BOOLEAN_FALSE&amp;project=rtmp_client" class="xfld">TYPE_BOOLEAN_FALSE</a> = <span class="n">0x02</span>;
<a class="l" name="72" href="#72">72</a>
<a class="l" name="73" href="#73">73</a>    <span class="c">/**
<a class="l" name="74" href="#74">74</a>     * Boolean true marker
<a class="l" name="75" href="#75">75</a>     */</span>
<a class="l" name="76" href="#76">76</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_BOOLEAN_TRUE"/><a href="/source/s?refs=TYPE_BOOLEAN_TRUE&amp;project=rtmp_client" class="xfld">TYPE_BOOLEAN_TRUE</a> = <span class="n">0x03</span>;
<a class="l" name="77" href="#77">77</a>
<a class="l" name="78" href="#78">78</a>    <span class="c">/**
<a class="l" name="79" href="#79">79</a>     * Integer marker
<a class="hl" name="80" href="#80">80</a>     */</span>
<a class="l" name="81" href="#81">81</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_INTEGER"/><a href="/source/s?refs=TYPE_INTEGER&amp;project=rtmp_client" class="xfld">TYPE_INTEGER</a> = <span class="n">0x04</span>;
<a class="l" name="82" href="#82">82</a>
<a class="l" name="83" href="#83">83</a>    <span class="c">/**
<a class="l" name="84" href="#84">84</a>     * Number marker
<a class="l" name="85" href="#85">85</a>     */</span>
<a class="l" name="86" href="#86">86</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_NUMBER"/><a href="/source/s?refs=TYPE_NUMBER&amp;project=rtmp_client" class="xfld">TYPE_NUMBER</a> = <span class="n">0x05</span>;
<a class="l" name="87" href="#87">87</a>
<a class="l" name="88" href="#88">88</a>    <span class="c">/**
<a class="l" name="89" href="#89">89</a>     * String marker
<a class="hl" name="90" href="#90">90</a>     */</span>
<a class="l" name="91" href="#91">91</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_STRING"/><a href="/source/s?refs=TYPE_STRING&amp;project=rtmp_client" class="xfld">TYPE_STRING</a> = <span class="n">0x06</span>;
<a class="l" name="92" href="#92">92</a>
<a class="l" name="93" href="#93">93</a>	<span class="c">/**
<a class="l" name="94" href="#94">94</a>	 * XML document marker
<a class="l" name="95" href="#95">95</a>	 * &lt;br /&gt;
<a class="l" name="96" href="#96">96</a>	 * This is for the legacy XMLDocument type is retained in the language
<a class="l" name="97" href="#97">97</a>	 * as <a href="/source/s?path=flash.xml.XML&amp;project=rtmp_client">flash.xml.XML</a>Document. Similar to AMF 0, the structure of an
<a class="l" name="98" href="#98">98</a>	 * XMLDocument needs to be flattened into a string representation for
<a class="l" name="99" href="#99">99</a>	 * serialization. As with other strings in AMF, the content is encoded in
<a class="hl" name="100" href="#100">100</a>	 * UTF-8.
<a class="l" name="101" href="#101">101</a>	 * XMLDocuments can be sent as a reference to a previously occurring
<a class="l" name="102" href="#102">102</a>	 * XMLDocument instance by using an index to the implicit object reference
<a class="l" name="103" href="#103">103</a>	 * table.
<a class="l" name="104" href="#104">104</a>	 */</span>
<a class="l" name="105" href="#105">105</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_XML_DOCUMENT"/><a href="/source/s?refs=TYPE_XML_DOCUMENT&amp;project=rtmp_client" class="xfld">TYPE_XML_DOCUMENT</a> = <span class="n">0x07</span>;
<a class="l" name="106" href="#106">106</a>
<a class="l" name="107" href="#107">107</a>    <span class="c">/**
<a class="l" name="108" href="#108">108</a>     * Date marker
<a class="l" name="109" href="#109">109</a>     */</span>
<a class="hl" name="110" href="#110">110</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_DATE"/><a href="/source/s?refs=TYPE_DATE&amp;project=rtmp_client" class="xfld">TYPE_DATE</a> = <span class="n">0x08</span>;
<a class="l" name="111" href="#111">111</a>
<a class="l" name="112" href="#112">112</a>    <span class="c">/**
<a class="l" name="113" href="#113">113</a>     * Array start marker
<a class="l" name="114" href="#114">114</a>     */</span>
<a class="l" name="115" href="#115">115</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_ARRAY"/><a href="/source/s?refs=TYPE_ARRAY&amp;project=rtmp_client" class="xfld">TYPE_ARRAY</a> = <span class="n">0x09</span>;
<a class="l" name="116" href="#116">116</a>
<a class="l" name="117" href="#117">117</a>    <span class="c">/**
<a class="l" name="118" href="#118">118</a>     * Object start marker
<a class="l" name="119" href="#119">119</a>     */</span>
<a class="hl" name="120" href="#120">120</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_OBJECT"/><a href="/source/s?refs=TYPE_OBJECT&amp;project=rtmp_client" class="xfld">TYPE_OBJECT</a> = <span class="n">0x0A</span>;
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>    <span class="c">/**
<a class="l" name="123" href="#123">123</a>     * XML start marker
<a class="l" name="124" href="#124">124</a>     */</span>
<a class="l" name="125" href="#125">125</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_XML"/><a href="/source/s?refs=TYPE_XML&amp;project=rtmp_client" class="xfld">TYPE_XML</a> = <span class="n">0x0B</span>;
<a class="l" name="126" href="#126">126</a>
<a class="l" name="127" href="#127">127</a>    <span class="c">/**
<a class="l" name="128" href="#128">128</a>     * ByteArray marker
<a class="l" name="129" href="#129">129</a>     */</span>
<a class="hl" name="130" href="#130">130</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_BYTEARRAY"/><a href="/source/s?refs=TYPE_BYTEARRAY&amp;project=rtmp_client" class="xfld">TYPE_BYTEARRAY</a> = <span class="n">0x0C</span>;
<a class="l" name="131" href="#131">131</a>
<a class="l" name="132" href="#132">132</a>    <span class="c">/**
<a class="l" name="133" href="#133">133</a>     * Vector&lt;int&gt; marker
<a class="l" name="134" href="#134">134</a>     */</span>
<a class="l" name="135" href="#135">135</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_VECTOR_INT"/><a href="/source/s?refs=TYPE_VECTOR_INT&amp;project=rtmp_client" class="xfld">TYPE_VECTOR_INT</a> = <span class="n">0x0D</span>;
<a class="l" name="136" href="#136">136</a>
<a class="l" name="137" href="#137">137</a>    <span class="c">/**
<a class="l" name="138" href="#138">138</a>     * Vector&lt;uint&gt; marker
<a class="l" name="139" href="#139">139</a>     */</span>
<a class="hl" name="140" href="#140">140</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_VECTOR_UINT"/><a href="/source/s?refs=TYPE_VECTOR_UINT&amp;project=rtmp_client" class="xfld">TYPE_VECTOR_UINT</a> = <span class="n">0x0E</span>;
<a class="l" name="141" href="#141">141</a>
<a class="l" name="142" href="#142">142</a>    <span class="c">/**
<a class="l" name="143" href="#143">143</a>     * Vector&lt;Number&gt; marker
<a class="l" name="144" href="#144">144</a>     */</span>
<a class="l" name="145" href="#145">145</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_VECTOR_NUMBER"/><a href="/source/s?refs=TYPE_VECTOR_NUMBER&amp;project=rtmp_client" class="xfld">TYPE_VECTOR_NUMBER</a> = <span class="n">0x0F</span>;
<a class="l" name="146" href="#146">146</a>
<a class="l" name="147" href="#147">147</a>    <span class="c">/**
<a class="l" name="148" href="#148">148</a>     * Vector&lt;Object&gt; marker
<a class="l" name="149" href="#149">149</a>     */</span>
<a class="hl" name="150" href="#150">150</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_VECTOR_OBJECT"/><a href="/source/s?refs=TYPE_VECTOR_OBJECT&amp;project=rtmp_client" class="xfld">TYPE_VECTOR_OBJECT</a> = <span class="n">0x10</span>;
<a class="l" name="151" href="#151">151</a>
<a class="l" name="152" href="#152">152</a>    <span class="c">/**
<a class="l" name="153" href="#153">153</a>	 * Property list encoding.
<a class="l" name="154" href="#154">154</a>	 *
<a class="l" name="155" href="#155">155</a>	 * The remaining integer-data represents the number of class members
<a class="l" name="156" href="#156">156</a>	 * that exist. The property names are read as string-data. The values
<a class="l" name="157" href="#157">157</a>	 * are then read as AMF3-data.
<a class="l" name="158" href="#158">158</a>	 */</span>
<a class="l" name="159" href="#159">159</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_OBJECT_PROPERTY"/><a href="/source/s?refs=TYPE_OBJECT_PROPERTY&amp;project=rtmp_client" class="xfld">TYPE_OBJECT_PROPERTY</a> = <span class="n">0x00</span>;
<a class="hl" name="160" href="#160">160</a>
<a class="l" name="161" href="#161">161</a>	<span class="c">/**
<a class="l" name="162" href="#162">162</a>	 * Externalizable object.
<a class="l" name="163" href="#163">163</a>	 *
<a class="l" name="164" href="#164">164</a>	 * What follows is the value of the "inner" object, including type code.
<a class="l" name="165" href="#165">165</a>	 * This value appears for objects that implement IExternalizable, such
<a class="l" name="166" href="#166">166</a>	 * as ArrayCollection and ObjectProxy.
<a class="l" name="167" href="#167">167</a>	 */</span>
<a class="l" name="168" href="#168">168</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_OBJECT_EXTERNALIZABLE"/><a href="/source/s?refs=TYPE_OBJECT_EXTERNALIZABLE&amp;project=rtmp_client" class="xfld">TYPE_OBJECT_EXTERNALIZABLE</a> = <span class="n">0x01</span>;
<a class="l" name="169" href="#169">169</a>
<a class="hl" name="170" href="#170">170</a>	<span class="c">/**
<a class="l" name="171" href="#171">171</a>	 * Name-value encoding.
<a class="l" name="172" href="#172">172</a>	 *
<a class="l" name="173" href="#173">173</a>	 * The property names and values are encoded as string-data followed by
<a class="l" name="174" href="#174">174</a>	 * AMF3-data until there is an empty string property name. If there is
<a class="l" name="175" href="#175">175</a>	 * a class-def reference there are no property names and the number of
<a class="l" name="176" href="#176">176</a>	 * values is equal to the number of properties in the class-def.
<a class="l" name="177" href="#177">177</a>	 */</span>
<a class="l" name="178" href="#178">178</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_OBJECT_VALUE"/><a href="/source/s?refs=TYPE_OBJECT_VALUE&amp;project=rtmp_client" class="xfld">TYPE_OBJECT_VALUE</a> = <span class="n">0x02</span>;
<a class="l" name="179" href="#179">179</a>
<a class="hl" name="180" href="#180">180</a>	<span class="c">/**
<a class="l" name="181" href="#181">181</a>	 * Proxy object.
<a class="l" name="182" href="#182">182</a>	 */</span>
<a class="l" name="183" href="#183">183</a>    <b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="TYPE_OBJECT_PROXY"/><a href="/source/s?refs=TYPE_OBJECT_PROXY&amp;project=rtmp_client" class="xfld">TYPE_OBJECT_PROXY</a> = <span class="n">0x03</span>;
<a class="l" name="184" href="#184">184</a>
<a class="l" name="185" href="#185">185</a>}
<a class="l" name="186" href="#186">186</a>