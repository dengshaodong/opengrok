<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["DataOutput",37]]],["Package","xp",[["org.red5.io.amf3",1]]],["Method","xmt",[["DataOutput",54],["getEndian",61],["setEndian",66],["writeBoolean",71],["writeByte",76],["writeBytes",81],["writeBytes",86],["writeBytes",91],["writeDouble",96],["writeFloat",101],["writeInt",106],["writeMultiByte",111],["writeObject",118],["writeShort",123],["writeUTF",133],["writeUTFBytes",140],["writeUnsignedInt",128]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=ByteOrder&amp;project=rtmp_client">ByteOrder</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=charset&amp;project=rtmp_client">charset</a>.<a href="/source/s?defs=Charset&amp;project=rtmp_client">Charset</a>;
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>;
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a><span class="c">/**
<a class="hl" name="30" href="#30">30</a> * Implementation of the IDataOutput interface. Can be used to store an
<a class="l" name="31" href="#31">31</a> * IExternalizable object.
<a class="l" name="32" href="#32">32</a> *
<a class="l" name="33" href="#33">33</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="34" href="#34">34</a> * <strong>@author</strong> Joachim Bauch (jojo@struktur.de)
<a class="l" name="35" href="#35">35</a> *
<a class="l" name="36" href="#36">36</a> */</span>
<a class="l" name="37" href="#37">37</a><b>public</b> <b>class</b> <a class="xc" name="DataOutput"/><a href="/source/s?refs=DataOutput&amp;project=rtmp_client" class="xc">DataOutput</a> <b>implements</b> <a href="/source/s?defs=IDataOutput&amp;project=rtmp_client">IDataOutput</a> {
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>	<span class="c">/** The output stream. */</span>
<a class="hl" name="40" href="#40">40</a>	<b>private</b> <a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a> <a class="xfld" name="output"/><a href="/source/s?refs=output&amp;project=rtmp_client" class="xfld">output</a>;
<a class="l" name="41" href="#41">41</a>
<a class="l" name="42" href="#42">42</a>	<span class="c">/** The serializer to use. */</span>
<a class="l" name="43" href="#43">43</a>	<b>private</b> <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xfld" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xfld">serializer</a>;
<a class="l" name="44" href="#44">44</a>
<a class="l" name="45" href="#45">45</a>	<span class="c">/** Raw data of output destination. */</span>
<a class="l" name="46" href="#46">46</a>	<b>private</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xfld" name="buffer"/><a href="/source/s?refs=buffer&amp;project=rtmp_client" class="xfld">buffer</a>;
<a class="l" name="47" href="#47">47</a>
<a class="l" name="48" href="#48">48</a>	<span class="c">/**
<a class="l" name="49" href="#49">49</a>	 * Create a new DataOutput.
<a class="hl" name="50" href="#50">50</a>	 *
<a class="l" name="51" href="#51">51</a>	 * <strong>@param</strong> <em>output</em>		destination to write to
<a class="l" name="52" href="#52">52</a>	 * <strong>@param</strong> <em>serializer</em>	the serializer to use
<a class="l" name="53" href="#53">53</a>	 */</span>
<a class="l" name="54" href="#54">54</a>	<b>protected</b> <a class="xmt" name="DataOutput"/><a href="/source/s?refs=DataOutput&amp;project=rtmp_client" class="xmt">DataOutput</a>(<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a> <a class="xa" name="output"/><a href="/source/s?refs=output&amp;project=rtmp_client" class="xa">output</a>, <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xa" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xa">serializer</a>) {
<a class="l" name="55" href="#55">55</a>		<b>this</b>.<a href="/source/s?defs=output&amp;project=rtmp_client">output</a> = <a href="/source/s?defs=output&amp;project=rtmp_client">output</a>;
<a class="l" name="56" href="#56">56</a>		<b>this</b>.<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a> = <a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>;
<a class="l" name="57" href="#57">57</a>		<a class="d" href="#buffer">buffer</a> = <a href="/source/s?defs=output&amp;project=rtmp_client">output</a>.<a href="/source/s?defs=getBuffer&amp;project=rtmp_client">getBuffer</a>();
<a class="l" name="58" href="#58">58</a>	}
<a class="l" name="59" href="#59">59</a>
<a class="hl" name="60" href="#60">60</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="61" href="#61">61</a>	<b>public</b> <a href="/source/s?defs=ByteOrder&amp;project=rtmp_client">ByteOrder</a> <a class="xmt" name="getEndian"/><a href="/source/s?refs=getEndian&amp;project=rtmp_client" class="xmt">getEndian</a>() {
<a class="l" name="62" href="#62">62</a>		<b>return</b> <a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=order&amp;project=rtmp_client">order</a>();
<a class="l" name="63" href="#63">63</a>	}
<a class="l" name="64" href="#64">64</a>
<a class="l" name="65" href="#65">65</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="66" href="#66">66</a>	<b>public</b> <b>void</b> <a class="xmt" name="setEndian"/><a href="/source/s?refs=setEndian&amp;project=rtmp_client" class="xmt">setEndian</a>(<a href="/source/s?defs=ByteOrder&amp;project=rtmp_client">ByteOrder</a> <a class="xa" name="endian"/><a href="/source/s?refs=endian&amp;project=rtmp_client" class="xa">endian</a>) {
<a class="l" name="67" href="#67">67</a>		<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=order&amp;project=rtmp_client">order</a>(<a class="d" href="#endian">endian</a>);
<a class="l" name="68" href="#68">68</a>	}
<a class="l" name="69" href="#69">69</a>
<a class="hl" name="70" href="#70">70</a>    <span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="71" href="#71">71</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeBoolean"/><a href="/source/s?refs=writeBoolean&amp;project=rtmp_client" class="xmt">writeBoolean</a>(<b>boolean</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="72" href="#72">72</a>		<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> ? <span class="n">1</span> : <span class="n">0</span>));
<a class="l" name="73" href="#73">73</a>	}
<a class="l" name="74" href="#74">74</a>
<a class="l" name="75" href="#75">75</a>    <span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="76" href="#76">76</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeByte"/><a href="/source/s?refs=writeByte&amp;project=rtmp_client" class="xmt">writeByte</a>(<b>byte</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="77" href="#77">77</a>		<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="78" href="#78">78</a>	}
<a class="l" name="79" href="#79">79</a>
<a class="hl" name="80" href="#80">80</a>    <span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="81" href="#81">81</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeBytes"/><a href="/source/s?refs=writeBytes&amp;project=rtmp_client" class="xmt">writeBytes</a>(<b>byte</b>[] <a class="xa" name="bytes"/><a href="/source/s?refs=bytes&amp;project=rtmp_client" class="xa">bytes</a>) {
<a class="l" name="82" href="#82">82</a>		<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>);
<a class="l" name="83" href="#83">83</a>	}
<a class="l" name="84" href="#84">84</a>
<a class="l" name="85" href="#85">85</a>    <span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="86" href="#86">86</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeBytes"/><a href="/source/s?refs=writeBytes&amp;project=rtmp_client" class="xmt">writeBytes</a>(<b>byte</b>[] <a class="xa" name="bytes"/><a href="/source/s?refs=bytes&amp;project=rtmp_client" class="xa">bytes</a>, <b>int</b> <a class="xa" name="offset"/><a href="/source/s?refs=offset&amp;project=rtmp_client" class="xa">offset</a>) {
<a class="l" name="87" href="#87">87</a>		<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>, <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>, <a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>.<a class="d" href="#length">length</a> - <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>);
<a class="l" name="88" href="#88">88</a>	}
<a class="l" name="89" href="#89">89</a>
<a class="hl" name="90" href="#90">90</a>    <span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="91" href="#91">91</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeBytes"/><a href="/source/s?refs=writeBytes&amp;project=rtmp_client" class="xmt">writeBytes</a>(<b>byte</b>[] <a class="xa" name="bytes"/><a href="/source/s?refs=bytes&amp;project=rtmp_client" class="xa">bytes</a>, <b>int</b> <a class="xa" name="offset"/><a href="/source/s?refs=offset&amp;project=rtmp_client" class="xa">offset</a>, <b>int</b> <a class="xa" name="length"/><a href="/source/s?refs=length&amp;project=rtmp_client" class="xa">length</a>) {
<a class="l" name="92" href="#92">92</a>		<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>, <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>, <a class="d" href="#length">length</a>);
<a class="l" name="93" href="#93">93</a>	}
<a class="l" name="94" href="#94">94</a>
<a class="l" name="95" href="#95">95</a>    <span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="96" href="#96">96</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeDouble"/><a href="/source/s?refs=writeDouble&amp;project=rtmp_client" class="xmt">writeDouble</a>(<b>double</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="97" href="#97">97</a>		<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=putDouble&amp;project=rtmp_client">putDouble</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="98" href="#98">98</a>	}
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a>    <span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="101" href="#101">101</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeFloat"/><a href="/source/s?refs=writeFloat&amp;project=rtmp_client" class="xmt">writeFloat</a>(<b>float</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="102" href="#102">102</a>		<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=putFloat&amp;project=rtmp_client">putFloat</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="103" href="#103">103</a>	}
<a class="l" name="104" href="#104">104</a>
<a class="l" name="105" href="#105">105</a>    <span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="106" href="#106">106</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeInt"/><a href="/source/s?refs=writeInt&amp;project=rtmp_client" class="xmt">writeInt</a>(<b>int</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="107" href="#107">107</a>		<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="108" href="#108">108</a>	}
<a class="l" name="109" href="#109">109</a>
<a class="hl" name="110" href="#110">110</a>    <span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="111" href="#111">111</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeMultiByte"/><a href="/source/s?refs=writeMultiByte&amp;project=rtmp_client" class="xmt">writeMultiByte</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="encoding"/><a href="/source/s?refs=encoding&amp;project=rtmp_client" class="xa">encoding</a>) {
<a class="l" name="112" href="#112">112</a>		<b>final</b> <a href="/source/s?defs=Charset&amp;project=rtmp_client">Charset</a> <a href="/source/s?defs=cs&amp;project=rtmp_client">cs</a> = <a href="/source/s?defs=Charset&amp;project=rtmp_client">Charset</a>.<a href="/source/s?defs=forName&amp;project=rtmp_client">forName</a>(<a class="d" href="#encoding">encoding</a>);
<a class="l" name="113" href="#113">113</a>		<b>final</b> <a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a> <a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a> = <a href="/source/s?defs=cs&amp;project=rtmp_client">cs</a>.<a href="/source/s?defs=encode&amp;project=rtmp_client">encode</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="114" href="#114">114</a>		<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a>);
<a class="l" name="115" href="#115">115</a>	}
<a class="l" name="116" href="#116">116</a>
<a class="l" name="117" href="#117">117</a>    <span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="118" href="#118">118</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeObject"/><a href="/source/s?refs=writeObject&amp;project=rtmp_client" class="xmt">writeObject</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="119" href="#119">119</a>		<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="hl" name="120" href="#120">120</a>	}
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>    <span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="123" href="#123">123</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeShort"/><a href="/source/s?refs=writeShort&amp;project=rtmp_client" class="xmt">writeShort</a>(<b>short</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="124" href="#124">124</a>		<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=putShort&amp;project=rtmp_client">putShort</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="125" href="#125">125</a>	}
<a class="l" name="126" href="#126">126</a>
<a class="l" name="127" href="#127">127</a>    <span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="128" href="#128">128</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeUnsignedInt"/><a href="/source/s?refs=writeUnsignedInt&amp;project=rtmp_client" class="xmt">writeUnsignedInt</a>(<b>long</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="129" href="#129">129</a>		<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>((<b>int</b>) <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="hl" name="130" href="#130">130</a>	}
<a class="l" name="131" href="#131">131</a>
<a class="l" name="132" href="#132">132</a>    <span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="133" href="#133">133</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeUTF"/><a href="/source/s?refs=writeUTF&amp;project=rtmp_client" class="xmt">writeUTF</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="134" href="#134">134</a>		<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=putShort&amp;project=rtmp_client">putShort</a>((<b>short</b>) <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>.<a class="d" href="#length">length</a>());
<a class="l" name="135" href="#135">135</a>		<b>final</b> <a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a> <a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a> = <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=CHARSET&amp;project=rtmp_client">CHARSET</a>.<a href="/source/s?defs=encode&amp;project=rtmp_client">encode</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="136" href="#136">136</a>		<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a>);
<a class="l" name="137" href="#137">137</a>	}
<a class="l" name="138" href="#138">138</a>
<a class="l" name="139" href="#139">139</a>    <span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="140" href="#140">140</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeUTFBytes"/><a href="/source/s?refs=writeUTFBytes&amp;project=rtmp_client" class="xmt">writeUTFBytes</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="141" href="#141">141</a>		<b>final</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=ByteBuffer&amp;project=rtmp_client">ByteBuffer</a> <a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a> = <a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>.<a href="/source/s?defs=CHARSET&amp;project=rtmp_client">CHARSET</a>.<a href="/source/s?defs=encode&amp;project=rtmp_client">encode</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="142" href="#142">142</a>		<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=strBuf&amp;project=rtmp_client">strBuf</a>);
<a class="l" name="143" href="#143">143</a>	}
<a class="l" name="144" href="#144">144</a>
<a class="l" name="145" href="#145">145</a>}
<a class="l" name="146" href="#146">146</a>