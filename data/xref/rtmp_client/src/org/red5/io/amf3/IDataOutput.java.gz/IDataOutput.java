<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.red5.io.amf3",1]]],["Interface","xi",[["IDataOutput",30]]],["Method","xmt",[["getEndian",37],["setEndian",44],["writeBoolean",51],["writeByte",58],["writeBytes",65],["writeBytes",73],["writeBytes",82],["writeDouble",89],["writeFloat",96],["writeInt",103],["writeMultiByte",111],["writeObject",118],["writeShort",125],["writeUTF",139],["writeUTFBytes",147],["writeUnsignedInt",132]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=ByteOrder&amp;project=rtmp_client">ByteOrder</a>;
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a><span class="c">/**
<a class="l" name="25" href="#25">25</a> * Interface implemented by classes that provide a way to store custom objects.
<a class="l" name="26" href="#26">26</a> *
<a class="l" name="27" href="#27">27</a> * <strong>@see</strong> IExternalizable#writeExternal(IDataOutput)
<a class="l" name="28" href="#28">28</a> * <strong>@see</strong> &lt;a href="<a href="http://livedocs.adobe.com/flex/2/langref/flash/utils/IDataOutput.html">http://livedocs.adobe.com/flex/2/langref/flash/utils/IDataOutput.html</a>"&gt;Adobe Livedocs (external)&lt;/a&gt;
<a class="l" name="29" href="#29">29</a> */</span>
<a class="hl" name="30" href="#30">30</a><b>public</b> <b>interface</b> <a class="xi" name="IDataOutput"/><a href="/source/s?refs=IDataOutput&amp;project=rtmp_client" class="xi">IDataOutput</a> {
<a class="l" name="31" href="#31">31</a>
<a class="l" name="32" href="#32">32</a>	<span class="c">/**
<a class="l" name="33" href="#33">33</a>	 * Return the byteorder used when storing values.
<a class="l" name="34" href="#34">34</a>	 *
<a class="l" name="35" href="#35">35</a>	 * <strong>@return</strong> the byteorder
<a class="l" name="36" href="#36">36</a>	 */</span>
<a class="l" name="37" href="#37">37</a>	<b>public</b> <a href="/source/s?defs=ByteOrder&amp;project=rtmp_client">ByteOrder</a> <a class="xmt" name="getEndian"/><a href="/source/s?refs=getEndian&amp;project=rtmp_client" class="xmt">getEndian</a>();
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>	<span class="c">/**
<a class="hl" name="40" href="#40">40</a>	 * Set the byteorder to use when storing values.
<a class="l" name="41" href="#41">41</a>	 *
<a class="l" name="42" href="#42">42</a>	 * <strong>@param</strong> <em>endian</em> the byteorder to use
<a class="l" name="43" href="#43">43</a>	 */</span>
<a class="l" name="44" href="#44">44</a>	<b>public</b> <b>void</b> <a class="xmt" name="setEndian"/><a href="/source/s?refs=setEndian&amp;project=rtmp_client" class="xmt">setEndian</a>(<a href="/source/s?defs=ByteOrder&amp;project=rtmp_client">ByteOrder</a> <a class="xa" name="endian"/><a href="/source/s?refs=endian&amp;project=rtmp_client" class="xa">endian</a>);
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a>	<span class="c">/**
<a class="l" name="47" href="#47">47</a>	 * Write boolean value.
<a class="l" name="48" href="#48">48</a>	 *
<a class="l" name="49" href="#49">49</a>	 * <strong>@param</strong> <em>value</em> the value
<a class="hl" name="50" href="#50">50</a>	 */</span>
<a class="l" name="51" href="#51">51</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeBoolean"/><a href="/source/s?refs=writeBoolean&amp;project=rtmp_client" class="xmt">writeBoolean</a>(<b>boolean</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>);
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>	<span class="c">/**
<a class="l" name="54" href="#54">54</a>	 * Write signed byte value.
<a class="l" name="55" href="#55">55</a>	 *
<a class="l" name="56" href="#56">56</a>	 * <strong>@param</strong> <em>value</em> the value
<a class="l" name="57" href="#57">57</a>	 */</span>
<a class="l" name="58" href="#58">58</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeByte"/><a href="/source/s?refs=writeByte&amp;project=rtmp_client" class="xmt">writeByte</a>(<b>byte</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>);
<a class="l" name="59" href="#59">59</a>
<a class="hl" name="60" href="#60">60</a>	<span class="c">/**
<a class="l" name="61" href="#61">61</a>	 * Write multiple bytes.
<a class="l" name="62" href="#62">62</a>	 *
<a class="l" name="63" href="#63">63</a>	 * <strong>@param</strong> <em>bytes</em> the bytes
<a class="l" name="64" href="#64">64</a>	 */</span>
<a class="l" name="65" href="#65">65</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeBytes"/><a href="/source/s?refs=writeBytes&amp;project=rtmp_client" class="xmt">writeBytes</a>(<b>byte</b>[] <a class="xa" name="bytes"/><a href="/source/s?refs=bytes&amp;project=rtmp_client" class="xa">bytes</a>);
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a>	<span class="c">/**
<a class="l" name="68" href="#68">68</a>	 * Write multiple bytes from given offset.
<a class="l" name="69" href="#69">69</a>	 *
<a class="hl" name="70" href="#70">70</a>	 * <strong>@param</strong> <em>bytes</em> the bytes
<a class="l" name="71" href="#71">71</a>	 * <strong>@param</strong> <em>offset</em> offset in bytes to start writing from
<a class="l" name="72" href="#72">72</a>	 */</span>
<a class="l" name="73" href="#73">73</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeBytes"/><a href="/source/s?refs=writeBytes&amp;project=rtmp_client" class="xmt">writeBytes</a>(<b>byte</b>[] <a class="xa" name="bytes"/><a href="/source/s?refs=bytes&amp;project=rtmp_client" class="xa">bytes</a>, <b>int</b> <a class="xa" name="offset"/><a href="/source/s?refs=offset&amp;project=rtmp_client" class="xa">offset</a>);
<a class="l" name="74" href="#74">74</a>
<a class="l" name="75" href="#75">75</a>	<span class="c">/**
<a class="l" name="76" href="#76">76</a>	 * Write given number of bytes from given offset.
<a class="l" name="77" href="#77">77</a>	 *
<a class="l" name="78" href="#78">78</a>	 * <strong>@param</strong> <em>bytes</em> the bytes
<a class="l" name="79" href="#79">79</a>	 * <strong>@param</strong> <em>offset</em> offset in bytes to start writing from
<a class="hl" name="80" href="#80">80</a>	 * <strong>@param</strong> <em>length</em> number of bytes to write
<a class="l" name="81" href="#81">81</a>	 */</span>
<a class="l" name="82" href="#82">82</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeBytes"/><a href="/source/s?refs=writeBytes&amp;project=rtmp_client" class="xmt">writeBytes</a>(<b>byte</b>[] <a class="xa" name="bytes"/><a href="/source/s?refs=bytes&amp;project=rtmp_client" class="xa">bytes</a>, <b>int</b> <a class="xa" name="offset"/><a href="/source/s?refs=offset&amp;project=rtmp_client" class="xa">offset</a>, <b>int</b> <a class="xa" name="length"/><a href="/source/s?refs=length&amp;project=rtmp_client" class="xa">length</a>);
<a class="l" name="83" href="#83">83</a>
<a class="l" name="84" href="#84">84</a>	<span class="c">/**
<a class="l" name="85" href="#85">85</a>	 * Write double-precision floating point value.
<a class="l" name="86" href="#86">86</a>	 *
<a class="l" name="87" href="#87">87</a>	 * <strong>@param</strong> <em>value</em> the value
<a class="l" name="88" href="#88">88</a>	 */</span>
<a class="l" name="89" href="#89">89</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeDouble"/><a href="/source/s?refs=writeDouble&amp;project=rtmp_client" class="xmt">writeDouble</a>(<b>double</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>);
<a class="hl" name="90" href="#90">90</a>
<a class="l" name="91" href="#91">91</a>	<span class="c">/**
<a class="l" name="92" href="#92">92</a>	 * Write single-precision floating point value.
<a class="l" name="93" href="#93">93</a>	 *
<a class="l" name="94" href="#94">94</a>	 * <strong>@param</strong> <em>value</em> the value
<a class="l" name="95" href="#95">95</a>	 */</span>
<a class="l" name="96" href="#96">96</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeFloat"/><a href="/source/s?refs=writeFloat&amp;project=rtmp_client" class="xmt">writeFloat</a>(<b>float</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>);
<a class="l" name="97" href="#97">97</a>
<a class="l" name="98" href="#98">98</a>	<span class="c">/**
<a class="l" name="99" href="#99">99</a>	 * Write signed integer value.
<a class="hl" name="100" href="#100">100</a>	 *
<a class="l" name="101" href="#101">101</a>	 * <strong>@param</strong> <em>value</em> the value
<a class="l" name="102" href="#102">102</a>	 */</span>
<a class="l" name="103" href="#103">103</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeInt"/><a href="/source/s?refs=writeInt&amp;project=rtmp_client" class="xmt">writeInt</a>(<b>int</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>);
<a class="l" name="104" href="#104">104</a>
<a class="l" name="105" href="#105">105</a>	<span class="c">/**
<a class="l" name="106" href="#106">106</a>	 * Write string in given character set.
<a class="l" name="107" href="#107">107</a>	 *
<a class="l" name="108" href="#108">108</a>	 * <strong>@param</strong> <em>value</em> the string
<a class="l" name="109" href="#109">109</a>	 * <strong>@param</strong> <em>encoding</em> the character set
<a class="hl" name="110" href="#110">110</a>	 */</span>
<a class="l" name="111" href="#111">111</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeMultiByte"/><a href="/source/s?refs=writeMultiByte&amp;project=rtmp_client" class="xmt">writeMultiByte</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="encoding"/><a href="/source/s?refs=encoding&amp;project=rtmp_client" class="xa">encoding</a>);
<a class="l" name="112" href="#112">112</a>
<a class="l" name="113" href="#113">113</a>	<span class="c">/**
<a class="l" name="114" href="#114">114</a>	 * Write arbitrary object.
<a class="l" name="115" href="#115">115</a>	 *
<a class="l" name="116" href="#116">116</a>	 * <strong>@param</strong> <em>value</em> the object
<a class="l" name="117" href="#117">117</a>	 */</span>
<a class="l" name="118" href="#118">118</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeObject"/><a href="/source/s?refs=writeObject&amp;project=rtmp_client" class="xmt">writeObject</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>);
<a class="l" name="119" href="#119">119</a>
<a class="hl" name="120" href="#120">120</a>	<span class="c">/**
<a class="l" name="121" href="#121">121</a>	 * Write signed short value.
<a class="l" name="122" href="#122">122</a>	 *
<a class="l" name="123" href="#123">123</a>	 * <strong>@param</strong> <em>value</em> the value
<a class="l" name="124" href="#124">124</a>	 */</span>
<a class="l" name="125" href="#125">125</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeShort"/><a href="/source/s?refs=writeShort&amp;project=rtmp_client" class="xmt">writeShort</a>(<b>short</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>);
<a class="l" name="126" href="#126">126</a>
<a class="l" name="127" href="#127">127</a>	<span class="c">/**
<a class="l" name="128" href="#128">128</a>	 * Write unsigned integer value.
<a class="l" name="129" href="#129">129</a>	 *
<a class="hl" name="130" href="#130">130</a>	 * <strong>@param</strong> <em>value</em> the value
<a class="l" name="131" href="#131">131</a>	 */</span>
<a class="l" name="132" href="#132">132</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeUnsignedInt"/><a href="/source/s?refs=writeUnsignedInt&amp;project=rtmp_client" class="xmt">writeUnsignedInt</a>(<b>long</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>);
<a class="l" name="133" href="#133">133</a>
<a class="l" name="134" href="#134">134</a>	<span class="c">/**
<a class="l" name="135" href="#135">135</a>	 * Write UTF-8 encoded string.
<a class="l" name="136" href="#136">136</a>	 *
<a class="l" name="137" href="#137">137</a>	 * <strong>@param</strong> <em>value</em> the string
<a class="l" name="138" href="#138">138</a>	 */</span>
<a class="l" name="139" href="#139">139</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeUTF"/><a href="/source/s?refs=writeUTF&amp;project=rtmp_client" class="xmt">writeUTF</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>);
<a class="hl" name="140" href="#140">140</a>
<a class="l" name="141" href="#141">141</a>	<span class="c">/**
<a class="l" name="142" href="#142">142</a>	 * Write UTF-8 encoded string as byte array. This string is stored without informations
<a class="l" name="143" href="#143">143</a>	 * about its length, so {<strong>@link</strong> IDataInput#readUTFBytes(int)} must be used to load it.
<a class="l" name="144" href="#144">144</a>	 *
<a class="l" name="145" href="#145">145</a>	 * <strong>@param</strong> <em>value</em> the string
<a class="l" name="146" href="#146">146</a>	 */</span>
<a class="l" name="147" href="#147">147</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeUTFBytes"/><a href="/source/s?refs=writeUTFBytes&amp;project=rtmp_client" class="xmt">writeUTFBytes</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>);
<a class="l" name="148" href="#148">148</a>
<a class="l" name="149" href="#149">149</a>}
<a class="hl" name="150" href="#150">150</a>