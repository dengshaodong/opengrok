<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["ByteArray",38]]],["Package","xp",[["org.red5.io.amf3",1]]],["Method","xmt",[["ByteArray",55],["ByteArray",68],["bytesAvailable",120],["compress",151],["getData",93],["getEndian",215],["length",129],["position",102],["position",111],["prepareIO",77],["readBoolean",220],["readByte",225],["readBytes",230],["readBytes",235],["readBytes",240],["readDouble",245],["readFloat",250],["readInt",255],["readMultiByte",260],["readObject",265],["readShort",273],["readUTF",278],["readUTFBytes",283],["readUnsignedByte",288],["readUnsignedInt",293],["readUnsignedShort",298],["setEndian",303],["toString",138],["uncompress",182],["writeBoolean",309],["writeByte",314],["writeBytes",319],["writeBytes",324],["writeBytes",329],["writeDouble",334],["writeFloat",339],["writeInt",344],["writeMultiByte",349],["writeObject",354],["writeShort",362],["writeUTF",367],["writeUTFBytes",372],["writeUnsignedInt",377]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=ByteOrder&amp;project=rtmp_client">ByteOrder</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=zip&amp;project=rtmp_client">zip</a>.<a href="/source/s?defs=Deflater&amp;project=rtmp_client">Deflater</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=zip&amp;project=rtmp_client">zip</a>.<a href="/source/s?defs=DeflaterOutputStream&amp;project=rtmp_client">DeflaterOutputStream</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=zip&amp;project=rtmp_client">zip</a>.<a href="/source/s?defs=InflaterInputStream&amp;project=rtmp_client">InflaterInputStream</a>;
<a class="l" name="27" href="#27">27</a>
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>;
<a class="l" name="31" href="#31">31</a>
<a class="l" name="32" href="#32">32</a><span class="c">/**
<a class="l" name="33" href="#33">33</a> * Red5 version of the Flex ByteArray class.
<a class="l" name="34" href="#34">34</a> *
<a class="l" name="35" href="#35">35</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="36" href="#36">36</a> * <strong>@author</strong> Joachim Bauch (jojo@struktur.de)
<a class="l" name="37" href="#37">37</a> */</span>
<a class="l" name="38" href="#38">38</a><b>public</b> <b>class</b> <a class="xc" name="ByteArray"/><a href="/source/s?refs=ByteArray&amp;project=rtmp_client" class="xc">ByteArray</a> <b>implements</b> <a href="/source/s?defs=IDataInput&amp;project=rtmp_client">IDataInput</a>, <a href="/source/s?defs=IDataOutput&amp;project=rtmp_client">IDataOutput</a> {
<a class="l" name="39" href="#39">39</a>
<a class="hl" name="40" href="#40">40</a>	<span class="c">/** Internal storage for array contents. */</span>
<a class="l" name="41" href="#41">41</a>	<b>protected</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xfld" name="data"/><a href="/source/s?refs=data&amp;project=rtmp_client" class="xfld">data</a>;
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a>	<span class="c">/** Object used to read from array. */</span>
<a class="l" name="44" href="#44">44</a>	<b>protected</b> <a href="/source/s?defs=IDataInput&amp;project=rtmp_client">IDataInput</a> <a class="xfld" name="dataInput"/><a href="/source/s?refs=dataInput&amp;project=rtmp_client" class="xfld">dataInput</a>;
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a>	<span class="c">/** Object used to write to array. */</span>
<a class="l" name="47" href="#47">47</a>	<b>protected</b> <a href="/source/s?defs=IDataOutput&amp;project=rtmp_client">IDataOutput</a> <a class="xfld" name="dataOutput"/><a href="/source/s?refs=dataOutput&amp;project=rtmp_client" class="xfld">dataOutput</a>;
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>	<span class="c">/**
<a class="hl" name="50" href="#50">50</a>	 * Internal constructor used to create ByteArray during deserialization.
<a class="l" name="51" href="#51">51</a>	 *
<a class="l" name="52" href="#52">52</a>	 * <strong>@param</strong> <em>buffer</em>
<a class="l" name="53" href="#53">53</a>	 * <strong>@param</strong> <em>length</em>
<a class="l" name="54" href="#54">54</a>	 */</span>
<a class="l" name="55" href="#55">55</a>	<b>protected</b> <a class="xmt" name="ByteArray"/><a href="/source/s?refs=ByteArray&amp;project=rtmp_client" class="xmt">ByteArray</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="buffer"/><a href="/source/s?refs=buffer&amp;project=rtmp_client" class="xa">buffer</a>, <b>int</b> <a class="xa" name="length"/><a href="/source/s?refs=length&amp;project=rtmp_client" class="xa">length</a>) {
<a class="l" name="56" href="#56">56</a>		<a class="d" href="#data">data</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>);
<a class="l" name="57" href="#57">57</a>		<a class="d" href="#data">data</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="58" href="#58">58</a>		<b>byte</b>[] <a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a> = <b>new</b> <b>byte</b>[<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>];
<a class="l" name="59" href="#59">59</a>		<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a>);
<a class="hl" name="60" href="#60">60</a>		<a class="d" href="#data">data</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a>);
<a class="l" name="61" href="#61">61</a>		<a class="d" href="#data">data</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="62" href="#62">62</a>		<a class="d" href="#prepareIO">prepareIO</a>();
<a class="l" name="63" href="#63">63</a>	}
<a class="l" name="64" href="#64">64</a>
<a class="l" name="65" href="#65">65</a>	<span class="c">/**
<a class="l" name="66" href="#66">66</a>	 * Public constructor. Creates new empty ByteArray.
<a class="l" name="67" href="#67">67</a>	 */</span>
<a class="l" name="68" href="#68">68</a>	<b>public</b> <a class="xmt" name="ByteArray"/><a href="/source/s?refs=ByteArray&amp;project=rtmp_client" class="xmt">ByteArray</a>() {
<a class="l" name="69" href="#69">69</a>		<a class="d" href="#data">data</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">0</span>);
<a class="hl" name="70" href="#70">70</a>		<a class="d" href="#data">data</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="71" href="#71">71</a>		<a class="d" href="#prepareIO">prepareIO</a>();
<a class="l" name="72" href="#72">72</a>	}
<a class="l" name="73" href="#73">73</a>
<a class="l" name="74" href="#74">74</a>	<span class="c">/**
<a class="l" name="75" href="#75">75</a>	 * Create internal objects used for reading and writing.
<a class="l" name="76" href="#76">76</a>	 */</span>
<a class="l" name="77" href="#77">77</a>	<b>protected</b> <b>void</b> <a class="xmt" name="prepareIO"/><a href="/source/s?refs=prepareIO&amp;project=rtmp_client" class="xmt">prepareIO</a>() {
<a class="l" name="78" href="#78">78</a>		<span class="c">// we assume that everything in ByteArray is in AMF3</span>
<a class="l" name="79" href="#79">79</a>		<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a> <a href="/source/s?defs=input&amp;project=rtmp_client">input</a> = <b>new</b> <a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>(<a class="d" href="#data">data</a>);
<a class="hl" name="80" href="#80">80</a>		<a href="/source/s?defs=input&amp;project=rtmp_client">input</a>.<a href="/source/s?defs=enforceAMF3&amp;project=rtmp_client">enforceAMF3</a>();
<a class="l" name="81" href="#81">81</a>		<a class="d" href="#dataInput">dataInput</a> = <b>new</b> <a href="/source/s?defs=DataInput&amp;project=rtmp_client">DataInput</a>(<a href="/source/s?defs=input&amp;project=rtmp_client">input</a>, <b>new</b> <a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a>());
<a class="l" name="82" href="#82">82</a>
<a class="l" name="83" href="#83">83</a>		<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a> <a href="/source/s?defs=output&amp;project=rtmp_client">output</a> = <b>new</b> <a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>(<a class="d" href="#data">data</a>);
<a class="l" name="84" href="#84">84</a>		<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>.<a href="/source/s?defs=enforceAMF3&amp;project=rtmp_client">enforceAMF3</a>();
<a class="l" name="85" href="#85">85</a>		<a class="d" href="#dataOutput">dataOutput</a> = <b>new</b> <a href="/source/s?defs=DataOutput&amp;project=rtmp_client">DataOutput</a>(<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>, <b>new</b> <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>());
<a class="l" name="86" href="#86">86</a>	}
<a class="l" name="87" href="#87">87</a>
<a class="l" name="88" href="#88">88</a>	<span class="c">/**
<a class="l" name="89" href="#89">89</a>	 * Get internal data.
<a class="hl" name="90" href="#90">90</a>	 *
<a class="l" name="91" href="#91">91</a>	 * <strong>@return</strong> byte buffer
<a class="l" name="92" href="#92">92</a>	 */</span>
<a class="l" name="93" href="#93">93</a>	<b>protected</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="getData"/><a href="/source/s?refs=getData&amp;project=rtmp_client" class="xmt">getData</a>() {
<a class="l" name="94" href="#94">94</a>		<b>return</b> <a class="d" href="#data">data</a>;
<a class="l" name="95" href="#95">95</a>	}
<a class="l" name="96" href="#96">96</a>
<a class="l" name="97" href="#97">97</a>	<span class="c">/**
<a class="l" name="98" href="#98">98</a>	 * Get the current position in the data.
<a class="l" name="99" href="#99">99</a>	 *
<a class="hl" name="100" href="#100">100</a>	 * <strong>@return</strong> current position
<a class="l" name="101" href="#101">101</a>	 */</span>
<a class="l" name="102" href="#102">102</a>	<b>public</b> <b>int</b> <a class="xmt" name="position"/><a href="/source/s?refs=position&amp;project=rtmp_client" class="xmt">position</a>() {
<a class="l" name="103" href="#103">103</a>		<b>return</b> <a class="d" href="#data">data</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>();
<a class="l" name="104" href="#104">104</a>	}
<a class="l" name="105" href="#105">105</a>
<a class="l" name="106" href="#106">106</a>	<span class="c">/**
<a class="l" name="107" href="#107">107</a>	 * Set the current position in the data.
<a class="l" name="108" href="#108">108</a>	 *
<a class="l" name="109" href="#109">109</a>	 * <strong>@param</strong> <em>position</em> position to set
<a class="hl" name="110" href="#110">110</a>	 */</span>
<a class="l" name="111" href="#111">111</a>	<b>public</b> <b>void</b> <a class="xa" name="position"/><a href="/source/s?refs=position&amp;project=rtmp_client" class="xa">position</a>(<b>int</b> <a class="xa" name="position"/><a href="/source/s?refs=position&amp;project=rtmp_client" class="xa">position</a>) {
<a class="l" name="112" href="#112">112</a>		<a class="d" href="#data">data</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>);
<a class="l" name="113" href="#113">113</a>	}
<a class="l" name="114" href="#114">114</a>
<a class="l" name="115" href="#115">115</a>	<span class="c">/**
<a class="l" name="116" href="#116">116</a>	 * Return number of bytes available for reading.
<a class="l" name="117" href="#117">117</a>	 *
<a class="l" name="118" href="#118">118</a>	 * <strong>@return</strong> bytes available
<a class="l" name="119" href="#119">119</a>	 */</span>
<a class="hl" name="120" href="#120">120</a>	<b>public</b> <b>int</b> <a class="xmt" name="bytesAvailable"/><a href="/source/s?refs=bytesAvailable&amp;project=rtmp_client" class="xmt">bytesAvailable</a>() {
<a class="l" name="121" href="#121">121</a>		<b>return</b> <a href="/source/s?defs=length&amp;project=rtmp_client">length</a>() - <a href="/source/s?defs=position&amp;project=rtmp_client">position</a>();
<a class="l" name="122" href="#122">122</a>	}
<a class="l" name="123" href="#123">123</a>
<a class="l" name="124" href="#124">124</a>	<span class="c">/**
<a class="l" name="125" href="#125">125</a>	 * Return total number of bytes in array.
<a class="l" name="126" href="#126">126</a>	 *
<a class="l" name="127" href="#127">127</a>	 * <strong>@return</strong> number of bytes in array
<a class="l" name="128" href="#128">128</a>	 */</span>
<a class="l" name="129" href="#129">129</a>	<b>public</b> <b>int</b> <a class="xmt" name="length"/><a href="/source/s?refs=length&amp;project=rtmp_client" class="xmt">length</a>() {
<a class="hl" name="130" href="#130">130</a>		<b>return</b> <a class="d" href="#data">data</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>();
<a class="l" name="131" href="#131">131</a>	}
<a class="l" name="132" href="#132">132</a>
<a class="l" name="133" href="#133">133</a>	<span class="c">/**
<a class="l" name="134" href="#134">134</a>	 * Return string representation of the array's contents.
<a class="l" name="135" href="#135">135</a>	 *
<a class="l" name="136" href="#136">136</a>	 * <strong>@return</strong> string representaiton of array's contents.
<a class="l" name="137" href="#137">137</a>	 */</span>
<a class="l" name="138" href="#138">138</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toString"/><a href="/source/s?refs=toString&amp;project=rtmp_client" class="xmt">toString</a>() {
<a class="l" name="139" href="#139">139</a>		<b>int</b> <a href="/source/s?defs=old&amp;project=rtmp_client">old</a> = <a class="d" href="#data">data</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>();
<a class="hl" name="140" href="#140">140</a>		<b>try</b> {
<a class="l" name="141" href="#141">141</a>			<a class="d" href="#data">data</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<span class="n">0</span>);
<a class="l" name="142" href="#142">142</a>			<b>return</b> <a class="d" href="#data">data</a>.<a href="/source/s?defs=asCharBuffer&amp;project=rtmp_client">asCharBuffer</a>().<a class="d" href="#toString">toString</a>();
<a class="l" name="143" href="#143">143</a>		} <b>finally</b> {
<a class="l" name="144" href="#144">144</a>			<a class="d" href="#data">data</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<a href="/source/s?defs=old&amp;project=rtmp_client">old</a>);
<a class="l" name="145" href="#145">145</a>		}
<a class="l" name="146" href="#146">146</a>	}
<a class="l" name="147" href="#147">147</a>
<a class="l" name="148" href="#148">148</a>	<span class="c">/**
<a class="l" name="149" href="#149">149</a>	 * Compress contents using zlib.
<a class="hl" name="150" href="#150">150</a>	 */</span>
<a class="l" name="151" href="#151">151</a>	<b>public</b> <b>void</b> <a class="xmt" name="compress"/><a href="/source/s?refs=compress&amp;project=rtmp_client" class="xmt">compress</a>() {
<a class="l" name="152" href="#152">152</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">0</span>);
<a class="l" name="153" href="#153">153</a>		<a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="154" href="#154">154</a>		<a href="/source/s?defs=DeflaterOutputStream&amp;project=rtmp_client">DeflaterOutputStream</a> <a href="/source/s?defs=deflater&amp;project=rtmp_client">deflater</a> = <b>new</b> <a href="/source/s?defs=DeflaterOutputStream&amp;project=rtmp_client">DeflaterOutputStream</a>(<a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a>.<a href="/source/s?defs=asOutputStream&amp;project=rtmp_client">asOutputStream</a>(), <b>new</b> <a href="/source/s?defs=Deflater&amp;project=rtmp_client">Deflater</a>(<a href="/source/s?defs=Deflater&amp;project=rtmp_client">Deflater</a>.<a href="/source/s?defs=BEST_COMPRESSION&amp;project=rtmp_client">BEST_COMPRESSION</a>));
<a class="l" name="155" href="#155">155</a>		<b>byte</b>[] <a href="/source/s?defs=tmpData&amp;project=rtmp_client">tmpData</a> = <b>new</b> <b>byte</b>[<a class="d" href="#data">data</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>()];
<a class="l" name="156" href="#156">156</a>		<a class="d" href="#data">data</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<span class="n">0</span>);
<a class="l" name="157" href="#157">157</a>		<a class="d" href="#data">data</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=tmpData&amp;project=rtmp_client">tmpData</a>);
<a class="l" name="158" href="#158">158</a>		<b>try</b> {
<a class="l" name="159" href="#159">159</a>			<a href="/source/s?defs=deflater&amp;project=rtmp_client">deflater</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=tmpData&amp;project=rtmp_client">tmpData</a>);
<a class="hl" name="160" href="#160">160</a>			<a href="/source/s?defs=deflater&amp;project=rtmp_client">deflater</a>.<a href="/source/s?defs=finish&amp;project=rtmp_client">finish</a>();
<a class="l" name="161" href="#161">161</a>		} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> e) {
<a class="l" name="162" href="#162">162</a>			<span class="c">//docs state that free is optional</span>
<a class="l" name="163" href="#163">163</a>			<a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a>.<a href="/source/s?defs=free&amp;project=rtmp_client">free</a>();
<a class="l" name="164" href="#164">164</a>			<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"could not compress data"</span>, e);
<a class="l" name="165" href="#165">165</a>		} <b>finally</b> {
<a class="l" name="166" href="#166">166</a>			<b>if</b> (<a href="/source/s?defs=deflater&amp;project=rtmp_client">deflater</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="167" href="#167">167</a>				<b>try</b> {
<a class="l" name="168" href="#168">168</a>					<a href="/source/s?defs=deflater&amp;project=rtmp_client">deflater</a>.<a href="/source/s?defs=close&amp;project=rtmp_client">close</a>();
<a class="l" name="169" href="#169">169</a>				} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> <a href="/source/s?defs=e1&amp;project=rtmp_client">e1</a>) {
<a class="hl" name="170" href="#170">170</a>				}
<a class="l" name="171" href="#171">171</a>			}
<a class="l" name="172" href="#172">172</a>		}
<a class="l" name="173" href="#173">173</a>		<a class="d" href="#data">data</a>.<a href="/source/s?defs=free&amp;project=rtmp_client">free</a>();
<a class="l" name="174" href="#174">174</a>		<a class="d" href="#data">data</a> = <a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a>;
<a class="l" name="175" href="#175">175</a>		<a class="d" href="#data">data</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="176" href="#176">176</a>		<a class="d" href="#prepareIO">prepareIO</a>();
<a class="l" name="177" href="#177">177</a>	}
<a class="l" name="178" href="#178">178</a>
<a class="l" name="179" href="#179">179</a>	<span class="c">/**
<a class="hl" name="180" href="#180">180</a>	 * Decompress contents using zlib.
<a class="l" name="181" href="#181">181</a>	 */</span>
<a class="l" name="182" href="#182">182</a>	<b>public</b> <b>void</b> <a class="xmt" name="uncompress"/><a href="/source/s?refs=uncompress&amp;project=rtmp_client" class="xmt">uncompress</a>() {
<a class="l" name="183" href="#183">183</a>		<a class="d" href="#data">data</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<span class="n">0</span>);
<a class="l" name="184" href="#184">184</a>		<a href="/source/s?defs=InflaterInputStream&amp;project=rtmp_client">InflaterInputStream</a> <a href="/source/s?defs=inflater&amp;project=rtmp_client">inflater</a> = <b>new</b> <a href="/source/s?defs=InflaterInputStream&amp;project=rtmp_client">InflaterInputStream</a>(<a class="d" href="#data">data</a>.<a href="/source/s?defs=asInputStream&amp;project=rtmp_client">asInputStream</a>());
<a class="l" name="185" href="#185">185</a>		<b>byte</b>[] <a class="d" href="#buffer">buffer</a> = <b>new</b> <b>byte</b>[<span class="n">8192</span>];
<a class="l" name="186" href="#186">186</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">0</span>);
<a class="l" name="187" href="#187">187</a>		<a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="188" href="#188">188</a>		<b>try</b> {
<a class="l" name="189" href="#189">189</a>			<b>while</b> (<a href="/source/s?defs=inflater&amp;project=rtmp_client">inflater</a>.<a href="/source/s?defs=available&amp;project=rtmp_client">available</a>() &gt; <span class="n">0</span>) {
<a class="hl" name="190" href="#190">190</a>				<b>int</b> <a href="/source/s?defs=decompressed&amp;project=rtmp_client">decompressed</a> = <a href="/source/s?defs=inflater&amp;project=rtmp_client">inflater</a>.<a href="/source/s?defs=read&amp;project=rtmp_client">read</a>(<a class="d" href="#buffer">buffer</a>);
<a class="l" name="191" href="#191">191</a>				<b>if</b> (<a href="/source/s?defs=decompressed&amp;project=rtmp_client">decompressed</a> &lt;= <span class="n">0</span>) {
<a class="l" name="192" href="#192">192</a>					<span class="c">// Finished decompression</span>
<a class="l" name="193" href="#193">193</a>					<b>break</b>;
<a class="l" name="194" href="#194">194</a>				}
<a class="l" name="195" href="#195">195</a>				<a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#buffer">buffer</a>, <span class="n">0</span>, <a href="/source/s?defs=decompressed&amp;project=rtmp_client">decompressed</a>);
<a class="l" name="196" href="#196">196</a>			}
<a class="l" name="197" href="#197">197</a>		} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> e) {
<a class="l" name="198" href="#198">198</a>			<a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a>.<a href="/source/s?defs=free&amp;project=rtmp_client">free</a>();
<a class="l" name="199" href="#199">199</a>			<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"could not uncompress data"</span>, e);
<a class="hl" name="200" href="#200">200</a>		} <b>finally</b> {
<a class="l" name="201" href="#201">201</a>			<b>if</b> (<a href="/source/s?defs=inflater&amp;project=rtmp_client">inflater</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="202" href="#202">202</a>				<b>try</b> {
<a class="l" name="203" href="#203">203</a>					<a href="/source/s?defs=inflater&amp;project=rtmp_client">inflater</a>.<a href="/source/s?defs=close&amp;project=rtmp_client">close</a>();
<a class="l" name="204" href="#204">204</a>				} <b>catch</b> (<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> <a href="/source/s?defs=e1&amp;project=rtmp_client">e1</a>) {
<a class="l" name="205" href="#205">205</a>				}
<a class="l" name="206" href="#206">206</a>			}
<a class="l" name="207" href="#207">207</a>		}
<a class="l" name="208" href="#208">208</a>		<a class="d" href="#data">data</a>.<a href="/source/s?defs=free&amp;project=rtmp_client">free</a>();
<a class="l" name="209" href="#209">209</a>		<a class="d" href="#data">data</a> = <a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a>;
<a class="hl" name="210" href="#210">210</a>		<a class="d" href="#data">data</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="211" href="#211">211</a>		<a class="d" href="#prepareIO">prepareIO</a>();
<a class="l" name="212" href="#212">212</a>	}
<a class="l" name="213" href="#213">213</a>
<a class="l" name="214" href="#214">214</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="215" href="#215">215</a>	<b>public</b> <a href="/source/s?defs=ByteOrder&amp;project=rtmp_client">ByteOrder</a> <a class="xmt" name="getEndian"/><a href="/source/s?refs=getEndian&amp;project=rtmp_client" class="xmt">getEndian</a>() {
<a class="l" name="216" href="#216">216</a>		<b>return</b> <a class="d" href="#dataInput">dataInput</a>.<a class="d" href="#getEndian">getEndian</a>();
<a class="l" name="217" href="#217">217</a>	}
<a class="l" name="218" href="#218">218</a>
<a class="l" name="219" href="#219">219</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="220" href="#220">220</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="readBoolean"/><a href="/source/s?refs=readBoolean&amp;project=rtmp_client" class="xmt">readBoolean</a>() {
<a class="l" name="221" href="#221">221</a>		<b>return</b> <a class="d" href="#dataInput">dataInput</a>.<a class="d" href="#readBoolean">readBoolean</a>();
<a class="l" name="222" href="#222">222</a>	}
<a class="l" name="223" href="#223">223</a>
<a class="l" name="224" href="#224">224</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="225" href="#225">225</a>	<b>public</b> <b>byte</b> <a class="xmt" name="readByte"/><a href="/source/s?refs=readByte&amp;project=rtmp_client" class="xmt">readByte</a>() {
<a class="l" name="226" href="#226">226</a>		<b>return</b> <a class="d" href="#dataInput">dataInput</a>.<a class="d" href="#readByte">readByte</a>();
<a class="l" name="227" href="#227">227</a>	}
<a class="l" name="228" href="#228">228</a>
<a class="l" name="229" href="#229">229</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="230" href="#230">230</a>	<b>public</b> <b>void</b> <a class="xmt" name="readBytes"/><a href="/source/s?refs=readBytes&amp;project=rtmp_client" class="xmt">readBytes</a>(<b>byte</b>[] <a class="xa" name="bytes"/><a href="/source/s?refs=bytes&amp;project=rtmp_client" class="xa">bytes</a>) {
<a class="l" name="231" href="#231">231</a>		<a class="d" href="#dataInput">dataInput</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>);
<a class="l" name="232" href="#232">232</a>	}
<a class="l" name="233" href="#233">233</a>
<a class="l" name="234" href="#234">234</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="235" href="#235">235</a>	<b>public</b> <b>void</b> <a class="xmt" name="readBytes"/><a href="/source/s?refs=readBytes&amp;project=rtmp_client" class="xmt">readBytes</a>(<b>byte</b>[] <a class="xa" name="bytes"/><a href="/source/s?refs=bytes&amp;project=rtmp_client" class="xa">bytes</a>, <b>int</b> <a class="xa" name="offset"/><a href="/source/s?refs=offset&amp;project=rtmp_client" class="xa">offset</a>) {
<a class="l" name="236" href="#236">236</a>		<a class="d" href="#dataInput">dataInput</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>, <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>);
<a class="l" name="237" href="#237">237</a>	}
<a class="l" name="238" href="#238">238</a>
<a class="l" name="239" href="#239">239</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="240" href="#240">240</a>	<b>public</b> <b>void</b> <a class="xmt" name="readBytes"/><a href="/source/s?refs=readBytes&amp;project=rtmp_client" class="xmt">readBytes</a>(<b>byte</b>[] <a class="xa" name="bytes"/><a href="/source/s?refs=bytes&amp;project=rtmp_client" class="xa">bytes</a>, <b>int</b> <a class="xa" name="offset"/><a href="/source/s?refs=offset&amp;project=rtmp_client" class="xa">offset</a>, <b>int</b> <a class="xa" name="length"/><a href="/source/s?refs=length&amp;project=rtmp_client" class="xa">length</a>) {
<a class="l" name="241" href="#241">241</a>		<a class="d" href="#dataInput">dataInput</a>.<a href="/source/s?defs=readBytes&amp;project=rtmp_client">readBytes</a>(<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>, <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>, <a href="/source/s?defs=length&amp;project=rtmp_client">length</a>);
<a class="l" name="242" href="#242">242</a>	}
<a class="l" name="243" href="#243">243</a>
<a class="l" name="244" href="#244">244</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="245" href="#245">245</a>	<b>public</b> <b>double</b> <a class="xmt" name="readDouble"/><a href="/source/s?refs=readDouble&amp;project=rtmp_client" class="xmt">readDouble</a>() {
<a class="l" name="246" href="#246">246</a>		<b>return</b> <a class="d" href="#dataInput">dataInput</a>.<a class="d" href="#readDouble">readDouble</a>();
<a class="l" name="247" href="#247">247</a>	}
<a class="l" name="248" href="#248">248</a>
<a class="l" name="249" href="#249">249</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="250" href="#250">250</a>	<b>public</b> <b>float</b> <a class="xmt" name="readFloat"/><a href="/source/s?refs=readFloat&amp;project=rtmp_client" class="xmt">readFloat</a>() {
<a class="l" name="251" href="#251">251</a>		<b>return</b> <a class="d" href="#dataInput">dataInput</a>.<a class="d" href="#readFloat">readFloat</a>();
<a class="l" name="252" href="#252">252</a>	}
<a class="l" name="253" href="#253">253</a>
<a class="l" name="254" href="#254">254</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="255" href="#255">255</a>	<b>public</b> <b>int</b> <a class="xmt" name="readInt"/><a href="/source/s?refs=readInt&amp;project=rtmp_client" class="xmt">readInt</a>() {
<a class="l" name="256" href="#256">256</a>		<b>return</b> <a class="d" href="#dataInput">dataInput</a>.<a class="d" href="#readInt">readInt</a>();
<a class="l" name="257" href="#257">257</a>	}
<a class="l" name="258" href="#258">258</a>
<a class="l" name="259" href="#259">259</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="260" href="#260">260</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="readMultiByte"/><a href="/source/s?refs=readMultiByte&amp;project=rtmp_client" class="xmt">readMultiByte</a>(<b>int</b> <a class="xa" name="length"/><a href="/source/s?refs=length&amp;project=rtmp_client" class="xa">length</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="charSet"/><a href="/source/s?refs=charSet&amp;project=rtmp_client" class="xa">charSet</a>) {
<a class="l" name="261" href="#261">261</a>		<b>return</b> <a class="d" href="#dataInput">dataInput</a>.<a class="d" href="#readMultiByte">readMultiByte</a>(<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>, <a class="d" href="#charSet">charSet</a>);
<a class="l" name="262" href="#262">262</a>	}
<a class="l" name="263" href="#263">263</a>
<a class="l" name="264" href="#264">264</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="265" href="#265">265</a>	<b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="readObject"/><a href="/source/s?refs=readObject&amp;project=rtmp_client" class="xmt">readObject</a>() {
<a class="l" name="266" href="#266">266</a>		<span class="c">// according to AMF3 spec, each object should have its own "reference" tables,</span>
<a class="l" name="267" href="#267">267</a>		<span class="c">// so we must recreate Input object before reading each object</span>
<a class="l" name="268" href="#268">268</a>		<a class="d" href="#prepareIO">prepareIO</a>();
<a class="l" name="269" href="#269">269</a>		<b>return</b> <a class="d" href="#dataInput">dataInput</a>.<a class="d" href="#readObject">readObject</a>();
<a class="hl" name="270" href="#270">270</a>	}
<a class="l" name="271" href="#271">271</a>
<a class="l" name="272" href="#272">272</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="273" href="#273">273</a>	<b>public</b> <b>short</b> <a class="xmt" name="readShort"/><a href="/source/s?refs=readShort&amp;project=rtmp_client" class="xmt">readShort</a>() {
<a class="l" name="274" href="#274">274</a>		<b>return</b> <a class="d" href="#dataInput">dataInput</a>.<a class="d" href="#readShort">readShort</a>();
<a class="l" name="275" href="#275">275</a>	}
<a class="l" name="276" href="#276">276</a>
<a class="l" name="277" href="#277">277</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="278" href="#278">278</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="readUTF"/><a href="/source/s?refs=readUTF&amp;project=rtmp_client" class="xmt">readUTF</a>() {
<a class="l" name="279" href="#279">279</a>		<b>return</b> <a class="d" href="#dataInput">dataInput</a>.<a class="d" href="#readUTF">readUTF</a>();
<a class="hl" name="280" href="#280">280</a>	}
<a class="l" name="281" href="#281">281</a>
<a class="l" name="282" href="#282">282</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="283" href="#283">283</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="readUTFBytes"/><a href="/source/s?refs=readUTFBytes&amp;project=rtmp_client" class="xmt">readUTFBytes</a>(<b>int</b> <a class="xa" name="length"/><a href="/source/s?refs=length&amp;project=rtmp_client" class="xa">length</a>) {
<a class="l" name="284" href="#284">284</a>		<b>return</b> <a class="d" href="#dataInput">dataInput</a>.<a class="d" href="#readUTFBytes">readUTFBytes</a>(<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>);
<a class="l" name="285" href="#285">285</a>	}
<a class="l" name="286" href="#286">286</a>
<a class="l" name="287" href="#287">287</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="288" href="#288">288</a>	<b>public</b> <b>int</b> <a class="xmt" name="readUnsignedByte"/><a href="/source/s?refs=readUnsignedByte&amp;project=rtmp_client" class="xmt">readUnsignedByte</a>() {
<a class="l" name="289" href="#289">289</a>		<b>return</b> <a class="d" href="#dataInput">dataInput</a>.<a class="d" href="#readUnsignedByte">readUnsignedByte</a>();
<a class="hl" name="290" href="#290">290</a>	}
<a class="l" name="291" href="#291">291</a>
<a class="l" name="292" href="#292">292</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="293" href="#293">293</a>	<b>public</b> <b>long</b> <a class="xmt" name="readUnsignedInt"/><a href="/source/s?refs=readUnsignedInt&amp;project=rtmp_client" class="xmt">readUnsignedInt</a>() {
<a class="l" name="294" href="#294">294</a>		<b>return</b> <a class="d" href="#dataInput">dataInput</a>.<a class="d" href="#readUnsignedInt">readUnsignedInt</a>();
<a class="l" name="295" href="#295">295</a>	}
<a class="l" name="296" href="#296">296</a>
<a class="l" name="297" href="#297">297</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="298" href="#298">298</a>	<b>public</b> <b>int</b> <a class="xmt" name="readUnsignedShort"/><a href="/source/s?refs=readUnsignedShort&amp;project=rtmp_client" class="xmt">readUnsignedShort</a>() {
<a class="l" name="299" href="#299">299</a>		<b>return</b> <a class="d" href="#dataInput">dataInput</a>.<a class="d" href="#readUnsignedShort">readUnsignedShort</a>();
<a class="hl" name="300" href="#300">300</a>	}
<a class="l" name="301" href="#301">301</a>
<a class="l" name="302" href="#302">302</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="303" href="#303">303</a>	<b>public</b> <b>void</b> <a class="xmt" name="setEndian"/><a href="/source/s?refs=setEndian&amp;project=rtmp_client" class="xmt">setEndian</a>(<a href="/source/s?defs=ByteOrder&amp;project=rtmp_client">ByteOrder</a> <a class="xa" name="endian"/><a href="/source/s?refs=endian&amp;project=rtmp_client" class="xa">endian</a>) {
<a class="l" name="304" href="#304">304</a>		<a class="d" href="#dataInput">dataInput</a>.<a class="d" href="#setEndian">setEndian</a>(<a class="d" href="#endian">endian</a>);
<a class="l" name="305" href="#305">305</a>		<a class="d" href="#dataOutput">dataOutput</a>.<a class="d" href="#setEndian">setEndian</a>(<a class="d" href="#endian">endian</a>);
<a class="l" name="306" href="#306">306</a>	}
<a class="l" name="307" href="#307">307</a>
<a class="l" name="308" href="#308">308</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="309" href="#309">309</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeBoolean"/><a href="/source/s?refs=writeBoolean&amp;project=rtmp_client" class="xmt">writeBoolean</a>(<b>boolean</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="hl" name="310" href="#310">310</a>		<a class="d" href="#dataOutput">dataOutput</a>.<a class="d" href="#writeBoolean">writeBoolean</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="311" href="#311">311</a>	}
<a class="l" name="312" href="#312">312</a>
<a class="l" name="313" href="#313">313</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="314" href="#314">314</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeByte"/><a href="/source/s?refs=writeByte&amp;project=rtmp_client" class="xmt">writeByte</a>(<b>byte</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="315" href="#315">315</a>		<a class="d" href="#dataOutput">dataOutput</a>.<a class="d" href="#writeByte">writeByte</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="316" href="#316">316</a>	}
<a class="l" name="317" href="#317">317</a>
<a class="l" name="318" href="#318">318</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="319" href="#319">319</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeBytes"/><a href="/source/s?refs=writeBytes&amp;project=rtmp_client" class="xmt">writeBytes</a>(<b>byte</b>[] <a class="xa" name="bytes"/><a href="/source/s?refs=bytes&amp;project=rtmp_client" class="xa">bytes</a>) {
<a class="hl" name="320" href="#320">320</a>		<a class="d" href="#dataOutput">dataOutput</a>.<a href="/source/s?defs=writeBytes&amp;project=rtmp_client">writeBytes</a>(<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>);
<a class="l" name="321" href="#321">321</a>	}
<a class="l" name="322" href="#322">322</a>
<a class="l" name="323" href="#323">323</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="324" href="#324">324</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeBytes"/><a href="/source/s?refs=writeBytes&amp;project=rtmp_client" class="xmt">writeBytes</a>(<b>byte</b>[] <a class="xa" name="bytes"/><a href="/source/s?refs=bytes&amp;project=rtmp_client" class="xa">bytes</a>, <b>int</b> <a class="xa" name="offset"/><a href="/source/s?refs=offset&amp;project=rtmp_client" class="xa">offset</a>) {
<a class="l" name="325" href="#325">325</a>		<a class="d" href="#dataOutput">dataOutput</a>.<a href="/source/s?defs=writeBytes&amp;project=rtmp_client">writeBytes</a>(<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>, <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>);
<a class="l" name="326" href="#326">326</a>	}
<a class="l" name="327" href="#327">327</a>
<a class="l" name="328" href="#328">328</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="329" href="#329">329</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeBytes"/><a href="/source/s?refs=writeBytes&amp;project=rtmp_client" class="xmt">writeBytes</a>(<b>byte</b>[] <a class="xa" name="bytes"/><a href="/source/s?refs=bytes&amp;project=rtmp_client" class="xa">bytes</a>, <b>int</b> <a class="xa" name="offset"/><a href="/source/s?refs=offset&amp;project=rtmp_client" class="xa">offset</a>, <b>int</b> <a class="xa" name="length"/><a href="/source/s?refs=length&amp;project=rtmp_client" class="xa">length</a>) {
<a class="hl" name="330" href="#330">330</a>		<a class="d" href="#dataOutput">dataOutput</a>.<a href="/source/s?defs=writeBytes&amp;project=rtmp_client">writeBytes</a>(<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>, <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>, <a href="/source/s?defs=length&amp;project=rtmp_client">length</a>);
<a class="l" name="331" href="#331">331</a>	}
<a class="l" name="332" href="#332">332</a>
<a class="l" name="333" href="#333">333</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="334" href="#334">334</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeDouble"/><a href="/source/s?refs=writeDouble&amp;project=rtmp_client" class="xmt">writeDouble</a>(<b>double</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="335" href="#335">335</a>		<a class="d" href="#dataOutput">dataOutput</a>.<a class="d" href="#writeDouble">writeDouble</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="336" href="#336">336</a>	}
<a class="l" name="337" href="#337">337</a>
<a class="l" name="338" href="#338">338</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="339" href="#339">339</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeFloat"/><a href="/source/s?refs=writeFloat&amp;project=rtmp_client" class="xmt">writeFloat</a>(<b>float</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="hl" name="340" href="#340">340</a>		<a class="d" href="#dataOutput">dataOutput</a>.<a class="d" href="#writeFloat">writeFloat</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="341" href="#341">341</a>	}
<a class="l" name="342" href="#342">342</a>
<a class="l" name="343" href="#343">343</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="344" href="#344">344</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeInt"/><a href="/source/s?refs=writeInt&amp;project=rtmp_client" class="xmt">writeInt</a>(<b>int</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="345" href="#345">345</a>		<a class="d" href="#dataOutput">dataOutput</a>.<a class="d" href="#writeInt">writeInt</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="346" href="#346">346</a>	}
<a class="l" name="347" href="#347">347</a>
<a class="l" name="348" href="#348">348</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="349" href="#349">349</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeMultiByte"/><a href="/source/s?refs=writeMultiByte&amp;project=rtmp_client" class="xmt">writeMultiByte</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="encoding"/><a href="/source/s?refs=encoding&amp;project=rtmp_client" class="xa">encoding</a>) {
<a class="hl" name="350" href="#350">350</a>		<a class="d" href="#dataOutput">dataOutput</a>.<a class="d" href="#writeMultiByte">writeMultiByte</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>, <a class="d" href="#encoding">encoding</a>);
<a class="l" name="351" href="#351">351</a>	}
<a class="l" name="352" href="#352">352</a>
<a class="l" name="353" href="#353">353</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="354" href="#354">354</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeObject"/><a href="/source/s?refs=writeObject&amp;project=rtmp_client" class="xmt">writeObject</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="355" href="#355">355</a>		<span class="c">// according to AMF3 spec, each object should have its own "reference" tables,</span>
<a class="l" name="356" href="#356">356</a>		<span class="c">// so we must recreate Input object before writing each object</span>
<a class="l" name="357" href="#357">357</a>		<a class="d" href="#prepareIO">prepareIO</a>();
<a class="l" name="358" href="#358">358</a>		<a class="d" href="#dataOutput">dataOutput</a>.<a class="d" href="#writeObject">writeObject</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="359" href="#359">359</a>	}
<a class="hl" name="360" href="#360">360</a>
<a class="l" name="361" href="#361">361</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="362" href="#362">362</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeShort"/><a href="/source/s?refs=writeShort&amp;project=rtmp_client" class="xmt">writeShort</a>(<b>short</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="363" href="#363">363</a>		<a class="d" href="#dataOutput">dataOutput</a>.<a class="d" href="#writeShort">writeShort</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="364" href="#364">364</a>	}
<a class="l" name="365" href="#365">365</a>
<a class="l" name="366" href="#366">366</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="367" href="#367">367</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeUTF"/><a href="/source/s?refs=writeUTF&amp;project=rtmp_client" class="xmt">writeUTF</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="368" href="#368">368</a>		<a class="d" href="#dataOutput">dataOutput</a>.<a class="d" href="#writeUTF">writeUTF</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="369" href="#369">369</a>	}
<a class="hl" name="370" href="#370">370</a>
<a class="l" name="371" href="#371">371</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="372" href="#372">372</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeUTFBytes"/><a href="/source/s?refs=writeUTFBytes&amp;project=rtmp_client" class="xmt">writeUTFBytes</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="373" href="#373">373</a>		<a class="d" href="#dataOutput">dataOutput</a>.<a class="d" href="#writeUTFBytes">writeUTFBytes</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="374" href="#374">374</a>	}
<a class="l" name="375" href="#375">375</a>
<a class="l" name="376" href="#376">376</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="377" href="#377">377</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeUnsignedInt"/><a href="/source/s?refs=writeUnsignedInt&amp;project=rtmp_client" class="xmt">writeUnsignedInt</a>(<b>long</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="378" href="#378">378</a>		<a class="d" href="#dataOutput">dataOutput</a>.<a class="d" href="#writeUnsignedInt">writeUnsignedInt</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="379" href="#379">379</a>	}
<a class="hl" name="380" href="#380">380</a>
<a class="l" name="381" href="#381">381</a>}
<a class="l" name="382" href="#382">382</a>