<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.red5.io",1]]],["Interface","xi",[["IStreamableFile",27]]],["Method","xmt",[["getAppendWriter",51],["getReader",35],["getWriter",43]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a><span class="c">/**
<a class="l" name="25" href="#25">25</a> * Interface represents streamable file with tag reader and writers (one for plain mode and one for append)
<a class="l" name="26" href="#26">26</a> */</span>
<a class="l" name="27" href="#27">27</a><b>public</b> <b>interface</b> <a class="xi" name="IStreamableFile"/><a href="/source/s?refs=IStreamableFile&amp;project=rtmp_client" class="xi">IStreamableFile</a> {
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a>	<span class="c">/**
<a class="hl" name="30" href="#30">30</a>	 * Returns a reader to parse and read the tags inside the file.
<a class="l" name="31" href="#31">31</a>	 *
<a class="l" name="32" href="#32">32</a>	 * <strong>@return</strong> the reader                 Tag reader
<a class="l" name="33" href="#33">33</a>     * <strong>@throws</strong> <em>java.io.IOException</em>        I/O exception
<a class="l" name="34" href="#34">34</a>	 */</span>
<a class="l" name="35" href="#35">35</a>	<b>public</b> <a href="/source/s?defs=ITagReader&amp;project=rtmp_client">ITagReader</a> <a class="xmt" name="getReader"/><a href="/source/s?refs=getReader&amp;project=rtmp_client" class="xmt">getReader</a>() <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a>	<span class="c">/**
<a class="l" name="38" href="#38">38</a>	 * Returns a writer that creates a new file or truncates existing contents.
<a class="l" name="39" href="#39">39</a>	 *
<a class="hl" name="40" href="#40">40</a>	 * <strong>@return</strong> the writer                  Tag writer
<a class="l" name="41" href="#41">41</a>     * <strong>@throws</strong> <em>java.io.IOException</em>         I/O exception
<a class="l" name="42" href="#42">42</a>	 */</span>
<a class="l" name="43" href="#43">43</a>	<b>public</b> <a href="/source/s?defs=ITagWriter&amp;project=rtmp_client">ITagWriter</a> <a class="xmt" name="getWriter"/><a href="/source/s?refs=getWriter&amp;project=rtmp_client" class="xmt">getWriter</a>() <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="44" href="#44">44</a>
<a class="l" name="45" href="#45">45</a>	<span class="c">/**
<a class="l" name="46" href="#46">46</a>	 * Returns a Writer which is setup to append to the file.
<a class="l" name="47" href="#47">47</a>	 *
<a class="l" name="48" href="#48">48</a>	 * <strong>@return</strong> the writer                  Tag writer used for append mode
<a class="l" name="49" href="#49">49</a>     * <strong>@throws</strong> <em>java.io.IOException</em>         I/O exception
<a class="hl" name="50" href="#50">50</a>	 */</span>
<a class="l" name="51" href="#51">51</a>	<b>public</b> <a href="/source/s?defs=ITagWriter&amp;project=rtmp_client">ITagWriter</a> <a class="xmt" name="getAppendWriter"/><a href="/source/s?refs=getAppendWriter&amp;project=rtmp_client" class="xmt">getAppendWriter</a>() <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>}
<a class="l" name="54" href="#54">54</a>