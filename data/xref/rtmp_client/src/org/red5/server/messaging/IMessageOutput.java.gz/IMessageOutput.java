<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.red5.server.messaging",1]]],["Interface","xi",[["IMessageOutput",32]]],["Method","xmt",[["getProviders",67],["pushMessage",40],["sendOOBControlMessage",77],["subscribe",51],["unsubscribe",60]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=messaging&amp;project=rtmp_client">messaging</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright ? 2006 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a><span class="c">/**
<a class="l" name="27" href="#27">27</a> * Output Endpoint for a provider to connect.
<a class="l" name="28" href="#28">28</a> *
<a class="l" name="29" href="#29">29</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="hl" name="30" href="#30">30</a> * <strong>@author</strong> Steven Gong (steven.gong@gmail.com)
<a class="l" name="31" href="#31">31</a> */</span>
<a class="l" name="32" href="#32">32</a><b>public</b> <b>interface</b> <a class="xi" name="IMessageOutput"/><a href="/source/s?refs=IMessageOutput&amp;project=rtmp_client" class="xi">IMessageOutput</a> {
<a class="l" name="33" href="#33">33</a>	<span class="c">/**
<a class="l" name="34" href="#34">34</a>	 * Push a message to this output endpoint. May block
<a class="l" name="35" href="#35">35</a>	 * the pusher when output can't handle the message at
<a class="l" name="36" href="#36">36</a>	 * the time.
<a class="l" name="37" href="#37">37</a>	 * <strong>@param</strong> <em>message</em> Message to be pushed.
<a class="l" name="38" href="#38">38</a>	 * <strong>@throws</strong> <em>IOException</em> If message could not be written.
<a class="l" name="39" href="#39">39</a>	 */</span>
<a class="hl" name="40" href="#40">40</a>	<b>void</b> <a class="xmt" name="pushMessage"/><a href="/source/s?refs=pushMessage&amp;project=rtmp_client" class="xmt">pushMessage</a>(<a href="/source/s?defs=IMessage&amp;project=rtmp_client">IMessage</a> <a class="xa" name="message"/><a href="/source/s?refs=message&amp;project=rtmp_client" class="xa">message</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="41" href="#41">41</a>
<a class="l" name="42" href="#42">42</a>	<span class="c">/**
<a class="l" name="43" href="#43">43</a>	 * Connect to a provider. Note that params passed has nothing to deal with
<a class="l" name="44" href="#44">44</a>     *  NetConnection.connect in client-side <a href="/source/s?path=Flex/">Flex</a>/<a href="/source/s?path=Flex/Flash">Flash</a> RIA.
<a class="l" name="45" href="#45">45</a>	 *
<a class="l" name="46" href="#46">46</a>	 * <strong>@param</strong> <em>provider</em>       Provider
<a class="l" name="47" href="#47">47</a>	 * <strong>@param</strong> <em>paramMap</em>       Parameters passed with connection
<a class="l" name="48" href="#48">48</a>	 * <strong>@return</strong> &lt;tt&gt;true&lt;/tt&gt; when successfully subscribed,
<a class="l" name="49" href="#49">49</a>	 * &lt;tt&gt;false&lt;/tt&gt; otherwise.
<a class="hl" name="50" href="#50">50</a>	 */</span>
<a class="l" name="51" href="#51">51</a>	<b>boolean</b> <a class="xmt" name="subscribe"/><a href="/source/s?refs=subscribe&amp;project=rtmp_client" class="xmt">subscribe</a>(<a href="/source/s?defs=IProvider&amp;project=rtmp_client">IProvider</a> <a class="xa" name="provider"/><a href="/source/s?refs=provider&amp;project=rtmp_client" class="xa">provider</a>, <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xa" name="paramMap"/><a href="/source/s?refs=paramMap&amp;project=rtmp_client" class="xa">paramMap</a>);
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>	<span class="c">/**
<a class="l" name="54" href="#54">54</a>	 * Disconnect from a provider.
<a class="l" name="55" href="#55">55</a>	 *
<a class="l" name="56" href="#56">56</a>	 * <strong>@param</strong> <em>provider</em>       Provider
<a class="l" name="57" href="#57">57</a>	 * <strong>@return</strong> &lt;tt&gt;true&lt;/tt&gt; when successfully unsubscribed,
<a class="l" name="58" href="#58">58</a>	 * &lt;tt&gt;false&lt;/tt&gt; otherwise.
<a class="l" name="59" href="#59">59</a>	 */</span>
<a class="hl" name="60" href="#60">60</a>	<b>boolean</b> <a class="xmt" name="unsubscribe"/><a href="/source/s?refs=unsubscribe&amp;project=rtmp_client" class="xmt">unsubscribe</a>(<a href="/source/s?defs=IProvider&amp;project=rtmp_client">IProvider</a> <a class="xa" name="provider"/><a href="/source/s?refs=provider&amp;project=rtmp_client" class="xa">provider</a>);
<a class="l" name="61" href="#61">61</a>
<a class="l" name="62" href="#62">62</a>	<span class="c">/**
<a class="l" name="63" href="#63">63</a>     * Getter for providers
<a class="l" name="64" href="#64">64</a>     *
<a class="l" name="65" href="#65">65</a>     * <strong>@return</strong>  Providers
<a class="l" name="66" href="#66">66</a>     */</span>
<a class="l" name="67" href="#67">67</a>    <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=IProvider&amp;project=rtmp_client">IProvider</a>&gt; <a class="xmt" name="getProviders"/><a href="/source/s?refs=getProviders&amp;project=rtmp_client" class="xmt">getProviders</a>();
<a class="l" name="68" href="#68">68</a>
<a class="l" name="69" href="#69">69</a>	<span class="c">/**
<a class="hl" name="70" href="#70">70</a>	 * Send OOB Control Message to all consumers on the other side of pipe.
<a class="l" name="71" href="#71">71</a>	 *
<a class="l" name="72" href="#72">72</a>	 * <strong>@param</strong> <em>provider</em>
<a class="l" name="73" href="#73">73</a>	 *            The provider that sends the message
<a class="l" name="74" href="#74">74</a>	 * <strong>@param</strong> <em>oobCtrlMsg</em>
<a class="l" name="75" href="#75">75</a>     *            Out-of-band control message
<a class="l" name="76" href="#76">76</a>	 */</span>
<a class="l" name="77" href="#77">77</a>	<b>void</b> <a class="xmt" name="sendOOBControlMessage"/><a href="/source/s?refs=sendOOBControlMessage&amp;project=rtmp_client" class="xmt">sendOOBControlMessage</a>(<a href="/source/s?defs=IProvider&amp;project=rtmp_client">IProvider</a> <a class="xa" name="provider"/><a href="/source/s?refs=provider&amp;project=rtmp_client" class="xa">provider</a>, <a href="/source/s?defs=OOBControlMessage&amp;project=rtmp_client">OOBControlMessage</a> <a class="xa" name="oobCtrlMsg"/><a href="/source/s?refs=oobCtrlMsg&amp;project=rtmp_client" class="xa">oobCtrlMsg</a>);
<a class="l" name="78" href="#78">78</a>}
<a class="l" name="79" href="#79">79</a>