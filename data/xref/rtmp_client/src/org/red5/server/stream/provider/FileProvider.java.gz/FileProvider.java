<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["FileProvider",63]]],["Package","xp",[["org.red5.server.stream.provider",1]]],["Method","xmt",[["FileProvider",109],["hasVideo",124],["init",228],["onOOBControlMessage",200],["onPipeConnectionEvent",178],["pullMessage",129],["pullMessage",173],["seek",261],["setStart",119],["uninit",253]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=provider&amp;project=rtmp_client">provider</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=File&amp;project=rtmp_client">File</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IStreamableFile&amp;project=rtmp_client">IStreamableFile</a>;
<a class="l" name="26" href="#26">26</a><span class="c">//import org.red5.io.IStreamableFileFactory;</span>
<a class="l" name="27" href="#27">27</a><span class="c">//import org.red5.io.IStreamableFileService;</span>
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=ITagReader&amp;project=rtmp_client">ITagReader</a>;
<a class="hl" name="30" href="#30">30</a><span class="c">//import org.red5.io.StreamableFileFactory;</span>
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>.<a href="/source/s?defs=FLV&amp;project=rtmp_client">FLV</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>.<a href="/source/s?defs=IKeyFrameDataAnalyzer&amp;project=rtmp_client">IKeyFrameDataAnalyzer</a>;
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=flv&amp;project=rtmp_client">flv</a>.<a href="/source/s?defs=IKeyFrameDataAnalyzer&amp;project=rtmp_client">IKeyFrameDataAnalyzer</a>.<a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a>;
<a class="l" name="34" href="#34">34</a><span class="c">//import org.red5.server.api.IScope;</span>
<a class="l" name="35" href="#35">35</a><span class="c">//import org.red5.server.api.ScopeUtils;</span>
<a class="l" name="36" href="#36">36</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=messaging&amp;project=rtmp_client">messaging</a>.<a href="/source/s?defs=IMessage&amp;project=rtmp_client">IMessage</a>;
<a class="l" name="37" href="#37">37</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=messaging&amp;project=rtmp_client">messaging</a>.<a href="/source/s?defs=IMessageComponent&amp;project=rtmp_client">IMessageComponent</a>;
<a class="l" name="38" href="#38">38</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=messaging&amp;project=rtmp_client">messaging</a>.<a href="/source/s?defs=IPassive&amp;project=rtmp_client">IPassive</a>;
<a class="l" name="39" href="#39">39</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=messaging&amp;project=rtmp_client">messaging</a>.<a href="/source/s?defs=IPipe&amp;project=rtmp_client">IPipe</a>;
<a class="hl" name="40" href="#40">40</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=messaging&amp;project=rtmp_client">messaging</a>.<a href="/source/s?defs=IPipeConnectionListener&amp;project=rtmp_client">IPipeConnectionListener</a>;
<a class="l" name="41" href="#41">41</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=messaging&amp;project=rtmp_client">messaging</a>.<a href="/source/s?defs=IPullableProvider&amp;project=rtmp_client">IPullableProvider</a>;
<a class="l" name="42" href="#42">42</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=messaging&amp;project=rtmp_client">messaging</a>.<a href="/source/s?defs=OOBControlMessage&amp;project=rtmp_client">OOBControlMessage</a>;
<a class="l" name="43" href="#43">43</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=messaging&amp;project=rtmp_client">messaging</a>.<a href="/source/s?defs=PipeConnectionEvent&amp;project=rtmp_client">PipeConnectionEvent</a>;
<a class="l" name="44" href="#44">44</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a class="d" href="#event">event</a>.<a href="/source/s?defs=AudioData&amp;project=rtmp_client">AudioData</a>;
<a class="l" name="45" href="#45">45</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a class="d" href="#event">event</a>.<a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a>;
<a class="l" name="46" href="#46">46</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a class="d" href="#event">event</a>.<a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>;
<a class="l" name="47" href="#47">47</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a class="d" href="#event">event</a>.<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>;
<a class="l" name="48" href="#48">48</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a class="d" href="#event">event</a>.<a href="/source/s?defs=Unknown&amp;project=rtmp_client">Unknown</a>;
<a class="l" name="49" href="#49">49</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a class="d" href="#event">event</a>.<a href="/source/s?defs=VideoData&amp;project=rtmp_client">VideoData</a>;
<a class="hl" name="50" href="#50">50</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a class="d" href="#event">event</a>.<a href="/source/s?defs=FlexStreamSend&amp;project=rtmp_client">FlexStreamSend</a>;
<a class="l" name="51" href="#51">51</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>;
<a class="l" name="52" href="#52">52</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=ISeekableProvider&amp;project=rtmp_client">ISeekableProvider</a>;
<a class="l" name="53" href="#53">53</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=IStreamTypeAwareProvider&amp;project=rtmp_client">IStreamTypeAwareProvider</a>;
<a class="l" name="54" href="#54">54</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=RTMPMessage&amp;project=rtmp_client">RTMPMessage</a>;
<a class="l" name="55" href="#55">55</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="56" href="#56">56</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="57" href="#57">57</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=mp3&amp;project=rtmp_client">mp3</a>.<a href="/source/s?defs=MP3&amp;project=rtmp_client">MP3</a>;
<a class="l" name="58" href="#58">58</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=mp4&amp;project=rtmp_client">mp4</a>.<a href="/source/s?defs=MP4&amp;project=rtmp_client">MP4</a>;
<a class="l" name="59" href="#59">59</a>
<a class="hl" name="60" href="#60">60</a><span class="c">/**
<a class="l" name="61" href="#61">61</a> * Pullable provider for files
<a class="l" name="62" href="#62">62</a> */</span>
<a class="l" name="63" href="#63">63</a><b>public</b> <b>class</b> <a class="xc" name="FileProvider"/><a href="/source/s?refs=FileProvider&amp;project=rtmp_client" class="xc">FileProvider</a> <b>implements</b> <a href="/source/s?defs=IPassive&amp;project=rtmp_client">IPassive</a>, <a href="/source/s?defs=ISeekableProvider&amp;project=rtmp_client">ISeekableProvider</a>, <a href="/source/s?defs=IPullableProvider&amp;project=rtmp_client">IPullableProvider</a>, <a href="/source/s?defs=IPipeConnectionListener&amp;project=rtmp_client">IPipeConnectionListener</a>, <a href="/source/s?defs=IStreamTypeAwareProvider&amp;project=rtmp_client">IStreamTypeAwareProvider</a> {
<a class="l" name="64" href="#64">64</a>	<span class="c">/**
<a class="l" name="65" href="#65">65</a>	 * Logger
<a class="l" name="66" href="#66">66</a>	 */</span>
<a class="l" name="67" href="#67">67</a>	<b>private</b> <b>static</b> <b>final</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a href="/source/s?defs=FileProvider&amp;project=rtmp_client">FileProvider</a>.<b>class</b>);
<a class="l" name="68" href="#68">68</a>
<a class="l" name="69" href="#69">69</a>	<span class="c">/**
<a class="hl" name="70" href="#70">70</a>	 * Class name
<a class="l" name="71" href="#71">71</a>	 */</span>
<a class="l" name="72" href="#72">72</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="KEY"/><a href="/source/s?refs=KEY&amp;project=rtmp_client" class="xfld">KEY</a> = <a href="/source/s?defs=FileProvider&amp;project=rtmp_client">FileProvider</a>.<b>class</b>.<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>();
<a class="l" name="73" href="#73">73</a>
<a class="l" name="74" href="#74">74</a>	<span class="c">/**
<a class="l" name="75" href="#75">75</a>	 * Provider scope
<a class="l" name="76" href="#76">76</a>	 */</span>
<a class="l" name="77" href="#77">77</a><span class="c">//	private IScope scope;</span>
<a class="l" name="78" href="#78">78</a>
<a class="l" name="79" href="#79">79</a>	<span class="c">/**
<a class="hl" name="80" href="#80">80</a>	 * Source file
<a class="l" name="81" href="#81">81</a>	 */</span>
<a class="l" name="82" href="#82">82</a>	<b>private</b> <a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a class="xfld" name="file"/><a href="/source/s?refs=file&amp;project=rtmp_client" class="xfld">file</a>;
<a class="l" name="83" href="#83">83</a>
<a class="l" name="84" href="#84">84</a>	<span class="c">/**
<a class="l" name="85" href="#85">85</a>	 * Consumer pipe
<a class="l" name="86" href="#86">86</a>	 */</span>
<a class="l" name="87" href="#87">87</a>	<b>private</b> <a href="/source/s?defs=IPipe&amp;project=rtmp_client">IPipe</a> <a class="xfld" name="pipe"/><a href="/source/s?refs=pipe&amp;project=rtmp_client" class="xfld">pipe</a>;
<a class="l" name="88" href="#88">88</a>
<a class="l" name="89" href="#89">89</a>	<span class="c">/**
<a class="hl" name="90" href="#90">90</a>	 * Tag reader
<a class="l" name="91" href="#91">91</a>	 */</span>
<a class="l" name="92" href="#92">92</a>	<b>private</b> <a href="/source/s?defs=ITagReader&amp;project=rtmp_client">ITagReader</a> <a class="xfld" name="reader"/><a href="/source/s?refs=reader&amp;project=rtmp_client" class="xfld">reader</a>;
<a class="l" name="93" href="#93">93</a>
<a class="l" name="94" href="#94">94</a>	<span class="c">/**
<a class="l" name="95" href="#95">95</a>	 * Keyframe metadata
<a class="l" name="96" href="#96">96</a>	 */</span>
<a class="l" name="97" href="#97">97</a>	<b>private</b> <a href="/source/s?defs=KeyFrameMeta&amp;project=rtmp_client">KeyFrameMeta</a> <a class="xfld" name="keyFrameMeta"/><a href="/source/s?refs=keyFrameMeta&amp;project=rtmp_client" class="xfld">keyFrameMeta</a>;
<a class="l" name="98" href="#98">98</a>
<a class="l" name="99" href="#99">99</a>	<span class="c">/**
<a class="hl" name="100" href="#100">100</a>	 * Position at start
<a class="l" name="101" href="#101">101</a>	 */</span>
<a class="l" name="102" href="#102">102</a>	<b>private</b> <b>int</b> <a class="xfld" name="start"/><a href="/source/s?refs=start&amp;project=rtmp_client" class="xfld">start</a>;
<a class="l" name="103" href="#103">103</a>
<a class="l" name="104" href="#104">104</a>	<span class="c">/**
<a class="l" name="105" href="#105">105</a>	 * Create file provider for given file and scope
<a class="l" name="106" href="#106">106</a>	 * <strong>@param</strong> <em>scope</em>            Scope
<a class="l" name="107" href="#107">107</a>	 * <strong>@param</strong> <em>file</em>             File
<a class="l" name="108" href="#108">108</a>	 */</span>
<a class="l" name="109" href="#109">109</a>	<b>public</b> <a class="xmt" name="FileProvider"/><a href="/source/s?refs=FileProvider&amp;project=rtmp_client" class="xmt">FileProvider</a>(<a href="/source/s?defs=File&amp;project=rtmp_client">File</a> <a class="xa" name="file"/><a href="/source/s?refs=file&amp;project=rtmp_client" class="xa">file</a>) {
<a class="hl" name="110" href="#110">110</a><span class="c">//		this.scope = scope;</span>
<a class="l" name="111" href="#111">111</a>		<b>this</b>.<a href="/source/s?defs=file&amp;project=rtmp_client">file</a> = <a href="/source/s?defs=file&amp;project=rtmp_client">file</a>;
<a class="l" name="112" href="#112">112</a>	}
<a class="l" name="113" href="#113">113</a>
<a class="l" name="114" href="#114">114</a>	<span class="c">/**
<a class="l" name="115" href="#115">115</a>	 * Setter for start position
<a class="l" name="116" href="#116">116</a>	 *
<a class="l" name="117" href="#117">117</a>	 * <strong>@param</strong> <em>start</em> Start position
<a class="l" name="118" href="#118">118</a>	 */</span>
<a class="l" name="119" href="#119">119</a>	<b>public</b> <b>void</b> <a class="xmt" name="setStart"/><a href="/source/s?refs=setStart&amp;project=rtmp_client" class="xmt">setStart</a>(<b>int</b> <a class="xa" name="start"/><a href="/source/s?refs=start&amp;project=rtmp_client" class="xa">start</a>) {
<a class="hl" name="120" href="#120">120</a>		<b>this</b>.<a href="/source/s?defs=start&amp;project=rtmp_client">start</a> = <a href="/source/s?defs=start&amp;project=rtmp_client">start</a>;
<a class="l" name="121" href="#121">121</a>	}
<a class="l" name="122" href="#122">122</a>
<a class="l" name="123" href="#123">123</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="124" href="#124">124</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="hasVideo"/><a href="/source/s?refs=hasVideo&amp;project=rtmp_client" class="xmt">hasVideo</a>() {
<a class="l" name="125" href="#125">125</a>		<b>return</b> (<a class="d" href="#reader">reader</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a class="d" href="#reader">reader</a>.<a class="d" href="#hasVideo">hasVideo</a>());
<a class="l" name="126" href="#126">126</a>	}
<a class="l" name="127" href="#127">127</a>
<a class="l" name="128" href="#128">128</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="129" href="#129">129</a>	<b>public</b> <b>synchronized</b> <a href="/source/s?defs=IMessage&amp;project=rtmp_client">IMessage</a> <a class="xmt" name="pullMessage"/><a href="/source/s?refs=pullMessage&amp;project=rtmp_client" class="xmt">pullMessage</a>(<a href="/source/s?defs=IPipe&amp;project=rtmp_client">IPipe</a> <a class="xa" name="pipe"/><a href="/source/s?refs=pipe&amp;project=rtmp_client" class="xa">pipe</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="hl" name="130" href="#130">130</a><span class="c">//		if (this.pipe != pipe) {</span>
<a class="l" name="131" href="#131">131</a><span class="c">//			return null;</span>
<a class="l" name="132" href="#132">132</a><span class="c">//		}</span>
<a class="l" name="133" href="#133">133</a>		<b>if</b> (<b>this</b>.<a class="d" href="#reader">reader</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="134" href="#134">134</a>			<a class="d" href="#init">init</a>();
<a class="l" name="135" href="#135">135</a>		}
<a class="l" name="136" href="#136">136</a>		<b>if</b> (!<a class="d" href="#reader">reader</a>.<a href="/source/s?defs=hasMoreTags&amp;project=rtmp_client">hasMoreTags</a>()) {
<a class="l" name="137" href="#137">137</a>			<span class="c">// TODO send OOBCM to notify EOF</span>
<a class="l" name="138" href="#138">138</a>			<span class="c">// Do not unsubscribe as this kills VOD seek while in buffer</span>
<a class="l" name="139" href="#139">139</a>			<span class="c">// this.pipe.unsubscribe(this);</span>
<a class="hl" name="140" href="#140">140</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="141" href="#141">141</a>		}
<a class="l" name="142" href="#142">142</a>		<a href="/source/s?defs=ITag&amp;project=rtmp_client">ITag</a> <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a> = <a class="d" href="#reader">reader</a>.<a href="/source/s?defs=readTag&amp;project=rtmp_client">readTag</a>();
<a class="l" name="143" href="#143">143</a>		<a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a> <a href="/source/s?defs=msg&amp;project=rtmp_client">msg</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="144" href="#144">144</a>		<b>int</b> <a href="/source/s?defs=timestamp&amp;project=rtmp_client">timestamp</a> = <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getTimestamp&amp;project=rtmp_client">getTimestamp</a>();
<a class="l" name="145" href="#145">145</a>		<b>switch</b> (<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>()) {
<a class="l" name="146" href="#146">146</a>			<b>case</b> <a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>.<a href="/source/s?defs=TYPE_AUDIO_DATA&amp;project=rtmp_client">TYPE_AUDIO_DATA</a>:
<a class="l" name="147" href="#147">147</a>				<a href="/source/s?defs=msg&amp;project=rtmp_client">msg</a> = <b>new</b> <a href="/source/s?defs=AudioData&amp;project=rtmp_client">AudioData</a>(<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getBody&amp;project=rtmp_client">getBody</a>());
<a class="l" name="148" href="#148">148</a><span class="c">//				log.error("body size is {}", msg.toString());</span>
<a class="l" name="149" href="#149">149</a>				<b>break</b>;
<a class="hl" name="150" href="#150">150</a>			<b>case</b> <a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>.<a href="/source/s?defs=TYPE_VIDEO_DATA&amp;project=rtmp_client">TYPE_VIDEO_DATA</a>:
<a class="l" name="151" href="#151">151</a>				<a href="/source/s?defs=msg&amp;project=rtmp_client">msg</a> = <b>new</b> <a href="/source/s?defs=VideoData&amp;project=rtmp_client">VideoData</a>(<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getBody&amp;project=rtmp_client">getBody</a>());
<a class="l" name="152" href="#152">152</a>				<b>break</b>;
<a class="l" name="153" href="#153">153</a>			<b>case</b> <a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>.<a href="/source/s?defs=TYPE_INVOKE&amp;project=rtmp_client">TYPE_INVOKE</a>:
<a class="l" name="154" href="#154">154</a>				<a href="/source/s?defs=msg&amp;project=rtmp_client">msg</a> = <b>new</b> <a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>(<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getBody&amp;project=rtmp_client">getBody</a>());
<a class="l" name="155" href="#155">155</a>				<b>break</b>;
<a class="l" name="156" href="#156">156</a>			<b>case</b> <a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>.<a href="/source/s?defs=TYPE_NOTIFY&amp;project=rtmp_client">TYPE_NOTIFY</a>:
<a class="l" name="157" href="#157">157</a>				<a href="/source/s?defs=msg&amp;project=rtmp_client">msg</a> = <b>new</b> <a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>(<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getBody&amp;project=rtmp_client">getBody</a>());
<a class="l" name="158" href="#158">158</a>				<b>break</b>;
<a class="l" name="159" href="#159">159</a>			<b>case</b> <a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>.<a href="/source/s?defs=TYPE_FLEX_STREAM_SEND&amp;project=rtmp_client">TYPE_FLEX_STREAM_SEND</a>:
<a class="hl" name="160" href="#160">160</a>				<a href="/source/s?defs=msg&amp;project=rtmp_client">msg</a> = <b>new</b> <a href="/source/s?defs=FlexStreamSend&amp;project=rtmp_client">FlexStreamSend</a>(<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getBody&amp;project=rtmp_client">getBody</a>());
<a class="l" name="161" href="#161">161</a>				<b>break</b>;
<a class="l" name="162" href="#162">162</a>			<b>default</b>:
<a class="l" name="163" href="#163">163</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Unexpected type? {}"</span>, <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>());
<a class="l" name="164" href="#164">164</a>				<a href="/source/s?defs=msg&amp;project=rtmp_client">msg</a> = <b>new</b> <a href="/source/s?defs=Unknown&amp;project=rtmp_client">Unknown</a>(<a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>(), <a href="/source/s?defs=tag&amp;project=rtmp_client">tag</a>.<a href="/source/s?defs=getBody&amp;project=rtmp_client">getBody</a>());
<a class="l" name="165" href="#165">165</a>		}
<a class="l" name="166" href="#166">166</a>		<a href="/source/s?defs=msg&amp;project=rtmp_client">msg</a>.<a href="/source/s?defs=setTimestamp&amp;project=rtmp_client">setTimestamp</a>(<a href="/source/s?defs=timestamp&amp;project=rtmp_client">timestamp</a>);
<a class="l" name="167" href="#167">167</a>		<a href="/source/s?defs=RTMPMessage&amp;project=rtmp_client">RTMPMessage</a> <a href="/source/s?defs=rtmpMsg&amp;project=rtmp_client">rtmpMsg</a> = <b>new</b> <a href="/source/s?defs=RTMPMessage&amp;project=rtmp_client">RTMPMessage</a>();
<a class="l" name="168" href="#168">168</a>		<a href="/source/s?defs=rtmpMsg&amp;project=rtmp_client">rtmpMsg</a>.<a href="/source/s?defs=setBody&amp;project=rtmp_client">setBody</a>(<a href="/source/s?defs=msg&amp;project=rtmp_client">msg</a>);
<a class="l" name="169" href="#169">169</a>		<b>return</b> <a href="/source/s?defs=rtmpMsg&amp;project=rtmp_client">rtmpMsg</a>;
<a class="hl" name="170" href="#170">170</a>	}
<a class="l" name="171" href="#171">171</a>
<a class="l" name="172" href="#172">172</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="173" href="#173">173</a>	<b>public</b> <a href="/source/s?defs=IMessage&amp;project=rtmp_client">IMessage</a> <a class="xmt" name="pullMessage"/><a href="/source/s?refs=pullMessage&amp;project=rtmp_client" class="xmt">pullMessage</a>(<a href="/source/s?defs=IPipe&amp;project=rtmp_client">IPipe</a> <a class="xa" name="pipe"/><a href="/source/s?refs=pipe&amp;project=rtmp_client" class="xa">pipe</a>, <b>long</b> <a class="xa" name="wait"/><a href="/source/s?refs=wait&amp;project=rtmp_client" class="xa">wait</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="174" href="#174">174</a>		<b>return</b> <a href="/source/s?defs=pullMessage&amp;project=rtmp_client">pullMessage</a>(<a href="/source/s?defs=pipe&amp;project=rtmp_client">pipe</a>);
<a class="l" name="175" href="#175">175</a>	}
<a class="l" name="176" href="#176">176</a>
<a class="l" name="177" href="#177">177</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="178" href="#178">178</a>	<b>public</b> <b>void</b> <a class="xmt" name="onPipeConnectionEvent"/><a href="/source/s?refs=onPipeConnectionEvent&amp;project=rtmp_client" class="xmt">onPipeConnectionEvent</a>(<a href="/source/s?defs=PipeConnectionEvent&amp;project=rtmp_client">PipeConnectionEvent</a> <a class="xa" name="event"/><a href="/source/s?refs=event&amp;project=rtmp_client" class="xa">event</a>) {
<a class="l" name="179" href="#179">179</a>		<b>switch</b> (<a class="d" href="#event">event</a>.<a href="/source/s?defs=getType&amp;project=rtmp_client">getType</a>()) {
<a class="hl" name="180" href="#180">180</a>			<b>case</b> <a href="/source/s?defs=PipeConnectionEvent&amp;project=rtmp_client">PipeConnectionEvent</a>.<a href="/source/s?defs=PROVIDER_CONNECT_PULL&amp;project=rtmp_client">PROVIDER_CONNECT_PULL</a>:
<a class="l" name="181" href="#181">181</a>				<b>if</b> (<a href="/source/s?defs=pipe&amp;project=rtmp_client">pipe</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="182" href="#182">182</a>					<a href="/source/s?defs=pipe&amp;project=rtmp_client">pipe</a> = (<a href="/source/s?defs=IPipe&amp;project=rtmp_client">IPipe</a>) <a class="d" href="#event">event</a>.<a href="/source/s?defs=getSource&amp;project=rtmp_client">getSource</a>();
<a class="l" name="183" href="#183">183</a>				}
<a class="l" name="184" href="#184">184</a>				<b>break</b>;
<a class="l" name="185" href="#185">185</a>			<b>case</b> <a href="/source/s?defs=PipeConnectionEvent&amp;project=rtmp_client">PipeConnectionEvent</a>.<a href="/source/s?defs=PROVIDER_DISCONNECT&amp;project=rtmp_client">PROVIDER_DISCONNECT</a>:
<a class="l" name="186" href="#186">186</a>				<b>if</b> (<a href="/source/s?defs=pipe&amp;project=rtmp_client">pipe</a> == <a class="d" href="#event">event</a>.<a href="/source/s?defs=getSource&amp;project=rtmp_client">getSource</a>()) {
<a class="l" name="187" href="#187">187</a>					<b>this</b>.<a href="/source/s?defs=pipe&amp;project=rtmp_client">pipe</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="188" href="#188">188</a>					<a class="d" href="#uninit">uninit</a>();
<a class="l" name="189" href="#189">189</a>				}
<a class="hl" name="190" href="#190">190</a>				<b>break</b>;
<a class="l" name="191" href="#191">191</a>			<b>case</b> <a href="/source/s?defs=PipeConnectionEvent&amp;project=rtmp_client">PipeConnectionEvent</a>.<a href="/source/s?defs=CONSUMER_DISCONNECT&amp;project=rtmp_client">CONSUMER_DISCONNECT</a>:
<a class="l" name="192" href="#192">192</a>				<b>if</b> (<a href="/source/s?defs=pipe&amp;project=rtmp_client">pipe</a> == <a class="d" href="#event">event</a>.<a href="/source/s?defs=getSource&amp;project=rtmp_client">getSource</a>()) {
<a class="l" name="193" href="#193">193</a>					<a class="d" href="#uninit">uninit</a>();
<a class="l" name="194" href="#194">194</a>				}
<a class="l" name="195" href="#195">195</a>			<b>default</b>:
<a class="l" name="196" href="#196">196</a>		}
<a class="l" name="197" href="#197">197</a>	}
<a class="l" name="198" href="#198">198</a>
<a class="l" name="199" href="#199">199</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="200" href="#200">200</a>	<b>public</b> <b>void</b> <a class="xmt" name="onOOBControlMessage"/><a href="/source/s?refs=onOOBControlMessage&amp;project=rtmp_client" class="xmt">onOOBControlMessage</a>(<a href="/source/s?defs=IMessageComponent&amp;project=rtmp_client">IMessageComponent</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=IPipe&amp;project=rtmp_client">IPipe</a> <a class="xa" name="pipe"/><a href="/source/s?refs=pipe&amp;project=rtmp_client" class="xa">pipe</a>, <a href="/source/s?defs=OOBControlMessage&amp;project=rtmp_client">OOBControlMessage</a> <a class="xa" name="oobCtrlMsg"/><a href="/source/s?refs=oobCtrlMsg&amp;project=rtmp_client" class="xa">oobCtrlMsg</a>) {
<a class="l" name="201" href="#201">201</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=serviceName&amp;project=rtmp_client">serviceName</a> = <a class="d" href="#oobCtrlMsg">oobCtrlMsg</a>.<a href="/source/s?defs=getServiceName&amp;project=rtmp_client">getServiceName</a>();
<a class="l" name="202" href="#202">202</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=target&amp;project=rtmp_client">target</a> = <a class="d" href="#oobCtrlMsg">oobCtrlMsg</a>.<a href="/source/s?defs=getTarget&amp;project=rtmp_client">getTarget</a>();
<a class="l" name="203" href="#203">203</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"onOOBControlMessage - service name: {} target: {}"</span>, <a href="/source/s?defs=serviceName&amp;project=rtmp_client">serviceName</a>, <a href="/source/s?defs=target&amp;project=rtmp_client">target</a>);
<a class="l" name="204" href="#204">204</a>		<b>if</b> (<a href="/source/s?defs=serviceName&amp;project=rtmp_client">serviceName</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="205" href="#205">205</a>			<b>if</b> (<a href="/source/s?defs=IPassive&amp;project=rtmp_client">IPassive</a>.<a class="d" href="#KEY">KEY</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>)) {
<a class="l" name="206" href="#206">206</a>				<b>if</b> (<span class="s">"init"</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=serviceName&amp;project=rtmp_client">serviceName</a>)) {
<a class="l" name="207" href="#207">207</a>					<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a> <a href="/source/s?defs=startTS&amp;project=rtmp_client">startTS</a> = (<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>) <a class="d" href="#oobCtrlMsg">oobCtrlMsg</a>.<a href="/source/s?defs=getServiceParamMap&amp;project=rtmp_client">getServiceParamMap</a>().<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<span class="s">"startTS"</span>);
<a class="l" name="208" href="#208">208</a>					<a class="d" href="#setStart">setStart</a>(<a href="/source/s?defs=startTS&amp;project=rtmp_client">startTS</a>);
<a class="l" name="209" href="#209">209</a>				}
<a class="hl" name="210" href="#210">210</a>			} <b>else</b> <b>if</b> (<a href="/source/s?defs=ISeekableProvider&amp;project=rtmp_client">ISeekableProvider</a>.<a class="d" href="#KEY">KEY</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>)) {
<a class="l" name="211" href="#211">211</a>				<b>if</b> (<span class="s">"seek"</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=serviceName&amp;project=rtmp_client">serviceName</a>)) {
<a class="l" name="212" href="#212">212</a>					<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a> <a href="/source/s?defs=position&amp;project=rtmp_client">position</a> = (<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>) <a class="d" href="#oobCtrlMsg">oobCtrlMsg</a>.<a href="/source/s?defs=getServiceParamMap&amp;project=rtmp_client">getServiceParamMap</a>().<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<span class="s">"position"</span>);
<a class="l" name="213" href="#213">213</a>					<b>int</b> <a href="/source/s?defs=seekPos&amp;project=rtmp_client">seekPos</a> = <a class="d" href="#seek">seek</a>(<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>.<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>());
<a class="l" name="214" href="#214">214</a>					<span class="c">// Return position we seeked to</span>
<a class="l" name="215" href="#215">215</a>					<a class="d" href="#oobCtrlMsg">oobCtrlMsg</a>.<a href="/source/s?defs=setResult&amp;project=rtmp_client">setResult</a>(<a href="/source/s?defs=seekPos&amp;project=rtmp_client">seekPos</a>);
<a class="l" name="216" href="#216">216</a>				}
<a class="l" name="217" href="#217">217</a>			} <b>else</b> <b>if</b> (<a href="/source/s?defs=IStreamTypeAwareProvider&amp;project=rtmp_client">IStreamTypeAwareProvider</a>.<a class="d" href="#KEY">KEY</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>)) {
<a class="l" name="218" href="#218">218</a>				<b>if</b> (<span class="s">"hasVideo"</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=serviceName&amp;project=rtmp_client">serviceName</a>)) {
<a class="l" name="219" href="#219">219</a>					<a class="d" href="#oobCtrlMsg">oobCtrlMsg</a>.<a href="/source/s?defs=setResult&amp;project=rtmp_client">setResult</a>(<a class="d" href="#hasVideo">hasVideo</a>());
<a class="hl" name="220" href="#220">220</a>				}
<a class="l" name="221" href="#221">221</a>			}
<a class="l" name="222" href="#222">222</a>		}
<a class="l" name="223" href="#223">223</a>	}
<a class="l" name="224" href="#224">224</a>
<a class="l" name="225" href="#225">225</a>	<span class="c">/**
<a class="l" name="226" href="#226">226</a>	 * Initializes file provider. Creates streamable file factory and service, seeks to start position
<a class="l" name="227" href="#227">227</a>	 */</span>
<a class="l" name="228" href="#228">228</a>	<b>private</b> <b>void</b> <a class="xmt" name="init"/><a href="/source/s?refs=init&amp;project=rtmp_client" class="xmt">init</a>() <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="229" href="#229">229</a><span class="c">//		IStreamableFileFactory factory = (IStreamableFileFactory) ScopeUtils.getScopeService(scope, IStreamableFileFactory.class, StreamableFileFactory.class);</span>
<a class="hl" name="230" href="#230">230</a><span class="c">//		IStreamableFileService service = factory.getService(file);</span>
<a class="l" name="231" href="#231">231</a><span class="c">//		if (service == null) {</span>
<a class="l" name="232" href="#232">232</a><span class="c">//			log.error("No service found for {}", file.getAbsolutePath());</span>
<a class="l" name="233" href="#233">233</a><span class="c">//			return;</span>
<a class="l" name="234" href="#234">234</a><span class="c">//		}</span>
<a class="l" name="235" href="#235">235</a>		<a href="/source/s?defs=IStreamableFile&amp;project=rtmp_client">IStreamableFile</a> <a href="/source/s?defs=streamFile&amp;project=rtmp_client">streamFile</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="236" href="#236">236</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=fileName&amp;project=rtmp_client">fileName</a> = <a href="/source/s?defs=file&amp;project=rtmp_client">file</a>.<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>();
<a class="l" name="237" href="#237">237</a>		<b>if</b> (<a href="/source/s?defs=fileName&amp;project=rtmp_client">fileName</a>.<a href="/source/s?defs=endsWith&amp;project=rtmp_client">endsWith</a>(<span class="s">"mp3"</span>) || <a href="/source/s?defs=fileName&amp;project=rtmp_client">fileName</a>.<a href="/source/s?defs=endsWith&amp;project=rtmp_client">endsWith</a>(<span class="s">"MP3"</span>)){
<a class="l" name="238" href="#238">238</a>			<a href="/source/s?defs=streamFile&amp;project=rtmp_client">streamFile</a>= <b>new</b> <a href="/source/s?defs=MP3&amp;project=rtmp_client">MP3</a>(<a href="/source/s?defs=file&amp;project=rtmp_client">file</a>);
<a class="l" name="239" href="#239">239</a>		}<b>else</b> <b>if</b> (<a href="/source/s?defs=fileName&amp;project=rtmp_client">fileName</a>.<a href="/source/s?defs=endsWith&amp;project=rtmp_client">endsWith</a>(<span class="s">"mp4"</span>) || <a href="/source/s?defs=fileName&amp;project=rtmp_client">fileName</a>.<a href="/source/s?defs=endsWith&amp;project=rtmp_client">endsWith</a>(<span class="s">"MP4"</span>)){
<a class="hl" name="240" href="#240">240</a>			<a href="/source/s?defs=streamFile&amp;project=rtmp_client">streamFile</a>= <b>new</b> <a href="/source/s?defs=MP4&amp;project=rtmp_client">MP4</a>(<a href="/source/s?defs=file&amp;project=rtmp_client">file</a>);
<a class="l" name="241" href="#241">241</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=fileName&amp;project=rtmp_client">fileName</a>.<a href="/source/s?defs=endsWith&amp;project=rtmp_client">endsWith</a>(<span class="s">"flv"</span>) || <a href="/source/s?defs=fileName&amp;project=rtmp_client">fileName</a>.<a href="/source/s?defs=endsWith&amp;project=rtmp_client">endsWith</a>(<span class="s">"FLV"</span>)) {
<a class="l" name="242" href="#242">242</a>			<a href="/source/s?defs=streamFile&amp;project=rtmp_client">streamFile</a> = <b>new</b> <a href="/source/s?defs=FLV&amp;project=rtmp_client">FLV</a>(<a href="/source/s?defs=file&amp;project=rtmp_client">file</a>);
<a class="l" name="243" href="#243">243</a>		}
<a class="l" name="244" href="#244">244</a>		<a class="d" href="#reader">reader</a> = <a href="/source/s?defs=streamFile&amp;project=rtmp_client">streamFile</a>.<a href="/source/s?defs=getReader&amp;project=rtmp_client">getReader</a>();
<a class="l" name="245" href="#245">245</a>		<b>if</b> (<a href="/source/s?defs=start&amp;project=rtmp_client">start</a> &gt; <span class="n">0</span>) {
<a class="l" name="246" href="#246">246</a>			<a class="d" href="#seek">seek</a>(<a href="/source/s?defs=start&amp;project=rtmp_client">start</a>);
<a class="l" name="247" href="#247">247</a>		}
<a class="l" name="248" href="#248">248</a>	}
<a class="l" name="249" href="#249">249</a>
<a class="hl" name="250" href="#250">250</a>	<span class="c">/**
<a class="l" name="251" href="#251">251</a>	 * Reset
<a class="l" name="252" href="#252">252</a>	 */</span>
<a class="l" name="253" href="#253">253</a>	<b>private</b> <b>synchronized</b> <b>void</b> <a class="xmt" name="uninit"/><a href="/source/s?refs=uninit&amp;project=rtmp_client" class="xmt">uninit</a>() {
<a class="l" name="254" href="#254">254</a>		<b>if</b> (<b>this</b>.<a class="d" href="#reader">reader</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="255" href="#255">255</a>			<b>this</b>.<a class="d" href="#reader">reader</a>.<a href="/source/s?defs=close&amp;project=rtmp_client">close</a>();
<a class="l" name="256" href="#256">256</a>			<b>this</b>.<a class="d" href="#reader">reader</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="257" href="#257">257</a>		}
<a class="l" name="258" href="#258">258</a>	}
<a class="l" name="259" href="#259">259</a>
<a class="hl" name="260" href="#260">260</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="261" href="#261">261</a>	<b>public</b> <b>synchronized</b> <b>int</b> <a class="xmt" name="seek"/><a href="/source/s?refs=seek&amp;project=rtmp_client" class="xmt">seek</a>(<b>int</b> <a class="xa" name="ts"/><a href="/source/s?refs=ts&amp;project=rtmp_client" class="xa">ts</a>) {
<a class="l" name="262" href="#262">262</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Seek ts: {}"</span>, <a class="d" href="#ts">ts</a>);
<a class="l" name="263" href="#263">263</a>		<b>if</b> (<a class="d" href="#keyFrameMeta">keyFrameMeta</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="264" href="#264">264</a>			<b>if</b> (!(<a class="d" href="#reader">reader</a> <b>instanceof</b> <a href="/source/s?defs=IKeyFrameDataAnalyzer&amp;project=rtmp_client">IKeyFrameDataAnalyzer</a>)) {
<a class="l" name="265" href="#265">265</a>				<span class="c">// Seeking not supported</span>
<a class="l" name="266" href="#266">266</a>				<b>return</b> <a class="d" href="#ts">ts</a>;
<a class="l" name="267" href="#267">267</a>			}
<a class="l" name="268" href="#268">268</a>
<a class="l" name="269" href="#269">269</a>			<a class="d" href="#keyFrameMeta">keyFrameMeta</a> = ((<a href="/source/s?defs=IKeyFrameDataAnalyzer&amp;project=rtmp_client">IKeyFrameDataAnalyzer</a>) <a class="d" href="#reader">reader</a>).<a href="/source/s?defs=analyzeKeyFrames&amp;project=rtmp_client">analyzeKeyFrames</a>();
<a class="hl" name="270" href="#270">270</a>		}
<a class="l" name="271" href="#271">271</a>
<a class="l" name="272" href="#272">272</a>		<b>if</b> (<a class="d" href="#keyFrameMeta">keyFrameMeta</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> == <span class="n">0</span>) {
<a class="l" name="273" href="#273">273</a>			<span class="c">// no video keyframe metainfo, it's an audio-only FLV</span>
<a class="l" name="274" href="#274">274</a>			<span class="c">// we skip the seek for now.</span>
<a class="l" name="275" href="#275">275</a>			<span class="c">// TODO add audio-seek capability</span>
<a class="l" name="276" href="#276">276</a>			<b>return</b> <a class="d" href="#ts">ts</a>;
<a class="l" name="277" href="#277">277</a>		}
<a class="l" name="278" href="#278">278</a>		<b>if</b> (<a class="d" href="#ts">ts</a> &gt;= <a class="d" href="#keyFrameMeta">keyFrameMeta</a>.<a href="/source/s?defs=duration&amp;project=rtmp_client">duration</a>) {
<a class="l" name="279" href="#279">279</a>			<span class="c">// Seek at or beyond EOF</span>
<a class="hl" name="280" href="#280">280</a>			<a class="d" href="#reader">reader</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>.<a href="/source/s?defs=MAX_VALUE&amp;project=rtmp_client">MAX_VALUE</a>);
<a class="l" name="281" href="#281">281</a>			<b>return</b> (<b>int</b>) <a class="d" href="#keyFrameMeta">keyFrameMeta</a>.<a href="/source/s?defs=duration&amp;project=rtmp_client">duration</a>;
<a class="l" name="282" href="#282">282</a>		}
<a class="l" name="283" href="#283">283</a>		<b>int</b> <a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a> = <span class="n">0</span>;
<a class="l" name="284" href="#284">284</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#keyFrameMeta">keyFrameMeta</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>; i++) {
<a class="l" name="285" href="#285">285</a>			<b>if</b> (<a class="d" href="#keyFrameMeta">keyFrameMeta</a>.<a href="/source/s?defs=timestamps&amp;project=rtmp_client">timestamps</a>[i] &gt; <a class="d" href="#ts">ts</a>) {
<a class="l" name="286" href="#286">286</a>				<b>break</b>;
<a class="l" name="287" href="#287">287</a>			}
<a class="l" name="288" href="#288">288</a>			<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a> = i;
<a class="l" name="289" href="#289">289</a>		}
<a class="hl" name="290" href="#290">290</a>		<a class="d" href="#reader">reader</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<a class="d" href="#keyFrameMeta">keyFrameMeta</a>.<a href="/source/s?defs=positions&amp;project=rtmp_client">positions</a>[<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>]);
<a class="l" name="291" href="#291">291</a>		<b>return</b> <a class="d" href="#keyFrameMeta">keyFrameMeta</a>.<a href="/source/s?defs=timestamps&amp;project=rtmp_client">timestamps</a>[<a href="/source/s?defs=frame&amp;project=rtmp_client">frame</a>];
<a class="l" name="292" href="#292">292</a>	}
<a class="l" name="293" href="#293">293</a>}
<a class="l" name="294" href="#294">294</a>