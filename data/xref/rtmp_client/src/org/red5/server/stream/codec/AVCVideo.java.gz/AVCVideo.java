<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["AVCVideo",34]]],["Package","xp",[["org.red5.server.stream.codec",1]]],["Method","xmt",[["AVCVideo",74],["addData",112],["canDropFrames",84],["canHandleData",99],["getDecoderConfiguration",183],["getKeyframe",171],["getName",79],["reset",89]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=codec&amp;project=rtmp_client">codec</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a><span class="c">/**
<a class="l" name="27" href="#27">27</a> * Red5 video codec for the AVC (h264) video format.
<a class="l" name="28" href="#28">28</a> *
<a class="l" name="29" href="#29">29</a> * Store DecoderConfigurationRecord and last keyframe (for now! we're cooking a very exciting new!)
<a class="hl" name="30" href="#30">30</a> *
<a class="l" name="31" href="#31">31</a> * <strong>@author</strong> Tiago Jacobs (tiago@imdt.com.br)
<a class="l" name="32" href="#32">32</a> * <strong>@author</strong> Paul Gregoire (mondain@gmail.com)
<a class="l" name="33" href="#33">33</a> */</span>
<a class="l" name="34" href="#34">34</a><b>public</b> <b>class</b> <a class="xc" name="AVCVideo"/><a href="/source/s?refs=AVCVideo&amp;project=rtmp_client" class="xc">AVCVideo</a> <b>implements</b> <a href="/source/s?defs=IVideoStreamCodec&amp;project=rtmp_client">IVideoStreamCodec</a> {
<a class="l" name="35" href="#35">35</a>
<a class="l" name="36" href="#36">36</a>	<b>private</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a href="/source/s?defs=AVCVideo&amp;project=rtmp_client">AVCVideo</a>.<b>class</b>);
<a class="l" name="37" href="#37">37</a>
<a class="l" name="38" href="#38">38</a>	<span class="c">/**
<a class="l" name="39" href="#39">39</a>	 * AVC video codec constant
<a class="hl" name="40" href="#40">40</a>	 */</span>
<a class="l" name="41" href="#41">41</a>	<b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="CODEC_NAME"/><a href="/source/s?refs=CODEC_NAME&amp;project=rtmp_client" class="xfld">CODEC_NAME</a> = <span class="s">"AVC"</span>;
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a>	<span class="c">/**
<a class="l" name="44" href="#44">44</a>	 * Block of data (AVC DecoderConfigurationRecord)
<a class="l" name="45" href="#45">45</a>	 */</span>
<a class="l" name="46" href="#46">46</a>	<b>private</b> <b>byte</b>[] <a class="xfld" name="blockDataAVCDCR"/><a href="/source/s?refs=blockDataAVCDCR&amp;project=rtmp_client" class="xfld">blockDataAVCDCR</a>;
<a class="l" name="47" href="#47">47</a>
<a class="l" name="48" href="#48">48</a>	<span class="c">/**
<a class="l" name="49" href="#49">49</a>	 * Data block size (AVC DecoderConfigurationRecord)
<a class="hl" name="50" href="#50">50</a>	 */</span>
<a class="l" name="51" href="#51">51</a>	<b>private</b> <b>int</b> <a class="xfld" name="blockSizeAVCDCR"/><a href="/source/s?refs=blockSizeAVCDCR&amp;project=rtmp_client" class="xfld">blockSizeAVCDCR</a>;
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>	<span class="c">/**
<a class="l" name="54" href="#54">54</a>	 * Block of data (Last KeyFrame)
<a class="l" name="55" href="#55">55</a>	 */</span>
<a class="l" name="56" href="#56">56</a>	<b>private</b> <b>byte</b>[] <a class="xfld" name="blockDataLKF"/><a href="/source/s?refs=blockDataLKF&amp;project=rtmp_client" class="xfld">blockDataLKF</a>;
<a class="l" name="57" href="#57">57</a>
<a class="l" name="58" href="#58">58</a>	<span class="c">/**
<a class="l" name="59" href="#59">59</a>	 * Data block size (Last KeyFrame)
<a class="hl" name="60" href="#60">60</a>	 */</span>
<a class="l" name="61" href="#61">61</a>	<b>private</b> <b>int</b> <a class="xfld" name="blockSizeLKF"/><a href="/source/s?refs=blockSizeLKF&amp;project=rtmp_client" class="xfld">blockSizeLKF</a>;
<a class="l" name="62" href="#62">62</a>
<a class="l" name="63" href="#63">63</a>	<span class="c">/**
<a class="l" name="64" href="#64">64</a>	 * Number of data blocks (last key frame)
<a class="l" name="65" href="#65">65</a>	 */</span>
<a class="l" name="66" href="#66">66</a>	<b>private</b> <b>int</b> <a class="xfld" name="dataCountLKF"/><a href="/source/s?refs=dataCountLKF&amp;project=rtmp_client" class="xfld">dataCountLKF</a>;
<a class="l" name="67" href="#67">67</a>
<a class="l" name="68" href="#68">68</a>	<span class="c">/**
<a class="l" name="69" href="#69">69</a>	 * Number of data blocks (Decoder Configuration Record)
<a class="hl" name="70" href="#70">70</a>	 */</span>
<a class="l" name="71" href="#71">71</a>	<b>private</b> <b>int</b> <a class="xfld" name="dataCountAVCDCR"/><a href="/source/s?refs=dataCountAVCDCR&amp;project=rtmp_client" class="xfld">dataCountAVCDCR</a>;
<a class="l" name="72" href="#72">72</a>
<a class="l" name="73" href="#73">73</a>	<span class="c">/** Constructs a new AVCVideo. */</span>
<a class="l" name="74" href="#74">74</a>	<b>public</b> <a class="xmt" name="AVCVideo"/><a href="/source/s?refs=AVCVideo&amp;project=rtmp_client" class="xmt">AVCVideo</a>() {
<a class="l" name="75" href="#75">75</a>		<b>this</b>.<a class="d" href="#reset">reset</a>();
<a class="l" name="76" href="#76">76</a>	}
<a class="l" name="77" href="#77">77</a>
<a class="l" name="78" href="#78">78</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="79" href="#79">79</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getName"/><a href="/source/s?refs=getName&amp;project=rtmp_client" class="xmt">getName</a>() {
<a class="hl" name="80" href="#80">80</a>		<b>return</b> <a class="d" href="#CODEC_NAME">CODEC_NAME</a>;
<a class="l" name="81" href="#81">81</a>	}
<a class="l" name="82" href="#82">82</a>
<a class="l" name="83" href="#83">83</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="84" href="#84">84</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="canDropFrames"/><a href="/source/s?refs=canDropFrames&amp;project=rtmp_client" class="xmt">canDropFrames</a>() {
<a class="l" name="85" href="#85">85</a>		<b>return</b> <b>true</b>;
<a class="l" name="86" href="#86">86</a>	}
<a class="l" name="87" href="#87">87</a>
<a class="l" name="88" href="#88">88</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="89" href="#89">89</a>	<b>public</b> <b>void</b> <a class="xmt" name="reset"/><a href="/source/s?refs=reset&amp;project=rtmp_client" class="xmt">reset</a>() {
<a class="hl" name="90" href="#90">90</a>		<b>this</b>.<a class="d" href="#blockDataLKF">blockDataLKF</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="91" href="#91">91</a>		<b>this</b>.<a class="d" href="#blockSizeLKF">blockSizeLKF</a> = <span class="n">0</span>;
<a class="l" name="92" href="#92">92</a>		<b>this</b>.<a class="d" href="#blockSizeAVCDCR">blockSizeAVCDCR</a> = <span class="n">0</span>;
<a class="l" name="93" href="#93">93</a>		<b>this</b>.<a class="d" href="#blockDataAVCDCR">blockDataAVCDCR</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="94" href="#94">94</a>		<b>this</b>.<a class="d" href="#dataCountLKF">dataCountLKF</a> = <span class="n">0</span>;
<a class="l" name="95" href="#95">95</a>		<b>this</b>.<a class="d" href="#dataCountAVCDCR">dataCountAVCDCR</a> = <span class="n">0</span>;
<a class="l" name="96" href="#96">96</a>	}
<a class="l" name="97" href="#97">97</a>
<a class="l" name="98" href="#98">98</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="99" href="#99">99</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="canHandleData"/><a href="/source/s?refs=canHandleData&amp;project=rtmp_client" class="xmt">canHandleData</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="data"/><a href="/source/s?refs=data&amp;project=rtmp_client" class="xa">data</a>) {
<a class="hl" name="100" href="#100">100</a>		<b>if</b> (<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>() == <span class="n">0</span>) {
<a class="l" name="101" href="#101">101</a>			<span class="c">// Empty buffer</span>
<a class="l" name="102" href="#102">102</a>			<b>return</b> <b>false</b>;
<a class="l" name="103" href="#103">103</a>		}
<a class="l" name="104" href="#104">104</a>
<a class="l" name="105" href="#105">105</a>		<b>byte</b> <a href="/source/s?defs=first&amp;project=rtmp_client">first</a> = <a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="106" href="#106">106</a>		<b>boolean</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = ((<a href="/source/s?defs=first&amp;project=rtmp_client">first</a> &amp; <span class="n">0x0f</span>) == <a href="/source/s?defs=VideoCodec&amp;project=rtmp_client">VideoCodec</a>.<a href="/source/s?defs=AVC&amp;project=rtmp_client">AVC</a>.<a href="/source/s?defs=getId&amp;project=rtmp_client">getId</a>());
<a class="l" name="107" href="#107">107</a>		<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=rewind&amp;project=rtmp_client">rewind</a>();
<a class="l" name="108" href="#108">108</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="109" href="#109">109</a>	}
<a class="hl" name="110" href="#110">110</a>
<a class="l" name="111" href="#111">111</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="112" href="#112">112</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="addData"/><a href="/source/s?refs=addData&amp;project=rtmp_client" class="xmt">addData</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="data"/><a href="/source/s?refs=data&amp;project=rtmp_client" class="xa">data</a>) {
<a class="l" name="113" href="#113">113</a>		<b>if</b> (<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>() &gt; <span class="n">0</span>) {
<a class="l" name="114" href="#114">114</a>
<a class="l" name="115" href="#115">115</a>			<span class="c">//ensure that we can "handle" the data</span>
<a class="l" name="116" href="#116">116</a>    		<b>if</b> (!<a class="d" href="#canHandleData">canHandleData</a>(<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>)) {
<a class="l" name="117" href="#117">117</a>    			<b>return</b> <b>false</b>;
<a class="l" name="118" href="#118">118</a>    		}
<a class="l" name="119" href="#119">119</a>
<a class="hl" name="120" href="#120">120</a>    		<b>byte</b> <a href="/source/s?defs=frameType&amp;project=rtmp_client">frameType</a> = <a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>    		<span class="c">//check for keyframe</span>
<a class="l" name="123" href="#123">123</a>    		<b>if</b> ((<a href="/source/s?defs=frameType&amp;project=rtmp_client">frameType</a> &amp; <span class="n">0xf0</span>) == <a href="/source/s?defs=FLV_FRAME_KEY&amp;project=rtmp_client">FLV_FRAME_KEY</a>) {
<a class="l" name="124" href="#124">124</a>    			<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Key frame found"</span>);
<a class="l" name="125" href="#125">125</a>    			<span class="c">//If we don't have the AVCDecoderConfigurationRecord stored...</span>
<a class="l" name="126" href="#126">126</a>    			<b>if</b> (<a class="d" href="#blockDataAVCDCR">blockDataAVCDCR</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="127" href="#127">127</a>    				<span class="c">//data.get();//Frame Type - already read above</span>
<a class="l" name="128" href="#128">128</a>    				<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();<span class="c">//CODECID</span>
<a class="l" name="129" href="#129">129</a>
<a class="hl" name="130" href="#130">130</a>    				<b>byte</b> <a href="/source/s?defs=AVCPacketType&amp;project=rtmp_client">AVCPacketType</a> = <a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="131" href="#131">131</a>
<a class="l" name="132" href="#132">132</a>    				<span class="c">//Sequence Header / here comes a AVCDecoderConfigurationRecord</span>
<a class="l" name="133" href="#133">133</a>    				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"AVCPacketType: {}"</span>, <a href="/source/s?defs=AVCPacketType&amp;project=rtmp_client">AVCPacketType</a>);
<a class="l" name="134" href="#134">134</a>    				<b>if</b> (<a href="/source/s?defs=AVCPacketType&amp;project=rtmp_client">AVCPacketType</a> == <span class="n">0</span>) {
<a class="l" name="135" href="#135">135</a>    					<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Decoder configuration found"</span>);
<a class="l" name="136" href="#136">136</a>    					<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=rewind&amp;project=rtmp_client">rewind</a>();
<a class="l" name="137" href="#137">137</a>
<a class="l" name="138" href="#138">138</a>    					<span class="c">// Store AVCDecoderConfigurationRecord data</span>
<a class="l" name="139" href="#139">139</a>    					<b>this</b>.<a class="d" href="#dataCountAVCDCR">dataCountAVCDCR</a> = <a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>();
<a class="hl" name="140" href="#140">140</a>
<a class="l" name="141" href="#141">141</a>    					<b>if</b> (<b>this</b>.<a class="d" href="#blockSizeAVCDCR">blockSizeAVCDCR</a> &lt; <b>this</b>.<a class="d" href="#dataCountAVCDCR">dataCountAVCDCR</a>) {
<a class="l" name="142" href="#142">142</a>    						<b>this</b>.<a class="d" href="#blockSizeAVCDCR">blockSizeAVCDCR</a> = <b>this</b>.<a class="d" href="#dataCountAVCDCR">dataCountAVCDCR</a>;
<a class="l" name="143" href="#143">143</a>    						<b>this</b>.<a class="d" href="#blockDataAVCDCR">blockDataAVCDCR</a> = <b>new</b> <b>byte</b>[<b>this</b>.<a class="d" href="#blockSizeAVCDCR">blockSizeAVCDCR</a>];
<a class="l" name="144" href="#144">144</a>    					}
<a class="l" name="145" href="#145">145</a>
<a class="l" name="146" href="#146">146</a>    					<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<b>this</b>.<a class="d" href="#blockDataAVCDCR">blockDataAVCDCR</a>, <span class="n">0</span>, <b>this</b>.<a class="d" href="#dataCountAVCDCR">dataCountAVCDCR</a>);
<a class="l" name="147" href="#147">147</a>    				}
<a class="l" name="148" href="#148">148</a>    			}
<a class="l" name="149" href="#149">149</a>
<a class="hl" name="150" href="#150">150</a>    			<span class="c">//rewind data prior to reading the keyframe</span>
<a class="l" name="151" href="#151">151</a>    			<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=rewind&amp;project=rtmp_client">rewind</a>();
<a class="l" name="152" href="#152">152</a>
<a class="l" name="153" href="#153">153</a>    			<span class="c">// Store last keyframe</span>
<a class="l" name="154" href="#154">154</a>    			<b>this</b>.<a class="d" href="#dataCountLKF">dataCountLKF</a> = <a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>();
<a class="l" name="155" href="#155">155</a>    			<b>if</b> (<b>this</b>.<a class="d" href="#blockSizeLKF">blockSizeLKF</a> &lt; <b>this</b>.<a class="d" href="#dataCountLKF">dataCountLKF</a>) {
<a class="l" name="156" href="#156">156</a>    				<b>this</b>.<a class="d" href="#blockSizeLKF">blockSizeLKF</a> = <b>this</b>.<a class="d" href="#dataCountLKF">dataCountLKF</a>;
<a class="l" name="157" href="#157">157</a>    				<b>this</b>.<a class="d" href="#blockDataLKF">blockDataLKF</a> = <b>new</b> <b>byte</b>[<b>this</b>.<a class="d" href="#blockSizeLKF">blockSizeLKF</a>];
<a class="l" name="158" href="#158">158</a>    			}
<a class="l" name="159" href="#159">159</a>
<a class="hl" name="160" href="#160">160</a>    			<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<b>this</b>.<a class="d" href="#blockDataLKF">blockDataLKF</a>, <span class="n">0</span>, <b>this</b>.<a class="d" href="#dataCountLKF">dataCountLKF</a>);
<a class="l" name="161" href="#161">161</a>    		}
<a class="l" name="162" href="#162">162</a>
<a class="l" name="163" href="#163">163</a>    		<span class="c">//finished with the data, rewind one last time</span>
<a class="l" name="164" href="#164">164</a>    		<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=rewind&amp;project=rtmp_client">rewind</a>();
<a class="l" name="165" href="#165">165</a>		}
<a class="l" name="166" href="#166">166</a>
<a class="l" name="167" href="#167">167</a>		<b>return</b> <b>true</b>;
<a class="l" name="168" href="#168">168</a>	}
<a class="l" name="169" href="#169">169</a>
<a class="hl" name="170" href="#170">170</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="171" href="#171">171</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="getKeyframe"/><a href="/source/s?refs=getKeyframe&amp;project=rtmp_client" class="xmt">getKeyframe</a>() {
<a class="l" name="172" href="#172">172</a>		<b>if</b> (<b>this</b>.<a class="d" href="#dataCountLKF">dataCountLKF</a> == <span class="n">0</span>) {
<a class="l" name="173" href="#173">173</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="174" href="#174">174</a>		}
<a class="l" name="175" href="#175">175</a>
<a class="l" name="176" href="#176">176</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<a class="d" href="#dataCountLKF">dataCountLKF</a>);
<a class="l" name="177" href="#177">177</a>		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#blockDataLKF">blockDataLKF</a>, <span class="n">0</span>, <a class="d" href="#dataCountLKF">dataCountLKF</a>);
<a class="l" name="178" href="#178">178</a>		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="179" href="#179">179</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="hl" name="180" href="#180">180</a>	}
<a class="l" name="181" href="#181">181</a>
<a class="l" name="182" href="#182">182</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="183" href="#183">183</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="getDecoderConfiguration"/><a href="/source/s?refs=getDecoderConfiguration&amp;project=rtmp_client" class="xmt">getDecoderConfiguration</a>() {
<a class="l" name="184" href="#184">184</a>		<b>if</b> (<a class="d" href="#dataCountAVCDCR">dataCountAVCDCR</a> == <span class="n">0</span>) {
<a class="l" name="185" href="#185">185</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="186" href="#186">186</a>		}
<a class="l" name="187" href="#187">187</a>
<a class="l" name="188" href="#188">188</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<a class="d" href="#dataCountAVCDCR">dataCountAVCDCR</a>);
<a class="l" name="189" href="#189">189</a>		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#blockDataAVCDCR">blockDataAVCDCR</a>, <span class="n">0</span>, <a class="d" href="#dataCountAVCDCR">dataCountAVCDCR</a>);
<a class="hl" name="190" href="#190">190</a>		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="191" href="#191">191</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="192" href="#192">192</a>	}
<a class="l" name="193" href="#193">193</a>}
<a class="l" name="194" href="#194">194</a>