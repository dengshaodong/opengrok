<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["AbstractStream",33]]],["Package","xp",[["org.red5.server.stream",1]]],["Method","xmt",[["getCodecInfo",77],["getCreationTime",103],["getMetaData",86],["getName",69],["setCodecInfo",119],["setName",111]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><span class="c">//import org.red5.server.api.IScope;</span>
<a class="l" name="23" href="#23">23</a><span class="c">//import org.red5.server.api.IScopeHandler;</span>
<a class="l" name="24" href="#24">24</a><span class="c">//import org.red5.server.api.stream.IStreamAwareScopeHandler;</span>
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>;
<a class="l" name="26" href="#26">26</a>
<a class="l" name="27" href="#27">27</a><span class="c">/**
<a class="l" name="28" href="#28">28</a> * Abstract base implementation of IStream. Contains codec information, stream name, scope, event handling
<a class="l" name="29" href="#29">29</a> * meand, provides stream start and stop operations.
<a class="hl" name="30" href="#30">30</a> *
<a class="l" name="31" href="#31">31</a> * <strong>@see</strong>  org.red5.server.stream.IStream
<a class="l" name="32" href="#32">32</a> */</span>
<a class="l" name="33" href="#33">33</a><b>public</b> <b>abstract</b> <b>class</b> <a class="xc" name="AbstractStream"/><a href="/source/s?refs=AbstractStream&amp;project=rtmp_client" class="xc">AbstractStream</a> <b>implements</b> <a href="/source/s?defs=IStream&amp;project=rtmp_client">IStream</a> {
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a>    <span class="c">/**
<a class="l" name="36" href="#36">36</a>     * Current state
<a class="l" name="37" href="#37">37</a>     */</span>
<a class="l" name="38" href="#38">38</a>    <b>protected</b> <a href="/source/s?defs=StreamState&amp;project=rtmp_client">StreamState</a> <a class="xfld" name="state"/><a href="/source/s?refs=state&amp;project=rtmp_client" class="xfld">state</a> = <a href="/source/s?defs=StreamState&amp;project=rtmp_client">StreamState</a>.<a href="/source/s?defs=UNINIT&amp;project=rtmp_client">UNINIT</a>;
<a class="l" name="39" href="#39">39</a>
<a class="hl" name="40" href="#40">40</a>	<span class="c">/**
<a class="l" name="41" href="#41">41</a>     *  Stream name
<a class="l" name="42" href="#42">42</a>     */</span>
<a class="l" name="43" href="#43">43</a>    <b>private</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xfld">name</a>;
<a class="l" name="44" href="#44">44</a>
<a class="l" name="45" href="#45">45</a>    <span class="c">/**
<a class="l" name="46" href="#46">46</a>     *  Stream audio and video codec information
<a class="l" name="47" href="#47">47</a>     */</span>
<a class="l" name="48" href="#48">48</a>	<b>private</b> <a href="/source/s?defs=IStreamCodecInfo&amp;project=rtmp_client">IStreamCodecInfo</a> <a class="xfld" name="codecInfo"/><a href="/source/s?refs=codecInfo&amp;project=rtmp_client" class="xfld">codecInfo</a>;
<a class="l" name="49" href="#49">49</a>
<a class="hl" name="50" href="#50">50</a>	<span class="c">/**
<a class="l" name="51" href="#51">51</a>	 * Stores the streams metadata
<a class="l" name="52" href="#52">52</a>	 */</span>
<a class="l" name="53" href="#53">53</a>	<b>protected</b> <a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a> <a class="xfld" name="metaData"/><a href="/source/s?refs=metaData&amp;project=rtmp_client" class="xfld">metaData</a>;
<a class="l" name="54" href="#54">54</a>
<a class="l" name="55" href="#55">55</a>	<span class="c">/**
<a class="l" name="56" href="#56">56</a>     *  Stream scope
<a class="l" name="57" href="#57">57</a>     */</span>
<a class="l" name="58" href="#58">58</a><span class="c">//	private IScope scope;</span>
<a class="l" name="59" href="#59">59</a>
<a class="hl" name="60" href="#60">60</a>	<span class="c">/**
<a class="l" name="61" href="#61">61</a>	 * Timestamp the stream was created.
<a class="l" name="62" href="#62">62</a>	 */</span>
<a class="l" name="63" href="#63">63</a>	<b>protected</b> <b>long</b> <a class="xfld" name="creationTime"/><a href="/source/s?refs=creationTime&amp;project=rtmp_client" class="xfld">creationTime</a>;
<a class="l" name="64" href="#64">64</a>
<a class="l" name="65" href="#65">65</a>    <span class="c">/**
<a class="l" name="66" href="#66">66</a>     *  Return stream name
<a class="l" name="67" href="#67">67</a>     *  <strong>@return</strong>     Stream name
<a class="l" name="68" href="#68">68</a>     */</span>
<a class="l" name="69" href="#69">69</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getName"/><a href="/source/s?refs=getName&amp;project=rtmp_client" class="xmt">getName</a>() {
<a class="hl" name="70" href="#70">70</a>		<b>return</b> <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>;
<a class="l" name="71" href="#71">71</a>	}
<a class="l" name="72" href="#72">72</a>
<a class="l" name="73" href="#73">73</a>    <span class="c">/**
<a class="l" name="74" href="#74">74</a>     * Return codec information
<a class="l" name="75" href="#75">75</a>     * <strong>@return</strong>              Stream codec information
<a class="l" name="76" href="#76">76</a>     */</span>
<a class="l" name="77" href="#77">77</a>    <b>public</b> <a href="/source/s?defs=IStreamCodecInfo&amp;project=rtmp_client">IStreamCodecInfo</a> <a class="xmt" name="getCodecInfo"/><a href="/source/s?refs=getCodecInfo&amp;project=rtmp_client" class="xmt">getCodecInfo</a>() {
<a class="l" name="78" href="#78">78</a>		<b>return</b> <a href="/source/s?defs=codecInfo&amp;project=rtmp_client">codecInfo</a>;
<a class="l" name="79" href="#79">79</a>	}
<a class="hl" name="80" href="#80">80</a>
<a class="l" name="81" href="#81">81</a>	<span class="c">/**
<a class="l" name="82" href="#82">82</a>	 * Returns the metadata for the associated stream, if it exists.
<a class="l" name="83" href="#83">83</a>	 *
<a class="l" name="84" href="#84">84</a>	 * <strong>@return</strong> stream meta data
<a class="l" name="85" href="#85">85</a>	 */</span>
<a class="l" name="86" href="#86">86</a>	<b>public</b> <a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a> <a class="xmt" name="getMetaData"/><a href="/source/s?refs=getMetaData&amp;project=rtmp_client" class="xmt">getMetaData</a>() {
<a class="l" name="87" href="#87">87</a>		<b>return</b> <a class="d" href="#metaData">metaData</a>;
<a class="l" name="88" href="#88">88</a>	}
<a class="l" name="89" href="#89">89</a>
<a class="hl" name="90" href="#90">90</a>    <span class="c">/**
<a class="l" name="91" href="#91">91</a>     * Return scope
<a class="l" name="92" href="#92">92</a>     * <strong>@return</strong>         Scope
<a class="l" name="93" href="#93">93</a>     */</span>
<a class="l" name="94" href="#94">94</a><span class="c">//    public IScope getScope() {</span>
<a class="l" name="95" href="#95">95</a><span class="c">//		return scope;</span>
<a class="l" name="96" href="#96">96</a><span class="c">//	}</span>
<a class="l" name="97" href="#97">97</a>
<a class="l" name="98" href="#98">98</a>	<span class="c">/**
<a class="l" name="99" href="#99">99</a>	 * Returns timestamp at which the stream was created.
<a class="hl" name="100" href="#100">100</a>	 *
<a class="l" name="101" href="#101">101</a>	 * <strong>@return</strong> creation timestamp
<a class="l" name="102" href="#102">102</a>	 */</span>
<a class="l" name="103" href="#103">103</a>	<b>public</b> <b>long</b> <a class="xmt" name="getCreationTime"/><a href="/source/s?refs=getCreationTime&amp;project=rtmp_client" class="xmt">getCreationTime</a>() {
<a class="l" name="104" href="#104">104</a>		<b>return</b> <a class="d" href="#creationTime">creationTime</a>;
<a class="l" name="105" href="#105">105</a>	}
<a class="l" name="106" href="#106">106</a>
<a class="l" name="107" href="#107">107</a>    <span class="c">/**
<a class="l" name="108" href="#108">108</a>     * Setter for name
<a class="l" name="109" href="#109">109</a>     * <strong>@param</strong> <em>name</em>     Stream name
<a class="hl" name="110" href="#110">110</a>     */</span>
<a class="l" name="111" href="#111">111</a>	<b>public</b> <b>void</b> <a class="xmt" name="setName"/><a href="/source/s?refs=setName&amp;project=rtmp_client" class="xmt">setName</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="l" name="112" href="#112">112</a>		<b>this</b>.<a href="/source/s?defs=name&amp;project=rtmp_client">name</a> = <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>;
<a class="l" name="113" href="#113">113</a>	}
<a class="l" name="114" href="#114">114</a>
<a class="l" name="115" href="#115">115</a>    <span class="c">/**
<a class="l" name="116" href="#116">116</a>     * Setter for codec info
<a class="l" name="117" href="#117">117</a>     * <strong>@param</strong> <em>codecInfo</em>     Codec info
<a class="l" name="118" href="#118">118</a>     */</span>
<a class="l" name="119" href="#119">119</a>    <b>public</b> <b>void</b> <a class="xmt" name="setCodecInfo"/><a href="/source/s?refs=setCodecInfo&amp;project=rtmp_client" class="xmt">setCodecInfo</a>(<a href="/source/s?defs=IStreamCodecInfo&amp;project=rtmp_client">IStreamCodecInfo</a> <a class="xa" name="codecInfo"/><a href="/source/s?refs=codecInfo&amp;project=rtmp_client" class="xa">codecInfo</a>) {
<a class="hl" name="120" href="#120">120</a>		<b>this</b>.<a href="/source/s?defs=codecInfo&amp;project=rtmp_client">codecInfo</a> = <a href="/source/s?defs=codecInfo&amp;project=rtmp_client">codecInfo</a>;
<a class="l" name="121" href="#121">121</a>	}
<a class="l" name="122" href="#122">122</a>
<a class="l" name="123" href="#123">123</a>    <span class="c">/**
<a class="l" name="124" href="#124">124</a>     * Setter for scope
<a class="l" name="125" href="#125">125</a>     * <strong>@param</strong> <em>scope</em>         Scope
<a class="l" name="126" href="#126">126</a>     */</span>
<a class="l" name="127" href="#127">127</a><span class="c">//	public void setScope(IScope scope) {</span>
<a class="l" name="128" href="#128">128</a><span class="c">//		this.scope = scope;</span>
<a class="l" name="129" href="#129">129</a><span class="c">//	}</span>
<a class="hl" name="130" href="#130">130</a>
<a class="l" name="131" href="#131">131</a>    <span class="c">/**
<a class="l" name="132" href="#132">132</a>     * Return stream aware scope handler or null if scope is null
<a class="l" name="133" href="#133">133</a>     * <strong>@return</strong>      IStreamAwareScopeHandler implementation
<a class="l" name="134" href="#134">134</a>     */</span>
<a class="l" name="135" href="#135">135</a><span class="c">//	protected IStreamAwareScopeHandler getStreamAwareHandler() {</span>
<a class="l" name="136" href="#136">136</a><span class="c">////		if (scope != null) {</span>
<a class="l" name="137" href="#137">137</a><span class="c">////			IScopeHandler handler = scope.getHandler();</span>
<a class="l" name="138" href="#138">138</a><span class="c">////			if (handler instanceof IStreamAwareScopeHandler) {</span>
<a class="l" name="139" href="#139">139</a><span class="c">////				return (IStreamAwareScopeHandler) handler;</span>
<a class="hl" name="140" href="#140">140</a><span class="c">////			}</span>
<a class="l" name="141" href="#141">141</a><span class="c">////		}</span>
<a class="l" name="142" href="#142">142</a><span class="c">//		return null;</span>
<a class="l" name="143" href="#143">143</a><span class="c">//	}</span>
<a class="l" name="144" href="#144">144</a>}
<a class="l" name="145" href="#145">145</a>