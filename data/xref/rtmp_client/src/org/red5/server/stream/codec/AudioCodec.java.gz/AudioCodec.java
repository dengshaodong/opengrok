<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.red5.server.stream.codec",1]]],["Enum","xe",[["AAC",34],["ADPCM",31],["AudioCodec",29],["DEVICE_SPECIFIC",35],["MP3",31],["MP3_8K",34],["NELLY_MOSER",32],["NELLY_MOSER_16K",32],["NELLY_MOSER_8K",32],["PCM",31],["PCM_ALAW",33],["PCM_LE",31],["PCM_MULAW",33],["RESERVED",33],["SPEEX",34]]],["Method","xmt",[["AudioCodec",39],["getId",49]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=codec&amp;project=rtmp_client">codec</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a>
<a class="l" name="23" href="#23">23</a><span class="c">/**
<a class="l" name="24" href="#24">24</a> * Audio codecs that Red5 supports.
<a class="l" name="25" href="#25">25</a> *
<a class="l" name="26" href="#26">26</a> * <strong>@author</strong> Art Clarke
<a class="l" name="27" href="#27">27</a> * <strong>@author</strong> Paul Gregoire (mondain@gmail.com)
<a class="l" name="28" href="#28">28</a> */</span>
<a class="l" name="29" href="#29">29</a><b>public</b> <b>enum</b> <a class="xe" name="AudioCodec"/><a href="/source/s?refs=AudioCodec&amp;project=rtmp_client" class="xe">AudioCodec</a> {
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a>	<a class="xe" name="PCM"/><a href="/source/s?refs=PCM&amp;project=rtmp_client" class="xe">PCM</a>((<b>byte</b>) <span class="n">0</span>), <a class="xe" name="ADPCM"/><a href="/source/s?refs=ADPCM&amp;project=rtmp_client" class="xe">ADPCM</a>((<b>byte</b>) <span class="n">0x01</span>), <a class="xe" name="MP3"/><a href="/source/s?refs=MP3&amp;project=rtmp_client" class="xe">MP3</a>((<b>byte</b>) <span class="n">0x02</span>), <a class="xe" name="PCM_LE"/><a href="/source/s?refs=PCM_LE&amp;project=rtmp_client" class="xe">PCM_LE</a>((<b>byte</b>) <span class="n">0x03</span>),
<a class="l" name="32" href="#32">32</a>	<a class="xe" name="NELLY_MOSER_16K"/><a href="/source/s?refs=NELLY_MOSER_16K&amp;project=rtmp_client" class="xe">NELLY_MOSER_16K</a>((<b>byte</b>) <span class="n">0x04</span>), <a class="xe" name="NELLY_MOSER_8K"/><a href="/source/s?refs=NELLY_MOSER_8K&amp;project=rtmp_client" class="xe">NELLY_MOSER_8K</a>((<b>byte</b>) <span class="n">0x05</span>), <a class="xe" name="NELLY_MOSER"/><a href="/source/s?refs=NELLY_MOSER&amp;project=rtmp_client" class="xe">NELLY_MOSER</a>((<b>byte</b>) <span class="n">0x06</span>),
<a class="l" name="33" href="#33">33</a>	<a class="xe" name="PCM_ALAW"/><a href="/source/s?refs=PCM_ALAW&amp;project=rtmp_client" class="xe">PCM_ALAW</a>((<b>byte</b>) <span class="n">0x07</span>), <a class="xe" name="PCM_MULAW"/><a href="/source/s?refs=PCM_MULAW&amp;project=rtmp_client" class="xe">PCM_MULAW</a>((<b>byte</b>) <span class="n">0x08</span>), <a class="xe" name="RESERVED"/><a href="/source/s?refs=RESERVED&amp;project=rtmp_client" class="xe">RESERVED</a>((<b>byte</b>) <span class="n">0x09</span>),
<a class="l" name="34" href="#34">34</a>	<a class="xe" name="AAC"/><a href="/source/s?refs=AAC&amp;project=rtmp_client" class="xe">AAC</a>((<b>byte</b>) <span class="n">0x0a</span>), <a class="xe" name="SPEEX"/><a href="/source/s?refs=SPEEX&amp;project=rtmp_client" class="xe">SPEEX</a>((<b>byte</b>) <span class="n">0x0b</span>), <a class="xe" name="MP3_8K"/><a href="/source/s?refs=MP3_8K&amp;project=rtmp_client" class="xe">MP3_8K</a>((<b>byte</b>) <span class="n">0x0e</span>),
<a class="l" name="35" href="#35">35</a>	<a class="xe" name="DEVICE_SPECIFIC"/><a href="/source/s?refs=DEVICE_SPECIFIC&amp;project=rtmp_client" class="xe">DEVICE_SPECIFIC</a>((<b>byte</b>) <span class="n">0x0f</span>);
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a>	<b>private</b> <b>byte</b> <a class="xfld" name="id"/><a href="/source/s?refs=id&amp;project=rtmp_client" class="xfld">id</a>;
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>	<b>private</b> <a class="xmt" name="AudioCodec"/><a href="/source/s?refs=AudioCodec&amp;project=rtmp_client" class="xmt">AudioCodec</a>(<b>byte</b> <a class="xa" name="id"/><a href="/source/s?refs=id&amp;project=rtmp_client" class="xa">id</a>) {
<a class="hl" name="40" href="#40">40</a>		<b>this</b>.<a href="/source/s?defs=id&amp;project=rtmp_client">id</a> = <a href="/source/s?defs=id&amp;project=rtmp_client">id</a>;
<a class="l" name="41" href="#41">41</a>	}
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a>	<span class="c">/**
<a class="l" name="44" href="#44">44</a>	 * Returns back a numeric id for this codec, that happens to correspond to the
<a class="l" name="45" href="#45">45</a>	 * numeric identifier that FLV will use for this codec.
<a class="l" name="46" href="#46">46</a>	 *
<a class="l" name="47" href="#47">47</a>	 * <strong>@return</strong> the codec id
<a class="l" name="48" href="#48">48</a>	 */</span>
<a class="l" name="49" href="#49">49</a>	<b>public</b> <b>byte</b> <a class="xmt" name="getId"/><a href="/source/s?refs=getId&amp;project=rtmp_client" class="xmt">getId</a>() {
<a class="hl" name="50" href="#50">50</a>		<b>return</b> <a href="/source/s?defs=id&amp;project=rtmp_client">id</a>;
<a class="l" name="51" href="#51">51</a>	}
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>}