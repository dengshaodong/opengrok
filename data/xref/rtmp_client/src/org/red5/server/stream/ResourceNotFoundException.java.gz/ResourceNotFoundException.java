<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["ResourceNotFoundException",22]]],["Package","xp",[["org.red5.server.stream",1]]],["Method","xmt",[["ResourceNotFoundException",26],["ResourceNotFoundException",30],["ResourceNotFoundException",34],["ResourceNotFoundException",38]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>public</b> <b>class</b> <a class="xc" name="ResourceNotFoundException"/><a href="/source/s?refs=ResourceNotFoundException&amp;project=rtmp_client" class="xc">ResourceNotFoundException</a> <b>extends</b> <a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> {
<a class="l" name="23" href="#23">23</a>	<b>private</b> <b>static</b> <b>final</b> <b>long</b> <a class="xfld" name="serialVersionUID"/><a href="/source/s?refs=serialVersionUID&amp;project=rtmp_client" class="xfld">serialVersionUID</a> = -<span class="n">1963629259187714996L</span>;
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a>	<span class="c">/** Constructs a new ResourceNotFoundException. */</span>
<a class="l" name="26" href="#26">26</a>    <b>public</b> <a class="xmt" name="ResourceNotFoundException"/><a href="/source/s?refs=ResourceNotFoundException&amp;project=rtmp_client" class="xmt">ResourceNotFoundException</a>() {
<a class="l" name="27" href="#27">27</a>		<b>super</b>();
<a class="l" name="28" href="#28">28</a>	}
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a>	<b>public</b> <a class="xmt" name="ResourceNotFoundException"/><a href="/source/s?refs=ResourceNotFoundException&amp;project=rtmp_client" class="xmt">ResourceNotFoundException</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="message"/><a href="/source/s?refs=message&amp;project=rtmp_client" class="xa">message</a>, <a href="/source/s?defs=Throwable&amp;project=rtmp_client">Throwable</a> <a class="xa" name="cause"/><a href="/source/s?refs=cause&amp;project=rtmp_client" class="xa">cause</a>) {
<a class="l" name="31" href="#31">31</a>		<b>super</b>(<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>, <a href="/source/s?defs=cause&amp;project=rtmp_client">cause</a>);
<a class="l" name="32" href="#32">32</a>	}
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a>	<b>public</b> <a class="xmt" name="ResourceNotFoundException"/><a href="/source/s?refs=ResourceNotFoundException&amp;project=rtmp_client" class="xmt">ResourceNotFoundException</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="message"/><a href="/source/s?refs=message&amp;project=rtmp_client" class="xa">message</a>) {
<a class="l" name="35" href="#35">35</a>		<b>super</b>(<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="36" href="#36">36</a>	}
<a class="l" name="37" href="#37">37</a>
<a class="l" name="38" href="#38">38</a>	<b>public</b> <a class="xmt" name="ResourceNotFoundException"/><a href="/source/s?refs=ResourceNotFoundException&amp;project=rtmp_client" class="xmt">ResourceNotFoundException</a>(<a href="/source/s?defs=Throwable&amp;project=rtmp_client">Throwable</a> <a class="xa" name="cause"/><a href="/source/s?refs=cause&amp;project=rtmp_client" class="xa">cause</a>) {
<a class="l" name="39" href="#39">39</a>		<b>super</b>(<a href="/source/s?defs=cause&amp;project=rtmp_client">cause</a>);
<a class="hl" name="40" href="#40">40</a>	}
<a class="l" name="41" href="#41">41</a>
<a class="l" name="42" href="#42">42</a>}
<a class="l" name="43" href="#43">43</a>