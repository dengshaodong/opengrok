<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["Ping",30]]],["Package","xp",[["org.red5.server.net.rtmp.event",1]]],["Method","xmt",[["Ping",115],["Ping",119],["Ping",125],["Ping",132],["Ping",140],["doRelease",244],["getDataType",150],["getDebug",231],["getEventType",159],["getValue2",177],["getValue3",195],["getValue4",213],["readExternal",265],["releaseInternal",260],["setDebug",240],["setEventType",168],["setValue2",186],["setValue3",204],["setValue4",222],["toString",253],["writeExternal",274]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=ObjectInput&amp;project=rtmp_client">ObjectInput</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=ObjectOutput&amp;project=rtmp_client">ObjectOutput</a>;
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a><span class="c">/**
<a class="l" name="27" href="#27">27</a> * Ping event, actually combination of different events. This is
<a class="l" name="28" href="#28">28</a> * also known as a user control message.
<a class="l" name="29" href="#29">29</a> */</span>
<a class="hl" name="30" href="#30">30</a><b>public</b> <b>class</b> <a class="xc" name="Ping"/><a href="/source/s?refs=Ping&amp;project=rtmp_client" class="xc">Ping</a> <b>extends</b> <a href="/source/s?defs=BaseEvent&amp;project=rtmp_client">BaseEvent</a> {
<a class="l" name="31" href="#31">31</a>
<a class="l" name="32" href="#32">32</a>	<b>private</b> <b>static</b> <b>final</b> <b>long</b> <a class="xfld" name="serialVersionUID"/><a href="/source/s?refs=serialVersionUID&amp;project=rtmp_client" class="xfld">serialVersionUID</a> = -<span class="n">6478248060425544923L</span>;
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a>	<span class="c">/**
<a class="l" name="35" href="#35">35</a>	 * Stream begin / clear event
<a class="l" name="36" href="#36">36</a>	 */</span>
<a class="l" name="37" href="#37">37</a>	<b>public</b> <b>static</b> <b>final</b> <b>short</b> <a class="xfld" name="STREAM_BEGIN"/><a href="/source/s?refs=STREAM_BEGIN&amp;project=rtmp_client" class="xfld">STREAM_BEGIN</a> = <span class="n">0</span>;
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>	<span class="c">/**
<a class="hl" name="40" href="#40">40</a>	 * Stream EOF, playback of requested stream is completed.
<a class="l" name="41" href="#41">41</a>	 */</span>
<a class="l" name="42" href="#42">42</a>	<b>public</b> <b>static</b> <b>final</b> <b>short</b> <a class="xfld" name="STREAM_PLAYBUFFER_CLEAR"/><a href="/source/s?refs=STREAM_PLAYBUFFER_CLEAR&amp;project=rtmp_client" class="xfld">STREAM_PLAYBUFFER_CLEAR</a> = <span class="n">1</span>;
<a class="l" name="43" href="#43">43</a>
<a class="l" name="44" href="#44">44</a>	<span class="c">/**
<a class="l" name="45" href="#45">45</a>	 * Stream is empty
<a class="l" name="46" href="#46">46</a>	 */</span>
<a class="l" name="47" href="#47">47</a>	<b>public</b> <b>static</b> <b>final</b> <b>short</b> <a class="xfld" name="STREAM_DRY"/><a href="/source/s?refs=STREAM_DRY&amp;project=rtmp_client" class="xfld">STREAM_DRY</a> = <span class="n">2</span>;
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>	<span class="c">/**
<a class="hl" name="50" href="#50">50</a>	 * Client buffer. Sent by client to indicate its buffer time in milliseconds.
<a class="l" name="51" href="#51">51</a>	 */</span>
<a class="l" name="52" href="#52">52</a>	<b>public</b> <b>static</b> <b>final</b> <b>short</b> <a class="xfld" name="CLIENT_BUFFER"/><a href="/source/s?refs=CLIENT_BUFFER&amp;project=rtmp_client" class="xfld">CLIENT_BUFFER</a> = <span class="n">3</span>;
<a class="l" name="53" href="#53">53</a>
<a class="l" name="54" href="#54">54</a>	<span class="c">/**
<a class="l" name="55" href="#55">55</a>	 * Recorded stream. Sent by server to indicate a recorded stream.
<a class="l" name="56" href="#56">56</a>	 */</span>
<a class="l" name="57" href="#57">57</a>	<b>public</b> <b>static</b> <b>final</b> <b>short</b> <a class="xfld" name="RECORDED_STREAM"/><a href="/source/s?refs=RECORDED_STREAM&amp;project=rtmp_client" class="xfld">RECORDED_STREAM</a> = <span class="n">4</span>;
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a>	<span class="c">/**
<a class="hl" name="60" href="#60">60</a>	 * One more unknown event
<a class="l" name="61" href="#61">61</a>	 */</span>
<a class="l" name="62" href="#62">62</a>	<b>public</b> <b>static</b> <b>final</b> <b>short</b> <a class="xfld" name="UNKNOWN_5"/><a href="/source/s?refs=UNKNOWN_5&amp;project=rtmp_client" class="xfld">UNKNOWN_5</a> = <span class="n">5</span>;
<a class="l" name="63" href="#63">63</a>
<a class="l" name="64" href="#64">64</a>	<span class="c">/**
<a class="l" name="65" href="#65">65</a>	 * Client ping event. Sent by server to test if client is reachable.
<a class="l" name="66" href="#66">66</a>	 */</span>
<a class="l" name="67" href="#67">67</a>	<b>public</b> <b>static</b> <b>final</b> <b>short</b> <a class="xfld" name="PING_CLIENT"/><a href="/source/s?refs=PING_CLIENT&amp;project=rtmp_client" class="xfld">PING_CLIENT</a> = <span class="n">6</span>;
<a class="l" name="68" href="#68">68</a>
<a class="l" name="69" href="#69">69</a>	<span class="c">/**
<a class="hl" name="70" href="#70">70</a>	 * Server response event. A clients ping response.
<a class="l" name="71" href="#71">71</a>	 */</span>
<a class="l" name="72" href="#72">72</a>	<b>public</b> <b>static</b> <b>final</b> <b>short</b> <a class="xfld" name="PONG_SERVER"/><a href="/source/s?refs=PONG_SERVER&amp;project=rtmp_client" class="xfld">PONG_SERVER</a> = <span class="n">7</span>;
<a class="l" name="73" href="#73">73</a>
<a class="l" name="74" href="#74">74</a>    <span class="c">/**
<a class="l" name="75" href="#75">75</a>     * One more unknown event
<a class="l" name="76" href="#76">76</a>     */</span>
<a class="l" name="77" href="#77">77</a>    <b>public</b> <b>static</b> <b>final</b> <b>short</b> <a class="xfld" name="UNKNOWN_8"/><a href="/source/s?refs=UNKNOWN_8&amp;project=rtmp_client" class="xfld">UNKNOWN_8</a> = <span class="n">8</span>;
<a class="l" name="78" href="#78">78</a>
<a class="l" name="79" href="#79">79</a>    <span class="c">/**
<a class="hl" name="80" href="#80">80</a>     * SWF verification ping 0x001a
<a class="l" name="81" href="#81">81</a>     */</span>
<a class="l" name="82" href="#82">82</a>	<b>public</b> <b>static</b> <b>final</b> <b>short</b> <a class="xfld" name="PING_SWF_VERIFY"/><a href="/source/s?refs=PING_SWF_VERIFY&amp;project=rtmp_client" class="xfld">PING_SWF_VERIFY</a> = <span class="n">26</span>;
<a class="l" name="83" href="#83">83</a>
<a class="l" name="84" href="#84">84</a>    <span class="c">/**
<a class="l" name="85" href="#85">85</a>     * SWF verification pong 0x001b
<a class="l" name="86" href="#86">86</a>     */</span>
<a class="l" name="87" href="#87">87</a>	<b>public</b> <b>static</b> <b>final</b> <b>short</b> <a class="xfld" name="PONG_SWF_VERIFY"/><a href="/source/s?refs=PONG_SWF_VERIFY&amp;project=rtmp_client" class="xfld">PONG_SWF_VERIFY</a> = <span class="n">27</span>;
<a class="l" name="88" href="#88">88</a>
<a class="l" name="89" href="#89">89</a>    <span class="c">/**
<a class="hl" name="90" href="#90">90</a>     * Event type is undefined
<a class="l" name="91" href="#91">91</a>     */</span>
<a class="l" name="92" href="#92">92</a>    <b>public</b> <b>static</b> <b>final</b> <b>int</b> <a class="xfld" name="UNDEFINED"/><a href="/source/s?refs=UNDEFINED&amp;project=rtmp_client" class="xfld">UNDEFINED</a> = -<span class="n">1</span>;
<a class="l" name="93" href="#93">93</a>
<a class="l" name="94" href="#94">94</a>    <span class="c">/**
<a class="l" name="95" href="#95">95</a>     * The sub-type
<a class="l" name="96" href="#96">96</a>     */</span>
<a class="l" name="97" href="#97">97</a>	<b>private</b> <b>short</b> <a class="xfld" name="eventType"/><a href="/source/s?refs=eventType&amp;project=rtmp_client" class="xfld">eventType</a>;
<a class="l" name="98" href="#98">98</a>
<a class="l" name="99" href="#99">99</a>	<span class="c">/**
<a class="hl" name="100" href="#100">100</a>	 * Represents the stream id in all cases except PING_CLIENT and PONG_SERVER
<a class="l" name="101" href="#101">101</a>	 * where it represents the local server timestamp.
<a class="l" name="102" href="#102">102</a>	 */</span>
<a class="l" name="103" href="#103">103</a>	<b>private</b> <b>int</b> <a class="xfld" name="value2"/><a href="/source/s?refs=value2&amp;project=rtmp_client" class="xfld">value2</a>;
<a class="l" name="104" href="#104">104</a>
<a class="l" name="105" href="#105">105</a>	<b>private</b> <b>int</b> <a class="xfld" name="value3"/><a href="/source/s?refs=value3&amp;project=rtmp_client" class="xfld">value3</a> = <a class="d" href="#UNDEFINED">UNDEFINED</a>;
<a class="l" name="106" href="#106">106</a>
<a class="l" name="107" href="#107">107</a>	<b>private</b> <b>int</b> <a class="xfld" name="value4"/><a href="/source/s?refs=value4&amp;project=rtmp_client" class="xfld">value4</a> = <a class="d" href="#UNDEFINED">UNDEFINED</a>;
<a class="l" name="108" href="#108">108</a>
<a class="l" name="109" href="#109">109</a>    <span class="c">/**
<a class="hl" name="110" href="#110">110</a>     * Debug string
<a class="l" name="111" href="#111">111</a>     */</span>
<a class="l" name="112" href="#112">112</a>    <b>private</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="debug"/><a href="/source/s?refs=debug&amp;project=rtmp_client" class="xfld">debug</a> = <span class="s">""</span>;
<a class="l" name="113" href="#113">113</a>
<a class="l" name="114" href="#114">114</a>	<span class="c">/** Constructs a new Ping. */</span>
<a class="l" name="115" href="#115">115</a>    <b>public</b> <a class="xmt" name="Ping"/><a href="/source/s?refs=Ping&amp;project=rtmp_client" class="xmt">Ping</a>() {
<a class="l" name="116" href="#116">116</a>		<b>super</b>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=SYSTEM&amp;project=rtmp_client">SYSTEM</a>);
<a class="l" name="117" href="#117">117</a>	}
<a class="l" name="118" href="#118">118</a>
<a class="l" name="119" href="#119">119</a>    <b>public</b> <a class="xmt" name="Ping"/><a href="/source/s?refs=Ping&amp;project=rtmp_client" class="xmt">Ping</a>(<b>short</b> <a class="xa" name="eventType"/><a href="/source/s?refs=eventType&amp;project=rtmp_client" class="xa">eventType</a>, <b>int</b> <a class="xa" name="value2"/><a href="/source/s?refs=value2&amp;project=rtmp_client" class="xa">value2</a>) {
<a class="hl" name="120" href="#120">120</a>		<b>super</b>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=SYSTEM&amp;project=rtmp_client">SYSTEM</a>);
<a class="l" name="121" href="#121">121</a>		<b>this</b>.<a href="/source/s?defs=eventType&amp;project=rtmp_client">eventType</a> = <a href="/source/s?defs=eventType&amp;project=rtmp_client">eventType</a>;
<a class="l" name="122" href="#122">122</a>		<b>this</b>.<a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a> = <a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a>;
<a class="l" name="123" href="#123">123</a>	}
<a class="l" name="124" href="#124">124</a>
<a class="l" name="125" href="#125">125</a>	<b>public</b> <a class="xmt" name="Ping"/><a href="/source/s?refs=Ping&amp;project=rtmp_client" class="xmt">Ping</a>(<b>short</b> <a class="xa" name="eventType"/><a href="/source/s?refs=eventType&amp;project=rtmp_client" class="xa">eventType</a>, <b>int</b> <a class="xa" name="value2"/><a href="/source/s?refs=value2&amp;project=rtmp_client" class="xa">value2</a>, <b>int</b> <a class="xa" name="value3"/><a href="/source/s?refs=value3&amp;project=rtmp_client" class="xa">value3</a>) {
<a class="l" name="126" href="#126">126</a>		<b>super</b>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=SYSTEM&amp;project=rtmp_client">SYSTEM</a>);
<a class="l" name="127" href="#127">127</a>		<b>this</b>.<a href="/source/s?defs=eventType&amp;project=rtmp_client">eventType</a> = <a href="/source/s?defs=eventType&amp;project=rtmp_client">eventType</a>;
<a class="l" name="128" href="#128">128</a>		<b>this</b>.<a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a> = <a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a>;
<a class="l" name="129" href="#129">129</a>		<b>this</b>.<a href="/source/s?defs=value3&amp;project=rtmp_client">value3</a> = <a href="/source/s?defs=value3&amp;project=rtmp_client">value3</a>;
<a class="hl" name="130" href="#130">130</a>	}
<a class="l" name="131" href="#131">131</a>
<a class="l" name="132" href="#132">132</a>	<b>public</b> <a class="xmt" name="Ping"/><a href="/source/s?refs=Ping&amp;project=rtmp_client" class="xmt">Ping</a>(<b>short</b> <a class="xa" name="eventType"/><a href="/source/s?refs=eventType&amp;project=rtmp_client" class="xa">eventType</a>, <b>int</b> <a class="xa" name="value2"/><a href="/source/s?refs=value2&amp;project=rtmp_client" class="xa">value2</a>, <b>int</b> <a class="xa" name="value3"/><a href="/source/s?refs=value3&amp;project=rtmp_client" class="xa">value3</a>, <b>int</b> <a class="xa" name="value4"/><a href="/source/s?refs=value4&amp;project=rtmp_client" class="xa">value4</a>) {
<a class="l" name="133" href="#133">133</a>		<b>super</b>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=SYSTEM&amp;project=rtmp_client">SYSTEM</a>);
<a class="l" name="134" href="#134">134</a>		<b>this</b>.<a href="/source/s?defs=eventType&amp;project=rtmp_client">eventType</a> = <a href="/source/s?defs=eventType&amp;project=rtmp_client">eventType</a>;
<a class="l" name="135" href="#135">135</a>		<b>this</b>.<a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a> = <a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a>;
<a class="l" name="136" href="#136">136</a>		<b>this</b>.<a href="/source/s?defs=value3&amp;project=rtmp_client">value3</a> = <a href="/source/s?defs=value3&amp;project=rtmp_client">value3</a>;
<a class="l" name="137" href="#137">137</a>		<b>this</b>.<a href="/source/s?defs=value4&amp;project=rtmp_client">value4</a> = <a href="/source/s?defs=value4&amp;project=rtmp_client">value4</a>;
<a class="l" name="138" href="#138">138</a>	}
<a class="l" name="139" href="#139">139</a>
<a class="hl" name="140" href="#140">140</a>	<b>public</b> <a class="xmt" name="Ping"/><a href="/source/s?refs=Ping&amp;project=rtmp_client" class="xmt">Ping</a>(<a class="xmt" name="Ping"/><a href="/source/s?refs=Ping&amp;project=rtmp_client" class="xmt">Ping</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="141" href="#141">141</a>		<b>super</b>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=SYSTEM&amp;project=rtmp_client">SYSTEM</a>);
<a class="l" name="142" href="#142">142</a>		<b>this</b>.<a href="/source/s?defs=eventType&amp;project=rtmp_client">eventType</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a class="d" href="#getEventType">getEventType</a>();
<a class="l" name="143" href="#143">143</a>		<b>this</b>.<a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a class="d" href="#getValue2">getValue2</a>();
<a class="l" name="144" href="#144">144</a>		<b>this</b>.<a href="/source/s?defs=value3&amp;project=rtmp_client">value3</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a class="d" href="#getValue3">getValue3</a>();
<a class="l" name="145" href="#145">145</a>		<b>this</b>.<a href="/source/s?defs=value4&amp;project=rtmp_client">value4</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a class="d" href="#getValue4">getValue4</a>();
<a class="l" name="146" href="#146">146</a>	}
<a class="l" name="147" href="#147">147</a>
<a class="l" name="148" href="#148">148</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="149" href="#149">149</a>    @<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="hl" name="150" href="#150">150</a>	<b>public</b> <b>byte</b> <a class="xmt" name="getDataType"/><a href="/source/s?refs=getDataType&amp;project=rtmp_client" class="xmt">getDataType</a>() {
<a class="l" name="151" href="#151">151</a>		<b>return</b> <a href="/source/s?defs=TYPE_PING&amp;project=rtmp_client">TYPE_PING</a>;
<a class="l" name="152" href="#152">152</a>	}
<a class="l" name="153" href="#153">153</a>
<a class="l" name="154" href="#154">154</a>    <span class="c">/**
<a class="l" name="155" href="#155">155</a>     * Returns the events sub-type
<a class="l" name="156" href="#156">156</a>     *
<a class="l" name="157" href="#157">157</a>     * <strong>@return</strong> the event type
<a class="l" name="158" href="#158">158</a>     */</span>
<a class="l" name="159" href="#159">159</a>	<b>public</b> <b>short</b> <a class="xmt" name="getEventType"/><a href="/source/s?refs=getEventType&amp;project=rtmp_client" class="xmt">getEventType</a>() {
<a class="hl" name="160" href="#160">160</a>		<b>return</b> <a href="/source/s?defs=eventType&amp;project=rtmp_client">eventType</a>;
<a class="l" name="161" href="#161">161</a>	}
<a class="l" name="162" href="#162">162</a>
<a class="l" name="163" href="#163">163</a>	<span class="c">/**
<a class="l" name="164" href="#164">164</a>	 * Sets the events sub-type
<a class="l" name="165" href="#165">165</a>	 *
<a class="l" name="166" href="#166">166</a>	 * <strong>@param</strong> <em>eventType</em>
<a class="l" name="167" href="#167">167</a>	 */</span>
<a class="l" name="168" href="#168">168</a>	<b>public</b> <b>void</b> <a class="xmt" name="setEventType"/><a href="/source/s?refs=setEventType&amp;project=rtmp_client" class="xmt">setEventType</a>(<b>short</b> <a class="xa" name="eventType"/><a href="/source/s?refs=eventType&amp;project=rtmp_client" class="xa">eventType</a>) {
<a class="l" name="169" href="#169">169</a>		<b>this</b>.<a href="/source/s?defs=eventType&amp;project=rtmp_client">eventType</a> = <a href="/source/s?defs=eventType&amp;project=rtmp_client">eventType</a>;
<a class="hl" name="170" href="#170">170</a>	}
<a class="l" name="171" href="#171">171</a>
<a class="l" name="172" href="#172">172</a>	<span class="c">/**
<a class="l" name="173" href="#173">173</a>     * Getter for property 'value2'.
<a class="l" name="174" href="#174">174</a>     *
<a class="l" name="175" href="#175">175</a>     * <strong>@return</strong> Value for property 'value2'.
<a class="l" name="176" href="#176">176</a>     */</span>
<a class="l" name="177" href="#177">177</a>    <b>public</b> <b>int</b> <a class="xmt" name="getValue2"/><a href="/source/s?refs=getValue2&amp;project=rtmp_client" class="xmt">getValue2</a>() {
<a class="l" name="178" href="#178">178</a>		<b>return</b> <a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a>;
<a class="l" name="179" href="#179">179</a>	}
<a class="hl" name="180" href="#180">180</a>
<a class="l" name="181" href="#181">181</a>	<span class="c">/**
<a class="l" name="182" href="#182">182</a>     * Setter for property 'value2'.
<a class="l" name="183" href="#183">183</a>     *
<a class="l" name="184" href="#184">184</a>     * <strong>@param</strong> <em>value2</em> Value to set for property 'value2'.
<a class="l" name="185" href="#185">185</a>     */</span>
<a class="l" name="186" href="#186">186</a>    <b>public</b> <b>void</b> <a class="xmt" name="setValue2"/><a href="/source/s?refs=setValue2&amp;project=rtmp_client" class="xmt">setValue2</a>(<b>int</b> <a class="xa" name="value2"/><a href="/source/s?refs=value2&amp;project=rtmp_client" class="xa">value2</a>) {
<a class="l" name="187" href="#187">187</a>		<b>this</b>.<a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a> = <a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a>;
<a class="l" name="188" href="#188">188</a>	}
<a class="l" name="189" href="#189">189</a>
<a class="hl" name="190" href="#190">190</a>	<span class="c">/**
<a class="l" name="191" href="#191">191</a>     * Getter for property 'value3'.
<a class="l" name="192" href="#192">192</a>     *
<a class="l" name="193" href="#193">193</a>     * <strong>@return</strong> Value for property 'value3'.
<a class="l" name="194" href="#194">194</a>     */</span>
<a class="l" name="195" href="#195">195</a>    <b>public</b> <b>int</b> <a class="xmt" name="getValue3"/><a href="/source/s?refs=getValue3&amp;project=rtmp_client" class="xmt">getValue3</a>() {
<a class="l" name="196" href="#196">196</a>		<b>return</b> <a href="/source/s?defs=value3&amp;project=rtmp_client">value3</a>;
<a class="l" name="197" href="#197">197</a>	}
<a class="l" name="198" href="#198">198</a>
<a class="l" name="199" href="#199">199</a>	<span class="c">/**
<a class="hl" name="200" href="#200">200</a>     * Setter for property 'value3'.
<a class="l" name="201" href="#201">201</a>     *
<a class="l" name="202" href="#202">202</a>     * <strong>@param</strong> <em>value3</em> Value to set for property 'value3'.
<a class="l" name="203" href="#203">203</a>     */</span>
<a class="l" name="204" href="#204">204</a>    <b>public</b> <b>void</b> <a class="xmt" name="setValue3"/><a href="/source/s?refs=setValue3&amp;project=rtmp_client" class="xmt">setValue3</a>(<b>int</b> <a class="xa" name="value3"/><a href="/source/s?refs=value3&amp;project=rtmp_client" class="xa">value3</a>) {
<a class="l" name="205" href="#205">205</a>		<b>this</b>.<a href="/source/s?defs=value3&amp;project=rtmp_client">value3</a> = <a href="/source/s?defs=value3&amp;project=rtmp_client">value3</a>;
<a class="l" name="206" href="#206">206</a>	}
<a class="l" name="207" href="#207">207</a>
<a class="l" name="208" href="#208">208</a>	<span class="c">/**
<a class="l" name="209" href="#209">209</a>     * Getter for property 'value4'.
<a class="hl" name="210" href="#210">210</a>     *
<a class="l" name="211" href="#211">211</a>     * <strong>@return</strong> Value for property 'value4'.
<a class="l" name="212" href="#212">212</a>     */</span>
<a class="l" name="213" href="#213">213</a>    <b>public</b> <b>int</b> <a class="xmt" name="getValue4"/><a href="/source/s?refs=getValue4&amp;project=rtmp_client" class="xmt">getValue4</a>() {
<a class="l" name="214" href="#214">214</a>		<b>return</b> <a href="/source/s?defs=value4&amp;project=rtmp_client">value4</a>;
<a class="l" name="215" href="#215">215</a>	}
<a class="l" name="216" href="#216">216</a>
<a class="l" name="217" href="#217">217</a>	<span class="c">/**
<a class="l" name="218" href="#218">218</a>     * Setter for property 'value4'.
<a class="l" name="219" href="#219">219</a>     *
<a class="hl" name="220" href="#220">220</a>     * <strong>@param</strong> <em>value4</em> Value to set for property 'value4'.
<a class="l" name="221" href="#221">221</a>     */</span>
<a class="l" name="222" href="#222">222</a>    <b>public</b> <b>void</b> <a class="xmt" name="setValue4"/><a href="/source/s?refs=setValue4&amp;project=rtmp_client" class="xmt">setValue4</a>(<b>int</b> <a class="xa" name="value4"/><a href="/source/s?refs=value4&amp;project=rtmp_client" class="xa">value4</a>) {
<a class="l" name="223" href="#223">223</a>		<b>this</b>.<a href="/source/s?defs=value4&amp;project=rtmp_client">value4</a> = <a href="/source/s?defs=value4&amp;project=rtmp_client">value4</a>;
<a class="l" name="224" href="#224">224</a>	}
<a class="l" name="225" href="#225">225</a>
<a class="l" name="226" href="#226">226</a>	<span class="c">/**
<a class="l" name="227" href="#227">227</a>     * Getter for property 'debug'.
<a class="l" name="228" href="#228">228</a>     *
<a class="l" name="229" href="#229">229</a>     * <strong>@return</strong> Value for property 'debug'.
<a class="hl" name="230" href="#230">230</a>     */</span>
<a class="l" name="231" href="#231">231</a>    <b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getDebug"/><a href="/source/s?refs=getDebug&amp;project=rtmp_client" class="xmt">getDebug</a>() {
<a class="l" name="232" href="#232">232</a>		<b>return</b> <a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>;
<a class="l" name="233" href="#233">233</a>	}
<a class="l" name="234" href="#234">234</a>
<a class="l" name="235" href="#235">235</a>	<span class="c">/**
<a class="l" name="236" href="#236">236</a>     * Setter for property 'debug'.
<a class="l" name="237" href="#237">237</a>     *
<a class="l" name="238" href="#238">238</a>     * <strong>@param</strong> <em>debug</em> Value to set for property 'debug'.
<a class="l" name="239" href="#239">239</a>     */</span>
<a class="hl" name="240" href="#240">240</a>    <b>public</b> <b>void</b> <a class="xmt" name="setDebug"/><a href="/source/s?refs=setDebug&amp;project=rtmp_client" class="xmt">setDebug</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="debug"/><a href="/source/s?refs=debug&amp;project=rtmp_client" class="xa">debug</a>) {
<a class="l" name="241" href="#241">241</a>		<b>this</b>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a> = <a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>;
<a class="l" name="242" href="#242">242</a>	}
<a class="l" name="243" href="#243">243</a>
<a class="l" name="244" href="#244">244</a>	<b>protected</b> <b>void</b> <a class="xmt" name="doRelease"/><a href="/source/s?refs=doRelease&amp;project=rtmp_client" class="xmt">doRelease</a>() {
<a class="l" name="245" href="#245">245</a>		<a href="/source/s?defs=eventType&amp;project=rtmp_client">eventType</a> = <span class="n">0</span>;
<a class="l" name="246" href="#246">246</a>		<a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a> = <span class="n">0</span>;
<a class="l" name="247" href="#247">247</a>		<a href="/source/s?defs=value3&amp;project=rtmp_client">value3</a> = <a class="d" href="#UNDEFINED">UNDEFINED</a>;
<a class="l" name="248" href="#248">248</a>		<a href="/source/s?defs=value4&amp;project=rtmp_client">value4</a> = <a class="d" href="#UNDEFINED">UNDEFINED</a>;
<a class="l" name="249" href="#249">249</a>	}
<a class="hl" name="250" href="#250">250</a>
<a class="l" name="251" href="#251">251</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="252" href="#252">252</a>    @<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="253" href="#253">253</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toString"/><a href="/source/s?refs=toString&amp;project=rtmp_client" class="xmt">toString</a>() {
<a class="l" name="254" href="#254">254</a>		<b>return</b> <span class="s">"Ping: "</span> + <a href="/source/s?defs=eventType&amp;project=rtmp_client">eventType</a> + <span class="s">", "</span> + <a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a> + <span class="s">", "</span> + <a href="/source/s?defs=value3&amp;project=rtmp_client">value3</a> + <span class="s">", "</span>
<a class="l" name="255" href="#255">255</a>				+ <a href="/source/s?defs=value4&amp;project=rtmp_client">value4</a> + <span class="s">"\n"</span> + <a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>;
<a class="l" name="256" href="#256">256</a>	}
<a class="l" name="257" href="#257">257</a>
<a class="l" name="258" href="#258">258</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="259" href="#259">259</a>    @<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="hl" name="260" href="#260">260</a>	<b>protected</b> <b>void</b> <a class="xmt" name="releaseInternal"/><a href="/source/s?refs=releaseInternal&amp;project=rtmp_client" class="xmt">releaseInternal</a>() {
<a class="l" name="261" href="#261">261</a>
<a class="l" name="262" href="#262">262</a>	}
<a class="l" name="263" href="#263">263</a>
<a class="l" name="264" href="#264">264</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="265" href="#265">265</a>	<b>public</b> <b>void</b> <a class="xmt" name="readExternal"/><a href="/source/s?refs=readExternal&amp;project=rtmp_client" class="xmt">readExternal</a>(<a href="/source/s?defs=ObjectInput&amp;project=rtmp_client">ObjectInput</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>, <a href="/source/s?defs=ClassNotFoundException&amp;project=rtmp_client">ClassNotFoundException</a> {
<a class="l" name="266" href="#266">266</a>		<b>super</b>.<a class="d" href="#readExternal">readExternal</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="267" href="#267">267</a>		<a href="/source/s?defs=eventType&amp;project=rtmp_client">eventType</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=readShort&amp;project=rtmp_client">readShort</a>();
<a class="l" name="268" href="#268">268</a>		<a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=readInt&amp;project=rtmp_client">readInt</a>();
<a class="l" name="269" href="#269">269</a>		<a href="/source/s?defs=value3&amp;project=rtmp_client">value3</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=readInt&amp;project=rtmp_client">readInt</a>();
<a class="hl" name="270" href="#270">270</a>		<a href="/source/s?defs=value4&amp;project=rtmp_client">value4</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=readInt&amp;project=rtmp_client">readInt</a>();
<a class="l" name="271" href="#271">271</a>	}
<a class="l" name="272" href="#272">272</a>
<a class="l" name="273" href="#273">273</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="274" href="#274">274</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeExternal"/><a href="/source/s?refs=writeExternal&amp;project=rtmp_client" class="xmt">writeExternal</a>(<a href="/source/s?defs=ObjectOutput&amp;project=rtmp_client">ObjectOutput</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="275" href="#275">275</a>		<b>super</b>.<a class="d" href="#writeExternal">writeExternal</a>(<a class="d" href="#out">out</a>);
<a class="l" name="276" href="#276">276</a>		<a class="d" href="#out">out</a>.<a href="/source/s?defs=writeShort&amp;project=rtmp_client">writeShort</a>(<a href="/source/s?defs=eventType&amp;project=rtmp_client">eventType</a>);
<a class="l" name="277" href="#277">277</a>		<a class="d" href="#out">out</a>.<a href="/source/s?defs=writeInt&amp;project=rtmp_client">writeInt</a>(<a href="/source/s?defs=value2&amp;project=rtmp_client">value2</a>);
<a class="l" name="278" href="#278">278</a>		<a class="d" href="#out">out</a>.<a href="/source/s?defs=writeInt&amp;project=rtmp_client">writeInt</a>(<a href="/source/s?defs=value3&amp;project=rtmp_client">value3</a>);
<a class="l" name="279" href="#279">279</a>		<a class="d" href="#out">out</a>.<a href="/source/s?defs=writeInt&amp;project=rtmp_client">writeInt</a>(<a href="/source/s?defs=value4&amp;project=rtmp_client">value4</a>);
<a class="hl" name="280" href="#280">280</a>	}
<a class="l" name="281" href="#281">281</a>}
<a class="l" name="282" href="#282">282</a>