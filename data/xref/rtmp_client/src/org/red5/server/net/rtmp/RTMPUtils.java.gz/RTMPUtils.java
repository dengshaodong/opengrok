<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["RTMPUtils",32]]],["Package","xp",[["org.red5.server.net.rtmp",1]]],["Method","xmt",[["compareTimestamps",245],["decodeChannelId",190],["decodeHeaderSize",207],["diffTimestamps",258],["encodeHeaderByte",169],["getHeaderLength",223],["readMediumInt",131],["readMediumIntOld",113],["readReverseInt",149],["readUnsignedMediumInt",82],["readUnsignedMediumIntOld",98],["writeMediumInt",71],["writeReverseInt",59],["writeReverseIntOld",39]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors. All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>;
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a><span class="c">/**
<a class="l" name="26" href="#26">26</a> * RTMP utilities class.
<a class="l" name="27" href="#27">27</a> *
<a class="l" name="28" href="#28">28</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="29" href="#29">29</a> * <strong>@author</strong> Luke Hubbard, Codegent Ltd (luke@codegent.com)
<a class="hl" name="30" href="#30">30</a> * <strong>@author</strong> Art Clarke (aclarke@xuggle.com)
<a class="l" name="31" href="#31">31</a> */</span>
<a class="l" name="32" href="#32">32</a><b>public</b> <b>class</b> <a class="xc" name="RTMPUtils"/><a href="/source/s?refs=RTMPUtils&amp;project=rtmp_client" class="xc">RTMPUtils</a> <b>implements</b> <a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a> {
<a class="l" name="33" href="#33">33</a>    <span class="c">/**
<a class="l" name="34" href="#34">34</a>     * Writes reversed integer to buffer.
<a class="l" name="35" href="#35">35</a>	 *
<a class="l" name="36" href="#36">36</a>     * <strong>@param</strong> <em>out</em>          Buffer
<a class="l" name="37" href="#37">37</a>     * <strong>@param</strong> <em>value</em>        Integer to write
<a class="l" name="38" href="#38">38</a>     */</span>
<a class="l" name="39" href="#39">39</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="writeReverseIntOld"/><a href="/source/s?refs=writeReverseIntOld&amp;project=rtmp_client" class="xmt">writeReverseIntOld</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>, <b>int</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="hl" name="40" href="#40">40</a>		<b>byte</b>[] <a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a> = <b>new</b> <b>byte</b>[<span class="n">4</span>];
<a class="l" name="41" href="#41">41</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=rev&amp;project=rtmp_client">rev</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">4</span>);
<a class="l" name="42" href="#42">42</a>		<a href="/source/s?defs=rev&amp;project=rtmp_client">rev</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="43" href="#43">43</a>		<a href="/source/s?defs=rev&amp;project=rtmp_client">rev</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="44" href="#44">44</a>		<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">3</span>] = <a href="/source/s?defs=rev&amp;project=rtmp_client">rev</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="45" href="#45">45</a>		<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">2</span>] = <a href="/source/s?defs=rev&amp;project=rtmp_client">rev</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="46" href="#46">46</a>		<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">1</span>] = <a href="/source/s?defs=rev&amp;project=rtmp_client">rev</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="47" href="#47">47</a>		<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">0</span>] = <a href="/source/s?defs=rev&amp;project=rtmp_client">rev</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="48" href="#48">48</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>);
<a class="l" name="49" href="#49">49</a>		<a href="/source/s?defs=rev&amp;project=rtmp_client">rev</a>.<a href="/source/s?defs=free&amp;project=rtmp_client">free</a>();
<a class="hl" name="50" href="#50">50</a>		<a href="/source/s?defs=rev&amp;project=rtmp_client">rev</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="51" href="#51">51</a>	}
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>    <span class="c">/**
<a class="l" name="54" href="#54">54</a>     * Writes reversed integer to buffer.
<a class="l" name="55" href="#55">55</a>	 *
<a class="l" name="56" href="#56">56</a>     * <strong>@param</strong> <em>out</em>          Buffer
<a class="l" name="57" href="#57">57</a>     * <strong>@param</strong> <em>value</em>        Integer to write
<a class="l" name="58" href="#58">58</a>     */</span>
<a class="l" name="59" href="#59">59</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="writeReverseInt"/><a href="/source/s?refs=writeReverseInt&amp;project=rtmp_client" class="xmt">writeReverseInt</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>, <b>int</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="hl" name="60" href="#60">60</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) (<span class="n">0xFF</span> &amp; <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>));
<a class="l" name="61" href="#61">61</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) (<span class="n">0xFF</span> &amp; (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> &gt;&gt; <span class="n">8</span>)));
<a class="l" name="62" href="#62">62</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) (<span class="n">0xFF</span> &amp; (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> &gt;&gt; <span class="n">16</span>)));
<a class="l" name="63" href="#63">63</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) (<span class="n">0xFF</span> &amp; (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> &gt;&gt; <span class="n">24</span>)));
<a class="l" name="64" href="#64">64</a>	}
<a class="l" name="65" href="#65">65</a>
<a class="l" name="66" href="#66">66</a>    <span class="c">/**
<a class="l" name="67" href="#67">67</a>     *
<a class="l" name="68" href="#68">68</a>     * <strong>@param</strong> <em>out</em> output buffer
<a class="l" name="69" href="#69">69</a>     * <strong>@param</strong> <em>value</em> value to write
<a class="hl" name="70" href="#70">70</a>     */</span>
<a class="l" name="71" href="#71">71</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="writeMediumInt"/><a href="/source/s?refs=writeMediumInt&amp;project=rtmp_client" class="xmt">writeMediumInt</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>, <b>int</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="72" href="#72">72</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) (<span class="n">0xFF</span> &amp; (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> &gt;&gt; <span class="n">16</span>)));
<a class="l" name="73" href="#73">73</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) (<span class="n">0xFF</span> &amp; (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> &gt;&gt; <span class="n">8</span>)));
<a class="l" name="74" href="#74">74</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) (<span class="n">0xFF</span> &amp; (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> &gt;&gt; <span class="n">0</span>)));
<a class="l" name="75" href="#75">75</a>	}
<a class="l" name="76" href="#76">76</a>
<a class="l" name="77" href="#77">77</a>    <span class="c">/**
<a class="l" name="78" href="#78">78</a>     *
<a class="l" name="79" href="#79">79</a>     * <strong>@param</strong> <em>in</em> input
<a class="hl" name="80" href="#80">80</a>     * <strong>@return</strong> unsigned int
<a class="l" name="81" href="#81">81</a>     */</span>
<a class="l" name="82" href="#82">82</a>	<b>public</b> <b>static</b> <b>int</b> <a class="xmt" name="readUnsignedMediumInt"/><a href="/source/s?refs=readUnsignedMediumInt&amp;project=rtmp_client" class="xmt">readUnsignedMediumInt</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="83" href="#83">83</a>		<b>final</b> <b>byte</b> a = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="84" href="#84">84</a>		<b>final</b> <b>byte</b> b = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="85" href="#85">85</a>		<b>final</b> <b>byte</b> c = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="86" href="#86">86</a>		<b>int</b> <a href="/source/s?defs=val&amp;project=rtmp_client">val</a> = <span class="n">0</span>;
<a class="l" name="87" href="#87">87</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += (a &amp; <span class="n">0xff</span>) &lt;&lt; <span class="n">16</span>;
<a class="l" name="88" href="#88">88</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += (b &amp; <span class="n">0xff</span>) &lt;&lt; <span class="n">8</span>;
<a class="l" name="89" href="#89">89</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += (c &amp; <span class="n">0xff</span>);
<a class="hl" name="90" href="#90">90</a>		<b>return</b> <a href="/source/s?defs=val&amp;project=rtmp_client">val</a>;
<a class="l" name="91" href="#91">91</a>	}
<a class="l" name="92" href="#92">92</a>
<a class="l" name="93" href="#93">93</a>    <span class="c">/**
<a class="l" name="94" href="#94">94</a>     *
<a class="l" name="95" href="#95">95</a>     * <strong>@param</strong> <em>in</em> input
<a class="l" name="96" href="#96">96</a>     * <strong>@return</strong> unsigned medium (3 byte) int.
<a class="l" name="97" href="#97">97</a>     */</span>
<a class="l" name="98" href="#98">98</a>	<b>public</b> <b>static</b> <b>int</b> <a class="xmt" name="readUnsignedMediumIntOld"/><a href="/source/s?refs=readUnsignedMediumIntOld&amp;project=rtmp_client" class="xmt">readUnsignedMediumIntOld</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="99" href="#99">99</a>		<b>byte</b>[] <a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a> = <b>new</b> <b>byte</b>[<span class="n">3</span>];
<a class="hl" name="100" href="#100">100</a>		<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>);
<a class="l" name="101" href="#101">101</a>		<b>int</b> <a href="/source/s?defs=val&amp;project=rtmp_client">val</a> = <span class="n">0</span>;
<a class="l" name="102" href="#102">102</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += (<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">0</span>] &amp; <span class="n">0xFF</span>) * <span class="n">256</span> * <span class="n">256</span>;
<a class="l" name="103" href="#103">103</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += (<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">1</span>] &amp; <span class="n">0xFF</span>) * <span class="n">256</span>;
<a class="l" name="104" href="#104">104</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += (<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">2</span>] &amp; <span class="n">0xFF</span>);
<a class="l" name="105" href="#105">105</a>		<b>return</b> <a href="/source/s?defs=val&amp;project=rtmp_client">val</a>;
<a class="l" name="106" href="#106">106</a>	}
<a class="l" name="107" href="#107">107</a>
<a class="l" name="108" href="#108">108</a>    <span class="c">/**
<a class="l" name="109" href="#109">109</a>     *
<a class="hl" name="110" href="#110">110</a>     * <strong>@param</strong> <em>in</em> input
<a class="l" name="111" href="#111">111</a>     * <strong>@return</strong> signed 3-byte int
<a class="l" name="112" href="#112">112</a>     */</span>
<a class="l" name="113" href="#113">113</a>	<b>public</b> <b>static</b> <b>int</b> <a class="xmt" name="readMediumIntOld"/><a href="/source/s?refs=readMediumIntOld&amp;project=rtmp_client" class="xmt">readMediumIntOld</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="114" href="#114">114</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">4</span>);
<a class="l" name="115" href="#115">115</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) <span class="n">0x00</span>);
<a class="l" name="116" href="#116">116</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>());
<a class="l" name="117" href="#117">117</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>());
<a class="l" name="118" href="#118">118</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>());
<a class="l" name="119" href="#119">119</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="hl" name="120" href="#120">120</a>		<b>int</b> <a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>();
<a class="l" name="121" href="#121">121</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=free&amp;project=rtmp_client">free</a>();
<a class="l" name="122" href="#122">122</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="123" href="#123">123</a>		<b>return</b> <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>;
<a class="l" name="124" href="#124">124</a>	}
<a class="l" name="125" href="#125">125</a>
<a class="l" name="126" href="#126">126</a>    <span class="c">/**
<a class="l" name="127" href="#127">127</a>     *
<a class="l" name="128" href="#128">128</a>     * <strong>@param</strong> <em>in</em> input
<a class="l" name="129" href="#129">129</a>     * <strong>@return</strong> signed 3 byte int
<a class="hl" name="130" href="#130">130</a>     */</span>
<a class="l" name="131" href="#131">131</a>	<b>public</b> <b>static</b> <b>int</b> <a class="xmt" name="readMediumInt"/><a href="/source/s?refs=readMediumInt&amp;project=rtmp_client" class="xmt">readMediumInt</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="132" href="#132">132</a>		<b>final</b> <b>byte</b> a = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="133" href="#133">133</a>		<b>final</b> <b>byte</b> b = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="134" href="#134">134</a>		<b>final</b> <b>byte</b> c = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="135" href="#135">135</a>		<span class="c">// Fix unsigned values</span>
<a class="l" name="136" href="#136">136</a>		<b>int</b> <a href="/source/s?defs=val&amp;project=rtmp_client">val</a> = <span class="n">0</span>;
<a class="l" name="137" href="#137">137</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += (a &amp; <span class="n">0xff</span>) &lt;&lt; <span class="n">16</span>;
<a class="l" name="138" href="#138">138</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += (b &amp; <span class="n">0xff</span>) &lt;&lt; <span class="n">8</span>;
<a class="l" name="139" href="#139">139</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += (c &amp; <span class="n">0xff</span>);
<a class="hl" name="140" href="#140">140</a>		<b>return</b> <a href="/source/s?defs=val&amp;project=rtmp_client">val</a>;
<a class="l" name="141" href="#141">141</a>	}
<a class="l" name="142" href="#142">142</a>
<a class="l" name="143" href="#143">143</a>    <span class="c">/**
<a class="l" name="144" href="#144">144</a>     * Read integer in reversed order.
<a class="l" name="145" href="#145">145</a>	 *
<a class="l" name="146" href="#146">146</a>     * <strong>@param</strong> <em>in</em>         Input buffer
<a class="l" name="147" href="#147">147</a>     * <strong>@return</strong>           Integer
<a class="l" name="148" href="#148">148</a>     */</span>
<a class="l" name="149" href="#149">149</a>	<b>public</b> <b>static</b> <b>int</b> <a class="xmt" name="readReverseInt"/><a href="/source/s?refs=readReverseInt&amp;project=rtmp_client" class="xmt">readReverseInt</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="hl" name="150" href="#150">150</a>		<b>final</b> <b>byte</b> a = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="151" href="#151">151</a>		<b>final</b> <b>byte</b> b = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="152" href="#152">152</a>		<b>final</b> <b>byte</b> c = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="153" href="#153">153</a>		<b>final</b> <b>byte</b> d = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="154" href="#154">154</a>		<b>int</b> <a href="/source/s?defs=val&amp;project=rtmp_client">val</a> = <span class="n">0</span>;
<a class="l" name="155" href="#155">155</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += (d &amp; <span class="n">0xff</span>) &lt;&lt; <span class="n">24</span>;
<a class="l" name="156" href="#156">156</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += (c &amp; <span class="n">0xff</span>) &lt;&lt; <span class="n">16</span>;
<a class="l" name="157" href="#157">157</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += (b &amp; <span class="n">0xff</span>) &lt;&lt; <span class="n">8</span>;
<a class="l" name="158" href="#158">158</a>		<a href="/source/s?defs=val&amp;project=rtmp_client">val</a> += (a &amp; <span class="n">0xff</span>);
<a class="l" name="159" href="#159">159</a>		<b>return</b> <a href="/source/s?defs=val&amp;project=rtmp_client">val</a>;
<a class="hl" name="160" href="#160">160</a>	}
<a class="l" name="161" href="#161">161</a>
<a class="l" name="162" href="#162">162</a>    <span class="c">/**
<a class="l" name="163" href="#163">163</a>     * Encodes header size marker and channel id into header marker.
<a class="l" name="164" href="#164">164</a>     * <strong>@param</strong> <em>out</em> output buffer
<a class="l" name="165" href="#165">165</a>	 *
<a class="l" name="166" href="#166">166</a>     * <strong>@param</strong> <em>headerSize</em>         Header size marker
<a class="l" name="167" href="#167">167</a>     * <strong>@param</strong> <em>channelId</em>          Channel used
<a class="l" name="168" href="#168">168</a>     */</span>
<a class="l" name="169" href="#169">169</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="encodeHeaderByte"/><a href="/source/s?refs=encodeHeaderByte&amp;project=rtmp_client" class="xmt">encodeHeaderByte</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>, <b>byte</b> <a class="xa" name="headerSize"/><a href="/source/s?refs=headerSize&amp;project=rtmp_client" class="xa">headerSize</a>, <b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>) {
<a class="hl" name="170" href="#170">170</a>		<b>if</b> (<a class="d" href="#channelId">channelId</a> &lt;= <span class="n">63</span>) {
<a class="l" name="171" href="#171">171</a>			<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) ((<a href="/source/s?defs=headerSize&amp;project=rtmp_client">headerSize</a> &lt;&lt; <span class="n">6</span>) + <a class="d" href="#channelId">channelId</a>));
<a class="l" name="172" href="#172">172</a>		} <b>else</b> <b>if</b> (<a class="d" href="#channelId">channelId</a> &lt;= <span class="n">320</span>) {
<a class="l" name="173" href="#173">173</a>			<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) (<a href="/source/s?defs=headerSize&amp;project=rtmp_client">headerSize</a> &lt;&lt; <span class="n">6</span>));
<a class="l" name="174" href="#174">174</a>			<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) (<a class="d" href="#channelId">channelId</a> - <span class="n">64</span>));
<a class="l" name="175" href="#175">175</a>		} <b>else</b> {
<a class="l" name="176" href="#176">176</a>			<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) ((<a href="/source/s?defs=headerSize&amp;project=rtmp_client">headerSize</a> &lt;&lt; <span class="n">6</span>) | <span class="n">1</span>));
<a class="l" name="177" href="#177">177</a>			<a class="d" href="#channelId">channelId</a> -= <span class="n">64</span>;
<a class="l" name="178" href="#178">178</a>			<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) (<a class="d" href="#channelId">channelId</a> &amp; <span class="n">0xff</span>));
<a class="l" name="179" href="#179">179</a>			<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) (<a class="d" href="#channelId">channelId</a> &gt;&gt; <span class="n">8</span>));
<a class="hl" name="180" href="#180">180</a>		}
<a class="l" name="181" href="#181">181</a>	}
<a class="l" name="182" href="#182">182</a>
<a class="l" name="183" href="#183">183</a>    <span class="c">/**
<a class="l" name="184" href="#184">184</a>     * Decode channel id.
<a class="l" name="185" href="#185">185</a>	 *
<a class="l" name="186" href="#186">186</a>     * <strong>@param</strong> <em>header</em>        Header
<a class="l" name="187" href="#187">187</a>     * <strong>@param</strong> <em>byteCount</em> byte count
<a class="l" name="188" href="#188">188</a>     * <strong>@return</strong>              Channel id
<a class="l" name="189" href="#189">189</a>     */</span>
<a class="hl" name="190" href="#190">190</a>	<b>public</b> <b>static</b> <b>int</b> <a class="xmt" name="decodeChannelId"/><a href="/source/s?refs=decodeChannelId&amp;project=rtmp_client" class="xmt">decodeChannelId</a>(<b>int</b> <a class="xa" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xa">header</a>, <b>int</b> <a class="xa" name="byteCount"/><a href="/source/s?refs=byteCount&amp;project=rtmp_client" class="xa">byteCount</a>) {
<a class="l" name="191" href="#191">191</a>		<b>if</b> (<a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a> == <span class="n">1</span>) {
<a class="l" name="192" href="#192">192</a>			<b>return</b> (<a href="/source/s?defs=header&amp;project=rtmp_client">header</a> &amp; <span class="n">0x3f</span>);
<a class="l" name="193" href="#193">193</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a> == <span class="n">2</span>) {
<a class="l" name="194" href="#194">194</a>			<b>return</b> <span class="n">64</span> + (<a href="/source/s?defs=header&amp;project=rtmp_client">header</a> &amp; <span class="n">0xff</span>);
<a class="l" name="195" href="#195">195</a>		} <b>else</b> {
<a class="l" name="196" href="#196">196</a>			<b>return</b> <span class="n">64</span> + ((<a href="/source/s?defs=header&amp;project=rtmp_client">header</a> &gt;&gt; <span class="n">8</span>) &amp; <span class="n">0xff</span>) + ((<a href="/source/s?defs=header&amp;project=rtmp_client">header</a> &amp; <span class="n">0xff</span>) &lt;&lt; <span class="n">8</span>);
<a class="l" name="197" href="#197">197</a>		}
<a class="l" name="198" href="#198">198</a>	}
<a class="l" name="199" href="#199">199</a>
<a class="hl" name="200" href="#200">200</a>    <span class="c">/**
<a class="l" name="201" href="#201">201</a>     * Decode header size.
<a class="l" name="202" href="#202">202</a>	 *
<a class="l" name="203" href="#203">203</a>     * <strong>@param</strong> <em>header</em>      Header byte
<a class="l" name="204" href="#204">204</a>     * <strong>@param</strong> <em>byteCount</em> byte count
<a class="l" name="205" href="#205">205</a>     * <strong>@return</strong>            Header size byte
<a class="l" name="206" href="#206">206</a>     */</span>
<a class="l" name="207" href="#207">207</a>    <b>public</b> <b>static</b> <b>byte</b> <a class="xmt" name="decodeHeaderSize"/><a href="/source/s?refs=decodeHeaderSize&amp;project=rtmp_client" class="xmt">decodeHeaderSize</a>(<b>int</b> <a class="xa" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xa">header</a>, <b>int</b> <a class="xa" name="byteCount"/><a href="/source/s?refs=byteCount&amp;project=rtmp_client" class="xa">byteCount</a>) {
<a class="l" name="208" href="#208">208</a>    	<b>if</b> (<a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a> == <span class="n">1</span>) {
<a class="l" name="209" href="#209">209</a>    		<b>return</b> (<b>byte</b>) (<a href="/source/s?defs=header&amp;project=rtmp_client">header</a> &gt;&gt; <span class="n">6</span>);
<a class="hl" name="210" href="#210">210</a>    	} <b>else</b> <b>if</b> (<a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a> == <span class="n">2</span>) {
<a class="l" name="211" href="#211">211</a>        	<b>return</b> (<b>byte</b>) (<a href="/source/s?defs=header&amp;project=rtmp_client">header</a> &gt;&gt; <span class="n">14</span>);
<a class="l" name="212" href="#212">212</a>    	} <b>else</b> {
<a class="l" name="213" href="#213">213</a>    		<b>return</b> (<b>byte</b>) (<a href="/source/s?defs=header&amp;project=rtmp_client">header</a> &gt;&gt; <span class="n">22</span>);
<a class="l" name="214" href="#214">214</a>    	}
<a class="l" name="215" href="#215">215</a>	}
<a class="l" name="216" href="#216">216</a>
<a class="l" name="217" href="#217">217</a>    <span class="c">/**
<a class="l" name="218" href="#218">218</a>     * Return header length from marker value.
<a class="l" name="219" href="#219">219</a>	 *
<a class="hl" name="220" href="#220">220</a>     * <strong>@param</strong> <em>headerSize</em>       Header size marker value
<a class="l" name="221" href="#221">221</a>     * <strong>@return</strong>                 Header length
<a class="l" name="222" href="#222">222</a>     */</span>
<a class="l" name="223" href="#223">223</a>    <b>public</b> <b>static</b> <b>int</b> <a class="xmt" name="getHeaderLength"/><a href="/source/s?refs=getHeaderLength&amp;project=rtmp_client" class="xmt">getHeaderLength</a>(<b>byte</b> <a class="xa" name="headerSize"/><a href="/source/s?refs=headerSize&amp;project=rtmp_client" class="xa">headerSize</a>) {
<a class="l" name="224" href="#224">224</a>		<b>switch</b> (<a href="/source/s?defs=headerSize&amp;project=rtmp_client">headerSize</a>) {
<a class="l" name="225" href="#225">225</a>			<b>case</b> <a href="/source/s?defs=HEADER_NEW&amp;project=rtmp_client">HEADER_NEW</a>:
<a class="l" name="226" href="#226">226</a>				<b>return</b> <span class="n">12</span>;
<a class="l" name="227" href="#227">227</a>			<b>case</b> <a href="/source/s?defs=HEADER_SAME_SOURCE&amp;project=rtmp_client">HEADER_SAME_SOURCE</a>:
<a class="l" name="228" href="#228">228</a>				<b>return</b> <span class="n">8</span>;
<a class="l" name="229" href="#229">229</a>			<b>case</b> <a href="/source/s?defs=HEADER_TIMER_CHANGE&amp;project=rtmp_client">HEADER_TIMER_CHANGE</a>:
<a class="hl" name="230" href="#230">230</a>				<b>return</b> <span class="n">4</span>;
<a class="l" name="231" href="#231">231</a>			<b>case</b> <a href="/source/s?defs=HEADER_CONTINUE&amp;project=rtmp_client">HEADER_CONTINUE</a>:
<a class="l" name="232" href="#232">232</a>				<b>return</b> <span class="n">1</span>;
<a class="l" name="233" href="#233">233</a>			<b>default</b>:
<a class="l" name="234" href="#234">234</a>				<b>return</b> -<span class="n">1</span>;
<a class="l" name="235" href="#235">235</a>		}
<a class="l" name="236" href="#236">236</a>	}
<a class="l" name="237" href="#237">237</a>
<a class="l" name="238" href="#238">238</a>    <span class="c">/**
<a class="l" name="239" href="#239">239</a>     * Compares two RTMP time stamps, accounting for time stamp wrapping.
<a class="hl" name="240" href="#240">240</a>     *
<a class="l" name="241" href="#241">241</a>     * <strong>@param</strong> a First time stamp
<a class="l" name="242" href="#242">242</a>     * <strong>@param</strong> b Second time stamp
<a class="l" name="243" href="#243">243</a>     * <strong>@return</strong> -1 if a &lt; b, 1 if a &gt; b, or 0 if a == b
<a class="l" name="244" href="#244">244</a>     */</span>
<a class="l" name="245" href="#245">245</a>    <b>public</b> <b>static</b> <b>int</b> <a class="xmt" name="compareTimestamps"/><a href="/source/s?refs=compareTimestamps&amp;project=rtmp_client" class="xmt">compareTimestamps</a>(<b>final</b> <b>int</b> a, <b>final</b> <b>int</b> b) {
<a class="l" name="246" href="#246">246</a>    	<b>long</b> <a href="/source/s?defs=diff&amp;project=rtmp_client">diff</a> = <a class="d" href="#diffTimestamps">diffTimestamps</a>(a, b);
<a class="l" name="247" href="#247">247</a>    	<b>return</b> <a href="/source/s?defs=diff&amp;project=rtmp_client">diff</a> &lt; <span class="n">0</span> ? -<span class="n">1</span> : (<a href="/source/s?defs=diff&amp;project=rtmp_client">diff</a> &gt; <span class="n">0</span> ? <span class="n">1</span> : <span class="n">0</span>);
<a class="l" name="248" href="#248">248</a>    }
<a class="l" name="249" href="#249">249</a>
<a class="hl" name="250" href="#250">250</a>    <span class="c">/**
<a class="l" name="251" href="#251">251</a>     * Calculates the delta between two time stamps, adjusting
<a class="l" name="252" href="#252">252</a>     * for time stamp wrapping.
<a class="l" name="253" href="#253">253</a>     *
<a class="l" name="254" href="#254">254</a>     * <strong>@param</strong> a First time stamp
<a class="l" name="255" href="#255">255</a>     * <strong>@param</strong> b Second time stamp
<a class="l" name="256" href="#256">256</a>     * <strong>@return</strong> the distance between a and b, which will be negative if a is less than b.
<a class="l" name="257" href="#257">257</a>     */</span>
<a class="l" name="258" href="#258">258</a>    <b>public</b> <b>static</b> <b>long</b> <a class="xmt" name="diffTimestamps"/><a href="/source/s?refs=diffTimestamps&amp;project=rtmp_client" class="xmt">diffTimestamps</a>(<b>final</b> <b>int</b> a, <b>final</b> <b>int</b> b) {
<a class="l" name="259" href="#259">259</a>    	<span class="c">// first convert each to unsigned integers</span>
<a class="hl" name="260" href="#260">260</a>    	<b>final</b> <b>long</b> <a href="/source/s?defs=unsignedA&amp;project=rtmp_client">unsignedA</a> = a &amp; <span class="n">0xFFFFFFFFL</span>;
<a class="l" name="261" href="#261">261</a>    	<b>final</b> <b>long</b> <a href="/source/s?defs=unsignedB&amp;project=rtmp_client">unsignedB</a> = b &amp; <span class="n">0xFFFFFFFFL</span>;
<a class="l" name="262" href="#262">262</a>    	<span class="c">// then find the delta</span>
<a class="l" name="263" href="#263">263</a>    	<b>final</b> <b>long</b> <a href="/source/s?defs=delta&amp;project=rtmp_client">delta</a> = <a href="/source/s?defs=unsignedA&amp;project=rtmp_client">unsignedA</a>-<a href="/source/s?defs=unsignedB&amp;project=rtmp_client">unsignedB</a>;
<a class="l" name="264" href="#264">264</a>    	<b>return</b> <a href="/source/s?defs=delta&amp;project=rtmp_client">delta</a>;
<a class="l" name="265" href="#265">265</a>    }
<a class="l" name="266" href="#266">266</a>
<a class="l" name="267" href="#267">267</a>}
<a class="l" name="268" href="#268">268</a>