<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["RTMPProtocolEncoder",72]]],["Package","xp",[["org.red5.server.net.rtmp.codec",1]]],["Method","xmt",[["calculateHeaderSize",388],["doEncodeSharedObject",625],["dropMessage",220],["encode",117],["encodeAggregate",857],["encodeAudioData",863],["encodeBytesRead",850],["encodeChunkSize",594],["encodeClientBW",586],["encodeFlexMessage",926],["encodeFlexSharedObject",601],["encodeFlexStreamSend",935],["encodeHeader",407],["encodeHeader",421],["encodeInvoke",742],["encodeMessage",489],["encodeNotify",737],["encodeNotifyOrInvoke",752],["encodeNotifyOrInvoke",765],["encodePacket",138],["encodePing",829],["encodeServerBW",574],["encodeSharedObject",611],["encodeStreamMetadata",880],["encodeUnknown",875],["encodeVideoData",869],["generateErrorResult",892],["getBaseTolerance",967],["getHeaderType",353],["setBaseTolerance",954],["setDropLiveFuture",963],["setSerializer",950],["updateTolerance",940]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=codec&amp;project=rtmp_client">codec</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><span class="c">//import java.util.ArrayList;</span>
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>.<a href="/source/s?defs=BufferUtils&amp;project=rtmp_client">BufferUtils</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=IConnection&amp;project=rtmp_client">IConnection</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=Red5&amp;project=rtmp_client">Red5</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=IConnection&amp;project=rtmp_client">IConnection</a>.<a href="/source/s?defs=Encoding&amp;project=rtmp_client">Encoding</a>;
<a class="l" name="33" href="#33">33</a><span class="c">//import org.red5.server.api.stream.IClientStream;</span>
<a class="l" name="34" href="#34">34</a><span class="c">//import org.red5.server.exception.ClientDetailsException;</span>
<a class="l" name="35" href="#35">35</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a>;
<a class="l" name="36" href="#36">36</a><span class="c">//import org.red5.server.net.rtmp.RTMPConnection;</span>
<a class="l" name="37" href="#37">37</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>;
<a class="l" name="38" href="#38">38</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=codec&amp;project=rtmp_client">codec</a>.<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=LiveTimestampMapping&amp;project=rtmp_client">LiveTimestampMapping</a>;
<a class="l" name="39" href="#39">39</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Aggregate&amp;project=rtmp_client">Aggregate</a>;
<a class="hl" name="40" href="#40">40</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=AudioData&amp;project=rtmp_client">AudioData</a>;
<a class="l" name="41" href="#41">41</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=BytesRead&amp;project=rtmp_client">BytesRead</a>;
<a class="l" name="42" href="#42">42</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=ChunkSize&amp;project=rtmp_client">ChunkSize</a>;
<a class="l" name="43" href="#43">43</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=ClientBW&amp;project=rtmp_client">ClientBW</a>;
<a class="l" name="44" href="#44">44</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=FlexMessage&amp;project=rtmp_client">FlexMessage</a>;
<a class="l" name="45" href="#45">45</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=FlexStreamSend&amp;project=rtmp_client">FlexStreamSend</a>;
<a class="l" name="46" href="#46">46</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a>;
<a class="l" name="47" href="#47">47</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>;
<a class="l" name="48" href="#48">48</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>;
<a class="l" name="49" href="#49">49</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>;
<a class="hl" name="50" href="#50">50</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=ServerBW&amp;project=rtmp_client">ServerBW</a>;
<a class="l" name="51" href="#51">51</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Unknown&amp;project=rtmp_client">Unknown</a>;
<a class="l" name="52" href="#52">52</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=VideoData&amp;project=rtmp_client">VideoData</a>;
<a class="l" name="53" href="#53">53</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=VideoData&amp;project=rtmp_client">VideoData</a>.<a href="/source/s?defs=FrameType&amp;project=rtmp_client">FrameType</a>;
<a class="l" name="54" href="#54">54</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>;
<a class="l" name="55" href="#55">55</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a>;
<a class="l" name="56" href="#56">56</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a>;
<a class="l" name="57" href="#57">57</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=SharedObjectTypeMapping&amp;project=rtmp_client">SharedObjectTypeMapping</a>;
<a class="l" name="58" href="#58">58</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=status&amp;project=rtmp_client">status</a>.<a href="/source/s?defs=Status&amp;project=rtmp_client">Status</a>;
<a class="l" name="59" href="#59">59</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=status&amp;project=rtmp_client">status</a>.<a href="/source/s?defs=StatusCodes&amp;project=rtmp_client">StatusCodes</a>;
<a class="hl" name="60" href="#60">60</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=status&amp;project=rtmp_client">status</a>.<a href="/source/s?defs=StatusObject&amp;project=rtmp_client">StatusObject</a>;
<a class="l" name="61" href="#61">61</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>;
<a class="l" name="62" href="#62">62</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a>;
<a class="l" name="63" href="#63">63</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a>;
<a class="l" name="64" href="#64">64</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=so&amp;project=rtmp_client">so</a>.<a href="/source/s?defs=ISharedObjectEvent&amp;project=rtmp_client">ISharedObjectEvent</a>;
<a class="l" name="65" href="#65">65</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=so&amp;project=rtmp_client">so</a>.<a href="/source/s?defs=ISharedObjectMessage&amp;project=rtmp_client">ISharedObjectMessage</a>;
<a class="l" name="66" href="#66">66</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="67" href="#67">67</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="68" href="#68">68</a>
<a class="l" name="69" href="#69">69</a><span class="c">/**
<a class="hl" name="70" href="#70">70</a> * RTMP protocol encoder encodes RTMP messages and packets to byte buffers.
<a class="l" name="71" href="#71">71</a> */</span>
<a class="l" name="72" href="#72">72</a><b>public</b> <b>class</b> <a class="xc" name="RTMPProtocolEncoder"/><a href="/source/s?refs=RTMPProtocolEncoder&amp;project=rtmp_client" class="xc">RTMPProtocolEncoder</a> <b>implements</b> <a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>, <a href="/source/s?defs=IEventEncoder&amp;project=rtmp_client">IEventEncoder</a> {
<a class="l" name="73" href="#73">73</a>
<a class="l" name="74" href="#74">74</a>	<span class="c">/**
<a class="l" name="75" href="#75">75</a>	 * Logger.
<a class="l" name="76" href="#76">76</a>	 */</span>
<a class="l" name="77" href="#77">77</a>	<b>protected</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a class="d" href="#RTMPProtocolEncoder">RTMPProtocolEncoder</a>.<b>class</b>);
<a class="l" name="78" href="#78">78</a>
<a class="l" name="79" href="#79">79</a>	<span class="c">/**
<a class="hl" name="80" href="#80">80</a>	 * Serializer object.
<a class="l" name="81" href="#81">81</a>	 */</span>
<a class="l" name="82" href="#82">82</a>	<b>private</b> <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xfld" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xfld">serializer</a>;
<a class="l" name="83" href="#83">83</a>
<a class="l" name="84" href="#84">84</a>	<span class="c">/**
<a class="l" name="85" href="#85">85</a>	 * Tolerance (in milliseconds) for late media on streams. A set of levels based on this
<a class="l" name="86" href="#86">86</a>	 * value will be determined.
<a class="l" name="87" href="#87">87</a>	 */</span>
<a class="l" name="88" href="#88">88</a>	<b>private</b> <b>long</b> <a class="xfld" name="baseTolerance"/><a href="/source/s?refs=baseTolerance&amp;project=rtmp_client" class="xfld">baseTolerance</a> = <span class="n">15000</span>;
<a class="l" name="89" href="#89">89</a>
<a class="hl" name="90" href="#90">90</a>	<span class="c">/**
<a class="l" name="91" href="#91">91</a>	 * Middle tardiness level, between base and this value disposable frames
<a class="l" name="92" href="#92">92</a>	 * will be dropped. Between this and highest value regular interframes
<a class="l" name="93" href="#93">93</a>	 * will be dropped.
<a class="l" name="94" href="#94">94</a>	 */</span>
<a class="l" name="95" href="#95">95</a>	<b>private</b> <b>long</b> <a class="xfld" name="midTolerance"/><a href="/source/s?refs=midTolerance&amp;project=rtmp_client" class="xfld">midTolerance</a> = <a href="/source/s?defs=baseTolerance&amp;project=rtmp_client">baseTolerance</a> + (<b>long</b>) (<a href="/source/s?defs=baseTolerance&amp;project=rtmp_client">baseTolerance</a> * <span class="n">0.3</span>);
<a class="l" name="96" href="#96">96</a>
<a class="l" name="97" href="#97">97</a>	<span class="c">/**
<a class="l" name="98" href="#98">98</a>	 * Highest tardiness level before dropping key frames
<a class="l" name="99" href="#99">99</a>	 */</span>
<a class="hl" name="100" href="#100">100</a>	<b>private</b> <b>long</b> <a class="xfld" name="highestTolerance"/><a href="/source/s?refs=highestTolerance&amp;project=rtmp_client" class="xfld">highestTolerance</a> = <a href="/source/s?defs=baseTolerance&amp;project=rtmp_client">baseTolerance</a> + (<b>long</b>) (<a href="/source/s?defs=baseTolerance&amp;project=rtmp_client">baseTolerance</a> * <span class="n">0.6</span>);
<a class="l" name="101" href="#101">101</a>
<a class="l" name="102" href="#102">102</a>
<a class="l" name="103" href="#103">103</a>	<span class="c">/**
<a class="l" name="104" href="#104">104</a>	 * Indicates if we should drop live packets with future timestamp
<a class="l" name="105" href="#105">105</a>	 * (i.e, when publisher bandwidth is limited) - EXPERIMENTAL
<a class="l" name="106" href="#106">106</a>	 * */</span>
<a class="l" name="107" href="#107">107</a>	<b>private</b> <b>boolean</b> <a class="xfld" name="dropLiveFuture"/><a href="/source/s?refs=dropLiveFuture&amp;project=rtmp_client" class="xfld">dropLiveFuture</a> = <b>false</b>;
<a class="l" name="108" href="#108">108</a>
<a class="l" name="109" href="#109">109</a>	<span class="c">/**
<a class="hl" name="110" href="#110">110</a>	 * Encodes object with given protocol state to byte buffer
<a class="l" name="111" href="#111">111</a>	 *
<a class="l" name="112" href="#112">112</a>	 * <strong>@param</strong> <em>state</em>			Protocol state
<a class="l" name="113" href="#113">113</a>	 * <strong>@param</strong> <em>message</em>		Object to encode
<a class="l" name="114" href="#114">114</a>	 * <strong>@return</strong>				IoBuffer with encoded data
<a class="l" name="115" href="#115">115</a>	 * <strong>@throws</strong> <em>Exception</em>    Any decoding exception
<a class="l" name="116" href="#116">116</a>	 */</span>
<a class="l" name="117" href="#117">117</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encode"/><a href="/source/s?refs=encode&amp;project=rtmp_client" class="xmt">encode</a>(<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a> <a class="xa" name="state"/><a href="/source/s?refs=state&amp;project=rtmp_client" class="xa">state</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="message"/><a href="/source/s?refs=message&amp;project=rtmp_client" class="xa">message</a>) <b>throws</b> <a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> {
<a class="l" name="118" href="#118">118</a>		<b>try</b> {
<a class="l" name="119" href="#119">119</a>			<b>final</b> <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a> = (<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>) <a class="d" href="#state">state</a>;
<a class="hl" name="120" href="#120">120</a>			<b>if</b> (<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> <b>instanceof</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>) {
<a class="l" name="121" href="#121">121</a>				<b>return</b> (<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>;
<a class="l" name="122" href="#122">122</a>			} <b>else</b> {
<a class="l" name="123" href="#123">123</a>				<b>return</b> <a class="d" href="#encodePacket">encodePacket</a>(<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>, (<a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="124" href="#124">124</a>			}
<a class="l" name="125" href="#125">125</a>		} <b>catch</b> (<a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a> e) {
<a class="l" name="126" href="#126">126</a>			<a class="d" href="#log">log</a>.<a class="d" href="#error">error</a>(<span class="s">"Error encoding object: "</span>, e);
<a class="l" name="127" href="#127">127</a>		}
<a class="l" name="128" href="#128">128</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="129" href="#129">129</a>	}
<a class="hl" name="130" href="#130">130</a>
<a class="l" name="131" href="#131">131</a>	<span class="c">/**
<a class="l" name="132" href="#132">132</a>	 * Encode packet.
<a class="l" name="133" href="#133">133</a>	 *
<a class="l" name="134" href="#134">134</a>	 * <strong>@param</strong> <em>rtmp</em>        RTMP protocol state
<a class="l" name="135" href="#135">135</a>	 * <strong>@param</strong> <em>packet</em>      RTMP packet
<a class="l" name="136" href="#136">136</a>	 * <strong>@return</strong>            Encoded data
<a class="l" name="137" href="#137">137</a>	 */</span>
<a class="l" name="138" href="#138">138</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodePacket"/><a href="/source/s?refs=encodePacket&amp;project=rtmp_client" class="xmt">encodePacket</a>(<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>, <a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a> <a class="xa" name="packet"/><a href="/source/s?refs=packet&amp;project=rtmp_client" class="xa">packet</a>) {
<a class="l" name="139" href="#139">139</a>
<a class="hl" name="140" href="#140">140</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="141" href="#141">141</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=data&amp;project=rtmp_client">data</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="142" href="#142">142</a>
<a class="l" name="143" href="#143">143</a>		<b>final</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a href="/source/s?defs=header&amp;project=rtmp_client">header</a> = <a class="d" href="#packet">packet</a>.<a href="/source/s?defs=getHeader&amp;project=rtmp_client">getHeader</a>();
<a class="l" name="144" href="#144">144</a>		<b>final</b> <b>int</b> <a class="d" href="#channelId">channelId</a> = <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getChannelId&amp;project=rtmp_client">getChannelId</a>();
<a class="l" name="145" href="#145">145</a><span class="c">//		log.debug("Channel id: {}", channelId);</span>
<a class="l" name="146" href="#146">146</a>		<b>final</b> <a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a> <a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#packet">packet</a>.<a href="/source/s?defs=getMessage&amp;project=rtmp_client">getMessage</a>();
<a class="l" name="147" href="#147">147</a>
<a class="l" name="148" href="#148">148</a>		<b>if</b> (<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> <b>instanceof</b> <a href="/source/s?defs=ChunkSize&amp;project=rtmp_client">ChunkSize</a>) {
<a class="l" name="149" href="#149">149</a>			<a href="/source/s?defs=ChunkSize&amp;project=rtmp_client">ChunkSize</a> <a href="/source/s?defs=chunkSizeMsg&amp;project=rtmp_client">chunkSizeMsg</a> = (<a href="/source/s?defs=ChunkSize&amp;project=rtmp_client">ChunkSize</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>;
<a class="hl" name="150" href="#150">150</a>			<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setWriteChunkSize&amp;project=rtmp_client">setWriteChunkSize</a>(<a href="/source/s?defs=chunkSizeMsg&amp;project=rtmp_client">chunkSizeMsg</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>());
<a class="l" name="151" href="#151">151</a>		}
<a class="l" name="152" href="#152">152</a>
<a class="l" name="153" href="#153">153</a>		<span class="c">//normally the message is expected not to be dropped</span>
<a class="l" name="154" href="#154">154</a>		<b>if</b> (!<a class="d" href="#dropMessage">dropMessage</a>(<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>, <a class="d" href="#channelId">channelId</a>, <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>)) {
<a class="l" name="155" href="#155">155</a>			<a href="/source/s?defs=data&amp;project=rtmp_client">data</a> = <a class="d" href="#encodeMessage">encodeMessage</a>(<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>, <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="156" href="#156">156</a>			<b>if</b> (<a href="/source/s?defs=data&amp;project=rtmp_client">data</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="157" href="#157">157</a>				<b>if</b> (<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() != <span class="n">0</span>) {
<a class="l" name="158" href="#158">158</a>					<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="159" href="#159">159</a>				} <b>else</b> {
<a class="hl" name="160" href="#160">160</a>					<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=rewind&amp;project=rtmp_client">rewind</a>();
<a class="l" name="161" href="#161">161</a>				}
<a class="l" name="162" href="#162">162</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setSize&amp;project=rtmp_client">setSize</a>(<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>());
<a class="l" name="163" href="#163">163</a>
<a class="l" name="164" href="#164">164</a>				<a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a href="/source/s?defs=lastHeader&amp;project=rtmp_client">lastHeader</a> = <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getLastWriteHeader&amp;project=rtmp_client">getLastWriteHeader</a>(<a class="d" href="#channelId">channelId</a>);
<a class="l" name="165" href="#165">165</a>				<b>int</b> <a href="/source/s?defs=headerSize&amp;project=rtmp_client">headerSize</a> = <a class="d" href="#calculateHeaderSize">calculateHeaderSize</a>(<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>, <a href="/source/s?defs=lastHeader&amp;project=rtmp_client">lastHeader</a>);
<a class="l" name="166" href="#166">166</a>
<a class="l" name="167" href="#167">167</a>				<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setLastWriteHeader&amp;project=rtmp_client">setLastWriteHeader</a>(<a class="d" href="#channelId">channelId</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>);
<a class="l" name="168" href="#168">168</a>				<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setLastWritePacket&amp;project=rtmp_client">setLastWritePacket</a>(<a class="d" href="#channelId">channelId</a>, <a class="d" href="#packet">packet</a>);
<a class="l" name="169" href="#169">169</a>
<a class="hl" name="170" href="#170">170</a>				<b>int</b> <a class="d" href="#chunkSize">chunkSize</a> = <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getWriteChunkSize&amp;project=rtmp_client">getWriteChunkSize</a>();
<a class="l" name="171" href="#171">171</a>				<b>int</b> <a href="/source/s?defs=chunkHeaderSize&amp;project=rtmp_client">chunkHeaderSize</a> = <span class="n">1</span>;
<a class="l" name="172" href="#172">172</a>				<b>if</b> (<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getChannelId&amp;project=rtmp_client">getChannelId</a>() &gt; <span class="n">320</span>) {
<a class="l" name="173" href="#173">173</a>					<a href="/source/s?defs=chunkHeaderSize&amp;project=rtmp_client">chunkHeaderSize</a> = <span class="n">3</span>;
<a class="l" name="174" href="#174">174</a>				} <b>else</b> <b>if</b> (<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getChannelId&amp;project=rtmp_client">getChannelId</a>() &gt; <span class="n">63</span>) {
<a class="l" name="175" href="#175">175</a>					<a href="/source/s?defs=chunkHeaderSize&amp;project=rtmp_client">chunkHeaderSize</a> = <span class="n">2</span>;
<a class="l" name="176" href="#176">176</a>				}
<a class="l" name="177" href="#177">177</a>				<b>int</b> <a href="/source/s?defs=numChunks&amp;project=rtmp_client">numChunks</a> = (<b>int</b>) <a href="/source/s?defs=Math&amp;project=rtmp_client">Math</a>.<a href="/source/s?defs=ceil&amp;project=rtmp_client">ceil</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>() / (<b>float</b>) <a class="d" href="#chunkSize">chunkSize</a>);
<a class="l" name="178" href="#178">178</a>				<b>int</b> <a href="/source/s?defs=bufSize&amp;project=rtmp_client">bufSize</a> = <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>() + <a href="/source/s?defs=headerSize&amp;project=rtmp_client">headerSize</a> + (<a href="/source/s?defs=numChunks&amp;project=rtmp_client">numChunks</a> &gt; <span class="n">0</span> ? (<a href="/source/s?defs=numChunks&amp;project=rtmp_client">numChunks</a> - <span class="n">1</span>) * <a href="/source/s?defs=chunkHeaderSize&amp;project=rtmp_client">chunkHeaderSize</a> : <span class="n">0</span>);
<a class="l" name="179" href="#179">179</a>				<a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<a href="/source/s?defs=bufSize&amp;project=rtmp_client">bufSize</a>, <b>false</b>);
<a class="hl" name="180" href="#180">180</a>
<a class="l" name="181" href="#181">181</a>				<a href="/source/s?defs=encodeHeader&amp;project=rtmp_client">encodeHeader</a>(<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>, <a href="/source/s?defs=lastHeader&amp;project=rtmp_client">lastHeader</a>, <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>);
<a class="l" name="182" href="#182">182</a>
<a class="l" name="183" href="#183">183</a>				<b>if</b> (<a href="/source/s?defs=numChunks&amp;project=rtmp_client">numChunks</a> == <span class="n">1</span>) {
<a class="l" name="184" href="#184">184</a>					<span class="c">// we can do it with a single copy</span>
<a class="l" name="185" href="#185">185</a>					<a href="/source/s?defs=BufferUtils&amp;project=rtmp_client">BufferUtils</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>, <a href="/source/s?defs=data&amp;project=rtmp_client">data</a>, <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>());
<a class="l" name="186" href="#186">186</a>				} <b>else</b> {
<a class="l" name="187" href="#187">187</a>					<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=numChunks&amp;project=rtmp_client">numChunks</a> - <span class="n">1</span>; i++) {
<a class="l" name="188" href="#188">188</a>						<a href="/source/s?defs=BufferUtils&amp;project=rtmp_client">BufferUtils</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>, <a href="/source/s?defs=data&amp;project=rtmp_client">data</a>, <a class="d" href="#chunkSize">chunkSize</a>);
<a class="l" name="189" href="#189">189</a>						<a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=encodeHeaderByte&amp;project=rtmp_client">encodeHeaderByte</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>, <a href="/source/s?defs=HEADER_CONTINUE&amp;project=rtmp_client">HEADER_CONTINUE</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getChannelId&amp;project=rtmp_client">getChannelId</a>());
<a class="hl" name="190" href="#190">190</a>					}
<a class="l" name="191" href="#191">191</a>					<a href="/source/s?defs=BufferUtils&amp;project=rtmp_client">BufferUtils</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>, <a href="/source/s?defs=data&amp;project=rtmp_client">data</a>, <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>());
<a class="l" name="192" href="#192">192</a>				}
<a class="l" name="193" href="#193">193</a>
<a class="l" name="194" href="#194">194</a>				<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=free&amp;project=rtmp_client">free</a>();
<a class="l" name="195" href="#195">195</a>				<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="196" href="#196">196</a>				<a href="/source/s?defs=data&amp;project=rtmp_client">data</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="197" href="#197">197</a>			}
<a class="l" name="198" href="#198">198</a>		}
<a class="l" name="199" href="#199">199</a>		<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=release&amp;project=rtmp_client">release</a>();
<a class="hl" name="200" href="#200">200</a>
<a class="l" name="201" href="#201">201</a>		<b>return</b> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>;
<a class="l" name="202" href="#202">202</a>	}
<a class="l" name="203" href="#203">203</a>
<a class="l" name="204" href="#204">204</a>	<span class="c">/**
<a class="l" name="205" href="#205">205</a>	 * Determine if this message should be dropped for lateness. Live publish data
<a class="l" name="206" href="#206">206</a>	 * does not come through this section, only outgoing data does.
<a class="l" name="207" href="#207">207</a>	 *
<a class="l" name="208" href="#208">208</a>	 * - determine latency between server and client using ping
<a class="l" name="209" href="#209">209</a>	 * - ping timestamp is unsigned int (4 bytes) and is set from value on sender
<a class="hl" name="210" href="#210">210</a>	 *
<a class="l" name="211" href="#211">211</a>	 * 1st drop disposable frames - lowest mark
<a class="l" name="212" href="#212">212</a>	 * 2nd drop interframes - middle
<a class="l" name="213" href="#213">213</a>	 * 3rd drop key frames - high mark
<a class="l" name="214" href="#214">214</a>	 *
<a class="l" name="215" href="#215">215</a>	 * <strong>@param</strong> <em>rtmp</em> the protocol state
<a class="l" name="216" href="#216">216</a>	 * <strong>@param</strong> <em>channelId</em> the channel ID
<a class="l" name="217" href="#217">217</a>	 * <strong>@param</strong> <em>message</em> the message
<a class="l" name="218" href="#218">218</a>	 * <strong>@return</strong> true to drop; false to send
<a class="l" name="219" href="#219">219</a>	 */</span>
<a class="hl" name="220" href="#220">220</a>	<b>protected</b> <b>boolean</b> <a class="xmt" name="dropMessage"/><a href="/source/s?refs=dropMessage&amp;project=rtmp_client" class="xmt">dropMessage</a>(<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>, <b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>, <a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a> <a class="xa" name="message"/><a href="/source/s?refs=message&amp;project=rtmp_client" class="xa">message</a>) {
<a class="l" name="221" href="#221">221</a>		<span class="c">//whether or not the packet will be dropped</span>
<a class="l" name="222" href="#222">222</a>		<b>boolean</b> <a href="/source/s?defs=drop&amp;project=rtmp_client">drop</a> = <b>false</b>;
<a class="l" name="223" href="#223">223</a>		<span class="c">// we only drop in server mode</span>
<a class="l" name="224" href="#224">224</a>		<b>if</b> (<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getMode&amp;project=rtmp_client">getMode</a>() == <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=MODE_SERVER&amp;project=rtmp_client">MODE_SERVER</a>) {
<a class="l" name="225" href="#225">225</a>			<span class="c">//whether or not the packet is video data</span>
<a class="l" name="226" href="#226">226</a>			<b>boolean</b> <a href="/source/s?defs=isVideo&amp;project=rtmp_client">isVideo</a> = <b>false</b>;
<a class="l" name="227" href="#227">227</a>			<b>if</b> (<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> <b>instanceof</b> <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>) {
<a class="l" name="228" href="#228">228</a>				<b>final</b> <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a> <a href="/source/s?defs=pingMessage&amp;project=rtmp_client">pingMessage</a> = (<a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>;
<a class="l" name="229" href="#229">229</a>				<b>if</b> (<a href="/source/s?defs=pingMessage&amp;project=rtmp_client">pingMessage</a>.<a href="/source/s?defs=getEventType&amp;project=rtmp_client">getEventType</a>() == <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>.<a href="/source/s?defs=STREAM_PLAYBUFFER_CLEAR&amp;project=rtmp_client">STREAM_PLAYBUFFER_CLEAR</a>) {
<a class="hl" name="230" href="#230">230</a>					<span class="c">// client buffer cleared, make sure to reset timestamps for this stream</span>
<a class="l" name="231" href="#231">231</a>					<b>final</b> <b>int</b> <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a> = (<span class="n">4</span> + ((<a href="/source/s?defs=pingMessage&amp;project=rtmp_client">pingMessage</a>.<a href="/source/s?defs=getValue2&amp;project=rtmp_client">getValue2</a>() - <span class="n">1</span>) * <span class="n">5</span>));
<a class="l" name="232" href="#232">232</a>					<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setLastTimestampMapping&amp;project=rtmp_client">setLastTimestampMapping</a>(<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="233" href="#233">233</a>					<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setLastTimestampMapping&amp;project=rtmp_client">setLastTimestampMapping</a>(<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>+<span class="n">1</span>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="234" href="#234">234</a>					<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setLastTimestampMapping&amp;project=rtmp_client">setLastTimestampMapping</a>(<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>+<span class="n">2</span>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="235" href="#235">235</a>				}
<a class="l" name="236" href="#236">236</a>				<span class="c">// never drop pings</span>
<a class="l" name="237" href="#237">237</a>				<b>return</b> <b>false</b>;
<a class="l" name="238" href="#238">238</a>			}
<a class="l" name="239" href="#239">239</a>
<a class="hl" name="240" href="#240">240</a>			<span class="c">//we only drop audio or video data</span>
<a class="l" name="241" href="#241">241</a>			<b>if</b> ((<a href="/source/s?defs=isVideo&amp;project=rtmp_client">isVideo</a> = <a href="/source/s?defs=message&amp;project=rtmp_client">message</a> <b>instanceof</b> <a href="/source/s?defs=VideoData&amp;project=rtmp_client">VideoData</a>) || <a href="/source/s?defs=message&amp;project=rtmp_client">message</a> <b>instanceof</b> <a href="/source/s?defs=AudioData&amp;project=rtmp_client">AudioData</a>) {
<a class="l" name="242" href="#242">242</a>				<b>if</b> (<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=getTimestamp&amp;project=rtmp_client">getTimestamp</a>() == <span class="n">0</span>) {
<a class="l" name="243" href="#243">243</a>					<span class="c">// never drop initial packages, also this could be the first packet after</span>
<a class="l" name="244" href="#244">244</a>					<span class="c">// MP4 seeking and therefore mess with the timestamp mapping</span>
<a class="l" name="245" href="#245">245</a>					<b>return</b> <b>false</b>;
<a class="l" name="246" href="#246">246</a>				}
<a class="l" name="247" href="#247">247</a>
<a class="l" name="248" href="#248">248</a>				<span class="c">//determine working type</span>
<a class="l" name="249" href="#249">249</a>				<b>boolean</b> <a href="/source/s?defs=isLive&amp;project=rtmp_client">isLive</a> = <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=getSourceType&amp;project=rtmp_client">getSourceType</a>() == <a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>.<a href="/source/s?defs=SOURCE_TYPE_LIVE&amp;project=rtmp_client">SOURCE_TYPE_LIVE</a>;
<a class="hl" name="250" href="#250">250</a><span class="c">//				log.trace("Connection type: {}", (isLive ? "Live" : "VOD"));</span>
<a class="l" name="251" href="#251">251</a>
<a class="l" name="252" href="#252">252</a>				<b>long</b> <a href="/source/s?defs=timestamp&amp;project=rtmp_client">timestamp</a> = (<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=getTimestamp&amp;project=rtmp_client">getTimestamp</a>() &amp; <span class="n">0xFFFFFFFFL</span>);
<a class="l" name="253" href="#253">253</a>				<a href="/source/s?defs=LiveTimestampMapping&amp;project=rtmp_client">LiveTimestampMapping</a> <a href="/source/s?defs=mapping&amp;project=rtmp_client">mapping</a> = <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getLastTimestampMapping&amp;project=rtmp_client">getLastTimestampMapping</a>(<a class="d" href="#channelId">channelId</a>);
<a class="l" name="254" href="#254">254</a>				<span class="c">// just get the current time ONCE per packet</span>
<a class="l" name="255" href="#255">255</a>				<b>long</b> <a href="/source/s?defs=now&amp;project=rtmp_client">now</a> = <a href="/source/s?defs=System&amp;project=rtmp_client">System</a>.<a href="/source/s?defs=currentTimeMillis&amp;project=rtmp_client">currentTimeMillis</a>();
<a class="l" name="256" href="#256">256</a>				<b>if</b> (<a href="/source/s?defs=mapping&amp;project=rtmp_client">mapping</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> || <a href="/source/s?defs=timestamp&amp;project=rtmp_client">timestamp</a> &lt; <a href="/source/s?defs=mapping&amp;project=rtmp_client">mapping</a>.<a href="/source/s?defs=getLastStreamTime&amp;project=rtmp_client">getLastStreamTime</a>()) {
<a class="l" name="257" href="#257">257</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Resetting clock time ({}) to stream time ({})"</span>, <a href="/source/s?defs=now&amp;project=rtmp_client">now</a>, <a href="/source/s?defs=timestamp&amp;project=rtmp_client">timestamp</a>);
<a class="l" name="258" href="#258">258</a>					<span class="c">// either first time through, or time stamps were reset</span>
<a class="l" name="259" href="#259">259</a>					<a href="/source/s?defs=mapping&amp;project=rtmp_client">mapping</a> = <b>new</b> <a href="/source/s?defs=LiveTimestampMapping&amp;project=rtmp_client">LiveTimestampMapping</a>(<a href="/source/s?defs=now&amp;project=rtmp_client">now</a>, <a href="/source/s?defs=timestamp&amp;project=rtmp_client">timestamp</a>);
<a class="hl" name="260" href="#260">260</a>					<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setLastTimestampMapping&amp;project=rtmp_client">setLastTimestampMapping</a>(<a class="d" href="#channelId">channelId</a>, <a href="/source/s?defs=mapping&amp;project=rtmp_client">mapping</a>);
<a class="l" name="261" href="#261">261</a>				}
<a class="l" name="262" href="#262">262</a>				<a href="/source/s?defs=mapping&amp;project=rtmp_client">mapping</a>.<a href="/source/s?defs=setLastStreamTime&amp;project=rtmp_client">setLastStreamTime</a>(<a href="/source/s?defs=timestamp&amp;project=rtmp_client">timestamp</a>);
<a class="l" name="263" href="#263">263</a>
<a class="l" name="264" href="#264">264</a>				<b>long</b> <a href="/source/s?defs=clockTimeOfMessage&amp;project=rtmp_client">clockTimeOfMessage</a> = <a href="/source/s?defs=mapping&amp;project=rtmp_client">mapping</a>.<a href="/source/s?defs=getClockStartTime&amp;project=rtmp_client">getClockStartTime</a>() + <a href="/source/s?defs=timestamp&amp;project=rtmp_client">timestamp</a> - <a href="/source/s?defs=mapping&amp;project=rtmp_client">mapping</a>.<a href="/source/s?defs=getStreamStartTime&amp;project=rtmp_client">getStreamStartTime</a>();
<a class="l" name="265" href="#265">265</a>
<a class="l" name="266" href="#266">266</a>				<span class="c">//determine tardiness / how late it is</span>
<a class="l" name="267" href="#267">267</a>				<b>long</b> <a href="/source/s?defs=tardiness&amp;project=rtmp_client">tardiness</a> = <a href="/source/s?defs=clockTimeOfMessage&amp;project=rtmp_client">clockTimeOfMessage</a> - <a href="/source/s?defs=now&amp;project=rtmp_client">now</a>;
<a class="l" name="268" href="#268">268</a>				<span class="c">//TDJ: EXPERIMENTAL dropping for LIVE packets in future (default false)</span>
<a class="l" name="269" href="#269">269</a>				<b>if</b> (<a href="/source/s?defs=isLive&amp;project=rtmp_client">isLive</a> &amp;&amp; <a href="/source/s?defs=dropLiveFuture&amp;project=rtmp_client">dropLiveFuture</a>) {
<a class="hl" name="270" href="#270">270</a>					<a href="/source/s?defs=tardiness&amp;project=rtmp_client">tardiness</a> = <a href="/source/s?defs=Math&amp;project=rtmp_client">Math</a>.<a href="/source/s?defs=abs&amp;project=rtmp_client">abs</a>(<a href="/source/s?defs=tardiness&amp;project=rtmp_client">tardiness</a>);
<a class="l" name="271" href="#271">271</a>				}
<a class="l" name="272" href="#272">272</a>				<span class="c">//subtract the ping time / latency from the tardiness value</span>
<a class="l" name="273" href="#273">273</a>				<a href="/source/s?defs=IConnection&amp;project=rtmp_client">IConnection</a> <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> = <a href="/source/s?defs=Red5&amp;project=rtmp_client">Red5</a>.<a href="/source/s?defs=getConnectionLocal&amp;project=rtmp_client">getConnectionLocal</a>();
<a class="l" name="274" href="#274">274</a><span class="c">//				log.debug("Connection: {}", conn);</span>
<a class="l" name="275" href="#275">275</a>				<b>if</b> (<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="276" href="#276">276</a><span class="c">//					log.debug("Last ping time for connection: {}", conn.getLastPingTime());</span>
<a class="l" name="277" href="#277">277</a>					<a href="/source/s?defs=tardiness&amp;project=rtmp_client">tardiness</a> -= <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=getLastPingTime&amp;project=rtmp_client">getLastPingTime</a>();
<a class="l" name="278" href="#278">278</a>					<span class="c">//subtract the buffer time</span>
<a class="l" name="279" href="#279">279</a><span class="c">//					RTMPConnection rtmpConn = (RTMPConnection) conn;</span>
<a class="hl" name="280" href="#280">280</a><span class="c">//					int streamId = rtmpConn.getStreamIdForChannel(channelId);</span>
<a class="l" name="281" href="#281">281</a><span class="c">//					IClientStream stream = rtmpConn.getStreamById(streamId);</span>
<a class="l" name="282" href="#282">282</a><span class="c">//					if (stream != null) {</span>
<a class="l" name="283" href="#283">283</a><span class="c">//						int clientBufferDuration = stream.getClientBufferDuration();</span>
<a class="l" name="284" href="#284">284</a><span class="c">//						if (clientBufferDuration &gt; 0) {</span>
<a class="l" name="285" href="#285">285</a><span class="c">//							//two times the buffer duration seems to work best with vod</span>
<a class="l" name="286" href="#286">286</a><span class="c">//							if (!isLive) {</span>
<a class="l" name="287" href="#287">287</a><span class="c">//								tardiness -= clientBufferDuration * 2;</span>
<a class="l" name="288" href="#288">288</a><span class="c">//							} else {</span>
<a class="l" name="289" href="#289">289</a><span class="c">//								tardiness -= clientBufferDuration;</span>
<a class="hl" name="290" href="#290">290</a><span class="c">//							}</span>
<a class="l" name="291" href="#291">291</a><span class="c">//						}</span>
<a class="l" name="292" href="#292">292</a><span class="c">////						log.debug("Client buffer duration: {}", clientBufferDuration);</span>
<a class="l" name="293" href="#293">293</a><span class="c">//					}</span>
<a class="l" name="294" href="#294">294</a>				} <b>else</b> {
<a class="l" name="295" href="#295">295</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Connection is null"</span>);
<a class="l" name="296" href="#296">296</a>				}
<a class="l" name="297" href="#297">297</a>
<a class="l" name="298" href="#298">298</a>				<span class="c">//TODO: how should we differ handling based on live or vod?</span>
<a class="l" name="299" href="#299">299</a>
<a class="hl" name="300" href="#300">300</a>				<span class="c">//TODO: if we are VOD do we "pause" the provider when we are consistently late?</span>
<a class="l" name="301" href="#301">301</a>
<a class="l" name="302" href="#302">302</a><span class="c">//				log.debug("Packet timestamp: {}; tardiness: {}; now: {}; message clock time: {}, dropLiveFuture: {}", new Object[] { timestamp, tardiness, now, clockTimeOfMessage,</span>
<a class="l" name="303" href="#303">303</a><span class="c">//						dropLiveFuture });</span>
<a class="l" name="304" href="#304">304</a>
<a class="l" name="305" href="#305">305</a>				<span class="c">//anything coming in less than the base will be allowed to pass, it will not be</span>
<a class="l" name="306" href="#306">306</a>				<span class="c">//dropped or manipulated</span>
<a class="l" name="307" href="#307">307</a>				<b>if</b> (<a href="/source/s?defs=tardiness&amp;project=rtmp_client">tardiness</a> &lt; <a href="/source/s?defs=baseTolerance&amp;project=rtmp_client">baseTolerance</a>) {
<a class="l" name="308" href="#308">308</a>					<span class="c">//frame is below lowest bounds, let it go</span>
<a class="l" name="309" href="#309">309</a>
<a class="hl" name="310" href="#310">310</a>				} <b>else</b> <b>if</b> (<a href="/source/s?defs=tardiness&amp;project=rtmp_client">tardiness</a> &gt; <a class="d" href="#highestTolerance">highestTolerance</a>) {
<a class="l" name="311" href="#311">311</a>					<span class="c">//frame is really late, drop it no matter what type</span>
<a class="l" name="312" href="#312">312</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Dropping late message: {}"</span>, <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="313" href="#313">313</a>					<span class="c">//if we're working with video, indicate that we will need a key frame to proceed</span>
<a class="l" name="314" href="#314">314</a>					<b>if</b> (<a href="/source/s?defs=isVideo&amp;project=rtmp_client">isVideo</a>) {
<a class="l" name="315" href="#315">315</a>						<a href="/source/s?defs=mapping&amp;project=rtmp_client">mapping</a>.<a href="/source/s?defs=setKeyFrameNeeded&amp;project=rtmp_client">setKeyFrameNeeded</a>(<b>true</b>);
<a class="l" name="316" href="#316">316</a>					}
<a class="l" name="317" href="#317">317</a>					<span class="c">//drop it</span>
<a class="l" name="318" href="#318">318</a>					<a href="/source/s?defs=drop&amp;project=rtmp_client">drop</a> = <b>true</b>;
<a class="l" name="319" href="#319">319</a>				} <b>else</b> {
<a class="hl" name="320" href="#320">320</a>					<b>if</b> (<a href="/source/s?defs=isVideo&amp;project=rtmp_client">isVideo</a>) {
<a class="l" name="321" href="#321">321</a>						<a href="/source/s?defs=VideoData&amp;project=rtmp_client">VideoData</a> <a href="/source/s?defs=video&amp;project=rtmp_client">video</a> = (<a href="/source/s?defs=VideoData&amp;project=rtmp_client">VideoData</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>;
<a class="l" name="322" href="#322">322</a>						<b>if</b> (<a href="/source/s?defs=video&amp;project=rtmp_client">video</a>.<a href="/source/s?defs=getFrameType&amp;project=rtmp_client">getFrameType</a>() == <a href="/source/s?defs=FrameType&amp;project=rtmp_client">FrameType</a>.<a href="/source/s?defs=KEYFRAME&amp;project=rtmp_client">KEYFRAME</a>) {
<a class="l" name="323" href="#323">323</a>							<span class="c">//if its a key frame the inter and disposible checks can be skipped</span>
<a class="l" name="324" href="#324">324</a><span class="c">//							log.debug("Resuming stream with key frame; message: {}", message);</span>
<a class="l" name="325" href="#325">325</a>							<a href="/source/s?defs=mapping&amp;project=rtmp_client">mapping</a>.<a href="/source/s?defs=setKeyFrameNeeded&amp;project=rtmp_client">setKeyFrameNeeded</a>(<b>false</b>);
<a class="l" name="326" href="#326">326</a>						} <b>else</b> <b>if</b> (<a href="/source/s?defs=tardiness&amp;project=rtmp_client">tardiness</a> &gt;= <a href="/source/s?defs=baseTolerance&amp;project=rtmp_client">baseTolerance</a> &amp;&amp; <a href="/source/s?defs=tardiness&amp;project=rtmp_client">tardiness</a> &lt; <a class="d" href="#midTolerance">midTolerance</a>) {
<a class="l" name="327" href="#327">327</a>							<span class="c">//drop disposable frames</span>
<a class="l" name="328" href="#328">328</a>							<b>if</b> (<a href="/source/s?defs=video&amp;project=rtmp_client">video</a>.<a href="/source/s?defs=getFrameType&amp;project=rtmp_client">getFrameType</a>() == <a href="/source/s?defs=FrameType&amp;project=rtmp_client">FrameType</a>.<a href="/source/s?defs=DISPOSABLE_INTERFRAME&amp;project=rtmp_client">DISPOSABLE_INTERFRAME</a>) {
<a class="l" name="329" href="#329">329</a>								<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Dropping disposible frame; message: {}"</span>, <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="hl" name="330" href="#330">330</a>								<a href="/source/s?defs=drop&amp;project=rtmp_client">drop</a> = <b>true</b>;
<a class="l" name="331" href="#331">331</a>							}
<a class="l" name="332" href="#332">332</a>						} <b>else</b> <b>if</b> (<a href="/source/s?defs=tardiness&amp;project=rtmp_client">tardiness</a> &gt;= <a class="d" href="#midTolerance">midTolerance</a> &amp;&amp; <a href="/source/s?defs=tardiness&amp;project=rtmp_client">tardiness</a> &lt;= <a class="d" href="#highestTolerance">highestTolerance</a>) {
<a class="l" name="333" href="#333">333</a>							<span class="c">//drop inter-frames and disposable frames</span>
<a class="l" name="334" href="#334">334</a>							<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Dropping disposible or inter frame; message: {}"</span>, <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="335" href="#335">335</a>							<a href="/source/s?defs=drop&amp;project=rtmp_client">drop</a> = <b>true</b>;
<a class="l" name="336" href="#336">336</a>						}
<a class="l" name="337" href="#337">337</a>					}
<a class="l" name="338" href="#338">338</a>				}
<a class="l" name="339" href="#339">339</a>			}
<a class="hl" name="340" href="#340">340</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Drop data: {}"</span>, <a href="/source/s?defs=drop&amp;project=rtmp_client">drop</a>);
<a class="l" name="341" href="#341">341</a>		}
<a class="l" name="342" href="#342">342</a>		<b>return</b> <a href="/source/s?defs=drop&amp;project=rtmp_client">drop</a>;
<a class="l" name="343" href="#343">343</a>	}
<a class="l" name="344" href="#344">344</a>
<a class="l" name="345" href="#345">345</a>	<span class="c">/**
<a class="l" name="346" href="#346">346</a>	 * Determine type of header to use.
<a class="l" name="347" href="#347">347</a>	 *
<a class="l" name="348" href="#348">348</a>	 * <strong>@param</strong> <em>rtmp</em>        The protocol state
<a class="l" name="349" href="#349">349</a>	 * <strong>@param</strong> <em>header</em>      RTMP message header
<a class="hl" name="350" href="#350">350</a>	 * <strong>@param</strong> <em>lastHeader</em>  Previous header
<a class="l" name="351" href="#351">351</a>	 * <strong>@return</strong>            Header type to use.
<a class="l" name="352" href="#352">352</a>	 */</span>
<a class="l" name="353" href="#353">353</a>	<b>private</b> <b>byte</b> <a class="xmt" name="getHeaderType"/><a href="/source/s?refs=getHeaderType&amp;project=rtmp_client" class="xmt">getHeaderType</a>(<b>final</b> <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>, <b>final</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xa">header</a>, <b>final</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="lastHeader"/><a href="/source/s?refs=lastHeader&amp;project=rtmp_client" class="xa">lastHeader</a>) {
<a class="l" name="354" href="#354">354</a>		<b>if</b> (<a href="/source/s?defs=lastHeader&amp;project=rtmp_client">lastHeader</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="355" href="#355">355</a>			<b>return</b> <a href="/source/s?defs=HEADER_NEW&amp;project=rtmp_client">HEADER_NEW</a>;
<a class="l" name="356" href="#356">356</a>		}
<a class="l" name="357" href="#357">357</a>		<b>final</b> <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a> <a href="/source/s?defs=lastFullTs&amp;project=rtmp_client">lastFullTs</a> = <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getLastFullTimestampWritten&amp;project=rtmp_client">getLastFullTimestampWritten</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getChannelId&amp;project=rtmp_client">getChannelId</a>());
<a class="l" name="358" href="#358">358</a>		<b>if</b> (<a href="/source/s?defs=lastFullTs&amp;project=rtmp_client">lastFullTs</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="359" href="#359">359</a>			<b>return</b> <a href="/source/s?defs=HEADER_NEW&amp;project=rtmp_client">HEADER_NEW</a>;
<a class="hl" name="360" href="#360">360</a>		}
<a class="l" name="361" href="#361">361</a>		<b>final</b> <b>byte</b> <a href="/source/s?defs=headerType&amp;project=rtmp_client">headerType</a>;
<a class="l" name="362" href="#362">362</a>		<b>final</b> <b>long</b> <a href="/source/s?defs=diff&amp;project=rtmp_client">diff</a> = <a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=diffTimestamps&amp;project=rtmp_client">diffTimestamps</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>(), <a href="/source/s?defs=lastHeader&amp;project=rtmp_client">lastHeader</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>());
<a class="l" name="363" href="#363">363</a>		<b>final</b> <b>long</b> <a href="/source/s?defs=timeSinceFullTs&amp;project=rtmp_client">timeSinceFullTs</a> = <a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=diffTimestamps&amp;project=rtmp_client">diffTimestamps</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>(), <a href="/source/s?defs=lastFullTs&amp;project=rtmp_client">lastFullTs</a>);
<a class="l" name="364" href="#364">364</a>		<b>if</b> (<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getStreamId&amp;project=rtmp_client">getStreamId</a>() != <a href="/source/s?defs=lastHeader&amp;project=rtmp_client">lastHeader</a>.<a href="/source/s?defs=getStreamId&amp;project=rtmp_client">getStreamId</a>() || <a href="/source/s?defs=diff&amp;project=rtmp_client">diff</a> &lt; <span class="n">0</span> || <a href="/source/s?defs=timeSinceFullTs&amp;project=rtmp_client">timeSinceFullTs</a> &gt;= <span class="n">250</span>) {
<a class="l" name="365" href="#365">365</a>			<span class="c">// New header mark if header for another stream</span>
<a class="l" name="366" href="#366">366</a>			<a href="/source/s?defs=headerType&amp;project=rtmp_client">headerType</a> = <a href="/source/s?defs=HEADER_NEW&amp;project=rtmp_client">HEADER_NEW</a>;
<a class="l" name="367" href="#367">367</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>() != <a href="/source/s?defs=lastHeader&amp;project=rtmp_client">lastHeader</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>() || <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>() != <a href="/source/s?defs=lastHeader&amp;project=rtmp_client">lastHeader</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>()) {
<a class="l" name="368" href="#368">368</a>			<span class="c">// Same source header if last header data type or size differ</span>
<a class="l" name="369" href="#369">369</a>			<a href="/source/s?defs=headerType&amp;project=rtmp_client">headerType</a> = <a href="/source/s?defs=HEADER_SAME_SOURCE&amp;project=rtmp_client">HEADER_SAME_SOURCE</a>;
<a class="hl" name="370" href="#370">370</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>() != <a href="/source/s?defs=lastHeader&amp;project=rtmp_client">lastHeader</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>() + <a href="/source/s?defs=lastHeader&amp;project=rtmp_client">lastHeader</a>.<a href="/source/s?defs=getTimerDelta&amp;project=rtmp_client">getTimerDelta</a>()) {
<a class="l" name="371" href="#371">371</a>			<span class="c">// Timer change marker if there's time gap between header time stamps</span>
<a class="l" name="372" href="#372">372</a>			<a href="/source/s?defs=headerType&amp;project=rtmp_client">headerType</a> = <a href="/source/s?defs=HEADER_TIMER_CHANGE&amp;project=rtmp_client">HEADER_TIMER_CHANGE</a>;
<a class="l" name="373" href="#373">373</a>		} <b>else</b> {
<a class="l" name="374" href="#374">374</a>			<span class="c">// Continue encoding</span>
<a class="l" name="375" href="#375">375</a>			<a href="/source/s?defs=headerType&amp;project=rtmp_client">headerType</a> = <a href="/source/s?defs=HEADER_CONTINUE&amp;project=rtmp_client">HEADER_CONTINUE</a>;
<a class="l" name="376" href="#376">376</a>		}
<a class="l" name="377" href="#377">377</a>		<b>return</b> <a href="/source/s?defs=headerType&amp;project=rtmp_client">headerType</a>;
<a class="l" name="378" href="#378">378</a>	}
<a class="l" name="379" href="#379">379</a>
<a class="hl" name="380" href="#380">380</a>	<span class="c">/**
<a class="l" name="381" href="#381">381</a>	 * Calculate number of bytes necessary to encode the header.
<a class="l" name="382" href="#382">382</a>	 *
<a class="l" name="383" href="#383">383</a>	 * <strong>@param</strong> <em>rtmp</em>        The protocol state
<a class="l" name="384" href="#384">384</a>	 * <strong>@param</strong> <em>header</em>      RTMP message header
<a class="l" name="385" href="#385">385</a>	 * <strong>@param</strong> <em>lastHeader</em>  Previous header
<a class="l" name="386" href="#386">386</a>	 * <strong>@return</strong>            Calculated size
<a class="l" name="387" href="#387">387</a>	 */</span>
<a class="l" name="388" href="#388">388</a>	<b>private</b> <b>int</b> <a class="xmt" name="calculateHeaderSize"/><a href="/source/s?refs=calculateHeaderSize&amp;project=rtmp_client" class="xmt">calculateHeaderSize</a>(<b>final</b> <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>, <b>final</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xa">header</a>, <b>final</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="lastHeader"/><a href="/source/s?refs=lastHeader&amp;project=rtmp_client" class="xa">lastHeader</a>) {
<a class="l" name="389" href="#389">389</a>		<b>final</b> <b>byte</b> <a href="/source/s?defs=headerType&amp;project=rtmp_client">headerType</a> = <a class="d" href="#getHeaderType">getHeaderType</a>(<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>, <a href="/source/s?defs=lastHeader&amp;project=rtmp_client">lastHeader</a>);
<a class="hl" name="390" href="#390">390</a>		<b>int</b> <a href="/source/s?defs=channelIdAdd&amp;project=rtmp_client">channelIdAdd</a> = <span class="n">0</span>;
<a class="l" name="391" href="#391">391</a>		<b>int</b> <a class="d" href="#channelId">channelId</a> = <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getChannelId&amp;project=rtmp_client">getChannelId</a>();
<a class="l" name="392" href="#392">392</a>		<b>if</b> (<a class="d" href="#channelId">channelId</a> &gt; <span class="n">320</span>) {
<a class="l" name="393" href="#393">393</a>			<a href="/source/s?defs=channelIdAdd&amp;project=rtmp_client">channelIdAdd</a> = <span class="n">2</span>;
<a class="l" name="394" href="#394">394</a>		} <b>else</b> <b>if</b> (<a class="d" href="#channelId">channelId</a> &gt; <span class="n">63</span>) {
<a class="l" name="395" href="#395">395</a>			<a href="/source/s?defs=channelIdAdd&amp;project=rtmp_client">channelIdAdd</a> = <span class="n">1</span>;
<a class="l" name="396" href="#396">396</a>		}
<a class="l" name="397" href="#397">397</a>		<b>return</b> <a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=getHeaderLength&amp;project=rtmp_client">getHeaderLength</a>(<a href="/source/s?defs=headerType&amp;project=rtmp_client">headerType</a>) + <a href="/source/s?defs=channelIdAdd&amp;project=rtmp_client">channelIdAdd</a>;
<a class="l" name="398" href="#398">398</a>	}
<a class="l" name="399" href="#399">399</a>
<a class="hl" name="400" href="#400">400</a>	<span class="c">/**
<a class="l" name="401" href="#401">401</a>	 * Encode RTMP header.
<a class="l" name="402" href="#402">402</a>	 * <strong>@param</strong> <em>rtmp</em>        The protocol state
<a class="l" name="403" href="#403">403</a>	 * <strong>@param</strong> <em>header</em>      RTMP message header
<a class="l" name="404" href="#404">404</a>	 * <strong>@param</strong> <em>lastHeader</em>  Previous header
<a class="l" name="405" href="#405">405</a>	 * <strong>@return</strong>            Encoded header data
<a class="l" name="406" href="#406">406</a>	 */</span>
<a class="l" name="407" href="#407">407</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeHeader"/><a href="/source/s?refs=encodeHeader&amp;project=rtmp_client" class="xmt">encodeHeader</a>(<b>final</b> <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>, <b>final</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xa">header</a>, <b>final</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="lastHeader"/><a href="/source/s?refs=lastHeader&amp;project=rtmp_client" class="xa">lastHeader</a>) {
<a class="l" name="408" href="#408">408</a>		<b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<a class="d" href="#calculateHeaderSize">calculateHeaderSize</a>(<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>, <a href="/source/s?defs=lastHeader&amp;project=rtmp_client">lastHeader</a>));
<a class="l" name="409" href="#409">409</a>		<a href="/source/s?defs=encodeHeader&amp;project=rtmp_client">encodeHeader</a>(<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>, <a href="/source/s?defs=lastHeader&amp;project=rtmp_client">lastHeader</a>, <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>);
<a class="hl" name="410" href="#410">410</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="411" href="#411">411</a>	}
<a class="l" name="412" href="#412">412</a>
<a class="l" name="413" href="#413">413</a>	<span class="c">/**
<a class="l" name="414" href="#414">414</a>	 * Encode RTMP header into given IoBuffer.
<a class="l" name="415" href="#415">415</a>	 *
<a class="l" name="416" href="#416">416</a>	 * <strong>@param</strong> <em>rtmp</em>        The protocol state
<a class="l" name="417" href="#417">417</a>	 * <strong>@param</strong> <em>header</em>      RTMP message header
<a class="l" name="418" href="#418">418</a>	 * <strong>@param</strong> <em>lastHeader</em>  Previous header
<a class="l" name="419" href="#419">419</a>	 * <strong>@param</strong> <em>buf</em>         Buffer to write encoded header to
<a class="hl" name="420" href="#420">420</a>	 */</span>
<a class="l" name="421" href="#421">421</a>	<b>public</b> <b>void</b> <a class="xmt" name="encodeHeader"/><a href="/source/s?refs=encodeHeader&amp;project=rtmp_client" class="xmt">encodeHeader</a>(<b>final</b> <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>, <b>final</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xa">header</a>, <b>final</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="lastHeader"/><a href="/source/s?refs=lastHeader&amp;project=rtmp_client" class="xa">lastHeader</a>, <b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="buf"/><a href="/source/s?refs=buf&amp;project=rtmp_client" class="xa">buf</a>) {
<a class="l" name="422" href="#422">422</a>		<b>final</b> <b>byte</b> <a href="/source/s?defs=headerType&amp;project=rtmp_client">headerType</a> = <a class="d" href="#getHeaderType">getHeaderType</a>(<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>, <a href="/source/s?defs=lastHeader&amp;project=rtmp_client">lastHeader</a>);
<a class="l" name="423" href="#423">423</a>		<a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=encodeHeaderByte&amp;project=rtmp_client">encodeHeaderByte</a>(<a class="d" href="#buf">buf</a>, <a href="/source/s?defs=headerType&amp;project=rtmp_client">headerType</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getChannelId&amp;project=rtmp_client">getChannelId</a>());
<a class="l" name="424" href="#424">424</a>
<a class="l" name="425" href="#425">425</a>		<b>final</b> <b>int</b> <a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a>;
<a class="l" name="426" href="#426">426</a>		<b>switch</b> (<a href="/source/s?defs=headerType&amp;project=rtmp_client">headerType</a>) {
<a class="l" name="427" href="#427">427</a>			<b>case</b> <a href="/source/s?defs=HEADER_NEW&amp;project=rtmp_client">HEADER_NEW</a>:
<a class="l" name="428" href="#428">428</a>				<a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a> = <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>();
<a class="l" name="429" href="#429">429</a>				<b>if</b> (<a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a> &lt; <span class="n">0</span> || <a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a> &gt;= <span class="n">0xffffff</span>) {
<a class="hl" name="430" href="#430">430</a>					<a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=writeMediumInt&amp;project=rtmp_client">writeMediumInt</a>(<a class="d" href="#buf">buf</a>, <span class="n">0xffffff</span>);
<a class="l" name="431" href="#431">431</a>				} <b>else</b> {
<a class="l" name="432" href="#432">432</a>					<a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=writeMediumInt&amp;project=rtmp_client">writeMediumInt</a>(<a class="d" href="#buf">buf</a>, <a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a>);
<a class="l" name="433" href="#433">433</a>				}
<a class="l" name="434" href="#434">434</a>				<a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=writeMediumInt&amp;project=rtmp_client">writeMediumInt</a>(<a class="d" href="#buf">buf</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>());
<a class="l" name="435" href="#435">435</a>				<a class="d" href="#buf">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>());
<a class="l" name="436" href="#436">436</a>				<a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=writeReverseInt&amp;project=rtmp_client">writeReverseInt</a>(<a class="d" href="#buf">buf</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getStreamId&amp;project=rtmp_client">getStreamId</a>());
<a class="l" name="437" href="#437">437</a>				<b>if</b> (<a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a> &lt; <span class="n">0</span> || <a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a> &gt;= <span class="n">0xffffff</span>) {
<a class="l" name="438" href="#438">438</a>					<a class="d" href="#buf">buf</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a>);
<a class="l" name="439" href="#439">439</a>				}
<a class="hl" name="440" href="#440">440</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setTimerBase&amp;project=rtmp_client">setTimerBase</a>(<a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a>);
<a class="l" name="441" href="#441">441</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setTimerDelta&amp;project=rtmp_client">setTimerDelta</a>(<span class="n">0</span>);
<a class="l" name="442" href="#442">442</a>				<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setLastFullTimestampWritten&amp;project=rtmp_client">setLastFullTimestampWritten</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getChannelId&amp;project=rtmp_client">getChannelId</a>(), <a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a>);
<a class="l" name="443" href="#443">443</a>				<b>break</b>;
<a class="l" name="444" href="#444">444</a>			<b>case</b> <a href="/source/s?defs=HEADER_SAME_SOURCE&amp;project=rtmp_client">HEADER_SAME_SOURCE</a>:
<a class="l" name="445" href="#445">445</a>				<a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a> = (<b>int</b>) <a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=diffTimestamps&amp;project=rtmp_client">diffTimestamps</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>(), <a href="/source/s?defs=lastHeader&amp;project=rtmp_client">lastHeader</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>());
<a class="l" name="446" href="#446">446</a>				<b>if</b> (<a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a> &lt; <span class="n">0</span> || <a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a> &gt;= <span class="n">0xffffff</span>) {
<a class="l" name="447" href="#447">447</a>					<a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=writeMediumInt&amp;project=rtmp_client">writeMediumInt</a>(<a class="d" href="#buf">buf</a>, <span class="n">0xffffff</span>);
<a class="l" name="448" href="#448">448</a>				} <b>else</b> {
<a class="l" name="449" href="#449">449</a>					<a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=writeMediumInt&amp;project=rtmp_client">writeMediumInt</a>(<a class="d" href="#buf">buf</a>, <a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a>);
<a class="hl" name="450" href="#450">450</a>				}
<a class="l" name="451" href="#451">451</a>				<a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=writeMediumInt&amp;project=rtmp_client">writeMediumInt</a>(<a class="d" href="#buf">buf</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>());
<a class="l" name="452" href="#452">452</a>				<a class="d" href="#buf">buf</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>());
<a class="l" name="453" href="#453">453</a>				<b>if</b> (<a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a> &lt; <span class="n">0</span> || <a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a> &gt;= <span class="n">0xffffff</span>) {
<a class="l" name="454" href="#454">454</a>					<a class="d" href="#buf">buf</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a>);
<a class="l" name="455" href="#455">455</a>				}
<a class="l" name="456" href="#456">456</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setTimerBase&amp;project=rtmp_client">setTimerBase</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>() - <a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a>);
<a class="l" name="457" href="#457">457</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setTimerDelta&amp;project=rtmp_client">setTimerDelta</a>(<a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a>);
<a class="l" name="458" href="#458">458</a>				<b>break</b>;
<a class="l" name="459" href="#459">459</a>			<b>case</b> <a href="/source/s?defs=HEADER_TIMER_CHANGE&amp;project=rtmp_client">HEADER_TIMER_CHANGE</a>:
<a class="hl" name="460" href="#460">460</a>				<a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a> = (<b>int</b>) <a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=diffTimestamps&amp;project=rtmp_client">diffTimestamps</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>(), <a href="/source/s?defs=lastHeader&amp;project=rtmp_client">lastHeader</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>());
<a class="l" name="461" href="#461">461</a>				<b>if</b> (<a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a> &lt; <span class="n">0</span> || <a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a> &gt;= <span class="n">0xffffff</span>) {
<a class="l" name="462" href="#462">462</a>					<a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=writeMediumInt&amp;project=rtmp_client">writeMediumInt</a>(<a class="d" href="#buf">buf</a>, <span class="n">0xffffff</span>);
<a class="l" name="463" href="#463">463</a>					<a class="d" href="#buf">buf</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a>);
<a class="l" name="464" href="#464">464</a>				} <b>else</b> {
<a class="l" name="465" href="#465">465</a>					<a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=writeMediumInt&amp;project=rtmp_client">writeMediumInt</a>(<a class="d" href="#buf">buf</a>, <a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a>);
<a class="l" name="466" href="#466">466</a>				}
<a class="l" name="467" href="#467">467</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setTimerBase&amp;project=rtmp_client">setTimerBase</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>() - <a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a>);
<a class="l" name="468" href="#468">468</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setTimerDelta&amp;project=rtmp_client">setTimerDelta</a>(<a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a>);
<a class="l" name="469" href="#469">469</a>				<b>break</b>;
<a class="hl" name="470" href="#470">470</a>			<b>case</b> <a href="/source/s?defs=HEADER_CONTINUE&amp;project=rtmp_client">HEADER_CONTINUE</a>:
<a class="l" name="471" href="#471">471</a>				<a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a> = (<b>int</b>) <a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=diffTimestamps&amp;project=rtmp_client">diffTimestamps</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>(), <a href="/source/s?defs=lastHeader&amp;project=rtmp_client">lastHeader</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>());
<a class="l" name="472" href="#472">472</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setTimerBase&amp;project=rtmp_client">setTimerBase</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>() - <a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a>);
<a class="l" name="473" href="#473">473</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setTimerDelta&amp;project=rtmp_client">setTimerDelta</a>(<a href="/source/s?defs=timer&amp;project=rtmp_client">timer</a>);
<a class="l" name="474" href="#474">474</a>				<b>break</b>;
<a class="l" name="475" href="#475">475</a>			<b>default</b>:
<a class="l" name="476" href="#476">476</a>				<b>break</b>;
<a class="l" name="477" href="#477">477</a>		}
<a class="l" name="478" href="#478">478</a><span class="c">//		log.trace("CHUNK, E, {}, {}", header, headerType);</span>
<a class="l" name="479" href="#479">479</a>	}
<a class="hl" name="480" href="#480">480</a>
<a class="l" name="481" href="#481">481</a>	<span class="c">/**
<a class="l" name="482" href="#482">482</a>	 * Encode message.
<a class="l" name="483" href="#483">483</a>	 *
<a class="l" name="484" href="#484">484</a>	 * <strong>@param</strong> <em>rtmp</em>        RTMP protocol state
<a class="l" name="485" href="#485">485</a>	 * <strong>@param</strong> <em>header</em>      RTMP message header
<a class="l" name="486" href="#486">486</a>	 * <strong>@param</strong> <em>message</em>     RTMP message (event)
<a class="l" name="487" href="#487">487</a>	 * <strong>@return</strong>            Encoded message data
<a class="l" name="488" href="#488">488</a>	 */</span>
<a class="l" name="489" href="#489">489</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeMessage"/><a href="/source/s?refs=encodeMessage&amp;project=rtmp_client" class="xmt">encodeMessage</a>(<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xa">header</a>, <a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a> <a class="xa" name="message"/><a href="/source/s?refs=message&amp;project=rtmp_client" class="xa">message</a>) {
<a class="hl" name="490" href="#490">490</a>		<a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a> <a href="/source/s?defs=call&amp;project=rtmp_client">call</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="491" href="#491">491</a>		<b>switch</b> (<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>()) {
<a class="l" name="492" href="#492">492</a>			<b>case</b> <a href="/source/s?defs=TYPE_CHUNK_SIZE&amp;project=rtmp_client">TYPE_CHUNK_SIZE</a>:
<a class="l" name="493" href="#493">493</a>				<b>return</b> <a class="d" href="#encodeChunkSize">encodeChunkSize</a>((<a href="/source/s?defs=ChunkSize&amp;project=rtmp_client">ChunkSize</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="494" href="#494">494</a>			<b>case</b> <a href="/source/s?defs=TYPE_INVOKE&amp;project=rtmp_client">TYPE_INVOKE</a>:
<a class="l" name="495" href="#495">495</a><span class="c">//				log.trace("Invoke {}", message);</span>
<a class="l" name="496" href="#496">496</a>				<a href="/source/s?defs=call&amp;project=rtmp_client">call</a> = ((<a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>).<a href="/source/s?defs=getCall&amp;project=rtmp_client">getCall</a>();
<a class="l" name="497" href="#497">497</a>				<b>if</b> (<a href="/source/s?defs=call&amp;project=rtmp_client">call</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="498" href="#498">498</a><span class="c">//					log.debug("{}", call.toString());</span>
<a class="l" name="499" href="#499">499</a>					<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a href="/source/s?defs=args&amp;project=rtmp_client">args</a> = <a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=getArguments&amp;project=rtmp_client">getArguments</a>();
<a class="hl" name="500" href="#500">500</a>					<b>if</b> (<a href="/source/s?defs=args&amp;project=rtmp_client">args</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a href="/source/s?defs=args&amp;project=rtmp_client">args</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> &gt; <span class="n">0</span>) {
<a class="l" name="501" href="#501">501</a>						<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=a0&amp;project=rtmp_client">a0</a> = <a href="/source/s?defs=args&amp;project=rtmp_client">args</a>[<span class="n">0</span>];
<a class="l" name="502" href="#502">502</a>						<b>if</b> (<a href="/source/s?defs=a0&amp;project=rtmp_client">a0</a> <b>instanceof</b> <a href="/source/s?defs=Status&amp;project=rtmp_client">Status</a>) {
<a class="l" name="503" href="#503">503</a>							<a href="/source/s?defs=Status&amp;project=rtmp_client">Status</a> <a href="/source/s?defs=status&amp;project=rtmp_client">status</a> = (<a href="/source/s?defs=Status&amp;project=rtmp_client">Status</a>) <a href="/source/s?defs=a0&amp;project=rtmp_client">a0</a>;
<a class="l" name="504" href="#504">504</a>							<span class="c">//code: NetStream.Seek.Notify</span>
<a class="l" name="505" href="#505">505</a>							<b>if</b> (<a href="/source/s?defs=StatusCodes&amp;project=rtmp_client">StatusCodes</a>.<a href="/source/s?defs=NS_SEEK_NOTIFY&amp;project=rtmp_client">NS_SEEK_NOTIFY</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=status&amp;project=rtmp_client">status</a>.<a href="/source/s?defs=getCode&amp;project=rtmp_client">getCode</a>())) {
<a class="l" name="506" href="#506">506</a>								<span class="c">//desc: Seeking 25000 (stream ID: 1).</span>
<a class="l" name="507" href="#507">507</a>								<b>int</b> <a href="/source/s?defs=seekTime&amp;project=rtmp_client">seekTime</a> = <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=status&amp;project=rtmp_client">status</a>.<a href="/source/s?defs=getDescription&amp;project=rtmp_client">getDescription</a>().<a href="/source/s?defs=split&amp;project=rtmp_client">split</a>(<span class="s">" "</span>)[<span class="n">1</span>]);
<a class="l" name="508" href="#508">508</a><span class="c">//								log.trace("Seek to time: {}", seekTime);</span>
<a class="l" name="509" href="#509">509</a>								<span class="c">//audio and video channels</span>
<a class="hl" name="510" href="#510">510</a>								<b>int</b>[] <a href="/source/s?defs=channels&amp;project=rtmp_client">channels</a> = <b>new</b> <b>int</b>[] { <span class="n">5</span>, <span class="n">6</span> };
<a class="l" name="511" href="#511">511</a>								<span class="c">//if its a seek notification, reset the "mapping" for audio (5) and video (6)</span>
<a class="l" name="512" href="#512">512</a>								<b>for</b> (<b>int</b> <a class="d" href="#channelId">channelId</a> : <a href="/source/s?defs=channels&amp;project=rtmp_client">channels</a>) {
<a class="l" name="513" href="#513">513</a>									<a href="/source/s?defs=LiveTimestampMapping&amp;project=rtmp_client">LiveTimestampMapping</a> <a href="/source/s?defs=mapping&amp;project=rtmp_client">mapping</a> = <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getLastTimestampMapping&amp;project=rtmp_client">getLastTimestampMapping</a>(<a class="d" href="#channelId">channelId</a>);
<a class="l" name="514" href="#514">514</a>									<b>if</b> (<a href="/source/s?defs=mapping&amp;project=rtmp_client">mapping</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="515" href="#515">515</a>										<b>long</b> <a href="/source/s?defs=timestamp&amp;project=rtmp_client">timestamp</a> = <a href="/source/s?defs=mapping&amp;project=rtmp_client">mapping</a>.<a href="/source/s?defs=getClockStartTime&amp;project=rtmp_client">getClockStartTime</a>() + (<a href="/source/s?defs=seekTime&amp;project=rtmp_client">seekTime</a> &amp; <span class="n">0xFFFFFFFFL</span>);
<a class="l" name="516" href="#516">516</a><span class="c">//										log.trace("Setting last stream time to: {}", timestamp);</span>
<a class="l" name="517" href="#517">517</a>										<a href="/source/s?defs=mapping&amp;project=rtmp_client">mapping</a>.<a href="/source/s?defs=setLastStreamTime&amp;project=rtmp_client">setLastStreamTime</a>(<a href="/source/s?defs=timestamp&amp;project=rtmp_client">timestamp</a>);
<a class="l" name="518" href="#518">518</a>									} <b>else</b> {
<a class="l" name="519" href="#519">519</a>										<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"No ts mapping for channel id: {}"</span>, <a class="d" href="#channelId">channelId</a>);
<a class="hl" name="520" href="#520">520</a>									}
<a class="l" name="521" href="#521">521</a>								}
<a class="l" name="522" href="#522">522</a>							}
<a class="l" name="523" href="#523">523</a>						}
<a class="l" name="524" href="#524">524</a>					}
<a class="l" name="525" href="#525">525</a>				}
<a class="l" name="526" href="#526">526</a>				<b>return</b> <a class="d" href="#encodeInvoke">encodeInvoke</a>((<a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="527" href="#527">527</a>			<b>case</b> <a href="/source/s?defs=TYPE_NOTIFY&amp;project=rtmp_client">TYPE_NOTIFY</a>:
<a class="l" name="528" href="#528">528</a><span class="c">//				log.trace("Notify {}", message);</span>
<a class="l" name="529" href="#529">529</a>				<a href="/source/s?defs=call&amp;project=rtmp_client">call</a> = ((<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>).<a href="/source/s?defs=getCall&amp;project=rtmp_client">getCall</a>();
<a class="hl" name="530" href="#530">530</a>				<b>if</b> (<a href="/source/s?defs=call&amp;project=rtmp_client">call</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="531" href="#531">531</a>					<b>return</b> <a class="d" href="#encodeStreamMetadata">encodeStreamMetadata</a>((<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="532" href="#532">532</a>				} <b>else</b> {
<a class="l" name="533" href="#533">533</a>					<b>return</b> <a class="d" href="#encodeNotify">encodeNotify</a>((<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="534" href="#534">534</a>				}
<a class="l" name="535" href="#535">535</a>			<b>case</b> <a href="/source/s?defs=TYPE_PING&amp;project=rtmp_client">TYPE_PING</a>:
<a class="l" name="536" href="#536">536</a>				<b>return</b> <a class="d" href="#encodePing">encodePing</a>((<a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="537" href="#537">537</a>			<b>case</b> <a href="/source/s?defs=TYPE_BYTES_READ&amp;project=rtmp_client">TYPE_BYTES_READ</a>:
<a class="l" name="538" href="#538">538</a>				<b>return</b> <a class="d" href="#encodeBytesRead">encodeBytesRead</a>((<a href="/source/s?defs=BytesRead&amp;project=rtmp_client">BytesRead</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="539" href="#539">539</a>			<b>case</b> <a href="/source/s?defs=TYPE_AGGREGATE&amp;project=rtmp_client">TYPE_AGGREGATE</a>:
<a class="hl" name="540" href="#540">540</a><span class="c">//				log.trace("Encode aggregate message");</span>
<a class="l" name="541" href="#541">541</a>				<b>return</b> <a class="d" href="#encodeAggregate">encodeAggregate</a>((<a href="/source/s?defs=Aggregate&amp;project=rtmp_client">Aggregate</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="542" href="#542">542</a>			<b>case</b> <a href="/source/s?defs=TYPE_AUDIO_DATA&amp;project=rtmp_client">TYPE_AUDIO_DATA</a>:
<a class="l" name="543" href="#543">543</a><span class="c">//				log.trace("Encode audio message");</span>
<a class="l" name="544" href="#544">544</a>
<a class="l" name="545" href="#545">545</a>				<b>return</b> <a class="d" href="#encodeAudioData">encodeAudioData</a>((<a href="/source/s?defs=AudioData&amp;project=rtmp_client">AudioData</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="546" href="#546">546</a>			<b>case</b> <a href="/source/s?defs=TYPE_VIDEO_DATA&amp;project=rtmp_client">TYPE_VIDEO_DATA</a>:
<a class="l" name="547" href="#547">547</a><span class="c">//				log.trace("Encode video message");</span>
<a class="l" name="548" href="#548">548</a>
<a class="l" name="549" href="#549">549</a>				<b>return</b> <a class="d" href="#encodeVideoData">encodeVideoData</a>((<a href="/source/s?defs=VideoData&amp;project=rtmp_client">VideoData</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="hl" name="550" href="#550">550</a>			<b>case</b> <a href="/source/s?defs=TYPE_FLEX_SHARED_OBJECT&amp;project=rtmp_client">TYPE_FLEX_SHARED_OBJECT</a>:
<a class="l" name="551" href="#551">551</a>				<b>return</b> <a class="d" href="#encodeFlexSharedObject">encodeFlexSharedObject</a>((<a href="/source/s?defs=ISharedObjectMessage&amp;project=rtmp_client">ISharedObjectMessage</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="552" href="#552">552</a>			<b>case</b> <a href="/source/s?defs=TYPE_SHARED_OBJECT&amp;project=rtmp_client">TYPE_SHARED_OBJECT</a>:
<a class="l" name="553" href="#553">553</a>				<b>return</b> <a class="d" href="#encodeSharedObject">encodeSharedObject</a>((<a href="/source/s?defs=ISharedObjectMessage&amp;project=rtmp_client">ISharedObjectMessage</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="554" href="#554">554</a>			<b>case</b> <a href="/source/s?defs=TYPE_SERVER_BANDWIDTH&amp;project=rtmp_client">TYPE_SERVER_BANDWIDTH</a>:
<a class="l" name="555" href="#555">555</a>				<b>return</b> <a class="d" href="#encodeServerBW">encodeServerBW</a>((<a href="/source/s?defs=ServerBW&amp;project=rtmp_client">ServerBW</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="556" href="#556">556</a>			<b>case</b> <a href="/source/s?defs=TYPE_CLIENT_BANDWIDTH&amp;project=rtmp_client">TYPE_CLIENT_BANDWIDTH</a>:
<a class="l" name="557" href="#557">557</a>				<b>return</b> <a class="d" href="#encodeClientBW">encodeClientBW</a>((<a href="/source/s?defs=ClientBW&amp;project=rtmp_client">ClientBW</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="558" href="#558">558</a>			<b>case</b> <a href="/source/s?defs=TYPE_FLEX_MESSAGE&amp;project=rtmp_client">TYPE_FLEX_MESSAGE</a>:
<a class="l" name="559" href="#559">559</a>				<b>return</b> <a class="d" href="#encodeFlexMessage">encodeFlexMessage</a>((<a href="/source/s?defs=FlexMessage&amp;project=rtmp_client">FlexMessage</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="hl" name="560" href="#560">560</a>			<b>case</b> <a href="/source/s?defs=TYPE_FLEX_STREAM_SEND&amp;project=rtmp_client">TYPE_FLEX_STREAM_SEND</a>:
<a class="l" name="561" href="#561">561</a>				<b>return</b> <a class="d" href="#encodeFlexStreamSend">encodeFlexStreamSend</a>((<a href="/source/s?defs=FlexStreamSend&amp;project=rtmp_client">FlexStreamSend</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="562" href="#562">562</a>			<b>default</b>:
<a class="l" name="563" href="#563">563</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Unknown object type: {}"</span>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>());
<a class="l" name="564" href="#564">564</a>		}
<a class="l" name="565" href="#565">565</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="566" href="#566">566</a>	}
<a class="l" name="567" href="#567">567</a>
<a class="l" name="568" href="#568">568</a>	<span class="c">/**
<a class="l" name="569" href="#569">569</a>	 * Encode server-side bandwidth event.
<a class="hl" name="570" href="#570">570</a>	 *
<a class="l" name="571" href="#571">571</a>	 * <strong>@param</strong> <em>serverBW</em>    Server-side bandwidth event
<a class="l" name="572" href="#572">572</a>	 * <strong>@return</strong>            Encoded event data
<a class="l" name="573" href="#573">573</a>	 */</span>
<a class="l" name="574" href="#574">574</a>	<b>private</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeServerBW"/><a href="/source/s?refs=encodeServerBW&amp;project=rtmp_client" class="xmt">encodeServerBW</a>(<a href="/source/s?defs=ServerBW&amp;project=rtmp_client">ServerBW</a> <a class="xa" name="serverBW"/><a href="/source/s?refs=serverBW&amp;project=rtmp_client" class="xa">serverBW</a>) {
<a class="l" name="575" href="#575">575</a>		<b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">4</span>);
<a class="l" name="576" href="#576">576</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a class="d" href="#serverBW">serverBW</a>.<a href="/source/s?defs=getBandwidth&amp;project=rtmp_client">getBandwidth</a>());
<a class="l" name="577" href="#577">577</a>		<b>return</b> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>;
<a class="l" name="578" href="#578">578</a>	}
<a class="l" name="579" href="#579">579</a>
<a class="hl" name="580" href="#580">580</a>	<span class="c">/**
<a class="l" name="581" href="#581">581</a>	 * Encode client-side bandwidth event.
<a class="l" name="582" href="#582">582</a>	 *
<a class="l" name="583" href="#583">583</a>	 * <strong>@param</strong> <em>clientBW</em>    Client-side bandwidth event
<a class="l" name="584" href="#584">584</a>	 * <strong>@return</strong>            Encoded event data
<a class="l" name="585" href="#585">585</a>	 */</span>
<a class="l" name="586" href="#586">586</a>	<b>private</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeClientBW"/><a href="/source/s?refs=encodeClientBW&amp;project=rtmp_client" class="xmt">encodeClientBW</a>(<a href="/source/s?defs=ClientBW&amp;project=rtmp_client">ClientBW</a> <a class="xa" name="clientBW"/><a href="/source/s?refs=clientBW&amp;project=rtmp_client" class="xa">clientBW</a>) {
<a class="l" name="587" href="#587">587</a>		<b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">5</span>);
<a class="l" name="588" href="#588">588</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a class="d" href="#clientBW">clientBW</a>.<a href="/source/s?defs=getBandwidth&amp;project=rtmp_client">getBandwidth</a>());
<a class="l" name="589" href="#589">589</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#clientBW">clientBW</a>.<a href="/source/s?defs=getValue2&amp;project=rtmp_client">getValue2</a>());
<a class="hl" name="590" href="#590">590</a>		<b>return</b> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>;
<a class="l" name="591" href="#591">591</a>	}
<a class="l" name="592" href="#592">592</a>
<a class="l" name="593" href="#593">593</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="594" href="#594">594</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeChunkSize"/><a href="/source/s?refs=encodeChunkSize&amp;project=rtmp_client" class="xmt">encodeChunkSize</a>(<a href="/source/s?defs=ChunkSize&amp;project=rtmp_client">ChunkSize</a> <a class="xa" name="chunkSize"/><a href="/source/s?refs=chunkSize&amp;project=rtmp_client" class="xa">chunkSize</a>) {
<a class="l" name="595" href="#595">595</a>		<b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">4</span>);
<a class="l" name="596" href="#596">596</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a class="d" href="#chunkSize">chunkSize</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>());
<a class="l" name="597" href="#597">597</a>		<b>return</b> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>;
<a class="l" name="598" href="#598">598</a>	}
<a class="l" name="599" href="#599">599</a>
<a class="hl" name="600" href="#600">600</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="601" href="#601">601</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeFlexSharedObject"/><a href="/source/s?refs=encodeFlexSharedObject&amp;project=rtmp_client" class="xmt">encodeFlexSharedObject</a>(<a href="/source/s?defs=ISharedObjectMessage&amp;project=rtmp_client">ISharedObjectMessage</a> <a class="xa" name="so"/><a href="/source/s?refs=so&amp;project=rtmp_client" class="xa">so</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>) {
<a class="l" name="602" href="#602">602</a>		<b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">128</span>);
<a class="l" name="603" href="#603">603</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="604" href="#604">604</a>		<span class="c">// TODO: also support sending of AMF3 encoded data</span>
<a class="l" name="605" href="#605">605</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) <span class="n">0x00</span>);
<a class="l" name="606" href="#606">606</a>		<a class="d" href="#doEncodeSharedObject">doEncodeSharedObject</a>(<a href="/source/s?defs=so&amp;project=rtmp_client">so</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>, <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>);
<a class="l" name="607" href="#607">607</a>		<b>return</b> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>;
<a class="l" name="608" href="#608">608</a>	}
<a class="l" name="609" href="#609">609</a>
<a class="hl" name="610" href="#610">610</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="611" href="#611">611</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeSharedObject"/><a href="/source/s?refs=encodeSharedObject&amp;project=rtmp_client" class="xmt">encodeSharedObject</a>(<a href="/source/s?defs=ISharedObjectMessage&amp;project=rtmp_client">ISharedObjectMessage</a> <a class="xa" name="so"/><a href="/source/s?refs=so&amp;project=rtmp_client" class="xa">so</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>) {
<a class="l" name="612" href="#612">612</a>		<b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">128</span>);
<a class="l" name="613" href="#613">613</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="614" href="#614">614</a>		<a class="d" href="#doEncodeSharedObject">doEncodeSharedObject</a>(<a href="/source/s?defs=so&amp;project=rtmp_client">so</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>, <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>);
<a class="l" name="615" href="#615">615</a>		<b>return</b> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>;
<a class="l" name="616" href="#616">616</a>	}
<a class="l" name="617" href="#617">617</a>
<a class="l" name="618" href="#618">618</a>	<span class="c">/**
<a class="l" name="619" href="#619">619</a>	 * Perform the actual encoding of the shared object contents.
<a class="hl" name="620" href="#620">620</a>	 *
<a class="l" name="621" href="#621">621</a>	 * <strong>@param</strong> <em>so</em> shared object
<a class="l" name="622" href="#622">622</a>	 * <strong>@param</strong> <em>rtmp</em> rtmp
<a class="l" name="623" href="#623">623</a>	 * <strong>@param</strong> <em>out</em> output buffer
<a class="l" name="624" href="#624">624</a>	 */</span>
<a class="l" name="625" href="#625">625</a>	<b>public</b> <b>void</b> <a class="xmt" name="doEncodeSharedObject"/><a href="/source/s?refs=doEncodeSharedObject&amp;project=rtmp_client" class="xmt">doEncodeSharedObject</a>(<a href="/source/s?defs=ISharedObjectMessage&amp;project=rtmp_client">ISharedObjectMessage</a> <a class="xa" name="so"/><a href="/source/s?refs=so&amp;project=rtmp_client" class="xa">so</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>, <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>) {
<a class="l" name="626" href="#626">626</a>		<b>final</b> <a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a> <a href="/source/s?defs=output&amp;project=rtmp_client">output</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>);
<a class="l" name="627" href="#627">627</a>
<a class="l" name="628" href="#628">628</a>		<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>.<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<a href="/source/s?defs=so&amp;project=rtmp_client">so</a>.<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>());
<a class="l" name="629" href="#629">629</a>		<span class="c">// SO version</span>
<a class="hl" name="630" href="#630">630</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=so&amp;project=rtmp_client">so</a>.<a href="/source/s?defs=getVersion&amp;project=rtmp_client">getVersion</a>());
<a class="l" name="631" href="#631">631</a>		<span class="c">// Encoding (this always seems to be 2 for persistent shared objects)</span>
<a class="l" name="632" href="#632">632</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=so&amp;project=rtmp_client">so</a>.<a href="/source/s?defs=isPersistent&amp;project=rtmp_client">isPersistent</a>() ? <span class="n">2</span> : <span class="n">0</span>);
<a class="l" name="633" href="#633">633</a>		<span class="c">// unknown field</span>
<a class="l" name="634" href="#634">634</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<span class="n">0</span>);
<a class="l" name="635" href="#635">635</a>
<a class="l" name="636" href="#636">636</a>		<b>int</b> <a href="/source/s?defs=mark&amp;project=rtmp_client">mark</a>, <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>;
<a class="l" name="637" href="#637">637</a>
<a class="l" name="638" href="#638">638</a>		<b>for</b> (<a href="/source/s?defs=ISharedObjectEvent&amp;project=rtmp_client">ISharedObjectEvent</a> <a href="/source/s?defs=event&amp;project=rtmp_client">event</a> : <a href="/source/s?defs=so&amp;project=rtmp_client">so</a>.<a href="/source/s?defs=getEvents&amp;project=rtmp_client">getEvents</a>()) {
<a class="l" name="639" href="#639">639</a>			<b>byte</b> <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <a href="/source/s?defs=SharedObjectTypeMapping&amp;project=rtmp_client">SharedObjectTypeMapping</a>.<a href="/source/s?defs=toByte&amp;project=rtmp_client">toByte</a>(<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=getType&amp;project=rtmp_client">getType</a>());
<a class="hl" name="640" href="#640">640</a>
<a class="l" name="641" href="#641">641</a>			<b>switch</b> (<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=getType&amp;project=rtmp_client">getType</a>()) {
<a class="l" name="642" href="#642">642</a>				<b>case</b> <a href="/source/s?defs=SERVER_CONNECT&amp;project=rtmp_client">SERVER_CONNECT</a>:
<a class="l" name="643" href="#643">643</a>				<b>case</b> <a href="/source/s?defs=CLIENT_INITIAL_DATA&amp;project=rtmp_client">CLIENT_INITIAL_DATA</a>:
<a class="l" name="644" href="#644">644</a>				<b>case</b> <a href="/source/s?defs=CLIENT_CLEAR_DATA&amp;project=rtmp_client">CLIENT_CLEAR_DATA</a>:
<a class="l" name="645" href="#645">645</a>					<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>);
<a class="l" name="646" href="#646">646</a>					<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<span class="n">0</span>);
<a class="l" name="647" href="#647">647</a>					<b>break</b>;
<a class="l" name="648" href="#648">648</a>
<a class="l" name="649" href="#649">649</a>				<b>case</b> <a href="/source/s?defs=SERVER_DELETE_ATTRIBUTE&amp;project=rtmp_client">SERVER_DELETE_ATTRIBUTE</a>:
<a class="hl" name="650" href="#650">650</a>				<b>case</b> <a href="/source/s?defs=CLIENT_DELETE_DATA&amp;project=rtmp_client">CLIENT_DELETE_DATA</a>:
<a class="l" name="651" href="#651">651</a>				<b>case</b> <a href="/source/s?defs=CLIENT_UPDATE_ATTRIBUTE&amp;project=rtmp_client">CLIENT_UPDATE_ATTRIBUTE</a>:
<a class="l" name="652" href="#652">652</a>					<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>);
<a class="l" name="653" href="#653">653</a>					<a href="/source/s?defs=mark&amp;project=rtmp_client">mark</a> = <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>();
<a class="l" name="654" href="#654">654</a>					<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=skip&amp;project=rtmp_client">skip</a>(<span class="n">4</span>); <span class="c">// we will be back</span>
<a class="l" name="655" href="#655">655</a>					<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>.<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=getKey&amp;project=rtmp_client">getKey</a>());
<a class="l" name="656" href="#656">656</a>					<a href="/source/s?defs=len&amp;project=rtmp_client">len</a> = <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() - <a href="/source/s?defs=mark&amp;project=rtmp_client">mark</a> - <span class="n">4</span>;
<a class="l" name="657" href="#657">657</a>					<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=mark&amp;project=rtmp_client">mark</a>, <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>);
<a class="l" name="658" href="#658">658</a>					<b>break</b>;
<a class="l" name="659" href="#659">659</a>
<a class="hl" name="660" href="#660">660</a>				<b>case</b> <a href="/source/s?defs=SERVER_SET_ATTRIBUTE&amp;project=rtmp_client">SERVER_SET_ATTRIBUTE</a>:
<a class="l" name="661" href="#661">661</a>				<b>case</b> <a href="/source/s?defs=CLIENT_UPDATE_DATA&amp;project=rtmp_client">CLIENT_UPDATE_DATA</a>:
<a class="l" name="662" href="#662">662</a>					<b>if</b> (<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=getKey&amp;project=rtmp_client">getKey</a>() == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="663" href="#663">663</a>						<span class="c">// Update multiple attributes in one request</span>
<a class="l" name="664" href="#664">664</a>						<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;?, ?&gt; <a href="/source/s?defs=initialData&amp;project=rtmp_client">initialData</a> = (<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;?, ?&gt;) <a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=getValue&amp;project=rtmp_client">getValue</a>();
<a class="l" name="665" href="#665">665</a>						<b>for</b> (<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> o : <a href="/source/s?defs=initialData&amp;project=rtmp_client">initialData</a>.<a href="/source/s?defs=keySet&amp;project=rtmp_client">keySet</a>()) {
<a class="l" name="666" href="#666">666</a>
<a class="l" name="667" href="#667">667</a>							<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>);
<a class="l" name="668" href="#668">668</a>							<a href="/source/s?defs=mark&amp;project=rtmp_client">mark</a> = <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>();
<a class="l" name="669" href="#669">669</a>							<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=skip&amp;project=rtmp_client">skip</a>(<span class="n">4</span>); <span class="c">// we will be back</span>
<a class="hl" name="670" href="#670">670</a>
<a class="l" name="671" href="#671">671</a>							<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=key&amp;project=rtmp_client">key</a> = (<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>) o;
<a class="l" name="672" href="#672">672</a>							<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>.<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<a href="/source/s?defs=key&amp;project=rtmp_client">key</a>);
<a class="l" name="673" href="#673">673</a>							<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>, <a href="/source/s?defs=initialData&amp;project=rtmp_client">initialData</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=key&amp;project=rtmp_client">key</a>));
<a class="l" name="674" href="#674">674</a>
<a class="l" name="675" href="#675">675</a>							<a href="/source/s?defs=len&amp;project=rtmp_client">len</a> = <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() - <a href="/source/s?defs=mark&amp;project=rtmp_client">mark</a> - <span class="n">4</span>;
<a class="l" name="676" href="#676">676</a>							<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=mark&amp;project=rtmp_client">mark</a>, <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>);
<a class="l" name="677" href="#677">677</a>						}
<a class="l" name="678" href="#678">678</a>					} <b>else</b> {
<a class="l" name="679" href="#679">679</a>						<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>);
<a class="hl" name="680" href="#680">680</a>						<a href="/source/s?defs=mark&amp;project=rtmp_client">mark</a> = <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>();
<a class="l" name="681" href="#681">681</a>						<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=skip&amp;project=rtmp_client">skip</a>(<span class="n">4</span>); <span class="c">// we will be back</span>
<a class="l" name="682" href="#682">682</a>
<a class="l" name="683" href="#683">683</a>						<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>.<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=getKey&amp;project=rtmp_client">getKey</a>());
<a class="l" name="684" href="#684">684</a>						<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>, <a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=getValue&amp;project=rtmp_client">getValue</a>());
<a class="l" name="685" href="#685">685</a>
<a class="l" name="686" href="#686">686</a>						<a href="/source/s?defs=len&amp;project=rtmp_client">len</a> = <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() - <a href="/source/s?defs=mark&amp;project=rtmp_client">mark</a> - <span class="n">4</span>;
<a class="l" name="687" href="#687">687</a>						<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=mark&amp;project=rtmp_client">mark</a>, <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>);
<a class="l" name="688" href="#688">688</a>					}
<a class="l" name="689" href="#689">689</a>					<b>break</b>;
<a class="hl" name="690" href="#690">690</a>
<a class="l" name="691" href="#691">691</a>				<b>case</b> <a href="/source/s?defs=CLIENT_SEND_MESSAGE&amp;project=rtmp_client">CLIENT_SEND_MESSAGE</a>:
<a class="l" name="692" href="#692">692</a>				<b>case</b> <a href="/source/s?defs=SERVER_SEND_MESSAGE&amp;project=rtmp_client">SERVER_SEND_MESSAGE</a>:
<a class="l" name="693" href="#693">693</a>					<span class="c">// Send method name and value</span>
<a class="l" name="694" href="#694">694</a>					<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>);
<a class="l" name="695" href="#695">695</a>					<a href="/source/s?defs=mark&amp;project=rtmp_client">mark</a> = <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>();
<a class="l" name="696" href="#696">696</a>					<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=skip&amp;project=rtmp_client">skip</a>(<span class="n">4</span>);
<a class="l" name="697" href="#697">697</a>					<span class="c">// Serialize name of the handler to call...</span>
<a class="l" name="698" href="#698">698</a>					<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>, <a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=getKey&amp;project=rtmp_client">getKey</a>());
<a class="l" name="699" href="#699">699</a>					<span class="c">// ...and the arguments</span>
<a class="hl" name="700" href="#700">700</a>					<b>for</b> (<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=arg&amp;project=rtmp_client">arg</a> : (<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;?&gt;) <a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=getValue&amp;project=rtmp_client">getValue</a>()) {
<a class="l" name="701" href="#701">701</a>						<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>, <a href="/source/s?defs=arg&amp;project=rtmp_client">arg</a>);
<a class="l" name="702" href="#702">702</a>					}
<a class="l" name="703" href="#703">703</a>					<a href="/source/s?defs=len&amp;project=rtmp_client">len</a> = <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() - <a href="/source/s?defs=mark&amp;project=rtmp_client">mark</a> - <span class="n">4</span>;
<a class="l" name="704" href="#704">704</a>					<span class="c">//log.debug(len);</span>
<a class="l" name="705" href="#705">705</a>					<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=mark&amp;project=rtmp_client">mark</a>, <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>);
<a class="l" name="706" href="#706">706</a>					<span class="c">//log.info(out.getHexDump());</span>
<a class="l" name="707" href="#707">707</a>					<b>break</b>;
<a class="l" name="708" href="#708">708</a>
<a class="l" name="709" href="#709">709</a>				<b>case</b> <a href="/source/s?defs=CLIENT_STATUS&amp;project=rtmp_client">CLIENT_STATUS</a>:
<a class="hl" name="710" href="#710">710</a>					<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>);
<a class="l" name="711" href="#711">711</a>					<b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=status&amp;project=rtmp_client">status</a> = <a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=getKey&amp;project=rtmp_client">getKey</a>();
<a class="l" name="712" href="#712">712</a>					<b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = (<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>) <a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=getValue&amp;project=rtmp_client">getValue</a>();
<a class="l" name="713" href="#713">713</a>					<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>() + <a href="/source/s?defs=status&amp;project=rtmp_client">status</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>() + <span class="n">4</span>);
<a class="l" name="714" href="#714">714</a>					<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>.<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="715" href="#715">715</a>					<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>.<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<a href="/source/s?defs=status&amp;project=rtmp_client">status</a>);
<a class="l" name="716" href="#716">716</a>					<b>break</b>;
<a class="l" name="717" href="#717">717</a>
<a class="l" name="718" href="#718">718</a>				<b>default</b>:
<a class="l" name="719" href="#719">719</a>					<span class="c">//log.error("Unknown event " + event.getType());</span>
<a class="hl" name="720" href="#720">720</a>					<span class="c">// XXX: come back here, need to make this work in server or client mode</span>
<a class="l" name="721" href="#721">721</a>					<span class="c">// talk to joachim about this part.</span>
<a class="l" name="722" href="#722">722</a>					<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>);
<a class="l" name="723" href="#723">723</a>					<a href="/source/s?defs=mark&amp;project=rtmp_client">mark</a> = <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>();
<a class="l" name="724" href="#724">724</a>					<span class="c">//out.putInt(0);</span>
<a class="l" name="725" href="#725">725</a>					<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=skip&amp;project=rtmp_client">skip</a>(<span class="n">4</span>); <span class="c">// we will be back</span>
<a class="l" name="726" href="#726">726</a>					<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>.<a href="/source/s?defs=putString&amp;project=rtmp_client">putString</a>(<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=getKey&amp;project=rtmp_client">getKey</a>());
<a class="l" name="727" href="#727">727</a>					<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>, <a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=getValue&amp;project=rtmp_client">getValue</a>());
<a class="l" name="728" href="#728">728</a>					<a href="/source/s?defs=len&amp;project=rtmp_client">len</a> = <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() - <a href="/source/s?defs=mark&amp;project=rtmp_client">mark</a> - <span class="n">4</span>;
<a class="l" name="729" href="#729">729</a>					<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a href="/source/s?defs=mark&amp;project=rtmp_client">mark</a>, <a href="/source/s?defs=len&amp;project=rtmp_client">len</a>);
<a class="hl" name="730" href="#730">730</a>					<b>break</b>;
<a class="l" name="731" href="#731">731</a>
<a class="l" name="732" href="#732">732</a>			}
<a class="l" name="733" href="#733">733</a>		}
<a class="l" name="734" href="#734">734</a>	}
<a class="l" name="735" href="#735">735</a>
<a class="l" name="736" href="#736">736</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="737" href="#737">737</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeNotify"/><a href="/source/s?refs=encodeNotify&amp;project=rtmp_client" class="xmt">encodeNotify</a>(<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a> <a class="xa" name="notify"/><a href="/source/s?refs=notify&amp;project=rtmp_client" class="xa">notify</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>) {
<a class="l" name="738" href="#738">738</a>		<b>return</b> <a href="/source/s?defs=encodeNotifyOrInvoke&amp;project=rtmp_client">encodeNotifyOrInvoke</a>(<a class="d" href="#notify">notify</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="739" href="#739">739</a>	}
<a class="hl" name="740" href="#740">740</a>
<a class="l" name="741" href="#741">741</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="742" href="#742">742</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeInvoke"/><a href="/source/s?refs=encodeInvoke&amp;project=rtmp_client" class="xmt">encodeInvoke</a>(<a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a> <a class="xa" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xa">invoke</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>) {
<a class="l" name="743" href="#743">743</a>		<b>return</b> <a href="/source/s?defs=encodeNotifyOrInvoke&amp;project=rtmp_client">encodeNotifyOrInvoke</a>(<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="744" href="#744">744</a>	}
<a class="l" name="745" href="#745">745</a>
<a class="l" name="746" href="#746">746</a>	<span class="c">/**
<a class="l" name="747" href="#747">747</a>	 * Encode notification event.
<a class="l" name="748" href="#748">748</a>	 *
<a class="l" name="749" href="#749">749</a>	 * <strong>@param</strong> <em>invoke</em>            Notification event
<a class="hl" name="750" href="#750">750</a>	 * <strong>@return</strong>                  Encoded event data
<a class="l" name="751" href="#751">751</a>	 */</span>
<a class="l" name="752" href="#752">752</a>	<b>protected</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeNotifyOrInvoke"/><a href="/source/s?refs=encodeNotifyOrInvoke&amp;project=rtmp_client" class="xmt">encodeNotifyOrInvoke</a>(<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a> <a class="xa" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xa">invoke</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>) {
<a class="l" name="753" href="#753">753</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">1024</span>);
<a class="l" name="754" href="#754">754</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="755" href="#755">755</a>		<a href="/source/s?defs=encodeNotifyOrInvoke&amp;project=rtmp_client">encodeNotifyOrInvoke</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>, <a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="756" href="#756">756</a>		<b>return</b> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>;
<a class="l" name="757" href="#757">757</a>	}
<a class="l" name="758" href="#758">758</a>
<a class="l" name="759" href="#759">759</a>	<span class="c">/**
<a class="hl" name="760" href="#760">760</a>	 * Encode notification event and fill given byte buffer.
<a class="l" name="761" href="#761">761</a>	 *
<a class="l" name="762" href="#762">762</a>	 * <strong>@param</strong> <em>out</em>               Byte buffer to fill
<a class="l" name="763" href="#763">763</a>	 * <strong>@param</strong> <em>invoke</em>            Notification event
<a class="l" name="764" href="#764">764</a>	 */</span>
<a class="l" name="765" href="#765">765</a>	<b>protected</b> <b>void</b> <a class="xmt" name="encodeNotifyOrInvoke"/><a href="/source/s?refs=encodeNotifyOrInvoke&amp;project=rtmp_client" class="xmt">encodeNotifyOrInvoke</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>, <a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a> <a class="xa" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xa">invoke</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>) {
<a class="l" name="766" href="#766">766</a>		<span class="c">// TODO: tidy up here</span>
<a class="l" name="767" href="#767">767</a>		<span class="c">// log.debug("Encode invoke");</span>
<a class="l" name="768" href="#768">768</a>		<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a> <a href="/source/s?defs=output&amp;project=rtmp_client">output</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>);
<a class="l" name="769" href="#769">769</a>		<b>final</b> <a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a> <a href="/source/s?defs=call&amp;project=rtmp_client">call</a> = <a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=getCall&amp;project=rtmp_client">getCall</a>();
<a class="hl" name="770" href="#770">770</a>		<b>final</b> <b>boolean</b> <a href="/source/s?defs=isPending&amp;project=rtmp_client">isPending</a> = (<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=getStatus&amp;project=rtmp_client">getStatus</a>() == <a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>.<a href="/source/s?defs=STATUS_PENDING&amp;project=rtmp_client">STATUS_PENDING</a>);
<a class="l" name="771" href="#771">771</a><span class="c">//		log.debug("Call: {} pending: {}", call, isPending);</span>
<a class="l" name="772" href="#772">772</a>		<b>if</b> (!<a href="/source/s?defs=isPending&amp;project=rtmp_client">isPending</a>) {
<a class="l" name="773" href="#773">773</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Call has been executed, send result"</span>);
<a class="l" name="774" href="#774">774</a>			<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>, <a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=isSuccess&amp;project=rtmp_client">isSuccess</a>() ? <span class="s">"_result"</span> : <span class="s">"_error"</span>); <span class="c">// seems right</span>
<a class="l" name="775" href="#775">775</a>		} <b>else</b> {
<a class="l" name="776" href="#776">776</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"This is a pending call, send request"</span>);
<a class="l" name="777" href="#777">777</a>			<span class="c">// for request we need to use AMF3 for client mode</span>
<a class="l" name="778" href="#778">778</a>			<span class="c">// if the connection is AMF3</span>
<a class="l" name="779" href="#779">779</a>			<b>if</b> (<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getEncoding&amp;project=rtmp_client">getEncoding</a>() == <a href="/source/s?defs=Encoding&amp;project=rtmp_client">Encoding</a>.<a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a> &amp;&amp; <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getMode&amp;project=rtmp_client">getMode</a>() == <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=MODE_CLIENT&amp;project=rtmp_client">MODE_CLIENT</a>) {
<a class="hl" name="780" href="#780">780</a>				<a href="/source/s?defs=output&amp;project=rtmp_client">output</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>.<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>);
<a class="l" name="781" href="#781">781</a>			}
<a class="l" name="782" href="#782">782</a>			<b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=action&amp;project=rtmp_client">action</a> = (<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=getServiceName&amp;project=rtmp_client">getServiceName</a>() == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) ? <a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=getServiceMethodName&amp;project=rtmp_client">getServiceMethodName</a>() : <a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=getServiceName&amp;project=rtmp_client">getServiceName</a>() + <span class="s">'.'</span> + <a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=getServiceMethodName&amp;project=rtmp_client">getServiceMethodName</a>();
<a class="l" name="783" href="#783">783</a>			<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>, <a href="/source/s?defs=action&amp;project=rtmp_client">action</a>); <span class="c">// seems right</span>
<a class="l" name="784" href="#784">784</a>		}
<a class="l" name="785" href="#785">785</a>		<b>if</b> (<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a> <b>instanceof</b> <a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>) {
<a class="l" name="786" href="#786">786</a>			<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>, <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=getInvokeId&amp;project=rtmp_client">getInvokeId</a>()));
<a class="l" name="787" href="#787">787</a>			<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>, <a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=getConnectionParams&amp;project=rtmp_client">getConnectionParams</a>());
<a class="l" name="788" href="#788">788</a>		}
<a class="l" name="789" href="#789">789</a>
<a class="hl" name="790" href="#790">790</a>		<b>if</b> (<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=getServiceName&amp;project=rtmp_client">getServiceName</a>() == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <span class="s">"connect"</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=getServiceMethodName&amp;project=rtmp_client">getServiceMethodName</a>())) {
<a class="l" name="791" href="#791">791</a>			<span class="c">// Response to initial connect, always use AMF0</span>
<a class="l" name="792" href="#792">792</a>			<a href="/source/s?defs=output&amp;project=rtmp_client">output</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>);
<a class="l" name="793" href="#793">793</a>		} <b>else</b> {
<a class="l" name="794" href="#794">794</a>			<b>if</b> (<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getEncoding&amp;project=rtmp_client">getEncoding</a>() == <a href="/source/s?defs=Encoding&amp;project=rtmp_client">Encoding</a>.<a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>) {
<a class="l" name="795" href="#795">795</a>				<a href="/source/s?defs=output&amp;project=rtmp_client">output</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>.<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>);
<a class="l" name="796" href="#796">796</a>			} <b>else</b> {
<a class="l" name="797" href="#797">797</a>				<a href="/source/s?defs=output&amp;project=rtmp_client">output</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>);
<a class="l" name="798" href="#798">798</a>			}
<a class="l" name="799" href="#799">799</a>		}
<a class="hl" name="800" href="#800">800</a>
<a class="l" name="801" href="#801">801</a>		<b>if</b> (!<a href="/source/s?defs=isPending&amp;project=rtmp_client">isPending</a> &amp;&amp; (<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a> <b>instanceof</b> <a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>)) {
<a class="l" name="802" href="#802">802</a>			<a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a> <a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a> = (<a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a>) <a href="/source/s?defs=call&amp;project=rtmp_client">call</a>;
<a class="l" name="803" href="#803">803</a>			<b>if</b> (!<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=isSuccess&amp;project=rtmp_client">isSuccess</a>()) {
<a class="l" name="804" href="#804">804</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Call was not successful"</span>);
<a class="l" name="805" href="#805">805</a>				<a href="/source/s?defs=StatusObject&amp;project=rtmp_client">StatusObject</a> <a href="/source/s?defs=status&amp;project=rtmp_client">status</a> = <a class="d" href="#generateErrorResult">generateErrorResult</a>(<a href="/source/s?defs=StatusCodes&amp;project=rtmp_client">StatusCodes</a>.<a href="/source/s?defs=NC_CALL_FAILED&amp;project=rtmp_client">NC_CALL_FAILED</a>, <a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=getException&amp;project=rtmp_client">getException</a>());
<a class="l" name="806" href="#806">806</a>				<a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a>.<a href="/source/s?defs=setResult&amp;project=rtmp_client">setResult</a>(<a href="/source/s?defs=status&amp;project=rtmp_client">status</a>);
<a class="l" name="807" href="#807">807</a>			}
<a class="l" name="808" href="#808">808</a>			<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=res&amp;project=rtmp_client">res</a> = <a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a>.<a href="/source/s?defs=getResult&amp;project=rtmp_client">getResult</a>();
<a class="l" name="809" href="#809">809</a><span class="c">//			log.debug("Writing result: {}", res);</span>
<a class="hl" name="810" href="#810">810</a>			<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>, <a href="/source/s?defs=res&amp;project=rtmp_client">res</a>);
<a class="l" name="811" href="#811">811</a>		} <b>else</b> {
<a class="l" name="812" href="#812">812</a><span class="c">//			log.debug("Writing params");</span>
<a class="l" name="813" href="#813">813</a>			<b>final</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a href="/source/s?defs=args&amp;project=rtmp_client">args</a> = <a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=getArguments&amp;project=rtmp_client">getArguments</a>();
<a class="l" name="814" href="#814">814</a>			<b>if</b> (<a href="/source/s?defs=args&amp;project=rtmp_client">args</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="815" href="#815">815</a>				<b>for</b> (<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=element&amp;project=rtmp_client">element</a> : <a href="/source/s?defs=args&amp;project=rtmp_client">args</a>) {
<a class="l" name="816" href="#816">816</a>					<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>.<a href="/source/s?defs=serialize&amp;project=rtmp_client">serialize</a>(<a href="/source/s?defs=output&amp;project=rtmp_client">output</a>, <a href="/source/s?defs=element&amp;project=rtmp_client">element</a>);
<a class="l" name="817" href="#817">817</a>				}
<a class="l" name="818" href="#818">818</a>			}
<a class="l" name="819" href="#819">819</a>		}
<a class="hl" name="820" href="#820">820</a>
<a class="l" name="821" href="#821">821</a>		<b>if</b> (<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=getData&amp;project=rtmp_client">getData</a>() != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="822" href="#822">822</a>			<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="823" href="#823">823</a>			<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=getData&amp;project=rtmp_client">getData</a>());
<a class="l" name="824" href="#824">824</a>		}
<a class="l" name="825" href="#825">825</a>
<a class="l" name="826" href="#826">826</a>	}
<a class="l" name="827" href="#827">827</a>
<a class="l" name="828" href="#828">828</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="829" href="#829">829</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodePing"/><a href="/source/s?refs=encodePing&amp;project=rtmp_client" class="xmt">encodePing</a>(<a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a> <a class="xa" name="ping"/><a href="/source/s?refs=ping&amp;project=rtmp_client" class="xa">ping</a>) {
<a class="hl" name="830" href="#830">830</a>		<b>int</b> <a href="/source/s?defs=len&amp;project=rtmp_client">len</a> = <span class="n">6</span>;
<a class="l" name="831" href="#831">831</a>		<b>if</b> (<a class="d" href="#ping">ping</a>.<a href="/source/s?defs=getValue3&amp;project=rtmp_client">getValue3</a>() != <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>.<a href="/source/s?defs=UNDEFINED&amp;project=rtmp_client">UNDEFINED</a>) {
<a class="l" name="832" href="#832">832</a>			<a href="/source/s?defs=len&amp;project=rtmp_client">len</a> += <span class="n">4</span>;
<a class="l" name="833" href="#833">833</a>		}
<a class="l" name="834" href="#834">834</a>		<b>if</b> (<a class="d" href="#ping">ping</a>.<a href="/source/s?defs=getValue4&amp;project=rtmp_client">getValue4</a>() != <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>.<a href="/source/s?defs=UNDEFINED&amp;project=rtmp_client">UNDEFINED</a>) {
<a class="l" name="835" href="#835">835</a>			<a href="/source/s?defs=len&amp;project=rtmp_client">len</a> += <span class="n">4</span>;
<a class="l" name="836" href="#836">836</a>		}
<a class="l" name="837" href="#837">837</a>		<b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<a href="/source/s?defs=len&amp;project=rtmp_client">len</a>);
<a class="l" name="838" href="#838">838</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putShort&amp;project=rtmp_client">putShort</a>(<a class="d" href="#ping">ping</a>.<a href="/source/s?defs=getEventType&amp;project=rtmp_client">getEventType</a>());
<a class="l" name="839" href="#839">839</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a class="d" href="#ping">ping</a>.<a href="/source/s?defs=getValue2&amp;project=rtmp_client">getValue2</a>());
<a class="hl" name="840" href="#840">840</a>		<b>if</b> (<a class="d" href="#ping">ping</a>.<a href="/source/s?defs=getValue3&amp;project=rtmp_client">getValue3</a>() != <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>.<a href="/source/s?defs=UNDEFINED&amp;project=rtmp_client">UNDEFINED</a>) {
<a class="l" name="841" href="#841">841</a>			<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a class="d" href="#ping">ping</a>.<a href="/source/s?defs=getValue3&amp;project=rtmp_client">getValue3</a>());
<a class="l" name="842" href="#842">842</a>		}
<a class="l" name="843" href="#843">843</a>		<b>if</b> (<a class="d" href="#ping">ping</a>.<a href="/source/s?defs=getValue4&amp;project=rtmp_client">getValue4</a>() != <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>.<a href="/source/s?defs=UNDEFINED&amp;project=rtmp_client">UNDEFINED</a>) {
<a class="l" name="844" href="#844">844</a>			<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a class="d" href="#ping">ping</a>.<a href="/source/s?defs=getValue4&amp;project=rtmp_client">getValue4</a>());
<a class="l" name="845" href="#845">845</a>		}
<a class="l" name="846" href="#846">846</a>		<b>return</b> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>;
<a class="l" name="847" href="#847">847</a>	}
<a class="l" name="848" href="#848">848</a>
<a class="l" name="849" href="#849">849</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="850" href="#850">850</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeBytesRead"/><a href="/source/s?refs=encodeBytesRead&amp;project=rtmp_client" class="xmt">encodeBytesRead</a>(<a href="/source/s?defs=BytesRead&amp;project=rtmp_client">BytesRead</a> <a class="xa" name="bytesRead"/><a href="/source/s?refs=bytesRead&amp;project=rtmp_client" class="xa">bytesRead</a>) {
<a class="l" name="851" href="#851">851</a>		<b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">4</span>);
<a class="l" name="852" href="#852">852</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=putInt&amp;project=rtmp_client">putInt</a>(<a class="d" href="#bytesRead">bytesRead</a>.<a href="/source/s?defs=getBytesRead&amp;project=rtmp_client">getBytesRead</a>());
<a class="l" name="853" href="#853">853</a>		<b>return</b> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>;
<a class="l" name="854" href="#854">854</a>	}
<a class="l" name="855" href="#855">855</a>
<a class="l" name="856" href="#856">856</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="857" href="#857">857</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeAggregate"/><a href="/source/s?refs=encodeAggregate&amp;project=rtmp_client" class="xmt">encodeAggregate</a>(<a href="/source/s?defs=Aggregate&amp;project=rtmp_client">Aggregate</a> <a class="xa" name="aggregate"/><a href="/source/s?refs=aggregate&amp;project=rtmp_client" class="xa">aggregate</a>) {
<a class="l" name="858" href="#858">858</a>		<b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a class="d" href="#aggregate">aggregate</a>.<a href="/source/s?defs=getData&amp;project=rtmp_client">getData</a>();
<a class="l" name="859" href="#859">859</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="hl" name="860" href="#860">860</a>	}
<a class="l" name="861" href="#861">861</a>
<a class="l" name="862" href="#862">862</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="863" href="#863">863</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeAudioData"/><a href="/source/s?refs=encodeAudioData&amp;project=rtmp_client" class="xmt">encodeAudioData</a>(<a href="/source/s?defs=AudioData&amp;project=rtmp_client">AudioData</a> <a class="xa" name="audioData"/><a href="/source/s?refs=audioData&amp;project=rtmp_client" class="xa">audioData</a>) {
<a class="l" name="864" href="#864">864</a>		<b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a class="d" href="#audioData">audioData</a>.<a href="/source/s?defs=getData&amp;project=rtmp_client">getData</a>();
<a class="l" name="865" href="#865">865</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="866" href="#866">866</a>	}
<a class="l" name="867" href="#867">867</a>
<a class="l" name="868" href="#868">868</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="869" href="#869">869</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeVideoData"/><a href="/source/s?refs=encodeVideoData&amp;project=rtmp_client" class="xmt">encodeVideoData</a>(<a href="/source/s?defs=VideoData&amp;project=rtmp_client">VideoData</a> <a class="xa" name="videoData"/><a href="/source/s?refs=videoData&amp;project=rtmp_client" class="xa">videoData</a>) {
<a class="hl" name="870" href="#870">870</a>		<b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a class="d" href="#videoData">videoData</a>.<a href="/source/s?defs=getData&amp;project=rtmp_client">getData</a>();
<a class="l" name="871" href="#871">871</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="872" href="#872">872</a>	}
<a class="l" name="873" href="#873">873</a>
<a class="l" name="874" href="#874">874</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="875" href="#875">875</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeUnknown"/><a href="/source/s?refs=encodeUnknown&amp;project=rtmp_client" class="xmt">encodeUnknown</a>(<a href="/source/s?defs=Unknown&amp;project=rtmp_client">Unknown</a> <a class="xa" name="unknown"/><a href="/source/s?refs=unknown&amp;project=rtmp_client" class="xa">unknown</a>) {
<a class="l" name="876" href="#876">876</a>		<b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a class="d" href="#unknown">unknown</a>.<a href="/source/s?defs=getData&amp;project=rtmp_client">getData</a>();
<a class="l" name="877" href="#877">877</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="878" href="#878">878</a>	}
<a class="l" name="879" href="#879">879</a>
<a class="hl" name="880" href="#880">880</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeStreamMetadata"/><a href="/source/s?refs=encodeStreamMetadata&amp;project=rtmp_client" class="xmt">encodeStreamMetadata</a>(<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a> <a class="xa" name="metaData"/><a href="/source/s?refs=metaData&amp;project=rtmp_client" class="xa">metaData</a>) {
<a class="l" name="881" href="#881">881</a>		<b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a class="d" href="#metaData">metaData</a>.<a href="/source/s?defs=getData&amp;project=rtmp_client">getData</a>();
<a class="l" name="882" href="#882">882</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="883" href="#883">883</a>	}
<a class="l" name="884" href="#884">884</a>
<a class="l" name="885" href="#885">885</a>	<span class="c">/**
<a class="l" name="886" href="#886">886</a>	 * Generate error object to return for given exception.
<a class="l" name="887" href="#887">887</a>	 *
<a class="l" name="888" href="#888">888</a>	 * <strong>@param</strong> <em>code</em> call
<a class="l" name="889" href="#889">889</a>	 * <strong>@param</strong> <em>error</em> error
<a class="hl" name="890" href="#890">890</a>	 * <strong>@return</strong> status object
<a class="l" name="891" href="#891">891</a>	 */</span>
<a class="l" name="892" href="#892">892</a>	<b>protected</b> <a href="/source/s?defs=StatusObject&amp;project=rtmp_client">StatusObject</a> <a class="xmt" name="generateErrorResult"/><a href="/source/s?refs=generateErrorResult&amp;project=rtmp_client" class="xmt">generateErrorResult</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="code"/><a href="/source/s?refs=code&amp;project=rtmp_client" class="xa">code</a>, <a href="/source/s?defs=Throwable&amp;project=rtmp_client">Throwable</a> <a class="xa" name="error"/><a href="/source/s?refs=error&amp;project=rtmp_client" class="xa">error</a>) {
<a class="l" name="893" href="#893">893</a>		<span class="c">// Construct error object to return</span>
<a class="l" name="894" href="#894">894</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <span class="s">""</span>;
<a class="l" name="895" href="#895">895</a>		<b>while</b> (<a class="d" href="#error">error</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a class="d" href="#error">error</a>.<a href="/source/s?defs=getCause&amp;project=rtmp_client">getCause</a>() != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="896" href="#896">896</a>			<a class="d" href="#error">error</a> = <a class="d" href="#error">error</a>.<a href="/source/s?defs=getCause&amp;project=rtmp_client">getCause</a>();
<a class="l" name="897" href="#897">897</a>		}
<a class="l" name="898" href="#898">898</a>		<b>if</b> (<a class="d" href="#error">error</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a class="d" href="#error">error</a>.<a href="/source/s?defs=getMessage&amp;project=rtmp_client">getMessage</a>() != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="899" href="#899">899</a>			<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#error">error</a>.<a href="/source/s?defs=getMessage&amp;project=rtmp_client">getMessage</a>();
<a class="hl" name="900" href="#900">900</a>		}
<a class="l" name="901" href="#901">901</a>		<a href="/source/s?defs=StatusObject&amp;project=rtmp_client">StatusObject</a> <a href="/source/s?defs=status&amp;project=rtmp_client">status</a> = <b>new</b> <a href="/source/s?defs=StatusObject&amp;project=rtmp_client">StatusObject</a>(<a class="d" href="#code">code</a>, <span class="s">"error"</span>, <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="902" href="#902">902</a><span class="c">//		if (error instanceof ClientDetailsException) {</span>
<a class="l" name="903" href="#903">903</a><span class="c">//			// Return exception details to client</span>
<a class="l" name="904" href="#904">904</a><span class="c">//			status.setApplication(((ClientDetailsException) error).getParameters());</span>
<a class="l" name="905" href="#905">905</a><span class="c">//			if (((ClientDetailsException) error).includeStacktrace()) {</span>
<a class="l" name="906" href="#906">906</a><span class="c">//				List&lt;String&gt; stack = new ArrayList&lt;String&gt;();</span>
<a class="l" name="907" href="#907">907</a><span class="c">//				for (StackTraceElement element: error.getStackTrace()) {</span>
<a class="l" name="908" href="#908">908</a><span class="c">//					stack.add(element.toString());</span>
<a class="l" name="909" href="#909">909</a><span class="c">//				}</span>
<a class="hl" name="910" href="#910">910</a><span class="c">//				status.setAdditional("stacktrace", stack);</span>
<a class="l" name="911" href="#911">911</a><span class="c">//			}</span>
<a class="l" name="912" href="#912">912</a><span class="c">//		} else</span>
<a class="l" name="913" href="#913">913</a>		<b>if</b> (<a class="d" href="#error">error</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="914" href="#914">914</a>			<a href="/source/s?defs=status&amp;project=rtmp_client">status</a>.<a href="/source/s?defs=setApplication&amp;project=rtmp_client">setApplication</a>(<a class="d" href="#error">error</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>().<a href="/source/s?defs=getCanonicalName&amp;project=rtmp_client">getCanonicalName</a>());
<a class="l" name="915" href="#915">915</a>		}
<a class="l" name="916" href="#916">916</a>		<b>return</b> <a href="/source/s?defs=status&amp;project=rtmp_client">status</a>;
<a class="l" name="917" href="#917">917</a>	}
<a class="l" name="918" href="#918">918</a>
<a class="l" name="919" href="#919">919</a>	<span class="c">/**
<a class="hl" name="920" href="#920">920</a>	 * Encodes Flex message event.
<a class="l" name="921" href="#921">921</a>	 *
<a class="l" name="922" href="#922">922</a>	 * <strong>@param</strong> <em>msg</em>                Flex message event
<a class="l" name="923" href="#923">923</a>	 * <strong>@param</strong> <em>rtmp</em> RTMP
<a class="l" name="924" href="#924">924</a>	 * <strong>@return</strong>                   Encoded data
<a class="l" name="925" href="#925">925</a>	 */</span>
<a class="l" name="926" href="#926">926</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeFlexMessage"/><a href="/source/s?refs=encodeFlexMessage&amp;project=rtmp_client" class="xmt">encodeFlexMessage</a>(<a href="/source/s?defs=FlexMessage&amp;project=rtmp_client">FlexMessage</a> <a class="xa" name="msg"/><a href="/source/s?refs=msg&amp;project=rtmp_client" class="xa">msg</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>) {
<a class="l" name="927" href="#927">927</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">1024</span>);
<a class="l" name="928" href="#928">928</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="929" href="#929">929</a>		<span class="c">// Unknown byte, always 0?</span>
<a class="hl" name="930" href="#930">930</a>		<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>((<b>byte</b>) <span class="n">0</span>);
<a class="l" name="931" href="#931">931</a>		<a href="/source/s?defs=encodeNotifyOrInvoke&amp;project=rtmp_client">encodeNotifyOrInvoke</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>, <a href="/source/s?defs=msg&amp;project=rtmp_client">msg</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="932" href="#932">932</a>		<b>return</b> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a>;
<a class="l" name="933" href="#933">933</a>	}
<a class="l" name="934" href="#934">934</a>
<a class="l" name="935" href="#935">935</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="encodeFlexStreamSend"/><a href="/source/s?refs=encodeFlexStreamSend&amp;project=rtmp_client" class="xmt">encodeFlexStreamSend</a>(<a href="/source/s?defs=FlexStreamSend&amp;project=rtmp_client">FlexStreamSend</a> <a class="xa" name="msg"/><a href="/source/s?refs=msg&amp;project=rtmp_client" class="xa">msg</a>) {
<a class="l" name="936" href="#936">936</a>		<b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=msg&amp;project=rtmp_client">msg</a>.<a href="/source/s?defs=getData&amp;project=rtmp_client">getData</a>();
<a class="l" name="937" href="#937">937</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="938" href="#938">938</a>	}
<a class="l" name="939" href="#939">939</a>
<a class="hl" name="940" href="#940">940</a>	<b>private</b> <b>void</b> <a class="xmt" name="updateTolerance"/><a href="/source/s?refs=updateTolerance&amp;project=rtmp_client" class="xmt">updateTolerance</a>() {
<a class="l" name="941" href="#941">941</a>		<a class="d" href="#midTolerance">midTolerance</a> = <a href="/source/s?defs=baseTolerance&amp;project=rtmp_client">baseTolerance</a> + (<b>long</b>) (<a href="/source/s?defs=baseTolerance&amp;project=rtmp_client">baseTolerance</a> * <span class="n">0.3</span>);
<a class="l" name="942" href="#942">942</a>		<a class="d" href="#highestTolerance">highestTolerance</a> = <a href="/source/s?defs=baseTolerance&amp;project=rtmp_client">baseTolerance</a> + (<b>long</b>) (<a href="/source/s?defs=baseTolerance&amp;project=rtmp_client">baseTolerance</a> * <span class="n">0.6</span>);
<a class="l" name="943" href="#943">943</a>	}
<a class="l" name="944" href="#944">944</a>
<a class="l" name="945" href="#945">945</a>	<span class="c">/**
<a class="l" name="946" href="#946">946</a>	 * Setter for serializer.
<a class="l" name="947" href="#947">947</a>	 *
<a class="l" name="948" href="#948">948</a>	 * <strong>@param</strong> <em>serializer</em> Serializer
<a class="l" name="949" href="#949">949</a>	 */</span>
<a class="hl" name="950" href="#950">950</a>	<b>public</b> <b>void</b> <a class="xmt" name="setSerializer"/><a href="/source/s?refs=setSerializer&amp;project=rtmp_client" class="xmt">setSerializer</a>(<a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a class="xa" name="serializer"/><a href="/source/s?refs=serializer&amp;project=rtmp_client" class="xa">serializer</a>) {
<a class="l" name="951" href="#951">951</a>		<b>this</b>.<a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a> = <a href="/source/s?defs=serializer&amp;project=rtmp_client">serializer</a>;
<a class="l" name="952" href="#952">952</a>	}
<a class="l" name="953" href="#953">953</a>
<a class="l" name="954" href="#954">954</a>	<b>public</b> <b>void</b> <a class="xmt" name="setBaseTolerance"/><a href="/source/s?refs=setBaseTolerance&amp;project=rtmp_client" class="xmt">setBaseTolerance</a>(<b>long</b> <a class="xa" name="baseTolerance"/><a href="/source/s?refs=baseTolerance&amp;project=rtmp_client" class="xa">baseTolerance</a>) {
<a class="l" name="955" href="#955">955</a>		<b>this</b>.<a href="/source/s?defs=baseTolerance&amp;project=rtmp_client">baseTolerance</a> = <a href="/source/s?defs=baseTolerance&amp;project=rtmp_client">baseTolerance</a>;
<a class="l" name="956" href="#956">956</a>		<span class="c">//update high and low tolerance</span>
<a class="l" name="957" href="#957">957</a>		<a class="d" href="#updateTolerance">updateTolerance</a>();
<a class="l" name="958" href="#958">958</a>	}
<a class="l" name="959" href="#959">959</a>
<a class="hl" name="960" href="#960">960</a>	<span class="c">/**
<a class="l" name="961" href="#961">961</a>	 *   Setter for dropLiveFuture
<a class="l" name="962" href="#962">962</a>	 * */</span>
<a class="l" name="963" href="#963">963</a>	<b>public</b> <b>void</b> <a class="xmt" name="setDropLiveFuture"/><a href="/source/s?refs=setDropLiveFuture&amp;project=rtmp_client" class="xmt">setDropLiveFuture</a>(<b>boolean</b> <a class="xa" name="dropLiveFuture"/><a href="/source/s?refs=dropLiveFuture&amp;project=rtmp_client" class="xa">dropLiveFuture</a>) {
<a class="l" name="964" href="#964">964</a>		<b>this</b>.<a href="/source/s?defs=dropLiveFuture&amp;project=rtmp_client">dropLiveFuture</a> = <a href="/source/s?defs=dropLiveFuture&amp;project=rtmp_client">dropLiveFuture</a>;
<a class="l" name="965" href="#965">965</a>	}
<a class="l" name="966" href="#966">966</a>
<a class="l" name="967" href="#967">967</a>	<b>public</b> <b>long</b> <a class="xmt" name="getBaseTolerance"/><a href="/source/s?refs=getBaseTolerance&amp;project=rtmp_client" class="xmt">getBaseTolerance</a>() {
<a class="l" name="968" href="#968">968</a>		<b>return</b> <a href="/source/s?defs=baseTolerance&amp;project=rtmp_client">baseTolerance</a>;
<a class="l" name="969" href="#969">969</a>	}
<a class="hl" name="970" href="#970">970</a>
<a class="l" name="971" href="#971">971</a>}
<a class="l" name="972" href="#972">972</a>