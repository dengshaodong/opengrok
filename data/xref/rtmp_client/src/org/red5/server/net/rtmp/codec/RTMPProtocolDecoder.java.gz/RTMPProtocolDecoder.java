<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["RTMPProtocolDecoder",75]]],["Package","xp",[["org.red5.server.net.rtmp.codec",1]]],["Method","xmt",[["RTMPProtocolDecoder",88],["decode",177],["decodeAbort",575],["decodeAggregate",606],["decodeAudioData",919],["decodeBuffer",108],["decodeBytesRead",914],["decodeChunkSize",611],["decodeClientBW",596],["decodeFlexMessage",988],["decodeFlexSharedObject",616],["decodeFlexStreamSend",1042],["decodeHandshake",208],["decodeHeader",412],["decodeInvoke",752],["decodeMessage",514],["decodeNotify",743],["decodeNotify",747],["decodeNotifyOrInvoke",799],["decodePacket",261],["decodePing",899],["decodeServerBW",585],["decodeSharedObject",640],["decodeStreamMetadata",929],["decodeUnknown",601],["decodeVideoData",924],["doDecodeSharedObject",662],["isStreamCommand",764],["setDeserializer",96]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=codec&amp;project=rtmp_client">codec</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=LinkedList&amp;project=rtmp_client">LinkedList</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="27" href="#27">27</a>
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a>;
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>;
<a class="l" name="34" href="#34">34</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>;
<a class="l" name="35" href="#35">35</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>.<a href="/source/s?defs=BufferUtils&amp;project=rtmp_client">BufferUtils</a>;
<a class="l" name="36" href="#36">36</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=IConnection&amp;project=rtmp_client">IConnection</a>;
<a class="l" name="37" href="#37">37</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=Red5&amp;project=rtmp_client">Red5</a>;
<a class="l" name="38" href="#38">38</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=IConnection&amp;project=rtmp_client">IConnection</a>.<a href="/source/s?defs=Encoding&amp;project=rtmp_client">Encoding</a>;
<a class="l" name="39" href="#39">39</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=ProtocolException&amp;project=rtmp_client">ProtocolException</a>;
<a class="hl" name="40" href="#40">40</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a>;
<a class="l" name="41" href="#41">41</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=HandshakeFailedException&amp;project=rtmp_client">HandshakeFailedException</a>;
<a class="l" name="42" href="#42">42</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>;
<a class="l" name="43" href="#43">43</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Abort&amp;project=rtmp_client">Abort</a>;
<a class="l" name="44" href="#44">44</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Aggregate&amp;project=rtmp_client">Aggregate</a>;
<a class="l" name="45" href="#45">45</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=AudioData&amp;project=rtmp_client">AudioData</a>;
<a class="l" name="46" href="#46">46</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=BytesRead&amp;project=rtmp_client">BytesRead</a>;
<a class="l" name="47" href="#47">47</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=ChunkSize&amp;project=rtmp_client">ChunkSize</a>;
<a class="l" name="48" href="#48">48</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=ClientBW&amp;project=rtmp_client">ClientBW</a>;
<a class="l" name="49" href="#49">49</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=FlexMessage&amp;project=rtmp_client">FlexMessage</a>;
<a class="hl" name="50" href="#50">50</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=FlexStreamSend&amp;project=rtmp_client">FlexStreamSend</a>;
<a class="l" name="51" href="#51">51</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a>;
<a class="l" name="52" href="#52">52</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>;
<a class="l" name="53" href="#53">53</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>;
<a class="l" name="54" href="#54">54</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>;
<a class="l" name="55" href="#55">55</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=ServerBW&amp;project=rtmp_client">ServerBW</a>;
<a class="l" name="56" href="#56">56</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Unknown&amp;project=rtmp_client">Unknown</a>;
<a class="l" name="57" href="#57">57</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=VideoData&amp;project=rtmp_client">VideoData</a>;
<a class="l" name="58" href="#58">58</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>;
<a class="l" name="59" href="#59">59</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a>;
<a class="hl" name="60" href="#60">60</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a>;
<a class="l" name="61" href="#61">61</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=SharedObjectTypeMapping&amp;project=rtmp_client">SharedObjectTypeMapping</a>;
<a class="l" name="62" href="#62">62</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=StreamAction&amp;project=rtmp_client">StreamAction</a>;
<a class="l" name="63" href="#63">63</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>;
<a class="l" name="64" href="#64">64</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a>;
<a class="l" name="65" href="#65">65</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a class="d" href="#so">so</a>.<a href="/source/s?defs=FlexSharedObjectMessage&amp;project=rtmp_client">FlexSharedObjectMessage</a>;
<a class="l" name="66" href="#66">66</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a class="d" href="#so">so</a>.<a href="/source/s?defs=ISharedObjectEvent&amp;project=rtmp_client">ISharedObjectEvent</a>;
<a class="l" name="67" href="#67">67</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a class="d" href="#so">so</a>.<a href="/source/s?defs=ISharedObjectMessage&amp;project=rtmp_client">ISharedObjectMessage</a>;
<a class="l" name="68" href="#68">68</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a class="d" href="#so">so</a>.<a href="/source/s?defs=SharedObjectMessage&amp;project=rtmp_client">SharedObjectMessage</a>;
<a class="l" name="69" href="#69">69</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="hl" name="70" href="#70">70</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="71" href="#71">71</a>
<a class="l" name="72" href="#72">72</a><span class="c">/**
<a class="l" name="73" href="#73">73</a> * RTMP protocol decoder.
<a class="l" name="74" href="#74">74</a> */</span>
<a class="l" name="75" href="#75">75</a><b>public</b> <b>class</b> <a class="xc" name="RTMPProtocolDecoder"/><a href="/source/s?refs=RTMPProtocolDecoder&amp;project=rtmp_client" class="xc">RTMPProtocolDecoder</a> <b>implements</b> <a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>, <a href="/source/s?defs=IEventDecoder&amp;project=rtmp_client">IEventDecoder</a> {
<a class="l" name="76" href="#76">76</a>
<a class="l" name="77" href="#77">77</a>	<span class="c">/**
<a class="l" name="78" href="#78">78</a>	 * Logger.
<a class="l" name="79" href="#79">79</a>	 */</span>
<a class="hl" name="80" href="#80">80</a>	<b>protected</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a href="/source/s?defs=RTMPProtocolDecoder&amp;project=rtmp_client">RTMPProtocolDecoder</a>.<b>class</b>);
<a class="l" name="81" href="#81">81</a>
<a class="l" name="82" href="#82">82</a>	<span class="c">/**
<a class="l" name="83" href="#83">83</a>	 * Deserializer.
<a class="l" name="84" href="#84">84</a>	 */</span>
<a class="l" name="85" href="#85">85</a>	<b>private</b> <a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xfld" name="deserializer"/><a href="/source/s?refs=deserializer&amp;project=rtmp_client" class="xfld">deserializer</a>;
<a class="l" name="86" href="#86">86</a>
<a class="l" name="87" href="#87">87</a>	<span class="c">/** Constructs a new RTMPProtocolDecoder. */</span>
<a class="l" name="88" href="#88">88</a>	<b>public</b> <a class="xmt" name="RTMPProtocolDecoder"/><a href="/source/s?refs=RTMPProtocolDecoder&amp;project=rtmp_client" class="xmt">RTMPProtocolDecoder</a>() {
<a class="l" name="89" href="#89">89</a>	}
<a class="hl" name="90" href="#90">90</a>
<a class="l" name="91" href="#91">91</a>	<span class="c">/**
<a class="l" name="92" href="#92">92</a>	 * Setter for deserializer.
<a class="l" name="93" href="#93">93</a>	 *
<a class="l" name="94" href="#94">94</a>	 * <strong>@param</strong> <em>deserializer</em> Deserializer
<a class="l" name="95" href="#95">95</a>	 */</span>
<a class="l" name="96" href="#96">96</a>	<b>public</b> <b>void</b> <a class="xmt" name="setDeserializer"/><a href="/source/s?refs=setDeserializer&amp;project=rtmp_client" class="xmt">setDeserializer</a>(<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a class="xa" name="deserializer"/><a href="/source/s?refs=deserializer&amp;project=rtmp_client" class="xa">deserializer</a>) {
<a class="l" name="97" href="#97">97</a>		<b>this</b>.<a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>;
<a class="l" name="98" href="#98">98</a>	}
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a>	<span class="c">/**
<a class="l" name="101" href="#101">101</a>	 * Decode all available objects in buffer.
<a class="l" name="102" href="#102">102</a>	 *
<a class="l" name="103" href="#103">103</a>	 * <strong>@param</strong> <em>state</em> Stores state for the protocol
<a class="l" name="104" href="#104">104</a>	 * <strong>@param</strong> <em>buffer</em> IoBuffer of data to be decoded
<a class="l" name="105" href="#105">105</a>	 * <strong>@return</strong> a list of decoded objects, may be empty if nothing could be
<a class="l" name="106" href="#106">106</a>	 *         decoded
<a class="l" name="107" href="#107">107</a>	 */</span>
<a class="l" name="108" href="#108">108</a>	<b>public</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xmt" name="decodeBuffer"/><a href="/source/s?refs=decodeBuffer&amp;project=rtmp_client" class="xmt">decodeBuffer</a>(<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a> <a class="xa" name="state"/><a href="/source/s?refs=state&amp;project=rtmp_client" class="xa">state</a>, <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="buffer"/><a href="/source/s?refs=buffer&amp;project=rtmp_client" class="xa">buffer</a>) {
<a class="l" name="109" href="#109">109</a>		<b>final</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>new</b> <a href="/source/s?defs=LinkedList&amp;project=rtmp_client">LinkedList</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="hl" name="110" href="#110">110</a>		<b>try</b> {
<a class="l" name="111" href="#111">111</a>			<b>while</b> (<b>true</b>) {
<a class="l" name="112" href="#112">112</a>				<b>final</b> <b>int</b> <a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a> = <a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>();
<a class="l" name="113" href="#113">113</a>				<b>if</b> (<a href="/source/s?defs=state&amp;project=rtmp_client">state</a>.<a href="/source/s?defs=canStartDecoding&amp;project=rtmp_client">canStartDecoding</a>(<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>)) {
<a class="l" name="114" href="#114">114</a>					<a href="/source/s?defs=state&amp;project=rtmp_client">state</a>.<a href="/source/s?defs=startDecoding&amp;project=rtmp_client">startDecoding</a>();
<a class="l" name="115" href="#115">115</a>				} <b>else</b> {
<a class="l" name="116" href="#116">116</a>					<b>break</b>;
<a class="l" name="117" href="#117">117</a>				}
<a class="l" name="118" href="#118">118</a>				<b>final</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=decodedObject&amp;project=rtmp_client">decodedObject</a> = <a class="d" href="#decode">decode</a>(<a href="/source/s?defs=state&amp;project=rtmp_client">state</a>, <a class="d" href="#buffer">buffer</a>);
<a class="l" name="119" href="#119">119</a>				<b>if</b> (<a href="/source/s?defs=state&amp;project=rtmp_client">state</a>.<a href="/source/s?defs=hasDecodedObject&amp;project=rtmp_client">hasDecodedObject</a>()) {
<a class="hl" name="120" href="#120">120</a>					<b>if</b> (<a href="/source/s?defs=decodedObject&amp;project=rtmp_client">decodedObject</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="121" href="#121">121</a>						<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=decodedObject&amp;project=rtmp_client">decodedObject</a>);
<a class="l" name="122" href="#122">122</a>					}
<a class="l" name="123" href="#123">123</a>				} <b>else</b> <b>if</b> (<a href="/source/s?defs=state&amp;project=rtmp_client">state</a>.<a href="/source/s?defs=canContinueDecoding&amp;project=rtmp_client">canContinueDecoding</a>()) {
<a class="l" name="124" href="#124">124</a>					<b>continue</b>;
<a class="l" name="125" href="#125">125</a>				} <b>else</b> {
<a class="l" name="126" href="#126">126</a>					<b>break</b>;
<a class="l" name="127" href="#127">127</a>				}
<a class="l" name="128" href="#128">128</a>				<b>if</b> (!<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=hasRemaining&amp;project=rtmp_client">hasRemaining</a>()) {
<a class="l" name="129" href="#129">129</a>					<b>break</b>;
<a class="hl" name="130" href="#130">130</a>				}
<a class="l" name="131" href="#131">131</a>			}
<a class="l" name="132" href="#132">132</a>		} <b>catch</b> (<a href="/source/s?defs=HandshakeFailedException&amp;project=rtmp_client">HandshakeFailedException</a> <a href="/source/s?defs=hfe&amp;project=rtmp_client">hfe</a>) {
<a class="l" name="133" href="#133">133</a>			<span class="c">// patched by Victor to clear buffer if something is wrong in</span>
<a class="l" name="134" href="#134">134</a>			<span class="c">// protocol decoding.</span>
<a class="l" name="135" href="#135">135</a>			<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=clear&amp;project=rtmp_client">clear</a>();
<a class="l" name="136" href="#136">136</a>			<span class="c">// get the connection and close it</span>
<a class="l" name="137" href="#137">137</a>			<a href="/source/s?defs=IConnection&amp;project=rtmp_client">IConnection</a> <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> = <a href="/source/s?defs=Red5&amp;project=rtmp_client">Red5</a>.<a href="/source/s?defs=getConnectionLocal&amp;project=rtmp_client">getConnectionLocal</a>();
<a class="l" name="138" href="#138">138</a>			<b>if</b> (<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="139" href="#139">139</a>				<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=close&amp;project=rtmp_client">close</a>();
<a class="hl" name="140" href="#140">140</a>			} <b>else</b> {
<a class="l" name="141" href="#141">141</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Handshake validation failed but no current connection!?"</span>);
<a class="l" name="142" href="#142">142</a>			}
<a class="l" name="143" href="#143">143</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="144" href="#144">144</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> <a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>) {
<a class="l" name="145" href="#145">145</a>			<span class="c">// Exception handling is patched by Victor - we catch any exception in the decoding</span>
<a class="l" name="146" href="#146">146</a>			<span class="c">// Then clear the buffer to eliminate memory leaks when we can't parse protocol</span>
<a class="l" name="147" href="#147">147</a>			<span class="c">// Also close Connection because we can't parse data from it</span>
<a class="l" name="148" href="#148">148</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error decoding buffer"</span>, <a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>);
<a class="l" name="149" href="#149">149</a>			<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=clear&amp;project=rtmp_client">clear</a>();
<a class="hl" name="150" href="#150">150</a>			<span class="c">// get the connection and close it</span>
<a class="l" name="151" href="#151">151</a>			<a href="/source/s?defs=IConnection&amp;project=rtmp_client">IConnection</a> <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> = <a href="/source/s?defs=Red5&amp;project=rtmp_client">Red5</a>.<a href="/source/s?defs=getConnectionLocal&amp;project=rtmp_client">getConnectionLocal</a>();
<a class="l" name="152" href="#152">152</a>			<b>if</b> (<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="153" href="#153">153</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Closing connection because decoding failed: {}"</span>, <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>);
<a class="l" name="154" href="#154">154</a>				<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=close&amp;project=rtmp_client">close</a>();
<a class="l" name="155" href="#155">155</a>			} <b>else</b> {
<a class="l" name="156" href="#156">156</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Decoding buffer failed but no current connection!?"</span>);
<a class="l" name="157" href="#157">157</a>			}
<a class="l" name="158" href="#158">158</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="159" href="#159">159</a>		} <b>finally</b> {
<a class="hl" name="160" href="#160">160</a>			<a class="d" href="#buffer">buffer</a>.<a href="/source/s?defs=compact&amp;project=rtmp_client">compact</a>();
<a class="l" name="161" href="#161">161</a>		}
<a class="l" name="162" href="#162">162</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="163" href="#163">163</a>	}
<a class="l" name="164" href="#164">164</a>
<a class="l" name="165" href="#165">165</a>	<span class="c">/**
<a class="l" name="166" href="#166">166</a>	 * Decodes the buffer data
<a class="l" name="167" href="#167">167</a>	 *
<a class="l" name="168" href="#168">168</a>	 * <strong>@param</strong> <em>state</em> Stores state for the protocol, ProtocolState is just a marker
<a class="l" name="169" href="#169">169</a>	 *            interface
<a class="hl" name="170" href="#170">170</a>	 * <strong>@param</strong> <em>in</em> IoBuffer of data to be decoded
<a class="l" name="171" href="#171">171</a>	 * <strong>@return</strong> one of three possible values. null : the object could not be
<a class="l" name="172" href="#172">172</a>	 *         decoded, or some data was skipped, just continue. ProtocolState :
<a class="l" name="173" href="#173">173</a>	 *         the decoder was unable to decode the whole object, refer to the
<a class="l" name="174" href="#174">174</a>	 *         protocol state Object : something was decoded, continue
<a class="l" name="175" href="#175">175</a>	 * <strong>@throws</strong> <em>Exception</em> on error
<a class="l" name="176" href="#176">176</a>	 */</span>
<a class="l" name="177" href="#177">177</a>	<b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="decode"/><a href="/source/s?refs=decode&amp;project=rtmp_client" class="xmt">decode</a>(<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a> <a class="xa" name="state"/><a href="/source/s?refs=state&amp;project=rtmp_client" class="xa">state</a>, <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) <b>throws</b> <a href="/source/s?defs=ProtocolException&amp;project=rtmp_client">ProtocolException</a> {
<a class="l" name="178" href="#178">178</a><span class="c">//		int start = in.position();</span>
<a class="l" name="179" href="#179">179</a><span class="c">//		log.debug("Start: {}", start);</span>
<a class="hl" name="180" href="#180">180</a>		<b>try</b> {
<a class="l" name="181" href="#181">181</a>			<b>final</b> <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a> = (<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>) <a href="/source/s?defs=state&amp;project=rtmp_client">state</a>;
<a class="l" name="182" href="#182">182</a>			<b>switch</b> (<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getState&amp;project=rtmp_client">getState</a>()) {
<a class="l" name="183" href="#183">183</a>				<b>case</b> <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=STATE_CONNECTED&amp;project=rtmp_client">STATE_CONNECTED</a>:
<a class="l" name="184" href="#184">184</a>					<b>return</b> <a class="d" href="#decodePacket">decodePacket</a>(<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>, <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="185" href="#185">185</a>				<b>case</b> <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=STATE_CONNECT&amp;project=rtmp_client">STATE_CONNECT</a>:
<a class="l" name="186" href="#186">186</a>				<b>case</b> <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=STATE_HANDSHAKE&amp;project=rtmp_client">STATE_HANDSHAKE</a>:
<a class="l" name="187" href="#187">187</a>					<b>return</b> <a class="d" href="#decodeHandshake">decodeHandshake</a>(<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>, <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="188" href="#188">188</a>				<b>case</b> <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=STATE_ERROR&amp;project=rtmp_client">STATE_ERROR</a>:
<a class="l" name="189" href="#189">189</a>					<span class="c">// attempt to correct error</span>
<a class="hl" name="190" href="#190">190</a>				<b>default</b>:
<a class="l" name="191" href="#191">191</a>					<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="192" href="#192">192</a>			}
<a class="l" name="193" href="#193">193</a>		} <b>catch</b> (<a href="/source/s?defs=ProtocolException&amp;project=rtmp_client">ProtocolException</a> <a href="/source/s?defs=pe&amp;project=rtmp_client">pe</a>) {
<a class="l" name="194" href="#194">194</a>			<span class="c">// Raise to caller unmodified</span>
<a class="l" name="195" href="#195">195</a>			<b>throw</b> <a href="/source/s?defs=pe&amp;project=rtmp_client">pe</a>;
<a class="l" name="196" href="#196">196</a>		} <b>catch</b> (<a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a> e) {
<a class="l" name="197" href="#197">197</a>			<b>throw</b> <b>new</b> <a href="/source/s?defs=ProtocolException&amp;project=rtmp_client">ProtocolException</a>(<span class="s">"Error during decoding"</span>, e);
<a class="l" name="198" href="#198">198</a>		}
<a class="l" name="199" href="#199">199</a>	}
<a class="hl" name="200" href="#200">200</a>
<a class="l" name="201" href="#201">201</a>	<span class="c">/**
<a class="l" name="202" href="#202">202</a>	 * Decodes handshake message.
<a class="l" name="203" href="#203">203</a>	 *
<a class="l" name="204" href="#204">204</a>	 * <strong>@param</strong> <em>rtmp</em> RTMP protocol state
<a class="l" name="205" href="#205">205</a>	 * <strong>@param</strong> <em>in</em> IoBuffer
<a class="l" name="206" href="#206">206</a>	 * <strong>@return</strong> IoBuffer
<a class="l" name="207" href="#207">207</a>	 */</span>
<a class="l" name="208" href="#208">208</a>	<b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="decodeHandshake"/><a href="/source/s?refs=decodeHandshake&amp;project=rtmp_client" class="xmt">decodeHandshake</a>(<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>, <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="209" href="#209">209</a><span class="c">//		log.debug("decodeHandshake - rtmp: {} buffer: {}", rtmp, in);</span>
<a class="hl" name="210" href="#210">210</a>		<b>final</b> <b>int</b> <a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>();
<a class="l" name="211" href="#211">211</a>		<b>if</b> (<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getMode&amp;project=rtmp_client">getMode</a>() == <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=MODE_SERVER&amp;project=rtmp_client">MODE_SERVER</a>) {
<a class="l" name="212" href="#212">212</a>			<b>if</b> (<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getState&amp;project=rtmp_client">getState</a>() == <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=STATE_CONNECT&amp;project=rtmp_client">STATE_CONNECT</a>) {
<a class="l" name="213" href="#213">213</a>				<b>if</b> (<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a> &lt; <a href="/source/s?defs=HANDSHAKE_SIZE&amp;project=rtmp_client">HANDSHAKE_SIZE</a> + <span class="n">1</span>) {
<a class="l" name="214" href="#214">214</a><span class="c">//					log.debug("Handshake init too small, buffering. remaining: {}", remaining);</span>
<a class="l" name="215" href="#215">215</a>					<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=bufferDecoding&amp;project=rtmp_client">bufferDecoding</a>(<a href="/source/s?defs=HANDSHAKE_SIZE&amp;project=rtmp_client">HANDSHAKE_SIZE</a> + <span class="n">1</span>);
<a class="l" name="216" href="#216">216</a>				} <b>else</b> {
<a class="l" name="217" href="#217">217</a>					<b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=hs&amp;project=rtmp_client">hs</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<a href="/source/s?defs=HANDSHAKE_SIZE&amp;project=rtmp_client">HANDSHAKE_SIZE</a>);
<a class="l" name="218" href="#218">218</a>					<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(); <span class="c">// skip the header byte</span>
<a class="l" name="219" href="#219">219</a>					<a href="/source/s?defs=BufferUtils&amp;project=rtmp_client">BufferUtils</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=hs&amp;project=rtmp_client">hs</a>, <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>, <a href="/source/s?defs=HANDSHAKE_SIZE&amp;project=rtmp_client">HANDSHAKE_SIZE</a>);
<a class="hl" name="220" href="#220">220</a>					<a href="/source/s?defs=hs&amp;project=rtmp_client">hs</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="221" href="#221">221</a>					<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setState&amp;project=rtmp_client">setState</a>(<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=STATE_HANDSHAKE&amp;project=rtmp_client">STATE_HANDSHAKE</a>);
<a class="l" name="222" href="#222">222</a>					<b>return</b> <a href="/source/s?defs=hs&amp;project=rtmp_client">hs</a>;
<a class="l" name="223" href="#223">223</a>				}
<a class="l" name="224" href="#224">224</a>			} <b>else</b> <b>if</b> (<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getState&amp;project=rtmp_client">getState</a>() == <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=STATE_HANDSHAKE&amp;project=rtmp_client">STATE_HANDSHAKE</a>) {
<a class="l" name="225" href="#225">225</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Handshake reply"</span>);
<a class="l" name="226" href="#226">226</a>				<b>if</b> (<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a> &lt; <a href="/source/s?defs=HANDSHAKE_SIZE&amp;project=rtmp_client">HANDSHAKE_SIZE</a>) {
<a class="l" name="227" href="#227">227</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Handshake reply too small, buffering. remaining: {}"</span>, <a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>);
<a class="l" name="228" href="#228">228</a>					<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=bufferDecoding&amp;project=rtmp_client">bufferDecoding</a>(<a href="/source/s?defs=HANDSHAKE_SIZE&amp;project=rtmp_client">HANDSHAKE_SIZE</a>);
<a class="l" name="229" href="#229">229</a>				} <b>else</b> {
<a class="hl" name="230" href="#230">230</a>					<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=skip&amp;project=rtmp_client">skip</a>(<a href="/source/s?defs=HANDSHAKE_SIZE&amp;project=rtmp_client">HANDSHAKE_SIZE</a>);
<a class="l" name="231" href="#231">231</a>					<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setState&amp;project=rtmp_client">setState</a>(<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=STATE_CONNECTED&amp;project=rtmp_client">STATE_CONNECTED</a>);
<a class="l" name="232" href="#232">232</a>					<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=continueDecoding&amp;project=rtmp_client">continueDecoding</a>();
<a class="l" name="233" href="#233">233</a>				}
<a class="l" name="234" href="#234">234</a>			}
<a class="l" name="235" href="#235">235</a>		} <b>else</b> {
<a class="l" name="236" href="#236">236</a>			<span class="c">// else, this is client mode.</span>
<a class="l" name="237" href="#237">237</a>			<b>if</b> (<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getState&amp;project=rtmp_client">getState</a>() == <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=STATE_CONNECT&amp;project=rtmp_client">STATE_CONNECT</a>) {
<a class="l" name="238" href="#238">238</a>				<b>final</b> <b>int</b> <a href="/source/s?defs=size&amp;project=rtmp_client">size</a> = (<span class="n">2</span> * <a href="/source/s?defs=HANDSHAKE_SIZE&amp;project=rtmp_client">HANDSHAKE_SIZE</a>) + <span class="n">1</span>;
<a class="l" name="239" href="#239">239</a>				<b>if</b> (<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a> &lt; <a href="/source/s?defs=size&amp;project=rtmp_client">size</a>) {
<a class="hl" name="240" href="#240">240</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Handshake init too small, buffering. remaining: {}"</span>, <a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>);
<a class="l" name="241" href="#241">241</a>					<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=bufferDecoding&amp;project=rtmp_client">bufferDecoding</a>(<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>);
<a class="l" name="242" href="#242">242</a>				} <b>else</b> {
<a class="l" name="243" href="#243">243</a>					<b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=hs&amp;project=rtmp_client">hs</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>);
<a class="l" name="244" href="#244">244</a>					<a href="/source/s?defs=BufferUtils&amp;project=rtmp_client">BufferUtils</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=hs&amp;project=rtmp_client">hs</a>, <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>, <a href="/source/s?defs=size&amp;project=rtmp_client">size</a>);
<a class="l" name="245" href="#245">245</a>					<a href="/source/s?defs=hs&amp;project=rtmp_client">hs</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="246" href="#246">246</a>					<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setState&amp;project=rtmp_client">setState</a>(<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=STATE_CONNECTED&amp;project=rtmp_client">STATE_CONNECTED</a>);
<a class="l" name="247" href="#247">247</a>					<b>return</b> <a href="/source/s?defs=hs&amp;project=rtmp_client">hs</a>;
<a class="l" name="248" href="#248">248</a>				}
<a class="l" name="249" href="#249">249</a>			}
<a class="hl" name="250" href="#250">250</a>		}
<a class="l" name="251" href="#251">251</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="252" href="#252">252</a>	}
<a class="l" name="253" href="#253">253</a>
<a class="l" name="254" href="#254">254</a>	<span class="c">/**
<a class="l" name="255" href="#255">255</a>	 * Decodes packet.
<a class="l" name="256" href="#256">256</a>	 *
<a class="l" name="257" href="#257">257</a>	 * <strong>@param</strong> <em>rtmp</em> RTMP protocol state
<a class="l" name="258" href="#258">258</a>	 * <strong>@param</strong> <em>in</em> IoBuffer
<a class="l" name="259" href="#259">259</a>	 * <strong>@return</strong> IoBuffer
<a class="hl" name="260" href="#260">260</a>	 */</span>
<a class="l" name="261" href="#261">261</a>	<b>public</b> <a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a> <a class="xmt" name="decodePacket"/><a href="/source/s?refs=decodePacket&amp;project=rtmp_client" class="xmt">decodePacket</a>(<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>, <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="262" href="#262">262</a><span class="c">//		log.debug("decodePacket - rtmp: {} buffer: {}", rtmp, in);</span>
<a class="l" name="263" href="#263">263</a>		<b>final</b> <b>int</b> <a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>();
<a class="l" name="264" href="#264">264</a>
<a class="l" name="265" href="#265">265</a>		<span class="c">// We need at least one byte</span>
<a class="l" name="266" href="#266">266</a>		<b>if</b> (<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a> &lt; <span class="n">1</span>) {
<a class="l" name="267" href="#267">267</a>			<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=bufferDecoding&amp;project=rtmp_client">bufferDecoding</a>(<span class="n">1</span>);
<a class="l" name="268" href="#268">268</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="269" href="#269">269</a>		}
<a class="hl" name="270" href="#270">270</a>
<a class="l" name="271" href="#271">271</a>		<b>final</b> <b>int</b> <a href="/source/s?defs=position&amp;project=rtmp_client">position</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>();
<a class="l" name="272" href="#272">272</a>		<b>byte</b> <a href="/source/s?defs=headerByte&amp;project=rtmp_client">headerByte</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="273" href="#273">273</a>		<b>int</b> <a href="/source/s?defs=headerValue&amp;project=rtmp_client">headerValue</a>;
<a class="l" name="274" href="#274">274</a>		<b>int</b> <a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a>;
<a class="l" name="275" href="#275">275</a>		<b>if</b> ((<a href="/source/s?defs=headerByte&amp;project=rtmp_client">headerByte</a> &amp; <span class="n">0x3f</span>) == <span class="n">0</span>) {
<a class="l" name="276" href="#276">276</a>			<span class="c">// Two byte header</span>
<a class="l" name="277" href="#277">277</a>			<b>if</b> (<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a> &lt; <span class="n">2</span>) {
<a class="l" name="278" href="#278">278</a>				<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>);
<a class="l" name="279" href="#279">279</a>				<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=bufferDecoding&amp;project=rtmp_client">bufferDecoding</a>(<span class="n">2</span>);
<a class="hl" name="280" href="#280">280</a>				<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="281" href="#281">281</a>			}
<a class="l" name="282" href="#282">282</a>			<a href="/source/s?defs=headerValue&amp;project=rtmp_client">headerValue</a> = (<a href="/source/s?defs=headerByte&amp;project=rtmp_client">headerByte</a> &amp; <span class="n">0xff</span>) &lt;&lt; <span class="n">8</span> | (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xff</span>);
<a class="l" name="283" href="#283">283</a>			<a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a> = <span class="n">2</span>;
<a class="l" name="284" href="#284">284</a>		} <b>else</b> <b>if</b> ((<a href="/source/s?defs=headerByte&amp;project=rtmp_client">headerByte</a> &amp; <span class="n">0x3f</span>) == <span class="n">1</span>) {
<a class="l" name="285" href="#285">285</a>			<span class="c">// Three byte header</span>
<a class="l" name="286" href="#286">286</a>			<b>if</b> (<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a> &lt; <span class="n">3</span>) {
<a class="l" name="287" href="#287">287</a>				<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>);
<a class="l" name="288" href="#288">288</a>				<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=bufferDecoding&amp;project=rtmp_client">bufferDecoding</a>(<span class="n">3</span>);
<a class="l" name="289" href="#289">289</a>				<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="hl" name="290" href="#290">290</a>			}
<a class="l" name="291" href="#291">291</a>			<a href="/source/s?defs=headerValue&amp;project=rtmp_client">headerValue</a> = (<a href="/source/s?defs=headerByte&amp;project=rtmp_client">headerByte</a> &amp; <span class="n">0xff</span>) &lt;&lt; <span class="n">16</span> | (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xff</span>) &lt;&lt; <span class="n">8</span> | (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xff</span>);
<a class="l" name="292" href="#292">292</a>			<a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a> = <span class="n">3</span>;
<a class="l" name="293" href="#293">293</a>		} <b>else</b> {
<a class="l" name="294" href="#294">294</a>			<span class="c">// Single byte header</span>
<a class="l" name="295" href="#295">295</a>			<a href="/source/s?defs=headerValue&amp;project=rtmp_client">headerValue</a> = <a href="/source/s?defs=headerByte&amp;project=rtmp_client">headerByte</a> &amp; <span class="n">0xff</span>;
<a class="l" name="296" href="#296">296</a>			<a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a> = <span class="n">1</span>;
<a class="l" name="297" href="#297">297</a>		}
<a class="l" name="298" href="#298">298</a>		<b>final</b> <b>int</b> <a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a> = <a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=decodeChannelId&amp;project=rtmp_client">decodeChannelId</a>(<a href="/source/s?defs=headerValue&amp;project=rtmp_client">headerValue</a>, <a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a>);
<a class="l" name="299" href="#299">299</a>		<b>if</b> (<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a> &lt; <span class="n">0</span>) {
<a class="hl" name="300" href="#300">300</a>			<b>throw</b> <b>new</b> <a href="/source/s?defs=ProtocolException&amp;project=rtmp_client">ProtocolException</a>(<span class="s">"Bad channel id: "</span> + <a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>);
<a class="l" name="301" href="#301">301</a>		}
<a class="l" name="302" href="#302">302</a>
<a class="l" name="303" href="#303">303</a>		<span class="c">// Get the header size and length</span>
<a class="l" name="304" href="#304">304</a>		<b>int</b> <a href="/source/s?defs=headerLength&amp;project=rtmp_client">headerLength</a> = <a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=getHeaderLength&amp;project=rtmp_client">getHeaderLength</a>(<a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=decodeHeaderSize&amp;project=rtmp_client">decodeHeaderSize</a>(<a href="/source/s?defs=headerValue&amp;project=rtmp_client">headerValue</a>, <a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a>));
<a class="l" name="305" href="#305">305</a>		<a href="/source/s?defs=headerLength&amp;project=rtmp_client">headerLength</a> += <a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a> - <span class="n">1</span>;
<a class="l" name="306" href="#306">306</a>
<a class="l" name="307" href="#307">307</a>		<b>if</b> (<a href="/source/s?defs=headerLength&amp;project=rtmp_client">headerLength</a> + <a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a> - <span class="n">1</span> &gt; <a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>) {
<a class="l" name="308" href="#308">308</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Header too small, buffering. remaining: {}"</span>, <a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>);
<a class="l" name="309" href="#309">309</a>			<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>);
<a class="hl" name="310" href="#310">310</a>			<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=bufferDecoding&amp;project=rtmp_client">bufferDecoding</a>(<a href="/source/s?defs=headerLength&amp;project=rtmp_client">headerLength</a> + <a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a> - <span class="n">1</span>);
<a class="l" name="311" href="#311">311</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="312" href="#312">312</a>		}
<a class="l" name="313" href="#313">313</a>
<a class="l" name="314" href="#314">314</a>		<span class="c">// Move the position back to the start</span>
<a class="l" name="315" href="#315">315</a>		<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>);
<a class="l" name="316" href="#316">316</a>
<a class="l" name="317" href="#317">317</a>		<a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="d" href="#lastHeader">lastHeader</a> = <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getLastReadHeader&amp;project=rtmp_client">getLastReadHeader</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>);
<a class="l" name="318" href="#318">318</a>		<b>final</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a href="/source/s?defs=header&amp;project=rtmp_client">header</a> = <a class="d" href="#decodeHeader">decodeHeader</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>, <a class="d" href="#lastHeader">lastHeader</a>);
<a class="l" name="319" href="#319">319</a>		<b>if</b> (<a href="/source/s?defs=header&amp;project=rtmp_client">header</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="320" href="#320">320</a>			<b>throw</b> <b>new</b> <a href="/source/s?defs=ProtocolException&amp;project=rtmp_client">ProtocolException</a>(<span class="s">"Header is null, check for error"</span>);
<a class="l" name="321" href="#321">321</a>		}
<a class="l" name="322" href="#322">322</a>		<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setLastReadHeader&amp;project=rtmp_client">setLastReadHeader</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>);
<a class="l" name="323" href="#323">323</a>
<a class="l" name="324" href="#324">324</a>		<span class="c">// Check to see if this is a new packets or continue decoding an</span>
<a class="l" name="325" href="#325">325</a>		<span class="c">// existing one.</span>
<a class="l" name="326" href="#326">326</a>		<a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a> <a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a> = <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getLastReadPacket&amp;project=rtmp_client">getLastReadPacket</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>);
<a class="l" name="327" href="#327">327</a>		<b>if</b> (<a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="328" href="#328">328</a>			<a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a> = <b>new</b> <a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=clone&amp;project=rtmp_client">clone</a>());
<a class="l" name="329" href="#329">329</a>			<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setLastReadPacket&amp;project=rtmp_client">setLastReadPacket</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>, <a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a>);
<a class="hl" name="330" href="#330">330</a>		}
<a class="l" name="331" href="#331">331</a>
<a class="l" name="332" href="#332">332</a>		<b>final</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> = <a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a>.<a href="/source/s?defs=getData&amp;project=rtmp_client">getData</a>();
<a class="l" name="333" href="#333">333</a>		<b>final</b> <b>int</b> <a href="/source/s?defs=readRemaining&amp;project=rtmp_client">readRemaining</a> = <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>() - <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>();
<a class="l" name="334" href="#334">334</a>		<b>final</b> <b>int</b> <a href="/source/s?defs=chunkSize&amp;project=rtmp_client">chunkSize</a> = <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getReadChunkSize&amp;project=rtmp_client">getReadChunkSize</a>();
<a class="l" name="335" href="#335">335</a>		<b>final</b> <b>int</b> <a href="/source/s?defs=readAmount&amp;project=rtmp_client">readAmount</a> = (<a href="/source/s?defs=readRemaining&amp;project=rtmp_client">readRemaining</a> &gt; <a href="/source/s?defs=chunkSize&amp;project=rtmp_client">chunkSize</a>) ? <a href="/source/s?defs=chunkSize&amp;project=rtmp_client">chunkSize</a> : <a href="/source/s?defs=readRemaining&amp;project=rtmp_client">readRemaining</a>;
<a class="l" name="336" href="#336">336</a>		<b>if</b> (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>() &lt; <a href="/source/s?defs=readAmount&amp;project=rtmp_client">readAmount</a>) {
<a class="l" name="337" href="#337">337</a><span class="c">//			log.debug("Chunk too small, buffering ({},{})", in.remaining(), readAmount);</span>
<a class="l" name="338" href="#338">338</a>			<span class="c">// skip the position back to the start</span>
<a class="l" name="339" href="#339">339</a>			<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>);
<a class="hl" name="340" href="#340">340</a>			<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=bufferDecoding&amp;project=rtmp_client">bufferDecoding</a>(<a href="/source/s?defs=headerLength&amp;project=rtmp_client">headerLength</a> + <a href="/source/s?defs=readAmount&amp;project=rtmp_client">readAmount</a>);
<a class="l" name="341" href="#341">341</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="342" href="#342">342</a>		}
<a class="l" name="343" href="#343">343</a>
<a class="l" name="344" href="#344">344</a>		<a href="/source/s?defs=BufferUtils&amp;project=rtmp_client">BufferUtils</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>, <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>, <a href="/source/s?defs=readAmount&amp;project=rtmp_client">readAmount</a>);
<a class="l" name="345" href="#345">345</a>		<b>if</b> (<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() &lt; <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>()) {
<a class="l" name="346" href="#346">346</a>			<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=continueDecoding&amp;project=rtmp_client">continueDecoding</a>();
<a class="l" name="347" href="#347">347</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="348" href="#348">348</a>		}
<a class="l" name="349" href="#349">349</a>
<a class="hl" name="350" href="#350">350</a>		<span class="c">// Check workaround for SN-19 to find cause for BufferOverflowException</span>
<a class="l" name="351" href="#351">351</a>		<b>if</b> (<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() &gt; <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>()) {
<a class="l" name="352" href="#352">352</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Packet size expanded from {} to {} ({})"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { (<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>()), <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(), <a href="/source/s?defs=header&amp;project=rtmp_client">header</a> });
<a class="l" name="353" href="#353">353</a>		}
<a class="l" name="354" href="#354">354</a>
<a class="l" name="355" href="#355">355</a>		<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="356" href="#356">356</a>
<a class="l" name="357" href="#357">357</a>		<b>try</b> {
<a class="l" name="358" href="#358">358</a>			<b>final</b> <a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a> <a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#decodeMessage">decodeMessage</a>(<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>, <a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a>.<a href="/source/s?defs=getHeader&amp;project=rtmp_client">getHeader</a>(), <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="359" href="#359">359</a>			<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=setHeader&amp;project=rtmp_client">setHeader</a>(<a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a>.<a href="/source/s?defs=getHeader&amp;project=rtmp_client">getHeader</a>());
<a class="hl" name="360" href="#360">360</a>			<span class="c">// Unfortunately flash will, especially when resetting a video stream with a new key frame, sometime</span>
<a class="l" name="361" href="#361">361</a>			<span class="c">// send an earlier time stamp.  To avoid dropping it, we just give it the minimal increment since the</span>
<a class="l" name="362" href="#362">362</a>			<span class="c">// last message.  But to avoid relative time stamps being mis-computed, we don't reset the header we stored.</span>
<a class="l" name="363" href="#363">363</a>			<b>final</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a href="/source/s?defs=lastReadHeader&amp;project=rtmp_client">lastReadHeader</a> = <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getLastReadPacketHeader&amp;project=rtmp_client">getLastReadPacketHeader</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>);
<a class="l" name="364" href="#364">364</a>			<b>if</b> (<a href="/source/s?defs=lastReadHeader&amp;project=rtmp_client">lastReadHeader</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; (<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> <b>instanceof</b> <a href="/source/s?defs=AudioData&amp;project=rtmp_client">AudioData</a> || <a href="/source/s?defs=message&amp;project=rtmp_client">message</a> <b>instanceof</b> <a href="/source/s?defs=VideoData&amp;project=rtmp_client">VideoData</a>)
<a class="l" name="365" href="#365">365</a>					&amp;&amp; <a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=compareTimestamps&amp;project=rtmp_client">compareTimestamps</a>(<a href="/source/s?defs=lastReadHeader&amp;project=rtmp_client">lastReadHeader</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>(), <a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a>.<a href="/source/s?defs=getHeader&amp;project=rtmp_client">getHeader</a>().<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>()) &gt;= <span class="n">0</span>) {
<a class="l" name="366" href="#366">366</a><span class="c">//				log.trace("Non-monotonically increasing timestamps; type: {}; adjusting to {}; ts: {}; last: {}", new Object[] { header.getDataType(),</span>
<a class="l" name="367" href="#367">367</a><span class="c">//						lastReadHeader.getTimer() + 1, header.getTimer(), lastReadHeader.getTimer() });</span>
<a class="l" name="368" href="#368">368</a>				<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=setTimestamp&amp;project=rtmp_client">setTimestamp</a>(<a href="/source/s?defs=lastReadHeader&amp;project=rtmp_client">lastReadHeader</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>() + <span class="n">1</span>);
<a class="l" name="369" href="#369">369</a>			} <b>else</b> {
<a class="hl" name="370" href="#370">370</a>				<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=setTimestamp&amp;project=rtmp_client">setTimestamp</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>());
<a class="l" name="371" href="#371">371</a>			}
<a class="l" name="372" href="#372">372</a>			<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setLastReadPacketHeader&amp;project=rtmp_client">setLastReadPacketHeader</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>, <a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a>.<a href="/source/s?defs=getHeader&amp;project=rtmp_client">getHeader</a>());
<a class="l" name="373" href="#373">373</a>
<a class="l" name="374" href="#374">374</a>			<a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a>.<a href="/source/s?defs=setMessage&amp;project=rtmp_client">setMessage</a>(<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="375" href="#375">375</a>
<a class="l" name="376" href="#376">376</a>			<b>if</b> (<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> <b>instanceof</b> <a href="/source/s?defs=ChunkSize&amp;project=rtmp_client">ChunkSize</a>) {
<a class="l" name="377" href="#377">377</a>				<a href="/source/s?defs=ChunkSize&amp;project=rtmp_client">ChunkSize</a> <a href="/source/s?defs=chunkSizeMsg&amp;project=rtmp_client">chunkSizeMsg</a> = (<a href="/source/s?defs=ChunkSize&amp;project=rtmp_client">ChunkSize</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>;
<a class="l" name="378" href="#378">378</a>				<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setReadChunkSize&amp;project=rtmp_client">setReadChunkSize</a>(<a href="/source/s?defs=chunkSizeMsg&amp;project=rtmp_client">chunkSizeMsg</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>());
<a class="l" name="379" href="#379">379</a>			} <b>else</b> <b>if</b> (<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> <b>instanceof</b> <a href="/source/s?defs=Abort&amp;project=rtmp_client">Abort</a>) {
<a class="hl" name="380" href="#380">380</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Abort packet detected"</span>);
<a class="l" name="381" href="#381">381</a>				<span class="c">// The client is aborting a message; reset the packet</span>
<a class="l" name="382" href="#382">382</a>				<span class="c">// because the next chunk on that stream will start a new packet.</span>
<a class="l" name="383" href="#383">383</a>				<a href="/source/s?defs=Abort&amp;project=rtmp_client">Abort</a> <a href="/source/s?defs=abort&amp;project=rtmp_client">abort</a> = (<a href="/source/s?defs=Abort&amp;project=rtmp_client">Abort</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>;
<a class="l" name="384" href="#384">384</a>				<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setLastReadPacket&amp;project=rtmp_client">setLastReadPacket</a>(<a href="/source/s?defs=abort&amp;project=rtmp_client">abort</a>.<a href="/source/s?defs=getChannelId&amp;project=rtmp_client">getChannelId</a>(), <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="385" href="#385">385</a>				<a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="386" href="#386">386</a>			}
<a class="l" name="387" href="#387">387</a>			<b>if</b> (<a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a>.<a href="/source/s?defs=getHeader&amp;project=rtmp_client">getHeader</a>().<a href="/source/s?defs=isGarbage&amp;project=rtmp_client">isGarbage</a>()) {
<a class="l" name="388" href="#388">388</a>				<span class="c">// discard this packet; this gets rid of the garbage</span>
<a class="l" name="389" href="#389">389</a>				<span class="c">// audio data FP inserts</span>
<a class="hl" name="390" href="#390">390</a><span class="c">//				log.trace("Dropping garbage packet: {}, {}", packet, packet.getHeader());</span>
<a class="l" name="391" href="#391">391</a>				<a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="392" href="#392">392</a>			} <b>else</b> {
<a class="l" name="393" href="#393">393</a>				<span class="c">// collapse the time stamps on the last packet so that it works</span>
<a class="l" name="394" href="#394">394</a>				<span class="c">// right for chunk type 3 later</span>
<a class="l" name="395" href="#395">395</a>				<a class="d" href="#lastHeader">lastHeader</a> = <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getLastReadHeader&amp;project=rtmp_client">getLastReadHeader</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>);
<a class="l" name="396" href="#396">396</a>				<a class="d" href="#lastHeader">lastHeader</a>.<a href="/source/s?defs=setTimerBase&amp;project=rtmp_client">setTimerBase</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>());
<a class="l" name="397" href="#397">397</a>			}
<a class="l" name="398" href="#398">398</a>		} <b>finally</b> {
<a class="l" name="399" href="#399">399</a>			<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setLastReadPacket&amp;project=rtmp_client">setLastReadPacket</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="hl" name="400" href="#400">400</a>		}
<a class="l" name="401" href="#401">401</a>		<b>return</b> <a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a>;
<a class="l" name="402" href="#402">402</a>
<a class="l" name="403" href="#403">403</a>	}
<a class="l" name="404" href="#404">404</a>
<a class="l" name="405" href="#405">405</a>	<span class="c">/**
<a class="l" name="406" href="#406">406</a>	 * Decodes packet header.
<a class="l" name="407" href="#407">407</a>	 *
<a class="l" name="408" href="#408">408</a>	 * <strong>@param</strong> <em>in</em> Input IoBuffer
<a class="l" name="409" href="#409">409</a>	 * <strong>@param</strong> <em>lastHeader</em> Previous header
<a class="hl" name="410" href="#410">410</a>	 * <strong>@return</strong> Decoded header
<a class="l" name="411" href="#411">411</a>	 */</span>
<a class="l" name="412" href="#412">412</a>	<b>public</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xmt" name="decodeHeader"/><a href="/source/s?refs=decodeHeader&amp;project=rtmp_client" class="xmt">decodeHeader</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="lastHeader"/><a href="/source/s?refs=lastHeader&amp;project=rtmp_client" class="xa">lastHeader</a>) {
<a class="l" name="413" href="#413">413</a><span class="c">//		log.debug("decodeHeader - lastHeader: {} buffer: {}", lastHeader, in);</span>
<a class="l" name="414" href="#414">414</a>		<b>byte</b> <a href="/source/s?defs=headerByte&amp;project=rtmp_client">headerByte</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="415" href="#415">415</a>		<b>int</b> <a href="/source/s?defs=headerValue&amp;project=rtmp_client">headerValue</a>;
<a class="l" name="416" href="#416">416</a>		<b>int</b> <a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a> = <span class="n">1</span>;
<a class="l" name="417" href="#417">417</a>		<b>if</b> ((<a href="/source/s?defs=headerByte&amp;project=rtmp_client">headerByte</a> &amp; <span class="n">0x3f</span>) == <span class="n">0</span>) {
<a class="l" name="418" href="#418">418</a>			<span class="c">// Two byte header</span>
<a class="l" name="419" href="#419">419</a>			<a href="/source/s?defs=headerValue&amp;project=rtmp_client">headerValue</a> = (<a href="/source/s?defs=headerByte&amp;project=rtmp_client">headerByte</a> &amp; <span class="n">0xff</span>) &lt;&lt; <span class="n">8</span> | (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xff</span>);
<a class="hl" name="420" href="#420">420</a>			<a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a> = <span class="n">2</span>;
<a class="l" name="421" href="#421">421</a>		} <b>else</b> <b>if</b> ((<a href="/source/s?defs=headerByte&amp;project=rtmp_client">headerByte</a> &amp; <span class="n">0x3f</span>) == <span class="n">1</span>) {
<a class="l" name="422" href="#422">422</a>			<span class="c">// Three byte header</span>
<a class="l" name="423" href="#423">423</a>			<a href="/source/s?defs=headerValue&amp;project=rtmp_client">headerValue</a> = (<a href="/source/s?defs=headerByte&amp;project=rtmp_client">headerByte</a> &amp; <span class="n">0xff</span>) &lt;&lt; <span class="n">16</span> | (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xff</span>) &lt;&lt; <span class="n">8</span> | (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xff</span>);
<a class="l" name="424" href="#424">424</a>			<a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a> = <span class="n">3</span>;
<a class="l" name="425" href="#425">425</a>		} <b>else</b> {
<a class="l" name="426" href="#426">426</a>			<span class="c">// Single byte header</span>
<a class="l" name="427" href="#427">427</a>			<a href="/source/s?defs=headerValue&amp;project=rtmp_client">headerValue</a> = <a href="/source/s?defs=headerByte&amp;project=rtmp_client">headerByte</a> &amp; <span class="n">0xff</span>;
<a class="l" name="428" href="#428">428</a>			<a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a> = <span class="n">1</span>;
<a class="l" name="429" href="#429">429</a>		}
<a class="hl" name="430" href="#430">430</a>		<b>final</b> <b>int</b> <a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a> = <a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=decodeChannelId&amp;project=rtmp_client">decodeChannelId</a>(<a href="/source/s?defs=headerValue&amp;project=rtmp_client">headerValue</a>, <a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a>);
<a class="l" name="431" href="#431">431</a>		<b>final</b> <b>int</b> <a href="/source/s?defs=headerSize&amp;project=rtmp_client">headerSize</a> = <a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=decodeHeaderSize&amp;project=rtmp_client">decodeHeaderSize</a>(<a href="/source/s?defs=headerValue&amp;project=rtmp_client">headerValue</a>, <a href="/source/s?defs=byteCount&amp;project=rtmp_client">byteCount</a>);
<a class="l" name="432" href="#432">432</a>		<a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a href="/source/s?defs=header&amp;project=rtmp_client">header</a> = <b>new</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a>();
<a class="l" name="433" href="#433">433</a>		<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setChannelId&amp;project=rtmp_client">setChannelId</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>);
<a class="l" name="434" href="#434">434</a>		<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setIsGarbage&amp;project=rtmp_client">setIsGarbage</a>(<b>false</b>);
<a class="l" name="435" href="#435">435</a>		<b>if</b> (<a href="/source/s?defs=headerSize&amp;project=rtmp_client">headerSize</a> != <a href="/source/s?defs=HEADER_NEW&amp;project=rtmp_client">HEADER_NEW</a> &amp;&amp; <a class="d" href="#lastHeader">lastHeader</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="436" href="#436">436</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Last header null not new, headerSize: {}, channelId {}"</span>, <a href="/source/s?defs=headerSize&amp;project=rtmp_client">headerSize</a>, <a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>);
<a class="l" name="437" href="#437">437</a>			<span class="c">//this will trigger an error status, which in turn will disconnect the "offending" flash player</span>
<a class="l" name="438" href="#438">438</a>			<span class="c">//preventing a memory leak and bringing the whole server to its knees</span>
<a class="l" name="439" href="#439">439</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="hl" name="440" href="#440">440</a>		}
<a class="l" name="441" href="#441">441</a>		<b>int</b> <a href="/source/s?defs=timeValue&amp;project=rtmp_client">timeValue</a>;
<a class="l" name="442" href="#442">442</a>		<b>switch</b> (<a href="/source/s?defs=headerSize&amp;project=rtmp_client">headerSize</a>) {
<a class="l" name="443" href="#443">443</a>			<b>case</b> <a href="/source/s?defs=HEADER_NEW&amp;project=rtmp_client">HEADER_NEW</a>:
<a class="l" name="444" href="#444">444</a>				<span class="c">// an absolute time value</span>
<a class="l" name="445" href="#445">445</a>				<a href="/source/s?defs=timeValue&amp;project=rtmp_client">timeValue</a> = <a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=readUnsignedMediumInt&amp;project=rtmp_client">readUnsignedMediumInt</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="446" href="#446">446</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setSize&amp;project=rtmp_client">setSize</a>(<a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=readUnsignedMediumInt&amp;project=rtmp_client">readUnsignedMediumInt</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>));
<a class="l" name="447" href="#447">447</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setDataType&amp;project=rtmp_client">setDataType</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>());
<a class="l" name="448" href="#448">448</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setStreamId&amp;project=rtmp_client">setStreamId</a>(<a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=readReverseInt&amp;project=rtmp_client">readReverseInt</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>));
<a class="l" name="449" href="#449">449</a>				<b>if</b> (<a href="/source/s?defs=timeValue&amp;project=rtmp_client">timeValue</a> == <span class="n">0xffffff</span>) {
<a class="hl" name="450" href="#450">450</a>					<a href="/source/s?defs=timeValue&amp;project=rtmp_client">timeValue</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>();
<a class="l" name="451" href="#451">451</a>				}
<a class="l" name="452" href="#452">452</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setTimerBase&amp;project=rtmp_client">setTimerBase</a>(<a href="/source/s?defs=timeValue&amp;project=rtmp_client">timeValue</a>);
<a class="l" name="453" href="#453">453</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setTimerDelta&amp;project=rtmp_client">setTimerDelta</a>(<span class="n">0</span>);
<a class="l" name="454" href="#454">454</a>				<b>break</b>;
<a class="l" name="455" href="#455">455</a>
<a class="l" name="456" href="#456">456</a>			<b>case</b> <a href="/source/s?defs=HEADER_SAME_SOURCE&amp;project=rtmp_client">HEADER_SAME_SOURCE</a>:
<a class="l" name="457" href="#457">457</a>				<span class="c">// a delta time value</span>
<a class="l" name="458" href="#458">458</a>				<a href="/source/s?defs=timeValue&amp;project=rtmp_client">timeValue</a> = <a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=readUnsignedMediumInt&amp;project=rtmp_client">readUnsignedMediumInt</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="459" href="#459">459</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setSize&amp;project=rtmp_client">setSize</a>(<a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=readUnsignedMediumInt&amp;project=rtmp_client">readUnsignedMediumInt</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>));
<a class="hl" name="460" href="#460">460</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setDataType&amp;project=rtmp_client">setDataType</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>());
<a class="l" name="461" href="#461">461</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setStreamId&amp;project=rtmp_client">setStreamId</a>(<a class="d" href="#lastHeader">lastHeader</a>.<a href="/source/s?defs=getStreamId&amp;project=rtmp_client">getStreamId</a>());
<a class="l" name="462" href="#462">462</a>				<b>if</b> (<a href="/source/s?defs=timeValue&amp;project=rtmp_client">timeValue</a> == <span class="n">0xffffff</span>) {
<a class="l" name="463" href="#463">463</a>					<a href="/source/s?defs=timeValue&amp;project=rtmp_client">timeValue</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>();
<a class="l" name="464" href="#464">464</a>				} <b>else</b> <b>if</b> (<a href="/source/s?defs=timeValue&amp;project=rtmp_client">timeValue</a> == <span class="n">0</span> &amp;&amp; <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>() == <a href="/source/s?defs=TYPE_AUDIO_DATA&amp;project=rtmp_client">TYPE_AUDIO_DATA</a>) {
<a class="l" name="465" href="#465">465</a>					<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setIsGarbage&amp;project=rtmp_client">setIsGarbage</a>(<b>true</b>);
<a class="l" name="466" href="#466">466</a><span class="c">//					log.trace("Audio with zero delta; setting to garbage; ChannelId: {}; DataType: {}; HeaderSize: {}", new Object[] { header.getChannelId(), header.getDataType(),</span>
<a class="l" name="467" href="#467">467</a><span class="c">//							headerSize });</span>
<a class="l" name="468" href="#468">468</a>				}
<a class="l" name="469" href="#469">469</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setTimerBase&amp;project=rtmp_client">setTimerBase</a>(<a class="d" href="#lastHeader">lastHeader</a>.<a href="/source/s?defs=getTimerBase&amp;project=rtmp_client">getTimerBase</a>());
<a class="hl" name="470" href="#470">470</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setTimerDelta&amp;project=rtmp_client">setTimerDelta</a>(<a href="/source/s?defs=timeValue&amp;project=rtmp_client">timeValue</a>);
<a class="l" name="471" href="#471">471</a>				<b>break</b>;
<a class="l" name="472" href="#472">472</a>
<a class="l" name="473" href="#473">473</a>			<b>case</b> <a href="/source/s?defs=HEADER_TIMER_CHANGE&amp;project=rtmp_client">HEADER_TIMER_CHANGE</a>:
<a class="l" name="474" href="#474">474</a>				<span class="c">// a delta time value</span>
<a class="l" name="475" href="#475">475</a>				<a href="/source/s?defs=timeValue&amp;project=rtmp_client">timeValue</a> = <a href="/source/s?defs=RTMPUtils&amp;project=rtmp_client">RTMPUtils</a>.<a href="/source/s?defs=readUnsignedMediumInt&amp;project=rtmp_client">readUnsignedMediumInt</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="476" href="#476">476</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setSize&amp;project=rtmp_client">setSize</a>(<a class="d" href="#lastHeader">lastHeader</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>());
<a class="l" name="477" href="#477">477</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setDataType&amp;project=rtmp_client">setDataType</a>(<a class="d" href="#lastHeader">lastHeader</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>());
<a class="l" name="478" href="#478">478</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setStreamId&amp;project=rtmp_client">setStreamId</a>(<a class="d" href="#lastHeader">lastHeader</a>.<a href="/source/s?defs=getStreamId&amp;project=rtmp_client">getStreamId</a>());
<a class="l" name="479" href="#479">479</a>				<b>if</b> (<a href="/source/s?defs=timeValue&amp;project=rtmp_client">timeValue</a> == <span class="n">0xffffff</span>) {
<a class="hl" name="480" href="#480">480</a>					<a href="/source/s?defs=timeValue&amp;project=rtmp_client">timeValue</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>();
<a class="l" name="481" href="#481">481</a>				} <b>else</b> <b>if</b> (<a href="/source/s?defs=timeValue&amp;project=rtmp_client">timeValue</a> == <span class="n">0</span> &amp;&amp; <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>() == <a href="/source/s?defs=TYPE_AUDIO_DATA&amp;project=rtmp_client">TYPE_AUDIO_DATA</a>) {
<a class="l" name="482" href="#482">482</a>					<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setIsGarbage&amp;project=rtmp_client">setIsGarbage</a>(<b>true</b>);
<a class="l" name="483" href="#483">483</a><span class="c">//					log.trace("Audio with zero delta; setting to garbage; ChannelId: {}; DataType: {}; HeaderSize: {}", new Object[] { header.getChannelId(), header.getDataType(),</span>
<a class="l" name="484" href="#484">484</a><span class="c">//							headerSize });</span>
<a class="l" name="485" href="#485">485</a>				}
<a class="l" name="486" href="#486">486</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setTimerBase&amp;project=rtmp_client">setTimerBase</a>(<a class="d" href="#lastHeader">lastHeader</a>.<a href="/source/s?defs=getTimerBase&amp;project=rtmp_client">getTimerBase</a>());
<a class="l" name="487" href="#487">487</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setTimerDelta&amp;project=rtmp_client">setTimerDelta</a>(<a href="/source/s?defs=timeValue&amp;project=rtmp_client">timeValue</a>);
<a class="l" name="488" href="#488">488</a>				<b>break</b>;
<a class="l" name="489" href="#489">489</a>
<a class="hl" name="490" href="#490">490</a>			<b>case</b> <a href="/source/s?defs=HEADER_CONTINUE&amp;project=rtmp_client">HEADER_CONTINUE</a>:
<a class="l" name="491" href="#491">491</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setSize&amp;project=rtmp_client">setSize</a>(<a class="d" href="#lastHeader">lastHeader</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>());
<a class="l" name="492" href="#492">492</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setDataType&amp;project=rtmp_client">setDataType</a>(<a class="d" href="#lastHeader">lastHeader</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>());
<a class="l" name="493" href="#493">493</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setStreamId&amp;project=rtmp_client">setStreamId</a>(<a class="d" href="#lastHeader">lastHeader</a>.<a href="/source/s?defs=getStreamId&amp;project=rtmp_client">getStreamId</a>());
<a class="l" name="494" href="#494">494</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setTimerBase&amp;project=rtmp_client">setTimerBase</a>(<a class="d" href="#lastHeader">lastHeader</a>.<a href="/source/s?defs=getTimerBase&amp;project=rtmp_client">getTimerBase</a>());
<a class="l" name="495" href="#495">495</a>				<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=setTimerDelta&amp;project=rtmp_client">setTimerDelta</a>(<a class="d" href="#lastHeader">lastHeader</a>.<a href="/source/s?defs=getTimerDelta&amp;project=rtmp_client">getTimerDelta</a>());
<a class="l" name="496" href="#496">496</a>				<b>break</b>;
<a class="l" name="497" href="#497">497</a>
<a class="l" name="498" href="#498">498</a>			<b>default</b>:
<a class="l" name="499" href="#499">499</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Unexpected header size: {}"</span>, <a href="/source/s?defs=headerSize&amp;project=rtmp_client">headerSize</a>);
<a class="hl" name="500" href="#500">500</a>				<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="501" href="#501">501</a>		}
<a class="l" name="502" href="#502">502</a><span class="c">//		log.trace("CHUNK, D, {}, {}", header, headerSize);</span>
<a class="l" name="503" href="#503">503</a>		<b>return</b> <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>;
<a class="l" name="504" href="#504">504</a>	}
<a class="l" name="505" href="#505">505</a>
<a class="l" name="506" href="#506">506</a>	<span class="c">/**
<a class="l" name="507" href="#507">507</a>	 * Decodes RTMP message event.
<a class="l" name="508" href="#508">508</a>	 *
<a class="l" name="509" href="#509">509</a>	 * <strong>@param</strong> <em>rtmp</em> RTMP protocol state
<a class="hl" name="510" href="#510">510</a>	 * <strong>@param</strong> <em>header</em> RTMP header
<a class="l" name="511" href="#511">511</a>	 * <strong>@param</strong> <em>in</em> Input IoBuffer
<a class="l" name="512" href="#512">512</a>	 * <strong>@return</strong> RTMP event
<a class="l" name="513" href="#513">513</a>	 */</span>
<a class="l" name="514" href="#514">514</a>	<b>public</b> <a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a> <a class="xmt" name="decodeMessage"/><a href="/source/s?refs=decodeMessage&amp;project=rtmp_client" class="xmt">decodeMessage</a>(<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xa">header</a>, <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="515" href="#515">515</a>		<a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a> <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>;
<a class="l" name="516" href="#516">516</a>		<b>byte</b> <a class="d" href="#dataType">dataType</a> = <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>();
<a class="l" name="517" href="#517">517</a>		<b>switch</b> (<a class="d" href="#dataType">dataType</a>) {
<a class="l" name="518" href="#518">518</a>			<b>case</b> <a href="/source/s?defs=TYPE_CHUNK_SIZE&amp;project=rtmp_client">TYPE_CHUNK_SIZE</a>:
<a class="l" name="519" href="#519">519</a>				<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#decodeChunkSize">decodeChunkSize</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="hl" name="520" href="#520">520</a>				<b>break</b>;
<a class="l" name="521" href="#521">521</a>			<b>case</b> <a href="/source/s?defs=TYPE_ABORT&amp;project=rtmp_client">TYPE_ABORT</a>:
<a class="l" name="522" href="#522">522</a>				<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#decodeAbort">decodeAbort</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="523" href="#523">523</a>				<b>break</b>;
<a class="l" name="524" href="#524">524</a>			<b>case</b> <a href="/source/s?defs=TYPE_INVOKE&amp;project=rtmp_client">TYPE_INVOKE</a>:
<a class="l" name="525" href="#525">525</a>				<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#decodeInvoke">decodeInvoke</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="526" href="#526">526</a>				<b>break</b>;
<a class="l" name="527" href="#527">527</a>			<b>case</b> <a href="/source/s?defs=TYPE_NOTIFY&amp;project=rtmp_client">TYPE_NOTIFY</a>:
<a class="l" name="528" href="#528">528</a>				<b>if</b> (<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getStreamId&amp;project=rtmp_client">getStreamId</a>() == <span class="n">0</span>) {
<a class="l" name="529" href="#529">529</a>					<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a href="/source/s?defs=decodeNotify&amp;project=rtmp_client">decodeNotify</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="hl" name="530" href="#530">530</a>				} <b>else</b> {
<a class="l" name="531" href="#531">531</a>					<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#decodeStreamMetadata">decodeStreamMetadata</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="532" href="#532">532</a>				}
<a class="l" name="533" href="#533">533</a>				<b>break</b>;
<a class="l" name="534" href="#534">534</a>			<b>case</b> <a href="/source/s?defs=TYPE_PING&amp;project=rtmp_client">TYPE_PING</a>:
<a class="l" name="535" href="#535">535</a>				<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#decodePing">decodePing</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="536" href="#536">536</a>				<b>break</b>;
<a class="l" name="537" href="#537">537</a>			<b>case</b> <a href="/source/s?defs=TYPE_BYTES_READ&amp;project=rtmp_client">TYPE_BYTES_READ</a>:
<a class="l" name="538" href="#538">538</a>				<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#decodeBytesRead">decodeBytesRead</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="539" href="#539">539</a>				<b>break</b>;
<a class="hl" name="540" href="#540">540</a>			<b>case</b> <a href="/source/s?defs=TYPE_AUDIO_DATA&amp;project=rtmp_client">TYPE_AUDIO_DATA</a>:
<a class="l" name="541" href="#541">541</a>				<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#decodeAudioData">decodeAudioData</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="542" href="#542">542</a>				<b>break</b>;
<a class="l" name="543" href="#543">543</a>			<b>case</b> <a href="/source/s?defs=TYPE_VIDEO_DATA&amp;project=rtmp_client">TYPE_VIDEO_DATA</a>:
<a class="l" name="544" href="#544">544</a>				<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#decodeVideoData">decodeVideoData</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="545" href="#545">545</a>				<b>break</b>;
<a class="l" name="546" href="#546">546</a>			<b>case</b> <a href="/source/s?defs=TYPE_FLEX_SHARED_OBJECT&amp;project=rtmp_client">TYPE_FLEX_SHARED_OBJECT</a>:
<a class="l" name="547" href="#547">547</a>				<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#decodeFlexSharedObject">decodeFlexSharedObject</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="548" href="#548">548</a>				<b>break</b>;
<a class="l" name="549" href="#549">549</a>			<b>case</b> <a href="/source/s?defs=TYPE_SHARED_OBJECT&amp;project=rtmp_client">TYPE_SHARED_OBJECT</a>:
<a class="hl" name="550" href="#550">550</a>				<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#decodeSharedObject">decodeSharedObject</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="551" href="#551">551</a>				<b>break</b>;
<a class="l" name="552" href="#552">552</a>			<b>case</b> <a href="/source/s?defs=TYPE_SERVER_BANDWIDTH&amp;project=rtmp_client">TYPE_SERVER_BANDWIDTH</a>:
<a class="l" name="553" href="#553">553</a>				<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#decodeServerBW">decodeServerBW</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="554" href="#554">554</a>				<b>break</b>;
<a class="l" name="555" href="#555">555</a>			<b>case</b> <a href="/source/s?defs=TYPE_CLIENT_BANDWIDTH&amp;project=rtmp_client">TYPE_CLIENT_BANDWIDTH</a>:
<a class="l" name="556" href="#556">556</a>				<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#decodeClientBW">decodeClientBW</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="557" href="#557">557</a>				<b>break</b>;
<a class="l" name="558" href="#558">558</a>			<b>case</b> <a href="/source/s?defs=TYPE_FLEX_MESSAGE&amp;project=rtmp_client">TYPE_FLEX_MESSAGE</a>:
<a class="l" name="559" href="#559">559</a>				<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#decodeFlexMessage">decodeFlexMessage</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="hl" name="560" href="#560">560</a>				<b>break</b>;
<a class="l" name="561" href="#561">561</a>			<b>case</b> <a href="/source/s?defs=TYPE_FLEX_STREAM_SEND&amp;project=rtmp_client">TYPE_FLEX_STREAM_SEND</a>:
<a class="l" name="562" href="#562">562</a>				<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#decodeFlexStreamSend">decodeFlexStreamSend</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="563" href="#563">563</a>				<b>break</b>;
<a class="l" name="564" href="#564">564</a>			<b>case</b> <a href="/source/s?defs=TYPE_AGGREGATE&amp;project=rtmp_client">TYPE_AGGREGATE</a>:
<a class="l" name="565" href="#565">565</a>				<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#decodeAggregate">decodeAggregate</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="566" href="#566">566</a>				<b>break</b>;
<a class="l" name="567" href="#567">567</a>			<b>default</b>:
<a class="l" name="568" href="#568">568</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Unknown object type: {}"</span>, <a class="d" href="#dataType">dataType</a>);
<a class="l" name="569" href="#569">569</a>				<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#decodeUnknown">decodeUnknown</a>(<a class="d" href="#dataType">dataType</a>, <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="hl" name="570" href="#570">570</a>				<b>break</b>;
<a class="l" name="571" href="#571">571</a>		}
<a class="l" name="572" href="#572">572</a>		<b>return</b> <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>;
<a class="l" name="573" href="#573">573</a>	}
<a class="l" name="574" href="#574">574</a>
<a class="l" name="575" href="#575">575</a>	<b>public</b> <a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a> <a class="xmt" name="decodeAbort"/><a href="/source/s?refs=decodeAbort&amp;project=rtmp_client" class="xmt">decodeAbort</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="576" href="#576">576</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=Abort&amp;project=rtmp_client">Abort</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>());
<a class="l" name="577" href="#577">577</a>	}
<a class="l" name="578" href="#578">578</a>
<a class="l" name="579" href="#579">579</a>	<span class="c">/**
<a class="hl" name="580" href="#580">580</a>	 * Decodes server bandwidth.
<a class="l" name="581" href="#581">581</a>	 *
<a class="l" name="582" href="#582">582</a>	 * <strong>@param</strong> <em>in</em> IoBuffer
<a class="l" name="583" href="#583">583</a>	 * <strong>@return</strong> RTMP event
<a class="l" name="584" href="#584">584</a>	 */</span>
<a class="l" name="585" href="#585">585</a>	<b>private</b> <a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a> <a class="xmt" name="decodeServerBW"/><a href="/source/s?refs=decodeServerBW&amp;project=rtmp_client" class="xmt">decodeServerBW</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="586" href="#586">586</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=ServerBW&amp;project=rtmp_client">ServerBW</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>());
<a class="l" name="587" href="#587">587</a>	}
<a class="l" name="588" href="#588">588</a>
<a class="l" name="589" href="#589">589</a>	<span class="c">/**
<a class="hl" name="590" href="#590">590</a>	 * Decodes client bandwidth.
<a class="l" name="591" href="#591">591</a>	 *
<a class="l" name="592" href="#592">592</a>	 * <strong>@param</strong> <em>in</em>
<a class="l" name="593" href="#593">593</a>	 *            Byte buffer
<a class="l" name="594" href="#594">594</a>	 * <strong>@return</strong> RTMP event
<a class="l" name="595" href="#595">595</a>	 */</span>
<a class="l" name="596" href="#596">596</a>	<b>private</b> <a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a> <a class="xmt" name="decodeClientBW"/><a href="/source/s?refs=decodeClientBW&amp;project=rtmp_client" class="xmt">decodeClientBW</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="597" href="#597">597</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=ClientBW&amp;project=rtmp_client">ClientBW</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>(), <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>());
<a class="l" name="598" href="#598">598</a>	}
<a class="l" name="599" href="#599">599</a>
<a class="hl" name="600" href="#600">600</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="601" href="#601">601</a>	<b>public</b> <a href="/source/s?defs=Unknown&amp;project=rtmp_client">Unknown</a> <a class="xmt" name="decodeUnknown"/><a href="/source/s?refs=decodeUnknown&amp;project=rtmp_client" class="xmt">decodeUnknown</a>(<b>byte</b> <a class="xa" name="dataType"/><a href="/source/s?refs=dataType&amp;project=rtmp_client" class="xa">dataType</a>, <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="602" href="#602">602</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=Unknown&amp;project=rtmp_client">Unknown</a>(<a class="d" href="#dataType">dataType</a>, <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="603" href="#603">603</a>	}
<a class="l" name="604" href="#604">604</a>
<a class="l" name="605" href="#605">605</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="606" href="#606">606</a>	<b>public</b> <a href="/source/s?defs=Aggregate&amp;project=rtmp_client">Aggregate</a> <a class="xmt" name="decodeAggregate"/><a href="/source/s?refs=decodeAggregate&amp;project=rtmp_client" class="xmt">decodeAggregate</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="607" href="#607">607</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=Aggregate&amp;project=rtmp_client">Aggregate</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="608" href="#608">608</a>	}
<a class="l" name="609" href="#609">609</a>
<a class="hl" name="610" href="#610">610</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="611" href="#611">611</a>	<b>public</b> <a href="/source/s?defs=ChunkSize&amp;project=rtmp_client">ChunkSize</a> <a class="xmt" name="decodeChunkSize"/><a href="/source/s?refs=decodeChunkSize&amp;project=rtmp_client" class="xmt">decodeChunkSize</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="612" href="#612">612</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=ChunkSize&amp;project=rtmp_client">ChunkSize</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>());
<a class="l" name="613" href="#613">613</a>	}
<a class="l" name="614" href="#614">614</a>
<a class="l" name="615" href="#615">615</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="616" href="#616">616</a>	<b>public</b> <a href="/source/s?defs=ISharedObjectMessage&amp;project=rtmp_client">ISharedObjectMessage</a> <a class="xmt" name="decodeFlexSharedObject"/><a href="/source/s?refs=decodeFlexSharedObject&amp;project=rtmp_client" class="xmt">decodeFlexSharedObject</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>) {
<a class="l" name="617" href="#617">617</a>		<b>byte</b> <a href="/source/s?defs=encoding&amp;project=rtmp_client">encoding</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="618" href="#618">618</a>		<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a> <a class="d" href="#input">input</a>;
<a class="l" name="619" href="#619">619</a>		<b>if</b> (<a href="/source/s?defs=encoding&amp;project=rtmp_client">encoding</a> == <span class="n">0</span>) {
<a class="hl" name="620" href="#620">620</a>			<a class="d" href="#input">input</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="621" href="#621">621</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=encoding&amp;project=rtmp_client">encoding</a> == <span class="n">3</span>) {
<a class="l" name="622" href="#622">622</a>			<a class="d" href="#input">input</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="623" href="#623">623</a>		} <b>else</b> {
<a class="l" name="624" href="#624">624</a>			<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"Unknown SO encoding: "</span> + <a href="/source/s?defs=encoding&amp;project=rtmp_client">encoding</a>);
<a class="l" name="625" href="#625">625</a>		}
<a class="l" name="626" href="#626">626</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=name&amp;project=rtmp_client">name</a> = <a class="d" href="#input">input</a>.<a href="/source/s?defs=getString&amp;project=rtmp_client">getString</a>();
<a class="l" name="627" href="#627">627</a>		<span class="c">// Read version of SO to modify</span>
<a class="l" name="628" href="#628">628</a>		<b>int</b> <a href="/source/s?defs=version&amp;project=rtmp_client">version</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>();
<a class="l" name="629" href="#629">629</a>		<span class="c">// Read persistence informations</span>
<a class="hl" name="630" href="#630">630</a>		<b>boolean</b> <a href="/source/s?defs=persistent&amp;project=rtmp_client">persistent</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>() == <span class="n">2</span>;
<a class="l" name="631" href="#631">631</a>		<span class="c">// Skip unknown bytes</span>
<a class="l" name="632" href="#632">632</a>		<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=skip&amp;project=rtmp_client">skip</a>(<span class="n">4</span>);
<a class="l" name="633" href="#633">633</a>
<a class="l" name="634" href="#634">634</a>		<b>final</b> <a href="/source/s?defs=SharedObjectMessage&amp;project=rtmp_client">SharedObjectMessage</a> <a class="d" href="#so">so</a> = <b>new</b> <a href="/source/s?defs=FlexSharedObjectMessage&amp;project=rtmp_client">FlexSharedObjectMessage</a>(<a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=version&amp;project=rtmp_client">version</a>, <a href="/source/s?defs=persistent&amp;project=rtmp_client">persistent</a>);
<a class="l" name="635" href="#635">635</a>		<a class="d" href="#doDecodeSharedObject">doDecodeSharedObject</a>(<a class="d" href="#so">so</a>, <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>, <a class="d" href="#input">input</a>);
<a class="l" name="636" href="#636">636</a>		<b>return</b> <a class="d" href="#so">so</a>;
<a class="l" name="637" href="#637">637</a>	}
<a class="l" name="638" href="#638">638</a>
<a class="l" name="639" href="#639">639</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="640" href="#640">640</a>	<b>public</b> <a href="/source/s?defs=ISharedObjectMessage&amp;project=rtmp_client">ISharedObjectMessage</a> <a class="xmt" name="decodeSharedObject"/><a href="/source/s?refs=decodeSharedObject&amp;project=rtmp_client" class="xmt">decodeSharedObject</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>) {
<a class="l" name="641" href="#641">641</a>		<b>final</b> <a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a> <a class="d" href="#input">input</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="642" href="#642">642</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=name&amp;project=rtmp_client">name</a> = <a class="d" href="#input">input</a>.<a href="/source/s?defs=getString&amp;project=rtmp_client">getString</a>();
<a class="l" name="643" href="#643">643</a>		<span class="c">// Read version of SO to modify</span>
<a class="l" name="644" href="#644">644</a>		<b>int</b> <a href="/source/s?defs=version&amp;project=rtmp_client">version</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>();
<a class="l" name="645" href="#645">645</a>		<span class="c">// Read persistence informations</span>
<a class="l" name="646" href="#646">646</a>		<b>boolean</b> <a href="/source/s?defs=persistent&amp;project=rtmp_client">persistent</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>() == <span class="n">2</span>;
<a class="l" name="647" href="#647">647</a>		<span class="c">// Skip unknown bytes</span>
<a class="l" name="648" href="#648">648</a>		<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=skip&amp;project=rtmp_client">skip</a>(<span class="n">4</span>);
<a class="l" name="649" href="#649">649</a>
<a class="hl" name="650" href="#650">650</a>		<b>final</b> <a href="/source/s?defs=SharedObjectMessage&amp;project=rtmp_client">SharedObjectMessage</a> <a class="d" href="#so">so</a> = <b>new</b> <a href="/source/s?defs=FlexSharedObjectMessage&amp;project=rtmp_client">FlexSharedObjectMessage</a>(<a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=version&amp;project=rtmp_client">version</a>, <a href="/source/s?defs=persistent&amp;project=rtmp_client">persistent</a>);
<a class="l" name="651" href="#651">651</a>		<a class="d" href="#doDecodeSharedObject">doDecodeSharedObject</a>(<a class="d" href="#so">so</a>, <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>, <a class="d" href="#input">input</a>);
<a class="l" name="652" href="#652">652</a>		<b>return</b> <a class="d" href="#so">so</a>;
<a class="l" name="653" href="#653">653</a>	}
<a class="l" name="654" href="#654">654</a>
<a class="l" name="655" href="#655">655</a>	<span class="c">/**
<a class="l" name="656" href="#656">656</a>	 * Perform the actual decoding of the shared object contents.
<a class="l" name="657" href="#657">657</a>	 *
<a class="l" name="658" href="#658">658</a>	 * <strong>@param</strong> <em>so</em>
<a class="l" name="659" href="#659">659</a>	 * <strong>@param</strong> <em>in</em>
<a class="hl" name="660" href="#660">660</a>	 * <strong>@param</strong> <em>input</em>
<a class="l" name="661" href="#661">661</a>	 */</span>
<a class="l" name="662" href="#662">662</a>	<b>protected</b> <b>void</b> <a class="xmt" name="doDecodeSharedObject"/><a href="/source/s?refs=doDecodeSharedObject&amp;project=rtmp_client" class="xmt">doDecodeSharedObject</a>(<a href="/source/s?defs=SharedObjectMessage&amp;project=rtmp_client">SharedObjectMessage</a> <a class="xa" name="so"/><a href="/source/s?refs=so&amp;project=rtmp_client" class="xa">so</a>, <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>, <a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a> <a class="xa" name="input"/><a href="/source/s?refs=input&amp;project=rtmp_client" class="xa">input</a>) {
<a class="l" name="663" href="#663">663</a>		<span class="c">// Parse request body</span>
<a class="l" name="664" href="#664">664</a>		<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a> <a href="/source/s?defs=amf3Input&amp;project=rtmp_client">amf3Input</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="665" href="#665">665</a>		<b>while</b> (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=hasRemaining&amp;project=rtmp_client">hasRemaining</a>()) {
<a class="l" name="666" href="#666">666</a>			<b>final</b> <a href="/source/s?defs=ISharedObjectEvent&amp;project=rtmp_client">ISharedObjectEvent</a>.<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a> <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> = <a href="/source/s?defs=SharedObjectTypeMapping&amp;project=rtmp_client">SharedObjectTypeMapping</a>.<a href="/source/s?defs=toType&amp;project=rtmp_client">toType</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>());
<a class="l" name="667" href="#667">667</a>			<b>if</b> (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="668" href="#668">668</a>				<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=skip&amp;project=rtmp_client">skip</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>());
<a class="l" name="669" href="#669">669</a>				<b>return</b>;
<a class="hl" name="670" href="#670">670</a>			}
<a class="l" name="671" href="#671">671</a>			<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=key&amp;project=rtmp_client">key</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="672" href="#672">672</a>			<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="673" href="#673">673</a>
<a class="l" name="674" href="#674">674</a>			<span class="c">// if(log.isDebugEnabled())</span>
<a class="l" name="675" href="#675">675</a>			<span class="c">// log.debug("type: "+SharedObjectTypeMapping.toString(type));</span>
<a class="l" name="676" href="#676">676</a>
<a class="l" name="677" href="#677">677</a>			<span class="c">// SharedObjectEvent event = new SharedObjectEvent(,null,null);</span>
<a class="l" name="678" href="#678">678</a>			<b>final</b> <b>int</b> <a href="/source/s?defs=length&amp;project=rtmp_client">length</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>();
<a class="l" name="679" href="#679">679</a>			<b>if</b> (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> == <a href="/source/s?defs=ISharedObjectEvent&amp;project=rtmp_client">ISharedObjectEvent</a>.<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_STATUS&amp;project=rtmp_client">CLIENT_STATUS</a>) {
<a class="hl" name="680" href="#680">680</a>				<span class="c">// Status code</span>
<a class="l" name="681" href="#681">681</a>				<a href="/source/s?defs=key&amp;project=rtmp_client">key</a> = <a class="d" href="#input">input</a>.<a href="/source/s?defs=getString&amp;project=rtmp_client">getString</a>();
<a class="l" name="682" href="#682">682</a>				<span class="c">// Status level</span>
<a class="l" name="683" href="#683">683</a>				<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a class="d" href="#input">input</a>.<a href="/source/s?defs=getString&amp;project=rtmp_client">getString</a>();
<a class="l" name="684" href="#684">684</a>			} <b>else</b> <b>if</b> (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> == <a href="/source/s?defs=ISharedObjectEvent&amp;project=rtmp_client">ISharedObjectEvent</a>.<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_UPDATE_DATA&amp;project=rtmp_client">CLIENT_UPDATE_DATA</a>) {
<a class="l" name="685" href="#685">685</a>				<a href="/source/s?defs=key&amp;project=rtmp_client">key</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="686" href="#686">686</a>				<span class="c">// Map containing new attribute values</span>
<a class="l" name="687" href="#687">687</a>				<b>final</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=map&amp;project=rtmp_client">map</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="l" name="688" href="#688">688</a>				<b>final</b> <b>int</b> <a href="/source/s?defs=start&amp;project=rtmp_client">start</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>();
<a class="l" name="689" href="#689">689</a>				<b>while</b> (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() - <a href="/source/s?defs=start&amp;project=rtmp_client">start</a> &lt; <a href="/source/s?defs=length&amp;project=rtmp_client">length</a>) {
<a class="hl" name="690" href="#690">690</a>					<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a> = <a class="d" href="#input">input</a>.<a href="/source/s?defs=getString&amp;project=rtmp_client">getString</a>();
<a class="l" name="691" href="#691">691</a>					<a href="/source/s?defs=map&amp;project=rtmp_client">map</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a>, <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<a class="d" href="#input">input</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>.<b>class</b>));
<a class="l" name="692" href="#692">692</a>				}
<a class="l" name="693" href="#693">693</a>				<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a href="/source/s?defs=map&amp;project=rtmp_client">map</a>;
<a class="l" name="694" href="#694">694</a>			} <b>else</b> <b>if</b> (<a href="/source/s?defs=type&amp;project=rtmp_client">type</a> != <a href="/source/s?defs=ISharedObjectEvent&amp;project=rtmp_client">ISharedObjectEvent</a>.<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=SERVER_SEND_MESSAGE&amp;project=rtmp_client">SERVER_SEND_MESSAGE</a> &amp;&amp; <a href="/source/s?defs=type&amp;project=rtmp_client">type</a> != <a href="/source/s?defs=ISharedObjectEvent&amp;project=rtmp_client">ISharedObjectEvent</a>.<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_SEND_MESSAGE&amp;project=rtmp_client">CLIENT_SEND_MESSAGE</a>) {
<a class="l" name="695" href="#695">695</a>				<b>if</b> (<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> &gt; <span class="n">0</span>) {
<a class="l" name="696" href="#696">696</a>					<a href="/source/s?defs=key&amp;project=rtmp_client">key</a> = <a class="d" href="#input">input</a>.<a href="/source/s?defs=getString&amp;project=rtmp_client">getString</a>();
<a class="l" name="697" href="#697">697</a>					<b>if</b> (<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> &gt; <a href="/source/s?defs=key&amp;project=rtmp_client">key</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>() + <span class="n">2</span>) {
<a class="l" name="698" href="#698">698</a>						<span class="c">// FIXME workaround for player version &gt;= 9.0.115.0</span>
<a class="l" name="699" href="#699">699</a>						<b>byte</b> <a href="/source/s?defs=objType&amp;project=rtmp_client">objType</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="hl" name="700" href="#700">700</a>						<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() - <span class="n">1</span>);
<a class="l" name="701" href="#701">701</a>						<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a> <a href="/source/s?defs=propertyInput&amp;project=rtmp_client">propertyInput</a>;
<a class="l" name="702" href="#702">702</a>						<b>if</b> (<a href="/source/s?defs=objType&amp;project=rtmp_client">objType</a> == <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_AMF3_OBJECT&amp;project=rtmp_client">TYPE_AMF3_OBJECT</a> &amp;&amp; !(<a class="d" href="#input">input</a> <b>instanceof</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>)) {
<a class="l" name="703" href="#703">703</a>							<span class="c">// The next parameter is encoded using AMF3</span>
<a class="l" name="704" href="#704">704</a>							<a href="/source/s?defs=propertyInput&amp;project=rtmp_client">propertyInput</a> = <a href="/source/s?defs=amf3Input&amp;project=rtmp_client">amf3Input</a>;
<a class="l" name="705" href="#705">705</a>						} <b>else</b> {
<a class="l" name="706" href="#706">706</a>							<span class="c">// The next parameter is encoded using AMF0</span>
<a class="l" name="707" href="#707">707</a>							<a href="/source/s?defs=propertyInput&amp;project=rtmp_client">propertyInput</a> = <a class="d" href="#input">input</a>;
<a class="l" name="708" href="#708">708</a>						}
<a class="l" name="709" href="#709">709</a>						<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<a href="/source/s?defs=propertyInput&amp;project=rtmp_client">propertyInput</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>.<b>class</b>);
<a class="hl" name="710" href="#710">710</a>					}
<a class="l" name="711" href="#711">711</a>				}
<a class="l" name="712" href="#712">712</a>			} <b>else</b> {
<a class="l" name="713" href="#713">713</a>				<b>final</b> <b>int</b> <a href="/source/s?defs=start&amp;project=rtmp_client">start</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>();
<a class="l" name="714" href="#714">714</a>				<span class="c">// the "send" event seems to encode the handler name</span>
<a class="l" name="715" href="#715">715</a>				<span class="c">// as complete AMF string including the string type byte</span>
<a class="l" name="716" href="#716">716</a>				<a href="/source/s?defs=key&amp;project=rtmp_client">key</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<a class="d" href="#input">input</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>);
<a class="l" name="717" href="#717">717</a>
<a class="l" name="718" href="#718">718</a>				<span class="c">// read parameters</span>
<a class="l" name="719" href="#719">719</a>				<b>final</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=list&amp;project=rtmp_client">list</a> = <b>new</b> <a href="/source/s?defs=LinkedList&amp;project=rtmp_client">LinkedList</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="hl" name="720" href="#720">720</a>				<span class="c">// while loop changed for JIRA CODECS-9</span>
<a class="l" name="721" href="#721">721</a>				<b>while</b> (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() - <a href="/source/s?defs=start&amp;project=rtmp_client">start</a> &lt; <a href="/source/s?defs=length&amp;project=rtmp_client">length</a>) {
<a class="l" name="722" href="#722">722</a>					<b>byte</b> <a href="/source/s?defs=objType&amp;project=rtmp_client">objType</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="723" href="#723">723</a>					<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() - <span class="n">1</span>);
<a class="l" name="724" href="#724">724</a>					<span class="c">// FIXME workaround for player version &gt;= 9.0.115.0</span>
<a class="l" name="725" href="#725">725</a>					<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a> <a href="/source/s?defs=propertyInput&amp;project=rtmp_client">propertyInput</a>;
<a class="l" name="726" href="#726">726</a>					<b>if</b> (<a href="/source/s?defs=objType&amp;project=rtmp_client">objType</a> == <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_AMF3_OBJECT&amp;project=rtmp_client">TYPE_AMF3_OBJECT</a> &amp;&amp; !(<a class="d" href="#input">input</a> <b>instanceof</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>)) {
<a class="l" name="727" href="#727">727</a>						<span class="c">// The next parameter is encoded using AMF3</span>
<a class="l" name="728" href="#728">728</a>						<a href="/source/s?defs=propertyInput&amp;project=rtmp_client">propertyInput</a> = <a href="/source/s?defs=amf3Input&amp;project=rtmp_client">amf3Input</a>;
<a class="l" name="729" href="#729">729</a>					} <b>else</b> {
<a class="hl" name="730" href="#730">730</a>						<span class="c">// The next parameter is encoded using AMF0</span>
<a class="l" name="731" href="#731">731</a>						<a href="/source/s?defs=propertyInput&amp;project=rtmp_client">propertyInput</a> = <a class="d" href="#input">input</a>;
<a class="l" name="732" href="#732">732</a>					}
<a class="l" name="733" href="#733">733</a>					<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<a href="/source/s?defs=propertyInput&amp;project=rtmp_client">propertyInput</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>.<b>class</b>);
<a class="l" name="734" href="#734">734</a>					<a href="/source/s?defs=list&amp;project=rtmp_client">list</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a>);
<a class="l" name="735" href="#735">735</a>				}
<a class="l" name="736" href="#736">736</a>				<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <a href="/source/s?defs=list&amp;project=rtmp_client">list</a>;
<a class="l" name="737" href="#737">737</a>			}
<a class="l" name="738" href="#738">738</a>			<a class="d" href="#so">so</a>.<a href="/source/s?defs=addEvent&amp;project=rtmp_client">addEvent</a>(<a href="/source/s?defs=type&amp;project=rtmp_client">type</a>, <a href="/source/s?defs=key&amp;project=rtmp_client">key</a>, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="739" href="#739">739</a>		}
<a class="hl" name="740" href="#740">740</a>	}
<a class="l" name="741" href="#741">741</a>
<a class="l" name="742" href="#742">742</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="743" href="#743">743</a>	<b>public</b> <a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a> <a class="xmt" name="decodeNotify"/><a href="/source/s?refs=decodeNotify&amp;project=rtmp_client" class="xmt">decodeNotify</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>) {
<a class="l" name="744" href="#744">744</a>		<b>return</b> <a href="/source/s?defs=decodeNotify&amp;project=rtmp_client">decodeNotify</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="745" href="#745">745</a>	}
<a class="l" name="746" href="#746">746</a>
<a class="l" name="747" href="#747">747</a>	<b>public</b> <a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a> <a class="xmt" name="decodeNotify"/><a href="/source/s?refs=decodeNotify&amp;project=rtmp_client" class="xmt">decodeNotify</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xa">header</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>) {
<a class="l" name="748" href="#748">748</a>		<b>return</b> <a class="d" href="#decodeNotifyOrInvoke">decodeNotifyOrInvoke</a>(<b>new</b> <a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>(), <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="749" href="#749">749</a>	}
<a class="hl" name="750" href="#750">750</a>
<a class="l" name="751" href="#751">751</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="752" href="#752">752</a>	<b>public</b> <a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a> <a class="xmt" name="decodeInvoke"/><a href="/source/s?refs=decodeInvoke&amp;project=rtmp_client" class="xmt">decodeInvoke</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>) {
<a class="l" name="753" href="#753">753</a>		<b>return</b> (<a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>) <a class="d" href="#decodeNotifyOrInvoke">decodeNotifyOrInvoke</a>(<b>new</b> <a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>(), <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="754" href="#754">754</a>	}
<a class="l" name="755" href="#755">755</a>
<a class="l" name="756" href="#756">756</a>	<span class="c">/**
<a class="l" name="757" href="#757">757</a>	 * Checks if the passed action is a reserved stream method.
<a class="l" name="758" href="#758">758</a>	 *
<a class="l" name="759" href="#759">759</a>	 * <strong>@param</strong> <em>action</em>
<a class="hl" name="760" href="#760">760</a>	 *            Action to check
<a class="l" name="761" href="#761">761</a>	 * <strong>@return</strong> &lt;code&gt;true&lt;/code&gt; if passed action is a reserved stream method,
<a class="l" name="762" href="#762">762</a>	 *         &lt;code&gt;false&lt;/code&gt; otherwise
<a class="l" name="763" href="#763">763</a>	 */</span>
<a class="l" name="764" href="#764">764</a>	<b>private</b> <b>boolean</b> <a class="xmt" name="isStreamCommand"/><a href="/source/s?refs=isStreamCommand&amp;project=rtmp_client" class="xmt">isStreamCommand</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="action"/><a href="/source/s?refs=action&amp;project=rtmp_client" class="xa">action</a>) {
<a class="l" name="765" href="#765">765</a>		<b>switch</b> (<a href="/source/s?defs=StreamAction&amp;project=rtmp_client">StreamAction</a>.<a href="/source/s?defs=getEnum&amp;project=rtmp_client">getEnum</a>(<a class="d" href="#action">action</a>)) {
<a class="l" name="766" href="#766">766</a>			<b>case</b> <a href="/source/s?defs=CREATE_STREAM&amp;project=rtmp_client">CREATE_STREAM</a>:
<a class="l" name="767" href="#767">767</a>			<b>case</b> <a href="/source/s?defs=DELETE_STREAM&amp;project=rtmp_client">DELETE_STREAM</a>:
<a class="l" name="768" href="#768">768</a>			<b>case</b> <a href="/source/s?defs=RELEASE_STREAM&amp;project=rtmp_client">RELEASE_STREAM</a>:
<a class="l" name="769" href="#769">769</a>			<b>case</b> <a href="/source/s?defs=PUBLISH&amp;project=rtmp_client">PUBLISH</a>:
<a class="hl" name="770" href="#770">770</a>			<b>case</b> <a href="/source/s?defs=PLAY&amp;project=rtmp_client">PLAY</a>:
<a class="l" name="771" href="#771">771</a>			<b>case</b> <a href="/source/s?defs=PLAY2&amp;project=rtmp_client">PLAY2</a>:
<a class="l" name="772" href="#772">772</a>			<b>case</b> <a href="/source/s?defs=SEEK&amp;project=rtmp_client">SEEK</a>:
<a class="l" name="773" href="#773">773</a>			<b>case</b> <a href="/source/s?defs=PAUSE&amp;project=rtmp_client">PAUSE</a>:
<a class="l" name="774" href="#774">774</a>			<b>case</b> <a href="/source/s?defs=PAUSE_RAW&amp;project=rtmp_client">PAUSE_RAW</a>:
<a class="l" name="775" href="#775">775</a>			<b>case</b> <a href="/source/s?defs=CLOSE_STREAM&amp;project=rtmp_client">CLOSE_STREAM</a>:
<a class="l" name="776" href="#776">776</a>			<b>case</b> <a href="/source/s?defs=RECEIVE_VIDEO&amp;project=rtmp_client">RECEIVE_VIDEO</a>:
<a class="l" name="777" href="#777">777</a>			<b>case</b> <a href="/source/s?defs=RECEIVE_AUDIO&amp;project=rtmp_client">RECEIVE_AUDIO</a>:
<a class="l" name="778" href="#778">778</a>				<b>return</b> <b>true</b>;
<a class="l" name="779" href="#779">779</a>			<b>default</b>:
<a class="hl" name="780" href="#780">780</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Stream action {} is not a recognized command"</span>, <a class="d" href="#action">action</a>);
<a class="l" name="781" href="#781">781</a>				<b>return</b> <b>false</b>;
<a class="l" name="782" href="#782">782</a>		}
<a class="l" name="783" href="#783">783</a>	}
<a class="l" name="784" href="#784">784</a>
<a class="l" name="785" href="#785">785</a>	<span class="c">/**
<a class="l" name="786" href="#786">786</a>	 * Decodes notification event.
<a class="l" name="787" href="#787">787</a>	 *
<a class="l" name="788" href="#788">788</a>	 * <strong>@param</strong> <em>notify</em>
<a class="l" name="789" href="#789">789</a>	 *            Notify event
<a class="hl" name="790" href="#790">790</a>	 * <strong>@param</strong> <em>in</em>
<a class="l" name="791" href="#791">791</a>	 *            Byte buffer
<a class="l" name="792" href="#792">792</a>	 * <strong>@param</strong> <em>header</em>
<a class="l" name="793" href="#793">793</a>	 *            Header
<a class="l" name="794" href="#794">794</a>	 * <strong>@param</strong> <em>rtmp</em>
<a class="l" name="795" href="#795">795</a>	 *            RTMP protocol state
<a class="l" name="796" href="#796">796</a>	 * <strong>@return</strong> Notification event
<a class="l" name="797" href="#797">797</a>	 */</span>
<a class="l" name="798" href="#798">798</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>({ <span class="s">"unchecked"</span> })
<a class="l" name="799" href="#799">799</a>	<b>protected</b> <a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a> <a class="xmt" name="decodeNotifyOrInvoke"/><a href="/source/s?refs=decodeNotifyOrInvoke&amp;project=rtmp_client" class="xmt">decodeNotifyOrInvoke</a>(<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a> <a class="xa" name="notify"/><a href="/source/s?refs=notify&amp;project=rtmp_client" class="xa">notify</a>, <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xa">header</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>) {
<a class="hl" name="800" href="#800">800</a>		<span class="c">// TODO: we should use different code depending on server or client mode</span>
<a class="l" name="801" href="#801">801</a>		<b>int</b> <a href="/source/s?defs=start&amp;project=rtmp_client">start</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>();
<a class="l" name="802" href="#802">802</a>		<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a> <a class="d" href="#input">input</a>;
<a class="l" name="803" href="#803">803</a>		<span class="c">// for response, the action string and invokeId is always encoded as AMF0</span>
<a class="l" name="804" href="#804">804</a>		<span class="c">// we use the first byte to decide which encoding to use.</span>
<a class="l" name="805" href="#805">805</a>		<b>byte</b> <a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="806" href="#806">806</a>		<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<a href="/source/s?defs=start&amp;project=rtmp_client">start</a>);
<a class="l" name="807" href="#807">807</a>		<b>if</b> (<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getEncoding&amp;project=rtmp_client">getEncoding</a>() == <a href="/source/s?defs=Encoding&amp;project=rtmp_client">Encoding</a>.<a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a> &amp;&amp; <a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a> == <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_AMF3_OBJECT&amp;project=rtmp_client">TYPE_AMF3_OBJECT</a>) {
<a class="l" name="808" href="#808">808</a>			<a class="d" href="#input">input</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="809" href="#809">809</a>		} <b>else</b> {
<a class="hl" name="810" href="#810">810</a>			<a class="d" href="#input">input</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="811" href="#811">811</a>		}
<a class="l" name="812" href="#812">812</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="d" href="#action">action</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<a class="d" href="#input">input</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>);
<a class="l" name="813" href="#813">813</a><span class="c">//		log.info("Action {}", action);</span>
<a class="l" name="814" href="#814">814</a>		<span class="c">//throw a runtime exception if there is no action</span>
<a class="l" name="815" href="#815">815</a>		<b>if</b> (<a class="d" href="#action">action</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="816" href="#816">816</a>			<span class="c">//TODO replace this with something better as time permits</span>
<a class="l" name="817" href="#817">817</a>			<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"Action was null"</span>);
<a class="l" name="818" href="#818">818</a>		}
<a class="l" name="819" href="#819">819</a>
<a class="hl" name="820" href="#820">820</a>		<span class="c">//TODO Handle NetStream.send? Where and how?</span>
<a class="l" name="821" href="#821">821</a>
<a class="l" name="822" href="#822">822</a>		<b>if</b> (!(<a class="d" href="#notify">notify</a> <b>instanceof</b> <a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>) &amp;&amp; <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getMode&amp;project=rtmp_client">getMode</a>() == <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=MODE_SERVER&amp;project=rtmp_client">MODE_SERVER</a> &amp;&amp; <a href="/source/s?defs=header&amp;project=rtmp_client">header</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getStreamId&amp;project=rtmp_client">getStreamId</a>() != <span class="n">0</span> &amp;&amp; !<a class="d" href="#isStreamCommand">isStreamCommand</a>(<a class="d" href="#action">action</a>)) {
<a class="l" name="823" href="#823">823</a>			<span class="c">// Don't decode "NetStream.send" requests</span>
<a class="l" name="824" href="#824">824</a>			<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<a href="/source/s?defs=start&amp;project=rtmp_client">start</a>);
<a class="l" name="825" href="#825">825</a>			<a class="d" href="#notify">notify</a>.<a href="/source/s?defs=setData&amp;project=rtmp_client">setData</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=asReadOnlyBuffer&amp;project=rtmp_client">asReadOnlyBuffer</a>());
<a class="l" name="826" href="#826">826</a>			<b>return</b> <a class="d" href="#notify">notify</a>;
<a class="l" name="827" href="#827">827</a>		}
<a class="l" name="828" href="#828">828</a>
<a class="l" name="829" href="#829">829</a>		<b>if</b> (<a href="/source/s?defs=header&amp;project=rtmp_client">header</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> || <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getStreamId&amp;project=rtmp_client">getStreamId</a>() == <span class="n">0</span>) {
<a class="hl" name="830" href="#830">830</a>			<b>int</b> <a href="/source/s?defs=invokeId&amp;project=rtmp_client">invokeId</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.&lt;<a href="/source/s?defs=Number&amp;project=rtmp_client">Number</a>&gt; <a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<a class="d" href="#input">input</a>, <a href="/source/s?defs=Number&amp;project=rtmp_client">Number</a>.<b>class</b>).<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>();
<a class="l" name="831" href="#831">831</a>			<a class="d" href="#notify">notify</a>.<a href="/source/s?defs=setInvokeId&amp;project=rtmp_client">setInvokeId</a>(<a href="/source/s?defs=invokeId&amp;project=rtmp_client">invokeId</a>);
<a class="l" name="832" href="#832">832</a>		}
<a class="l" name="833" href="#833">833</a>
<a class="l" name="834" href="#834">834</a>		<span class="c">// now go back to the actual encoding to decode parameters</span>
<a class="l" name="835" href="#835">835</a>		<b>if</b> (<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getEncoding&amp;project=rtmp_client">getEncoding</a>() == <a href="/source/s?defs=Encoding&amp;project=rtmp_client">Encoding</a>.<a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>) {
<a class="l" name="836" href="#836">836</a>			<a class="d" href="#input">input</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="837" href="#837">837</a>		} <b>else</b> {
<a class="l" name="838" href="#838">838</a>			<a class="d" href="#input">input</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="839" href="#839">839</a>		}
<a class="hl" name="840" href="#840">840</a>
<a class="l" name="841" href="#841">841</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a href="/source/s?defs=params&amp;project=rtmp_client">params</a> = <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] {};
<a class="l" name="842" href="#842">842</a>
<a class="l" name="843" href="#843">843</a>		<b>if</b> (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=hasRemaining&amp;project=rtmp_client">hasRemaining</a>()) {
<a class="l" name="844" href="#844">844</a>			<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=paramList&amp;project=rtmp_client">paramList</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="l" name="845" href="#845">845</a>
<a class="l" name="846" href="#846">846</a>			<b>final</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=obj&amp;project=rtmp_client">obj</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<a class="d" href="#input">input</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>.<b>class</b>);
<a class="l" name="847" href="#847">847</a>
<a class="l" name="848" href="#848">848</a>			<b>if</b> (<a href="/source/s?defs=obj&amp;project=rtmp_client">obj</a> <b>instanceof</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>) {
<a class="l" name="849" href="#849">849</a>				<span class="c">// Before the actual parameters we sometimes (connect) get a map</span>
<a class="hl" name="850" href="#850">850</a>				<span class="c">// of parameters, this is usually null, but if set should be</span>
<a class="l" name="851" href="#851">851</a>				<span class="c">// passed to the connection object.</span>
<a class="l" name="852" href="#852">852</a>				<b>final</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=connParams&amp;project=rtmp_client">connParams</a> = (<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;) <a href="/source/s?defs=obj&amp;project=rtmp_client">obj</a>;
<a class="l" name="853" href="#853">853</a>				<a class="d" href="#notify">notify</a>.<a href="/source/s?defs=setConnectionParams&amp;project=rtmp_client">setConnectionParams</a>(<a href="/source/s?defs=connParams&amp;project=rtmp_client">connParams</a>);
<a class="l" name="854" href="#854">854</a>			} <b>else</b> <b>if</b> (<a href="/source/s?defs=obj&amp;project=rtmp_client">obj</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="855" href="#855">855</a>				<a href="/source/s?defs=paramList&amp;project=rtmp_client">paramList</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=obj&amp;project=rtmp_client">obj</a>);
<a class="l" name="856" href="#856">856</a>			}
<a class="l" name="857" href="#857">857</a>
<a class="l" name="858" href="#858">858</a>			<b>while</b> (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=hasRemaining&amp;project=rtmp_client">hasRemaining</a>()) {
<a class="l" name="859" href="#859">859</a>				<a href="/source/s?defs=paramList&amp;project=rtmp_client">paramList</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<a class="d" href="#input">input</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>.<b>class</b>));
<a class="hl" name="860" href="#860">860</a>			}
<a class="l" name="861" href="#861">861</a>			<a href="/source/s?defs=params&amp;project=rtmp_client">params</a> = <a href="/source/s?defs=paramList&amp;project=rtmp_client">paramList</a>.<a href="/source/s?defs=toArray&amp;project=rtmp_client">toArray</a>();
<a class="l" name="862" href="#862">862</a><span class="c">//			if (log.isDebugEnabled()) {</span>
<a class="l" name="863" href="#863">863</a><span class="c">//				log.debug("Num params: {}", paramList.size());</span>
<a class="l" name="864" href="#864">864</a><span class="c">//				for (int i = 0; i &lt; params.length; i++) {</span>
<a class="l" name="865" href="#865">865</a><span class="c">//					log.info(" &gt; {}: {}", i, params[i]);</span>
<a class="l" name="866" href="#866">866</a><span class="c">//				}</span>
<a class="l" name="867" href="#867">867</a><span class="c">//			}</span>
<a class="l" name="868" href="#868">868</a>		}
<a class="l" name="869" href="#869">869</a>
<a class="hl" name="870" href="#870">870</a>		<b>final</b> <b>int</b> <a href="/source/s?defs=dotIndex&amp;project=rtmp_client">dotIndex</a> = <a class="d" href="#action">action</a>.<a href="/source/s?defs=lastIndexOf&amp;project=rtmp_client">lastIndexOf</a>(<span class="s">'.'</span>);
<a class="l" name="871" href="#871">871</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=serviceName&amp;project=rtmp_client">serviceName</a> = (<a href="/source/s?defs=dotIndex&amp;project=rtmp_client">dotIndex</a> == -<span class="n">1</span>) ? <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> : <a class="d" href="#action">action</a>.<a href="/source/s?defs=substring&amp;project=rtmp_client">substring</a>(<span class="n">0</span>, <a href="/source/s?defs=dotIndex&amp;project=rtmp_client">dotIndex</a>);
<a class="l" name="872" href="#872">872</a>		<span class="c">//pull off the prefixes since java doesnt allow this on a method name</span>
<a class="l" name="873" href="#873">873</a>		<b>if</b> (<a href="/source/s?defs=serviceName&amp;project=rtmp_client">serviceName</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; (<a href="/source/s?defs=serviceName&amp;project=rtmp_client">serviceName</a>.<a href="/source/s?defs=startsWith&amp;project=rtmp_client">startsWith</a>(<span class="s">"@"</span>) || <a href="/source/s?defs=serviceName&amp;project=rtmp_client">serviceName</a>.<a href="/source/s?defs=startsWith&amp;project=rtmp_client">startsWith</a>(<span class="s">"|"</span>))) {
<a class="l" name="874" href="#874">874</a>			<a href="/source/s?defs=serviceName&amp;project=rtmp_client">serviceName</a> = <a href="/source/s?defs=serviceName&amp;project=rtmp_client">serviceName</a>.<a href="/source/s?defs=substring&amp;project=rtmp_client">substring</a>(<span class="n">1</span>);
<a class="l" name="875" href="#875">875</a>		}
<a class="l" name="876" href="#876">876</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=serviceMethod&amp;project=rtmp_client">serviceMethod</a> = (<a href="/source/s?defs=dotIndex&amp;project=rtmp_client">dotIndex</a> == -<span class="n">1</span>) ? <a class="d" href="#action">action</a> : <a class="d" href="#action">action</a>.<a href="/source/s?defs=substring&amp;project=rtmp_client">substring</a>(<a href="/source/s?defs=dotIndex&amp;project=rtmp_client">dotIndex</a> + <span class="n">1</span>, <a class="d" href="#action">action</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>());
<a class="l" name="877" href="#877">877</a>		<span class="c">//pull off the prefixes since java doesnt allow this on a method name</span>
<a class="l" name="878" href="#878">878</a>		<b>if</b> (<a href="/source/s?defs=serviceMethod&amp;project=rtmp_client">serviceMethod</a>.<a href="/source/s?defs=startsWith&amp;project=rtmp_client">startsWith</a>(<span class="s">"@"</span>) || <a href="/source/s?defs=serviceMethod&amp;project=rtmp_client">serviceMethod</a>.<a href="/source/s?defs=startsWith&amp;project=rtmp_client">startsWith</a>(<span class="s">"|"</span>)) {
<a class="l" name="879" href="#879">879</a>			<a href="/source/s?defs=serviceMethod&amp;project=rtmp_client">serviceMethod</a> = <a href="/source/s?defs=serviceMethod&amp;project=rtmp_client">serviceMethod</a>.<a href="/source/s?defs=substring&amp;project=rtmp_client">substring</a>(<span class="n">1</span>);
<a class="hl" name="880" href="#880">880</a>		}
<a class="l" name="881" href="#881">881</a>
<a class="l" name="882" href="#882">882</a>		<b>if</b> (<a class="d" href="#notify">notify</a> <b>instanceof</b> <a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>) {
<a class="l" name="883" href="#883">883</a>			<a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a> <a href="/source/s?defs=call&amp;project=rtmp_client">call</a> = <b>new</b> <a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a>(<a href="/source/s?defs=serviceName&amp;project=rtmp_client">serviceName</a>, <a href="/source/s?defs=serviceMethod&amp;project=rtmp_client">serviceMethod</a>, <a href="/source/s?defs=params&amp;project=rtmp_client">params</a>);
<a class="l" name="884" href="#884">884</a>			((<a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>) <a class="d" href="#notify">notify</a>).<a href="/source/s?defs=setCall&amp;project=rtmp_client">setCall</a>(<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>);
<a class="l" name="885" href="#885">885</a>		} <b>else</b> {
<a class="l" name="886" href="#886">886</a>			<a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a> <a href="/source/s?defs=call&amp;project=rtmp_client">call</a> = <b>new</b> <a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>(<a href="/source/s?defs=serviceName&amp;project=rtmp_client">serviceName</a>, <a href="/source/s?defs=serviceMethod&amp;project=rtmp_client">serviceMethod</a>, <a href="/source/s?defs=params&amp;project=rtmp_client">params</a>);
<a class="l" name="887" href="#887">887</a>			<a class="d" href="#notify">notify</a>.<a href="/source/s?defs=setCall&amp;project=rtmp_client">setCall</a>(<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>);
<a class="l" name="888" href="#888">888</a>		}
<a class="l" name="889" href="#889">889</a>
<a class="hl" name="890" href="#890">890</a>		<b>return</b> <a class="d" href="#notify">notify</a>;
<a class="l" name="891" href="#891">891</a>	}
<a class="l" name="892" href="#892">892</a>
<a class="l" name="893" href="#893">893</a>	<span class="c">/**
<a class="l" name="894" href="#894">894</a>	 * Decodes ping event.
<a class="l" name="895" href="#895">895</a>	 *
<a class="l" name="896" href="#896">896</a>	 * <strong>@param</strong> <em>in</em> IoBuffer
<a class="l" name="897" href="#897">897</a>	 * <strong>@return</strong> Ping event
<a class="l" name="898" href="#898">898</a>	 */</span>
<a class="l" name="899" href="#899">899</a>	<b>public</b> <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a> <a class="xmt" name="decodePing"/><a href="/source/s?refs=decodePing&amp;project=rtmp_client" class="xmt">decodePing</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="hl" name="900" href="#900">900</a>		<b>final</b> <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a> <a href="/source/s?defs=ping&amp;project=rtmp_client">ping</a> = <b>new</b> <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>();
<a class="l" name="901" href="#901">901</a>		<a href="/source/s?defs=ping&amp;project=rtmp_client">ping</a>.<a href="/source/s?defs=setDebug&amp;project=rtmp_client">setDebug</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getHexDump&amp;project=rtmp_client">getHexDump</a>());
<a class="l" name="902" href="#902">902</a>		<a href="/source/s?defs=ping&amp;project=rtmp_client">ping</a>.<a href="/source/s?defs=setEventType&amp;project=rtmp_client">setEventType</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getShort&amp;project=rtmp_client">getShort</a>());
<a class="l" name="903" href="#903">903</a>		<a href="/source/s?defs=ping&amp;project=rtmp_client">ping</a>.<a href="/source/s?defs=setValue2&amp;project=rtmp_client">setValue2</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>());
<a class="l" name="904" href="#904">904</a>		<b>if</b> (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=hasRemaining&amp;project=rtmp_client">hasRemaining</a>()) {
<a class="l" name="905" href="#905">905</a>			<a href="/source/s?defs=ping&amp;project=rtmp_client">ping</a>.<a href="/source/s?defs=setValue3&amp;project=rtmp_client">setValue3</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>());
<a class="l" name="906" href="#906">906</a>		}
<a class="l" name="907" href="#907">907</a>		<b>if</b> (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=hasRemaining&amp;project=rtmp_client">hasRemaining</a>()) {
<a class="l" name="908" href="#908">908</a>			<a href="/source/s?defs=ping&amp;project=rtmp_client">ping</a>.<a href="/source/s?defs=setValue4&amp;project=rtmp_client">setValue4</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>());
<a class="l" name="909" href="#909">909</a>		}
<a class="hl" name="910" href="#910">910</a>		<b>return</b> <a href="/source/s?defs=ping&amp;project=rtmp_client">ping</a>;
<a class="l" name="911" href="#911">911</a>	}
<a class="l" name="912" href="#912">912</a>
<a class="l" name="913" href="#913">913</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="914" href="#914">914</a>	<b>public</b> <a href="/source/s?defs=BytesRead&amp;project=rtmp_client">BytesRead</a> <a class="xmt" name="decodeBytesRead"/><a href="/source/s?refs=decodeBytesRead&amp;project=rtmp_client" class="xmt">decodeBytesRead</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="915" href="#915">915</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=BytesRead&amp;project=rtmp_client">BytesRead</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=getInt&amp;project=rtmp_client">getInt</a>());
<a class="l" name="916" href="#916">916</a>	}
<a class="l" name="917" href="#917">917</a>
<a class="l" name="918" href="#918">918</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="919" href="#919">919</a>	<b>public</b> <a href="/source/s?defs=AudioData&amp;project=rtmp_client">AudioData</a> <a class="xmt" name="decodeAudioData"/><a href="/source/s?refs=decodeAudioData&amp;project=rtmp_client" class="xmt">decodeAudioData</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="hl" name="920" href="#920">920</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=AudioData&amp;project=rtmp_client">AudioData</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=asReadOnlyBuffer&amp;project=rtmp_client">asReadOnlyBuffer</a>());
<a class="l" name="921" href="#921">921</a>	}
<a class="l" name="922" href="#922">922</a>
<a class="l" name="923" href="#923">923</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="924" href="#924">924</a>	<b>public</b> <a href="/source/s?defs=VideoData&amp;project=rtmp_client">VideoData</a> <a class="xmt" name="decodeVideoData"/><a href="/source/s?refs=decodeVideoData&amp;project=rtmp_client" class="xmt">decodeVideoData</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="925" href="#925">925</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=VideoData&amp;project=rtmp_client">VideoData</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=asReadOnlyBuffer&amp;project=rtmp_client">asReadOnlyBuffer</a>());
<a class="l" name="926" href="#926">926</a>	}
<a class="l" name="927" href="#927">927</a>
<a class="l" name="928" href="#928">928</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unchecked"</span>)
<a class="l" name="929" href="#929">929</a>	<b>public</b> <a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a> <a class="xmt" name="decodeStreamMetadata"/><a href="/source/s?refs=decodeStreamMetadata&amp;project=rtmp_client" class="xmt">decodeStreamMetadata</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>) {
<a class="hl" name="930" href="#930">930</a>		<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a> <a class="d" href="#input">input</a>;
<a class="l" name="931" href="#931">931</a>		<span class="c">//we will make a pre-emptive copy of the incoming buffer here to</span>
<a class="l" name="932" href="#932">932</a>		<span class="c">//prevent issues that seem to occur fairly often</span>
<a class="l" name="933" href="#933">933</a>		<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=copy&amp;project=rtmp_client">copy</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=duplicate&amp;project=rtmp_client">duplicate</a>();
<a class="l" name="934" href="#934">934</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"metadata {}"</span>, <a href="/source/s?defs=copy&amp;project=rtmp_client">copy</a>.<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>().<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>());
<a class="l" name="935" href="#935">935</a>		<b>if</b> (<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getEncoding&amp;project=rtmp_client">getEncoding</a>() == <a href="/source/s?defs=Encoding&amp;project=rtmp_client">Encoding</a>.<a href="/source/s?defs=AMF0&amp;project=rtmp_client">AMF0</a>) {
<a class="l" name="936" href="#936">936</a>			<a class="d" href="#input">input</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>(<a href="/source/s?defs=copy&amp;project=rtmp_client">copy</a>);
<a class="l" name="937" href="#937">937</a>		} <b>else</b> {
<a class="l" name="938" href="#938">938</a>			<a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>.<a href="/source/s?defs=RefStorage&amp;project=rtmp_client">RefStorage</a> <a href="/source/s?defs=refStorage&amp;project=rtmp_client">refStorage</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>.<a href="/source/s?defs=RefStorage&amp;project=rtmp_client">RefStorage</a>();
<a class="l" name="939" href="#939">939</a>			<a class="d" href="#input">input</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>(<a href="/source/s?defs=copy&amp;project=rtmp_client">copy</a>, <a href="/source/s?defs=refStorage&amp;project=rtmp_client">refStorage</a>);
<a class="hl" name="940" href="#940">940</a>		}
<a class="l" name="941" href="#941">941</a>		<span class="c">//get the first datatype</span>
<a class="l" name="942" href="#942">942</a>		<b>byte</b> <a class="d" href="#dataType">dataType</a> = <a class="d" href="#input">input</a>.<a href="/source/s?defs=readDataType&amp;project=rtmp_client">readDataType</a>();
<a class="l" name="943" href="#943">943</a>		<b>if</b> (<a class="d" href="#dataType">dataType</a> == <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_STRING&amp;project=rtmp_client">CORE_STRING</a>) {
<a class="l" name="944" href="#944">944</a>			<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=setData&amp;project=rtmp_client">setData</a> = <a class="d" href="#input">input</a>.<a href="/source/s?defs=readString&amp;project=rtmp_client">readString</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>);
<a class="l" name="945" href="#945">945</a>			<b>if</b> (<a href="/source/s?defs=setData&amp;project=rtmp_client">setData</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<span class="s">"@setDataFrame"</span>)) {
<a class="l" name="946" href="#946">946</a>				<span class="c">//get the second datatype</span>
<a class="l" name="947" href="#947">947</a>				@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unused"</span>)
<a class="l" name="948" href="#948">948</a>				<b>byte</b> <a href="/source/s?defs=dataType2&amp;project=rtmp_client">dataType2</a> = <a class="d" href="#input">input</a>.<a href="/source/s?defs=readDataType&amp;project=rtmp_client">readDataType</a>();
<a class="l" name="949" href="#949">949</a><span class="c">//				log.debug("Dataframe method type: {}", dataType2);</span>
<a class="hl" name="950" href="#950">950</a>				<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=onCueOrOnMeta&amp;project=rtmp_client">onCueOrOnMeta</a> = <a class="d" href="#input">input</a>.<a href="/source/s?defs=readString&amp;project=rtmp_client">readString</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>);
<a class="l" name="951" href="#951">951</a>				<span class="c">//get the params datatype</span>
<a class="l" name="952" href="#952">952</a>				<b>byte</b> <a href="/source/s?defs=object&amp;project=rtmp_client">object</a> = <a class="d" href="#input">input</a>.<a href="/source/s?defs=readDataType&amp;project=rtmp_client">readDataType</a>();
<a class="l" name="953" href="#953">953</a><span class="c">//				log.debug("Dataframe params type: {}", object);</span>
<a class="l" name="954" href="#954">954</a>				<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=params&amp;project=rtmp_client">params</a>;
<a class="l" name="955" href="#955">955</a>				<b>if</b> (<a href="/source/s?defs=object&amp;project=rtmp_client">object</a> == <a href="/source/s?defs=DataTypes&amp;project=rtmp_client">DataTypes</a>.<a href="/source/s?defs=CORE_MAP&amp;project=rtmp_client">CORE_MAP</a>) {
<a class="l" name="956" href="#956">956</a>					<span class="c">// The params are sent as a Mixed-Array.  This is needed</span>
<a class="l" name="957" href="#957">957</a>					<span class="c">// to support the RTMP publish provided by <a href="/source/s?path=ffmpeg/">ffmpeg</a>/<a href="/source/s?path=ffmpeg/xuggler">xuggler</a></span>
<a class="l" name="958" href="#958">958</a>					<a href="/source/s?defs=params&amp;project=rtmp_client">params</a> = (<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;) <a class="d" href="#input">input</a>.<a href="/source/s?defs=readMap&amp;project=rtmp_client">readMap</a>(<a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="959" href="#959">959</a>				} <b>else</b> {
<a class="hl" name="960" href="#960">960</a>					<span class="c">// Read the params as a standard object</span>
<a class="l" name="961" href="#961">961</a>					<a href="/source/s?defs=params&amp;project=rtmp_client">params</a> = (<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;) <a class="d" href="#input">input</a>.<a href="/source/s?defs=readObject&amp;project=rtmp_client">readObject</a>(<a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>.<b>class</b>);
<a class="l" name="962" href="#962">962</a>				}
<a class="l" name="963" href="#963">963</a><span class="c">//				log.debug("Dataframe: {} params: {}", onCueOrOnMeta, params.toString());</span>
<a class="l" name="964" href="#964">964</a>
<a class="l" name="965" href="#965">965</a>				<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<span class="n">1024</span>);
<a class="l" name="966" href="#966">966</a>				<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="967" href="#967">967</a>				<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <b>new</b> <a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="968" href="#968">968</a>				<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=writeString&amp;project=rtmp_client">writeString</a>(<a href="/source/s?defs=onCueOrOnMeta&amp;project=rtmp_client">onCueOrOnMeta</a>);
<a class="l" name="969" href="#969">969</a>				<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>.<a href="/source/s?defs=writeMap&amp;project=rtmp_client">writeMap</a>(<a href="/source/s?defs=params&amp;project=rtmp_client">params</a>, <b>new</b> <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>());
<a class="hl" name="970" href="#970">970</a>
<a class="l" name="971" href="#971">971</a>				<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>.<a href="/source/s?defs=flip&amp;project=rtmp_client">flip</a>();
<a class="l" name="972" href="#972">972</a>				<b>return</b> <b>new</b> <a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>(<a href="/source/s?defs=buf&amp;project=rtmp_client">buf</a>);
<a class="l" name="973" href="#973">973</a>			} <b>else</b> {
<a class="l" name="974" href="#974">974</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"Unhandled request: {}"</span>, <a href="/source/s?defs=setData&amp;project=rtmp_client">setData</a>);
<a class="l" name="975" href="#975">975</a>			}
<a class="l" name="976" href="#976">976</a>		}
<a class="l" name="977" href="#977">977</a>
<a class="l" name="978" href="#978">978</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=asReadOnlyBuffer&amp;project=rtmp_client">asReadOnlyBuffer</a>());
<a class="l" name="979" href="#979">979</a>	}
<a class="hl" name="980" href="#980">980</a>
<a class="l" name="981" href="#981">981</a>	<span class="c">/**
<a class="l" name="982" href="#982">982</a>	 * Decodes FlexMessage event.
<a class="l" name="983" href="#983">983</a>	 *
<a class="l" name="984" href="#984">984</a>	 * <strong>@param</strong> <em>in</em> IoBuffer
<a class="l" name="985" href="#985">985</a>	 * <strong>@param</strong> <em>rtmp</em> RTMP protocol state
<a class="l" name="986" href="#986">986</a>	 * <strong>@return</strong> FlexMessage event
<a class="l" name="987" href="#987">987</a>	 */</span>
<a class="l" name="988" href="#988">988</a>	<b>public</b> <a href="/source/s?defs=FlexMessage&amp;project=rtmp_client">FlexMessage</a> <a class="xmt" name="decodeFlexMessage"/><a href="/source/s?refs=decodeFlexMessage&amp;project=rtmp_client" class="xmt">decodeFlexMessage</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>) {
<a class="l" name="989" href="#989">989</a>		<span class="c">// TODO: Unknown byte, probably encoding as with Flex SOs?</span>
<a class="hl" name="990" href="#990">990</a>		<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=skip&amp;project=rtmp_client">skip</a>(<span class="n">1</span>);
<a class="l" name="991" href="#991">991</a>		<span class="c">// Encoding of message params can be mixed - some params may be in AMF0, others in AMF3,</span>
<a class="l" name="992" href="#992">992</a>		<span class="c">// but according to AMF3 spec, we should collect AMF3 references</span>
<a class="l" name="993" href="#993">993</a>		<span class="c">// for the whole message body (through all params)</span>
<a class="l" name="994" href="#994">994</a>		<a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>.<a href="/source/s?defs=RefStorage&amp;project=rtmp_client">RefStorage</a> <a href="/source/s?defs=refStorage&amp;project=rtmp_client">refStorage</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>.<a href="/source/s?defs=RefStorage&amp;project=rtmp_client">RefStorage</a>();
<a class="l" name="995" href="#995">995</a>
<a class="l" name="996" href="#996">996</a>		<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a> <a class="d" href="#input">input</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="997" href="#997">997</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="d" href="#action">action</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<a class="d" href="#input">input</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>);
<a class="l" name="998" href="#998">998</a>		<b>int</b> <a href="/source/s?defs=invokeId&amp;project=rtmp_client">invokeId</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.&lt;<a href="/source/s?defs=Number&amp;project=rtmp_client">Number</a>&gt; <a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<a class="d" href="#input">input</a>, <a href="/source/s?defs=Number&amp;project=rtmp_client">Number</a>.<b>class</b>).<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>();
<a class="l" name="999" href="#999">999</a>		<a href="/source/s?defs=FlexMessage&amp;project=rtmp_client">FlexMessage</a> <a href="/source/s?defs=msg&amp;project=rtmp_client">msg</a> = <b>new</b> <a href="/source/s?defs=FlexMessage&amp;project=rtmp_client">FlexMessage</a>();
<a class="hl" name="1000" href="#1000">1000</a>		<a href="/source/s?defs=msg&amp;project=rtmp_client">msg</a>.<a href="/source/s?defs=setInvokeId&amp;project=rtmp_client">setInvokeId</a>(<a href="/source/s?defs=invokeId&amp;project=rtmp_client">invokeId</a>);
<a class="l" name="1001" href="#1001">1001</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a href="/source/s?defs=params&amp;project=rtmp_client">params</a> = <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] {};
<a class="l" name="1002" href="#1002">1002</a>
<a class="l" name="1003" href="#1003">1003</a>		<b>if</b> (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=hasRemaining&amp;project=rtmp_client">hasRemaining</a>()) {
<a class="l" name="1004" href="#1004">1004</a>			<a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=paramList&amp;project=rtmp_client">paramList</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="l" name="1005" href="#1005">1005</a>
<a class="l" name="1006" href="#1006">1006</a>			<b>final</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=obj&amp;project=rtmp_client">obj</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<a class="d" href="#input">input</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>.<b>class</b>);
<a class="l" name="1007" href="#1007">1007</a>			<b>if</b> (<a href="/source/s?defs=obj&amp;project=rtmp_client">obj</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="1008" href="#1008">1008</a>				<a href="/source/s?defs=paramList&amp;project=rtmp_client">paramList</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=obj&amp;project=rtmp_client">obj</a>);
<a class="l" name="1009" href="#1009">1009</a>			}
<a class="hl" name="1010" href="#1010">1010</a>
<a class="l" name="1011" href="#1011">1011</a>			<b>while</b> (<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=hasRemaining&amp;project=rtmp_client">hasRemaining</a>()) {
<a class="l" name="1012" href="#1012">1012</a>				<span class="c">// Check for AMF3 encoding of parameters</span>
<a class="l" name="1013" href="#1013">1013</a>				<b>byte</b> <a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a> = <a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="1014" href="#1014">1014</a>				<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=position&amp;project=rtmp_client">position</a>() - <span class="n">1</span>);
<a class="l" name="1015" href="#1015">1015</a>				<b>if</b> (<a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a> == <a href="/source/s?defs=AMF&amp;project=rtmp_client">AMF</a>.<a href="/source/s?defs=TYPE_AMF3_OBJECT&amp;project=rtmp_client">TYPE_AMF3_OBJECT</a>) {
<a class="l" name="1016" href="#1016">1016</a>					<span class="c">// The next parameter is encoded using AMF3</span>
<a class="l" name="1017" href="#1017">1017</a>					<a class="d" href="#input">input</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf3&amp;project=rtmp_client">amf3</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>, <a href="/source/s?defs=refStorage&amp;project=rtmp_client">refStorage</a>);
<a class="l" name="1018" href="#1018">1018</a>				} <b>else</b> {
<a class="l" name="1019" href="#1019">1019</a>					<span class="c">// The next parameter is encoded using AMF0</span>
<a class="hl" name="1020" href="#1020">1020</a>					<a class="d" href="#input">input</a> = <b>new</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=amf&amp;project=rtmp_client">amf</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>);
<a class="l" name="1021" href="#1021">1021</a>				}
<a class="l" name="1022" href="#1022">1022</a>				<a href="/source/s?defs=paramList&amp;project=rtmp_client">paramList</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a href="/source/s?defs=deserialize&amp;project=rtmp_client">deserialize</a>(<a class="d" href="#input">input</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>.<b>class</b>));
<a class="l" name="1023" href="#1023">1023</a>			}
<a class="l" name="1024" href="#1024">1024</a>			<a href="/source/s?defs=params&amp;project=rtmp_client">params</a> = <a href="/source/s?defs=paramList&amp;project=rtmp_client">paramList</a>.<a href="/source/s?defs=toArray&amp;project=rtmp_client">toArray</a>();
<a class="l" name="1025" href="#1025">1025</a><span class="c">//			if (log.isDebugEnabled()) {</span>
<a class="l" name="1026" href="#1026">1026</a><span class="c">//				log.debug("Num params: {}", paramList.size());</span>
<a class="l" name="1027" href="#1027">1027</a><span class="c">//				for (int i = 0; i &lt; params.length; i++) {</span>
<a class="l" name="1028" href="#1028">1028</a><span class="c">//					log.info(" &gt; {}: {}", i, params[i]);</span>
<a class="l" name="1029" href="#1029">1029</a><span class="c">//				}</span>
<a class="hl" name="1030" href="#1030">1030</a><span class="c">//			}</span>
<a class="l" name="1031" href="#1031">1031</a>		}
<a class="l" name="1032" href="#1032">1032</a>
<a class="l" name="1033" href="#1033">1033</a>		<b>final</b> <b>int</b> <a href="/source/s?defs=dotIndex&amp;project=rtmp_client">dotIndex</a> = <a class="d" href="#action">action</a>.<a href="/source/s?defs=lastIndexOf&amp;project=rtmp_client">lastIndexOf</a>(<span class="s">'.'</span>);
<a class="l" name="1034" href="#1034">1034</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=serviceName&amp;project=rtmp_client">serviceName</a> = (<a href="/source/s?defs=dotIndex&amp;project=rtmp_client">dotIndex</a> == -<span class="n">1</span>) ? <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> : <a class="d" href="#action">action</a>.<a href="/source/s?defs=substring&amp;project=rtmp_client">substring</a>(<span class="n">0</span>, <a href="/source/s?defs=dotIndex&amp;project=rtmp_client">dotIndex</a>);
<a class="l" name="1035" href="#1035">1035</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=serviceMethod&amp;project=rtmp_client">serviceMethod</a> = (<a href="/source/s?defs=dotIndex&amp;project=rtmp_client">dotIndex</a> == -<span class="n">1</span>) ? <a class="d" href="#action">action</a> : <a class="d" href="#action">action</a>.<a href="/source/s?defs=substring&amp;project=rtmp_client">substring</a>(<a href="/source/s?defs=dotIndex&amp;project=rtmp_client">dotIndex</a> + <span class="n">1</span>, <a class="d" href="#action">action</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>());
<a class="l" name="1036" href="#1036">1036</a>
<a class="l" name="1037" href="#1037">1037</a>		<a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a> <a href="/source/s?defs=call&amp;project=rtmp_client">call</a> = <b>new</b> <a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a>(<a href="/source/s?defs=serviceName&amp;project=rtmp_client">serviceName</a>, <a href="/source/s?defs=serviceMethod&amp;project=rtmp_client">serviceMethod</a>, <a href="/source/s?defs=params&amp;project=rtmp_client">params</a>);
<a class="l" name="1038" href="#1038">1038</a>		<a href="/source/s?defs=msg&amp;project=rtmp_client">msg</a>.<a href="/source/s?defs=setCall&amp;project=rtmp_client">setCall</a>(<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>);
<a class="l" name="1039" href="#1039">1039</a>		<b>return</b> <a href="/source/s?defs=msg&amp;project=rtmp_client">msg</a>;
<a class="hl" name="1040" href="#1040">1040</a>	}
<a class="l" name="1041" href="#1041">1041</a>
<a class="l" name="1042" href="#1042">1042</a>	<b>public</b> <a href="/source/s?defs=FlexStreamSend&amp;project=rtmp_client">FlexStreamSend</a> <a class="xmt" name="decodeFlexStreamSend"/><a href="/source/s?refs=decodeFlexStreamSend&amp;project=rtmp_client" class="xmt">decodeFlexStreamSend</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) {
<a class="l" name="1043" href="#1043">1043</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=FlexStreamSend&amp;project=rtmp_client">FlexStreamSend</a>(<a href="/source/s?defs=in&amp;project=rtmp_client">in</a>.<a href="/source/s?defs=asReadOnlyBuffer&amp;project=rtmp_client">asReadOnlyBuffer</a>());
<a class="l" name="1044" href="#1044">1044</a>	}
<a class="l" name="1045" href="#1045">1045</a>
<a class="l" name="1046" href="#1046">1046</a>}
<a class="l" name="1047" href="#1047">1047</a>