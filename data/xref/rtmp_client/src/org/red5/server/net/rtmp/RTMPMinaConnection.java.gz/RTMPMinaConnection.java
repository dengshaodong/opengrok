<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["RTMPMinaConnection",51]]],["Package","xp",[["org.red5.server.net.rtmp",1]]],["Method","xmt",[["RTMPMinaConnection",71],["close",77],["connect",116],["getIoSession",191],["getPendingMessages",197],["getReadBytes",206],["getWrittenBytes",215],["invokeMethod",222],["isConnected",228],["onInactive",236],["rawWrite",242],["setIoSession",253],["write",270]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><span class="c">//import java.beans.ConstructorProperties;</span>
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=InetSocketAddress&amp;project=rtmp_client">InetSocketAddress</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=SocketAddress&amp;project=rtmp_client">SocketAddress</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Collections&amp;project=rtmp_client">Collections</a>;
<a class="l" name="27" href="#27">27</a>
<a class="l" name="28" href="#28">28</a><span class="c">//import javax.management.ObjectName;</span>
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=filterchain&amp;project=rtmp_client">filterchain</a>.<a href="/source/s?defs=IoFilterChain&amp;project=rtmp_client">IoFilterChain</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=IoSession&amp;project=rtmp_client">IoSession</a>;
<a class="l" name="33" href="#33">33</a><span class="c">//import org.red5.server.api.IContext;</span>
<a class="l" name="34" href="#34">34</a><span class="c">//import org.red5.server.api.IScope;</span>
<a class="l" name="35" href="#35">35</a><span class="c">//import org.red5.server.net.filter.TrafficShapingFilter;</span>
<a class="l" name="36" href="#36">36</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a>;
<a class="l" name="37" href="#37">37</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=codec&amp;project=rtmp_client">codec</a>.<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>;
<a class="l" name="38" href="#38">38</a><span class="c">//import org.red5.server.net.rtmp.event.ClientBW;</span>
<a class="l" name="39" href="#39">39</a><span class="c">//import org.red5.server.net.rtmp.event.ServerBW;</span>
<a class="hl" name="40" href="#40">40</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a>;
<a class="l" name="41" href="#41">41</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="42" href="#42">42</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="43" href="#43">43</a>
<a class="l" name="44" href="#44">44</a><span class="c">/**
<a class="l" name="45" href="#45">45</a> * Represents an RTMP connection using Mina.
<a class="l" name="46" href="#46">46</a> *
<a class="l" name="47" href="#47">47</a> * <strong>@see</strong> "<a href="http://mina.apache.org/report/trunk/apidocs/org/apache/mina/core/session/IoSession.html">http://mina.apache.org/report/trunk/apidocs/org/apache/mina/core/session/IoSession.html</a>"
<a class="l" name="48" href="#48">48</a> *
<a class="l" name="49" href="#49">49</a> * <strong>@author</strong> Paul Gregoire
<a class="hl" name="50" href="#50">50</a> */</span>
<a class="l" name="51" href="#51">51</a><b>public</b> <b>class</b> <a class="xc" name="RTMPMinaConnection"/><a href="/source/s?refs=RTMPMinaConnection&amp;project=rtmp_client" class="xc">RTMPMinaConnection</a> <b>extends</b> <a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> {
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>	<b>protected</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a href="/source/s?defs=RTMPMinaConnection&amp;project=rtmp_client">RTMPMinaConnection</a>.<b>class</b>);
<a class="l" name="54" href="#54">54</a>
<a class="l" name="55" href="#55">55</a>	<span class="c">/**
<a class="l" name="56" href="#56">56</a>	 * MINA I/O session, connection between two end points
<a class="l" name="57" href="#57">57</a>	 */</span>
<a class="l" name="58" href="#58">58</a>	<b>private</b> <b>volatile</b> <a href="/source/s?defs=IoSession&amp;project=rtmp_client">IoSession</a> <a class="xfld" name="ioSession"/><a href="/source/s?refs=ioSession&amp;project=rtmp_client" class="xfld">ioSession</a>;
<a class="l" name="59" href="#59">59</a>
<a class="hl" name="60" href="#60">60</a>	<span class="c">/**
<a class="l" name="61" href="#61">61</a>	 * MBean object name used for <a href="/source/s?path=de/">de</a>/<a href="/source/s?path=de/registration">registration</a> purposes.
<a class="l" name="62" href="#62">62</a>	 */</span>
<a class="l" name="63" href="#63">63</a>	<span class="c">//private volatile ObjectName oName;</span>
<a class="l" name="64" href="#64">64</a>
<a class="l" name="65" href="#65">65</a>	{
<a class="l" name="66" href="#66">66</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"RTMPMinaConnection created"</span>);
<a class="l" name="67" href="#67">67</a>	}
<a class="l" name="68" href="#68">68</a>
<a class="l" name="69" href="#69">69</a>	<span class="c">/** Constructs a new RTMPMinaConnection. */</span>
<a class="hl" name="70" href="#70">70</a>	<span class="c">//@ConstructorProperties(value={"persistent"})</span>
<a class="l" name="71" href="#71">71</a>	<b>public</b> <a class="xmt" name="RTMPMinaConnection"/><a href="/source/s?refs=RTMPMinaConnection&amp;project=rtmp_client" class="xmt">RTMPMinaConnection</a>() {
<a class="l" name="72" href="#72">72</a>		<b>super</b>(<a href="/source/s?defs=PERSISTENT&amp;project=rtmp_client">PERSISTENT</a>);
<a class="l" name="73" href="#73">73</a>	}
<a class="l" name="74" href="#74">74</a>
<a class="l" name="75" href="#75">75</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="76" href="#76">76</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="77" href="#77">77</a>	<b>public</b> <b>void</b> <a class="xmt" name="close"/><a href="/source/s?refs=close&amp;project=rtmp_client" class="xmt">close</a>() {
<a class="l" name="78" href="#78">78</a>		<b>super</b>.<a class="d" href="#close">close</a>();
<a class="l" name="79" href="#79">79</a>		<b>if</b> (<a class="d" href="#ioSession">ioSession</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="80" href="#80">80</a>			<a href="/source/s?defs=IoFilterChain&amp;project=rtmp_client">IoFilterChain</a> <a href="/source/s?defs=filters&amp;project=rtmp_client">filters</a> =	<a class="d" href="#ioSession">ioSession</a>.<a href="/source/s?defs=getFilterChain&amp;project=rtmp_client">getFilterChain</a>();
<a class="l" name="81" href="#81">81</a>			<span class="c">//check if it exists and remove</span>
<a class="l" name="82" href="#82">82</a>			<b>if</b> (<a href="/source/s?defs=filters&amp;project=rtmp_client">filters</a>.<a href="/source/s?defs=contains&amp;project=rtmp_client">contains</a>(<span class="s">"bandwidthFilter"</span>)) {
<a class="l" name="83" href="#83">83</a>        		<a class="d" href="#ioSession">ioSession</a>.<a href="/source/s?defs=getFilterChain&amp;project=rtmp_client">getFilterChain</a>().<a href="/source/s?defs=remove&amp;project=rtmp_client">remove</a>(<span class="s">"bandwidthFilter"</span>);
<a class="l" name="84" href="#84">84</a>			}
<a class="l" name="85" href="#85">85</a>			<span class="c">// update our state</span>
<a class="l" name="86" href="#86">86</a>			<b>if</b> (<a class="d" href="#ioSession">ioSession</a>.<a href="/source/s?defs=containsAttribute&amp;project=rtmp_client">containsAttribute</a>(<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a>.<a href="/source/s?defs=SESSION_KEY&amp;project=rtmp_client">SESSION_KEY</a>)) {
<a class="l" name="87" href="#87">87</a>				<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a> = (<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>) <a class="d" href="#ioSession">ioSession</a>.<a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a>.<a href="/source/s?defs=SESSION_KEY&amp;project=rtmp_client">SESSION_KEY</a>);
<a class="l" name="88" href="#88">88</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"RTMP state: {}"</span>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="89" href="#89">89</a>				<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=setState&amp;project=rtmp_client">setState</a>(<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=STATE_DISCONNECTING&amp;project=rtmp_client">STATE_DISCONNECTING</a>);
<a class="hl" name="90" href="#90">90</a>			}
<a class="l" name="91" href="#91">91</a>			<span class="c">// accept no further incoming data</span>
<a class="l" name="92" href="#92">92</a>			<a class="d" href="#ioSession">ioSession</a>.<a href="/source/s?defs=suspendRead&amp;project=rtmp_client">suspendRead</a>();
<a class="l" name="93" href="#93">93</a>			<span class="c">// close now, no flushing, no waiting</span>
<a class="l" name="94" href="#94">94</a>			<a class="d" href="#ioSession">ioSession</a>.<a class="d" href="#close">close</a>(<b>true</b>);
<a class="l" name="95" href="#95">95</a>			<span class="c">// only close socket after all pending data has been sent, this does not</span>
<a class="l" name="96" href="#96">96</a>			<span class="c">// work as expected when using RTMPE</span>
<a class="l" name="97" href="#97">97</a>			<span class="c">//CloseFuture future = ioSession.close(false);</span>
<a class="l" name="98" href="#98">98</a>			<span class="c">// wait until the connection is closed</span>
<a class="l" name="99" href="#99">99</a>			<span class="c">//future.awaitUninterruptibly();</span>
<a class="hl" name="100" href="#100">100</a>			<span class="c">// now connection should be closed.</span>
<a class="l" name="101" href="#101">101</a>			<span class="c">//if (!future.isClosed()) {</span>
<a class="l" name="102" href="#102">102</a>				<span class="c">// force the close</span>
<a class="l" name="103" href="#103">103</a>			<span class="c">//	ioSession.close(true);</span>
<a class="l" name="104" href="#104">104</a>			<span class="c">//}</span>
<a class="l" name="105" href="#105">105</a>		}
<a class="l" name="106" href="#106">106</a>		<span class="c">//de-register with JMX</span>
<a class="l" name="107" href="#107">107</a><span class="c">//		try {</span>
<a class="l" name="108" href="#108">108</a><span class="c">//		    JMXAgent.unregisterMBean(oName);</span>
<a class="l" name="109" href="#109">109</a><span class="c">//		} catch (Exception e) {</span>
<a class="hl" name="110" href="#110">110</a><span class="c">//		    //sometimes the client is not registered in jmx</span>
<a class="l" name="111" href="#111">111</a><span class="c">//		}</span>
<a class="l" name="112" href="#112">112</a>	}
<a class="l" name="113" href="#113">113</a>
<a class="l" name="114" href="#114">114</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"cast"</span>)
<a class="l" name="115" href="#115">115</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="116" href="#116">116</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="connect"/><a href="/source/s?refs=connect&amp;project=rtmp_client" class="xmt">connect</a>( <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xa" name="params"/><a href="/source/s?refs=params&amp;project=rtmp_client" class="xa">params</a>) {
<a class="l" name="117" href="#117">117</a><span class="c">//		log.debug("Connect scope: {}", newScope);</span>
<a class="l" name="118" href="#118">118</a>		<b>boolean</b> <a href="/source/s?defs=success&amp;project=rtmp_client">success</a> = <b>super</b>.<a class="d" href="#connect">connect</a>( <a class="d" href="#params">params</a>);
<a class="l" name="119" href="#119">119</a>		<b>if</b> (!<a href="/source/s?defs=success&amp;project=rtmp_client">success</a>) {
<a class="hl" name="120" href="#120">120</a>			<b>return</b> <b>false</b>;
<a class="l" name="121" href="#121">121</a>		}
<a class="l" name="122" href="#122">122</a>		@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unused"</span>)
<a class="l" name="123" href="#123">123</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=hostStr&amp;project=rtmp_client">hostStr</a> = <a href="/source/s?defs=host&amp;project=rtmp_client">host</a>;
<a class="l" name="124" href="#124">124</a>		@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unused"</span>)
<a class="l" name="125" href="#125">125</a>		<b>int</b> <a href="/source/s?defs=port&amp;project=rtmp_client">port</a> = <span class="n">1935</span>;
<a class="l" name="126" href="#126">126</a>		<b>if</b> (<a href="/source/s?defs=host&amp;project=rtmp_client">host</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a href="/source/s?defs=host&amp;project=rtmp_client">host</a>.<a href="/source/s?defs=indexOf&amp;project=rtmp_client">indexOf</a>(<span class="s">":"</span>) &gt; -<span class="n">1</span>) {
<a class="l" name="127" href="#127">127</a>			<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>[] <a href="/source/s?defs=arr&amp;project=rtmp_client">arr</a> = <a href="/source/s?defs=host&amp;project=rtmp_client">host</a>.<a href="/source/s?defs=split&amp;project=rtmp_client">split</a>(<span class="s">":"</span>);
<a class="l" name="128" href="#128">128</a>			<a href="/source/s?defs=hostStr&amp;project=rtmp_client">hostStr</a> = <a href="/source/s?defs=arr&amp;project=rtmp_client">arr</a>[<span class="n">0</span>];
<a class="l" name="129" href="#129">129</a>			<a href="/source/s?defs=port&amp;project=rtmp_client">port</a> = <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=parseInt&amp;project=rtmp_client">parseInt</a>(<a href="/source/s?defs=arr&amp;project=rtmp_client">arr</a>[<span class="n">1</span>]);
<a class="hl" name="130" href="#130">130</a>		}
<a class="l" name="131" href="#131">131</a>		<span class="c">//if the client is null for some reason, skip the jmx registration</span>
<a class="l" name="132" href="#132">132</a>		<b>if</b> (<a href="/source/s?defs=client&amp;project=rtmp_client">client</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="133" href="#133">133</a>    		<b>try</b> {
<a class="l" name="134" href="#134">134</a>				<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=cName&amp;project=rtmp_client">cName</a> = <b>this</b>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>().<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>();
<a class="l" name="135" href="#135">135</a>				<b>if</b> (<a href="/source/s?defs=cName&amp;project=rtmp_client">cName</a>.<a href="/source/s?defs=indexOf&amp;project=rtmp_client">indexOf</a>(<span class="s">'.'</span>) != -<span class="n">1</span>) {
<a class="l" name="136" href="#136">136</a>					<a href="/source/s?defs=cName&amp;project=rtmp_client">cName</a> = <a href="/source/s?defs=cName&amp;project=rtmp_client">cName</a>.<a href="/source/s?defs=substring&amp;project=rtmp_client">substring</a>(<a href="/source/s?defs=cName&amp;project=rtmp_client">cName</a>.<a href="/source/s?defs=lastIndexOf&amp;project=rtmp_client">lastIndexOf</a>(<span class="s">'.'</span>)).<a href="/source/s?defs=replaceFirst&amp;project=rtmp_client">replaceFirst</a>(<span class="s">"[\\.]"</span>, <span class="s">""</span>);
<a class="l" name="137" href="#137">137</a>				}
<a class="l" name="138" href="#138">138</a>			    <span class="c">// Create a new mbean for this instance</span>
<a class="l" name="139" href="#139">139</a><span class="c">//			    oName = JMXFactory.createObjectName("type", cName, "connectionType", type, "host", hostStr, "port", port + "", "clientId", client.getId());</span>
<a class="hl" name="140" href="#140">140</a><span class="c">//			    JMXAgent.registerMBean(this, this.getClass().getName(),	RTMPMinaConnectionMXBean.class, oName);</span>
<a class="l" name="141" href="#141">141</a>    		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="142" href="#142">142</a>    			<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Exception registering mbean"</span>, e);
<a class="l" name="143" href="#143">143</a>    		}
<a class="l" name="144" href="#144">144</a>		} <b>else</b> {
<a class="l" name="145" href="#145">145</a>            <a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Client was null"</span>);
<a class="l" name="146" href="#146">146</a>		}
<a class="l" name="147" href="#147">147</a>		<span class="c">//add bandwidth filter</span>
<a class="l" name="148" href="#148">148</a>		<b>if</b> (<a class="d" href="#ioSession">ioSession</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="149" href="#149">149</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Top level scope detected, configuration will be applied if it exists"</span>);
<a class="hl" name="150" href="#150">150</a><span class="c">//			IContext ctx = scope.getContext();</span>
<a class="l" name="151" href="#151">151</a><span class="c">//			if (ctx != null) {</span>
<a class="l" name="152" href="#152">152</a><span class="c">//				log.debug("Context was found");</span>
<a class="l" name="153" href="#153">153</a><span class="c">//				IoFilterChain filters =	ioSession.getFilterChain();</span>
<a class="l" name="154" href="#154">154</a><span class="c">//				//add it if it does not exist</span>
<a class="l" name="155" href="#155">155</a><span class="c">//				if (!filters.contains("bandwidthFilter")) {</span>
<a class="l" name="156" href="#156">156</a><span class="c">//					//look for the bean first</span>
<a class="l" name="157" href="#157">157</a><span class="c">//					if (ctx.hasBean("bandwidthFilter")) {</span>
<a class="l" name="158" href="#158">158</a><span class="c">//						TrafficShapingFilter filter = (TrafficShapingFilter) ctx.getBean("bandwidthFilter");</span>
<a class="l" name="159" href="#159">159</a><span class="c">//                		//load the each after the last</span>
<a class="hl" name="160" href="#160">160</a><span class="c">//                		ioSession.getFilterChain().addAfter("protocolFilter", "bandwidthFilter", filter);</span>
<a class="l" name="161" href="#161">161</a><span class="c">//                		//notify client about new bandwidth settings (in bytes per second)</span>
<a class="l" name="162" href="#162">162</a><span class="c">//                		int downStream = filter.getMaxReadThroughput();</span>
<a class="l" name="163" href="#163">163</a><span class="c">//                		int upStream = filter.getMaxWriteThroughput();</span>
<a class="l" name="164" href="#164">164</a><span class="c">//                		if (downStream &gt; 0) {</span>
<a class="l" name="165" href="#165">165</a><span class="c">//                			ServerBW serverBW = new ServerBW((int) downStream / 8);</span>
<a class="l" name="166" href="#166">166</a><span class="c">//                			getChannel(2).write(serverBW);</span>
<a class="l" name="167" href="#167">167</a><span class="c">//                		}</span>
<a class="l" name="168" href="#168">168</a><span class="c">//                		if (upStream &gt; 0) {</span>
<a class="l" name="169" href="#169">169</a><span class="c">//                			ClientBW clientBW = new ClientBW((int) upStream / 8, (byte) 0);</span>
<a class="hl" name="170" href="#170">170</a><span class="c">//                			getChannel(2).write(clientBW);</span>
<a class="l" name="171" href="#171">171</a><span class="c">//            				// Update generation of BytesRead messages</span>
<a class="l" name="172" href="#172">172</a><span class="c">//            				// TODO: what are the correct values here?</span>
<a class="l" name="173" href="#173">173</a><span class="c">//            				bytesReadInterval = (int) upStream / 8;</span>
<a class="l" name="174" href="#174">174</a><span class="c">//            				nextBytesRead = (int) getWrittenBytes();</span>
<a class="l" name="175" href="#175">175</a><span class="c">//                		}</span>
<a class="l" name="176" href="#176">176</a><span class="c">//</span>
<a class="l" name="177" href="#177">177</a><span class="c">//					}</span>
<a class="l" name="178" href="#178">178</a><span class="c">//				}</span>
<a class="l" name="179" href="#179">179</a><span class="c">//			}</span>
<a class="hl" name="180" href="#180">180</a>		} <b>else</b> {
<a class="l" name="181" href="#181">181</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Session was null"</span>);
<a class="l" name="182" href="#182">182</a>		}
<a class="l" name="183" href="#183">183</a>		<b>return</b> <a href="/source/s?defs=success&amp;project=rtmp_client">success</a>;
<a class="l" name="184" href="#184">184</a>	}
<a class="l" name="185" href="#185">185</a>
<a class="l" name="186" href="#186">186</a>	<span class="c">/**
<a class="l" name="187" href="#187">187</a>	 * Return MINA I/O session.
<a class="l" name="188" href="#188">188</a>	 *
<a class="l" name="189" href="#189">189</a>	 * <strong>@return</strong> MINA O/I session, connection between two end-points
<a class="hl" name="190" href="#190">190</a>	 */</span>
<a class="l" name="191" href="#191">191</a>	<b>public</b> <a href="/source/s?defs=IoSession&amp;project=rtmp_client">IoSession</a> <a class="xmt" name="getIoSession"/><a href="/source/s?refs=getIoSession&amp;project=rtmp_client" class="xmt">getIoSession</a>() {
<a class="l" name="192" href="#192">192</a>		<b>return</b> <a class="d" href="#ioSession">ioSession</a>;
<a class="l" name="193" href="#193">193</a>	}
<a class="l" name="194" href="#194">194</a>
<a class="l" name="195" href="#195">195</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="196" href="#196">196</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="197" href="#197">197</a>	<b>public</b> <b>long</b> <a class="xmt" name="getPendingMessages"/><a href="/source/s?refs=getPendingMessages&amp;project=rtmp_client" class="xmt">getPendingMessages</a>() {
<a class="l" name="198" href="#198">198</a>		<b>if</b> (<a class="d" href="#ioSession">ioSession</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="199" href="#199">199</a>			<b>return</b> <a class="d" href="#ioSession">ioSession</a>.<a href="/source/s?defs=getScheduledWriteMessages&amp;project=rtmp_client">getScheduledWriteMessages</a>();
<a class="hl" name="200" href="#200">200</a>		}
<a class="l" name="201" href="#201">201</a>		<b>return</b> <span class="n">0</span>;
<a class="l" name="202" href="#202">202</a>	}
<a class="l" name="203" href="#203">203</a>
<a class="l" name="204" href="#204">204</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="205" href="#205">205</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="206" href="#206">206</a>	<b>public</b> <b>long</b> <a class="xmt" name="getReadBytes"/><a href="/source/s?refs=getReadBytes&amp;project=rtmp_client" class="xmt">getReadBytes</a>() {
<a class="l" name="207" href="#207">207</a>		<b>if</b> (<a class="d" href="#ioSession">ioSession</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="208" href="#208">208</a>			<b>return</b> <a class="d" href="#ioSession">ioSession</a>.<a class="d" href="#getReadBytes">getReadBytes</a>();
<a class="l" name="209" href="#209">209</a>		}
<a class="hl" name="210" href="#210">210</a>		<b>return</b> <span class="n">0</span>;
<a class="l" name="211" href="#211">211</a>	}
<a class="l" name="212" href="#212">212</a>
<a class="l" name="213" href="#213">213</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="214" href="#214">214</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="215" href="#215">215</a>	<b>public</b> <b>long</b> <a class="xmt" name="getWrittenBytes"/><a href="/source/s?refs=getWrittenBytes&amp;project=rtmp_client" class="xmt">getWrittenBytes</a>() {
<a class="l" name="216" href="#216">216</a>		<b>if</b> (<a class="d" href="#ioSession">ioSession</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="217" href="#217">217</a>			<b>return</b> <a class="d" href="#ioSession">ioSession</a>.<a class="d" href="#getWrittenBytes">getWrittenBytes</a>();
<a class="l" name="218" href="#218">218</a>		}
<a class="l" name="219" href="#219">219</a>		<b>return</b> <span class="n">0</span>;
<a class="hl" name="220" href="#220">220</a>	}
<a class="l" name="221" href="#221">221</a>
<a class="l" name="222" href="#222">222</a>	<b>public</b> <b>void</b> <a class="xmt" name="invokeMethod"/><a href="/source/s?refs=invokeMethod&amp;project=rtmp_client" class="xmt">invokeMethod</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="method"/><a href="/source/s?refs=method&amp;project=rtmp_client" class="xa">method</a>) {
<a class="l" name="223" href="#223">223</a>		<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>(<a class="d" href="#method">method</a>);
<a class="l" name="224" href="#224">224</a>	}
<a class="l" name="225" href="#225">225</a>
<a class="l" name="226" href="#226">226</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="227" href="#227">227</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="228" href="#228">228</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="isConnected"/><a href="/source/s?refs=isConnected&amp;project=rtmp_client" class="xmt">isConnected</a>() {
<a class="l" name="229" href="#229">229</a>		<span class="c">// XXX Paul: not sure isClosing is actually working as we expect here</span>
<a class="hl" name="230" href="#230">230</a>		<b>return</b> <b>true</b>;
<a class="l" name="231" href="#231">231</a>		<span class="c">//return super.isConnected() &amp;&amp; (ioSession != null) &amp;&amp; ioSession.isConnected(); // &amp;&amp; !ioSession.isClosing();</span>
<a class="l" name="232" href="#232">232</a>	}
<a class="l" name="233" href="#233">233</a>
<a class="l" name="234" href="#234">234</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="235" href="#235">235</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="236" href="#236">236</a>	<b>protected</b> <b>void</b> <a class="xmt" name="onInactive"/><a href="/source/s?refs=onInactive&amp;project=rtmp_client" class="xmt">onInactive</a>() {
<a class="l" name="237" href="#237">237</a>		<b>this</b>.<a class="d" href="#close">close</a>();
<a class="l" name="238" href="#238">238</a>	}
<a class="l" name="239" href="#239">239</a>
<a class="hl" name="240" href="#240">240</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="241" href="#241">241</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="242" href="#242">242</a>	<b>public</b> <b>void</b> <a class="xmt" name="rawWrite"/><a href="/source/s?refs=rawWrite&amp;project=rtmp_client" class="xmt">rawWrite</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>) {
<a class="l" name="243" href="#243">243</a>		<b>if</b> (<a class="d" href="#ioSession">ioSession</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="244" href="#244">244</a>			<a class="d" href="#ioSession">ioSession</a>.<a class="d" href="#write">write</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>);
<a class="l" name="245" href="#245">245</a>		}
<a class="l" name="246" href="#246">246</a>	}
<a class="l" name="247" href="#247">247</a>
<a class="l" name="248" href="#248">248</a>	<span class="c">/**
<a class="l" name="249" href="#249">249</a>	 * Setter for MINA I/O session (connection).
<a class="hl" name="250" href="#250">250</a>	 *
<a class="l" name="251" href="#251">251</a>	 * <strong>@param</strong> <em>protocolSession</em>  Protocol session
<a class="l" name="252" href="#252">252</a>	 */</span>
<a class="l" name="253" href="#253">253</a>	<b>public</b> <b>void</b> <a class="xmt" name="setIoSession"/><a href="/source/s?refs=setIoSession&amp;project=rtmp_client" class="xmt">setIoSession</a>(<a href="/source/s?defs=IoSession&amp;project=rtmp_client">IoSession</a> <a class="xa" name="protocolSession"/><a href="/source/s?refs=protocolSession&amp;project=rtmp_client" class="xa">protocolSession</a>) {
<a class="l" name="254" href="#254">254</a>		<a href="/source/s?defs=SocketAddress&amp;project=rtmp_client">SocketAddress</a> <a href="/source/s?defs=remote&amp;project=rtmp_client">remote</a> = <a class="d" href="#protocolSession">protocolSession</a>.<a href="/source/s?defs=getRemoteAddress&amp;project=rtmp_client">getRemoteAddress</a>();
<a class="l" name="255" href="#255">255</a>		<b>if</b> (<a href="/source/s?defs=remote&amp;project=rtmp_client">remote</a> <b>instanceof</b> <a href="/source/s?defs=InetSocketAddress&amp;project=rtmp_client">InetSocketAddress</a>) {
<a class="l" name="256" href="#256">256</a>			<a href="/source/s?defs=remoteAddress&amp;project=rtmp_client">remoteAddress</a> = ((<a href="/source/s?defs=InetSocketAddress&amp;project=rtmp_client">InetSocketAddress</a>) <a href="/source/s?defs=remote&amp;project=rtmp_client">remote</a>).<a href="/source/s?defs=getAddress&amp;project=rtmp_client">getAddress</a>().<a href="/source/s?defs=getHostAddress&amp;project=rtmp_client">getHostAddress</a>();
<a class="l" name="257" href="#257">257</a>			<a href="/source/s?defs=remotePort&amp;project=rtmp_client">remotePort</a> = ((<a href="/source/s?defs=InetSocketAddress&amp;project=rtmp_client">InetSocketAddress</a>) <a href="/source/s?defs=remote&amp;project=rtmp_client">remote</a>).<a href="/source/s?defs=getPort&amp;project=rtmp_client">getPort</a>();
<a class="l" name="258" href="#258">258</a>		} <b>else</b> {
<a class="l" name="259" href="#259">259</a>			<a href="/source/s?defs=remoteAddress&amp;project=rtmp_client">remoteAddress</a> = <a href="/source/s?defs=remote&amp;project=rtmp_client">remote</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>();
<a class="hl" name="260" href="#260">260</a>			<a href="/source/s?defs=remotePort&amp;project=rtmp_client">remotePort</a> = -<span class="n">1</span>;
<a class="l" name="261" href="#261">261</a>		}
<a class="l" name="262" href="#262">262</a>		<a href="/source/s?defs=remoteAddresses&amp;project=rtmp_client">remoteAddresses</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt;(<span class="n">1</span>);
<a class="l" name="263" href="#263">263</a>		<a href="/source/s?defs=remoteAddresses&amp;project=rtmp_client">remoteAddresses</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=remoteAddress&amp;project=rtmp_client">remoteAddress</a>);
<a class="l" name="264" href="#264">264</a>		<a href="/source/s?defs=remoteAddresses&amp;project=rtmp_client">remoteAddresses</a> = <a href="/source/s?defs=Collections&amp;project=rtmp_client">Collections</a>.<a href="/source/s?defs=unmodifiableList&amp;project=rtmp_client">unmodifiableList</a>(<a href="/source/s?defs=remoteAddresses&amp;project=rtmp_client">remoteAddresses</a>);
<a class="l" name="265" href="#265">265</a>		<b>this</b>.<a class="d" href="#ioSession">ioSession</a> = <a class="d" href="#protocolSession">protocolSession</a>;
<a class="l" name="266" href="#266">266</a>	}
<a class="l" name="267" href="#267">267</a>
<a class="l" name="268" href="#268">268</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="269" href="#269">269</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="hl" name="270" href="#270">270</a>	<b>public</b> <b>void</b> <a class="xmt" name="write"/><a href="/source/s?refs=write&amp;project=rtmp_client" class="xmt">write</a>(<a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>) {
<a class="l" name="271" href="#271">271</a>		<b>if</b> (<a class="d" href="#ioSession">ioSession</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="272" href="#272">272</a>			<a href="/source/s?defs=writingMessage&amp;project=rtmp_client">writingMessage</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>);
<a class="l" name="273" href="#273">273</a>			<a class="d" href="#ioSession">ioSession</a>.<a class="d" href="#write">write</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>);
<a class="l" name="274" href="#274">274</a>		}
<a class="l" name="275" href="#275">275</a>	}
<a class="l" name="276" href="#276">276</a>
<a class="l" name="277" href="#277">277</a><span class="c">//	@Override</span>
<a class="l" name="278" href="#278">278</a><span class="c">//	public IScope getScope() {</span>
<a class="l" name="279" href="#279">279</a><span class="c">//		// TODO Auto-generated method stub</span>
<a class="hl" name="280" href="#280">280</a><span class="c">//		return null;</span>
<a class="l" name="281" href="#281">281</a><span class="c">//	}</span>
<a class="l" name="282" href="#282">282</a>}
<a class="l" name="283" href="#283">283</a>