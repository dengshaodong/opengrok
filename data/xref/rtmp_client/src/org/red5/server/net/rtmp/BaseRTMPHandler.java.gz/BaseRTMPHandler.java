<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["BaseRTMPHandler",61]]],["Package","xp",[["org.red5.server.net.rtmp",1]]],["Method","xmt",[["connectionClosed",215],["connectionOpened",101],["getHostname",227],["getStreamId",81],["handlePendingCallResult",247],["messageReceived",110],["messageSent",205],["onChunkSize",285],["onInvoke",301],["onPing",315],["onSharedObject",345],["onStreamBytesRead",329],["setStreamId",91]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashSet&amp;project=rtmp_client">HashSet</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>;
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a class="d" href="#session">session</a>.<a href="/source/s?defs=IoSession&amp;project=rtmp_client">IoSession</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=Red5&amp;project=rtmp_client">Red5</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=IEventDispatcher&amp;project=rtmp_client">IEventDispatcher</a>;
<a class="l" name="29" href="#29">29</a><span class="c">//import org.red5.server.api.scheduling.ISchedulingService;</span>
<a class="hl" name="30" href="#30">30</a><span class="c">//import org.red5.server.api.stream.IClientStream;</span>
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a href="/source/s?defs=codec&amp;project=rtmp_client">codec</a>.<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>;
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=BytesRead&amp;project=rtmp_client">BytesRead</a>;
<a class="l" name="34" href="#34">34</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=ChunkSize&amp;project=rtmp_client">ChunkSize</a>;
<a class="l" name="35" href="#35">35</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a>;
<a class="l" name="36" href="#36">36</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>;
<a class="l" name="37" href="#37">37</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>;
<a class="l" name="38" href="#38">38</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>;
<a class="l" name="39" href="#39">39</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Unknown&amp;project=rtmp_client">Unknown</a>;
<a class="hl" name="40" href="#40">40</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a class="d" href="#message">message</a>.<a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>;
<a class="l" name="41" href="#41">41</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a class="d" href="#message">message</a>.<a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a>;
<a class="l" name="42" href="#42">42</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a class="d" href="#message">message</a>.<a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a>;
<a class="l" name="43" href="#43">43</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a class="d" href="#message">message</a>.<a href="/source/s?defs=StreamAction&amp;project=rtmp_client">StreamAction</a>;
<a class="l" name="44" href="#44">44</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a href="/source/s?defs=status&amp;project=rtmp_client">status</a>.<a href="/source/s?defs=StatusCodes&amp;project=rtmp_client">StatusCodes</a>;
<a class="l" name="45" href="#45">45</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a>;
<a class="l" name="46" href="#46">46</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a>;
<a class="l" name="47" href="#47">47</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a>;
<a class="l" name="48" href="#48">48</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=so&amp;project=rtmp_client">so</a>.<a href="/source/s?defs=SharedObjectMessage&amp;project=rtmp_client">SharedObjectMessage</a>;
<a class="l" name="49" href="#49">49</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=IClientStream&amp;project=rtmp_client">IClientStream</a>;
<a class="hl" name="50" href="#50">50</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="51" href="#51">51</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="52" href="#52">52</a><span class="c">//import org.springframework.beans.BeansException;</span>
<a class="l" name="53" href="#53">53</a><span class="c">//import org.springframework.context.ApplicationContext;</span>
<a class="l" name="54" href="#54">54</a><span class="c">//import org.springframework.context.ApplicationContextAware;</span>
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a><span class="c">/**
<a class="l" name="57" href="#57">57</a> * Base class for all RTMP handlers.
<a class="l" name="58" href="#58">58</a> *
<a class="l" name="59" href="#59">59</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="hl" name="60" href="#60">60</a> */</span>
<a class="l" name="61" href="#61">61</a><b>public</b> <b>abstract</b> <b>class</b> <a class="xc" name="BaseRTMPHandler"/><a href="/source/s?refs=BaseRTMPHandler&amp;project=rtmp_client" class="xc">BaseRTMPHandler</a> <b>implements</b> <a href="/source/s?defs=IRTMPHandler&amp;project=rtmp_client">IRTMPHandler</a>, <a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>, <a href="/source/s?defs=StatusCodes&amp;project=rtmp_client">StatusCodes</a> {
<a class="l" name="62" href="#62">62</a>	<span class="c">/**
<a class="l" name="63" href="#63">63</a>	 * Logger
<a class="l" name="64" href="#64">64</a>	 */</span>
<a class="l" name="65" href="#65">65</a>	<b>private</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a class="d" href="#BaseRTMPHandler">BaseRTMPHandler</a>.<b>class</b>);
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a>	<span class="c">/**
<a class="l" name="68" href="#68">68</a>	 * Application context
<a class="l" name="69" href="#69">69</a>	 */</span>
<a class="hl" name="70" href="#70">70</a><span class="c">//	private ApplicationContext appCtx;</span>
<a class="l" name="71" href="#71">71</a>
<a class="l" name="72" href="#72">72</a>	<span class="c">// XXX: HACK HACK HACK to support stream ids</span>
<a class="l" name="73" href="#73">73</a>	<b>private</b> <b>static</b> <a href="/source/s?defs=ThreadLocal&amp;project=rtmp_client">ThreadLocal</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt; <a class="xfld" name="streamLocal"/><a href="/source/s?refs=streamLocal&amp;project=rtmp_client" class="xfld">streamLocal</a> = <b>new</b> <a href="/source/s?defs=ThreadLocal&amp;project=rtmp_client">ThreadLocal</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt;();
<a class="l" name="74" href="#74">74</a>
<a class="l" name="75" href="#75">75</a>	<span class="c">/**
<a class="l" name="76" href="#76">76</a>	 * Getter for stream ID.
<a class="l" name="77" href="#77">77</a>	 *
<a class="l" name="78" href="#78">78</a>	 * <strong>@return</strong> Stream ID
<a class="l" name="79" href="#79">79</a>	 */</span>
<a class="hl" name="80" href="#80">80</a>	<span class="c">// XXX: HACK HACK HACK to support stream ids</span>
<a class="l" name="81" href="#81">81</a>	<b>public</b> <b>static</b> <b>int</b> <a class="xmt" name="getStreamId"/><a href="/source/s?refs=getStreamId&amp;project=rtmp_client" class="xmt">getStreamId</a>() {
<a class="l" name="82" href="#82">82</a>		<b>return</b> <a class="d" href="#streamLocal">streamLocal</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>().<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>();
<a class="l" name="83" href="#83">83</a>	}
<a class="l" name="84" href="#84">84</a>
<a class="l" name="85" href="#85">85</a>	<span class="c">/**
<a class="l" name="86" href="#86">86</a>	 * Setter for stream Id.
<a class="l" name="87" href="#87">87</a>	 *
<a class="l" name="88" href="#88">88</a>	 * <strong>@param</strong> <em>id</em>
<a class="l" name="89" href="#89">89</a>	 *            Stream id
<a class="hl" name="90" href="#90">90</a>	 */</span>
<a class="l" name="91" href="#91">91</a>	<b>private</b> <b>static</b> <b>void</b> <a class="xmt" name="setStreamId"/><a href="/source/s?refs=setStreamId&amp;project=rtmp_client" class="xmt">setStreamId</a>(<b>int</b> <a class="xa" name="id"/><a href="/source/s?refs=id&amp;project=rtmp_client" class="xa">id</a>) {
<a class="l" name="92" href="#92">92</a>		<a class="d" href="#streamLocal">streamLocal</a>.<a href="/source/s?defs=set&amp;project=rtmp_client">set</a>(<a class="d" href="#id">id</a>);
<a class="l" name="93" href="#93">93</a>	}
<a class="l" name="94" href="#94">94</a>
<a class="l" name="95" href="#95">95</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="96" href="#96">96</a><span class="c">//	public void setApplicationContext(ApplicationContext appCtx) throws BeansException {</span>
<a class="l" name="97" href="#97">97</a><span class="c">//		this.appCtx = appCtx;</span>
<a class="l" name="98" href="#98">98</a><span class="c">//	}</span>
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="101" href="#101">101</a>	<b>public</b> <b>void</b> <a class="xmt" name="connectionOpened"/><a href="/source/s?refs=connectionOpened&amp;project=rtmp_client" class="xmt">connectionOpened</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xa" name="conn"/><a href="/source/s?refs=conn&amp;project=rtmp_client" class="xa">conn</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="state"/><a href="/source/s?refs=state&amp;project=rtmp_client" class="xa">state</a>) {
<a class="l" name="102" href="#102">102</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"connectionOpened - conn: {} state: {}"</span>, <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>, <a href="/source/s?defs=state&amp;project=rtmp_client">state</a>);
<a class="l" name="103" href="#103">103</a><span class="c">//		if (state.getMode() == RTMP.MODE_SERVER &amp;&amp; appCtx != null) {</span>
<a class="l" name="104" href="#104">104</a><span class="c">//			ISchedulingService service = (ISchedulingService) appCtx.getBean(ISchedulingService.BEAN_NAME);</span>
<a class="l" name="105" href="#105">105</a><span class="c">//			conn.startWaitForHandshake(service);</span>
<a class="l" name="106" href="#106">106</a><span class="c">//		}</span>
<a class="l" name="107" href="#107">107</a>	}
<a class="l" name="108" href="#108">108</a>
<a class="l" name="109" href="#109">109</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="110" href="#110">110</a>	<b>public</b> <b>void</b> <a class="xmt" name="messageReceived"/><a href="/source/s?refs=messageReceived&amp;project=rtmp_client" class="xmt">messageReceived</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>, <a href="/source/s?defs=IoSession&amp;project=rtmp_client">IoSession</a> <a class="xa" name="session"/><a href="/source/s?refs=session&amp;project=rtmp_client" class="xa">session</a>) <b>throws</b> <a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> {
<a class="l" name="111" href="#111">111</a><span class="c">//		log.error("messageReceived,need handle this!!");</span>
<a class="l" name="112" href="#112">112</a>		<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> = (<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>) <a class="d" href="#session">session</a>.<a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<a href="/source/s?defs=RTMP_CONNECTION_KEY&amp;project=rtmp_client">RTMP_CONNECTION_KEY</a>);
<a class="l" name="113" href="#113">113</a>		<a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a> <a class="d" href="#message">message</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="114" href="#114">114</a>		<b>try</b> {
<a class="l" name="115" href="#115">115</a>			<b>final</b> <a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a> <a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a> = (<a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a>) <a class="d" href="#in">in</a>;
<a class="l" name="116" href="#116">116</a>			<a class="d" href="#message">message</a> = <a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a>.<a href="/source/s?defs=getMessage&amp;project=rtmp_client">getMessage</a>();
<a class="l" name="117" href="#117">117</a>			<b>final</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a href="/source/s?defs=header&amp;project=rtmp_client">header</a> = <a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a>.<a href="/source/s?defs=getHeader&amp;project=rtmp_client">getHeader</a>();
<a class="l" name="118" href="#118">118</a>			<b>final</b> <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a> = <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=getChannel&amp;project=rtmp_client">getChannel</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getChannelId&amp;project=rtmp_client">getChannelId</a>());
<a class="l" name="119" href="#119">119</a>			<b>final</b> <a href="/source/s?defs=IClientStream&amp;project=rtmp_client">IClientStream</a> <a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a> = <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=getStreamById&amp;project=rtmp_client">getStreamById</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a class="d" href="#getStreamId">getStreamId</a>());
<a class="hl" name="120" href="#120">120</a>			<span class="c">//log.debug("Message received, header: {}", header);</span>
<a class="l" name="121" href="#121">121</a>			<span class="c">// Thread local performance ? Should we benchmark</span>
<a class="l" name="122" href="#122">122</a>			<a href="/source/s?defs=Red5&amp;project=rtmp_client">Red5</a>.<a href="/source/s?defs=setConnectionLocal&amp;project=rtmp_client">setConnectionLocal</a>(<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>);
<a class="l" name="123" href="#123">123</a>			<span class="c">// XXX: HACK HACK HACK to support stream ids</span>
<a class="l" name="124" href="#124">124</a>			<a class="d" href="#BaseRTMPHandler">BaseRTMPHandler</a>.<a class="d" href="#setStreamId">setStreamId</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a class="d" href="#getStreamId">getStreamId</a>());
<a class="l" name="125" href="#125">125</a>			<span class="c">// increase number of received messages</span>
<a class="l" name="126" href="#126">126</a>			<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a class="d" href="#messageReceived">messageReceived</a>();
<a class="l" name="127" href="#127">127</a>			<span class="c">// set the source of the message</span>
<a class="l" name="128" href="#128">128</a>			<a class="d" href="#message">message</a>.<a href="/source/s?defs=setSource&amp;project=rtmp_client">setSource</a>(<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>);
<a class="l" name="129" href="#129">129</a>			<span class="c">// process based on data type</span>
<a class="hl" name="130" href="#130">130</a>			<b>switch</b> (<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>()) {
<a class="l" name="131" href="#131">131</a>				<b>case</b> <a href="/source/s?defs=TYPE_CHUNK_SIZE&amp;project=rtmp_client">TYPE_CHUNK_SIZE</a>:
<a class="l" name="132" href="#132">132</a>					<a class="d" href="#onChunkSize">onChunkSize</a>(<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>, <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>, (<a href="/source/s?defs=ChunkSize&amp;project=rtmp_client">ChunkSize</a>) <a class="d" href="#message">message</a>);
<a class="l" name="133" href="#133">133</a>					<b>break</b>;
<a class="l" name="134" href="#134">134</a>				<b>case</b> <a href="/source/s?defs=TYPE_INVOKE&amp;project=rtmp_client">TYPE_INVOKE</a>:
<a class="l" name="135" href="#135">135</a>				<b>case</b> <a href="/source/s?defs=TYPE_FLEX_MESSAGE&amp;project=rtmp_client">TYPE_FLEX_MESSAGE</a>:
<a class="l" name="136" href="#136">136</a>					<a class="d" href="#onInvoke">onInvoke</a>(<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>, <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>, (<a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>) <a class="d" href="#message">message</a>, (<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>) <a class="d" href="#session">session</a>.<a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a>.<a href="/source/s?defs=SESSION_KEY&amp;project=rtmp_client">SESSION_KEY</a>));
<a class="l" name="137" href="#137">137</a>					<a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a> <a href="/source/s?defs=call&amp;project=rtmp_client">call</a> = ((<a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>) <a class="d" href="#message">message</a>).<a href="/source/s?defs=getCall&amp;project=rtmp_client">getCall</a>();
<a class="l" name="138" href="#138">138</a>					<b>if</b> (<a class="d" href="#message">message</a>.<a href="/source/s?defs=getHeader&amp;project=rtmp_client">getHeader</a>().<a class="d" href="#getStreamId">getStreamId</a>() != <span class="n">0</span> &amp;&amp; <a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=getServiceName&amp;project=rtmp_client">getServiceName</a>() == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a href="/source/s?defs=StreamAction&amp;project=rtmp_client">StreamAction</a>.<a href="/source/s?defs=PUBLISH&amp;project=rtmp_client">PUBLISH</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=getServiceMethodName&amp;project=rtmp_client">getServiceMethodName</a>())) {
<a class="l" name="139" href="#139">139</a>						<b>if</b> (<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="140" href="#140">140</a>							<span class="c">// Only dispatch if stream really was created</span>
<a class="l" name="141" href="#141">141</a>							((<a href="/source/s?defs=IEventDispatcher&amp;project=rtmp_client">IEventDispatcher</a>) <a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>).<a href="/source/s?defs=dispatchEvent&amp;project=rtmp_client">dispatchEvent</a>(<a class="d" href="#message">message</a>);
<a class="l" name="142" href="#142">142</a>						}
<a class="l" name="143" href="#143">143</a>					}
<a class="l" name="144" href="#144">144</a>					<b>break</b>;
<a class="l" name="145" href="#145">145</a>				<b>case</b> <a href="/source/s?defs=TYPE_NOTIFY&amp;project=rtmp_client">TYPE_NOTIFY</a>: <span class="c">// just like invoke, but does not return</span>
<a class="l" name="146" href="#146">146</a>					<b>if</b> (((<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>) <a class="d" href="#message">message</a>).<a href="/source/s?defs=getData&amp;project=rtmp_client">getData</a>() != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="147" href="#147">147</a>						<span class="c">// Stream metadata</span>
<a class="l" name="148" href="#148">148</a>						((<a href="/source/s?defs=IEventDispatcher&amp;project=rtmp_client">IEventDispatcher</a>) <a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>).<a href="/source/s?defs=dispatchEvent&amp;project=rtmp_client">dispatchEvent</a>(<a class="d" href="#message">message</a>);
<a class="l" name="149" href="#149">149</a>					} <b>else</b> {
<a class="hl" name="150" href="#150">150</a>						<a class="d" href="#onInvoke">onInvoke</a>(<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>, <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>, (<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>) <a class="d" href="#message">message</a>, (<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>) <a class="d" href="#session">session</a>.<a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a>.<a href="/source/s?defs=SESSION_KEY&amp;project=rtmp_client">SESSION_KEY</a>));
<a class="l" name="151" href="#151">151</a>					}
<a class="l" name="152" href="#152">152</a>					<b>break</b>;
<a class="l" name="153" href="#153">153</a>				<b>case</b> <a href="/source/s?defs=TYPE_FLEX_STREAM_SEND&amp;project=rtmp_client">TYPE_FLEX_STREAM_SEND</a>:
<a class="l" name="154" href="#154">154</a>					<b>if</b> (<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="155" href="#155">155</a>						((<a href="/source/s?defs=IEventDispatcher&amp;project=rtmp_client">IEventDispatcher</a>) <a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>).<a href="/source/s?defs=dispatchEvent&amp;project=rtmp_client">dispatchEvent</a>(<a class="d" href="#message">message</a>);
<a class="l" name="156" href="#156">156</a>					}
<a class="l" name="157" href="#157">157</a>					<b>break</b>;
<a class="l" name="158" href="#158">158</a>				<b>case</b> <a href="/source/s?defs=TYPE_PING&amp;project=rtmp_client">TYPE_PING</a>:
<a class="l" name="159" href="#159">159</a>					<a class="d" href="#onPing">onPing</a>(<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>, <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>, (<a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>) <a class="d" href="#message">message</a>);
<a class="hl" name="160" href="#160">160</a>					<b>break</b>;
<a class="l" name="161" href="#161">161</a>				<b>case</b> <a href="/source/s?defs=TYPE_BYTES_READ&amp;project=rtmp_client">TYPE_BYTES_READ</a>:
<a class="l" name="162" href="#162">162</a>					<a class="d" href="#onStreamBytesRead">onStreamBytesRead</a>(<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>, <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>, (<a href="/source/s?defs=BytesRead&amp;project=rtmp_client">BytesRead</a>) <a class="d" href="#message">message</a>);
<a class="l" name="163" href="#163">163</a>					<b>break</b>;
<a class="l" name="164" href="#164">164</a>				<b>case</b> <a href="/source/s?defs=TYPE_AGGREGATE&amp;project=rtmp_client">TYPE_AGGREGATE</a>:
<a class="l" name="165" href="#165">165</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Aggregate type data - header timer: {} size: {}"</span>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>(), <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>());
<a class="l" name="166" href="#166">166</a>				<b>case</b> <a href="/source/s?defs=TYPE_AUDIO_DATA&amp;project=rtmp_client">TYPE_AUDIO_DATA</a>:
<a class="l" name="167" href="#167">167</a>				<b>case</b> <a href="/source/s?defs=TYPE_VIDEO_DATA&amp;project=rtmp_client">TYPE_VIDEO_DATA</a>:
<a class="l" name="168" href="#168">168</a>					<span class="c">//mark the event as from a live source</span>
<a class="l" name="169" href="#169">169</a>					<span class="c">//log.trace("Marking message as originating from a Live source");</span>
<a class="hl" name="170" href="#170">170</a>					<a class="d" href="#message">message</a>.<a href="/source/s?defs=setSourceType&amp;project=rtmp_client">setSourceType</a>(<a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>.<a href="/source/s?defs=SOURCE_TYPE_LIVE&amp;project=rtmp_client">SOURCE_TYPE_LIVE</a>);
<a class="l" name="171" href="#171">171</a>					<span class="c">// NOTE: If we respond to "publish" with "NetStream.Publish.BadName",</span>
<a class="l" name="172" href="#172">172</a>					<span class="c">// the client sends a few stream packets before stopping. We need to ignore them.</span>
<a class="l" name="173" href="#173">173</a>					<b>if</b> (<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="174" href="#174">174</a>						((<a href="/source/s?defs=IEventDispatcher&amp;project=rtmp_client">IEventDispatcher</a>) <a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>).<a href="/source/s?defs=dispatchEvent&amp;project=rtmp_client">dispatchEvent</a>(<a class="d" href="#message">message</a>);
<a class="l" name="175" href="#175">175</a>					}
<a class="l" name="176" href="#176">176</a>					<b>break</b>;
<a class="l" name="177" href="#177">177</a>				<b>case</b> <a href="/source/s?defs=TYPE_FLEX_SHARED_OBJECT&amp;project=rtmp_client">TYPE_FLEX_SHARED_OBJECT</a>:
<a class="l" name="178" href="#178">178</a>				<b>case</b> <a href="/source/s?defs=TYPE_SHARED_OBJECT&amp;project=rtmp_client">TYPE_SHARED_OBJECT</a>:
<a class="l" name="179" href="#179">179</a>					<a class="d" href="#onSharedObject">onSharedObject</a>(<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>, <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>, (<a href="/source/s?defs=SharedObjectMessage&amp;project=rtmp_client">SharedObjectMessage</a>) <a class="d" href="#message">message</a>);
<a class="hl" name="180" href="#180">180</a>					<b>break</b>;
<a class="l" name="181" href="#181">181</a>				<b>case</b> <a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>.<a href="/source/s?defs=TYPE_CLIENT_BANDWIDTH&amp;project=rtmp_client">TYPE_CLIENT_BANDWIDTH</a>: <span class="c">//onBWDone</span>
<a class="l" name="182" href="#182">182</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Client bandwidth: {}"</span>, <a class="d" href="#message">message</a>);
<a class="l" name="183" href="#183">183</a>					<b>break</b>;
<a class="l" name="184" href="#184">184</a>				<b>case</b> <a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>.<a href="/source/s?defs=TYPE_SERVER_BANDWIDTH&amp;project=rtmp_client">TYPE_SERVER_BANDWIDTH</a>:
<a class="l" name="185" href="#185">185</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Server bandwidth: {}"</span>, <a class="d" href="#message">message</a>);
<a class="l" name="186" href="#186">186</a>					<b>break</b>;
<a class="l" name="187" href="#187">187</a>				<b>default</b>:
<a class="l" name="188" href="#188">188</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Unknown type: {}"</span>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getDataType&amp;project=rtmp_client">getDataType</a>());
<a class="l" name="189" href="#189">189</a>			}
<a class="hl" name="190" href="#190">190</a>			<b>if</b> (<a class="d" href="#message">message</a> <b>instanceof</b> <a href="/source/s?defs=Unknown&amp;project=rtmp_client">Unknown</a>) {
<a class="l" name="191" href="#191">191</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"Message type unknown: {}"</span>, <a class="d" href="#message">message</a>);
<a class="l" name="192" href="#192">192</a>			}
<a class="l" name="193" href="#193">193</a>		} <b>catch</b> (<a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a> e) {
<a class="l" name="194" href="#194">194</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Exception"</span>, e);
<a class="l" name="195" href="#195">195</a>		}
<a class="l" name="196" href="#196">196</a>		<span class="c">// XXX this may be causing 'missing' data if previous methods are not making copies</span>
<a class="l" name="197" href="#197">197</a>		<span class="c">// before buffering etc..</span>
<a class="l" name="198" href="#198">198</a>		<b>if</b> (<a class="d" href="#message">message</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="199" href="#199">199</a>			<a class="d" href="#message">message</a>.<a href="/source/s?defs=release&amp;project=rtmp_client">release</a>();
<a class="hl" name="200" href="#200">200</a>		}
<a class="l" name="201" href="#201">201</a>
<a class="l" name="202" href="#202">202</a>	}
<a class="l" name="203" href="#203">203</a>
<a class="l" name="204" href="#204">204</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="205" href="#205">205</a>	<b>public</b> <b>void</b> <a class="xmt" name="messageSent"/><a href="/source/s?refs=messageSent&amp;project=rtmp_client" class="xmt">messageSent</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xa" name="conn"/><a href="/source/s?refs=conn&amp;project=rtmp_client" class="xa">conn</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="message"/><a href="/source/s?refs=message&amp;project=rtmp_client" class="xa">message</a>) {
<a class="l" name="206" href="#206">206</a>		<span class="c">//log.debug("Message sent");</span>
<a class="l" name="207" href="#207">207</a>		<b>if</b> (<a class="d" href="#message">message</a> <b>instanceof</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>) {
<a class="l" name="208" href="#208">208</a>			<b>return</b>;
<a class="l" name="209" href="#209">209</a>		}
<a class="hl" name="210" href="#210">210</a>		<span class="c">// Increase number of sent messages</span>
<a class="l" name="211" href="#211">211</a>		<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a class="d" href="#messageSent">messageSent</a>((<a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a>) <a class="d" href="#message">message</a>);
<a class="l" name="212" href="#212">212</a>	}
<a class="l" name="213" href="#213">213</a>
<a class="l" name="214" href="#214">214</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="215" href="#215">215</a>	<b>public</b> <b>void</b> <a class="xmt" name="connectionClosed"/><a href="/source/s?refs=connectionClosed&amp;project=rtmp_client" class="xmt">connectionClosed</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xa" name="conn"/><a href="/source/s?refs=conn&amp;project=rtmp_client" class="xa">conn</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="state"/><a href="/source/s?refs=state&amp;project=rtmp_client" class="xa">state</a>) {
<a class="l" name="216" href="#216">216</a>		<a href="/source/s?defs=state&amp;project=rtmp_client">state</a>.<a href="/source/s?defs=setState&amp;project=rtmp_client">setState</a>(<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=STATE_DISCONNECTED&amp;project=rtmp_client">STATE_DISCONNECTED</a>);
<a class="l" name="217" href="#217">217</a>		<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=close&amp;project=rtmp_client">close</a>();
<a class="l" name="218" href="#218">218</a>	}
<a class="l" name="219" href="#219">219</a>
<a class="hl" name="220" href="#220">220</a>	<span class="c">/**
<a class="l" name="221" href="#221">221</a>	 * Return hostname for URL.
<a class="l" name="222" href="#222">222</a>	 *
<a class="l" name="223" href="#223">223</a>	 * <strong>@param</strong> <em>url</em>
<a class="l" name="224" href="#224">224</a>	 *            URL
<a class="l" name="225" href="#225">225</a>	 * <strong>@return</strong> Hostname from that URL
<a class="l" name="226" href="#226">226</a>	 */</span>
<a class="l" name="227" href="#227">227</a>	<b>protected</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getHostname"/><a href="/source/s?refs=getHostname&amp;project=rtmp_client" class="xmt">getHostname</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="url"/><a href="/source/s?refs=url&amp;project=rtmp_client" class="xa">url</a>) {
<a class="l" name="228" href="#228">228</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"url: {}"</span>, <a class="d" href="#url">url</a>);
<a class="l" name="229" href="#229">229</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>[] <a href="/source/s?defs=parts&amp;project=rtmp_client">parts</a> = <a class="d" href="#url">url</a>.<a href="/source/s?defs=split&amp;project=rtmp_client">split</a>(<span class="s">"/"</span>);
<a class="hl" name="230" href="#230">230</a>		<b>if</b> (<a href="/source/s?defs=parts&amp;project=rtmp_client">parts</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> == <span class="n">2</span>) {
<a class="l" name="231" href="#231">231</a>			<span class="c">// TODO: is this a good default hostname?</span>
<a class="l" name="232" href="#232">232</a>			<b>return</b> <span class="s">""</span>;
<a class="l" name="233" href="#233">233</a>		} <b>else</b> {
<a class="l" name="234" href="#234">234</a>			<b>return</b> <a href="/source/s?defs=parts&amp;project=rtmp_client">parts</a>[<span class="n">2</span>];
<a class="l" name="235" href="#235">235</a>		}
<a class="l" name="236" href="#236">236</a>	}
<a class="l" name="237" href="#237">237</a>
<a class="l" name="238" href="#238">238</a>	<span class="c">/**
<a class="l" name="239" href="#239">239</a>	 * Handler for pending call result. Dispatches results to all pending call
<a class="hl" name="240" href="#240">240</a>	 * handlers.
<a class="l" name="241" href="#241">241</a>	 *
<a class="l" name="242" href="#242">242</a>	 * <strong>@param</strong> <em>conn</em>
<a class="l" name="243" href="#243">243</a>	 *            Connection
<a class="l" name="244" href="#244">244</a>	 * <strong>@param</strong> <em>invoke</em>
<a class="l" name="245" href="#245">245</a>	 *            Pending call result event context
<a class="l" name="246" href="#246">246</a>	 */</span>
<a class="l" name="247" href="#247">247</a>	<b>protected</b> <b>void</b> <a class="xmt" name="handlePendingCallResult"/><a href="/source/s?refs=handlePendingCallResult&amp;project=rtmp_client" class="xmt">handlePendingCallResult</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xa" name="conn"/><a href="/source/s?refs=conn&amp;project=rtmp_client" class="xa">conn</a>, <a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a> <a class="xa" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xa">invoke</a>) {
<a class="l" name="248" href="#248">248</a>		<b>final</b> <a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a> <a href="/source/s?defs=call&amp;project=rtmp_client">call</a> = <a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=getCall&amp;project=rtmp_client">getCall</a>();
<a class="l" name="249" href="#249">249</a>		<b>final</b> <a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a> <a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a> = <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=retrievePendingCall&amp;project=rtmp_client">retrievePendingCall</a>(<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=getInvokeId&amp;project=rtmp_client">getInvokeId</a>());
<a class="hl" name="250" href="#250">250</a>		<b>if</b> (<a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="251" href="#251">251</a>			<span class="c">// The client sent a response to a previously made call.</span>
<a class="l" name="252" href="#252">252</a>			<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a href="/source/s?defs=args&amp;project=rtmp_client">args</a> = <a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=getArguments&amp;project=rtmp_client">getArguments</a>();
<a class="l" name="253" href="#253">253</a>			<b>if</b> ((<a href="/source/s?defs=args&amp;project=rtmp_client">args</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) &amp;&amp; (<a href="/source/s?defs=args&amp;project=rtmp_client">args</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> &gt; <span class="n">0</span>)) {
<a class="l" name="254" href="#254">254</a>				<span class="c">// TODO: can a client return multiple results?</span>
<a class="l" name="255" href="#255">255</a>				<a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a>.<a href="/source/s?defs=setResult&amp;project=rtmp_client">setResult</a>(<a href="/source/s?defs=args&amp;project=rtmp_client">args</a>[<span class="n">0</span>]);
<a class="l" name="256" href="#256">256</a>			}
<a class="l" name="257" href="#257">257</a>			<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>&lt;<a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a>&gt; <a href="/source/s?defs=callbacks&amp;project=rtmp_client">callbacks</a> = <a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a>.<a href="/source/s?defs=getCallbacks&amp;project=rtmp_client">getCallbacks</a>();
<a class="l" name="258" href="#258">258</a>			<b>if</b> (!<a href="/source/s?defs=callbacks&amp;project=rtmp_client">callbacks</a>.<a href="/source/s?defs=isEmpty&amp;project=rtmp_client">isEmpty</a>()) {
<a class="l" name="259" href="#259">259</a>				<a href="/source/s?defs=HashSet&amp;project=rtmp_client">HashSet</a>&lt;<a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a>&gt; <a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a> = <b>new</b> <a href="/source/s?defs=HashSet&amp;project=rtmp_client">HashSet</a>&lt;<a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a>&gt;();
<a class="hl" name="260" href="#260">260</a>				<a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a>.<a href="/source/s?defs=addAll&amp;project=rtmp_client">addAll</a>(<a href="/source/s?defs=callbacks&amp;project=rtmp_client">callbacks</a>);
<a class="l" name="261" href="#261">261</a>				<b>for</b> (<a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> <a href="/source/s?defs=callback&amp;project=rtmp_client">callback</a> : <a href="/source/s?defs=tmp&amp;project=rtmp_client">tmp</a>) {
<a class="l" name="262" href="#262">262</a>					<b>try</b> {
<a class="l" name="263" href="#263">263</a>						<a href="/source/s?defs=callback&amp;project=rtmp_client">callback</a>.<a href="/source/s?defs=resultReceived&amp;project=rtmp_client">resultReceived</a>(<a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a>);
<a class="l" name="264" href="#264">264</a>					} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="265" href="#265">265</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error while executing callback {} {}"</span>, <a href="/source/s?defs=callback&amp;project=rtmp_client">callback</a>, e);
<a class="l" name="266" href="#266">266</a>					}
<a class="l" name="267" href="#267">267</a>				}
<a class="l" name="268" href="#268">268</a>			}
<a class="l" name="269" href="#269">269</a>		}
<a class="hl" name="270" href="#270">270</a>	}
<a class="l" name="271" href="#271">271</a>
<a class="l" name="272" href="#272">272</a>	<span class="c">/**
<a class="l" name="273" href="#273">273</a>	 * Chunk size change event handler. Abstract, to be implemented in
<a class="l" name="274" href="#274">274</a>	 * subclasses.
<a class="l" name="275" href="#275">275</a>	 *
<a class="l" name="276" href="#276">276</a>	 * <strong>@param</strong> <em>conn</em>
<a class="l" name="277" href="#277">277</a>	 *            Connection
<a class="l" name="278" href="#278">278</a>	 * <strong>@param</strong> <em>channel</em>
<a class="l" name="279" href="#279">279</a>	 *            Channel
<a class="hl" name="280" href="#280">280</a>	 * <strong>@param</strong> <em>source</em>
<a class="l" name="281" href="#281">281</a>	 *            Header
<a class="l" name="282" href="#282">282</a>	 * <strong>@param</strong> <em>chunkSize</em>
<a class="l" name="283" href="#283">283</a>	 *            New chunk size
<a class="l" name="284" href="#284">284</a>	 */</span>
<a class="l" name="285" href="#285">285</a>	<b>protected</b> <b>abstract</b> <b>void</b> <a class="xmt" name="onChunkSize"/><a href="/source/s?refs=onChunkSize&amp;project=rtmp_client" class="xmt">onChunkSize</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xa" name="conn"/><a href="/source/s?refs=conn&amp;project=rtmp_client" class="xa">conn</a>, <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a class="xa" name="channel"/><a href="/source/s?refs=channel&amp;project=rtmp_client" class="xa">channel</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=ChunkSize&amp;project=rtmp_client">ChunkSize</a> <a class="xa" name="chunkSize"/><a href="/source/s?refs=chunkSize&amp;project=rtmp_client" class="xa">chunkSize</a>);
<a class="l" name="286" href="#286">286</a>
<a class="l" name="287" href="#287">287</a>	<span class="c">/**
<a class="l" name="288" href="#288">288</a>	 * Invocation event handler.
<a class="l" name="289" href="#289">289</a>	 *
<a class="hl" name="290" href="#290">290</a>	 * <strong>@param</strong> <em>conn</em>
<a class="l" name="291" href="#291">291</a>	 *            Connection
<a class="l" name="292" href="#292">292</a>	 * <strong>@param</strong> <em>channel</em>
<a class="l" name="293" href="#293">293</a>	 *            Channel
<a class="l" name="294" href="#294">294</a>	 * <strong>@param</strong> <em>source</em>
<a class="l" name="295" href="#295">295</a>	 *            Header
<a class="l" name="296" href="#296">296</a>	 * <strong>@param</strong> <em>invoke</em>
<a class="l" name="297" href="#297">297</a>	 *            Invocation event context
<a class="l" name="298" href="#298">298</a>	 * <strong>@param</strong> <em>rtmp</em>
<a class="l" name="299" href="#299">299</a>	 *            RTMP connection state
<a class="hl" name="300" href="#300">300</a>	 */</span>
<a class="l" name="301" href="#301">301</a>	<b>protected</b> <b>abstract</b> <b>void</b> <a class="xmt" name="onInvoke"/><a href="/source/s?refs=onInvoke&amp;project=rtmp_client" class="xmt">onInvoke</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xa" name="conn"/><a href="/source/s?refs=conn&amp;project=rtmp_client" class="xa">conn</a>, <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a class="xa" name="channel"/><a href="/source/s?refs=channel&amp;project=rtmp_client" class="xa">channel</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a> <a class="xa" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xa">invoke</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>);
<a class="l" name="302" href="#302">302</a>
<a class="l" name="303" href="#303">303</a>	<span class="c">/**
<a class="l" name="304" href="#304">304</a>	 * Ping event handler.
<a class="l" name="305" href="#305">305</a>	 *
<a class="l" name="306" href="#306">306</a>	 * <strong>@param</strong> <em>conn</em>
<a class="l" name="307" href="#307">307</a>	 *            Connection
<a class="l" name="308" href="#308">308</a>	 * <strong>@param</strong> <em>channel</em>
<a class="l" name="309" href="#309">309</a>	 *            Channel
<a class="hl" name="310" href="#310">310</a>	 * <strong>@param</strong> <em>source</em>
<a class="l" name="311" href="#311">311</a>	 *            Header
<a class="l" name="312" href="#312">312</a>	 * <strong>@param</strong> <em>ping</em>
<a class="l" name="313" href="#313">313</a>	 *            Ping event context
<a class="l" name="314" href="#314">314</a>	 */</span>
<a class="l" name="315" href="#315">315</a>	<b>protected</b> <b>abstract</b> <b>void</b> <a class="xmt" name="onPing"/><a href="/source/s?refs=onPing&amp;project=rtmp_client" class="xmt">onPing</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xa" name="conn"/><a href="/source/s?refs=conn&amp;project=rtmp_client" class="xa">conn</a>, <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a class="xa" name="channel"/><a href="/source/s?refs=channel&amp;project=rtmp_client" class="xa">channel</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a> <a class="xa" name="ping"/><a href="/source/s?refs=ping&amp;project=rtmp_client" class="xa">ping</a>);
<a class="l" name="316" href="#316">316</a>
<a class="l" name="317" href="#317">317</a>	<span class="c">/**
<a class="l" name="318" href="#318">318</a>	 * Stream bytes read event handler.
<a class="l" name="319" href="#319">319</a>	 *
<a class="hl" name="320" href="#320">320</a>	 * <strong>@param</strong> <em>conn</em>
<a class="l" name="321" href="#321">321</a>	 *            Connection
<a class="l" name="322" href="#322">322</a>	 * <strong>@param</strong> <em>channel</em>
<a class="l" name="323" href="#323">323</a>	 *            Channel
<a class="l" name="324" href="#324">324</a>	 * <strong>@param</strong> <em>source</em>
<a class="l" name="325" href="#325">325</a>	 *            Header
<a class="l" name="326" href="#326">326</a>	 * <strong>@param</strong> <em>streamBytesRead</em>
<a class="l" name="327" href="#327">327</a>	 *            Bytes read event context
<a class="l" name="328" href="#328">328</a>	 */</span>
<a class="l" name="329" href="#329">329</a>	<b>protected</b> <b>void</b> <a class="xmt" name="onStreamBytesRead"/><a href="/source/s?refs=onStreamBytesRead&amp;project=rtmp_client" class="xmt">onStreamBytesRead</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xa" name="conn"/><a href="/source/s?refs=conn&amp;project=rtmp_client" class="xa">conn</a>, <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a class="xa" name="channel"/><a href="/source/s?refs=channel&amp;project=rtmp_client" class="xa">channel</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=BytesRead&amp;project=rtmp_client">BytesRead</a> <a class="xa" name="streamBytesRead"/><a href="/source/s?refs=streamBytesRead&amp;project=rtmp_client" class="xa">streamBytesRead</a>) {
<a class="hl" name="330" href="#330">330</a>		<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=receivedBytesRead&amp;project=rtmp_client">receivedBytesRead</a>(<a class="d" href="#streamBytesRead">streamBytesRead</a>.<a href="/source/s?defs=getBytesRead&amp;project=rtmp_client">getBytesRead</a>());
<a class="l" name="331" href="#331">331</a>	}
<a class="l" name="332" href="#332">332</a>
<a class="l" name="333" href="#333">333</a>	<span class="c">/**
<a class="l" name="334" href="#334">334</a>	 * Shared object event handler.
<a class="l" name="335" href="#335">335</a>	 *
<a class="l" name="336" href="#336">336</a>	 * <strong>@param</strong> <em>conn</em>
<a class="l" name="337" href="#337">337</a>	 *            Connection
<a class="l" name="338" href="#338">338</a>	 * <strong>@param</strong> <em>channel</em>
<a class="l" name="339" href="#339">339</a>	 *            Channel
<a class="hl" name="340" href="#340">340</a>	 * <strong>@param</strong> <em>source</em>
<a class="l" name="341" href="#341">341</a>	 *            Header
<a class="l" name="342" href="#342">342</a>	 * <strong>@param</strong> <em>object</em>
<a class="l" name="343" href="#343">343</a>	 *            Shared object event context
<a class="l" name="344" href="#344">344</a>	 */</span>
<a class="l" name="345" href="#345">345</a>	<b>protected</b> <b>abstract</b> <b>void</b> <a class="xmt" name="onSharedObject"/><a href="/source/s?refs=onSharedObject&amp;project=rtmp_client" class="xmt">onSharedObject</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xa" name="conn"/><a href="/source/s?refs=conn&amp;project=rtmp_client" class="xa">conn</a>, <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a class="xa" name="channel"/><a href="/source/s?refs=channel&amp;project=rtmp_client" class="xa">channel</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=SharedObjectMessage&amp;project=rtmp_client">SharedObjectMessage</a> <a class="xa" name="object"/><a href="/source/s?refs=object&amp;project=rtmp_client" class="xa">object</a>);
<a class="l" name="346" href="#346">346</a>
<a class="l" name="347" href="#347">347</a>}
<a class="l" name="348" href="#348">348</a>