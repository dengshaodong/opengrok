<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["BaseRTMPClientHandler",64],["CreateStreamCallBack",680],["NetStream",653],["NetStreamPrivateData",711]]],["Package","xp",[["org.red5.server.net.rtmp",1]]],["Method","xmt",[["BaseRTMPClientHandler",124],["CreateStreamCallBack",683],["NetStream",656],["close",660],["connect",156],["connect",170],["connect",205],["connect",218],["connect",231],["connectionClosed",495],["connectionOpened",477],["createStream",417],["disconnect",407],["dispatchEvent",672],["getChannelForStreamId",621],["getCodecFactory",602],["getConnection",639],["getSharedObject",263],["handleException",606],["invoke",372],["invoke",392],["makeDefaultConnectionParams",181],["onBWDone",362],["onChunkSize",280],["onInvoke",505],["onPing",291],["onSharedObject",344],["play",461],["publish",423],["publishStreamData",447],["resultReceived",688],["setCodecFactory",593],["setConnection",630],["setConnectionClosedHandler",131],["setExceptionHandler",135],["setServiceProvider",252],["setStreamEventDispatcher",649],["start",664],["startConnector",147],["stop",668],["unpublish",441]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Arrays&amp;project=rtmp_client">Arrays</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=concurrent&amp;project=rtmp_client">concurrent</a>.<a href="/source/s?defs=ConcurrentHashMap&amp;project=rtmp_client">ConcurrentHashMap</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=concurrent&amp;project=rtmp_client">concurrent</a>.<a href="/source/s?defs=ConcurrentMap&amp;project=rtmp_client">ConcurrentMap</a>;
<a class="l" name="26" href="#26">26</a>
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a class="d" href="#object">object</a>.<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a class="d" href="#object">object</a>.<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>.<a href="/source/s?defs=ObjectMap&amp;project=rtmp_client">ObjectMap</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=IConnection&amp;project=rtmp_client">IConnection</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a class="d" href="#event">event</a>.<a href="/source/s?defs=IEvent&amp;project=rtmp_client">IEvent</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a class="d" href="#event">event</a>.<a href="/source/s?defs=IEventDispatcher&amp;project=rtmp_client">IEventDispatcher</a>;
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=messaging&amp;project=rtmp_client">messaging</a>.<a href="/source/s?defs=IMessage&amp;project=rtmp_client">IMessage</a>;
<a class="l" name="34" href="#34">34</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a href="/source/s?defs=codec&amp;project=rtmp_client">codec</a>.<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>;
<a class="l" name="35" href="#35">35</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a href="/source/s?defs=codec&amp;project=rtmp_client">codec</a>.<a href="/source/s?defs=RTMPCodecFactory&amp;project=rtmp_client">RTMPCodecFactory</a>;
<a class="l" name="36" href="#36">36</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a class="d" href="#event">event</a>.<a href="/source/s?defs=ChunkSize&amp;project=rtmp_client">ChunkSize</a>;
<a class="l" name="37" href="#37">37</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a class="d" href="#event">event</a>.<a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>;
<a class="l" name="38" href="#38">38</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a class="d" href="#event">event</a>.<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>;
<a class="l" name="39" href="#39">39</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a class="d" href="#event">event</a>.<a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>;
<a class="hl" name="40" href="#40">40</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a class="d" href="#rtmp">rtmp</a>.<a class="d" href="#message">message</a>.<a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a>;
<a class="l" name="41" href="#41">41</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>;
<a class="l" name="42" href="#42">42</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a>;
<a class="l" name="43" href="#43">43</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a>;
<a class="l" name="44" href="#44">44</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a>;
<a class="l" name="45" href="#45">45</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=IServiceInvoker&amp;project=rtmp_client">IServiceInvoker</a>;
<a class="l" name="46" href="#46">46</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=ServiceInvoker&amp;project=rtmp_client">ServiceInvoker</a>;
<a class="l" name="47" href="#47">47</a><span class="c">//import org.red5.server.service.IServiceInvoker;</span>
<a class="l" name="48" href="#48">48</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=MethodNotFoundException&amp;project=rtmp_client">MethodNotFoundException</a>;
<a class="l" name="49" href="#49">49</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a>;
<a class="hl" name="50" href="#50">50</a><span class="c">//import org.red5.server.service.ServiceInvoker;</span>
<a class="l" name="51" href="#51">51</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=so&amp;project=rtmp_client">so</a>.<a href="/source/s?defs=ClientSharedObject&amp;project=rtmp_client">ClientSharedObject</a>;
<a class="l" name="52" href="#52">52</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=so&amp;project=rtmp_client">so</a>.<a href="/source/s?defs=IClientSharedObject&amp;project=rtmp_client">IClientSharedObject</a>;
<a class="l" name="53" href="#53">53</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=so&amp;project=rtmp_client">so</a>.<a href="/source/s?defs=SharedObjectMessage&amp;project=rtmp_client">SharedObjectMessage</a>;
<a class="l" name="54" href="#54">54</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=AbstractClientStream&amp;project=rtmp_client">AbstractClientStream</a>;
<a class="l" name="55" href="#55">55</a><span class="c">//import org.red5.server.stream.IClientStream;</span>
<a class="l" name="56" href="#56">56</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=OutputStream&amp;project=rtmp_client">OutputStream</a>;
<a class="l" name="57" href="#57">57</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=consumer&amp;project=rtmp_client">consumer</a>.<a href="/source/s?defs=ConnectionConsumer&amp;project=rtmp_client">ConnectionConsumer</a>;
<a class="l" name="58" href="#58">58</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="59" href="#59">59</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="hl" name="60" href="#60">60</a>
<a class="l" name="61" href="#61">61</a><span class="c">/**
<a class="l" name="62" href="#62">62</a> * Base class for clients (RTMP and RTMPT)
<a class="l" name="63" href="#63">63</a> */</span>
<a class="l" name="64" href="#64">64</a><b>public</b> <b>abstract</b> <b>class</b> <a class="xc" name="BaseRTMPClientHandler"/><a href="/source/s?refs=BaseRTMPClientHandler&amp;project=rtmp_client" class="xc">BaseRTMPClientHandler</a> <b>extends</b> <a href="/source/s?defs=BaseRTMPHandler&amp;project=rtmp_client">BaseRTMPHandler</a> {
<a class="l" name="65" href="#65">65</a>
<a class="l" name="66" href="#66">66</a>	<b>private</b> <b>static</b> <b>final</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a href="/source/s?defs=BaseRTMPClientHandler&amp;project=rtmp_client">BaseRTMPClientHandler</a>.<b>class</b>);
<a class="l" name="67" href="#67">67</a>
<a class="l" name="68" href="#68">68</a>	<span class="c">/**
<a class="l" name="69" href="#69">69</a>	 * Connection scheme / protocol
<a class="hl" name="70" href="#70">70</a>	 */</span>
<a class="l" name="71" href="#71">71</a>	<b>protected</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="scheme"/><a href="/source/s?refs=scheme&amp;project=rtmp_client" class="xfld">scheme</a> = <span class="s">"rtmp"</span>;
<a class="l" name="72" href="#72">72</a>
<a class="l" name="73" href="#73">73</a>	<span class="c">/**
<a class="l" name="74" href="#74">74</a>	 * Connection parameters
<a class="l" name="75" href="#75">75</a>	 */</span>
<a class="l" name="76" href="#76">76</a>	<b>protected</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xfld" name="connectionParams"/><a href="/source/s?refs=connectionParams&amp;project=rtmp_client" class="xfld">connectionParams</a>;
<a class="l" name="77" href="#77">77</a>
<a class="l" name="78" href="#78">78</a>	<span class="c">/**
<a class="l" name="79" href="#79">79</a>	 * Connect call arguments
<a class="hl" name="80" href="#80">80</a>	 */</span>
<a class="l" name="81" href="#81">81</a>	<b>private</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xfld" name="connectArguments"/><a href="/source/s?refs=connectArguments&amp;project=rtmp_client" class="xfld">connectArguments</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="82" href="#82">82</a>
<a class="l" name="83" href="#83">83</a>	<span class="c">/**
<a class="l" name="84" href="#84">84</a>	 * Connection callback
<a class="l" name="85" href="#85">85</a>	 */</span>
<a class="l" name="86" href="#86">86</a>	<b>private</b> <a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> <a class="xfld" name="connectCallback"/><a href="/source/s?refs=connectCallback&amp;project=rtmp_client" class="xfld">connectCallback</a>;
<a class="l" name="87" href="#87">87</a>
<a class="l" name="88" href="#88">88</a>	<span class="c">/**
<a class="l" name="89" href="#89">89</a>	 * Service provider
<a class="hl" name="90" href="#90">90</a>	 */</span>
<a class="l" name="91" href="#91">91</a>	<b>private</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xfld" name="serviceProvider"/><a href="/source/s?refs=serviceProvider&amp;project=rtmp_client" class="xfld">serviceProvider</a>;
<a class="l" name="92" href="#92">92</a>
<a class="l" name="93" href="#93">93</a>	<span class="c">/**
<a class="l" name="94" href="#94">94</a>	 * Service invoker
<a class="l" name="95" href="#95">95</a>	 */</span>
<a class="l" name="96" href="#96">96</a>	<b>private</b> <a href="/source/s?defs=IServiceInvoker&amp;project=rtmp_client">IServiceInvoker</a> <a class="xfld" name="serviceInvoker"/><a href="/source/s?refs=serviceInvoker&amp;project=rtmp_client" class="xfld">serviceInvoker</a> = <b>new</b> <a href="/source/s?defs=ServiceInvoker&amp;project=rtmp_client">ServiceInvoker</a>();
<a class="l" name="97" href="#97">97</a>
<a class="l" name="98" href="#98">98</a>	<span class="c">/**
<a class="l" name="99" href="#99">99</a>	 * Shared objects map
<a class="hl" name="100" href="#100">100</a>	 */</span>
<a class="l" name="101" href="#101">101</a>	<b>private</b> <b>volatile</b> <a href="/source/s?defs=ConcurrentMap&amp;project=rtmp_client">ConcurrentMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=ClientSharedObject&amp;project=rtmp_client">ClientSharedObject</a>&gt; <a class="xfld" name="sharedObjects"/><a href="/source/s?refs=sharedObjects&amp;project=rtmp_client" class="xfld">sharedObjects</a> = <b>new</b> <a href="/source/s?defs=ConcurrentHashMap&amp;project=rtmp_client">ConcurrentHashMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=ClientSharedObject&amp;project=rtmp_client">ClientSharedObject</a>&gt;();
<a class="l" name="102" href="#102">102</a>
<a class="l" name="103" href="#103">103</a>	<span class="c">/**
<a class="l" name="104" href="#104">104</a>	 * Net stream handling
<a class="l" name="105" href="#105">105</a>	 */</span>
<a class="l" name="106" href="#106">106</a>	<b>private</b> <b>volatile</b> <a href="/source/s?defs=ConcurrentMap&amp;project=rtmp_client">ConcurrentMap</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a class="d" href="#NetStreamPrivateData">NetStreamPrivateData</a>&gt; <a class="xfld" name="streamDataMap"/><a href="/source/s?refs=streamDataMap&amp;project=rtmp_client" class="xfld">streamDataMap</a> = <b>new</b> <a href="/source/s?defs=ConcurrentHashMap&amp;project=rtmp_client">ConcurrentHashMap</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>, <a class="d" href="#NetStreamPrivateData">NetStreamPrivateData</a>&gt;();
<a class="l" name="107" href="#107">107</a>
<a class="l" name="108" href="#108">108</a>	<span class="c">/**
<a class="l" name="109" href="#109">109</a>	 * Task to start on connection close
<a class="hl" name="110" href="#110">110</a>	 */</span>
<a class="l" name="111" href="#111">111</a>	<b>private</b> <a href="/source/s?defs=Runnable&amp;project=rtmp_client">Runnable</a> <a class="xfld" name="connectionClosedHandler"/><a href="/source/s?refs=connectionClosedHandler&amp;project=rtmp_client" class="xfld">connectionClosedHandler</a>;
<a class="l" name="112" href="#112">112</a>
<a class="l" name="113" href="#113">113</a>	<span class="c">/**
<a class="l" name="114" href="#114">114</a>	 * Task to start on connection errors
<a class="l" name="115" href="#115">115</a>	 */</span>
<a class="l" name="116" href="#116">116</a>	<b>private</b> <a href="/source/s?defs=ClientExceptionHandler&amp;project=rtmp_client">ClientExceptionHandler</a> <a class="xfld" name="exceptionHandler"/><a href="/source/s?refs=exceptionHandler&amp;project=rtmp_client" class="xfld">exceptionHandler</a>;
<a class="l" name="117" href="#117">117</a>
<a class="l" name="118" href="#118">118</a>	<b>private</b> <a href="/source/s?defs=RTMPCodecFactory&amp;project=rtmp_client">RTMPCodecFactory</a> <a class="xfld" name="codecFactory"/><a href="/source/s?refs=codecFactory&amp;project=rtmp_client" class="xfld">codecFactory</a>;
<a class="l" name="119" href="#119">119</a>
<a class="hl" name="120" href="#120">120</a>	<b>private</b> <a href="/source/s?defs=IEventDispatcher&amp;project=rtmp_client">IEventDispatcher</a> <a class="xfld" name="streamEventDispatcher"/><a href="/source/s?refs=streamEventDispatcher&amp;project=rtmp_client" class="xfld">streamEventDispatcher</a>;
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>	<b>protected</b> <b>volatile</b> <a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xfld" name="conn"/><a href="/source/s?refs=conn&amp;project=rtmp_client" class="xfld">conn</a>;
<a class="l" name="123" href="#123">123</a>
<a class="l" name="124" href="#124">124</a>	<b>protected</b> <a class="xmt" name="BaseRTMPClientHandler"/><a href="/source/s?refs=BaseRTMPClientHandler&amp;project=rtmp_client" class="xmt">BaseRTMPClientHandler</a>() {
<a class="l" name="125" href="#125">125</a>		<a class="d" href="#codecFactory">codecFactory</a> = <b>new</b> <a href="/source/s?defs=RTMPCodecFactory&amp;project=rtmp_client">RTMPCodecFactory</a>();
<a class="l" name="126" href="#126">126</a>		<a class="d" href="#codecFactory">codecFactory</a>.<a href="/source/s?defs=setDeserializer&amp;project=rtmp_client">setDeserializer</a>(<b>new</b> <a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a>());
<a class="l" name="127" href="#127">127</a>		<a class="d" href="#codecFactory">codecFactory</a>.<a href="/source/s?defs=setSerializer&amp;project=rtmp_client">setSerializer</a>(<b>new</b> <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>());
<a class="l" name="128" href="#128">128</a>		<a class="d" href="#codecFactory">codecFactory</a>.<a href="/source/s?defs=init&amp;project=rtmp_client">init</a>();
<a class="l" name="129" href="#129">129</a>	}
<a class="hl" name="130" href="#130">130</a>
<a class="l" name="131" href="#131">131</a>	<b>public</b> <b>void</b> <a class="xmt" name="setConnectionClosedHandler"/><a href="/source/s?refs=setConnectionClosedHandler&amp;project=rtmp_client" class="xmt">setConnectionClosedHandler</a>(<a href="/source/s?defs=Runnable&amp;project=rtmp_client">Runnable</a> <a class="xa" name="connectionClosedHandler"/><a href="/source/s?refs=connectionClosedHandler&amp;project=rtmp_client" class="xa">connectionClosedHandler</a>) {
<a class="l" name="132" href="#132">132</a>		<b>this</b>.<a href="/source/s?defs=connectionClosedHandler&amp;project=rtmp_client">connectionClosedHandler</a> = <a href="/source/s?defs=connectionClosedHandler&amp;project=rtmp_client">connectionClosedHandler</a>;
<a class="l" name="133" href="#133">133</a>	}
<a class="l" name="134" href="#134">134</a>
<a class="l" name="135" href="#135">135</a>	<b>public</b> <b>void</b> <a class="xmt" name="setExceptionHandler"/><a href="/source/s?refs=setExceptionHandler&amp;project=rtmp_client" class="xmt">setExceptionHandler</a>(<a href="/source/s?defs=ClientExceptionHandler&amp;project=rtmp_client">ClientExceptionHandler</a> <a class="xa" name="exceptionHandler"/><a href="/source/s?refs=exceptionHandler&amp;project=rtmp_client" class="xa">exceptionHandler</a>) {
<a class="l" name="136" href="#136">136</a>		<b>this</b>.<a href="/source/s?defs=exceptionHandler&amp;project=rtmp_client">exceptionHandler</a> = <a href="/source/s?defs=exceptionHandler&amp;project=rtmp_client">exceptionHandler</a>;
<a class="l" name="137" href="#137">137</a>	}
<a class="l" name="138" href="#138">138</a>
<a class="l" name="139" href="#139">139</a>	<span class="c">/**
<a class="hl" name="140" href="#140">140</a>	 * Start network connection to server
<a class="l" name="141" href="#141">141</a>	 *
<a class="l" name="142" href="#142">142</a>	 * <strong>@param</strong> <em>server</em>
<a class="l" name="143" href="#143">143</a>	 *            Server
<a class="l" name="144" href="#144">144</a>	 * <strong>@param</strong> <em>port</em>
<a class="l" name="145" href="#145">145</a>	 *            Connection port
<a class="l" name="146" href="#146">146</a>	 */</span>
<a class="l" name="147" href="#147">147</a>	<b>protected</b> <b>abstract</b> <b>void</b> <a class="xmt" name="startConnector"/><a href="/source/s?refs=startConnector&amp;project=rtmp_client" class="xmt">startConnector</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="server"/><a href="/source/s?refs=server&amp;project=rtmp_client" class="xa">server</a>, <b>int</b> <a class="xa" name="port"/><a href="/source/s?refs=port&amp;project=rtmp_client" class="xa">port</a>);
<a class="l" name="148" href="#148">148</a>
<a class="l" name="149" href="#149">149</a>	<span class="c">/**
<a class="hl" name="150" href="#150">150</a>	 * Connect RTMP client to server's application via given port
<a class="l" name="151" href="#151">151</a>	 *
<a class="l" name="152" href="#152">152</a>	 * <strong>@param</strong> <em>server</em> Server
<a class="l" name="153" href="#153">153</a>	 * <strong>@param</strong> <em>port</em> Connection port
<a class="l" name="154" href="#154">154</a>	 * <strong>@param</strong> <em>application</em> Application at that server
<a class="l" name="155" href="#155">155</a>	 */</span>
<a class="l" name="156" href="#156">156</a>	<b>public</b> <b>void</b> <a class="xmt" name="connect"/><a href="/source/s?refs=connect&amp;project=rtmp_client" class="xmt">connect</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="server"/><a href="/source/s?refs=server&amp;project=rtmp_client" class="xa">server</a>, <b>int</b> <a class="xa" name="port"/><a href="/source/s?refs=port&amp;project=rtmp_client" class="xa">port</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="application"/><a href="/source/s?refs=application&amp;project=rtmp_client" class="xa">application</a>) {
<a class="l" name="157" href="#157">157</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"connect server: {} port {} application {}"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <a href="/source/s?defs=server&amp;project=rtmp_client">server</a>, <a href="/source/s?defs=port&amp;project=rtmp_client">port</a>, <a href="/source/s?defs=application&amp;project=rtmp_client">application</a> });
<a class="l" name="158" href="#158">158</a>		<a href="/source/s?defs=connect&amp;project=rtmp_client">connect</a>(<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>, <a href="/source/s?defs=port&amp;project=rtmp_client">port</a>, <a href="/source/s?defs=application&amp;project=rtmp_client">application</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="159" href="#159">159</a>	}
<a class="hl" name="160" href="#160">160</a>
<a class="l" name="161" href="#161">161</a>	<span class="c">/**
<a class="l" name="162" href="#162">162</a>	 * Connect RTMP client to server's application via given port with given
<a class="l" name="163" href="#163">163</a>	 * connection callback
<a class="l" name="164" href="#164">164</a>	 *
<a class="l" name="165" href="#165">165</a>	 * <strong>@param</strong> <em>server</em> Server
<a class="l" name="166" href="#166">166</a>	 * <strong>@param</strong> <em>port</em> Connection port
<a class="l" name="167" href="#167">167</a>	 * <strong>@param</strong> <em>application</em> Application at that server
<a class="l" name="168" href="#168">168</a>	 * <strong>@param</strong> <em>connectCallback</em> Connection callback
<a class="l" name="169" href="#169">169</a>	 */</span>
<a class="hl" name="170" href="#170">170</a>	<b>public</b> <b>void</b> <a class="xmt" name="connect"/><a href="/source/s?refs=connect&amp;project=rtmp_client" class="xmt">connect</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="server"/><a href="/source/s?refs=server&amp;project=rtmp_client" class="xa">server</a>, <b>int</b> <a class="xa" name="port"/><a href="/source/s?refs=port&amp;project=rtmp_client" class="xa">port</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="application"/><a href="/source/s?refs=application&amp;project=rtmp_client" class="xa">application</a>, <a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> <a class="xa" name="connectCallback"/><a href="/source/s?refs=connectCallback&amp;project=rtmp_client" class="xa">connectCallback</a>) {
<a class="l" name="171" href="#171">171</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"connect server: {} port {} application {} connectCallback {}"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <a href="/source/s?defs=server&amp;project=rtmp_client">server</a>, <a href="/source/s?defs=port&amp;project=rtmp_client">port</a>, <a href="/source/s?defs=application&amp;project=rtmp_client">application</a>, <a href="/source/s?defs=connectCallback&amp;project=rtmp_client">connectCallback</a> });
<a class="l" name="172" href="#172">172</a>		<a href="/source/s?defs=connect&amp;project=rtmp_client">connect</a>(<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>, <a href="/source/s?defs=port&amp;project=rtmp_client">port</a>, <a class="d" href="#makeDefaultConnectionParams">makeDefaultConnectionParams</a>(<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>, <a href="/source/s?defs=port&amp;project=rtmp_client">port</a>, <a href="/source/s?defs=application&amp;project=rtmp_client">application</a>), <a href="/source/s?defs=connectCallback&amp;project=rtmp_client">connectCallback</a>);
<a class="l" name="173" href="#173">173</a>	}
<a class="l" name="174" href="#174">174</a>
<a class="l" name="175" href="#175">175</a>	<span class="c">/**
<a class="l" name="176" href="#176">176</a>	 * <strong>@param</strong> <em>server</em> Server
<a class="l" name="177" href="#177">177</a>	 * <strong>@param</strong> <em>port</em> Connection port
<a class="l" name="178" href="#178">178</a>	 * <strong>@param</strong> <em>application</em> Application at that server
<a class="l" name="179" href="#179">179</a>	 * <strong>@return</strong> default connection parameters
<a class="hl" name="180" href="#180">180</a>	 */</span>
<a class="l" name="181" href="#181">181</a>	<b>public</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xmt" name="makeDefaultConnectionParams"/><a href="/source/s?refs=makeDefaultConnectionParams&amp;project=rtmp_client" class="xmt">makeDefaultConnectionParams</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="server"/><a href="/source/s?refs=server&amp;project=rtmp_client" class="xa">server</a>, <b>int</b> <a class="xa" name="port"/><a href="/source/s?refs=port&amp;project=rtmp_client" class="xa">port</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="application"/><a href="/source/s?refs=application&amp;project=rtmp_client" class="xa">application</a>) {
<a class="l" name="182" href="#182">182</a>		<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="d" href="#params">params</a> = <b>new</b> <a href="/source/s?defs=ObjectMap&amp;project=rtmp_client">ObjectMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="l" name="183" href="#183">183</a>		<a class="d" href="#params">params</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"app"</span>, <a href="/source/s?defs=application&amp;project=rtmp_client">application</a>);
<a class="l" name="184" href="#184">184</a>		<a class="d" href="#params">params</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"objectEncoding"</span>, <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<span class="n">0</span>));
<a class="l" name="185" href="#185">185</a>		<a class="d" href="#params">params</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"fpad"</span>, <a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a>.<a href="/source/s?defs=FALSE&amp;project=rtmp_client">FALSE</a>);
<a class="l" name="186" href="#186">186</a>		<a class="d" href="#params">params</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"flashVer"</span>, <span class="s">"WIN 9,0,124,2"</span>);
<a class="l" name="187" href="#187">187</a>		<a class="d" href="#params">params</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"audioCodecs"</span>, <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<span class="n">1639</span>));
<a class="l" name="188" href="#188">188</a>		<a class="d" href="#params">params</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"videoFunction"</span>, <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<span class="n">1</span>));
<a class="l" name="189" href="#189">189</a>		<a class="d" href="#params">params</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"pageUrl"</span>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="hl" name="190" href="#190">190</a>		<a class="d" href="#params">params</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"path"</span>, <a href="/source/s?defs=application&amp;project=rtmp_client">application</a>);
<a class="l" name="191" href="#191">191</a>		<a class="d" href="#params">params</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"capabilities"</span>, <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<span class="n">15</span>));
<a class="l" name="192" href="#192">192</a>		<a class="d" href="#params">params</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"swfUrl"</span>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="193" href="#193">193</a>		<a class="d" href="#params">params</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"videoCodecs"</span>, <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<span class="n">252</span>));
<a class="l" name="194" href="#194">194</a>		<b>return</b> <a class="d" href="#params">params</a>;
<a class="l" name="195" href="#195">195</a>	}
<a class="l" name="196" href="#196">196</a>
<a class="l" name="197" href="#197">197</a>	<span class="c">/**
<a class="l" name="198" href="#198">198</a>	 * Connect RTMP client to server via given port and with given connection
<a class="l" name="199" href="#199">199</a>	 * parameters
<a class="hl" name="200" href="#200">200</a>	 *
<a class="l" name="201" href="#201">201</a>	 * <strong>@param</strong> <em>server</em> Server
<a class="l" name="202" href="#202">202</a>	 * <strong>@param</strong> <em>port</em> Connection port
<a class="l" name="203" href="#203">203</a>	 * <strong>@param</strong> <em>connectionParams</em> Connection parameters
<a class="l" name="204" href="#204">204</a>	 */</span>
<a class="l" name="205" href="#205">205</a>	<b>public</b> <b>void</b> <a class="xmt" name="connect"/><a href="/source/s?refs=connect&amp;project=rtmp_client" class="xmt">connect</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="server"/><a href="/source/s?refs=server&amp;project=rtmp_client" class="xa">server</a>, <b>int</b> <a class="xa" name="port"/><a href="/source/s?refs=port&amp;project=rtmp_client" class="xa">port</a>, <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xa" name="connectionParams"/><a href="/source/s?refs=connectionParams&amp;project=rtmp_client" class="xa">connectionParams</a>) {
<a class="l" name="206" href="#206">206</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"connect server: {} port {} connectionParams {}"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <a href="/source/s?defs=server&amp;project=rtmp_client">server</a>, <a href="/source/s?defs=port&amp;project=rtmp_client">port</a>, <a href="/source/s?defs=connectionParams&amp;project=rtmp_client">connectionParams</a> });
<a class="l" name="207" href="#207">207</a>		<a href="/source/s?defs=connect&amp;project=rtmp_client">connect</a>(<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>, <a href="/source/s?defs=port&amp;project=rtmp_client">port</a>, <a href="/source/s?defs=connectionParams&amp;project=rtmp_client">connectionParams</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="208" href="#208">208</a>	}
<a class="l" name="209" href="#209">209</a>
<a class="hl" name="210" href="#210">210</a>	<span class="c">/**
<a class="l" name="211" href="#211">211</a>	 * Connect RTMP client to server's application via given port
<a class="l" name="212" href="#212">212</a>	 *
<a class="l" name="213" href="#213">213</a>	 * <strong>@param</strong> <em>server</em> Server
<a class="l" name="214" href="#214">214</a>	 * <strong>@param</strong> <em>port</em> Connection port
<a class="l" name="215" href="#215">215</a>	 * <strong>@param</strong> <em>connectionParams</em> Connection parameters
<a class="l" name="216" href="#216">216</a>	 * <strong>@param</strong> <em>connectCallback</em> Connection callback
<a class="l" name="217" href="#217">217</a>	 */</span>
<a class="l" name="218" href="#218">218</a>	<b>public</b> <b>void</b> <a class="xmt" name="connect"/><a href="/source/s?refs=connect&amp;project=rtmp_client" class="xmt">connect</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="server"/><a href="/source/s?refs=server&amp;project=rtmp_client" class="xa">server</a>, <b>int</b> <a class="xa" name="port"/><a href="/source/s?refs=port&amp;project=rtmp_client" class="xa">port</a>, <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xa" name="connectionParams"/><a href="/source/s?refs=connectionParams&amp;project=rtmp_client" class="xa">connectionParams</a>, <a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> <a class="xa" name="connectCallback"/><a href="/source/s?refs=connectCallback&amp;project=rtmp_client" class="xa">connectCallback</a>) {
<a class="l" name="219" href="#219">219</a>		<a href="/source/s?defs=connect&amp;project=rtmp_client">connect</a>(<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>, <a href="/source/s?defs=port&amp;project=rtmp_client">port</a>, <a href="/source/s?defs=connectionParams&amp;project=rtmp_client">connectionParams</a>, <a href="/source/s?defs=connectCallback&amp;project=rtmp_client">connectCallback</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="hl" name="220" href="#220">220</a>	}
<a class="l" name="221" href="#221">221</a>
<a class="l" name="222" href="#222">222</a>	<span class="c">/**
<a class="l" name="223" href="#223">223</a>	 * Connect RTMP client to server's application via given port
<a class="l" name="224" href="#224">224</a>	 *
<a class="l" name="225" href="#225">225</a>	 * <strong>@param</strong> <em>server</em> Server
<a class="l" name="226" href="#226">226</a>	 * <strong>@param</strong> <em>port</em> Connection port
<a class="l" name="227" href="#227">227</a>	 * <strong>@param</strong> <em>connectionParams</em> Connection parameters
<a class="l" name="228" href="#228">228</a>	 * <strong>@param</strong> <em>connectCallback</em> Connection callback
<a class="l" name="229" href="#229">229</a>	 * <strong>@param</strong> <em>connectCallArguments</em> Arguments for 'connect' call
<a class="hl" name="230" href="#230">230</a>	 */</span>
<a class="l" name="231" href="#231">231</a>	<b>public</b> <b>void</b> <a class="xmt" name="connect"/><a href="/source/s?refs=connect&amp;project=rtmp_client" class="xmt">connect</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="server"/><a href="/source/s?refs=server&amp;project=rtmp_client" class="xa">server</a>, <b>int</b> <a class="xa" name="port"/><a href="/source/s?refs=port&amp;project=rtmp_client" class="xa">port</a>, <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xa" name="connectionParams"/><a href="/source/s?refs=connectionParams&amp;project=rtmp_client" class="xa">connectionParams</a>, <a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> <a class="xa" name="connectCallback"/><a href="/source/s?refs=connectCallback&amp;project=rtmp_client" class="xa">connectCallback</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xa" name="connectCallArguments"/><a href="/source/s?refs=connectCallArguments&amp;project=rtmp_client" class="xa">connectCallArguments</a>) {
<a class="l" name="232" href="#232">232</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"connect server: {} port {} connect - params: {} callback: {} args: {}"</span>,
<a class="l" name="233" href="#233">233</a>				<b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <a href="/source/s?defs=server&amp;project=rtmp_client">server</a>, <a href="/source/s?defs=port&amp;project=rtmp_client">port</a>, <a href="/source/s?defs=connectionParams&amp;project=rtmp_client">connectionParams</a>, <a href="/source/s?defs=connectCallback&amp;project=rtmp_client">connectCallback</a>, <a href="/source/s?defs=Arrays&amp;project=rtmp_client">Arrays</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>(<a class="d" href="#connectCallArguments">connectCallArguments</a>) });
<a class="l" name="234" href="#234">234</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"{}://{}:{}/{}"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <a class="d" href="#scheme">scheme</a>, <a href="/source/s?defs=server&amp;project=rtmp_client">server</a>, <a href="/source/s?defs=port&amp;project=rtmp_client">port</a>, <a href="/source/s?defs=connectionParams&amp;project=rtmp_client">connectionParams</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<span class="s">"app"</span>) });
<a class="l" name="235" href="#235">235</a>		<b>this</b>.<a href="/source/s?defs=connectionParams&amp;project=rtmp_client">connectionParams</a> = <a href="/source/s?defs=connectionParams&amp;project=rtmp_client">connectionParams</a>;
<a class="l" name="236" href="#236">236</a>		<b>this</b>.<a class="d" href="#connectArguments">connectArguments</a> = <a class="d" href="#connectCallArguments">connectCallArguments</a>;
<a class="l" name="237" href="#237">237</a>
<a class="l" name="238" href="#238">238</a>		<b>if</b> (!<a href="/source/s?defs=connectionParams&amp;project=rtmp_client">connectionParams</a>.<a href="/source/s?defs=containsKey&amp;project=rtmp_client">containsKey</a>(<span class="s">"objectEncoding"</span>)) {
<a class="l" name="239" href="#239">239</a>			<a href="/source/s?defs=connectionParams&amp;project=rtmp_client">connectionParams</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"objectEncoding"</span>, <span class="n">0</span>);
<a class="hl" name="240" href="#240">240</a>		}
<a class="l" name="241" href="#241">241</a>
<a class="l" name="242" href="#242">242</a>		<b>this</b>.<a href="/source/s?defs=connectCallback&amp;project=rtmp_client">connectCallback</a> = <a href="/source/s?defs=connectCallback&amp;project=rtmp_client">connectCallback</a>;
<a class="l" name="243" href="#243">243</a>
<a class="l" name="244" href="#244">244</a>		<a class="d" href="#startConnector">startConnector</a>(<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>, <a href="/source/s?defs=port&amp;project=rtmp_client">port</a>);
<a class="l" name="245" href="#245">245</a>	}
<a class="l" name="246" href="#246">246</a>
<a class="l" name="247" href="#247">247</a>	<span class="c">/**
<a class="l" name="248" href="#248">248</a>	 * Register object that provides methods that can be called by the server.
<a class="l" name="249" href="#249">249</a>	 *
<a class="hl" name="250" href="#250">250</a>	 * <strong>@param</strong> <em>serviceProvider</em> Service provider
<a class="l" name="251" href="#251">251</a>	 */</span>
<a class="l" name="252" href="#252">252</a>	<b>public</b> <b>void</b> <a class="xmt" name="setServiceProvider"/><a href="/source/s?refs=setServiceProvider&amp;project=rtmp_client" class="xmt">setServiceProvider</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="serviceProvider"/><a href="/source/s?refs=serviceProvider&amp;project=rtmp_client" class="xa">serviceProvider</a>) {
<a class="l" name="253" href="#253">253</a>		<b>this</b>.<a href="/source/s?defs=serviceProvider&amp;project=rtmp_client">serviceProvider</a> = <a href="/source/s?defs=serviceProvider&amp;project=rtmp_client">serviceProvider</a>;
<a class="l" name="254" href="#254">254</a>	}
<a class="l" name="255" href="#255">255</a>
<a class="l" name="256" href="#256">256</a>	<span class="c">/**
<a class="l" name="257" href="#257">257</a>	 * Connect to client shared object.
<a class="l" name="258" href="#258">258</a>	 *
<a class="l" name="259" href="#259">259</a>	 * <strong>@param</strong> <em>name</em> Client shared object name
<a class="hl" name="260" href="#260">260</a>	 * <strong>@param</strong> <em>persistent</em> SO persistence flag
<a class="l" name="261" href="#261">261</a>	 * <strong>@return</strong> Client shared object instance
<a class="l" name="262" href="#262">262</a>	 */</span>
<a class="l" name="263" href="#263">263</a>	<b>public</b> <b>synchronized</b> <a href="/source/s?defs=IClientSharedObject&amp;project=rtmp_client">IClientSharedObject</a> <a class="xmt" name="getSharedObject"/><a href="/source/s?refs=getSharedObject&amp;project=rtmp_client" class="xmt">getSharedObject</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>, <b>boolean</b> <a class="xa" name="persistent"/><a href="/source/s?refs=persistent&amp;project=rtmp_client" class="xa">persistent</a>) {
<a class="l" name="264" href="#264">264</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"getSharedObject name: {} persistent {}"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a class="d" href="#persistent">persistent</a> });
<a class="l" name="265" href="#265">265</a>		<a href="/source/s?defs=ClientSharedObject&amp;project=rtmp_client">ClientSharedObject</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a class="d" href="#sharedObjects">sharedObjects</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>);
<a class="l" name="266" href="#266">266</a>		<b>if</b> (<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="267" href="#267">267</a>			<b>if</b> (<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=isPersistentObject&amp;project=rtmp_client">isPersistentObject</a>() != <a class="d" href="#persistent">persistent</a>) {
<a class="l" name="268" href="#268">268</a>				<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"Already connected to a shared object with this name, but with different persistence."</span>);
<a class="l" name="269" href="#269">269</a>			}
<a class="hl" name="270" href="#270">270</a>			<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="271" href="#271">271</a>		}
<a class="l" name="272" href="#272">272</a>
<a class="l" name="273" href="#273">273</a>		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>new</b> <a href="/source/s?defs=ClientSharedObject&amp;project=rtmp_client">ClientSharedObject</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a class="d" href="#persistent">persistent</a>);
<a class="l" name="274" href="#274">274</a>		<a class="d" href="#sharedObjects">sharedObjects</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>);
<a class="l" name="275" href="#275">275</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="276" href="#276">276</a>	}
<a class="l" name="277" href="#277">277</a>
<a class="l" name="278" href="#278">278</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="279" href="#279">279</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="hl" name="280" href="#280">280</a>	<b>protected</b> <b>void</b> <a class="xmt" name="onChunkSize"/><a href="/source/s?refs=onChunkSize&amp;project=rtmp_client" class="xmt">onChunkSize</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xa" name="conn"/><a href="/source/s?refs=conn&amp;project=rtmp_client" class="xa">conn</a>, <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a class="xa" name="channel"/><a href="/source/s?refs=channel&amp;project=rtmp_client" class="xa">channel</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=ChunkSize&amp;project=rtmp_client">ChunkSize</a> <a class="xa" name="chunkSize"/><a href="/source/s?refs=chunkSize&amp;project=rtmp_client" class="xa">chunkSize</a>) {
<a class="l" name="281" href="#281">281</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"onChunkSize"</span>);
<a class="l" name="282" href="#282">282</a>		<span class="c">// set read and write chunk sizes</span>
<a class="l" name="283" href="#283">283</a>		<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a href="/source/s?defs=state&amp;project=rtmp_client">state</a> = <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=getState&amp;project=rtmp_client">getState</a>();
<a class="l" name="284" href="#284">284</a>		<a href="/source/s?defs=state&amp;project=rtmp_client">state</a>.<a href="/source/s?defs=setReadChunkSize&amp;project=rtmp_client">setReadChunkSize</a>(<a class="d" href="#chunkSize">chunkSize</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>());
<a class="l" name="285" href="#285">285</a>		<a href="/source/s?defs=state&amp;project=rtmp_client">state</a>.<a href="/source/s?defs=setWriteChunkSize&amp;project=rtmp_client">setWriteChunkSize</a>(<a class="d" href="#chunkSize">chunkSize</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>());
<a class="l" name="286" href="#286">286</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"ChunkSize is not implemented yet: {}"</span>, <a class="d" href="#chunkSize">chunkSize</a>);
<a class="l" name="287" href="#287">287</a>	}
<a class="l" name="288" href="#288">288</a>
<a class="l" name="289" href="#289">289</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="290" href="#290">290</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="291" href="#291">291</a>	<b>protected</b> <b>void</b> <a class="xmt" name="onPing"/><a href="/source/s?refs=onPing&amp;project=rtmp_client" class="xmt">onPing</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xa" name="conn"/><a href="/source/s?refs=conn&amp;project=rtmp_client" class="xa">conn</a>, <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a class="xa" name="channel"/><a href="/source/s?refs=channel&amp;project=rtmp_client" class="xa">channel</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a> <a class="xa" name="ping"/><a href="/source/s?refs=ping&amp;project=rtmp_client" class="xa">ping</a>) {
<a class="l" name="292" href="#292">292</a>		<span class="c">//log.debug("onPing");</span>
<a class="l" name="293" href="#293">293</a>		<b>switch</b> (<a class="d" href="#ping">ping</a>.<a href="/source/s?defs=getEventType&amp;project=rtmp_client">getEventType</a>()) {
<a class="l" name="294" href="#294">294</a>			<b>case</b> <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>.<a href="/source/s?defs=PING_CLIENT&amp;project=rtmp_client">PING_CLIENT</a>:
<a class="l" name="295" href="#295">295</a>			<b>case</b> <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>.<a href="/source/s?defs=STREAM_BEGIN&amp;project=rtmp_client">STREAM_BEGIN</a>:
<a class="l" name="296" href="#296">296</a>			<b>case</b> <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>.<a href="/source/s?defs=RECORDED_STREAM&amp;project=rtmp_client">RECORDED_STREAM</a>:
<a class="l" name="297" href="#297">297</a>			<b>case</b> <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>.<a href="/source/s?defs=STREAM_PLAYBUFFER_CLEAR&amp;project=rtmp_client">STREAM_PLAYBUFFER_CLEAR</a>:
<a class="l" name="298" href="#298">298</a>				<span class="c">// The server wants to measure the RTT</span>
<a class="l" name="299" href="#299">299</a>				<a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a> <a href="/source/s?defs=pong&amp;project=rtmp_client">pong</a> = <b>new</b> <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>();
<a class="hl" name="300" href="#300">300</a>				<a href="/source/s?defs=pong&amp;project=rtmp_client">pong</a>.<a href="/source/s?defs=setEventType&amp;project=rtmp_client">setEventType</a>(<a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>.<a href="/source/s?defs=PONG_SERVER&amp;project=rtmp_client">PONG_SERVER</a>);
<a class="l" name="301" href="#301">301</a>				<a href="/source/s?defs=pong&amp;project=rtmp_client">pong</a>.<a href="/source/s?defs=setValue2&amp;project=rtmp_client">setValue2</a>((<b>int</b>) (<a href="/source/s?defs=System&amp;project=rtmp_client">System</a>.<a href="/source/s?defs=currentTimeMillis&amp;project=rtmp_client">currentTimeMillis</a>() &amp; <span class="n">0xffffffff</span>));
<a class="l" name="302" href="#302">302</a>				<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a class="d" href="#ping">ping</a>(<a href="/source/s?defs=pong&amp;project=rtmp_client">pong</a>);
<a class="l" name="303" href="#303">303</a>				<b>break</b>;
<a class="l" name="304" href="#304">304</a>			<b>case</b> <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>.<a href="/source/s?defs=STREAM_DRY&amp;project=rtmp_client">STREAM_DRY</a>:
<a class="l" name="305" href="#305">305</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Stream indicates there is no data available"</span>);
<a class="l" name="306" href="#306">306</a>				<b>break</b>;
<a class="l" name="307" href="#307">307</a>			<b>case</b> <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>.<a href="/source/s?defs=CLIENT_BUFFER&amp;project=rtmp_client">CLIENT_BUFFER</a>:
<a class="l" name="308" href="#308">308</a>				<span class="c">//set the client buffer</span>
<a class="l" name="309" href="#309">309</a><span class="c">//				IClientStream stream = null;</span>
<a class="hl" name="310" href="#310">310</a><span class="c">//				//get the stream id</span>
<a class="l" name="311" href="#311">311</a><span class="c">//				int streamId = ping.getValue2();</span>
<a class="l" name="312" href="#312">312</a><span class="c">//				//get requested buffer size in milliseconds</span>
<a class="l" name="313" href="#313">313</a><span class="c">//				int buffer = ping.getValue3();</span>
<a class="l" name="314" href="#314">314</a><span class="c">//				log.debug("Client sent a buffer size: {} ms for stream id: {}", buffer, streamId);</span>
<a class="l" name="315" href="#315">315</a><span class="c">//				if (streamId != 0) {</span>
<a class="l" name="316" href="#316">316</a><span class="c">//					// The client wants to set the buffer time</span>
<a class="l" name="317" href="#317">317</a><span class="c">//					stream = conn.getStreamById(streamId);</span>
<a class="l" name="318" href="#318">318</a><span class="c">//					if (stream != null) {</span>
<a class="l" name="319" href="#319">319</a><span class="c">//						stream.setClientBufferDuration(buffer);</span>
<a class="hl" name="320" href="#320">320</a><span class="c">//						log.info("Setting client buffer on stream: {}", buffer);</span>
<a class="l" name="321" href="#321">321</a><span class="c">//					}</span>
<a class="l" name="322" href="#322">322</a><span class="c">//				}</span>
<a class="l" name="323" href="#323">323</a><span class="c">//				//catch-all to make sure buffer size is set</span>
<a class="l" name="324" href="#324">324</a><span class="c">//				if (stream == null) {</span>
<a class="l" name="325" href="#325">325</a><span class="c">//					// Remember buffer time until stream is created</span>
<a class="l" name="326" href="#326">326</a><span class="c">//					conn.rememberStreamBufferDuration(streamId, buffer);</span>
<a class="l" name="327" href="#327">327</a><span class="c">//					log.info("Remembering client buffer on stream: {}", buffer);</span>
<a class="l" name="328" href="#328">328</a><span class="c">//				}</span>
<a class="l" name="329" href="#329">329</a>				<b>break</b>;
<a class="hl" name="330" href="#330">330</a>			<b>case</b> <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>.<a href="/source/s?defs=PING_SWF_VERIFY&amp;project=rtmp_client">PING_SWF_VERIFY</a>:
<a class="l" name="331" href="#331">331</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"SWF verification ping"</span>);
<a class="l" name="332" href="#332">332</a>				<a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a> <a href="/source/s?defs=swfPong&amp;project=rtmp_client">swfPong</a> = <b>new</b> <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>();
<a class="l" name="333" href="#333">333</a>				<a href="/source/s?defs=swfPong&amp;project=rtmp_client">swfPong</a>.<a href="/source/s?defs=setEventType&amp;project=rtmp_client">setEventType</a>(<a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>.<a href="/source/s?defs=PONG_SWF_VERIFY&amp;project=rtmp_client">PONG_SWF_VERIFY</a>);
<a class="l" name="334" href="#334">334</a>				<a href="/source/s?defs=swfPong&amp;project=rtmp_client">swfPong</a>.<a href="/source/s?defs=setValue2&amp;project=rtmp_client">setValue2</a>((<b>int</b>) (<a href="/source/s?defs=System&amp;project=rtmp_client">System</a>.<a href="/source/s?defs=currentTimeMillis&amp;project=rtmp_client">currentTimeMillis</a>() &amp; <span class="n">0xffffffff</span>));
<a class="l" name="335" href="#335">335</a>				<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a class="d" href="#ping">ping</a>(<a href="/source/s?defs=swfPong&amp;project=rtmp_client">swfPong</a>);
<a class="l" name="336" href="#336">336</a>				<b>break</b>;
<a class="l" name="337" href="#337">337</a>			<b>default</b>:
<a class="l" name="338" href="#338">338</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Unhandled ping: {}"</span>, <a class="d" href="#ping">ping</a>);
<a class="l" name="339" href="#339">339</a>		}
<a class="hl" name="340" href="#340">340</a>	}
<a class="l" name="341" href="#341">341</a>
<a class="l" name="342" href="#342">342</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="343" href="#343">343</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="344" href="#344">344</a>	<b>protected</b> <b>void</b> <a class="xmt" name="onSharedObject"/><a href="/source/s?refs=onSharedObject&amp;project=rtmp_client" class="xmt">onSharedObject</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xa" name="conn"/><a href="/source/s?refs=conn&amp;project=rtmp_client" class="xa">conn</a>, <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a class="xa" name="channel"/><a href="/source/s?refs=channel&amp;project=rtmp_client" class="xa">channel</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=SharedObjectMessage&amp;project=rtmp_client">SharedObjectMessage</a> <a class="xa" name="object"/><a href="/source/s?refs=object&amp;project=rtmp_client" class="xa">object</a>) {
<a class="l" name="345" href="#345">345</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"onSharedObject"</span>);
<a class="l" name="346" href="#346">346</a>		<a href="/source/s?defs=ClientSharedObject&amp;project=rtmp_client">ClientSharedObject</a> <a href="/source/s?defs=so&amp;project=rtmp_client">so</a> = <a class="d" href="#sharedObjects">sharedObjects</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a class="d" href="#object">object</a>.<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>());
<a class="l" name="347" href="#347">347</a>		<b>if</b> (<a href="/source/s?defs=so&amp;project=rtmp_client">so</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="348" href="#348">348</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Ignoring request for non-existend SO: {}"</span>, <a class="d" href="#object">object</a>);
<a class="l" name="349" href="#349">349</a>			<b>return</b>;
<a class="hl" name="350" href="#350">350</a>		}
<a class="l" name="351" href="#351">351</a>		<b>if</b> (<a href="/source/s?defs=so&amp;project=rtmp_client">so</a>.<a href="/source/s?defs=isPersistentObject&amp;project=rtmp_client">isPersistentObject</a>() != <a class="d" href="#object">object</a>.<a href="/source/s?defs=isPersistent&amp;project=rtmp_client">isPersistent</a>()) {
<a class="l" name="352" href="#352">352</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Ignoring request for wrong-persistent SO: {}"</span>, <a class="d" href="#object">object</a>);
<a class="l" name="353" href="#353">353</a>			<b>return</b>;
<a class="l" name="354" href="#354">354</a>		}
<a class="l" name="355" href="#355">355</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Received SO request: {}"</span>, <a class="d" href="#object">object</a>);
<a class="l" name="356" href="#356">356</a>		<a href="/source/s?defs=so&amp;project=rtmp_client">so</a>.<a class="d" href="#dispatchEvent">dispatchEvent</a>(<a class="d" href="#object">object</a>);
<a class="l" name="357" href="#357">357</a>	}
<a class="l" name="358" href="#358">358</a>
<a class="l" name="359" href="#359">359</a>	<span class="c">/**
<a class="hl" name="360" href="#360">360</a>	 * Called when bandwidth has been configured.
<a class="l" name="361" href="#361">361</a>	 */</span>
<a class="l" name="362" href="#362">362</a>	<b>public</b> <b>void</b> <a class="xmt" name="onBWDone"/><a href="/source/s?refs=onBWDone&amp;project=rtmp_client" class="xmt">onBWDone</a>() {
<a class="l" name="363" href="#363">363</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"onBWDone"</span>);
<a class="l" name="364" href="#364">364</a>	}
<a class="l" name="365" href="#365">365</a>
<a class="l" name="366" href="#366">366</a>	<span class="c">/**
<a class="l" name="367" href="#367">367</a>	 * Invoke a method on the server.
<a class="l" name="368" href="#368">368</a>	 *
<a class="l" name="369" href="#369">369</a>	 * <strong>@param</strong> <em>method</em> Method name
<a class="hl" name="370" href="#370">370</a>	 * <strong>@param</strong> <em>callback</em> Callback handler
<a class="l" name="371" href="#371">371</a>	 */</span>
<a class="l" name="372" href="#372">372</a>	<b>public</b> <b>void</b> <a class="xmt" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xmt">invoke</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="method"/><a href="/source/s?refs=method&amp;project=rtmp_client" class="xa">method</a>, <a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> <a class="xa" name="callback"/><a href="/source/s?refs=callback&amp;project=rtmp_client" class="xa">callback</a>) {
<a class="l" name="373" href="#373">373</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"invoke method: {} params {} callback {}"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <a href="/source/s?defs=method&amp;project=rtmp_client">method</a>, <a href="/source/s?defs=callback&amp;project=rtmp_client">callback</a> });
<a class="l" name="374" href="#374">374</a>		<span class="c">// get it from the conn manager</span>
<a class="l" name="375" href="#375">375</a>		<b>if</b> (<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="376" href="#376">376</a>			<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>(<a href="/source/s?defs=method&amp;project=rtmp_client">method</a>, <a href="/source/s?defs=callback&amp;project=rtmp_client">callback</a>);
<a class="l" name="377" href="#377">377</a>		} <b>else</b> {
<a class="l" name="378" href="#378">378</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"Connection was null"</span>);
<a class="l" name="379" href="#379">379</a>            <a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>new</b> <a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a>(<a href="/source/s?defs=method&amp;project=rtmp_client">method</a>);
<a class="hl" name="380" href="#380">380</a>            <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=setStatus&amp;project=rtmp_client">setStatus</a>(<a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>.<a href="/source/s?defs=STATUS_NOT_CONNECTED&amp;project=rtmp_client">STATUS_NOT_CONNECTED</a>);
<a class="l" name="381" href="#381">381</a>            <a href="/source/s?defs=callback&amp;project=rtmp_client">callback</a>.<a class="d" href="#resultReceived">resultReceived</a>(<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>);
<a class="l" name="382" href="#382">382</a>		}
<a class="l" name="383" href="#383">383</a>	}
<a class="l" name="384" href="#384">384</a>
<a class="l" name="385" href="#385">385</a>	<span class="c">/**
<a class="l" name="386" href="#386">386</a>	 * Invoke a method on the server and pass parameters.
<a class="l" name="387" href="#387">387</a>	 *
<a class="l" name="388" href="#388">388</a>	 * <strong>@param</strong> <em>method</em> Method
<a class="l" name="389" href="#389">389</a>	 * <strong>@param</strong> <em>params</em> Method call parameters
<a class="hl" name="390" href="#390">390</a>	 * <strong>@param</strong> <em>callback</em> Callback object
<a class="l" name="391" href="#391">391</a>	 */</span>
<a class="l" name="392" href="#392">392</a>	<b>public</b> <b>void</b> <a class="xmt" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xmt">invoke</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="method"/><a href="/source/s?refs=method&amp;project=rtmp_client" class="xa">method</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xa" name="params"/><a href="/source/s?refs=params&amp;project=rtmp_client" class="xa">params</a>, <a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> <a class="xa" name="callback"/><a href="/source/s?refs=callback&amp;project=rtmp_client" class="xa">callback</a>) {
<a class="l" name="393" href="#393">393</a><span class="c">//		log.error("invoke method: {} params {} callback {}", new Object[] { method, params, callback });</span>
<a class="l" name="394" href="#394">394</a>		<b>if</b> (<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="395" href="#395">395</a>            <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>(<a href="/source/s?defs=method&amp;project=rtmp_client">method</a>, <a class="d" href="#params">params</a>, <a href="/source/s?defs=callback&amp;project=rtmp_client">callback</a>);
<a class="l" name="396" href="#396">396</a>		} <b>else</b> {
<a class="l" name="397" href="#397">397</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"Connection was null"</span>);
<a class="l" name="398" href="#398">398</a>            <a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>new</b> <a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a>(<a href="/source/s?defs=method&amp;project=rtmp_client">method</a>, <a class="d" href="#params">params</a>);
<a class="l" name="399" href="#399">399</a>            <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=setStatus&amp;project=rtmp_client">setStatus</a>(<a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>.<a href="/source/s?defs=STATUS_NOT_CONNECTED&amp;project=rtmp_client">STATUS_NOT_CONNECTED</a>);
<a class="hl" name="400" href="#400">400</a>            <a href="/source/s?defs=callback&amp;project=rtmp_client">callback</a>.<a class="d" href="#resultReceived">resultReceived</a>(<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>);
<a class="l" name="401" href="#401">401</a>		}
<a class="l" name="402" href="#402">402</a>	}
<a class="l" name="403" href="#403">403</a>
<a class="l" name="404" href="#404">404</a>	<span class="c">/**
<a class="l" name="405" href="#405">405</a>	 * Disconnect the first connection in the connection map
<a class="l" name="406" href="#406">406</a>	 */</span>
<a class="l" name="407" href="#407">407</a>	<b>public</b> <b>void</b> <a class="xmt" name="disconnect"/><a href="/source/s?refs=disconnect&amp;project=rtmp_client" class="xmt">disconnect</a>() {
<a class="l" name="408" href="#408">408</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"disconnect"</span>);
<a class="l" name="409" href="#409">409</a>		<b>if</b> (<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="410" href="#410">410</a>			<a class="d" href="#streamDataMap">streamDataMap</a>.<a href="/source/s?defs=clear&amp;project=rtmp_client">clear</a>();
<a class="l" name="411" href="#411">411</a>			<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a class="d" href="#close">close</a>();
<a class="l" name="412" href="#412">412</a>		} <b>else</b> {
<a class="l" name="413" href="#413">413</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"Connection was null"</span>);
<a class="l" name="414" href="#414">414</a>		}
<a class="l" name="415" href="#415">415</a>	}
<a class="l" name="416" href="#416">416</a>
<a class="l" name="417" href="#417">417</a>	<b>public</b> <b>void</b> <a class="xmt" name="createStream"/><a href="/source/s?refs=createStream&amp;project=rtmp_client" class="xmt">createStream</a>(<a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> <a class="xa" name="callback"/><a href="/source/s?refs=callback&amp;project=rtmp_client" class="xa">callback</a>) {
<a class="l" name="418" href="#418">418</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"createStream - callback: {}"</span>, <a href="/source/s?defs=callback&amp;project=rtmp_client">callback</a>);
<a class="l" name="419" href="#419">419</a>		<a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> <a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a> = <b>new</b> <a href="/source/s?defs=CreateStreamCallBack&amp;project=rtmp_client">CreateStreamCallBack</a>(<a href="/source/s?defs=callback&amp;project=rtmp_client">callback</a>);
<a class="hl" name="420" href="#420">420</a>		<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>(<span class="s">"createStream"</span>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>);
<a class="l" name="421" href="#421">421</a>	}
<a class="l" name="422" href="#422">422</a>
<a class="l" name="423" href="#423">423</a>	<b>public</b> <b>void</b> <a class="xmt" name="publish"/><a href="/source/s?refs=publish&amp;project=rtmp_client" class="xmt">publish</a>(<b>int</b> <a class="xa" name="streamId"/><a href="/source/s?refs=streamId&amp;project=rtmp_client" class="xa">streamId</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="mode"/><a href="/source/s?refs=mode&amp;project=rtmp_client" class="xa">mode</a>, <a href="/source/s?defs=INetStreamEventHandler&amp;project=rtmp_client">INetStreamEventHandler</a> <a class="xa" name="handler"/><a href="/source/s?refs=handler&amp;project=rtmp_client" class="xa">handler</a>) {
<a class="l" name="424" href="#424">424</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"publish - stream id: {}, name: {}, mode: {}"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a class="d" href="#mode">mode</a> });
<a class="l" name="425" href="#425">425</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="d" href="#params">params</a> = <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[<span class="n">2</span>];
<a class="l" name="426" href="#426">426</a>		<a class="d" href="#params">params</a>[<span class="n">0</span>] = <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>;
<a class="l" name="427" href="#427">427</a>		<a class="d" href="#params">params</a>[<span class="n">1</span>] = <a class="d" href="#mode">mode</a>;
<a class="l" name="428" href="#428">428</a>		<a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a> <a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a> = <b>new</b> <a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a>(<span class="s">"publish"</span>, <a class="d" href="#params">params</a>);
<a class="l" name="429" href="#429">429</a>		<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>(<a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a>, <a class="d" href="#getChannelForStreamId">getChannelForStreamId</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a>));
<a class="hl" name="430" href="#430">430</a>		<b>if</b> (<a href="/source/s?defs=handler&amp;project=rtmp_client">handler</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="431" href="#431">431</a>			<a class="d" href="#NetStreamPrivateData">NetStreamPrivateData</a> <a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a> = <a class="d" href="#streamDataMap">streamDataMap</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a>);
<a class="l" name="432" href="#432">432</a>			<b>if</b> (<a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="433" href="#433">433</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Setting handler on stream data - handler: {}"</span>, <a href="/source/s?defs=handler&amp;project=rtmp_client">handler</a>);
<a class="l" name="434" href="#434">434</a>				<a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a>.<a href="/source/s?defs=handler&amp;project=rtmp_client">handler</a> = <a href="/source/s?defs=handler&amp;project=rtmp_client">handler</a>;
<a class="l" name="435" href="#435">435</a>			} <b>else</b> {
<a class="l" name="436" href="#436">436</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Stream data not found for stream id: {}"</span>, <a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a>);
<a class="l" name="437" href="#437">437</a>			}
<a class="l" name="438" href="#438">438</a>		}
<a class="l" name="439" href="#439">439</a>	}
<a class="hl" name="440" href="#440">440</a>
<a class="l" name="441" href="#441">441</a>	<b>public</b> <b>void</b> <a class="xmt" name="unpublish"/><a href="/source/s?refs=unpublish&amp;project=rtmp_client" class="xmt">unpublish</a>(<b>int</b> <a class="xa" name="streamId"/><a href="/source/s?refs=streamId&amp;project=rtmp_client" class="xa">streamId</a>) {
<a class="l" name="442" href="#442">442</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"unpublish stream {}"</span>, <a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a>);
<a class="l" name="443" href="#443">443</a>		<a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a> <a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a> = <b>new</b> <a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a>(<span class="s">"publish"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <b>false</b> });
<a class="l" name="444" href="#444">444</a>		<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>(<a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a>, <a class="d" href="#getChannelForStreamId">getChannelForStreamId</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a>));
<a class="l" name="445" href="#445">445</a>	}
<a class="l" name="446" href="#446">446</a>
<a class="l" name="447" href="#447">447</a>	<b>public</b> <b>void</b> <a class="xmt" name="publishStreamData"/><a href="/source/s?refs=publishStreamData&amp;project=rtmp_client" class="xmt">publishStreamData</a>(<b>int</b> <a class="xa" name="streamId"/><a href="/source/s?refs=streamId&amp;project=rtmp_client" class="xa">streamId</a>, <a href="/source/s?defs=IMessage&amp;project=rtmp_client">IMessage</a> <a class="xa" name="message"/><a href="/source/s?refs=message&amp;project=rtmp_client" class="xa">message</a>) {
<a class="l" name="448" href="#448">448</a>		<a class="d" href="#NetStreamPrivateData">NetStreamPrivateData</a> <a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a> = <a class="d" href="#streamDataMap">streamDataMap</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a>);
<a class="l" name="449" href="#449">449</a><span class="c">//		log.debug("publishStreamData - stream data map: {}",	streamDataMap);</span>
<a class="hl" name="450" href="#450">450</a>		<b>if</b> (<a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="451" href="#451">451</a>			<b>if</b> (<a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a>.<a class="d" href="#connConsumer">connConsumer</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="452" href="#452">452</a>				<a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a>.<a class="d" href="#connConsumer">connConsumer</a>.<a href="/source/s?defs=pushMessage&amp;project=rtmp_client">pushMessage</a>(<a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a class="d" href="#message">message</a>);
<a class="l" name="453" href="#453">453</a>			} <b>else</b> {
<a class="l" name="454" href="#454">454</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Connection consumer was not found for stream id: {}"</span>, <a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a>);
<a class="l" name="455" href="#455">455</a>			}
<a class="l" name="456" href="#456">456</a>		} <b>else</b> {
<a class="l" name="457" href="#457">457</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Stream data not found for stream id: {}"</span>, <a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a>);
<a class="l" name="458" href="#458">458</a>		}
<a class="l" name="459" href="#459">459</a>	}
<a class="hl" name="460" href="#460">460</a>
<a class="l" name="461" href="#461">461</a>	<b>public</b> <b>void</b> <a class="xmt" name="play"/><a href="/source/s?refs=play&amp;project=rtmp_client" class="xmt">play</a>(<b>int</b> <a class="xa" name="streamId"/><a href="/source/s?refs=streamId&amp;project=rtmp_client" class="xa">streamId</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>, <b>int</b> <a class="xa" name="start"/><a href="/source/s?refs=start&amp;project=rtmp_client" class="xa">start</a>, <b>int</b> <a class="xa" name="length"/><a href="/source/s?refs=length&amp;project=rtmp_client" class="xa">length</a>) {
<a class="l" name="462" href="#462">462</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"play stream {}, name: {}, start {}, length {}"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=start&amp;project=rtmp_client">start</a>, <a class="d" href="#length">length</a> });
<a class="l" name="463" href="#463">463</a>		<b>if</b> (<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="464" href="#464">464</a>			<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="d" href="#params">params</a> = <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[<span class="n">3</span>];
<a class="l" name="465" href="#465">465</a>			<a class="d" href="#params">params</a>[<span class="n">0</span>] = <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>;
<a class="l" name="466" href="#466">466</a>			<a class="d" href="#params">params</a>[<span class="n">1</span>] = <a href="/source/s?defs=start&amp;project=rtmp_client">start</a>;
<a class="l" name="467" href="#467">467</a>			<a class="d" href="#params">params</a>[<span class="n">2</span>] = <a class="d" href="#length">length</a>;
<a class="l" name="468" href="#468">468</a>			<a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a> <a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a> = <b>new</b> <a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a>(<span class="s">"play"</span>, <a class="d" href="#params">params</a>);
<a class="l" name="469" href="#469">469</a>			<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>(<a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a>, <a class="d" href="#getChannelForStreamId">getChannelForStreamId</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a>));
<a class="hl" name="470" href="#470">470</a>		} <b>else</b> {
<a class="l" name="471" href="#471">471</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"Connection was null ?"</span>);
<a class="l" name="472" href="#472">472</a>		}
<a class="l" name="473" href="#473">473</a>	}
<a class="l" name="474" href="#474">474</a>
<a class="l" name="475" href="#475">475</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="476" href="#476">476</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="477" href="#477">477</a>	<b>public</b> <b>void</b> <a class="xmt" name="connectionOpened"/><a href="/source/s?refs=connectionOpened&amp;project=rtmp_client" class="xmt">connectionOpened</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xa" name="conn"/><a href="/source/s?refs=conn&amp;project=rtmp_client" class="xa">conn</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="state"/><a href="/source/s?refs=state&amp;project=rtmp_client" class="xa">state</a>) {
<a class="l" name="478" href="#478">478</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"connectionOpened"</span>);
<a class="l" name="479" href="#479">479</a>		<span class="c">// Send "connect" call to the server</span>
<a class="hl" name="480" href="#480">480</a>		<a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a> = <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=getChannel&amp;project=rtmp_client">getChannel</a>((<b>byte</b>) <span class="n">3</span>);
<a class="l" name="481" href="#481">481</a>		<a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a> <a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a> = <b>new</b> <a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a>(<span class="s">"connect"</span>);
<a class="l" name="482" href="#482">482</a>		<a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a>.<a href="/source/s?defs=setArguments&amp;project=rtmp_client">setArguments</a>(<a class="d" href="#connectArguments">connectArguments</a>);
<a class="l" name="483" href="#483">483</a>		<a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a> <a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a> = <b>new</b> <a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>(<a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a>);
<a class="l" name="484" href="#484">484</a>		<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=setConnectionParams&amp;project=rtmp_client">setConnectionParams</a>(<a href="/source/s?defs=connectionParams&amp;project=rtmp_client">connectionParams</a>);
<a class="l" name="485" href="#485">485</a>		<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=setInvokeId&amp;project=rtmp_client">setInvokeId</a>(<span class="n">1</span>);
<a class="l" name="486" href="#486">486</a>		<b>if</b> (<a href="/source/s?defs=connectCallback&amp;project=rtmp_client">connectCallback</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="487" href="#487">487</a>			<a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a>.<a href="/source/s?defs=registerCallback&amp;project=rtmp_client">registerCallback</a>(<a href="/source/s?defs=connectCallback&amp;project=rtmp_client">connectCallback</a>);
<a class="l" name="488" href="#488">488</a>		}
<a class="l" name="489" href="#489">489</a>		<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=registerPendingCall&amp;project=rtmp_client">registerPendingCall</a>(<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=getInvokeId&amp;project=rtmp_client">getInvokeId</a>(), <a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a>);
<a class="hl" name="490" href="#490">490</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Writing 'connect' invoke: {}, invokeId: {}"</span>, <a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>, <a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=getInvokeId&amp;project=rtmp_client">getInvokeId</a>());
<a class="l" name="491" href="#491">491</a>		<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>);
<a class="l" name="492" href="#492">492</a>	}
<a class="l" name="493" href="#493">493</a>
<a class="l" name="494" href="#494">494</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="495" href="#495">495</a>	<b>public</b> <b>void</b> <a class="xmt" name="connectionClosed"/><a href="/source/s?refs=connectionClosed&amp;project=rtmp_client" class="xmt">connectionClosed</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xa" name="conn"/><a href="/source/s?refs=conn&amp;project=rtmp_client" class="xa">conn</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="state"/><a href="/source/s?refs=state&amp;project=rtmp_client" class="xa">state</a>) {
<a class="l" name="496" href="#496">496</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"connectionClosed"</span>);
<a class="l" name="497" href="#497">497</a>		<b>super</b>.<a class="d" href="#connectionClosed">connectionClosed</a>(<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>, <a href="/source/s?defs=state&amp;project=rtmp_client">state</a>);
<a class="l" name="498" href="#498">498</a>		<b>if</b> (<a href="/source/s?defs=connectionClosedHandler&amp;project=rtmp_client">connectionClosedHandler</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="499" href="#499">499</a>			<a href="/source/s?defs=connectionClosedHandler&amp;project=rtmp_client">connectionClosedHandler</a>.<a href="/source/s?defs=run&amp;project=rtmp_client">run</a>();
<a class="hl" name="500" href="#500">500</a>		}
<a class="l" name="501" href="#501">501</a>	}
<a class="l" name="502" href="#502">502</a>
<a class="l" name="503" href="#503">503</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="504" href="#504">504</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="505" href="#505">505</a>	<b>protected</b> <b>void</b> <a class="xmt" name="onInvoke"/><a href="/source/s?refs=onInvoke&amp;project=rtmp_client" class="xmt">onInvoke</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xa" name="conn"/><a href="/source/s?refs=conn&amp;project=rtmp_client" class="xa">conn</a>, <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a class="xa" name="channel"/><a href="/source/s?refs=channel&amp;project=rtmp_client" class="xa">channel</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a> <a class="xa" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xa">invoke</a>, <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="rtmp"/><a href="/source/s?refs=rtmp&amp;project=rtmp_client" class="xa">rtmp</a>) {
<a class="l" name="506" href="#506">506</a>		<b>if</b> (<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=getType&amp;project=rtmp_client">getType</a>() == <a href="/source/s?defs=IEvent&amp;project=rtmp_client">IEvent</a>.<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=STREAM_DATA&amp;project=rtmp_client">STREAM_DATA</a>) {
<a class="l" name="507" href="#507">507</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Ignoring stream data notify with header: {}"</span>, <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>);
<a class="l" name="508" href="#508">508</a>			<b>return</b>;
<a class="l" name="509" href="#509">509</a>		}
<a class="hl" name="510" href="#510">510</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"onInvoke: {}, invokeId: {}"</span>, <a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>, <a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=getInvokeId&amp;project=rtmp_client">getInvokeId</a>());
<a class="l" name="511" href="#511">511</a>		<b>final</b> <a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a> <a class="d" href="#call">call</a> = <a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=getCall&amp;project=rtmp_client">getCall</a>();
<a class="l" name="512" href="#512">512</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=methodName&amp;project=rtmp_client">methodName</a> = <a class="d" href="#call">call</a>.<a href="/source/s?defs=getServiceMethodName&amp;project=rtmp_client">getServiceMethodName</a>();
<a class="l" name="513" href="#513">513</a>		<b>if</b> (<span class="s">"_result"</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=methodName&amp;project=rtmp_client">methodName</a>) || <span class="s">"_error"</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=methodName&amp;project=rtmp_client">methodName</a>)) {
<a class="l" name="514" href="#514">514</a>			<b>final</b> <a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a> <a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a> = <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=getPendingCall&amp;project=rtmp_client">getPendingCall</a>(<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=getInvokeId&amp;project=rtmp_client">getInvokeId</a>());
<a class="l" name="515" href="#515">515</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Received result for pending call {}"</span>, <a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a>);
<a class="l" name="516" href="#516">516</a>			<b>if</b> (<a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="517" href="#517">517</a>				<b>if</b> (<span class="s">"connect"</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=pendingCall&amp;project=rtmp_client">pendingCall</a>.<a href="/source/s?defs=getServiceMethodName&amp;project=rtmp_client">getServiceMethodName</a>())) {
<a class="l" name="518" href="#518">518</a>					<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a> <a href="/source/s?defs=encoding&amp;project=rtmp_client">encoding</a> = (<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>) <a href="/source/s?defs=connectionParams&amp;project=rtmp_client">connectionParams</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<span class="s">"objectEncoding"</span>);
<a class="l" name="519" href="#519">519</a>					<b>if</b> (<a href="/source/s?defs=encoding&amp;project=rtmp_client">encoding</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a href="/source/s?defs=encoding&amp;project=rtmp_client">encoding</a>.<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>() == <span class="n">3</span>) {
<a class="hl" name="520" href="#520">520</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Setting encoding to AMF3"</span>);
<a class="l" name="521" href="#521">521</a>						<a class="d" href="#rtmp">rtmp</a>.<a href="/source/s?defs=setEncoding&amp;project=rtmp_client">setEncoding</a>(<a href="/source/s?defs=IConnection&amp;project=rtmp_client">IConnection</a>.<a href="/source/s?defs=Encoding&amp;project=rtmp_client">Encoding</a>.<a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>);
<a class="l" name="522" href="#522">522</a>					}
<a class="l" name="523" href="#523">523</a>				}
<a class="l" name="524" href="#524">524</a>			}
<a class="l" name="525" href="#525">525</a>			<a href="/source/s?defs=handlePendingCallResult&amp;project=rtmp_client">handlePendingCallResult</a>(<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>, <a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>);
<a class="l" name="526" href="#526">526</a>			<b>return</b>;
<a class="l" name="527" href="#527">527</a>		}
<a class="l" name="528" href="#528">528</a>
<a class="l" name="529" href="#529">529</a>		<span class="c">// potentially used twice so get the value once</span>
<a class="hl" name="530" href="#530">530</a>		<b>boolean</b> <a href="/source/s?defs=onStatus&amp;project=rtmp_client">onStatus</a> = <a class="d" href="#call">call</a>.<a href="/source/s?defs=getServiceMethodName&amp;project=rtmp_client">getServiceMethodName</a>().<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<span class="s">"onStatus"</span>);
<a class="l" name="531" href="#531">531</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"onStatus {}"</span>, <a href="/source/s?defs=onStatus&amp;project=rtmp_client">onStatus</a>);
<a class="l" name="532" href="#532">532</a>		<b>if</b> (<a href="/source/s?defs=onStatus&amp;project=rtmp_client">onStatus</a>) {
<a class="l" name="533" href="#533">533</a>			<span class="c">// XXX better to serialize ObjectMap to Status object</span>
<a class="l" name="534" href="#534">534</a>			<a href="/source/s?defs=ObjectMap&amp;project=rtmp_client">ObjectMap</a>&lt;?, ?&gt; <a href="/source/s?defs=objMap&amp;project=rtmp_client">objMap</a> = (<a href="/source/s?defs=ObjectMap&amp;project=rtmp_client">ObjectMap</a>&lt;?, ?&gt;) <a class="d" href="#call">call</a>.<a href="/source/s?defs=getArguments&amp;project=rtmp_client">getArguments</a>()[<span class="n">0</span>];
<a class="l" name="535" href="#535">535</a>			<span class="c">// should keep this as an Object to stay compatible with FMS3 etc</span>
<a class="l" name="536" href="#536">536</a>			<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=clientId&amp;project=rtmp_client">clientId</a> = <a href="/source/s?defs=objMap&amp;project=rtmp_client">objMap</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<span class="s">"clientid"</span>);
<a class="l" name="537" href="#537">537</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Client id at onStatus: {}"</span>, <a href="/source/s?defs=clientId&amp;project=rtmp_client">clientId</a>);
<a class="l" name="538" href="#538">538</a>			<b>if</b> (<a href="/source/s?defs=clientId&amp;project=rtmp_client">clientId</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="539" href="#539">539</a>				<a href="/source/s?defs=clientId&amp;project=rtmp_client">clientId</a> = <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>.<a href="/source/s?defs=getStreamId&amp;project=rtmp_client">getStreamId</a>();
<a class="hl" name="540" href="#540">540</a>			}
<a class="l" name="541" href="#541">541</a>
<a class="l" name="542" href="#542">542</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"<a href="/source/s?path=Client/">Client</a>/<a href="/source/s?path=Client/stream">stream</a> id: {}"</span>, <a href="/source/s?defs=clientId&amp;project=rtmp_client">clientId</a>);
<a class="l" name="543" href="#543">543</a>			<b>if</b> (<a href="/source/s?defs=clientId&amp;project=rtmp_client">clientId</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="544" href="#544">544</a>				<span class="c">// try lookup by client id first</span>
<a class="l" name="545" href="#545">545</a>				<a class="d" href="#NetStreamPrivateData">NetStreamPrivateData</a> <a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a> = <a class="d" href="#streamDataMap">streamDataMap</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=clientId&amp;project=rtmp_client">clientId</a>);
<a class="l" name="546" href="#546">546</a>				<span class="c">// if null try to supply the first one in the map</span>
<a class="l" name="547" href="#547">547</a>				<b>if</b> (<a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="548" href="#548">548</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Stream data map: {}"</span>, <a class="d" href="#streamDataMap">streamDataMap</a>);
<a class="l" name="549" href="#549">549</a>					<a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a> = <a class="d" href="#streamDataMap">streamDataMap</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<span class="n">1</span>);
<a class="hl" name="550" href="#550">550</a>				}
<a class="l" name="551" href="#551">551</a>				<b>if</b> (<a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="552" href="#552">552</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Stream data was null for client id: {}"</span>, <a href="/source/s?defs=clientId&amp;project=rtmp_client">clientId</a>);
<a class="l" name="553" href="#553">553</a>				}
<a class="l" name="554" href="#554">554</a>				<b>if</b> (<a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a>.<a href="/source/s?defs=handler&amp;project=rtmp_client">handler</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="555" href="#555">555</a>					<a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a>.<a href="/source/s?defs=handler&amp;project=rtmp_client">handler</a>.<a href="/source/s?defs=onStreamEvent&amp;project=rtmp_client">onStreamEvent</a>(<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>);
<a class="l" name="556" href="#556">556</a>				}
<a class="l" name="557" href="#557">557</a>			}
<a class="l" name="558" href="#558">558</a>		}
<a class="l" name="559" href="#559">559</a>
<a class="hl" name="560" href="#560">560</a>		<b>if</b> (<a href="/source/s?defs=serviceProvider&amp;project=rtmp_client">serviceProvider</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="561" href="#561">561</a>			<span class="c">// Client doesn't support calling methods on him</span>
<a class="l" name="562" href="#562">562</a>			<a class="d" href="#call">call</a>.<a href="/source/s?defs=setStatus&amp;project=rtmp_client">setStatus</a>(<a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>.<a href="/source/s?defs=STATUS_METHOD_NOT_FOUND&amp;project=rtmp_client">STATUS_METHOD_NOT_FOUND</a>);
<a class="l" name="563" href="#563">563</a>			<a class="d" href="#call">call</a>.<a href="/source/s?defs=setException&amp;project=rtmp_client">setException</a>(<b>new</b> <a href="/source/s?defs=MethodNotFoundException&amp;project=rtmp_client">MethodNotFoundException</a>(<a class="d" href="#call">call</a>.<a href="/source/s?defs=getServiceMethodName&amp;project=rtmp_client">getServiceMethodName</a>()));
<a class="l" name="564" href="#564">564</a>		} <b>else</b> {
<a class="l" name="565" href="#565">565</a>			<a class="d" href="#serviceInvoker">serviceInvoker</a>.<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>(<a class="d" href="#call">call</a>, <a href="/source/s?defs=serviceProvider&amp;project=rtmp_client">serviceProvider</a>);
<a class="l" name="566" href="#566">566</a>		}
<a class="l" name="567" href="#567">567</a>
<a class="l" name="568" href="#568">568</a>		<b>if</b> (<a class="d" href="#call">call</a> <b>instanceof</b> <a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a>) {
<a class="l" name="569" href="#569">569</a>			<a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a> <a href="/source/s?defs=psc&amp;project=rtmp_client">psc</a> = (<a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a>) <a class="d" href="#call">call</a>;
<a class="hl" name="570" href="#570">570</a>			<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=psc&amp;project=rtmp_client">psc</a>.<a href="/source/s?defs=getResult&amp;project=rtmp_client">getResult</a>();
<a class="l" name="571" href="#571">571</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Pending call result is: {}"</span>, <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>);
<a class="l" name="572" href="#572">572</a>			<b>if</b> (<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> <b>instanceof</b> <a href="/source/s?defs=DeferredResult&amp;project=rtmp_client">DeferredResult</a>) {
<a class="l" name="573" href="#573">573</a>				<a href="/source/s?defs=DeferredResult&amp;project=rtmp_client">DeferredResult</a> <a href="/source/s?defs=dr&amp;project=rtmp_client">dr</a> = (<a href="/source/s?defs=DeferredResult&amp;project=rtmp_client">DeferredResult</a>) <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="574" href="#574">574</a>				<a href="/source/s?defs=dr&amp;project=rtmp_client">dr</a>.<a href="/source/s?defs=setInvokeId&amp;project=rtmp_client">setInvokeId</a>(<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=getInvokeId&amp;project=rtmp_client">getInvokeId</a>());
<a class="l" name="575" href="#575">575</a>				<a href="/source/s?defs=dr&amp;project=rtmp_client">dr</a>.<a href="/source/s?defs=setServiceCall&amp;project=rtmp_client">setServiceCall</a>(<a href="/source/s?defs=psc&amp;project=rtmp_client">psc</a>);
<a class="l" name="576" href="#576">576</a>				<a href="/source/s?defs=dr&amp;project=rtmp_client">dr</a>.<a href="/source/s?defs=setChannel&amp;project=rtmp_client">setChannel</a>(<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>);
<a class="l" name="577" href="#577">577</a>				<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=registerDeferredResult&amp;project=rtmp_client">registerDeferredResult</a>(<a href="/source/s?defs=dr&amp;project=rtmp_client">dr</a>);
<a class="l" name="578" href="#578">578</a>			} <b>else</b> <b>if</b> (!<a href="/source/s?defs=onStatus&amp;project=rtmp_client">onStatus</a>) {
<a class="l" name="579" href="#579">579</a>				<a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a> <a href="/source/s?defs=reply&amp;project=rtmp_client">reply</a> = <b>new</b> <a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>();
<a class="hl" name="580" href="#580">580</a>				<a href="/source/s?defs=reply&amp;project=rtmp_client">reply</a>.<a href="/source/s?defs=setCall&amp;project=rtmp_client">setCall</a>(<a class="d" href="#call">call</a>);
<a class="l" name="581" href="#581">581</a>				<a href="/source/s?defs=reply&amp;project=rtmp_client">reply</a>.<a href="/source/s?defs=setInvokeId&amp;project=rtmp_client">setInvokeId</a>(<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=getInvokeId&amp;project=rtmp_client">getInvokeId</a>());
<a class="l" name="582" href="#582">582</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Sending empty call reply: {}"</span>, <a href="/source/s?defs=reply&amp;project=rtmp_client">reply</a>);
<a class="l" name="583" href="#583">583</a>				<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=reply&amp;project=rtmp_client">reply</a>);
<a class="l" name="584" href="#584">584</a>			}
<a class="l" name="585" href="#585">585</a>		}
<a class="l" name="586" href="#586">586</a>	}
<a class="l" name="587" href="#587">587</a>
<a class="l" name="588" href="#588">588</a>	<span class="c">/**
<a class="l" name="589" href="#589">589</a>	 * Setter for codec factory
<a class="hl" name="590" href="#590">590</a>	 *
<a class="l" name="591" href="#591">591</a>	 * <strong>@param</strong> <em>factory</em> Codec factory to use
<a class="l" name="592" href="#592">592</a>	 */</span>
<a class="l" name="593" href="#593">593</a>	<b>public</b> <b>void</b> <a class="xmt" name="setCodecFactory"/><a href="/source/s?refs=setCodecFactory&amp;project=rtmp_client" class="xmt">setCodecFactory</a>(<a href="/source/s?defs=RTMPCodecFactory&amp;project=rtmp_client">RTMPCodecFactory</a> <a class="xa" name="factory"/><a href="/source/s?refs=factory&amp;project=rtmp_client" class="xa">factory</a>) {
<a class="l" name="594" href="#594">594</a>		<b>this</b>.<a class="d" href="#codecFactory">codecFactory</a> = <a class="d" href="#factory">factory</a>;
<a class="l" name="595" href="#595">595</a>	}
<a class="l" name="596" href="#596">596</a>
<a class="l" name="597" href="#597">597</a>	<span class="c">/**
<a class="l" name="598" href="#598">598</a>	 * Getter for codec factory
<a class="l" name="599" href="#599">599</a>	 *
<a class="hl" name="600" href="#600">600</a>	 * <strong>@return</strong> Codec factory
<a class="l" name="601" href="#601">601</a>	 */</span>
<a class="l" name="602" href="#602">602</a>	<b>public</b> <a href="/source/s?defs=RTMPCodecFactory&amp;project=rtmp_client">RTMPCodecFactory</a> <a class="xmt" name="getCodecFactory"/><a href="/source/s?refs=getCodecFactory&amp;project=rtmp_client" class="xmt">getCodecFactory</a>() {
<a class="l" name="603" href="#603">603</a>		<b>return</b> <b>this</b>.<a class="d" href="#codecFactory">codecFactory</a>;
<a class="l" name="604" href="#604">604</a>	}
<a class="l" name="605" href="#605">605</a>
<a class="l" name="606" href="#606">606</a>	<b>public</b> <b>void</b> <a class="xmt" name="handleException"/><a href="/source/s?refs=handleException&amp;project=rtmp_client" class="xmt">handleException</a>(<a href="/source/s?defs=Throwable&amp;project=rtmp_client">Throwable</a> <a class="xa" name="throwable"/><a href="/source/s?refs=throwable&amp;project=rtmp_client" class="xa">throwable</a>) {
<a class="l" name="607" href="#607">607</a>		<b>if</b> (<a href="/source/s?defs=exceptionHandler&amp;project=rtmp_client">exceptionHandler</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="608" href="#608">608</a>			<a href="/source/s?defs=exceptionHandler&amp;project=rtmp_client">exceptionHandler</a>.<a class="d" href="#handleException">handleException</a>(<a class="d" href="#throwable">throwable</a>);
<a class="l" name="609" href="#609">609</a>		} <b>else</b> {
<a class="hl" name="610" href="#610">610</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Connection exception"</span>, <a class="d" href="#throwable">throwable</a>);
<a class="l" name="611" href="#611">611</a>			<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<a class="d" href="#throwable">throwable</a>);
<a class="l" name="612" href="#612">612</a>		}
<a class="l" name="613" href="#613">613</a>	}
<a class="l" name="614" href="#614">614</a>
<a class="l" name="615" href="#615">615</a>	<span class="c">/**
<a class="l" name="616" href="#616">616</a>	 * Returns a channel based on the given stream id.
<a class="l" name="617" href="#617">617</a>	 *
<a class="l" name="618" href="#618">618</a>	 * <strong>@param</strong> <em>streamId</em>
<a class="l" name="619" href="#619">619</a>	 * <strong>@return</strong> the channel for this stream id
<a class="hl" name="620" href="#620">620</a>	 */</span>
<a class="l" name="621" href="#621">621</a>	<b>protected</b> <b>int</b> <a class="xmt" name="getChannelForStreamId"/><a href="/source/s?refs=getChannelForStreamId&amp;project=rtmp_client" class="xmt">getChannelForStreamId</a>(<b>int</b> <a class="xa" name="streamId"/><a href="/source/s?refs=streamId&amp;project=rtmp_client" class="xa">streamId</a>) {
<a class="l" name="622" href="#622">622</a>		<b>return</b> (<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a> - <span class="n">1</span>) * <span class="n">5</span> + <span class="n">4</span>;
<a class="l" name="623" href="#623">623</a>	}
<a class="l" name="624" href="#624">624</a>
<a class="l" name="625" href="#625">625</a>	<span class="c">/**
<a class="l" name="626" href="#626">626</a>	 * Sets a reference to the connection associated with this client handler.
<a class="l" name="627" href="#627">627</a>	 *
<a class="l" name="628" href="#628">628</a>	 * <strong>@param</strong> <em>conn</em>
<a class="l" name="629" href="#629">629</a>	 */</span>
<a class="hl" name="630" href="#630">630</a>	<b>public</b> <b>void</b> <a class="xmt" name="setConnection"/><a href="/source/s?refs=setConnection&amp;project=rtmp_client" class="xmt">setConnection</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xa" name="conn"/><a href="/source/s?refs=conn&amp;project=rtmp_client" class="xa">conn</a>) {
<a class="l" name="631" href="#631">631</a>		<b>this</b>.<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> = <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>;
<a class="l" name="632" href="#632">632</a>	}
<a class="l" name="633" href="#633">633</a>
<a class="l" name="634" href="#634">634</a>	<span class="c">/**
<a class="l" name="635" href="#635">635</a>	 * Returns the connection associated with this client.
<a class="l" name="636" href="#636">636</a>	 *
<a class="l" name="637" href="#637">637</a>	 * <strong>@return</strong> conn
<a class="l" name="638" href="#638">638</a>	 */</span>
<a class="l" name="639" href="#639">639</a>	<b>public</b> <a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a class="xmt" name="getConnection"/><a href="/source/s?refs=getConnection&amp;project=rtmp_client" class="xmt">getConnection</a>() {
<a class="hl" name="640" href="#640">640</a>		<b>return</b> <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>;
<a class="l" name="641" href="#641">641</a>	}
<a class="l" name="642" href="#642">642</a>
<a class="l" name="643" href="#643">643</a>	<span class="c">/**
<a class="l" name="644" href="#644">644</a>	 * Setter for stream event dispatcher (useful for saving playing stream to
<a class="l" name="645" href="#645">645</a>	 * file)
<a class="l" name="646" href="#646">646</a>	 *
<a class="l" name="647" href="#647">647</a>	 * <strong>@param</strong> <em>streamEventDispatcher</em> event dispatcher
<a class="l" name="648" href="#648">648</a>	 */</span>
<a class="l" name="649" href="#649">649</a>	<b>public</b> <b>void</b> <a class="xmt" name="setStreamEventDispatcher"/><a href="/source/s?refs=setStreamEventDispatcher&amp;project=rtmp_client" class="xmt">setStreamEventDispatcher</a>(<a href="/source/s?defs=IEventDispatcher&amp;project=rtmp_client">IEventDispatcher</a> <a class="xa" name="streamEventDispatcher"/><a href="/source/s?refs=streamEventDispatcher&amp;project=rtmp_client" class="xa">streamEventDispatcher</a>) {
<a class="hl" name="650" href="#650">650</a>		<b>this</b>.<a href="/source/s?defs=streamEventDispatcher&amp;project=rtmp_client">streamEventDispatcher</a> = <a href="/source/s?defs=streamEventDispatcher&amp;project=rtmp_client">streamEventDispatcher</a>;
<a class="l" name="651" href="#651">651</a>	}
<a class="l" name="652" href="#652">652</a>
<a class="l" name="653" href="#653">653</a>	<b>private</b> <b>static</b> <b>class</b> <a class="xc" name="NetStream"/><a href="/source/s?refs=NetStream&amp;project=rtmp_client" class="xc">NetStream</a> <b>extends</b> <a href="/source/s?defs=AbstractClientStream&amp;project=rtmp_client">AbstractClientStream</a> <b>implements</b> <a href="/source/s?defs=IEventDispatcher&amp;project=rtmp_client">IEventDispatcher</a> {
<a class="l" name="654" href="#654">654</a>		<b>private</b> <a href="/source/s?defs=IEventDispatcher&amp;project=rtmp_client">IEventDispatcher</a> <a class="xfld" name="dispatcher"/><a href="/source/s?refs=dispatcher&amp;project=rtmp_client" class="xfld">dispatcher</a>;
<a class="l" name="655" href="#655">655</a>
<a class="l" name="656" href="#656">656</a>		<b>public</b> <a class="xmt" name="NetStream"/><a href="/source/s?refs=NetStream&amp;project=rtmp_client" class="xmt">NetStream</a>(<a href="/source/s?defs=IEventDispatcher&amp;project=rtmp_client">IEventDispatcher</a> <a class="xa" name="dispatcher"/><a href="/source/s?refs=dispatcher&amp;project=rtmp_client" class="xa">dispatcher</a>) {
<a class="l" name="657" href="#657">657</a>			<b>this</b>.<a href="/source/s?defs=dispatcher&amp;project=rtmp_client">dispatcher</a> = <a href="/source/s?defs=dispatcher&amp;project=rtmp_client">dispatcher</a>;
<a class="l" name="658" href="#658">658</a>		}
<a class="l" name="659" href="#659">659</a>
<a class="hl" name="660" href="#660">660</a>		<b>public</b> <b>void</b> <a class="xmt" name="close"/><a href="/source/s?refs=close&amp;project=rtmp_client" class="xmt">close</a>() {
<a class="l" name="661" href="#661">661</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"NetStream close"</span>);
<a class="l" name="662" href="#662">662</a>		}
<a class="l" name="663" href="#663">663</a>
<a class="l" name="664" href="#664">664</a>		<b>public</b> <b>void</b> <a class="xmt" name="start"/><a href="/source/s?refs=start&amp;project=rtmp_client" class="xmt">start</a>() {
<a class="l" name="665" href="#665">665</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"NetStream start"</span>);
<a class="l" name="666" href="#666">666</a>		}
<a class="l" name="667" href="#667">667</a>
<a class="l" name="668" href="#668">668</a>		<b>public</b> <b>void</b> <a class="xmt" name="stop"/><a href="/source/s?refs=stop&amp;project=rtmp_client" class="xmt">stop</a>() {
<a class="l" name="669" href="#669">669</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"NetStream stop"</span>);
<a class="hl" name="670" href="#670">670</a>		}
<a class="l" name="671" href="#671">671</a>
<a class="l" name="672" href="#672">672</a>		<b>public</b> <b>void</b> <a class="xmt" name="dispatchEvent"/><a href="/source/s?refs=dispatchEvent&amp;project=rtmp_client" class="xmt">dispatchEvent</a>(<a href="/source/s?defs=IEvent&amp;project=rtmp_client">IEvent</a> <a class="xa" name="event"/><a href="/source/s?refs=event&amp;project=rtmp_client" class="xa">event</a>) {
<a class="l" name="673" href="#673">673</a><span class="c">//			log.debug("NetStream dispatchEvent: {}", event);</span>
<a class="l" name="674" href="#674">674</a>			<b>if</b> (<a href="/source/s?defs=dispatcher&amp;project=rtmp_client">dispatcher</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="675" href="#675">675</a>				<a href="/source/s?defs=dispatcher&amp;project=rtmp_client">dispatcher</a>.<a class="d" href="#dispatchEvent">dispatchEvent</a>(<a class="d" href="#event">event</a>);
<a class="l" name="676" href="#676">676</a>			}
<a class="l" name="677" href="#677">677</a>		}
<a class="l" name="678" href="#678">678</a>	}
<a class="l" name="679" href="#679">679</a>
<a class="hl" name="680" href="#680">680</a>	<b>private</b> <b>class</b> <a class="xc" name="CreateStreamCallBack"/><a href="/source/s?refs=CreateStreamCallBack&amp;project=rtmp_client" class="xc">CreateStreamCallBack</a> <b>implements</b> <a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> {
<a class="l" name="681" href="#681">681</a>		<b>private</b> <a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> <a class="xfld" name="wrapped"/><a href="/source/s?refs=wrapped&amp;project=rtmp_client" class="xfld">wrapped</a>;
<a class="l" name="682" href="#682">682</a>
<a class="l" name="683" href="#683">683</a>		<b>public</b> <a class="xmt" name="CreateStreamCallBack"/><a href="/source/s?refs=CreateStreamCallBack&amp;project=rtmp_client" class="xmt">CreateStreamCallBack</a>(<a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> <a class="xa" name="wrapped"/><a href="/source/s?refs=wrapped&amp;project=rtmp_client" class="xa">wrapped</a>) {
<a class="l" name="684" href="#684">684</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"CreateStreamCallBack {}"</span>, <a href="/source/s?defs=wrapped&amp;project=rtmp_client">wrapped</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>().<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>());
<a class="l" name="685" href="#685">685</a>			<b>this</b>.<a href="/source/s?defs=wrapped&amp;project=rtmp_client">wrapped</a> = <a href="/source/s?defs=wrapped&amp;project=rtmp_client">wrapped</a>;
<a class="l" name="686" href="#686">686</a>		}
<a class="l" name="687" href="#687">687</a>
<a class="l" name="688" href="#688">688</a>		<b>public</b> <b>void</b> <a class="xmt" name="resultReceived"/><a href="/source/s?refs=resultReceived&amp;project=rtmp_client" class="xmt">resultReceived</a>(<a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a> <a class="xa" name="call"/><a href="/source/s?refs=call&amp;project=rtmp_client" class="xa">call</a>) {
<a class="l" name="689" href="#689">689</a>			<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a> <a href="/source/s?defs=streamIdInt&amp;project=rtmp_client">streamIdInt</a> = (<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>) <a class="d" href="#call">call</a>.<a href="/source/s?defs=getResult&amp;project=rtmp_client">getResult</a>();
<a class="hl" name="690" href="#690">690</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Stream id: {}"</span>, <a href="/source/s?defs=streamIdInt&amp;project=rtmp_client">streamIdInt</a>);
<a class="l" name="691" href="#691">691</a>			<span class="c">//RTMPConnection conn = RTMPClientConnManager.getInstance().getConnection(clientId);</span>
<a class="l" name="692" href="#692">692</a><span class="c">//			log.debug("Connection: {}", conn);</span>
<a class="l" name="693" href="#693">693</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"CreateStreamCallBack resultReceived - stream id: {}"</span>, <a href="/source/s?defs=streamIdInt&amp;project=rtmp_client">streamIdInt</a>);
<a class="l" name="694" href="#694">694</a>			<b>if</b> (<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a href="/source/s?defs=streamIdInt&amp;project=rtmp_client">streamIdInt</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="695" href="#695">695</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Setting new net stream"</span>);
<a class="l" name="696" href="#696">696</a>				<a href="/source/s?defs=NetStream&amp;project=rtmp_client">NetStream</a> <a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a> = <b>new</b> <a href="/source/s?defs=NetStream&amp;project=rtmp_client">NetStream</a>(<a href="/source/s?defs=streamEventDispatcher&amp;project=rtmp_client">streamEventDispatcher</a>);
<a class="l" name="697" href="#697">697</a>				<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a class="d" href="#setConnection">setConnection</a>(<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>);
<a class="l" name="698" href="#698">698</a>				<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=setStreamId&amp;project=rtmp_client">setStreamId</a>(<a href="/source/s?defs=streamIdInt&amp;project=rtmp_client">streamIdInt</a>);
<a class="l" name="699" href="#699">699</a>				<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=addClientStream&amp;project=rtmp_client">addClientStream</a>(<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>);
<a class="hl" name="700" href="#700">700</a>				<a class="d" href="#NetStreamPrivateData">NetStreamPrivateData</a> <a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a> = <b>new</b> <a class="d" href="#NetStreamPrivateData">NetStreamPrivateData</a>();
<a class="l" name="701" href="#701">701</a>				<a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a>.<a class="d" href="#outputStream">outputStream</a> = <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=createOutputStream&amp;project=rtmp_client">createOutputStream</a>(<a href="/source/s?defs=streamIdInt&amp;project=rtmp_client">streamIdInt</a>);
<a class="l" name="702" href="#702">702</a>				<a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a>.<a class="d" href="#connConsumer">connConsumer</a> = <b>new</b> <a href="/source/s?defs=ConnectionConsumer&amp;project=rtmp_client">ConnectionConsumer</a>(<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>, <a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a>.<a class="d" href="#outputStream">outputStream</a>.<a href="/source/s?defs=getVideo&amp;project=rtmp_client">getVideo</a>().<a href="/source/s?defs=getId&amp;project=rtmp_client">getId</a>(), <a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a>.<a class="d" href="#outputStream">outputStream</a>.<a href="/source/s?defs=getAudio&amp;project=rtmp_client">getAudio</a>().<a href="/source/s?defs=getId&amp;project=rtmp_client">getId</a>(),
<a class="l" name="703" href="#703">703</a>						<a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a>.<a class="d" href="#outputStream">outputStream</a>.<a href="/source/s?defs=getData&amp;project=rtmp_client">getData</a>().<a href="/source/s?defs=getId&amp;project=rtmp_client">getId</a>());
<a class="l" name="704" href="#704">704</a>				<a class="d" href="#streamDataMap">streamDataMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=streamIdInt&amp;project=rtmp_client">streamIdInt</a>, <a href="/source/s?defs=streamData&amp;project=rtmp_client">streamData</a>);
<a class="l" name="705" href="#705">705</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"streamDataMap: {}"</span>, <a class="d" href="#streamDataMap">streamDataMap</a>);
<a class="l" name="706" href="#706">706</a>			}
<a class="l" name="707" href="#707">707</a>			<a href="/source/s?defs=wrapped&amp;project=rtmp_client">wrapped</a>.<a class="d" href="#resultReceived">resultReceived</a>(<a class="d" href="#call">call</a>);
<a class="l" name="708" href="#708">708</a>		}
<a class="l" name="709" href="#709">709</a>	}
<a class="hl" name="710" href="#710">710</a>
<a class="l" name="711" href="#711">711</a>	<b>private</b> <b>static</b> <b>class</b> <a class="xc" name="NetStreamPrivateData"/><a href="/source/s?refs=NetStreamPrivateData&amp;project=rtmp_client" class="xc">NetStreamPrivateData</a> {
<a class="l" name="712" href="#712">712</a>		<b>public</b> <b>volatile</b> <a href="/source/s?defs=INetStreamEventHandler&amp;project=rtmp_client">INetStreamEventHandler</a> <a class="xfld" name="handler"/><a href="/source/s?refs=handler&amp;project=rtmp_client" class="xfld">handler</a>;
<a class="l" name="713" href="#713">713</a>
<a class="l" name="714" href="#714">714</a>		<b>public</b> <b>volatile</b> <a href="/source/s?defs=OutputStream&amp;project=rtmp_client">OutputStream</a> <a class="xfld" name="outputStream"/><a href="/source/s?refs=outputStream&amp;project=rtmp_client" class="xfld">outputStream</a>;
<a class="l" name="715" href="#715">715</a>
<a class="l" name="716" href="#716">716</a>		<b>public</b> <b>volatile</b> <a href="/source/s?defs=ConnectionConsumer&amp;project=rtmp_client">ConnectionConsumer</a> <a class="xfld" name="connConsumer"/><a href="/source/s?refs=connConsumer&amp;project=rtmp_client" class="xfld">connConsumer</a>;
<a class="l" name="717" href="#717">717</a>	}
<a class="l" name="718" href="#718">718</a>}
<a class="l" name="719" href="#719">719</a>