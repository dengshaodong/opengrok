<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.red5.server.net.rtmp.message",1]]],["Enum","xe",[["CLOSE_STREAM",12],["CONNECT",12],["CREATE_STREAM",12],["CUSTOM",15],["DELETE_STREAM",12],["DISCONNECT",12],["INIT_STREAM",13],["PAUSE",13],["PAUSE_RAW",14],["PLAY",14],["PLAY2",14],["PUBLISH",13],["RECEIVE_AUDIO",15],["RECEIVE_VIDEO",14],["RELEASE_STREAM",13],["SEEK",14],["STOP",14],["StreamAction",11]]],["Method","xmt",[["StreamAction",23],["equals",48],["equals",52],["getActionString",27],["getEnum",31],["toString",56]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>;
<a class="l" name="4" href="#4">4</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a><span class="c">/**
<a class="l" name="7" href="#7">7</a> * Represents all the actions which may be permitted on a stream.
<a class="l" name="8" href="#8">8</a> *
<a class="l" name="9" href="#9">9</a> * <strong>@author</strong> Paul Gregoire
<a class="hl" name="10" href="#10">10</a> */</span>
<a class="l" name="11" href="#11">11</a><b>public</b> <b>enum</b> <a class="xe" name="StreamAction"/><a href="/source/s?refs=StreamAction&amp;project=rtmp_client" class="xe">StreamAction</a> {
<a class="l" name="12" href="#12">12</a>	<a class="xe" name="CONNECT"/><a href="/source/s?refs=CONNECT&amp;project=rtmp_client" class="xe">CONNECT</a>(<span class="s">"connect"</span>), <a class="xe" name="DISCONNECT"/><a href="/source/s?refs=DISCONNECT&amp;project=rtmp_client" class="xe">DISCONNECT</a>(<span class="s">"disconnect"</span>), <a class="xe" name="CREATE_STREAM"/><a href="/source/s?refs=CREATE_STREAM&amp;project=rtmp_client" class="xe">CREATE_STREAM</a>(<span class="s">"createStream"</span>), <a class="xe" name="DELETE_STREAM"/><a href="/source/s?refs=DELETE_STREAM&amp;project=rtmp_client" class="xe">DELETE_STREAM</a>(<span class="s">"deleteStream"</span>), <a class="xe" name="CLOSE_STREAM"/><a href="/source/s?refs=CLOSE_STREAM&amp;project=rtmp_client" class="xe">CLOSE_STREAM</a>(
<a class="l" name="13" href="#13">13</a>			<span class="s">"closeStream"</span>), <a class="xe" name="INIT_STREAM"/><a href="/source/s?refs=INIT_STREAM&amp;project=rtmp_client" class="xe">INIT_STREAM</a>(<span class="s">"initStream"</span>), <a class="xe" name="RELEASE_STREAM"/><a href="/source/s?refs=RELEASE_STREAM&amp;project=rtmp_client" class="xe">RELEASE_STREAM</a>(<span class="s">"releaseStream"</span>), <a class="xe" name="PUBLISH"/><a href="/source/s?refs=PUBLISH&amp;project=rtmp_client" class="xe">PUBLISH</a>(<span class="s">"publish"</span>), <a class="xe" name="PAUSE"/><a href="/source/s?refs=PAUSE&amp;project=rtmp_client" class="xe">PAUSE</a>(
<a class="l" name="14" href="#14">14</a>			<span class="s">"pause"</span>), <a class="xe" name="PAUSE_RAW"/><a href="/source/s?refs=PAUSE_RAW&amp;project=rtmp_client" class="xe">PAUSE_RAW</a>(<span class="s">"pauseRaw"</span>), <a class="xe" name="SEEK"/><a href="/source/s?refs=SEEK&amp;project=rtmp_client" class="xe">SEEK</a>(<span class="s">"seek"</span>), <a class="xe" name="PLAY"/><a href="/source/s?refs=PLAY&amp;project=rtmp_client" class="xe">PLAY</a>(<span class="s">"play"</span>), <a class="xe" name="PLAY2"/><a href="/source/s?refs=PLAY2&amp;project=rtmp_client" class="xe">PLAY2</a>(<span class="s">"play2"</span>), <a class="xe" name="STOP"/><a href="/source/s?refs=STOP&amp;project=rtmp_client" class="xe">STOP</a>(<span class="s">"disconnect"</span>), <a class="xe" name="RECEIVE_VIDEO"/><a href="/source/s?refs=RECEIVE_VIDEO&amp;project=rtmp_client" class="xe">RECEIVE_VIDEO</a>(
<a class="l" name="15" href="#15">15</a>			<span class="s">"receiveVideo"</span>), <a class="xe" name="RECEIVE_AUDIO"/><a href="/source/s?refs=RECEIVE_AUDIO&amp;project=rtmp_client" class="xe">RECEIVE_AUDIO</a>(<span class="s">"receiveAudio"</span>), <a class="xe" name="CUSTOM"/><a href="/source/s?refs=CUSTOM&amp;project=rtmp_client" class="xe">CUSTOM</a>(<span class="s">""</span>);
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a>	<span class="c">//presize to fit all enums in</span>
<a class="l" name="18" href="#18">18</a>	<b>private</b> <b>final</b> <b>static</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=StreamAction&amp;project=rtmp_client">StreamAction</a>&gt; <a class="xfld" name="map"/><a href="/source/s?refs=map&amp;project=rtmp_client" class="xfld">map</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=StreamAction&amp;project=rtmp_client">StreamAction</a>&gt;(<a href="/source/s?defs=StreamAction&amp;project=rtmp_client">StreamAction</a>.<a href="/source/s?defs=values&amp;project=rtmp_client">values</a>().<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>);
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a>	<span class="c">//the stream action this enum is for</span>
<a class="l" name="21" href="#21">21</a>	<b>private</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="actionString"/><a href="/source/s?refs=actionString&amp;project=rtmp_client" class="xfld">actionString</a>;
<a class="l" name="22" href="#22">22</a>
<a class="l" name="23" href="#23">23</a>	<a class="xmt" name="StreamAction"/><a href="/source/s?refs=StreamAction&amp;project=rtmp_client" class="xmt">StreamAction</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="actionString"/><a href="/source/s?refs=actionString&amp;project=rtmp_client" class="xa">actionString</a>) {
<a class="l" name="24" href="#24">24</a>		<b>this</b>.<a href="/source/s?defs=actionString&amp;project=rtmp_client">actionString</a> = <a href="/source/s?defs=actionString&amp;project=rtmp_client">actionString</a>;
<a class="l" name="25" href="#25">25</a>	}
<a class="l" name="26" href="#26">26</a>
<a class="l" name="27" href="#27">27</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getActionString"/><a href="/source/s?refs=getActionString&amp;project=rtmp_client" class="xmt">getActionString</a>() {
<a class="l" name="28" href="#28">28</a>		<b>return</b> <a href="/source/s?defs=actionString&amp;project=rtmp_client">actionString</a>;
<a class="l" name="29" href="#29">29</a>	}
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=StreamAction&amp;project=rtmp_client">StreamAction</a> <a class="xmt" name="getEnum"/><a href="/source/s?refs=getEnum&amp;project=rtmp_client" class="xmt">getEnum</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="actionString"/><a href="/source/s?refs=actionString&amp;project=rtmp_client" class="xa">actionString</a>) {
<a class="l" name="32" href="#32">32</a>		<span class="c">//fill the map if its empty</span>
<a class="l" name="33" href="#33">33</a>		<b>if</b> (<a class="d" href="#map">map</a>.<a href="/source/s?defs=isEmpty&amp;project=rtmp_client">isEmpty</a>()) {
<a class="l" name="34" href="#34">34</a>			<span class="c">//do this only once</span>
<a class="l" name="35" href="#35">35</a>			<b>for</b> (<a href="/source/s?defs=StreamAction&amp;project=rtmp_client">StreamAction</a> <a class="d" href="#action">action</a> : <a href="/source/s?defs=values&amp;project=rtmp_client">values</a>()) {
<a class="l" name="36" href="#36">36</a>				<a class="d" href="#map">map</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#action">action</a>.<a class="d" href="#getActionString">getActionString</a>(), <a class="d" href="#action">action</a>);
<a class="l" name="37" href="#37">37</a>			}
<a class="l" name="38" href="#38">38</a>		}
<a class="l" name="39" href="#39">39</a>		<span class="c">//look up the action from the predefined set</span>
<a class="hl" name="40" href="#40">40</a>		<a href="/source/s?defs=StreamAction&amp;project=rtmp_client">StreamAction</a> <a href="/source/s?defs=match&amp;project=rtmp_client">match</a> = <a class="d" href="#map">map</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=actionString&amp;project=rtmp_client">actionString</a>);
<a class="l" name="41" href="#41">41</a>		<b>if</b> (<a href="/source/s?defs=match&amp;project=rtmp_client">match</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="42" href="#42">42</a>			<b>return</b> <a href="/source/s?defs=match&amp;project=rtmp_client">match</a>;
<a class="l" name="43" href="#43">43</a>		}
<a class="l" name="44" href="#44">44</a>		<span class="c">//return an action representing a custom type</span>
<a class="l" name="45" href="#45">45</a>		<b>return</b> <a class="d" href="#CUSTOM">CUSTOM</a>;
<a class="l" name="46" href="#46">46</a>	}
<a class="l" name="47" href="#47">47</a>
<a class="l" name="48" href="#48">48</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="equals"/><a href="/source/s?refs=equals&amp;project=rtmp_client" class="xmt">equals</a>(<a href="/source/s?defs=StreamAction&amp;project=rtmp_client">StreamAction</a> <a class="xa" name="action"/><a href="/source/s?refs=action&amp;project=rtmp_client" class="xa">action</a>) {
<a class="l" name="49" href="#49">49</a>		<b>return</b> <a class="d" href="#action">action</a>.<a class="d" href="#getActionString">getActionString</a>().<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=actionString&amp;project=rtmp_client">actionString</a>);
<a class="hl" name="50" href="#50">50</a>	}
<a class="l" name="51" href="#51">51</a>
<a class="l" name="52" href="#52">52</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="equals"/><a href="/source/s?refs=equals&amp;project=rtmp_client" class="xmt">equals</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="actionString"/><a href="/source/s?refs=actionString&amp;project=rtmp_client" class="xa">actionString</a>) {
<a class="l" name="53" href="#53">53</a>		<b>return</b> <a class="d" href="#getActionString">getActionString</a>().<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=actionString&amp;project=rtmp_client">actionString</a>);
<a class="l" name="54" href="#54">54</a>	}
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toString"/><a href="/source/s?refs=toString&amp;project=rtmp_client" class="xmt">toString</a>() {
<a class="l" name="57" href="#57">57</a>		<b>return</b> <a href="/source/s?defs=actionString&amp;project=rtmp_client">actionString</a>;
<a class="l" name="58" href="#58">58</a>	}
<a class="l" name="59" href="#59">59</a>
<a class="hl" name="60" href="#60">60</a>}
<a class="l" name="61" href="#61">61</a>