<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["LiveTimestampMapping",162],["RTMP",33]]],["Package","xp",[["org.red5.server.net.rtmp.codec",1]]],["Method","xmt",[["LiveTimestampMapping",171],["RTMP",228],["freePackets",287],["getClockStartTime",182],["getEncoding",465],["getLastFullTimestampWritten",482],["getLastReadChannel",411],["getLastReadHeader",330],["getLastReadPacket",375],["getLastReadPacketHeader",490],["getLastStreamTime",194],["getLastTimestampMapping",494],["getLastWriteChannel",420],["getLastWriteHeader",351],["getLastWritePacket",402],["getMode",237],["getReadChunkSize",429],["getState",278],["getStreamStartTime",178],["getWriteChunkSize",447],["isDebug",246],["isEncrypted",262],["isKeyFrameNeeded",190],["setDebug",255],["setEncoding",474],["setEncrypted",269],["setKeyFrameNeeded",186],["setLastFullTimestampWritten",478],["setLastReadHeader",319],["setLastReadPacket",361],["setLastReadPacketHeader",486],["setLastStreamTime",198],["setLastTimestampMapping",498],["setLastWriteHeader",340],["setLastWritePacket",385],["setReadChunkSize",438],["setState",302],["setWriteChunkSize",456],["toString",506]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=codec&amp;project=rtmp_client">codec</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=IConnection&amp;project=rtmp_client">IConnection</a>.<a href="/source/s?defs=Encoding&amp;project=rtmp_client">Encoding</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a>;
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a><span class="c">/**
<a class="l" name="31" href="#31">31</a> * RTMP is the RTMP protocol state representation.
<a class="l" name="32" href="#32">32</a> */</span>
<a class="l" name="33" href="#33">33</a><b>public</b> <b>class</b> <a class="xc" name="RTMP"/><a href="/source/s?refs=RTMP&amp;project=rtmp_client" class="xc">RTMP</a> <b>extends</b> <a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a> {
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>[] <a class="xfld" name="states"/><a href="/source/s?refs=states&amp;project=rtmp_client" class="xfld">states</a> = {<span class="s">"connect"</span>, <span class="s">"handshake"</span>, <span class="s">"connected"</span>, <span class="s">"error"</span>, <span class="s">"disconnecting"</span>, <span class="s">"disconnected"</span>};
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a>	<span class="c">/**
<a class="l" name="38" href="#38">38</a>	 * Connect state.
<a class="l" name="39" href="#39">39</a>	 */</span>
<a class="hl" name="40" href="#40">40</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="STATE_CONNECT"/><a href="/source/s?refs=STATE_CONNECT&amp;project=rtmp_client" class="xfld">STATE_CONNECT</a> = <span class="n">0x00</span>;
<a class="l" name="41" href="#41">41</a>
<a class="l" name="42" href="#42">42</a>	<span class="c">/**
<a class="l" name="43" href="#43">43</a>	 * Handshake state. Server sends handshake request to client right after connection established.
<a class="l" name="44" href="#44">44</a>	 */</span>
<a class="l" name="45" href="#45">45</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="STATE_HANDSHAKE"/><a href="/source/s?refs=STATE_HANDSHAKE&amp;project=rtmp_client" class="xfld">STATE_HANDSHAKE</a> = <span class="n">0x01</span>;
<a class="l" name="46" href="#46">46</a>
<a class="l" name="47" href="#47">47</a>	<span class="c">/**
<a class="l" name="48" href="#48">48</a>	 * Connected.
<a class="l" name="49" href="#49">49</a>	 */</span>
<a class="hl" name="50" href="#50">50</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="STATE_CONNECTED"/><a href="/source/s?refs=STATE_CONNECTED&amp;project=rtmp_client" class="xfld">STATE_CONNECTED</a> = <span class="n">0x02</span>;
<a class="l" name="51" href="#51">51</a>
<a class="l" name="52" href="#52">52</a>	<span class="c">/**
<a class="l" name="53" href="#53">53</a>	 * Error.
<a class="l" name="54" href="#54">54</a>	 */</span>
<a class="l" name="55" href="#55">55</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="STATE_ERROR"/><a href="/source/s?refs=STATE_ERROR&amp;project=rtmp_client" class="xfld">STATE_ERROR</a> = <span class="n">0x03</span>;
<a class="l" name="56" href="#56">56</a>
<a class="l" name="57" href="#57">57</a>	<span class="c">/**
<a class="l" name="58" href="#58">58</a>	 * In the processing of disconnecting
<a class="l" name="59" href="#59">59</a>	 */</span>
<a class="hl" name="60" href="#60">60</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="STATE_DISCONNECTING"/><a href="/source/s?refs=STATE_DISCONNECTING&amp;project=rtmp_client" class="xfld">STATE_DISCONNECTING</a> = <span class="n">0x04</span>;
<a class="l" name="61" href="#61">61</a>
<a class="l" name="62" href="#62">62</a>	<span class="c">/**
<a class="l" name="63" href="#63">63</a>	 * Disconnected.
<a class="l" name="64" href="#64">64</a>	 */</span>
<a class="l" name="65" href="#65">65</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="STATE_DISCONNECTED"/><a href="/source/s?refs=STATE_DISCONNECTED&amp;project=rtmp_client" class="xfld">STATE_DISCONNECTED</a> = <span class="n">0x05</span>;
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a>	<span class="c">/**
<a class="l" name="68" href="#68">68</a>	 * Sent the connect message to origin.
<a class="l" name="69" href="#69">69</a>	 */</span>
<a class="hl" name="70" href="#70">70</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="STATE_EDGE_CONNECT_ORIGIN_SENT"/><a href="/source/s?refs=STATE_EDGE_CONNECT_ORIGIN_SENT&amp;project=rtmp_client" class="xfld">STATE_EDGE_CONNECT_ORIGIN_SENT</a> = <span class="n">0x11</span>;
<a class="l" name="71" href="#71">71</a>
<a class="l" name="72" href="#72">72</a>	<span class="c">/**
<a class="l" name="73" href="#73">73</a>	 * Forwarded client's connect call to origin.
<a class="l" name="74" href="#74">74</a>	 */</span>
<a class="l" name="75" href="#75">75</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="STATE_ORIGIN_CONNECT_FORWARDED"/><a href="/source/s?refs=STATE_ORIGIN_CONNECT_FORWARDED&amp;project=rtmp_client" class="xfld">STATE_ORIGIN_CONNECT_FORWARDED</a> = <span class="n">0x12</span>;
<a class="l" name="76" href="#76">76</a>
<a class="l" name="77" href="#77">77</a>	<span class="c">/**
<a class="l" name="78" href="#78">78</a>	 * Edge is disconnecting, waiting Origin close connection.
<a class="l" name="79" href="#79">79</a>	 */</span>
<a class="hl" name="80" href="#80">80</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="STATE_EDGE_DISCONNECTING"/><a href="/source/s?refs=STATE_EDGE_DISCONNECTING&amp;project=rtmp_client" class="xfld">STATE_EDGE_DISCONNECTING</a> = <span class="n">0x13</span>;
<a class="l" name="81" href="#81">81</a>
<a class="l" name="82" href="#82">82</a>	<span class="c">/**
<a class="l" name="83" href="#83">83</a>	 * Client mode.
<a class="l" name="84" href="#84">84</a>	 */</span>
<a class="l" name="85" href="#85">85</a>	<b>public</b> <b>static</b> <b>final</b> <b>boolean</b> <a class="xfld" name="MODE_CLIENT"/><a href="/source/s?refs=MODE_CLIENT&amp;project=rtmp_client" class="xfld">MODE_CLIENT</a> = <b>true</b>;
<a class="l" name="86" href="#86">86</a>
<a class="l" name="87" href="#87">87</a>	<span class="c">/**
<a class="l" name="88" href="#88">88</a>	 * Server mode.
<a class="l" name="89" href="#89">89</a>	 */</span>
<a class="hl" name="90" href="#90">90</a>	<b>public</b> <b>static</b> <b>final</b> <b>boolean</b> <a class="xfld" name="MODE_SERVER"/><a href="/source/s?refs=MODE_SERVER&amp;project=rtmp_client" class="xfld">MODE_SERVER</a> = <b>false</b>;
<a class="l" name="91" href="#91">91</a>
<a class="l" name="92" href="#92">92</a>	<span class="c">/**
<a class="l" name="93" href="#93">93</a>	 * Default chunk size. Packets are read and written chunk-by-chunk.
<a class="l" name="94" href="#94">94</a>	 */</span>
<a class="l" name="95" href="#95">95</a>	<b>public</b> <b>static</b> <b>final</b> <b>int</b> <a class="xfld" name="DEFAULT_CHUNK_SIZE"/><a href="/source/s?refs=DEFAULT_CHUNK_SIZE&amp;project=rtmp_client" class="xfld">DEFAULT_CHUNK_SIZE</a> = <span class="n">128</span>;
<a class="l" name="96" href="#96">96</a>
<a class="l" name="97" href="#97">97</a>	<span class="c">/**
<a class="l" name="98" href="#98">98</a>	 * RTMP state.
<a class="l" name="99" href="#99">99</a>	 */</span>
<a class="hl" name="100" href="#100">100</a>	<b>private</b> <b>volatile</b> <b>byte</b> <a class="xfld" name="state"/><a href="/source/s?refs=state&amp;project=rtmp_client" class="xfld">state</a> = <a class="d" href="#STATE_CONNECT">STATE_CONNECT</a>;
<a class="l" name="101" href="#101">101</a>
<a class="l" name="102" href="#102">102</a>	<span class="c">/**
<a class="l" name="103" href="#103">103</a>	 * Server mode by default.
<a class="l" name="104" href="#104">104</a>	 */</span>
<a class="l" name="105" href="#105">105</a>	<b>private</b> <b>volatile</b> <b>boolean</b> <a class="xfld" name="mode"/><a href="/source/s?refs=mode&amp;project=rtmp_client" class="xfld">mode</a> = <a class="d" href="#MODE_SERVER">MODE_SERVER</a>;
<a class="l" name="106" href="#106">106</a>
<a class="l" name="107" href="#107">107</a>	<span class="c">/**
<a class="l" name="108" href="#108">108</a>	 * Debug flag.
<a class="l" name="109" href="#109">109</a>	 */</span>
<a class="hl" name="110" href="#110">110</a>	<b>private</b> <b>boolean</b> <a class="xfld" name="debug"/><a href="/source/s?refs=debug&amp;project=rtmp_client" class="xfld">debug</a>;
<a class="l" name="111" href="#111">111</a>
<a class="l" name="112" href="#112">112</a>	<span class="c">/**
<a class="l" name="113" href="#113">113</a>	 * Encryption flag.
<a class="l" name="114" href="#114">114</a>	 */</span>
<a class="l" name="115" href="#115">115</a>	<b>private</b> <b>boolean</b> <a class="xfld" name="encrypted"/><a href="/source/s?refs=encrypted&amp;project=rtmp_client" class="xfld">encrypted</a> = <b>false</b>;
<a class="l" name="116" href="#116">116</a>
<a class="l" name="117" href="#117">117</a>	<span class="c">/**
<a class="l" name="118" href="#118">118</a>	 * Last read channel.
<a class="l" name="119" href="#119">119</a>	 */</span>
<a class="hl" name="120" href="#120">120</a>	<b>private</b> <b>int</b> <a class="xfld" name="lastReadChannel"/><a href="/source/s?refs=lastReadChannel&amp;project=rtmp_client" class="xfld">lastReadChannel</a> = <span class="n">0x00</span>;
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>	<span class="c">/**
<a class="l" name="123" href="#123">123</a>	 * Last write channel.
<a class="l" name="124" href="#124">124</a>	 */</span>
<a class="l" name="125" href="#125">125</a>	<b>private</b> <b>int</b> <a class="xfld" name="lastWriteChannel"/><a href="/source/s?refs=lastWriteChannel&amp;project=rtmp_client" class="xfld">lastWriteChannel</a> = <span class="n">0x00</span>;
<a class="l" name="126" href="#126">126</a>
<a class="l" name="127" href="#127">127</a>	<span class="c">/**
<a class="l" name="128" href="#128">128</a>	 * Read headers, keyed by channel id.
<a class="l" name="129" href="#129">129</a>	 */</span>
<a class="hl" name="130" href="#130">130</a>	<b>private</b> <b>final</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a>&gt; <a class="xfld" name="readHeaders"/><a href="/source/s?refs=readHeaders&amp;project=rtmp_client" class="xfld">readHeaders</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a>&gt;();
<a class="l" name="131" href="#131">131</a>
<a class="l" name="132" href="#132">132</a>	<span class="c">/**
<a class="l" name="133" href="#133">133</a>	 * Write headers, keyed by channel id.
<a class="l" name="134" href="#134">134</a>	 */</span>
<a class="l" name="135" href="#135">135</a>	<b>private</b> <b>final</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a>&gt; <a class="xfld" name="writeHeaders"/><a href="/source/s?refs=writeHeaders&amp;project=rtmp_client" class="xfld">writeHeaders</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a>&gt;();
<a class="l" name="136" href="#136">136</a>
<a class="l" name="137" href="#137">137</a>	<span class="c">/**
<a class="l" name="138" href="#138">138</a>	 * Headers actually used for a packet, keyed by channel id.
<a class="l" name="139" href="#139">139</a>	 */</span>
<a class="hl" name="140" href="#140">140</a>	<b>private</b> <b>final</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a>&gt; <a class="xfld" name="readPacketHeaders"/><a href="/source/s?refs=readPacketHeaders&amp;project=rtmp_client" class="xfld">readPacketHeaders</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a>&gt;();
<a class="l" name="141" href="#141">141</a>
<a class="l" name="142" href="#142">142</a>	<span class="c">/**
<a class="l" name="143" href="#143">143</a>	 * Read packets, keyed by channel id.
<a class="l" name="144" href="#144">144</a>	 */</span>
<a class="l" name="145" href="#145">145</a>	<b>private</b> <b>final</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a>&gt; <a class="xfld" name="readPackets"/><a href="/source/s?refs=readPackets&amp;project=rtmp_client" class="xfld">readPackets</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a>&gt;();
<a class="l" name="146" href="#146">146</a>
<a class="l" name="147" href="#147">147</a>	<span class="c">/**
<a class="l" name="148" href="#148">148</a>	 * Written packets, keyed by channel id.
<a class="l" name="149" href="#149">149</a>	 */</span>
<a class="hl" name="150" href="#150">150</a>	<b>private</b> <b>final</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a>&gt; <a class="xfld" name="writePackets"/><a href="/source/s?refs=writePackets&amp;project=rtmp_client" class="xfld">writePackets</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a>&gt;();
<a class="l" name="151" href="#151">151</a>
<a class="l" name="152" href="#152">152</a>	<span class="c">/**
<a class="l" name="153" href="#153">153</a>	 * Written timestamps
<a class="l" name="154" href="#154">154</a>	 */</span>
<a class="l" name="155" href="#155">155</a>	<b>private</b> <b>final</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt; <a class="xfld" name="writeTimestamps"/><a href="/source/s?refs=writeTimestamps&amp;project=rtmp_client" class="xfld">writeTimestamps</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt;();
<a class="l" name="156" href="#156">156</a>
<a class="l" name="157" href="#157">157</a>	<span class="c">/**
<a class="l" name="158" href="#158">158</a>	 * Class for mapping between clock time and stream time for live streams
<a class="l" name="159" href="#159">159</a>	 * <strong>@author</strong> aclarke
<a class="hl" name="160" href="#160">160</a>	 *
<a class="l" name="161" href="#161">161</a>	 */</span>
<a class="l" name="162" href="#162">162</a>	<b>static</b> <b>class</b> <a class="xc" name="LiveTimestampMapping"/><a href="/source/s?refs=LiveTimestampMapping&amp;project=rtmp_client" class="xc">LiveTimestampMapping</a> {
<a class="l" name="163" href="#163">163</a>		<b>private</b> <b>final</b> <b>long</b> <a class="xfld" name="clockStartTime"/><a href="/source/s?refs=clockStartTime&amp;project=rtmp_client" class="xfld">clockStartTime</a>;
<a class="l" name="164" href="#164">164</a>
<a class="l" name="165" href="#165">165</a>		<b>private</b> <b>final</b> <b>long</b> <a class="xfld" name="streamStartTime"/><a href="/source/s?refs=streamStartTime&amp;project=rtmp_client" class="xfld">streamStartTime</a>;
<a class="l" name="166" href="#166">166</a>
<a class="l" name="167" href="#167">167</a>		<b>private</b> <b>boolean</b> <a class="xfld" name="keyFrameNeeded"/><a href="/source/s?refs=keyFrameNeeded&amp;project=rtmp_client" class="xfld">keyFrameNeeded</a>;
<a class="l" name="168" href="#168">168</a>
<a class="l" name="169" href="#169">169</a>		<b>private</b> <b>long</b> <a class="xfld" name="lastStreamTime"/><a href="/source/s?refs=lastStreamTime&amp;project=rtmp_client" class="xfld">lastStreamTime</a>;
<a class="hl" name="170" href="#170">170</a>
<a class="l" name="171" href="#171">171</a>		<b>public</b> <a class="xmt" name="LiveTimestampMapping"/><a href="/source/s?refs=LiveTimestampMapping&amp;project=rtmp_client" class="xmt">LiveTimestampMapping</a>(<b>long</b> <a class="xa" name="clockStartTime"/><a href="/source/s?refs=clockStartTime&amp;project=rtmp_client" class="xa">clockStartTime</a>, <b>long</b> <a class="xa" name="streamStartTime"/><a href="/source/s?refs=streamStartTime&amp;project=rtmp_client" class="xa">streamStartTime</a>) {
<a class="l" name="172" href="#172">172</a>			<b>this</b>.<a href="/source/s?defs=clockStartTime&amp;project=rtmp_client">clockStartTime</a> = <a href="/source/s?defs=clockStartTime&amp;project=rtmp_client">clockStartTime</a>;
<a class="l" name="173" href="#173">173</a>			<b>this</b>.<a href="/source/s?defs=streamStartTime&amp;project=rtmp_client">streamStartTime</a> = <a href="/source/s?defs=streamStartTime&amp;project=rtmp_client">streamStartTime</a>;
<a class="l" name="174" href="#174">174</a>			<b>this</b>.<a href="/source/s?defs=keyFrameNeeded&amp;project=rtmp_client">keyFrameNeeded</a> = <b>true</b>; <span class="c">// Always start with a key frame</span>
<a class="l" name="175" href="#175">175</a>			<b>this</b>.<a href="/source/s?defs=lastStreamTime&amp;project=rtmp_client">lastStreamTime</a> = <a href="/source/s?defs=streamStartTime&amp;project=rtmp_client">streamStartTime</a>;
<a class="l" name="176" href="#176">176</a>		}
<a class="l" name="177" href="#177">177</a>
<a class="l" name="178" href="#178">178</a>		<b>public</b> <b>long</b> <a class="xmt" name="getStreamStartTime"/><a href="/source/s?refs=getStreamStartTime&amp;project=rtmp_client" class="xmt">getStreamStartTime</a>() {
<a class="l" name="179" href="#179">179</a>			<b>return</b> <a href="/source/s?defs=streamStartTime&amp;project=rtmp_client">streamStartTime</a>;
<a class="hl" name="180" href="#180">180</a>		}
<a class="l" name="181" href="#181">181</a>
<a class="l" name="182" href="#182">182</a>		<b>public</b> <b>long</b> <a class="xmt" name="getClockStartTime"/><a href="/source/s?refs=getClockStartTime&amp;project=rtmp_client" class="xmt">getClockStartTime</a>() {
<a class="l" name="183" href="#183">183</a>			<b>return</b> <a href="/source/s?defs=clockStartTime&amp;project=rtmp_client">clockStartTime</a>;
<a class="l" name="184" href="#184">184</a>		}
<a class="l" name="185" href="#185">185</a>
<a class="l" name="186" href="#186">186</a>		<b>public</b> <b>void</b> <a class="xmt" name="setKeyFrameNeeded"/><a href="/source/s?refs=setKeyFrameNeeded&amp;project=rtmp_client" class="xmt">setKeyFrameNeeded</a>(<b>boolean</b> <a class="xa" name="keyFrameNeeded"/><a href="/source/s?refs=keyFrameNeeded&amp;project=rtmp_client" class="xa">keyFrameNeeded</a>) {
<a class="l" name="187" href="#187">187</a>			<b>this</b>.<a href="/source/s?defs=keyFrameNeeded&amp;project=rtmp_client">keyFrameNeeded</a> = <a href="/source/s?defs=keyFrameNeeded&amp;project=rtmp_client">keyFrameNeeded</a>;
<a class="l" name="188" href="#188">188</a>		}
<a class="l" name="189" href="#189">189</a>
<a class="hl" name="190" href="#190">190</a>		<b>public</b> <b>boolean</b> <a class="xmt" name="isKeyFrameNeeded"/><a href="/source/s?refs=isKeyFrameNeeded&amp;project=rtmp_client" class="xmt">isKeyFrameNeeded</a>() {
<a class="l" name="191" href="#191">191</a>			<b>return</b> <a href="/source/s?defs=keyFrameNeeded&amp;project=rtmp_client">keyFrameNeeded</a>;
<a class="l" name="192" href="#192">192</a>		}
<a class="l" name="193" href="#193">193</a>
<a class="l" name="194" href="#194">194</a>		<b>public</b> <b>long</b> <a class="xmt" name="getLastStreamTime"/><a href="/source/s?refs=getLastStreamTime&amp;project=rtmp_client" class="xmt">getLastStreamTime</a>() {
<a class="l" name="195" href="#195">195</a>			<b>return</b> <a href="/source/s?defs=lastStreamTime&amp;project=rtmp_client">lastStreamTime</a>;
<a class="l" name="196" href="#196">196</a>		}
<a class="l" name="197" href="#197">197</a>
<a class="l" name="198" href="#198">198</a>		<b>public</b> <b>void</b> <a class="xmt" name="setLastStreamTime"/><a href="/source/s?refs=setLastStreamTime&amp;project=rtmp_client" class="xmt">setLastStreamTime</a>(<b>long</b> <a class="xa" name="lastStreamTime"/><a href="/source/s?refs=lastStreamTime&amp;project=rtmp_client" class="xa">lastStreamTime</a>) {
<a class="l" name="199" href="#199">199</a>			<b>this</b>.<a href="/source/s?defs=lastStreamTime&amp;project=rtmp_client">lastStreamTime</a> = <a href="/source/s?defs=lastStreamTime&amp;project=rtmp_client">lastStreamTime</a>;
<a class="hl" name="200" href="#200">200</a>		}
<a class="l" name="201" href="#201">201</a>	}
<a class="l" name="202" href="#202">202</a>
<a class="l" name="203" href="#203">203</a>	<span class="c">/**
<a class="l" name="204" href="#204">204</a>	 * Mapping between channel and the last clock to stream mapping
<a class="l" name="205" href="#205">205</a>	 */</span>
<a class="l" name="206" href="#206">206</a>	<b>private</b> <b>final</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=LiveTimestampMapping&amp;project=rtmp_client">LiveTimestampMapping</a>&gt; <a class="xfld" name="liveTimestamps"/><a href="/source/s?refs=liveTimestamps&amp;project=rtmp_client" class="xfld">liveTimestamps</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=LiveTimestampMapping&amp;project=rtmp_client">LiveTimestampMapping</a>&gt;();
<a class="l" name="207" href="#207">207</a>
<a class="l" name="208" href="#208">208</a>	<span class="c">/**
<a class="l" name="209" href="#209">209</a>	 * Read chunk size. Packets are read and written chunk-by-chunk.
<a class="hl" name="210" href="#210">210</a>	 */</span>
<a class="l" name="211" href="#211">211</a>	<b>private</b> <b>int</b> <a class="xfld" name="readChunkSize"/><a href="/source/s?refs=readChunkSize&amp;project=rtmp_client" class="xfld">readChunkSize</a> = <a class="d" href="#DEFAULT_CHUNK_SIZE">DEFAULT_CHUNK_SIZE</a>;
<a class="l" name="212" href="#212">212</a>
<a class="l" name="213" href="#213">213</a>	<span class="c">/**
<a class="l" name="214" href="#214">214</a>	 * Write chunk size. Packets are read and written chunk-by-chunk.
<a class="l" name="215" href="#215">215</a>	 */</span>
<a class="l" name="216" href="#216">216</a>	<b>private</b> <b>int</b> <a class="xfld" name="writeChunkSize"/><a href="/source/s?refs=writeChunkSize&amp;project=rtmp_client" class="xfld">writeChunkSize</a> = <a class="d" href="#DEFAULT_CHUNK_SIZE">DEFAULT_CHUNK_SIZE</a>;
<a class="l" name="217" href="#217">217</a>
<a class="l" name="218" href="#218">218</a>	<span class="c">/**
<a class="l" name="219" href="#219">219</a>	 * Encoding type for objects.
<a class="hl" name="220" href="#220">220</a>	 */</span>
<a class="l" name="221" href="#221">221</a>	<b>private</b> <a href="/source/s?defs=Encoding&amp;project=rtmp_client">Encoding</a> <a class="xfld" name="encoding"/><a href="/source/s?refs=encoding&amp;project=rtmp_client" class="xfld">encoding</a> = <a href="/source/s?defs=Encoding&amp;project=rtmp_client">Encoding</a>.<a href="/source/s?defs=AMF0&amp;project=rtmp_client">AMF0</a>;
<a class="l" name="222" href="#222">222</a>
<a class="l" name="223" href="#223">223</a>	<span class="c">/**
<a class="l" name="224" href="#224">224</a>	 * Creates RTMP object with initial mode.
<a class="l" name="225" href="#225">225</a>	 *
<a class="l" name="226" href="#226">226</a>	 * <strong>@param</strong> <em>mode</em>            Initial mode
<a class="l" name="227" href="#227">227</a>	 */</span>
<a class="l" name="228" href="#228">228</a>	<b>public</b> <a class="xmt" name="RTMP"/><a href="/source/s?refs=RTMP&amp;project=rtmp_client" class="xmt">RTMP</a>(<b>boolean</b> <a class="xa" name="mode"/><a href="/source/s?refs=mode&amp;project=rtmp_client" class="xa">mode</a>) {
<a class="l" name="229" href="#229">229</a>		<b>this</b>.<a href="/source/s?defs=mode&amp;project=rtmp_client">mode</a> = <a href="/source/s?defs=mode&amp;project=rtmp_client">mode</a>;
<a class="hl" name="230" href="#230">230</a>	}
<a class="l" name="231" href="#231">231</a>
<a class="l" name="232" href="#232">232</a>	<span class="c">/**
<a class="l" name="233" href="#233">233</a>	 * Return current mode.
<a class="l" name="234" href="#234">234</a>	 *
<a class="l" name="235" href="#235">235</a>	 * <strong>@return</strong>  Current mode
<a class="l" name="236" href="#236">236</a>	 */</span>
<a class="l" name="237" href="#237">237</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="getMode"/><a href="/source/s?refs=getMode&amp;project=rtmp_client" class="xmt">getMode</a>() {
<a class="l" name="238" href="#238">238</a>		<b>return</b> <a href="/source/s?defs=mode&amp;project=rtmp_client">mode</a>;
<a class="l" name="239" href="#239">239</a>	}
<a class="hl" name="240" href="#240">240</a>
<a class="l" name="241" href="#241">241</a>	<span class="c">/**
<a class="l" name="242" href="#242">242</a>	 * Getter for debug.
<a class="l" name="243" href="#243">243</a>	 *
<a class="l" name="244" href="#244">244</a>	 * <strong>@return</strong>  Debug state
<a class="l" name="245" href="#245">245</a>	 */</span>
<a class="l" name="246" href="#246">246</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="isDebug"/><a href="/source/s?refs=isDebug&amp;project=rtmp_client" class="xmt">isDebug</a>() {
<a class="l" name="247" href="#247">247</a>		<b>return</b> <a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>;
<a class="l" name="248" href="#248">248</a>	}
<a class="l" name="249" href="#249">249</a>
<a class="hl" name="250" href="#250">250</a>	<span class="c">/**
<a class="l" name="251" href="#251">251</a>	 * Setter for debug.
<a class="l" name="252" href="#252">252</a>	 *
<a class="l" name="253" href="#253">253</a>	 * <strong>@param</strong> <em>debug</em>  Debug flag new value
<a class="l" name="254" href="#254">254</a>	 */</span>
<a class="l" name="255" href="#255">255</a>	<b>public</b> <b>void</b> <a class="xmt" name="setDebug"/><a href="/source/s?refs=setDebug&amp;project=rtmp_client" class="xmt">setDebug</a>(<b>boolean</b> <a class="xa" name="debug"/><a href="/source/s?refs=debug&amp;project=rtmp_client" class="xa">debug</a>) {
<a class="l" name="256" href="#256">256</a>		<b>this</b>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a> = <a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>;
<a class="l" name="257" href="#257">257</a>	}
<a class="l" name="258" href="#258">258</a>
<a class="l" name="259" href="#259">259</a>	<span class="c">/**
<a class="hl" name="260" href="#260">260</a>	 * <strong>@return</strong> the encrypted
<a class="l" name="261" href="#261">261</a>	 */</span>
<a class="l" name="262" href="#262">262</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="isEncrypted"/><a href="/source/s?refs=isEncrypted&amp;project=rtmp_client" class="xmt">isEncrypted</a>() {
<a class="l" name="263" href="#263">263</a>		<b>return</b> <a href="/source/s?defs=encrypted&amp;project=rtmp_client">encrypted</a>;
<a class="l" name="264" href="#264">264</a>	}
<a class="l" name="265" href="#265">265</a>
<a class="l" name="266" href="#266">266</a>	<span class="c">/**
<a class="l" name="267" href="#267">267</a>	 * <strong>@param</strong> <em>encrypted</em> the encrypted to set
<a class="l" name="268" href="#268">268</a>	 */</span>
<a class="l" name="269" href="#269">269</a>	<b>public</b> <b>void</b> <a class="xmt" name="setEncrypted"/><a href="/source/s?refs=setEncrypted&amp;project=rtmp_client" class="xmt">setEncrypted</a>(<b>boolean</b> <a class="xa" name="encrypted"/><a href="/source/s?refs=encrypted&amp;project=rtmp_client" class="xa">encrypted</a>) {
<a class="hl" name="270" href="#270">270</a>		<b>this</b>.<a href="/source/s?defs=encrypted&amp;project=rtmp_client">encrypted</a> = <a href="/source/s?defs=encrypted&amp;project=rtmp_client">encrypted</a>;
<a class="l" name="271" href="#271">271</a>	}
<a class="l" name="272" href="#272">272</a>
<a class="l" name="273" href="#273">273</a>	<span class="c">/**
<a class="l" name="274" href="#274">274</a>	 * Return current state.
<a class="l" name="275" href="#275">275</a>	 *
<a class="l" name="276" href="#276">276</a>	 * <strong>@return</strong>  State
<a class="l" name="277" href="#277">277</a>	 */</span>
<a class="l" name="278" href="#278">278</a>	<b>public</b> <b>byte</b> <a class="xmt" name="getState"/><a href="/source/s?refs=getState&amp;project=rtmp_client" class="xmt">getState</a>() {
<a class="l" name="279" href="#279">279</a>		<b>return</b> <a href="/source/s?defs=state&amp;project=rtmp_client">state</a>;
<a class="hl" name="280" href="#280">280</a>	}
<a class="l" name="281" href="#281">281</a>
<a class="l" name="282" href="#282">282</a>	<span class="c">/**
<a class="l" name="283" href="#283">283</a>	 * Releases number of packets.
<a class="l" name="284" href="#284">284</a>	 *
<a class="l" name="285" href="#285">285</a>	 * <strong>@param</strong> <em>packets</em>            Packets to release
<a class="l" name="286" href="#286">286</a>	 */</span>
<a class="l" name="287" href="#287">287</a>	<b>private</b> <b>void</b> <a class="xmt" name="freePackets"/><a href="/source/s?refs=freePackets&amp;project=rtmp_client" class="xmt">freePackets</a>(<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a>&gt; <a class="xa" name="packets"/><a href="/source/s?refs=packets&amp;project=rtmp_client" class="xa">packets</a>) {
<a class="l" name="288" href="#288">288</a>		<b>for</b> (<a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a> <a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a> : <a class="d" href="#packets">packets</a>.<a href="/source/s?defs=values&amp;project=rtmp_client">values</a>()) {
<a class="l" name="289" href="#289">289</a>			<b>if</b> (<a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a>.<a href="/source/s?defs=getData&amp;project=rtmp_client">getData</a>() != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="290" href="#290">290</a>				<a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a>.<a href="/source/s?defs=getData&amp;project=rtmp_client">getData</a>().<a href="/source/s?defs=free&amp;project=rtmp_client">free</a>();
<a class="l" name="291" href="#291">291</a>				<a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a>.<a href="/source/s?defs=setData&amp;project=rtmp_client">setData</a>(<a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="292" href="#292">292</a>			}
<a class="l" name="293" href="#293">293</a>		}
<a class="l" name="294" href="#294">294</a>		<a class="d" href="#packets">packets</a>.<a href="/source/s?defs=clear&amp;project=rtmp_client">clear</a>();
<a class="l" name="295" href="#295">295</a>	}
<a class="l" name="296" href="#296">296</a>
<a class="l" name="297" href="#297">297</a>	<span class="c">/**
<a class="l" name="298" href="#298">298</a>	 * Setter for state.
<a class="l" name="299" href="#299">299</a>	 *
<a class="hl" name="300" href="#300">300</a>	 * <strong>@param</strong> <em>state</em>  New state
<a class="l" name="301" href="#301">301</a>	 */</span>
<a class="l" name="302" href="#302">302</a>	<b>public</b> <b>void</b> <a class="xmt" name="setState"/><a href="/source/s?refs=setState&amp;project=rtmp_client" class="xmt">setState</a>(<b>byte</b> <a class="xa" name="state"/><a href="/source/s?refs=state&amp;project=rtmp_client" class="xa">state</a>) {
<a class="l" name="303" href="#303">303</a>		<b>this</b>.<a href="/source/s?defs=state&amp;project=rtmp_client">state</a> = <a href="/source/s?defs=state&amp;project=rtmp_client">state</a>;
<a class="l" name="304" href="#304">304</a>		<b>if</b> (<a href="/source/s?defs=state&amp;project=rtmp_client">state</a> == <a class="d" href="#STATE_DISCONNECTED">STATE_DISCONNECTED</a>) {
<a class="l" name="305" href="#305">305</a>			<span class="c">// Free temporary packets</span>
<a class="l" name="306" href="#306">306</a>			<a class="d" href="#freePackets">freePackets</a>(<a class="d" href="#readPackets">readPackets</a>);
<a class="l" name="307" href="#307">307</a>			<a class="d" href="#freePackets">freePackets</a>(<a class="d" href="#writePackets">writePackets</a>);
<a class="l" name="308" href="#308">308</a>			<a class="d" href="#readHeaders">readHeaders</a>.<a href="/source/s?defs=clear&amp;project=rtmp_client">clear</a>();
<a class="l" name="309" href="#309">309</a>			<a class="d" href="#writeHeaders">writeHeaders</a>.<a href="/source/s?defs=clear&amp;project=rtmp_client">clear</a>();
<a class="hl" name="310" href="#310">310</a>		}
<a class="l" name="311" href="#311">311</a>	}
<a class="l" name="312" href="#312">312</a>
<a class="l" name="313" href="#313">313</a>	<span class="c">/**
<a class="l" name="314" href="#314">314</a>	 * Setter for last read header.
<a class="l" name="315" href="#315">315</a>	 *
<a class="l" name="316" href="#316">316</a>	 * <strong>@param</strong> <em>channelId</em>            Channel id
<a class="l" name="317" href="#317">317</a>	 * <strong>@param</strong> <em>header</em>               Header
<a class="l" name="318" href="#318">318</a>	 */</span>
<a class="l" name="319" href="#319">319</a>	<b>public</b> <b>void</b> <a class="xmt" name="setLastReadHeader"/><a href="/source/s?refs=setLastReadHeader&amp;project=rtmp_client" class="xmt">setLastReadHeader</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xa">header</a>) {
<a class="hl" name="320" href="#320">320</a>		<a class="d" href="#lastReadChannel">lastReadChannel</a> = <a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>;
<a class="l" name="321" href="#321">321</a>		<a class="d" href="#readHeaders">readHeaders</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>);
<a class="l" name="322" href="#322">322</a>	}
<a class="l" name="323" href="#323">323</a>
<a class="l" name="324" href="#324">324</a>	<span class="c">/**
<a class="l" name="325" href="#325">325</a>	 * Return last read header for channel.
<a class="l" name="326" href="#326">326</a>	 *
<a class="l" name="327" href="#327">327</a>	 * <strong>@param</strong> <em>channelId</em>             Channel id
<a class="l" name="328" href="#328">328</a>	 * <strong>@return</strong>                      Last read header
<a class="l" name="329" href="#329">329</a>	 */</span>
<a class="hl" name="330" href="#330">330</a>	<b>public</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xmt" name="getLastReadHeader"/><a href="/source/s?refs=getLastReadHeader&amp;project=rtmp_client" class="xmt">getLastReadHeader</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>) {
<a class="l" name="331" href="#331">331</a>		<b>return</b> <a class="d" href="#readHeaders">readHeaders</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>);
<a class="l" name="332" href="#332">332</a>	}
<a class="l" name="333" href="#333">333</a>
<a class="l" name="334" href="#334">334</a>	<span class="c">/**
<a class="l" name="335" href="#335">335</a>	 * Setter for last written header.
<a class="l" name="336" href="#336">336</a>	 *
<a class="l" name="337" href="#337">337</a>	 * <strong>@param</strong> <em>channelId</em>             Channel id
<a class="l" name="338" href="#338">338</a>	 * <strong>@param</strong> <em>header</em>                Header
<a class="l" name="339" href="#339">339</a>	 */</span>
<a class="hl" name="340" href="#340">340</a>	<b>public</b> <b>void</b> <a class="xmt" name="setLastWriteHeader"/><a href="/source/s?refs=setLastWriteHeader&amp;project=rtmp_client" class="xmt">setLastWriteHeader</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xa">header</a>) {
<a class="l" name="341" href="#341">341</a>		<a class="d" href="#lastWriteChannel">lastWriteChannel</a> = <a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>;
<a class="l" name="342" href="#342">342</a>		<a class="d" href="#writeHeaders">writeHeaders</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>);
<a class="l" name="343" href="#343">343</a>	}
<a class="l" name="344" href="#344">344</a>
<a class="l" name="345" href="#345">345</a>	<span class="c">/**
<a class="l" name="346" href="#346">346</a>	 * Return last written header for channel.
<a class="l" name="347" href="#347">347</a>	 *
<a class="l" name="348" href="#348">348</a>	 * <strong>@param</strong> <em>channelId</em>             Channel id
<a class="l" name="349" href="#349">349</a>	 * <strong>@return</strong>                      Last written header
<a class="hl" name="350" href="#350">350</a>	 */</span>
<a class="l" name="351" href="#351">351</a>	<b>public</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xmt" name="getLastWriteHeader"/><a href="/source/s?refs=getLastWriteHeader&amp;project=rtmp_client" class="xmt">getLastWriteHeader</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>) {
<a class="l" name="352" href="#352">352</a>		<b>return</b> <a class="d" href="#writeHeaders">writeHeaders</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>);
<a class="l" name="353" href="#353">353</a>	}
<a class="l" name="354" href="#354">354</a>
<a class="l" name="355" href="#355">355</a>	<span class="c">/**
<a class="l" name="356" href="#356">356</a>	 * Setter for last read packet.
<a class="l" name="357" href="#357">357</a>	 *
<a class="l" name="358" href="#358">358</a>	 * <strong>@param</strong> <em>channelId</em>           Channel id
<a class="l" name="359" href="#359">359</a>	 * <strong>@param</strong> <em>packet</em>              Packet
<a class="hl" name="360" href="#360">360</a>	 */</span>
<a class="l" name="361" href="#361">361</a>	<b>public</b> <b>void</b> <a class="xmt" name="setLastReadPacket"/><a href="/source/s?refs=setLastReadPacket&amp;project=rtmp_client" class="xmt">setLastReadPacket</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>, <a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a> <a class="xa" name="packet"/><a href="/source/s?refs=packet&amp;project=rtmp_client" class="xa">packet</a>) {
<a class="l" name="362" href="#362">362</a>		<a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a> <a href="/source/s?defs=prevPacket&amp;project=rtmp_client">prevPacket</a> = <a class="d" href="#readPackets">readPackets</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>, <a href="/source/s?defs=packet&amp;project=rtmp_client">packet</a>);
<a class="l" name="363" href="#363">363</a>		<b>if</b> (<a href="/source/s?defs=prevPacket&amp;project=rtmp_client">prevPacket</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a href="/source/s?defs=prevPacket&amp;project=rtmp_client">prevPacket</a>.<a href="/source/s?defs=getData&amp;project=rtmp_client">getData</a>() != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="364" href="#364">364</a>			<a href="/source/s?defs=prevPacket&amp;project=rtmp_client">prevPacket</a>.<a href="/source/s?defs=getData&amp;project=rtmp_client">getData</a>().<a href="/source/s?defs=free&amp;project=rtmp_client">free</a>();
<a class="l" name="365" href="#365">365</a>			<a href="/source/s?defs=prevPacket&amp;project=rtmp_client">prevPacket</a>.<a href="/source/s?defs=setData&amp;project=rtmp_client">setData</a>(<a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="366" href="#366">366</a>		}
<a class="l" name="367" href="#367">367</a>	}
<a class="l" name="368" href="#368">368</a>
<a class="l" name="369" href="#369">369</a>	<span class="c">/**
<a class="hl" name="370" href="#370">370</a>	 * Return last read packet for channel.
<a class="l" name="371" href="#371">371</a>	 *
<a class="l" name="372" href="#372">372</a>	 * <strong>@param</strong> <em>channelId</em>           Channel id
<a class="l" name="373" href="#373">373</a>	 * <strong>@return</strong>                    Last read packet for that channel
<a class="l" name="374" href="#374">374</a>	 */</span>
<a class="l" name="375" href="#375">375</a>	<b>public</b> <a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a> <a class="xmt" name="getLastReadPacket"/><a href="/source/s?refs=getLastReadPacket&amp;project=rtmp_client" class="xmt">getLastReadPacket</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>) {
<a class="l" name="376" href="#376">376</a>		<b>return</b> <a class="d" href="#readPackets">readPackets</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>);
<a class="l" name="377" href="#377">377</a>	}
<a class="l" name="378" href="#378">378</a>
<a class="l" name="379" href="#379">379</a>	<span class="c">/**
<a class="hl" name="380" href="#380">380</a>	 * Setter for last written packet.
<a class="l" name="381" href="#381">381</a>	 *
<a class="l" name="382" href="#382">382</a>	 * <strong>@param</strong> <em>channelId</em>           Channel id
<a class="l" name="383" href="#383">383</a>	 * <strong>@param</strong> <em>packet</em>              Last written packet
<a class="l" name="384" href="#384">384</a>	 */</span>
<a class="l" name="385" href="#385">385</a>	<b>public</b> <b>void</b> <a class="xmt" name="setLastWritePacket"/><a href="/source/s?refs=setLastWritePacket&amp;project=rtmp_client" class="xmt">setLastWritePacket</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>, <a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a> <a class="xa" name="packet"/><a href="/source/s?refs=packet&amp;project=rtmp_client" class="xa">packet</a>) {
<a class="l" name="386" href="#386">386</a>		<span class="c">// Disabled to help GC because we currently don't use the write packets</span>
<a class="l" name="387" href="#387">387</a>		<span class="c">/*
<a class="l" name="388" href="#388">388</a>		Packet prevPacket = writePackets.put(channelId, packet);
<a class="l" name="389" href="#389">389</a>		if (prevPacket != null &amp;&amp; prevPacket.getData() != null) {
<a class="hl" name="390" href="#390">390</a>			prevPacket.getData().release();
<a class="l" name="391" href="#391">391</a>			prevPacket.setData(null);
<a class="l" name="392" href="#392">392</a>		}
<a class="l" name="393" href="#393">393</a>		*/</span>
<a class="l" name="394" href="#394">394</a>	}
<a class="l" name="395" href="#395">395</a>
<a class="l" name="396" href="#396">396</a>	<span class="c">/**
<a class="l" name="397" href="#397">397</a>	 * Return packet that has been written last.
<a class="l" name="398" href="#398">398</a>	 *
<a class="l" name="399" href="#399">399</a>	 * <strong>@param</strong> <em>channelId</em>           Channel id
<a class="hl" name="400" href="#400">400</a>	 * <strong>@return</strong>                    Packet that has been written last
<a class="l" name="401" href="#401">401</a>	 */</span>
<a class="l" name="402" href="#402">402</a>	<b>public</b> <a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a> <a class="xmt" name="getLastWritePacket"/><a href="/source/s?refs=getLastWritePacket&amp;project=rtmp_client" class="xmt">getLastWritePacket</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>) {
<a class="l" name="403" href="#403">403</a>		<b>return</b> <a class="d" href="#writePackets">writePackets</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>);
<a class="l" name="404" href="#404">404</a>	}
<a class="l" name="405" href="#405">405</a>
<a class="l" name="406" href="#406">406</a>	<span class="c">/**
<a class="l" name="407" href="#407">407</a>	 * Return channel being read last.
<a class="l" name="408" href="#408">408</a>	 *
<a class="l" name="409" href="#409">409</a>	 * <strong>@return</strong>  Last read channel
<a class="hl" name="410" href="#410">410</a>	 */</span>
<a class="l" name="411" href="#411">411</a>	<b>public</b> <b>int</b> <a class="xmt" name="getLastReadChannel"/><a href="/source/s?refs=getLastReadChannel&amp;project=rtmp_client" class="xmt">getLastReadChannel</a>() {
<a class="l" name="412" href="#412">412</a>		<b>return</b> <a class="d" href="#lastReadChannel">lastReadChannel</a>;
<a class="l" name="413" href="#413">413</a>	}
<a class="l" name="414" href="#414">414</a>
<a class="l" name="415" href="#415">415</a>	<span class="c">/**
<a class="l" name="416" href="#416">416</a>	 * Getter for channel being written last.
<a class="l" name="417" href="#417">417</a>	 *
<a class="l" name="418" href="#418">418</a>	 * <strong>@return</strong>  Last write channel
<a class="l" name="419" href="#419">419</a>	 */</span>
<a class="hl" name="420" href="#420">420</a>	<b>public</b> <b>int</b> <a class="xmt" name="getLastWriteChannel"/><a href="/source/s?refs=getLastWriteChannel&amp;project=rtmp_client" class="xmt">getLastWriteChannel</a>() {
<a class="l" name="421" href="#421">421</a>		<b>return</b> <a class="d" href="#lastWriteChannel">lastWriteChannel</a>;
<a class="l" name="422" href="#422">422</a>	}
<a class="l" name="423" href="#423">423</a>
<a class="l" name="424" href="#424">424</a>	<span class="c">/**
<a class="l" name="425" href="#425">425</a>	 * Getter for  write chunk size. Data is being read chunk-by-chunk.
<a class="l" name="426" href="#426">426</a>	 *
<a class="l" name="427" href="#427">427</a>	 * <strong>@return</strong>  Read chunk size
<a class="l" name="428" href="#428">428</a>	 */</span>
<a class="l" name="429" href="#429">429</a>	<b>public</b> <b>int</b> <a class="xmt" name="getReadChunkSize"/><a href="/source/s?refs=getReadChunkSize&amp;project=rtmp_client" class="xmt">getReadChunkSize</a>() {
<a class="hl" name="430" href="#430">430</a>		<b>return</b> <a href="/source/s?defs=readChunkSize&amp;project=rtmp_client">readChunkSize</a>;
<a class="l" name="431" href="#431">431</a>	}
<a class="l" name="432" href="#432">432</a>
<a class="l" name="433" href="#433">433</a>	<span class="c">/**
<a class="l" name="434" href="#434">434</a>	 * Setter for  read chunk size. Data is being read chunk-by-chunk.
<a class="l" name="435" href="#435">435</a>	 *
<a class="l" name="436" href="#436">436</a>	 * <strong>@param</strong> <em>readChunkSize</em> Value to set for property 'readChunkSize'.
<a class="l" name="437" href="#437">437</a>	 */</span>
<a class="l" name="438" href="#438">438</a>	<b>public</b> <b>void</b> <a class="xmt" name="setReadChunkSize"/><a href="/source/s?refs=setReadChunkSize&amp;project=rtmp_client" class="xmt">setReadChunkSize</a>(<b>int</b> <a class="xa" name="readChunkSize"/><a href="/source/s?refs=readChunkSize&amp;project=rtmp_client" class="xa">readChunkSize</a>) {
<a class="l" name="439" href="#439">439</a>		<b>this</b>.<a href="/source/s?defs=readChunkSize&amp;project=rtmp_client">readChunkSize</a> = <a href="/source/s?defs=readChunkSize&amp;project=rtmp_client">readChunkSize</a>;
<a class="hl" name="440" href="#440">440</a>	}
<a class="l" name="441" href="#441">441</a>
<a class="l" name="442" href="#442">442</a>	<span class="c">/**
<a class="l" name="443" href="#443">443</a>	 * Getter for  write chunk size. Data is being written chunk-by-chunk.
<a class="l" name="444" href="#444">444</a>	 *
<a class="l" name="445" href="#445">445</a>	 * <strong>@return</strong>  Write chunk size
<a class="l" name="446" href="#446">446</a>	 */</span>
<a class="l" name="447" href="#447">447</a>	<b>public</b> <b>int</b> <a class="xmt" name="getWriteChunkSize"/><a href="/source/s?refs=getWriteChunkSize&amp;project=rtmp_client" class="xmt">getWriteChunkSize</a>() {
<a class="l" name="448" href="#448">448</a>		<b>return</b> <a href="/source/s?defs=writeChunkSize&amp;project=rtmp_client">writeChunkSize</a>;
<a class="l" name="449" href="#449">449</a>	}
<a class="hl" name="450" href="#450">450</a>
<a class="l" name="451" href="#451">451</a>	<span class="c">/**
<a class="l" name="452" href="#452">452</a>	 * Setter for  write chunk size.
<a class="l" name="453" href="#453">453</a>	 *
<a class="l" name="454" href="#454">454</a>	 * <strong>@param</strong> <em>writeChunkSize</em>  Write chunk size
<a class="l" name="455" href="#455">455</a>	 */</span>
<a class="l" name="456" href="#456">456</a>	<b>public</b> <b>void</b> <a class="xmt" name="setWriteChunkSize"/><a href="/source/s?refs=setWriteChunkSize&amp;project=rtmp_client" class="xmt">setWriteChunkSize</a>(<b>int</b> <a class="xa" name="writeChunkSize"/><a href="/source/s?refs=writeChunkSize&amp;project=rtmp_client" class="xa">writeChunkSize</a>) {
<a class="l" name="457" href="#457">457</a>		<b>this</b>.<a href="/source/s?defs=writeChunkSize&amp;project=rtmp_client">writeChunkSize</a> = <a href="/source/s?defs=writeChunkSize&amp;project=rtmp_client">writeChunkSize</a>;
<a class="l" name="458" href="#458">458</a>	}
<a class="l" name="459" href="#459">459</a>
<a class="hl" name="460" href="#460">460</a>	<span class="c">/**
<a class="l" name="461" href="#461">461</a>	 * Getter for encoding version.
<a class="l" name="462" href="#462">462</a>	 *
<a class="l" name="463" href="#463">463</a>	 * <strong>@return</strong> Encoding version
<a class="l" name="464" href="#464">464</a>	 */</span>
<a class="l" name="465" href="#465">465</a>	<b>public</b> <a href="/source/s?defs=Encoding&amp;project=rtmp_client">Encoding</a> <a class="xmt" name="getEncoding"/><a href="/source/s?refs=getEncoding&amp;project=rtmp_client" class="xmt">getEncoding</a>() {
<a class="l" name="466" href="#466">466</a>		<b>return</b> <a href="/source/s?defs=encoding&amp;project=rtmp_client">encoding</a>;
<a class="l" name="467" href="#467">467</a>	}
<a class="l" name="468" href="#468">468</a>
<a class="l" name="469" href="#469">469</a>	<span class="c">/**
<a class="hl" name="470" href="#470">470</a>	 * Setter for encoding version.
<a class="l" name="471" href="#471">471</a>	 *
<a class="l" name="472" href="#472">472</a>	 * <strong>@param</strong> <em>encoding</em>	Encoding version
<a class="l" name="473" href="#473">473</a>	 */</span>
<a class="l" name="474" href="#474">474</a>	<b>public</b> <b>void</b> <a class="xmt" name="setEncoding"/><a href="/source/s?refs=setEncoding&amp;project=rtmp_client" class="xmt">setEncoding</a>(<a href="/source/s?defs=Encoding&amp;project=rtmp_client">Encoding</a> <a class="xa" name="encoding"/><a href="/source/s?refs=encoding&amp;project=rtmp_client" class="xa">encoding</a>) {
<a class="l" name="475" href="#475">475</a>		<b>this</b>.<a href="/source/s?defs=encoding&amp;project=rtmp_client">encoding</a> = <a href="/source/s?defs=encoding&amp;project=rtmp_client">encoding</a>;
<a class="l" name="476" href="#476">476</a>	}
<a class="l" name="477" href="#477">477</a>
<a class="l" name="478" href="#478">478</a>	<b>public</b> <b>void</b> <a class="xmt" name="setLastFullTimestampWritten"/><a href="/source/s?refs=setLastFullTimestampWritten&amp;project=rtmp_client" class="xmt">setLastFullTimestampWritten</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>, <b>int</b> <a class="xa" name="timer"/><a href="/source/s?refs=timer&amp;project=rtmp_client" class="xa">timer</a>) {
<a class="l" name="479" href="#479">479</a>		<a class="d" href="#writeTimestamps">writeTimestamps</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>, <a class="d" href="#timer">timer</a>);
<a class="hl" name="480" href="#480">480</a>	}
<a class="l" name="481" href="#481">481</a>
<a class="l" name="482" href="#482">482</a>	<b>public</b> <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a> <a class="xmt" name="getLastFullTimestampWritten"/><a href="/source/s?refs=getLastFullTimestampWritten&amp;project=rtmp_client" class="xmt">getLastFullTimestampWritten</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>) {
<a class="l" name="483" href="#483">483</a>		<b>return</b> <a class="d" href="#writeTimestamps">writeTimestamps</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>);
<a class="l" name="484" href="#484">484</a>	}
<a class="l" name="485" href="#485">485</a>
<a class="l" name="486" href="#486">486</a>	<b>public</b> <b>void</b> <a class="xmt" name="setLastReadPacketHeader"/><a href="/source/s?refs=setLastReadPacketHeader&amp;project=rtmp_client" class="xmt">setLastReadPacketHeader</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>, <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xa">header</a>) {
<a class="l" name="487" href="#487">487</a>		<a class="d" href="#readPacketHeaders">readPacketHeaders</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>, <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>);
<a class="l" name="488" href="#488">488</a>	}
<a class="l" name="489" href="#489">489</a>
<a class="hl" name="490" href="#490">490</a>	<b>public</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xmt" name="getLastReadPacketHeader"/><a href="/source/s?refs=getLastReadPacketHeader&amp;project=rtmp_client" class="xmt">getLastReadPacketHeader</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>) {
<a class="l" name="491" href="#491">491</a>		<b>return</b> <a class="d" href="#readPacketHeaders">readPacketHeaders</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>);
<a class="l" name="492" href="#492">492</a>	}
<a class="l" name="493" href="#493">493</a>
<a class="l" name="494" href="#494">494</a>	<a href="/source/s?defs=LiveTimestampMapping&amp;project=rtmp_client">LiveTimestampMapping</a> <a class="xmt" name="getLastTimestampMapping"/><a href="/source/s?refs=getLastTimestampMapping&amp;project=rtmp_client" class="xmt">getLastTimestampMapping</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>) {
<a class="l" name="495" href="#495">495</a>		<b>return</b> <a class="d" href="#liveTimestamps">liveTimestamps</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>);
<a class="l" name="496" href="#496">496</a>	}
<a class="l" name="497" href="#497">497</a>
<a class="l" name="498" href="#498">498</a>	<b>void</b> <a class="xmt" name="setLastTimestampMapping"/><a href="/source/s?refs=setLastTimestampMapping&amp;project=rtmp_client" class="xmt">setLastTimestampMapping</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>, <a href="/source/s?defs=LiveTimestampMapping&amp;project=rtmp_client">LiveTimestampMapping</a> <a class="xa" name="mapping"/><a href="/source/s?refs=mapping&amp;project=rtmp_client" class="xa">mapping</a>) {
<a class="l" name="499" href="#499">499</a>		<a class="d" href="#liveTimestamps">liveTimestamps</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>, <a class="d" href="#mapping">mapping</a>);
<a class="hl" name="500" href="#500">500</a>	}
<a class="l" name="501" href="#501">501</a>
<a class="l" name="502" href="#502">502</a>	<span class="c">/* (non-Javadoc)
<a class="l" name="503" href="#503">503</a>	 * @see java.lang.Object#toString()
<a class="l" name="504" href="#504">504</a>	 */</span>
<a class="l" name="505" href="#505">505</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="506" href="#506">506</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toString"/><a href="/source/s?refs=toString&amp;project=rtmp_client" class="xmt">toString</a>() {
<a class="l" name="507" href="#507">507</a>		<b>return</b> <span class="s">"RTMP [state="</span> + <a class="d" href="#states">states</a>[<a href="/source/s?defs=state&amp;project=rtmp_client">state</a>] + <span class="s">", client-mode="</span> + <a href="/source/s?defs=mode&amp;project=rtmp_client">mode</a> + <span class="s">", debug="</span> + <a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a> + <span class="s">", encrypted="</span> + <a href="/source/s?defs=encrypted&amp;project=rtmp_client">encrypted</a> + <span class="s">", lastReadChannel="</span> + <a class="d" href="#lastReadChannel">lastReadChannel</a> + <span class="s">", lastWriteChannel="</span>
<a class="l" name="508" href="#508">508</a>				+ <a class="d" href="#lastWriteChannel">lastWriteChannel</a> + <span class="s">", readHeaders="</span> + <a class="d" href="#readHeaders">readHeaders</a> + <span class="s">", writeHeaders="</span> + <a class="d" href="#writeHeaders">writeHeaders</a> + <span class="s">", readPacketHeaders="</span> + <a class="d" href="#readPacketHeaders">readPacketHeaders</a> + <span class="s">", readPackets="</span>
<a class="l" name="509" href="#509">509</a>				+ <a class="d" href="#readPackets">readPackets</a> + <span class="s">", writePackets="</span> + <a class="d" href="#writePackets">writePackets</a> + <span class="s">", writeTimestamps="</span> + <a class="d" href="#writeTimestamps">writeTimestamps</a> + <span class="s">", liveTimestamps="</span> + <a class="d" href="#liveTimestamps">liveTimestamps</a> + <span class="s">", readChunkSize="</span>
<a class="hl" name="510" href="#510">510</a>				+ <a href="/source/s?defs=readChunkSize&amp;project=rtmp_client">readChunkSize</a> + <span class="s">", writeChunkSize="</span> + <a href="/source/s?defs=writeChunkSize&amp;project=rtmp_client">writeChunkSize</a> + <span class="s">", encoding="</span> + <a href="/source/s?defs=encoding&amp;project=rtmp_client">encoding</a> + <span class="s">"]"</span>;
<a class="l" name="511" href="#511">511</a>	}
<a class="l" name="512" href="#512">512</a>
<a class="l" name="513" href="#513">513</a>}
<a class="l" name="514" href="#514">514</a>