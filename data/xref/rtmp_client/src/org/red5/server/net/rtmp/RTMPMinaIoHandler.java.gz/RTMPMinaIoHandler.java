<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["RTMPMinaIoHandler",38]]],["Package","xp",[["org.red5.server.net.rtmp",1]]],["Method","xmt",[["createRTMPMinaConnection",275],["exceptionCaught",225],["getRtmpConnManager",265],["messageReceived",198],["messageSent",209],["rawBufferRecieved",153],["sessionClosed",125],["sessionCreated",66],["sessionOpened",108],["setCodecFactory",257],["setHandler",238],["setMode",248],["setRtmpConnManager",261]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=IoHandlerAdapter&amp;project=rtmp_client">IoHandlerAdapter</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=IoSession&amp;project=rtmp_client">IoSession</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=filter&amp;project=rtmp_client">filter</a>.<a href="/source/s?defs=codec&amp;project=rtmp_client">codec</a>.<a href="/source/s?defs=ProtocolCodecFactory&amp;project=rtmp_client">ProtocolCodecFactory</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=filter&amp;project=rtmp_client">filter</a>.<a href="/source/s?defs=codec&amp;project=rtmp_client">codec</a>.<a href="/source/s?defs=ProtocolCodecFilter&amp;project=rtmp_client">ProtocolCodecFilter</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=filter&amp;project=rtmp_client">filter</a>.<a href="/source/s?defs=logging&amp;project=rtmp_client">logging</a>.<a href="/source/s?defs=LoggingFilter&amp;project=rtmp_client">LoggingFilter</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=codec&amp;project=rtmp_client">codec</a>.<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmpe&amp;project=rtmp_client">rtmpe</a>.<a href="/source/s?defs=RTMPEIoFilter&amp;project=rtmp_client">RTMPEIoFilter</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a><span class="c">/**
<a class="l" name="36" href="#36">36</a> * Handles all RTMP protocol events fired by the MINA framework.
<a class="l" name="37" href="#37">37</a> */</span>
<a class="l" name="38" href="#38">38</a><b>public</b> <b>class</b> <a class="xc" name="RTMPMinaIoHandler"/><a href="/source/s?refs=RTMPMinaIoHandler&amp;project=rtmp_client" class="xc">RTMPMinaIoHandler</a> <b>extends</b> <a href="/source/s?defs=IoHandlerAdapter&amp;project=rtmp_client">IoHandlerAdapter</a>  {
<a class="l" name="39" href="#39">39</a>
<a class="hl" name="40" href="#40">40</a>	<b>private</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a class="d" href="#RTMPMinaIoHandler">RTMPMinaIoHandler</a>.<b>class</b>);
<a class="l" name="41" href="#41">41</a>
<a class="l" name="42" href="#42">42</a>	<span class="c">/**
<a class="l" name="43" href="#43">43</a>	 * RTMP events handler
<a class="l" name="44" href="#44">44</a>	 */</span>
<a class="l" name="45" href="#45">45</a>	<b>protected</b> <a href="/source/s?defs=IRTMPHandler&amp;project=rtmp_client">IRTMPHandler</a> <a class="xfld" name="handler"/><a href="/source/s?refs=handler&amp;project=rtmp_client" class="xfld">handler</a>;
<a class="l" name="46" href="#46">46</a>
<a class="l" name="47" href="#47">47</a>	<span class="c">/**
<a class="l" name="48" href="#48">48</a>	 * Mode
<a class="l" name="49" href="#49">49</a>	 */</span>
<a class="hl" name="50" href="#50">50</a>	<b>protected</b> <b>boolean</b> <a class="xfld" name="mode"/><a href="/source/s?refs=mode&amp;project=rtmp_client" class="xfld">mode</a> = <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=MODE_SERVER&amp;project=rtmp_client">MODE_SERVER</a>;
<a class="l" name="51" href="#51">51</a>
<a class="l" name="52" href="#52">52</a>	<span class="c">/**
<a class="l" name="53" href="#53">53</a>	 * Application context
<a class="l" name="54" href="#54">54</a>	 */</span>
<a class="l" name="55" href="#55">55</a>	<span class="c">//protected ApplicationContext appCtx;</span>
<a class="l" name="56" href="#56">56</a>
<a class="l" name="57" href="#57">57</a>	<span class="c">/**
<a class="l" name="58" href="#58">58</a>	 * RTMP protocol codec factory
<a class="l" name="59" href="#59">59</a>	 */</span>
<a class="hl" name="60" href="#60">60</a>	<b>protected</b> <a href="/source/s?defs=ProtocolCodecFactory&amp;project=rtmp_client">ProtocolCodecFactory</a> <a class="xfld" name="codecFactory"/><a href="/source/s?refs=codecFactory&amp;project=rtmp_client" class="xfld">codecFactory</a>;
<a class="l" name="61" href="#61">61</a>
<a class="l" name="62" href="#62">62</a>	<b>protected</b> <a href="/source/s?defs=IRTMPConnManager&amp;project=rtmp_client">IRTMPConnManager</a> <a class="xfld" name="rtmpConnManager"/><a href="/source/s?refs=rtmpConnManager&amp;project=rtmp_client" class="xfld">rtmpConnManager</a>;
<a class="l" name="63" href="#63">63</a>
<a class="l" name="64" href="#64">64</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="65" href="#65">65</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="66" href="#66">66</a>	<b>public</b> <b>void</b> <a class="xmt" name="sessionCreated"/><a href="/source/s?refs=sessionCreated&amp;project=rtmp_client" class="xmt">sessionCreated</a>(<a href="/source/s?defs=IoSession&amp;project=rtmp_client">IoSession</a> <a class="xa" name="session"/><a href="/source/s?refs=session&amp;project=rtmp_client" class="xa">session</a>) <b>throws</b> <a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> {
<a class="l" name="67" href="#67">67</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Session created"</span>);
<a class="l" name="68" href="#68">68</a>		<span class="c">// moved protocol state from connection object to RTMP object</span>
<a class="l" name="69" href="#69">69</a>		<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a> = <b>new</b> <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>(<a href="/source/s?defs=mode&amp;project=rtmp_client">mode</a>);
<a class="hl" name="70" href="#70">70</a>		<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=setAttribute&amp;project=rtmp_client">setAttribute</a>(<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a>.<a href="/source/s?defs=SESSION_KEY&amp;project=rtmp_client">SESSION_KEY</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="71" href="#71">71</a>		<span class="c">//add rtmpe filter</span>
<a class="l" name="72" href="#72">72</a>		<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=getFilterChain&amp;project=rtmp_client">getFilterChain</a>().<a href="/source/s?defs=addFirst&amp;project=rtmp_client">addFirst</a>(<span class="s">"rtmpeFilter"</span>, <b>new</b> <a href="/source/s?defs=RTMPEIoFilter&amp;project=rtmp_client">RTMPEIoFilter</a>());
<a class="l" name="73" href="#73">73</a>		<span class="c">//add protocol filter next</span>
<a class="l" name="74" href="#74">74</a>		<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=getFilterChain&amp;project=rtmp_client">getFilterChain</a>().<a href="/source/s?defs=addLast&amp;project=rtmp_client">addLast</a>(<span class="s">"protocolFilter"</span>, <b>new</b> <a href="/source/s?defs=ProtocolCodecFilter&amp;project=rtmp_client">ProtocolCodecFilter</a>(<a href="/source/s?defs=codecFactory&amp;project=rtmp_client">codecFactory</a>));
<a class="l" name="75" href="#75">75</a>		<b>if</b> (<a class="d" href="#log">log</a>.<a href="/source/s?defs=isTraceEnabled&amp;project=rtmp_client">isTraceEnabled</a>()) {
<a class="l" name="76" href="#76">76</a>			<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=getFilterChain&amp;project=rtmp_client">getFilterChain</a>().<a href="/source/s?defs=addLast&amp;project=rtmp_client">addLast</a>(<span class="s">"logger"</span>, <b>new</b> <a href="/source/s?defs=LoggingFilter&amp;project=rtmp_client">LoggingFilter</a>());
<a class="l" name="77" href="#77">77</a>		}
<a class="l" name="78" href="#78">78</a>		<span class="c">//create a connection</span>
<a class="l" name="79" href="#79">79</a>		<a href="/source/s?defs=RTMPMinaConnection&amp;project=rtmp_client">RTMPMinaConnection</a> <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> = <a class="d" href="#createRTMPMinaConnection">createRTMPMinaConnection</a>();
<a class="hl" name="80" href="#80">80</a>		<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=setIoSession&amp;project=rtmp_client">setIoSession</a>(<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>);
<a class="l" name="81" href="#81">81</a>		<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=setState&amp;project=rtmp_client">setState</a>(<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="82" href="#82">82</a>		<span class="c">//add the connection</span>
<a class="l" name="83" href="#83">83</a>		<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=setAttribute&amp;project=rtmp_client">setAttribute</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<a href="/source/s?defs=RTMP_CONNECTION_KEY&amp;project=rtmp_client">RTMP_CONNECTION_KEY</a>, <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>);
<a class="l" name="84" href="#84">84</a>		<span class="c">//create inbound or outbound handshaker</span>
<a class="l" name="85" href="#85">85</a>		<b>if</b> (<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getMode&amp;project=rtmp_client">getMode</a>() == <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=MODE_CLIENT&amp;project=rtmp_client">MODE_CLIENT</a>) {
<a class="l" name="86" href="#86">86</a>			<span class="c">// create an outbound handshake</span>
<a class="l" name="87" href="#87">87</a>			<a href="/source/s?defs=OutboundHandshake&amp;project=rtmp_client">OutboundHandshake</a> <a href="/source/s?defs=outgoingHandshake&amp;project=rtmp_client">outgoingHandshake</a> = <b>new</b> <a href="/source/s?defs=OutboundHandshake&amp;project=rtmp_client">OutboundHandshake</a>();
<a class="l" name="88" href="#88">88</a>			<span class="c">//if handler is rtmpe client set encryption on the protocol state</span>
<a class="l" name="89" href="#89">89</a>			<span class="c">//if (handler instanceof RTMPEClient) {</span>
<a class="hl" name="90" href="#90">90</a>				<span class="c">//rtmp.setEncrypted(true);</span>
<a class="l" name="91" href="#91">91</a>				<span class="c">//set the handshake type to encrypted as well</span>
<a class="l" name="92" href="#92">92</a>				<span class="c">//outgoingHandshake.setHandshakeType(RTMPConnection.RTMP_ENCRYPTED);</span>
<a class="l" name="93" href="#93">93</a>			<span class="c">//}</span>
<a class="l" name="94" href="#94">94</a>			<span class="c">//add the handshake</span>
<a class="l" name="95" href="#95">95</a>			<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=setAttribute&amp;project=rtmp_client">setAttribute</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<a href="/source/s?defs=RTMP_HANDSHAKE&amp;project=rtmp_client">RTMP_HANDSHAKE</a>, <a href="/source/s?defs=outgoingHandshake&amp;project=rtmp_client">outgoingHandshake</a>);
<a class="l" name="96" href="#96">96</a>			<span class="c">// set a reference to the connection on the client</span>
<a class="l" name="97" href="#97">97</a>			<b>if</b> (<a href="/source/s?defs=handler&amp;project=rtmp_client">handler</a> <b>instanceof</b> <a href="/source/s?defs=BaseRTMPClientHandler&amp;project=rtmp_client">BaseRTMPClientHandler</a>) {
<a class="l" name="98" href="#98">98</a>				((<a href="/source/s?defs=BaseRTMPClientHandler&amp;project=rtmp_client">BaseRTMPClientHandler</a>) <a href="/source/s?defs=handler&amp;project=rtmp_client">handler</a>).<a href="/source/s?defs=setConnection&amp;project=rtmp_client">setConnection</a>((<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>) <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>);
<a class="l" name="99" href="#99">99</a>			}
<a class="hl" name="100" href="#100">100</a>		} <b>else</b> {
<a class="l" name="101" href="#101">101</a>			<span class="c">//add the handshake</span>
<a class="l" name="102" href="#102">102</a><span class="c">//			session.setAttribute(RTMPConnection.RTMP_HANDSHAKE, new InboundHandshake());</span>
<a class="l" name="103" href="#103">103</a>		}
<a class="l" name="104" href="#104">104</a>	}
<a class="l" name="105" href="#105">105</a>
<a class="l" name="106" href="#106">106</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="107" href="#107">107</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="108" href="#108">108</a>	<b>public</b> <b>void</b> <a class="xmt" name="sessionOpened"/><a href="/source/s?refs=sessionOpened&amp;project=rtmp_client" class="xmt">sessionOpened</a>(<a href="/source/s?defs=IoSession&amp;project=rtmp_client">IoSession</a> <a class="xa" name="session"/><a href="/source/s?refs=session&amp;project=rtmp_client" class="xa">session</a>) <b>throws</b> <a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> {
<a class="l" name="109" href="#109">109</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Session opened"</span>);
<a class="hl" name="110" href="#110">110</a>		<b>super</b>.<a class="d" href="#sessionOpened">sessionOpened</a>(<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>);
<a class="l" name="111" href="#111">111</a>		<span class="c">// get protocol state</span>
<a class="l" name="112" href="#112">112</a>		<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a> = (<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>) <a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a>.<a href="/source/s?defs=SESSION_KEY&amp;project=rtmp_client">SESSION_KEY</a>);
<a class="l" name="113" href="#113">113</a>		<b>if</b> (<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getMode&amp;project=rtmp_client">getMode</a>() == <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=MODE_CLIENT&amp;project=rtmp_client">MODE_CLIENT</a>) {
<a class="l" name="114" href="#114">114</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Handshake - client phase 1"</span>);
<a class="l" name="115" href="#115">115</a>			<span class="c">//get the handshake from the session</span>
<a class="l" name="116" href="#116">116</a>			<a href="/source/s?defs=RTMPHandshake&amp;project=rtmp_client">RTMPHandshake</a> <a href="/source/s?defs=handshake&amp;project=rtmp_client">handshake</a> = (<a href="/source/s?defs=RTMPHandshake&amp;project=rtmp_client">RTMPHandshake</a>) <a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<a href="/source/s?defs=RTMP_HANDSHAKE&amp;project=rtmp_client">RTMP_HANDSHAKE</a>);
<a class="l" name="117" href="#117">117</a>			<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=handshake&amp;project=rtmp_client">handshake</a>.<a href="/source/s?defs=doHandshake&amp;project=rtmp_client">doHandshake</a>(<a href="/source/s?defs=null&amp;project=rtmp_client">null</a>));
<a class="l" name="118" href="#118">118</a>		} <b>else</b> {
<a class="l" name="119" href="#119">119</a>			<a href="/source/s?defs=handler&amp;project=rtmp_client">handler</a>.<a href="/source/s?defs=connectionOpened&amp;project=rtmp_client">connectionOpened</a>((<a href="/source/s?defs=RTMPMinaConnection&amp;project=rtmp_client">RTMPMinaConnection</a>) <a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<a href="/source/s?defs=RTMP_CONNECTION_KEY&amp;project=rtmp_client">RTMP_CONNECTION_KEY</a>), <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="hl" name="120" href="#120">120</a>		}
<a class="l" name="121" href="#121">121</a>	}
<a class="l" name="122" href="#122">122</a>
<a class="l" name="123" href="#123">123</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="124" href="#124">124</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="125" href="#125">125</a>	<b>public</b> <b>void</b> <a class="xmt" name="sessionClosed"/><a href="/source/s?refs=sessionClosed&amp;project=rtmp_client" class="xmt">sessionClosed</a>(<a href="/source/s?defs=IoSession&amp;project=rtmp_client">IoSession</a> <a class="xa" name="session"/><a href="/source/s?refs=session&amp;project=rtmp_client" class="xa">session</a>) <b>throws</b> <a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> {
<a class="l" name="126" href="#126">126</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Session closed"</span>);
<a class="l" name="127" href="#127">127</a>		<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a> = (<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>) <a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=removeAttribute&amp;project=rtmp_client">removeAttribute</a>(<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a>.<a href="/source/s?defs=SESSION_KEY&amp;project=rtmp_client">SESSION_KEY</a>);
<a class="l" name="128" href="#128">128</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"RTMP state: {}"</span>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="129" href="#129">129</a>		<a href="/source/s?defs=RTMPMinaConnection&amp;project=rtmp_client">RTMPMinaConnection</a> <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> = (<a href="/source/s?defs=RTMPMinaConnection&amp;project=rtmp_client">RTMPMinaConnection</a>) <a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=removeAttribute&amp;project=rtmp_client">removeAttribute</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<a href="/source/s?defs=RTMP_CONNECTION_KEY&amp;project=rtmp_client">RTMP_CONNECTION_KEY</a>);
<a class="hl" name="130" href="#130">130</a>		<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=sendPendingServiceCallsCloseError&amp;project=rtmp_client">sendPendingServiceCallsCloseError</a>();
<a class="l" name="131" href="#131">131</a>		<span class="c">// fire-off closed</span>
<a class="l" name="132" href="#132">132</a>		<a href="/source/s?defs=handler&amp;project=rtmp_client">handler</a>.<a href="/source/s?defs=connectionClosed&amp;project=rtmp_client">connectionClosed</a>(<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="133" href="#133">133</a>		<span class="c">// remove the handshake if not already done</span>
<a class="l" name="134" href="#134">134</a>		<b>if</b> (<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=containsAttribute&amp;project=rtmp_client">containsAttribute</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<a href="/source/s?defs=RTMP_HANDSHAKE&amp;project=rtmp_client">RTMP_HANDSHAKE</a>)) {
<a class="l" name="135" href="#135">135</a>    		<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=removeAttribute&amp;project=rtmp_client">removeAttribute</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<a href="/source/s?defs=RTMP_HANDSHAKE&amp;project=rtmp_client">RTMP_HANDSHAKE</a>);
<a class="l" name="136" href="#136">136</a>		}
<a class="l" name="137" href="#137">137</a>		<span class="c">// remove ciphers</span>
<a class="l" name="138" href="#138">138</a>		<b>if</b> (<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=containsAttribute&amp;project=rtmp_client">containsAttribute</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<a href="/source/s?defs=RTMPE_CIPHER_IN&amp;project=rtmp_client">RTMPE_CIPHER_IN</a>)) {
<a class="l" name="139" href="#139">139</a>			<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=removeAttribute&amp;project=rtmp_client">removeAttribute</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<a href="/source/s?defs=RTMPE_CIPHER_IN&amp;project=rtmp_client">RTMPE_CIPHER_IN</a>);
<a class="hl" name="140" href="#140">140</a>			<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=removeAttribute&amp;project=rtmp_client">removeAttribute</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<a href="/source/s?defs=RTMPE_CIPHER_OUT&amp;project=rtmp_client">RTMPE_CIPHER_OUT</a>);
<a class="l" name="141" href="#141">141</a>		}
<a class="l" name="142" href="#142">142</a>		<a href="/source/s?defs=rtmpConnManager&amp;project=rtmp_client">rtmpConnManager</a>.<a href="/source/s?defs=removeConnection&amp;project=rtmp_client">removeConnection</a>(<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=getId&amp;project=rtmp_client">getId</a>());
<a class="l" name="143" href="#143">143</a>	}
<a class="l" name="144" href="#144">144</a>
<a class="l" name="145" href="#145">145</a>	<span class="c">/**
<a class="l" name="146" href="#146">146</a>	 * Handle raw buffer receiving event.
<a class="l" name="147" href="#147">147</a>	 *
<a class="l" name="148" href="#148">148</a>	 * <strong>@param</strong> <em>in</em>
<a class="l" name="149" href="#149">149</a>	 *            Data buffer
<a class="hl" name="150" href="#150">150</a>	 * <strong>@param</strong> <em>session</em>
<a class="l" name="151" href="#151">151</a>	 *            I/O session, that is, connection between two endpoints
<a class="l" name="152" href="#152">152</a>	 */</span>
<a class="l" name="153" href="#153">153</a>	<b>protected</b> <b>void</b> <a class="xmt" name="rawBufferRecieved"/><a href="/source/s?refs=rawBufferRecieved&amp;project=rtmp_client" class="xmt">rawBufferRecieved</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>, <a href="/source/s?defs=IoSession&amp;project=rtmp_client">IoSession</a> <a class="xa" name="session"/><a href="/source/s?refs=session&amp;project=rtmp_client" class="xa">session</a>) {
<a class="l" name="154" href="#154">154</a><span class="c">//		log.debug("rawBufferRecieved: {}", in);</span>
<a class="l" name="155" href="#155">155</a>		<b>final</b> <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a> = (<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>) <a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a>.<a href="/source/s?defs=SESSION_KEY&amp;project=rtmp_client">SESSION_KEY</a>);
<a class="l" name="156" href="#156">156</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"state: {}"</span>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="157" href="#157">157</a>		<b>final</b> <a href="/source/s?defs=RTMPMinaConnection&amp;project=rtmp_client">RTMPMinaConnection</a> <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> = (<a href="/source/s?defs=RTMPMinaConnection&amp;project=rtmp_client">RTMPMinaConnection</a>) <a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<a href="/source/s?defs=RTMP_CONNECTION_KEY&amp;project=rtmp_client">RTMP_CONNECTION_KEY</a>);
<a class="l" name="158" href="#158">158</a>		<a href="/source/s?defs=RTMPHandshake&amp;project=rtmp_client">RTMPHandshake</a> <a href="/source/s?defs=handshake&amp;project=rtmp_client">handshake</a> = (<a href="/source/s?defs=RTMPHandshake&amp;project=rtmp_client">RTMPHandshake</a>) <a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<a href="/source/s?defs=RTMP_HANDSHAKE&amp;project=rtmp_client">RTMP_HANDSHAKE</a>);
<a class="l" name="159" href="#159">159</a>		<b>if</b> (<a href="/source/s?defs=handshake&amp;project=rtmp_client">handshake</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="160" href="#160">160</a>			<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="161" href="#161">161</a>			<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=lock&amp;project=rtmp_client">lock</a>();
<a class="l" name="162" href="#162">162</a>			<b>try</b> {
<a class="l" name="163" href="#163">163</a>				<b>if</b> (<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getMode&amp;project=rtmp_client">getMode</a>() == <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=MODE_SERVER&amp;project=rtmp_client">MODE_SERVER</a>) {
<a class="l" name="164" href="#164">164</a>					<b>if</b> (<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getState&amp;project=rtmp_client">getState</a>() != <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=STATE_HANDSHAKE&amp;project=rtmp_client">STATE_HANDSHAKE</a>) {
<a class="l" name="165" href="#165">165</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Raw buffer after handshake, something odd going on"</span>);
<a class="l" name="166" href="#166">166</a>					}
<a class="l" name="167" href="#167">167</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Handshake - server phase 1 - size: {}"</span>, <a class="d" href="#in">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>());
<a class="l" name="168" href="#168">168</a>				} <b>else</b> {
<a class="l" name="169" href="#169">169</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Handshake - client phase 2 - size: {}"</span>, <a class="d" href="#in">in</a>.<a href="/source/s?defs=remaining&amp;project=rtmp_client">remaining</a>());
<a class="hl" name="170" href="#170">170</a>				}
<a class="l" name="171" href="#171">171</a>				<a href="/source/s?defs=out&amp;project=rtmp_client">out</a> = <a href="/source/s?defs=handshake&amp;project=rtmp_client">handshake</a>.<a href="/source/s?defs=doHandshake&amp;project=rtmp_client">doHandshake</a>(<a class="d" href="#in">in</a>);
<a class="l" name="172" href="#172">172</a>			} <b>finally</b> {
<a class="l" name="173" href="#173">173</a>				<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=unlock&amp;project=rtmp_client">unlock</a>();
<a class="l" name="174" href="#174">174</a>				<b>if</b> (<a href="/source/s?defs=out&amp;project=rtmp_client">out</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="175" href="#175">175</a><span class="c">//					log.debug("Output: {}", out);</span>
<a class="l" name="176" href="#176">176</a>					<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=out&amp;project=rtmp_client">out</a>);
<a class="l" name="177" href="#177">177</a>					<span class="c">//if we are connected and doing encryption, add the ciphers</span>
<a class="l" name="178" href="#178">178</a>					<b>if</b> (<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=getState&amp;project=rtmp_client">getState</a>() == <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=STATE_CONNECTED&amp;project=rtmp_client">STATE_CONNECTED</a>) {
<a class="l" name="179" href="#179">179</a>						<span class="c">// remove handshake from session now that we are connected</span>
<a class="hl" name="180" href="#180">180</a>						<span class="c">//session.removeAttribute(RTMPConnection.RTMP_HANDSHAKE);</span>
<a class="l" name="181" href="#181">181</a>		    			<span class="c">// if we are using encryption then put the ciphers in the session</span>
<a class="l" name="182" href="#182">182</a>		        		<b>if</b> (<a href="/source/s?defs=handshake&amp;project=rtmp_client">handshake</a>.<a href="/source/s?defs=getHandshakeType&amp;project=rtmp_client">getHandshakeType</a>() == <a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<a href="/source/s?defs=RTMP_ENCRYPTED&amp;project=rtmp_client">RTMP_ENCRYPTED</a>) {
<a class="l" name="183" href="#183">183</a>		        			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Adding ciphers to the session"</span>);
<a class="l" name="184" href="#184">184</a>		        			<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=setAttribute&amp;project=rtmp_client">setAttribute</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<a href="/source/s?defs=RTMPE_CIPHER_IN&amp;project=rtmp_client">RTMPE_CIPHER_IN</a>, <a href="/source/s?defs=handshake&amp;project=rtmp_client">handshake</a>.<a href="/source/s?defs=getCipherIn&amp;project=rtmp_client">getCipherIn</a>());
<a class="l" name="185" href="#185">185</a>		        			<a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=setAttribute&amp;project=rtmp_client">setAttribute</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<a href="/source/s?defs=RTMPE_CIPHER_OUT&amp;project=rtmp_client">RTMPE_CIPHER_OUT</a>, <a href="/source/s?defs=handshake&amp;project=rtmp_client">handshake</a>.<a href="/source/s?defs=getCipherOut&amp;project=rtmp_client">getCipherOut</a>());
<a class="l" name="186" href="#186">186</a>		        		}
<a class="l" name="187" href="#187">187</a>					}
<a class="l" name="188" href="#188">188</a>				}
<a class="l" name="189" href="#189">189</a>			}
<a class="hl" name="190" href="#190">190</a>		} <b>else</b> {
<a class="l" name="191" href="#191">191</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Handshake was not found for this connection: {}"</span>, <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>);
<a class="l" name="192" href="#192">192</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"RTMP state: {} Session: {}"</span>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>, <a href="/source/s?defs=session&amp;project=rtmp_client">session</a>);
<a class="l" name="193" href="#193">193</a>		}
<a class="l" name="194" href="#194">194</a>	}
<a class="l" name="195" href="#195">195</a>
<a class="l" name="196" href="#196">196</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="197" href="#197">197</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="198" href="#198">198</a>	<b>public</b> <b>void</b> <a class="xmt" name="messageReceived"/><a href="/source/s?refs=messageReceived&amp;project=rtmp_client" class="xmt">messageReceived</a>(<a href="/source/s?defs=IoSession&amp;project=rtmp_client">IoSession</a> <a class="xa" name="session"/><a href="/source/s?refs=session&amp;project=rtmp_client" class="xa">session</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="message"/><a href="/source/s?refs=message&amp;project=rtmp_client" class="xa">message</a>) <b>throws</b> <a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> {
<a class="l" name="199" href="#199">199</a>		<span class="c">//log.debug("messageReceived");</span>
<a class="hl" name="200" href="#200">200</a>		<b>if</b> (<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> <b>instanceof</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>) {
<a class="l" name="201" href="#201">201</a>			<a class="d" href="#rawBufferRecieved">rawBufferRecieved</a>((<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>, <a href="/source/s?defs=session&amp;project=rtmp_client">session</a>);
<a class="l" name="202" href="#202">202</a>		} <b>else</b> {
<a class="l" name="203" href="#203">203</a>			<a href="/source/s?defs=handler&amp;project=rtmp_client">handler</a>.<a class="d" href="#messageReceived">messageReceived</a>(<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>, <a href="/source/s?defs=session&amp;project=rtmp_client">session</a>);
<a class="l" name="204" href="#204">204</a>		}
<a class="l" name="205" href="#205">205</a>	}
<a class="l" name="206" href="#206">206</a>
<a class="l" name="207" href="#207">207</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="208" href="#208">208</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="209" href="#209">209</a>	<b>public</b> <b>void</b> <a class="xmt" name="messageSent"/><a href="/source/s?refs=messageSent&amp;project=rtmp_client" class="xmt">messageSent</a>(<a href="/source/s?defs=IoSession&amp;project=rtmp_client">IoSession</a> <a class="xa" name="session"/><a href="/source/s?refs=session&amp;project=rtmp_client" class="xa">session</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="message"/><a href="/source/s?refs=message&amp;project=rtmp_client" class="xa">message</a>) <b>throws</b> <a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> {
<a class="hl" name="210" href="#210">210</a>		<span class="c">//log.debug("messageSent");</span>
<a class="l" name="211" href="#211">211</a>		<b>final</b> <a href="/source/s?defs=RTMPMinaConnection&amp;project=rtmp_client">RTMPMinaConnection</a> <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> = (<a href="/source/s?defs=RTMPMinaConnection&amp;project=rtmp_client">RTMPMinaConnection</a>) <a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<a href="/source/s?defs=RTMP_CONNECTION_KEY&amp;project=rtmp_client">RTMP_CONNECTION_KEY</a>);
<a class="l" name="212" href="#212">212</a>		<a href="/source/s?defs=handler&amp;project=rtmp_client">handler</a>.<a class="d" href="#messageSent">messageSent</a>(<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>, <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="213" href="#213">213</a>		<b>if</b> (<a href="/source/s?defs=mode&amp;project=rtmp_client">mode</a> == <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=MODE_CLIENT&amp;project=rtmp_client">MODE_CLIENT</a>) {
<a class="l" name="214" href="#214">214</a>			<b>if</b> (<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> <b>instanceof</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>) {
<a class="l" name="215" href="#215">215</a>				<b>if</b> (((<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>) <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>).<a href="/source/s?defs=limit&amp;project=rtmp_client">limit</a>() == <a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>.<a href="/source/s?defs=HANDSHAKE_SIZE&amp;project=rtmp_client">HANDSHAKE_SIZE</a>) {
<a class="l" name="216" href="#216">216</a>					<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a> = (<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>) <a href="/source/s?defs=session&amp;project=rtmp_client">session</a>.<a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=ProtocolState&amp;project=rtmp_client">ProtocolState</a>.<a href="/source/s?defs=SESSION_KEY&amp;project=rtmp_client">SESSION_KEY</a>);
<a class="l" name="217" href="#217">217</a>					<a href="/source/s?defs=handler&amp;project=rtmp_client">handler</a>.<a href="/source/s?defs=connectionOpened&amp;project=rtmp_client">connectionOpened</a>(<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>, <a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>);
<a class="l" name="218" href="#218">218</a>				}
<a class="l" name="219" href="#219">219</a>			}
<a class="hl" name="220" href="#220">220</a>		}
<a class="l" name="221" href="#221">221</a>	}
<a class="l" name="222" href="#222">222</a>
<a class="l" name="223" href="#223">223</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="224" href="#224">224</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="225" href="#225">225</a>	<b>public</b> <b>void</b> <a class="xmt" name="exceptionCaught"/><a href="/source/s?refs=exceptionCaught&amp;project=rtmp_client" class="xmt">exceptionCaught</a>(<a href="/source/s?defs=IoSession&amp;project=rtmp_client">IoSession</a> <a class="xa" name="session"/><a href="/source/s?refs=session&amp;project=rtmp_client" class="xa">session</a>, <a href="/source/s?defs=Throwable&amp;project=rtmp_client">Throwable</a> <a class="xa" name="cause"/><a href="/source/s?refs=cause&amp;project=rtmp_client" class="xa">cause</a>) <b>throws</b> <a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> {
<a class="l" name="226" href="#226">226</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Exception caught {}"</span>, <a class="d" href="#cause">cause</a>.<a href="/source/s?defs=getMessage&amp;project=rtmp_client">getMessage</a>());
<a class="l" name="227" href="#227">227</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Exception detail {}"</span>, <a class="d" href="#cause">cause</a>);
<a class="l" name="228" href="#228">228</a>		<b>if</b> (<a class="d" href="#log">log</a>.<a href="/source/s?defs=isDebugEnabled&amp;project=rtmp_client">isDebugEnabled</a>()) {
<a class="l" name="229" href="#229">229</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Exception detail"</span>, <a class="d" href="#cause">cause</a>);
<a class="hl" name="230" href="#230">230</a>		}
<a class="l" name="231" href="#231">231</a>	}
<a class="l" name="232" href="#232">232</a>
<a class="l" name="233" href="#233">233</a>	<span class="c">/**
<a class="l" name="234" href="#234">234</a>	 * Setter for handler.
<a class="l" name="235" href="#235">235</a>	 *
<a class="l" name="236" href="#236">236</a>	 * <strong>@param</strong> <em>handler</em> RTMP events handler
<a class="l" name="237" href="#237">237</a>	 */</span>
<a class="l" name="238" href="#238">238</a>	<b>public</b> <b>void</b> <a class="xmt" name="setHandler"/><a href="/source/s?refs=setHandler&amp;project=rtmp_client" class="xmt">setHandler</a>(<a href="/source/s?defs=IRTMPHandler&amp;project=rtmp_client">IRTMPHandler</a> <a class="xa" name="handler"/><a href="/source/s?refs=handler&amp;project=rtmp_client" class="xa">handler</a>) {
<a class="l" name="239" href="#239">239</a>		<b>this</b>.<a href="/source/s?defs=handler&amp;project=rtmp_client">handler</a> = <a href="/source/s?defs=handler&amp;project=rtmp_client">handler</a>;
<a class="hl" name="240" href="#240">240</a>	}
<a class="l" name="241" href="#241">241</a>
<a class="l" name="242" href="#242">242</a>	<span class="c">/**
<a class="l" name="243" href="#243">243</a>	 * Setter for mode.
<a class="l" name="244" href="#244">244</a>	 *
<a class="l" name="245" href="#245">245</a>	 * <strong>@param</strong> <em>mode</em> &lt;code&gt;true&lt;/code&gt; if handler should work in server mode,
<a class="l" name="246" href="#246">246</a>	 *            &lt;code&gt;false&lt;/code&gt; otherwise
<a class="l" name="247" href="#247">247</a>	 */</span>
<a class="l" name="248" href="#248">248</a>	<b>public</b> <b>void</b> <a class="xmt" name="setMode"/><a href="/source/s?refs=setMode&amp;project=rtmp_client" class="xmt">setMode</a>(<b>boolean</b> <a class="xa" name="mode"/><a href="/source/s?refs=mode&amp;project=rtmp_client" class="xa">mode</a>) {
<a class="l" name="249" href="#249">249</a>		<b>this</b>.<a href="/source/s?defs=mode&amp;project=rtmp_client">mode</a> = <a href="/source/s?defs=mode&amp;project=rtmp_client">mode</a>;
<a class="hl" name="250" href="#250">250</a>	}
<a class="l" name="251" href="#251">251</a>
<a class="l" name="252" href="#252">252</a>	<span class="c">/**
<a class="l" name="253" href="#253">253</a>	 * Setter for codec factory.
<a class="l" name="254" href="#254">254</a>	 *
<a class="l" name="255" href="#255">255</a>	 * <strong>@param</strong> <em>codecFactory</em> RTMP protocol codec factory
<a class="l" name="256" href="#256">256</a>	 */</span>
<a class="l" name="257" href="#257">257</a>	<b>public</b> <b>void</b> <a class="xmt" name="setCodecFactory"/><a href="/source/s?refs=setCodecFactory&amp;project=rtmp_client" class="xmt">setCodecFactory</a>(<a href="/source/s?defs=ProtocolCodecFactory&amp;project=rtmp_client">ProtocolCodecFactory</a> <a class="xa" name="codecFactory"/><a href="/source/s?refs=codecFactory&amp;project=rtmp_client" class="xa">codecFactory</a>) {
<a class="l" name="258" href="#258">258</a>		<b>this</b>.<a href="/source/s?defs=codecFactory&amp;project=rtmp_client">codecFactory</a> = <a href="/source/s?defs=codecFactory&amp;project=rtmp_client">codecFactory</a>;
<a class="l" name="259" href="#259">259</a>	}
<a class="hl" name="260" href="#260">260</a>
<a class="l" name="261" href="#261">261</a>	<b>public</b> <b>void</b> <a class="xmt" name="setRtmpConnManager"/><a href="/source/s?refs=setRtmpConnManager&amp;project=rtmp_client" class="xmt">setRtmpConnManager</a>(<a href="/source/s?defs=IRTMPConnManager&amp;project=rtmp_client">IRTMPConnManager</a> <a class="xa" name="rtmpConnManager"/><a href="/source/s?refs=rtmpConnManager&amp;project=rtmp_client" class="xa">rtmpConnManager</a>) {
<a class="l" name="262" href="#262">262</a>		<b>this</b>.<a href="/source/s?defs=rtmpConnManager&amp;project=rtmp_client">rtmpConnManager</a> = <a href="/source/s?defs=rtmpConnManager&amp;project=rtmp_client">rtmpConnManager</a>;
<a class="l" name="263" href="#263">263</a>	}
<a class="l" name="264" href="#264">264</a>
<a class="l" name="265" href="#265">265</a>	<b>protected</b> <a href="/source/s?defs=IRTMPConnManager&amp;project=rtmp_client">IRTMPConnManager</a> <a class="xmt" name="getRtmpConnManager"/><a href="/source/s?refs=getRtmpConnManager&amp;project=rtmp_client" class="xmt">getRtmpConnManager</a>() {
<a class="l" name="266" href="#266">266</a>		<b>return</b> <a href="/source/s?defs=rtmpConnManager&amp;project=rtmp_client">rtmpConnManager</a>;
<a class="l" name="267" href="#267">267</a>	}
<a class="l" name="268" href="#268">268</a>
<a class="l" name="269" href="#269">269</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="270" href="#270">270</a><span class="c">//	public void setApplicationContext(ApplicationContext appCtx) throws BeansException {</span>
<a class="l" name="271" href="#271">271</a><span class="c">//		log.debug("Setting application context: {} {}", appCtx.getDisplayName(), appCtx);</span>
<a class="l" name="272" href="#272">272</a><span class="c">//		this.appCtx = appCtx;</span>
<a class="l" name="273" href="#273">273</a><span class="c">//	}</span>
<a class="l" name="274" href="#274">274</a>
<a class="l" name="275" href="#275">275</a>	<b>protected</b> <a href="/source/s?defs=RTMPMinaConnection&amp;project=rtmp_client">RTMPMinaConnection</a> <a class="xmt" name="createRTMPMinaConnection"/><a href="/source/s?refs=createRTMPMinaConnection&amp;project=rtmp_client" class="xmt">createRTMPMinaConnection</a>() {
<a class="l" name="276" href="#276">276</a>		<b>return</b> (<a href="/source/s?defs=RTMPMinaConnection&amp;project=rtmp_client">RTMPMinaConnection</a>) <a href="/source/s?defs=rtmpConnManager&amp;project=rtmp_client">rtmpConnManager</a>.<a href="/source/s?defs=createConnection&amp;project=rtmp_client">createConnection</a>(<a href="/source/s?defs=RTMPMinaConnection&amp;project=rtmp_client">RTMPMinaConnection</a>.<b>class</b>);
<a class="l" name="277" href="#277">277</a>	}
<a class="l" name="278" href="#278">278</a>}
<a class="l" name="279" href="#279">279</a>