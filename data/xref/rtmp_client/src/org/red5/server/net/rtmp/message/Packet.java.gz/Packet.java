<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["Packet",33]]],["Package","xp",[["org.red5.server.net.rtmp.message",1]]],["Method","xmt",[["Packet",52],["Packet",60],["Packet",73],["getData",119],["getHeader",83],["getMessage",101],["readExternal",123],["setData",110],["setMessage",92],["writeExternal",130]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=Externalizable&amp;project=rtmp_client">Externalizable</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=ObjectInput&amp;project=rtmp_client">ObjectInput</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=ObjectOutput&amp;project=rtmp_client">ObjectOutput</a>;
<a class="l" name="26" href="#26">26</a>
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a class="d" href="#event">event</a>.<a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a>;
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a><span class="c">/**
<a class="l" name="31" href="#31">31</a> * RTMP packet. Consists of packet header, data and event context.
<a class="l" name="32" href="#32">32</a> */</span>
<a class="l" name="33" href="#33">33</a><b>public</b> <b>class</b> <a class="xc" name="Packet"/><a href="/source/s?refs=Packet&amp;project=rtmp_client" class="xc">Packet</a> <b>implements</b> <a href="/source/s?defs=Externalizable&amp;project=rtmp_client">Externalizable</a> {
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a>	<b>private</b> <b>static</b> <b>final</b> <b>long</b> <a class="xfld" name="serialVersionUID"/><a href="/source/s?refs=serialVersionUID&amp;project=rtmp_client" class="xfld">serialVersionUID</a> = -<span class="n">6415050845346626950L</span>;
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a>	<span class="c">/**
<a class="l" name="38" href="#38">38</a>     * Header
<a class="l" name="39" href="#39">39</a>     */</span>
<a class="hl" name="40" href="#40">40</a>	<b>private</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xfld" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xfld">header</a>;
<a class="l" name="41" href="#41">41</a>
<a class="l" name="42" href="#42">42</a>	<span class="c">/**
<a class="l" name="43" href="#43">43</a>     * RTMP event
<a class="l" name="44" href="#44">44</a>     */</span>
<a class="l" name="45" href="#45">45</a>	<b>private</b> <a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a> <a class="xfld" name="message"/><a href="/source/s?refs=message&amp;project=rtmp_client" class="xfld">message</a>;
<a class="l" name="46" href="#46">46</a>
<a class="l" name="47" href="#47">47</a>	<span class="c">/**
<a class="l" name="48" href="#48">48</a>     * Packet data
<a class="l" name="49" href="#49">49</a>     */</span>
<a class="hl" name="50" href="#50">50</a>	<b>private</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xfld" name="data"/><a href="/source/s?refs=data&amp;project=rtmp_client" class="xfld">data</a>;
<a class="l" name="51" href="#51">51</a>
<a class="l" name="52" href="#52">52</a>	<b>public</b> <a class="xmt" name="Packet"/><a href="/source/s?refs=Packet&amp;project=rtmp_client" class="xmt">Packet</a>() {
<a class="l" name="53" href="#53">53</a>		<a href="/source/s?defs=data&amp;project=rtmp_client">data</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="54" href="#54">54</a>		<a href="/source/s?defs=header&amp;project=rtmp_client">header</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="55" href="#55">55</a>	}
<a class="l" name="56" href="#56">56</a>    <span class="c">/**
<a class="l" name="57" href="#57">57</a>     * Create packet with given header
<a class="l" name="58" href="#58">58</a>     * <strong>@param</strong> <em>header</em>       Packet header
<a class="l" name="59" href="#59">59</a>     */</span>
<a class="hl" name="60" href="#60">60</a>    <b>public</b> <a class="xmt" name="Packet"/><a href="/source/s?refs=Packet&amp;project=rtmp_client" class="xmt">Packet</a>(<a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xa">header</a>) {
<a class="l" name="61" href="#61">61</a>		<b>this</b>.<a href="/source/s?defs=header&amp;project=rtmp_client">header</a> = <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>;
<a class="l" name="62" href="#62">62</a>		<a href="/source/s?defs=data&amp;project=rtmp_client">data</a> = <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>.<a href="/source/s?defs=allocate&amp;project=rtmp_client">allocate</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getSize&amp;project=rtmp_client">getSize</a>(), <b>false</b>);
<a class="l" name="63" href="#63">63</a>		<span class="c">// Workaround for SN-19: BufferOverflowException</span>
<a class="l" name="64" href="#64">64</a>		<span class="c">// Size is checked in RTMPProtocolDecoder</span>
<a class="l" name="65" href="#65">65</a>		<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>.<a href="/source/s?defs=setAutoExpand&amp;project=rtmp_client">setAutoExpand</a>(<b>true</b>);
<a class="l" name="66" href="#66">66</a>	}
<a class="l" name="67" href="#67">67</a>
<a class="l" name="68" href="#68">68</a>    <span class="c">/**
<a class="l" name="69" href="#69">69</a>     * Create packet with given header and event context
<a class="hl" name="70" href="#70">70</a>     * <strong>@param</strong> <em>header</em>     RTMP header
<a class="l" name="71" href="#71">71</a>     * <strong>@param</strong> <em>event</em>      RTMP message
<a class="l" name="72" href="#72">72</a>     */</span>
<a class="l" name="73" href="#73">73</a>    <b>public</b> <a class="xmt" name="Packet"/><a href="/source/s?refs=Packet&amp;project=rtmp_client" class="xmt">Packet</a>(<a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xa" name="header"/><a href="/source/s?refs=header&amp;project=rtmp_client" class="xa">header</a>, <a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a> <a class="xa" name="event"/><a href="/source/s?refs=event&amp;project=rtmp_client" class="xa">event</a>) {
<a class="l" name="74" href="#74">74</a>		<b>this</b>.<a href="/source/s?defs=header&amp;project=rtmp_client">header</a> = <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>;
<a class="l" name="75" href="#75">75</a>		<b>this</b>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a class="d" href="#event">event</a>;
<a class="l" name="76" href="#76">76</a>	}
<a class="l" name="77" href="#77">77</a>
<a class="l" name="78" href="#78">78</a>	<span class="c">/**
<a class="l" name="79" href="#79">79</a>     * Getter for header
<a class="hl" name="80" href="#80">80</a>     *
<a class="l" name="81" href="#81">81</a>     * <strong>@return</strong>  Packet header
<a class="l" name="82" href="#82">82</a>     */</span>
<a class="l" name="83" href="#83">83</a>    <b>public</b> <a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a> <a class="xmt" name="getHeader"/><a href="/source/s?refs=getHeader&amp;project=rtmp_client" class="xmt">getHeader</a>() {
<a class="l" name="84" href="#84">84</a>		<b>return</b> <a href="/source/s?defs=header&amp;project=rtmp_client">header</a>;
<a class="l" name="85" href="#85">85</a>	}
<a class="l" name="86" href="#86">86</a>
<a class="l" name="87" href="#87">87</a>	<span class="c">/**
<a class="l" name="88" href="#88">88</a>     * Setter for event context
<a class="l" name="89" href="#89">89</a>     *
<a class="hl" name="90" href="#90">90</a>     * <strong>@param</strong> <em>message</em>  RTMP event context
<a class="l" name="91" href="#91">91</a>     */</span>
<a class="l" name="92" href="#92">92</a>    <b>public</b> <b>void</b> <a class="xmt" name="setMessage"/><a href="/source/s?refs=setMessage&amp;project=rtmp_client" class="xmt">setMessage</a>(<a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a> <a class="xa" name="message"/><a href="/source/s?refs=message&amp;project=rtmp_client" class="xa">message</a>) {
<a class="l" name="93" href="#93">93</a>		<b>this</b>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>;
<a class="l" name="94" href="#94">94</a>	}
<a class="l" name="95" href="#95">95</a>
<a class="l" name="96" href="#96">96</a>	<span class="c">/**
<a class="l" name="97" href="#97">97</a>     * Getter for event context
<a class="l" name="98" href="#98">98</a>     *
<a class="l" name="99" href="#99">99</a>     * <strong>@return</strong> RTMP event context
<a class="hl" name="100" href="#100">100</a>     */</span>
<a class="l" name="101" href="#101">101</a>    <b>public</b> <a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a> <a class="xmt" name="getMessage"/><a href="/source/s?refs=getMessage&amp;project=rtmp_client" class="xmt">getMessage</a>() {
<a class="l" name="102" href="#102">102</a>		<b>return</b> <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>;
<a class="l" name="103" href="#103">103</a>	}
<a class="l" name="104" href="#104">104</a>
<a class="l" name="105" href="#105">105</a>	<span class="c">/**
<a class="l" name="106" href="#106">106</a>     * Setter for data
<a class="l" name="107" href="#107">107</a>     *
<a class="l" name="108" href="#108">108</a>     * <strong>@param</strong> <em>data</em> Packet data
<a class="l" name="109" href="#109">109</a>     */</span>
<a class="hl" name="110" href="#110">110</a>    <b>public</b> <b>void</b> <a class="xmt" name="setData"/><a href="/source/s?refs=setData&amp;project=rtmp_client" class="xmt">setData</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="data"/><a href="/source/s?refs=data&amp;project=rtmp_client" class="xa">data</a>) {
<a class="l" name="111" href="#111">111</a>		<b>this</b>.<a href="/source/s?defs=data&amp;project=rtmp_client">data</a> = <a href="/source/s?defs=data&amp;project=rtmp_client">data</a>;
<a class="l" name="112" href="#112">112</a>	}
<a class="l" name="113" href="#113">113</a>
<a class="l" name="114" href="#114">114</a>	<span class="c">/**
<a class="l" name="115" href="#115">115</a>     * Getter for data
<a class="l" name="116" href="#116">116</a>     *
<a class="l" name="117" href="#117">117</a>     * <strong>@return</strong> Packet data
<a class="l" name="118" href="#118">118</a>     */</span>
<a class="l" name="119" href="#119">119</a>    <b>public</b> <a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xmt" name="getData"/><a href="/source/s?refs=getData&amp;project=rtmp_client" class="xmt">getData</a>() {
<a class="hl" name="120" href="#120">120</a>		<b>return</b> <a href="/source/s?defs=data&amp;project=rtmp_client">data</a>;
<a class="l" name="121" href="#121">121</a>	}
<a class="l" name="122" href="#122">122</a>
<a class="l" name="123" href="#123">123</a>	<b>public</b> <b>void</b> <a class="xmt" name="readExternal"/><a href="/source/s?refs=readExternal&amp;project=rtmp_client" class="xmt">readExternal</a>(<a href="/source/s?defs=ObjectInput&amp;project=rtmp_client">ObjectInput</a> <a class="xa" name="in"/><a href="/source/s?refs=in&amp;project=rtmp_client" class="xa">in</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>, <a href="/source/s?defs=ClassNotFoundException&amp;project=rtmp_client">ClassNotFoundException</a> {
<a class="l" name="124" href="#124">124</a>		<a href="/source/s?defs=header&amp;project=rtmp_client">header</a> = (<a href="/source/s?defs=Header&amp;project=rtmp_client">Header</a>) <a class="d" href="#in">in</a>.<a href="/source/s?defs=readObject&amp;project=rtmp_client">readObject</a>();
<a class="l" name="125" href="#125">125</a>		<a href="/source/s?defs=message&amp;project=rtmp_client">message</a> = (<a href="/source/s?defs=IRTMPEvent&amp;project=rtmp_client">IRTMPEvent</a>) <a class="d" href="#in">in</a>.<a href="/source/s?defs=readObject&amp;project=rtmp_client">readObject</a>();
<a class="l" name="126" href="#126">126</a>		<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=setHeader&amp;project=rtmp_client">setHeader</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>);
<a class="l" name="127" href="#127">127</a>		<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=setTimestamp&amp;project=rtmp_client">setTimestamp</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>.<a href="/source/s?defs=getTimer&amp;project=rtmp_client">getTimer</a>());
<a class="l" name="128" href="#128">128</a>	}
<a class="l" name="129" href="#129">129</a>
<a class="hl" name="130" href="#130">130</a>	<b>public</b> <b>void</b> <a class="xmt" name="writeExternal"/><a href="/source/s?refs=writeExternal&amp;project=rtmp_client" class="xmt">writeExternal</a>(<a href="/source/s?defs=ObjectOutput&amp;project=rtmp_client">ObjectOutput</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="131" href="#131">131</a>		<a class="d" href="#out">out</a>.<a href="/source/s?defs=writeObject&amp;project=rtmp_client">writeObject</a>(<a href="/source/s?defs=header&amp;project=rtmp_client">header</a>);
<a class="l" name="132" href="#132">132</a>		<a class="d" href="#out">out</a>.<a href="/source/s?defs=writeObject&amp;project=rtmp_client">writeObject</a>(<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>);
<a class="l" name="133" href="#133">133</a>	}
<a class="l" name="134" href="#134">134</a>}
<a class="l" name="135" href="#135">135</a>