<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["RTMPHandshake",61]]],["Package","xp",[["org.red5.server.net.rtmp",1]]],["Method","xmt",[["RTMPHandshake",146],["calculateHMAC_SHA256",166],["calculateHMAC_SHA256",185],["createHandshakeBytes",266],["generateKeyPair",201],["getCipherIn",425],["getCipherOut",415],["getDHOffset",282],["getDHOffset0",301],["getDHOffset1",316],["getDigestOffset",332],["getDigestOffset0",352],["getDigestOffset1",371],["getHandshakeBytes",387],["getHandshakeType",406],["getPublicKey",222],["getSharedSecret",248],["setHandshakeType",396],["validate",274]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=math&amp;project=rtmp_client">math</a>.<a href="/source/s?defs=BigInteger&amp;project=rtmp_client">BigInteger</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=security&amp;project=rtmp_client">security</a>.<a href="/source/s?defs=InvalidKeyException&amp;project=rtmp_client">InvalidKeyException</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=security&amp;project=rtmp_client">security</a>.<a href="/source/s?defs=KeyFactory&amp;project=rtmp_client">KeyFactory</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=security&amp;project=rtmp_client">security</a>.<a href="/source/s?defs=KeyPair&amp;project=rtmp_client">KeyPair</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=security&amp;project=rtmp_client">security</a>.<a href="/source/s?defs=KeyPairGenerator&amp;project=rtmp_client">KeyPairGenerator</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=security&amp;project=rtmp_client">security</a>.<a href="/source/s?defs=NoSuchAlgorithmException&amp;project=rtmp_client">NoSuchAlgorithmException</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=security&amp;project=rtmp_client">security</a>.<a href="/source/s?defs=PublicKey&amp;project=rtmp_client">PublicKey</a>;
<a class="l" name="29" href="#29">29</a><span class="c">//import java.security.Security;</span>
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=security&amp;project=rtmp_client">security</a>.<a href="/source/s?defs=spec&amp;project=rtmp_client">spec</a>.<a href="/source/s?defs=KeySpec&amp;project=rtmp_client">KeySpec</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Random&amp;project=rtmp_client">Random</a>;
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=crypto&amp;project=rtmp_client">crypto</a>.<a href="/source/s?defs=Cipher&amp;project=rtmp_client">Cipher</a>;
<a class="l" name="34" href="#34">34</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=crypto&amp;project=rtmp_client">crypto</a>.<a href="/source/s?defs=KeyAgreement&amp;project=rtmp_client">KeyAgreement</a>;
<a class="l" name="35" href="#35">35</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=crypto&amp;project=rtmp_client">crypto</a>.<a href="/source/s?defs=Mac&amp;project=rtmp_client">Mac</a>;
<a class="l" name="36" href="#36">36</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=crypto&amp;project=rtmp_client">crypto</a>.<a href="/source/s?defs=interfaces&amp;project=rtmp_client">interfaces</a>.<a href="/source/s?defs=DHPublicKey&amp;project=rtmp_client">DHPublicKey</a>;
<a class="l" name="37" href="#37">37</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=crypto&amp;project=rtmp_client">crypto</a>.<a href="/source/s?defs=spec&amp;project=rtmp_client">spec</a>.<a href="/source/s?defs=DHParameterSpec&amp;project=rtmp_client">DHParameterSpec</a>;
<a class="l" name="38" href="#38">38</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=crypto&amp;project=rtmp_client">crypto</a>.<a href="/source/s?defs=spec&amp;project=rtmp_client">spec</a>.<a href="/source/s?defs=DHPublicKeySpec&amp;project=rtmp_client">DHPublicKeySpec</a>;
<a class="l" name="39" href="#39">39</a><b>import</b> <a href="/source/s?defs=javax&amp;project=rtmp_client">javax</a>.<a href="/source/s?defs=crypto&amp;project=rtmp_client">crypto</a>.<a href="/source/s?defs=spec&amp;project=rtmp_client">spec</a>.<a href="/source/s?defs=SecretKeySpec&amp;project=rtmp_client">SecretKeySpec</a>;
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a><span class="c">//import org.apache.commons.codec.binary.Hex;</span>
<a class="l" name="42" href="#42">42</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="43" href="#43">43</a><span class="c">//import org.bouncycastle.jce.provider.BouncyCastleProvider;</span>
<a class="l" name="44" href="#44">44</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=IHandshake&amp;project=rtmp_client">IHandshake</a>;
<a class="l" name="45" href="#45">45</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>;
<a class="l" name="46" href="#46">46</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="47" href="#47">47</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a><span class="c">/**
<a class="hl" name="50" href="#50">50</a> * Generates and validates the RTMP handshake response for Flash Players.
<a class="l" name="51" href="#51">51</a> * Client versions equal to or greater than Flash 9,0,124,0 require a nonzero
<a class="l" name="52" href="#52">52</a> * value as the fifth byte of the handshake request.
<a class="l" name="53" href="#53">53</a> *
<a class="l" name="54" href="#54">54</a> * <strong>@author</strong> Jacinto Shy II (jacinto.m.shy@ieee.org)
<a class="l" name="55" href="#55">55</a> * <strong>@author</strong> Steven Zimmer (stevenlzimmer@gmail.com)
<a class="l" name="56" href="#56">56</a> * <strong>@author</strong> Gavriloaie Eugen-Andrei
<a class="l" name="57" href="#57">57</a> * <strong>@author</strong> Ari-Pekka Viitanen
<a class="l" name="58" href="#58">58</a> * <strong>@author</strong> Paul Gregoire
<a class="l" name="59" href="#59">59</a> * <strong>@author</strong> Tiago Jacobs
<a class="hl" name="60" href="#60">60</a> */</span>
<a class="l" name="61" href="#61">61</a><b>public</b> <b>abstract</b> <b>class</b> <a class="xc" name="RTMPHandshake"/><a href="/source/s?refs=RTMPHandshake&amp;project=rtmp_client" class="xc">RTMPHandshake</a> <b>implements</b> <a href="/source/s?defs=IHandshake&amp;project=rtmp_client">IHandshake</a> {
<a class="l" name="62" href="#62">62</a>
<a class="l" name="63" href="#63">63</a>	<b>protected</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a href="/source/s?defs=RTMPHandshake&amp;project=rtmp_client">RTMPHandshake</a>.<b>class</b>);
<a class="l" name="64" href="#64">64</a>
<a class="l" name="65" href="#65">65</a>	<span class="c">//for old style handshake</span>
<a class="l" name="66" href="#66">66</a>	<b>public</b> <b>static</b> <b>byte</b>[] <a class="xfld" name="HANDSHAKE_PAD_BYTES"/><a href="/source/s?refs=HANDSHAKE_PAD_BYTES&amp;project=rtmp_client" class="xfld">HANDSHAKE_PAD_BYTES</a>;
<a class="l" name="67" href="#67">67</a>
<a class="l" name="68" href="#68">68</a>	<b>protected</b> <b>static</b> <b>final</b> <b>byte</b>[] <a class="xfld" name="GENUINE_FMS_KEY"/><a href="/source/s?refs=GENUINE_FMS_KEY&amp;project=rtmp_client" class="xfld">GENUINE_FMS_KEY</a> = {
<a class="l" name="69" href="#69">69</a>		(<b>byte</b>) <span class="n">0x47</span>, (<b>byte</b>) <span class="n">0x65</span>, (<b>byte</b>) <span class="n">0x6e</span>, (<b>byte</b>) <span class="n">0x75</span>, (<b>byte</b>) <span class="n">0x69</span>, (<b>byte</b>) <span class="n">0x6e</span>, (<b>byte</b>) <span class="n">0x65</span>, (<b>byte</b>) <span class="n">0x20</span>,
<a class="hl" name="70" href="#70">70</a>		(<b>byte</b>) <span class="n">0x41</span>, (<b>byte</b>) <span class="n">0x64</span>, (<b>byte</b>) <span class="n">0x6f</span>, (<b>byte</b>) <span class="n">0x62</span>, (<b>byte</b>) <span class="n">0x65</span>, (<b>byte</b>) <span class="n">0x20</span>, (<b>byte</b>) <span class="n">0x46</span>, (<b>byte</b>) <span class="n">0x6c</span>,
<a class="l" name="71" href="#71">71</a>		(<b>byte</b>) <span class="n">0x61</span>, (<b>byte</b>) <span class="n">0x73</span>, (<b>byte</b>) <span class="n">0x68</span>, (<b>byte</b>) <span class="n">0x20</span>, (<b>byte</b>) <span class="n">0x4d</span>, (<b>byte</b>) <span class="n">0x65</span>, (<b>byte</b>) <span class="n">0x64</span>, (<b>byte</b>) <span class="n">0x69</span>,
<a class="l" name="72" href="#72">72</a>		(<b>byte</b>) <span class="n">0x61</span>, (<b>byte</b>) <span class="n">0x20</span>, (<b>byte</b>) <span class="n">0x53</span>, (<b>byte</b>) <span class="n">0x65</span>, (<b>byte</b>) <span class="n">0x72</span>, (<b>byte</b>) <span class="n">0x76</span>, (<b>byte</b>) <span class="n">0x65</span>, (<b>byte</b>) <span class="n">0x72</span>,
<a class="l" name="73" href="#73">73</a>		(<b>byte</b>) <span class="n">0x20</span>, (<b>byte</b>) <span class="n">0x30</span>, (<b>byte</b>) <span class="n">0x30</span>, (<b>byte</b>) <span class="n">0x31</span>, <span class="c">// Genuine Adobe Flash Media Server 001</span>
<a class="l" name="74" href="#74">74</a>		(<b>byte</b>) <span class="n">0xf0</span>, (<b>byte</b>) <span class="n">0xee</span>, (<b>byte</b>) <span class="n">0xc2</span>, (<b>byte</b>) <span class="n">0x4a</span>, (<b>byte</b>) <span class="n">0x80</span>, (<b>byte</b>) <span class="n">0x68</span>, (<b>byte</b>) <span class="n">0xbe</span>, (<b>byte</b>) <span class="n">0xe8</span>,
<a class="l" name="75" href="#75">75</a>		(<b>byte</b>) <span class="n">0x2e</span>, (<b>byte</b>) <span class="n">0x00</span>, (<b>byte</b>) <span class="n">0xd0</span>, (<b>byte</b>) <span class="n">0xd1</span>, (<b>byte</b>) <span class="n">0x02</span>, (<b>byte</b>) <span class="n">0x9e</span>, (<b>byte</b>) <span class="n">0x7e</span>, (<b>byte</b>) <span class="n">0x57</span>,
<a class="l" name="76" href="#76">76</a>		(<b>byte</b>) <span class="n">0x6e</span>, (<b>byte</b>) <span class="n">0xec</span>, (<b>byte</b>) <span class="n">0x5d</span>, (<b>byte</b>) <span class="n">0x2d</span>, (<b>byte</b>) <span class="n">0x29</span>, (<b>byte</b>) <span class="n">0x80</span>, (<b>byte</b>) <span class="n">0x6f</span>, (<b>byte</b>) <span class="n">0xab</span>,
<a class="l" name="77" href="#77">77</a>		(<b>byte</b>) <span class="n">0x93</span>, (<b>byte</b>) <span class="n">0xb8</span>, (<b>byte</b>) <span class="n">0xe6</span>, (<b>byte</b>) <span class="n">0x36</span>, (<b>byte</b>) <span class="n">0xcf</span>, (<b>byte</b>) <span class="n">0xeb</span>, (<b>byte</b>) <span class="n">0x31</span>, (<b>byte</b>) <span class="n">0xae</span>};
<a class="l" name="78" href="#78">78</a>
<a class="l" name="79" href="#79">79</a>	<b>protected</b> <b>static</b> <b>final</b> <b>byte</b>[] <a class="xfld" name="GENUINE_FP_KEY"/><a href="/source/s?refs=GENUINE_FP_KEY&amp;project=rtmp_client" class="xfld">GENUINE_FP_KEY</a> = {
<a class="hl" name="80" href="#80">80</a>		(<b>byte</b>) <span class="n">0x47</span>, (<b>byte</b>) <span class="n">0x65</span>, (<b>byte</b>) <span class="n">0x6E</span>, (<b>byte</b>) <span class="n">0x75</span>, (<b>byte</b>) <span class="n">0x69</span>, (<b>byte</b>) <span class="n">0x6E</span>, (<b>byte</b>) <span class="n">0x65</span>, (<b>byte</b>) <span class="n">0x20</span>,
<a class="l" name="81" href="#81">81</a>		(<b>byte</b>) <span class="n">0x41</span>, (<b>byte</b>) <span class="n">0x64</span>, (<b>byte</b>) <span class="n">0x6F</span>, (<b>byte</b>) <span class="n">0x62</span>, (<b>byte</b>) <span class="n">0x65</span>, (<b>byte</b>) <span class="n">0x20</span>, (<b>byte</b>) <span class="n">0x46</span>, (<b>byte</b>) <span class="n">0x6C</span>,
<a class="l" name="82" href="#82">82</a>		(<b>byte</b>) <span class="n">0x61</span>, (<b>byte</b>) <span class="n">0x73</span>, (<b>byte</b>) <span class="n">0x68</span>, (<b>byte</b>) <span class="n">0x20</span>, (<b>byte</b>) <span class="n">0x50</span>, (<b>byte</b>) <span class="n">0x6C</span>, (<b>byte</b>) <span class="n">0x61</span>, (<b>byte</b>) <span class="n">0x79</span>,
<a class="l" name="83" href="#83">83</a>		(<b>byte</b>) <span class="n">0x65</span>, (<b>byte</b>) <span class="n">0x72</span>, (<b>byte</b>) <span class="n">0x20</span>, (<b>byte</b>) <span class="n">0x30</span>, (<b>byte</b>) <span class="n">0x30</span>, (<b>byte</b>) <span class="n">0x31</span>, <span class="c">// Genuine Adobe Flash Player 001</span>
<a class="l" name="84" href="#84">84</a>		(<b>byte</b>) <span class="n">0xF0</span>, (<b>byte</b>) <span class="n">0xEE</span>, (<b>byte</b>) <span class="n">0xC2</span>, (<b>byte</b>) <span class="n">0x4A</span>, (<b>byte</b>) <span class="n">0x80</span>, (<b>byte</b>) <span class="n">0x68</span>, (<b>byte</b>) <span class="n">0xBE</span>, (<b>byte</b>) <span class="n">0xE8</span>,
<a class="l" name="85" href="#85">85</a>		(<b>byte</b>) <span class="n">0x2E</span>, (<b>byte</b>) <span class="n">0x00</span>, (<b>byte</b>) <span class="n">0xD0</span>, (<b>byte</b>) <span class="n">0xD1</span>, (<b>byte</b>) <span class="n">0x02</span>, (<b>byte</b>) <span class="n">0x9E</span>, (<b>byte</b>) <span class="n">0x7E</span>, (<b>byte</b>) <span class="n">0x57</span>,
<a class="l" name="86" href="#86">86</a>		(<b>byte</b>) <span class="n">0x6E</span>, (<b>byte</b>) <span class="n">0xEC</span>, (<b>byte</b>) <span class="n">0x5D</span>, (<b>byte</b>) <span class="n">0x2D</span>, (<b>byte</b>) <span class="n">0x29</span>, (<b>byte</b>) <span class="n">0x80</span>, (<b>byte</b>) <span class="n">0x6F</span>, (<b>byte</b>) <span class="n">0xAB</span>,
<a class="l" name="87" href="#87">87</a>		(<b>byte</b>) <span class="n">0x93</span>, (<b>byte</b>) <span class="n">0xB8</span>, (<b>byte</b>) <span class="n">0xE6</span>, (<b>byte</b>) <span class="n">0x36</span>, (<b>byte</b>) <span class="n">0xCF</span>, (<b>byte</b>) <span class="n">0xEB</span>, (<b>byte</b>) <span class="n">0x31</span>, (<b>byte</b>) <span class="n">0xAE</span>};
<a class="l" name="88" href="#88">88</a>
<a class="l" name="89" href="#89">89</a>	<span class="c">/** Modulus bytes from flazr */</span>
<a class="hl" name="90" href="#90">90</a>	<b>protected</b> <b>static</b> <b>final</b> <b>byte</b>[] <a class="xfld" name="DH_MODULUS_BYTES"/><a href="/source/s?refs=DH_MODULUS_BYTES&amp;project=rtmp_client" class="xfld">DH_MODULUS_BYTES</a> = { (<b>byte</b>) <span class="n">0xff</span>, (<b>byte</b>) <span class="n">0xff</span>, (<b>byte</b>) <span class="n">0xff</span>, (<b>byte</b>) <span class="n">0xff</span>, (<b>byte</b>) <span class="n">0xff</span>,
<a class="l" name="91" href="#91">91</a>			(<b>byte</b>) <span class="n">0xff</span>, (<b>byte</b>) <span class="n">0xff</span>, (<b>byte</b>) <span class="n">0xff</span>, (<b>byte</b>) <span class="n">0xc9</span>, (<b>byte</b>) <span class="n">0x0f</span>, (<b>byte</b>) <span class="n">0xda</span>, (<b>byte</b>) <span class="n">0xa2</span>, (<b>byte</b>) <span class="n">0x21</span>,
<a class="l" name="92" href="#92">92</a>			(<b>byte</b>) <span class="n">0x68</span>, (<b>byte</b>) <span class="n">0xc2</span>, (<b>byte</b>) <span class="n">0x34</span>, (<b>byte</b>) <span class="n">0xc4</span>, (<b>byte</b>) <span class="n">0xc6</span>, (<b>byte</b>) <span class="n">0x62</span>, (<b>byte</b>) <span class="n">0x8b</span>, (<b>byte</b>) <span class="n">0x80</span>,
<a class="l" name="93" href="#93">93</a>			(<b>byte</b>) <span class="n">0xdc</span>, (<b>byte</b>) <span class="n">0x1c</span>, (<b>byte</b>) <span class="n">0xd1</span>, (<b>byte</b>) <span class="n">0x29</span>, (<b>byte</b>) <span class="n">0x02</span>, (<b>byte</b>) <span class="n">0x4e</span>, (<b>byte</b>) <span class="n">0x08</span>, (<b>byte</b>) <span class="n">0x8a</span>,
<a class="l" name="94" href="#94">94</a>			(<b>byte</b>) <span class="n">0x67</span>, (<b>byte</b>) <span class="n">0xcc</span>, (<b>byte</b>) <span class="n">0x74</span>, (<b>byte</b>) <span class="n">0x02</span>, (<b>byte</b>) <span class="n">0x0b</span>, (<b>byte</b>) <span class="n">0xbe</span>, (<b>byte</b>) <span class="n">0xa6</span>, (<b>byte</b>) <span class="n">0x3b</span>,
<a class="l" name="95" href="#95">95</a>			(<b>byte</b>) <span class="n">0x13</span>, (<b>byte</b>) <span class="n">0x9b</span>, (<b>byte</b>) <span class="n">0x22</span>, (<b>byte</b>) <span class="n">0x51</span>, (<b>byte</b>) <span class="n">0x4a</span>, (<b>byte</b>) <span class="n">0x08</span>, (<b>byte</b>) <span class="n">0x79</span>, (<b>byte</b>) <span class="n">0x8e</span>,
<a class="l" name="96" href="#96">96</a>			(<b>byte</b>) <span class="n">0x34</span>, (<b>byte</b>) <span class="n">0x04</span>, (<b>byte</b>) <span class="n">0xdd</span>, (<b>byte</b>) <span class="n">0xef</span>, (<b>byte</b>) <span class="n">0x95</span>, (<b>byte</b>) <span class="n">0x19</span>, (<b>byte</b>) <span class="n">0xb3</span>, (<b>byte</b>) <span class="n">0xcd</span>,
<a class="l" name="97" href="#97">97</a>			(<b>byte</b>) <span class="n">0x3a</span>, (<b>byte</b>) <span class="n">0x43</span>, (<b>byte</b>) <span class="n">0x1b</span>, (<b>byte</b>) <span class="n">0x30</span>, (<b>byte</b>) <span class="n">0x2b</span>, (<b>byte</b>) <span class="n">0x0a</span>, (<b>byte</b>) <span class="n">0x6d</span>, (<b>byte</b>) <span class="n">0xf2</span>,
<a class="l" name="98" href="#98">98</a>			(<b>byte</b>) <span class="n">0x5f</span>, (<b>byte</b>) <span class="n">0x14</span>, (<b>byte</b>) <span class="n">0x37</span>, (<b>byte</b>) <span class="n">0x4f</span>, (<b>byte</b>) <span class="n">0xe1</span>, (<b>byte</b>) <span class="n">0x35</span>, (<b>byte</b>) <span class="n">0x6d</span>, (<b>byte</b>) <span class="n">0x6d</span>,
<a class="l" name="99" href="#99">99</a>			(<b>byte</b>) <span class="n">0x51</span>, (<b>byte</b>) <span class="n">0xc2</span>, (<b>byte</b>) <span class="n">0x45</span>, (<b>byte</b>) <span class="n">0xe4</span>, (<b>byte</b>) <span class="n">0x85</span>, (<b>byte</b>) <span class="n">0xb5</span>, (<b>byte</b>) <span class="n">0x76</span>, (<b>byte</b>) <span class="n">0x62</span>,
<a class="hl" name="100" href="#100">100</a>			(<b>byte</b>) <span class="n">0x5e</span>, (<b>byte</b>) <span class="n">0x7e</span>, (<b>byte</b>) <span class="n">0xc6</span>, (<b>byte</b>) <span class="n">0xf4</span>, (<b>byte</b>) <span class="n">0x4c</span>, (<b>byte</b>) <span class="n">0x42</span>, (<b>byte</b>) <span class="n">0xe9</span>, (<b>byte</b>) <span class="n">0xa6</span>,
<a class="l" name="101" href="#101">101</a>			(<b>byte</b>) <span class="n">0x37</span>, (<b>byte</b>) <span class="n">0xed</span>, (<b>byte</b>) <span class="n">0x6b</span>, (<b>byte</b>) <span class="n">0x0b</span>, (<b>byte</b>) <span class="n">0xff</span>, (<b>byte</b>) <span class="n">0x5c</span>, (<b>byte</b>) <span class="n">0xb6</span>, (<b>byte</b>) <span class="n">0xf4</span>,
<a class="l" name="102" href="#102">102</a>			(<b>byte</b>) <span class="n">0x06</span>, (<b>byte</b>) <span class="n">0xb7</span>, (<b>byte</b>) <span class="n">0xed</span>, (<b>byte</b>) <span class="n">0xee</span>, (<b>byte</b>) <span class="n">0x38</span>, (<b>byte</b>) <span class="n">0x6b</span>, (<b>byte</b>) <span class="n">0xfb</span>, (<b>byte</b>) <span class="n">0x5a</span>,
<a class="l" name="103" href="#103">103</a>			(<b>byte</b>) <span class="n">0x89</span>, (<b>byte</b>) <span class="n">0x9f</span>, (<b>byte</b>) <span class="n">0xa5</span>, (<b>byte</b>) <span class="n">0xae</span>, (<b>byte</b>) <span class="n">0x9f</span>, (<b>byte</b>) <span class="n">0x24</span>, (<b>byte</b>) <span class="n">0x11</span>, (<b>byte</b>) <span class="n">0x7c</span>,
<a class="l" name="104" href="#104">104</a>			(<b>byte</b>) <span class="n">0x4b</span>, (<b>byte</b>) <span class="n">0x1f</span>, (<b>byte</b>) <span class="n">0xe6</span>, (<b>byte</b>) <span class="n">0x49</span>, (<b>byte</b>) <span class="n">0x28</span>, (<b>byte</b>) <span class="n">0x66</span>, (<b>byte</b>) <span class="n">0x51</span>, (<b>byte</b>) <span class="n">0xec</span>,
<a class="l" name="105" href="#105">105</a>			(<b>byte</b>) <span class="n">0xe6</span>, (<b>byte</b>) <span class="n">0x53</span>, (<b>byte</b>) <span class="n">0x81</span>, (<b>byte</b>) <span class="n">0xff</span>, (<b>byte</b>) <span class="n">0xff</span>, (<b>byte</b>) <span class="n">0xff</span>, (<b>byte</b>) <span class="n">0xff</span>, (<b>byte</b>) <span class="n">0xff</span>,
<a class="l" name="106" href="#106">106</a>			(<b>byte</b>) <span class="n">0xff</span>, (<b>byte</b>) <span class="n">0xff</span>, (<b>byte</b>) <span class="n">0xff</span> };
<a class="l" name="107" href="#107">107</a>
<a class="l" name="108" href="#108">108</a>    <b>protected</b> <b>static</b> <b>final</b> <a href="/source/s?defs=BigInteger&amp;project=rtmp_client">BigInteger</a> <a class="xfld" name="DH_MODULUS"/><a href="/source/s?refs=DH_MODULUS&amp;project=rtmp_client" class="xfld">DH_MODULUS</a> = <b>new</b> <a href="/source/s?defs=BigInteger&amp;project=rtmp_client">BigInteger</a>(<span class="n">1</span>, <a class="d" href="#DH_MODULUS_BYTES">DH_MODULUS_BYTES</a>);
<a class="l" name="109" href="#109">109</a>
<a class="hl" name="110" href="#110">110</a>    <b>protected</b> <b>static</b> <b>final</b> <a href="/source/s?defs=BigInteger&amp;project=rtmp_client">BigInteger</a> <a class="xfld" name="DH_BASE"/><a href="/source/s?refs=DH_BASE&amp;project=rtmp_client" class="xfld">DH_BASE</a> = <a href="/source/s?defs=BigInteger&amp;project=rtmp_client">BigInteger</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<span class="n">2</span>);
<a class="l" name="111" href="#111">111</a>
<a class="l" name="112" href="#112">112</a>    <b>protected</b> <b>static</b> <b>final</b> <b>int</b> <a class="xfld" name="HANDSHAKE_SIZE_SERVER"/><a href="/source/s?refs=HANDSHAKE_SIZE_SERVER&amp;project=rtmp_client" class="xfld">HANDSHAKE_SIZE_SERVER</a> = (<a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>.<a href="/source/s?defs=HANDSHAKE_SIZE&amp;project=rtmp_client">HANDSHAKE_SIZE</a> * <span class="n">2</span>) + <span class="n">1</span>;
<a class="l" name="113" href="#113">113</a>
<a class="l" name="114" href="#114">114</a>    <b>protected</b> <b>static</b> <b>final</b> <b>int</b> <a class="xfld" name="DIGEST_LENGTH"/><a href="/source/s?refs=DIGEST_LENGTH&amp;project=rtmp_client" class="xfld">DIGEST_LENGTH</a> = <span class="n">32</span>;
<a class="l" name="115" href="#115">115</a>
<a class="l" name="116" href="#116">116</a>    <b>protected</b> <b>static</b> <b>final</b> <b>int</b> <a class="xfld" name="KEY_LENGTH"/><a href="/source/s?refs=KEY_LENGTH&amp;project=rtmp_client" class="xfld">KEY_LENGTH</a> = <span class="n">128</span>;
<a class="l" name="117" href="#117">117</a>
<a class="l" name="118" href="#118">118</a>	<b>protected</b> <b>static</b> <b>final</b> <a href="/source/s?defs=Random&amp;project=rtmp_client">Random</a> <a class="xfld" name="random"/><a href="/source/s?refs=random&amp;project=rtmp_client" class="xfld">random</a> = <b>new</b> <a href="/source/s?defs=Random&amp;project=rtmp_client">Random</a>();
<a class="l" name="119" href="#119">119</a>
<a class="hl" name="120" href="#120">120</a>	<b>protected</b> <a href="/source/s?defs=KeyAgreement&amp;project=rtmp_client">KeyAgreement</a> <a class="xfld" name="keyAgreement"/><a href="/source/s?refs=keyAgreement&amp;project=rtmp_client" class="xfld">keyAgreement</a>;
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>	<b>protected</b> <a href="/source/s?defs=Cipher&amp;project=rtmp_client">Cipher</a> <a class="xfld" name="cipherOut"/><a href="/source/s?refs=cipherOut&amp;project=rtmp_client" class="xfld">cipherOut</a>;
<a class="l" name="123" href="#123">123</a>
<a class="l" name="124" href="#124">124</a>	<b>protected</b> <a href="/source/s?defs=Cipher&amp;project=rtmp_client">Cipher</a> <a class="xfld" name="cipherIn"/><a href="/source/s?refs=cipherIn&amp;project=rtmp_client" class="xfld">cipherIn</a>;
<a class="l" name="125" href="#125">125</a>
<a class="l" name="126" href="#126">126</a>	<b>protected</b> <b>byte</b> <a class="xfld" name="handshakeType"/><a href="/source/s?refs=handshakeType&amp;project=rtmp_client" class="xfld">handshakeType</a>;
<a class="l" name="127" href="#127">127</a>
<a class="l" name="128" href="#128">128</a>	<b>protected</b> <b>byte</b>[] <a class="xfld" name="handshakeBytes"/><a href="/source/s?refs=handshakeBytes&amp;project=rtmp_client" class="xfld">handshakeBytes</a>;
<a class="l" name="129" href="#129">129</a>
<a class="hl" name="130" href="#130">130</a>	<span class="c">// validation scheme</span>
<a class="l" name="131" href="#131">131</a>	<b>protected</b> <b>int</b> <a class="xfld" name="validationScheme"/><a href="/source/s?refs=validationScheme&amp;project=rtmp_client" class="xfld">validationScheme</a> = <span class="n">0</span>;
<a class="l" name="132" href="#132">132</a>
<a class="l" name="133" href="#133">133</a>	<span class="c">// servers public key</span>
<a class="l" name="134" href="#134">134</a>	<b>protected</b> <b>byte</b>[] <a class="xfld" name="incomingPublicKey"/><a href="/source/s?refs=incomingPublicKey&amp;project=rtmp_client" class="xfld">incomingPublicKey</a>;
<a class="l" name="135" href="#135">135</a>
<a class="l" name="136" href="#136">136</a>	<span class="c">// clients public key</span>
<a class="l" name="137" href="#137">137</a>	<b>protected</b> <b>byte</b>[] <a class="xfld" name="outgoingPublicKey"/><a href="/source/s?refs=outgoingPublicKey&amp;project=rtmp_client" class="xfld">outgoingPublicKey</a>;
<a class="l" name="138" href="#138">138</a>
<a class="l" name="139" href="#139">139</a>	<b>private</b> <a href="/source/s?defs=Mac&amp;project=rtmp_client">Mac</a> <a class="xfld" name="hmacSHA256"/><a href="/source/s?refs=hmacSHA256&amp;project=rtmp_client" class="xfld">hmacSHA256</a>;
<a class="hl" name="140" href="#140">140</a>
<a class="l" name="141" href="#141">141</a>	<b>static</b> {
<a class="l" name="142" href="#142">142</a>		<span class="c">//get security provider</span>
<a class="l" name="143" href="#143">143</a>		<span class="c">//Security.addProvider(new BouncyCastleProvider());</span>
<a class="l" name="144" href="#144">144</a>	}
<a class="l" name="145" href="#145">145</a>
<a class="l" name="146" href="#146">146</a>	<b>public</b> <a class="xmt" name="RTMPHandshake"/><a href="/source/s?refs=RTMPHandshake&amp;project=rtmp_client" class="xmt">RTMPHandshake</a>() {
<a class="l" name="147" href="#147">147</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Handshake ctor"</span>);
<a class="l" name="148" href="#148">148</a>		<b>try</b> {
<a class="l" name="149" href="#149">149</a>			<a class="d" href="#hmacSHA256">hmacSHA256</a> = <a href="/source/s?defs=Mac&amp;project=rtmp_client">Mac</a>.<a href="/source/s?defs=getInstance&amp;project=rtmp_client">getInstance</a>(<span class="s">"HmacSHA256"</span>);
<a class="hl" name="150" href="#150">150</a>		} <b>catch</b> (<a href="/source/s?defs=SecurityException&amp;project=rtmp_client">SecurityException</a> e) {
<a class="l" name="151" href="#151">151</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Security exception when getting HMAC"</span>, e);
<a class="l" name="152" href="#152">152</a>		} <b>catch</b> (<a href="/source/s?defs=NoSuchAlgorithmException&amp;project=rtmp_client">NoSuchAlgorithmException</a> e) {
<a class="l" name="153" href="#153">153</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"HMAC SHA256 does not exist"</span>);
<a class="l" name="154" href="#154">154</a>		}
<a class="l" name="155" href="#155">155</a>		<span class="c">//create our server handshake bytes</span>
<a class="l" name="156" href="#156">156</a>		<a class="d" href="#createHandshakeBytes">createHandshakeBytes</a>();
<a class="l" name="157" href="#157">157</a>	}
<a class="l" name="158" href="#158">158</a>
<a class="l" name="159" href="#159">159</a>	<span class="c">/**
<a class="hl" name="160" href="#160">160</a>	 * Calculates an HMAC SHA256 hash using a default key length.
<a class="l" name="161" href="#161">161</a>	 *
<a class="l" name="162" href="#162">162</a>	 * <strong>@param</strong> <em>input</em>
<a class="l" name="163" href="#163">163</a>	 * <strong>@param</strong> <em>key</em>
<a class="l" name="164" href="#164">164</a>	 * <strong>@return</strong> hmac hashed bytes
<a class="l" name="165" href="#165">165</a>	 */</span>
<a class="l" name="166" href="#166">166</a>	<b>public</b> <b>byte</b>[] <a class="xmt" name="calculateHMAC_SHA256"/><a href="/source/s?refs=calculateHMAC_SHA256&amp;project=rtmp_client" class="xmt">calculateHMAC_SHA256</a>(<b>byte</b>[] <a class="xa" name="input"/><a href="/source/s?refs=input&amp;project=rtmp_client" class="xa">input</a>, <b>byte</b>[] <a class="xa" name="key"/><a href="/source/s?refs=key&amp;project=rtmp_client" class="xa">key</a>) {
<a class="l" name="167" href="#167">167</a>		<b>byte</b>[] <a href="/source/s?defs=output&amp;project=rtmp_client">output</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="168" href="#168">168</a>		<b>try</b> {
<a class="l" name="169" href="#169">169</a>			<a class="d" href="#hmacSHA256">hmacSHA256</a>.<a href="/source/s?defs=init&amp;project=rtmp_client">init</a>(<b>new</b> <a href="/source/s?defs=SecretKeySpec&amp;project=rtmp_client">SecretKeySpec</a>(<a href="/source/s?defs=key&amp;project=rtmp_client">key</a>, <span class="s">"HmacSHA256"</span>));
<a class="hl" name="170" href="#170">170</a>			<a href="/source/s?defs=output&amp;project=rtmp_client">output</a> = <a class="d" href="#hmacSHA256">hmacSHA256</a>.<a href="/source/s?defs=doFinal&amp;project=rtmp_client">doFinal</a>(<a href="/source/s?defs=input&amp;project=rtmp_client">input</a>);
<a class="l" name="171" href="#171">171</a>		} <b>catch</b> (<a href="/source/s?defs=InvalidKeyException&amp;project=rtmp_client">InvalidKeyException</a> e) {
<a class="l" name="172" href="#172">172</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Invalid key"</span>, e);
<a class="l" name="173" href="#173">173</a>		}
<a class="l" name="174" href="#174">174</a>		<b>return</b> <a href="/source/s?defs=output&amp;project=rtmp_client">output</a>;
<a class="l" name="175" href="#175">175</a>	}
<a class="l" name="176" href="#176">176</a>
<a class="l" name="177" href="#177">177</a>	<span class="c">/**
<a class="l" name="178" href="#178">178</a>	 * Calculates an HMAC SHA256 hash using a set key length.
<a class="l" name="179" href="#179">179</a>	 *
<a class="hl" name="180" href="#180">180</a>	 * <strong>@param</strong> <em>input</em>
<a class="l" name="181" href="#181">181</a>	 * <strong>@param</strong> <em>key</em>
<a class="l" name="182" href="#182">182</a>	 * <strong>@param</strong> <em>length</em>
<a class="l" name="183" href="#183">183</a>	 * <strong>@return</strong> hmac hashed bytes
<a class="l" name="184" href="#184">184</a>	 */</span>
<a class="l" name="185" href="#185">185</a>	<b>public</b> <b>byte</b>[] <a class="xmt" name="calculateHMAC_SHA256"/><a href="/source/s?refs=calculateHMAC_SHA256&amp;project=rtmp_client" class="xmt">calculateHMAC_SHA256</a>(<b>byte</b>[] <a class="xa" name="input"/><a href="/source/s?refs=input&amp;project=rtmp_client" class="xa">input</a>, <b>byte</b>[] <a class="xa" name="key"/><a href="/source/s?refs=key&amp;project=rtmp_client" class="xa">key</a>, <b>int</b> <a class="xa" name="length"/><a href="/source/s?refs=length&amp;project=rtmp_client" class="xa">length</a>) {
<a class="l" name="186" href="#186">186</a>		<b>byte</b>[] <a href="/source/s?defs=output&amp;project=rtmp_client">output</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="187" href="#187">187</a>		<b>try</b> {
<a class="l" name="188" href="#188">188</a>			<a class="d" href="#hmacSHA256">hmacSHA256</a>.<a href="/source/s?defs=init&amp;project=rtmp_client">init</a>(<b>new</b> <a href="/source/s?defs=SecretKeySpec&amp;project=rtmp_client">SecretKeySpec</a>(<a href="/source/s?defs=key&amp;project=rtmp_client">key</a>, <span class="n">0</span>, <a class="d" href="#length">length</a>, <span class="s">"HmacSHA256"</span>));
<a class="l" name="189" href="#189">189</a>			<a href="/source/s?defs=output&amp;project=rtmp_client">output</a> = <a class="d" href="#hmacSHA256">hmacSHA256</a>.<a href="/source/s?defs=doFinal&amp;project=rtmp_client">doFinal</a>(<a href="/source/s?defs=input&amp;project=rtmp_client">input</a>);
<a class="hl" name="190" href="#190">190</a>		} <b>catch</b> (<a href="/source/s?defs=InvalidKeyException&amp;project=rtmp_client">InvalidKeyException</a> e) {
<a class="l" name="191" href="#191">191</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Invalid key"</span>, e);
<a class="l" name="192" href="#192">192</a>		}
<a class="l" name="193" href="#193">193</a>		<b>return</b> <a href="/source/s?defs=output&amp;project=rtmp_client">output</a>;
<a class="l" name="194" href="#194">194</a>	}
<a class="l" name="195" href="#195">195</a>
<a class="l" name="196" href="#196">196</a>	<span class="c">/**
<a class="l" name="197" href="#197">197</a>	 * Creates a Diffie-Hellman key pair.
<a class="l" name="198" href="#198">198</a>	 *
<a class="l" name="199" href="#199">199</a>	 * <strong>@return</strong> dh keypair
<a class="hl" name="200" href="#200">200</a>	 */</span>
<a class="l" name="201" href="#201">201</a>	<b>protected</b> <a href="/source/s?defs=KeyPair&amp;project=rtmp_client">KeyPair</a> <a class="xmt" name="generateKeyPair"/><a href="/source/s?refs=generateKeyPair&amp;project=rtmp_client" class="xmt">generateKeyPair</a>() {
<a class="l" name="202" href="#202">202</a>		<a href="/source/s?defs=KeyPair&amp;project=rtmp_client">KeyPair</a> <a class="d" href="#keyPair">keyPair</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="203" href="#203">203</a>		<a href="/source/s?defs=DHParameterSpec&amp;project=rtmp_client">DHParameterSpec</a> <a href="/source/s?defs=keySpec&amp;project=rtmp_client">keySpec</a> = <b>new</b> <a href="/source/s?defs=DHParameterSpec&amp;project=rtmp_client">DHParameterSpec</a>(<a class="d" href="#DH_MODULUS">DH_MODULUS</a>, <a class="d" href="#DH_BASE">DH_BASE</a>);
<a class="l" name="204" href="#204">204</a>		<b>try</b> {
<a class="l" name="205" href="#205">205</a>			<a href="/source/s?defs=KeyPairGenerator&amp;project=rtmp_client">KeyPairGenerator</a> <a href="/source/s?defs=keyGen&amp;project=rtmp_client">keyGen</a> = <a href="/source/s?defs=KeyPairGenerator&amp;project=rtmp_client">KeyPairGenerator</a>.<a href="/source/s?defs=getInstance&amp;project=rtmp_client">getInstance</a>(<span class="s">"DH"</span>);
<a class="l" name="206" href="#206">206</a>			<a href="/source/s?defs=keyGen&amp;project=rtmp_client">keyGen</a>.<a href="/source/s?defs=initialize&amp;project=rtmp_client">initialize</a>(<a href="/source/s?defs=keySpec&amp;project=rtmp_client">keySpec</a>);
<a class="l" name="207" href="#207">207</a>			<a class="d" href="#keyPair">keyPair</a> = <a href="/source/s?defs=keyGen&amp;project=rtmp_client">keyGen</a>.<a class="d" href="#generateKeyPair">generateKeyPair</a>();
<a class="l" name="208" href="#208">208</a>		    <a class="d" href="#keyAgreement">keyAgreement</a> = <a href="/source/s?defs=KeyAgreement&amp;project=rtmp_client">KeyAgreement</a>.<a href="/source/s?defs=getInstance&amp;project=rtmp_client">getInstance</a>(<span class="s">"DH"</span>);
<a class="l" name="209" href="#209">209</a>		    <a class="d" href="#keyAgreement">keyAgreement</a>.<a href="/source/s?defs=init&amp;project=rtmp_client">init</a>(<a class="d" href="#keyPair">keyPair</a>.<a href="/source/s?defs=getPrivate&amp;project=rtmp_client">getPrivate</a>());
<a class="hl" name="210" href="#210">210</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="211" href="#211">211</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error generating keypair"</span>, e);
<a class="l" name="212" href="#212">212</a>		}
<a class="l" name="213" href="#213">213</a>		<b>return</b> <a class="d" href="#keyPair">keyPair</a>;
<a class="l" name="214" href="#214">214</a>	}
<a class="l" name="215" href="#215">215</a>
<a class="l" name="216" href="#216">216</a>	<span class="c">/**
<a class="l" name="217" href="#217">217</a>	 * Returns the public key for a given key pair.
<a class="l" name="218" href="#218">218</a>	 *
<a class="l" name="219" href="#219">219</a>	 * <strong>@param</strong> <em>keyPair</em>
<a class="hl" name="220" href="#220">220</a>	 * <strong>@return</strong> public key
<a class="l" name="221" href="#221">221</a>	 */</span>
<a class="l" name="222" href="#222">222</a>	<b>protected</b> <b>static</b> <b>byte</b>[] <a class="xmt" name="getPublicKey"/><a href="/source/s?refs=getPublicKey&amp;project=rtmp_client" class="xmt">getPublicKey</a>(<a href="/source/s?defs=KeyPair&amp;project=rtmp_client">KeyPair</a> <a class="xa" name="keyPair"/><a href="/source/s?refs=keyPair&amp;project=rtmp_client" class="xa">keyPair</a>) {
<a class="l" name="223" href="#223">223</a>		 <a href="/source/s?defs=DHPublicKey&amp;project=rtmp_client">DHPublicKey</a> <a class="d" href="#incomingPublicKey">incomingPublicKey</a> = (<a href="/source/s?defs=DHPublicKey&amp;project=rtmp_client">DHPublicKey</a>) <a class="d" href="#keyPair">keyPair</a>.<a href="/source/s?defs=getPublic&amp;project=rtmp_client">getPublic</a>();
<a class="l" name="224" href="#224">224</a>	     <a href="/source/s?defs=BigInteger&amp;project=rtmp_client">BigInteger</a>	<a href="/source/s?defs=dhY&amp;project=rtmp_client">dhY</a> = <a class="d" href="#incomingPublicKey">incomingPublicKey</a>.<a href="/source/s?defs=getY&amp;project=rtmp_client">getY</a>();
<a class="l" name="225" href="#225">225</a>	     <a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Public key: {}"</span>, <a href="/source/s?defs=dhY&amp;project=rtmp_client">dhY</a>);
<a class="l" name="226" href="#226">226</a>	     <b>byte</b>[] <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=dhY&amp;project=rtmp_client">dhY</a>.<a href="/source/s?defs=toByteArray&amp;project=rtmp_client">toByteArray</a>();
<a class="l" name="227" href="#227">227</a>	     <span class="c">//log.debug("Public key as bytes - length [{}]: {}", result.length, Hex.encodeHexString(result));</span>
<a class="l" name="228" href="#228">228</a>	     <b>byte</b>[] <a href="/source/s?defs=temp&amp;project=rtmp_client">temp</a> = <b>new</b> <b>byte</b>[<a class="d" href="#KEY_LENGTH">KEY_LENGTH</a>];
<a class="l" name="229" href="#229">229</a>	     <b>if</b> (<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a class="d" href="#length">length</a> &lt; <a class="d" href="#KEY_LENGTH">KEY_LENGTH</a>) {
<a class="hl" name="230" href="#230">230</a>	    	 <a href="/source/s?defs=System&amp;project=rtmp_client">System</a>.<a href="/source/s?defs=arraycopy&amp;project=rtmp_client">arraycopy</a>(<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>, <span class="n">0</span>, <a href="/source/s?defs=temp&amp;project=rtmp_client">temp</a>, <a class="d" href="#KEY_LENGTH">KEY_LENGTH</a> - <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a class="d" href="#length">length</a>, <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a class="d" href="#length">length</a>);
<a class="l" name="231" href="#231">231</a>	    	 <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=temp&amp;project=rtmp_client">temp</a>;
<a class="l" name="232" href="#232">232</a>	    	 <a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Padded public key length to 128"</span>);
<a class="l" name="233" href="#233">233</a>	     } <b>else</b> <b>if</b>(<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a class="d" href="#length">length</a> &gt; <a class="d" href="#KEY_LENGTH">KEY_LENGTH</a>){
<a class="l" name="234" href="#234">234</a>	    	 <a href="/source/s?defs=System&amp;project=rtmp_client">System</a>.<a href="/source/s?defs=arraycopy&amp;project=rtmp_client">arraycopy</a>(<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>, <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a class="d" href="#length">length</a> - <a class="d" href="#KEY_LENGTH">KEY_LENGTH</a>, <a href="/source/s?defs=temp&amp;project=rtmp_client">temp</a>, <span class="n">0</span>, <a class="d" href="#KEY_LENGTH">KEY_LENGTH</a>);
<a class="l" name="235" href="#235">235</a>	    	 <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=temp&amp;project=rtmp_client">temp</a>;
<a class="l" name="236" href="#236">236</a>	    	 <a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Truncated public key length to 128"</span>);
<a class="l" name="237" href="#237">237</a>	     }
<a class="l" name="238" href="#238">238</a>	     <b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="239" href="#239">239</a>	}
<a class="hl" name="240" href="#240">240</a>
<a class="l" name="241" href="#241">241</a>	<span class="c">/**
<a class="l" name="242" href="#242">242</a>	 * Determines the validation scheme for given input.
<a class="l" name="243" href="#243">243</a>	 *
<a class="l" name="244" href="#244">244</a>	 * <strong>@param</strong> <em>otherPublicKeyBytes</em>
<a class="l" name="245" href="#245">245</a>	 * <strong>@param</strong> <em>agreement</em>
<a class="l" name="246" href="#246">246</a>	 * <strong>@return</strong> shared secret bytes if client used a supported validation scheme
<a class="l" name="247" href="#247">247</a>	 */</span>
<a class="l" name="248" href="#248">248</a>	<b>protected</b> <b>static</b> <b>byte</b>[] <a class="xmt" name="getSharedSecret"/><a href="/source/s?refs=getSharedSecret&amp;project=rtmp_client" class="xmt">getSharedSecret</a>(<b>byte</b>[] <a class="xa" name="otherPublicKeyBytes"/><a href="/source/s?refs=otherPublicKeyBytes&amp;project=rtmp_client" class="xa">otherPublicKeyBytes</a>, <a href="/source/s?defs=KeyAgreement&amp;project=rtmp_client">KeyAgreement</a> <a class="xa" name="agreement"/><a href="/source/s?refs=agreement&amp;project=rtmp_client" class="xa">agreement</a>) {
<a class="l" name="249" href="#249">249</a>		<a href="/source/s?defs=BigInteger&amp;project=rtmp_client">BigInteger</a> <a href="/source/s?defs=otherPublicKeyInt&amp;project=rtmp_client">otherPublicKeyInt</a> = <b>new</b> <a href="/source/s?defs=BigInteger&amp;project=rtmp_client">BigInteger</a>(<span class="n">1</span>, <a class="d" href="#otherPublicKeyBytes">otherPublicKeyBytes</a>);
<a class="hl" name="250" href="#250">250</a>		<b>try</b> {
<a class="l" name="251" href="#251">251</a>			<a href="/source/s?defs=KeyFactory&amp;project=rtmp_client">KeyFactory</a> <a href="/source/s?defs=keyFactory&amp;project=rtmp_client">keyFactory</a> = <a href="/source/s?defs=KeyFactory&amp;project=rtmp_client">KeyFactory</a>.<a href="/source/s?defs=getInstance&amp;project=rtmp_client">getInstance</a>(<span class="s">"DH"</span>);
<a class="l" name="252" href="#252">252</a>			<a href="/source/s?defs=KeySpec&amp;project=rtmp_client">KeySpec</a> <a href="/source/s?defs=otherPublicKeySpec&amp;project=rtmp_client">otherPublicKeySpec</a> = <b>new</b> <a href="/source/s?defs=DHPublicKeySpec&amp;project=rtmp_client">DHPublicKeySpec</a>(<a href="/source/s?defs=otherPublicKeyInt&amp;project=rtmp_client">otherPublicKeyInt</a>, <a href="/source/s?defs=RTMPHandshake&amp;project=rtmp_client">RTMPHandshake</a>.<a class="d" href="#DH_MODULUS">DH_MODULUS</a>, <a href="/source/s?defs=RTMPHandshake&amp;project=rtmp_client">RTMPHandshake</a>.<a class="d" href="#DH_BASE">DH_BASE</a>);
<a class="l" name="253" href="#253">253</a>			<a href="/source/s?defs=PublicKey&amp;project=rtmp_client">PublicKey</a> <a href="/source/s?defs=otherPublicKey&amp;project=rtmp_client">otherPublicKey</a> = <a href="/source/s?defs=keyFactory&amp;project=rtmp_client">keyFactory</a>.<a href="/source/s?defs=generatePublic&amp;project=rtmp_client">generatePublic</a>(<a href="/source/s?defs=otherPublicKeySpec&amp;project=rtmp_client">otherPublicKeySpec</a>);
<a class="l" name="254" href="#254">254</a>			<a class="d" href="#agreement">agreement</a>.<a href="/source/s?defs=doPhase&amp;project=rtmp_client">doPhase</a>(<a href="/source/s?defs=otherPublicKey&amp;project=rtmp_client">otherPublicKey</a>, <b>true</b>);
<a class="l" name="255" href="#255">255</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="256" href="#256">256</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Exception getting the shared secret"</span>, e);
<a class="l" name="257" href="#257">257</a>		}
<a class="l" name="258" href="#258">258</a>		<b>byte</b>[] <a href="/source/s?defs=sharedSecret&amp;project=rtmp_client">sharedSecret</a> = <a class="d" href="#agreement">agreement</a>.<a href="/source/s?defs=generateSecret&amp;project=rtmp_client">generateSecret</a>();
<a class="l" name="259" href="#259">259</a>		<span class="c">//log.debug("Shared secret [{}]: {}", sharedSecret.length, Hex.encodeHexString(sharedSecret));</span>
<a class="hl" name="260" href="#260">260</a>		<b>return</b> <a href="/source/s?defs=sharedSecret&amp;project=rtmp_client">sharedSecret</a>;
<a class="l" name="261" href="#261">261</a>	}
<a class="l" name="262" href="#262">262</a>
<a class="l" name="263" href="#263">263</a>	<span class="c">/**
<a class="l" name="264" href="#264">264</a>	 * Create the initial bytes for a request / response.
<a class="l" name="265" href="#265">265</a>	 */</span>
<a class="l" name="266" href="#266">266</a>	<b>abstract</b> <b>void</b> <a class="xmt" name="createHandshakeBytes"/><a href="/source/s?refs=createHandshakeBytes&amp;project=rtmp_client" class="xmt">createHandshakeBytes</a>();
<a class="l" name="267" href="#267">267</a>
<a class="l" name="268" href="#268">268</a>	<span class="c">/**
<a class="l" name="269" href="#269">269</a>	 * Determines the validation scheme for given input.
<a class="hl" name="270" href="#270">270</a>	 *
<a class="l" name="271" href="#271">271</a>	 * <strong>@param</strong> <em>input</em>
<a class="l" name="272" href="#272">272</a>	 * <strong>@return</strong> true if its a supported validation scheme, false if unsupported
<a class="l" name="273" href="#273">273</a>	 */</span>
<a class="l" name="274" href="#274">274</a>	<b>public</b> <b>abstract</b> <b>boolean</b> <a class="xmt" name="validate"/><a href="/source/s?refs=validate&amp;project=rtmp_client" class="xmt">validate</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="input"/><a href="/source/s?refs=input&amp;project=rtmp_client" class="xa">input</a>);
<a class="l" name="275" href="#275">275</a>
<a class="l" name="276" href="#276">276</a>	<span class="c">/**
<a class="l" name="277" href="#277">277</a>	 * Returns the DH offset from an array of bytes.
<a class="l" name="278" href="#278">278</a>	 *
<a class="l" name="279" href="#279">279</a>	 * <strong>@param</strong> <em>bytes</em>
<a class="hl" name="280" href="#280">280</a>	 * <strong>@return</strong> DH offset
<a class="l" name="281" href="#281">281</a>	 */</span>
<a class="l" name="282" href="#282">282</a>	<b>protected</b> <b>int</b> <a class="xmt" name="getDHOffset"/><a href="/source/s?refs=getDHOffset&amp;project=rtmp_client" class="xmt">getDHOffset</a>(<b>byte</b>[] <a class="xa" name="bytes"/><a href="/source/s?refs=bytes&amp;project=rtmp_client" class="xa">bytes</a>) {
<a class="l" name="283" href="#283">283</a>		<b>int</b> <a href="/source/s?defs=dhOffset&amp;project=rtmp_client">dhOffset</a> = -<span class="n">1</span>;
<a class="l" name="284" href="#284">284</a>		<b>switch</b> (<a class="d" href="#validationScheme">validationScheme</a>) {
<a class="l" name="285" href="#285">285</a>			<b>case</b> <span class="n">1</span>:
<a class="l" name="286" href="#286">286</a>				<a href="/source/s?defs=dhOffset&amp;project=rtmp_client">dhOffset</a> = <a class="d" href="#getDHOffset1">getDHOffset1</a>(<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>);
<a class="l" name="287" href="#287">287</a>				<b>break</b>;
<a class="l" name="288" href="#288">288</a>			<b>default</b>:
<a class="l" name="289" href="#289">289</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Scheme 0 will be used for DH offset"</span>);
<a class="hl" name="290" href="#290">290</a>			<b>case</b> <span class="n">0</span>:
<a class="l" name="291" href="#291">291</a>				<a href="/source/s?defs=dhOffset&amp;project=rtmp_client">dhOffset</a> = <a class="d" href="#getDHOffset0">getDHOffset0</a>(<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>);
<a class="l" name="292" href="#292">292</a>		}
<a class="l" name="293" href="#293">293</a>		<b>return</b> <a href="/source/s?defs=dhOffset&amp;project=rtmp_client">dhOffset</a>;
<a class="l" name="294" href="#294">294</a>	}
<a class="l" name="295" href="#295">295</a>
<a class="l" name="296" href="#296">296</a>	<span class="c">/**
<a class="l" name="297" href="#297">297</a>	 * Returns the DH byte offset.
<a class="l" name="298" href="#298">298</a>	 *
<a class="l" name="299" href="#299">299</a>	 * <strong>@return</strong> dh offset
<a class="hl" name="300" href="#300">300</a>	 */</span>
<a class="l" name="301" href="#301">301</a>	<b>protected</b> <b>int</b> <a class="xmt" name="getDHOffset0"/><a href="/source/s?refs=getDHOffset0&amp;project=rtmp_client" class="xmt">getDHOffset0</a>(<b>byte</b>[] <a class="xa" name="bytes"/><a href="/source/s?refs=bytes&amp;project=rtmp_client" class="xa">bytes</a>) {
<a class="l" name="302" href="#302">302</a>		<b>int</b> <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> = (<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">1532</span>] &amp; <span class="n">0x0ff</span>) + (<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">1533</span>] &amp; <span class="n">0x0ff</span>) + (<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">1534</span>] &amp; <span class="n">0x0ff</span>) + (<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">1535</span>] &amp; <span class="n">0x0ff</span>);
<a class="l" name="303" href="#303">303</a>	    <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> = <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> % <span class="n">632</span>;
<a class="l" name="304" href="#304">304</a>	    <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> = <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> + <span class="n">772</span>;
<a class="l" name="305" href="#305">305</a>	    <b>if</b> (<a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> + <a class="d" href="#KEY_LENGTH">KEY_LENGTH</a> &gt;= <span class="n">1536</span>) {
<a class="l" name="306" href="#306">306</a>	    	 <a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Invalid DH offset"</span>);
<a class="l" name="307" href="#307">307</a>	    }
<a class="l" name="308" href="#308">308</a>	    <b>return</b> <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>;
<a class="l" name="309" href="#309">309</a>	}
<a class="hl" name="310" href="#310">310</a>
<a class="l" name="311" href="#311">311</a>	<span class="c">/**
<a class="l" name="312" href="#312">312</a>	 * Returns the DH byte offset.
<a class="l" name="313" href="#313">313</a>	 *
<a class="l" name="314" href="#314">314</a>	 * <strong>@return</strong> dh offset
<a class="l" name="315" href="#315">315</a>	 */</span>
<a class="l" name="316" href="#316">316</a>	<b>protected</b> <b>int</b> <a class="xmt" name="getDHOffset1"/><a href="/source/s?refs=getDHOffset1&amp;project=rtmp_client" class="xmt">getDHOffset1</a>(<b>byte</b>[] <a class="xa" name="bytes"/><a href="/source/s?refs=bytes&amp;project=rtmp_client" class="xa">bytes</a>) {
<a class="l" name="317" href="#317">317</a>		<b>int</b> <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> = (<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">768</span>] &amp; <span class="n">0x0ff</span>) + (<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">769</span>] &amp; <span class="n">0x0ff</span>) + (<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">770</span>] &amp; <span class="n">0x0ff</span>) + (<a href="/source/s?defs=bytes&amp;project=rtmp_client">bytes</a>[<span class="n">771</span>] &amp; <span class="n">0x0ff</span>);
<a class="l" name="318" href="#318">318</a>	    <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> = <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> % <span class="n">632</span>;
<a class="l" name="319" href="#319">319</a>	    <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> = <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> + <span class="n">8</span>;
<a class="hl" name="320" href="#320">320</a>	    <b>if</b> (<a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> + <a class="d" href="#KEY_LENGTH">KEY_LENGTH</a> &gt;= <span class="n">1536</span>) {
<a class="l" name="321" href="#321">321</a>	    	 <a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Invalid DH offset"</span>);
<a class="l" name="322" href="#322">322</a>	    }
<a class="l" name="323" href="#323">323</a>	    <b>return</b> <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>;
<a class="l" name="324" href="#324">324</a>	}
<a class="l" name="325" href="#325">325</a>
<a class="l" name="326" href="#326">326</a>	<span class="c">/**
<a class="l" name="327" href="#327">327</a>	 * Returns the digest offset using current validation scheme.
<a class="l" name="328" href="#328">328</a>	 *
<a class="l" name="329" href="#329">329</a>	 * <strong>@param</strong> <em>pBuffer</em>
<a class="hl" name="330" href="#330">330</a>	 * <strong>@return</strong> digest offset
<a class="l" name="331" href="#331">331</a>	 */</span>
<a class="l" name="332" href="#332">332</a>	<b>protected</b> <b>int</b> <a class="xmt" name="getDigestOffset"/><a href="/source/s?refs=getDigestOffset&amp;project=rtmp_client" class="xmt">getDigestOffset</a>(<b>byte</b>[] <a class="xa" name="pBuffer"/><a href="/source/s?refs=pBuffer&amp;project=rtmp_client" class="xa">pBuffer</a>) {
<a class="l" name="333" href="#333">333</a>		<b>int</b> <a href="/source/s?defs=serverDigestOffset&amp;project=rtmp_client">serverDigestOffset</a> = -<span class="n">1</span>;
<a class="l" name="334" href="#334">334</a>		<b>switch</b> (<a class="d" href="#validationScheme">validationScheme</a>) {
<a class="l" name="335" href="#335">335</a>			<b>case</b> <span class="n">1</span>:
<a class="l" name="336" href="#336">336</a>				<a href="/source/s?defs=serverDigestOffset&amp;project=rtmp_client">serverDigestOffset</a> = <a class="d" href="#getDigestOffset1">getDigestOffset1</a>(<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>);
<a class="l" name="337" href="#337">337</a>				<b>break</b>;
<a class="l" name="338" href="#338">338</a>			<b>default</b>:
<a class="l" name="339" href="#339">339</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Scheme 0 will be used for DH offset"</span>);
<a class="hl" name="340" href="#340">340</a>			<b>case</b> <span class="n">0</span>:
<a class="l" name="341" href="#341">341</a>				<a href="/source/s?defs=serverDigestOffset&amp;project=rtmp_client">serverDigestOffset</a> = <a class="d" href="#getDigestOffset0">getDigestOffset0</a>(<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>);
<a class="l" name="342" href="#342">342</a>		}
<a class="l" name="343" href="#343">343</a>		<b>return</b> <a href="/source/s?defs=serverDigestOffset&amp;project=rtmp_client">serverDigestOffset</a>;
<a class="l" name="344" href="#344">344</a>	}
<a class="l" name="345" href="#345">345</a>
<a class="l" name="346" href="#346">346</a>	<span class="c">/**
<a class="l" name="347" href="#347">347</a>	 * Returns a digest byte offset.
<a class="l" name="348" href="#348">348</a>	 *
<a class="l" name="349" href="#349">349</a>	 * <strong>@param</strong> <em>pBuffer</em> source for digest data
<a class="hl" name="350" href="#350">350</a>	 * <strong>@return</strong> digest offset
<a class="l" name="351" href="#351">351</a>	 */</span>
<a class="l" name="352" href="#352">352</a>	<b>protected</b> <b>int</b> <a class="xmt" name="getDigestOffset0"/><a href="/source/s?refs=getDigestOffset0&amp;project=rtmp_client" class="xmt">getDigestOffset0</a>(<b>byte</b>[] <a class="xa" name="pBuffer"/><a href="/source/s?refs=pBuffer&amp;project=rtmp_client" class="xa">pBuffer</a>) {
<a class="l" name="353" href="#353">353</a>		<b>if</b> (<a class="d" href="#log">log</a>.<a href="/source/s?defs=isTraceEnabled&amp;project=rtmp_client">isTraceEnabled</a>()) {
<a class="l" name="354" href="#354">354</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Scheme 0 offset bytes {},{},{},{}"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[]{(<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>[<span class="n">8</span>] &amp; <span class="n">0x0ff</span>), (<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>[<span class="n">9</span>] &amp; <span class="n">0x0ff</span>), (<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>[<span class="n">10</span>] &amp; <span class="n">0x0ff</span>), (<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>[<span class="n">11</span>] &amp; <span class="n">0x0ff</span>)});
<a class="l" name="355" href="#355">355</a>		}
<a class="l" name="356" href="#356">356</a>		<b>int</b> <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> = (<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>[<span class="n">8</span>] &amp; <span class="n">0x0ff</span>) + (<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>[<span class="n">9</span>] &amp; <span class="n">0x0ff</span>) + (<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>[<span class="n">10</span>] &amp; <span class="n">0x0ff</span>) + (<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>[<span class="n">11</span>] &amp; <span class="n">0x0ff</span>);
<a class="l" name="357" href="#357">357</a>	    <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> = <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> % <span class="n">728</span>;
<a class="l" name="358" href="#358">358</a>	    <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> = <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> + <span class="n">12</span>;
<a class="l" name="359" href="#359">359</a>	    <b>if</b> (<a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> + <a class="d" href="#DIGEST_LENGTH">DIGEST_LENGTH</a> &gt;= <span class="n">1536</span>) {
<a class="hl" name="360" href="#360">360</a>	        <a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Invalid digest offset"</span>);
<a class="l" name="361" href="#361">361</a>	    }
<a class="l" name="362" href="#362">362</a>	    <b>return</b> <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>;
<a class="l" name="363" href="#363">363</a>	}
<a class="l" name="364" href="#364">364</a>
<a class="l" name="365" href="#365">365</a>	<span class="c">/**
<a class="l" name="366" href="#366">366</a>	 * Returns a digest byte offset.
<a class="l" name="367" href="#367">367</a>	 *
<a class="l" name="368" href="#368">368</a>	 * <strong>@param</strong> <em>pBuffer</em> source for digest data
<a class="l" name="369" href="#369">369</a>	 * <strong>@return</strong> digest offset
<a class="hl" name="370" href="#370">370</a>	 */</span>
<a class="l" name="371" href="#371">371</a>	<b>protected</b> <b>int</b> <a class="xmt" name="getDigestOffset1"/><a href="/source/s?refs=getDigestOffset1&amp;project=rtmp_client" class="xmt">getDigestOffset1</a>(<b>byte</b>[] <a class="xa" name="pBuffer"/><a href="/source/s?refs=pBuffer&amp;project=rtmp_client" class="xa">pBuffer</a>) {
<a class="l" name="372" href="#372">372</a>		<b>if</b> (<a class="d" href="#log">log</a>.<a href="/source/s?defs=isTraceEnabled&amp;project=rtmp_client">isTraceEnabled</a>()) {
<a class="l" name="373" href="#373">373</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Scheme 1 offset bytes {},{},{},{}"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[]{(<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>[<span class="n">772</span>] &amp; <span class="n">0x0ff</span>), (<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>[<span class="n">773</span>] &amp; <span class="n">0x0ff</span>), (<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>[<span class="n">774</span>] &amp; <span class="n">0x0ff</span>), (<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>[<span class="n">775</span>] &amp; <span class="n">0x0ff</span>)});
<a class="l" name="374" href="#374">374</a>		}
<a class="l" name="375" href="#375">375</a>		<b>int</b> <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> = (<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>[<span class="n">772</span>] &amp; <span class="n">0x0ff</span>) + (<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>[<span class="n">773</span>] &amp; <span class="n">0x0ff</span>) + (<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>[<span class="n">774</span>] &amp; <span class="n">0x0ff</span>) + (<a href="/source/s?defs=pBuffer&amp;project=rtmp_client">pBuffer</a>[<span class="n">775</span>] &amp; <span class="n">0x0ff</span>);
<a class="l" name="376" href="#376">376</a>	    <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> = <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> % <span class="n">728</span>;
<a class="l" name="377" href="#377">377</a>	    <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> = <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> + <span class="n">776</span>;
<a class="l" name="378" href="#378">378</a>	    <b>if</b> (<a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a> + <a class="d" href="#DIGEST_LENGTH">DIGEST_LENGTH</a> &gt;= <span class="n">1536</span>) {
<a class="l" name="379" href="#379">379</a>	        <a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Invalid digest offset"</span>);
<a class="hl" name="380" href="#380">380</a>	    }
<a class="l" name="381" href="#381">381</a>	    <b>return</b> <a href="/source/s?defs=offset&amp;project=rtmp_client">offset</a>;
<a class="l" name="382" href="#382">382</a>	}
<a class="l" name="383" href="#383">383</a>
<a class="l" name="384" href="#384">384</a>	<span class="c">/**
<a class="l" name="385" href="#385">385</a>	 * Creates the servers handshake bytes
<a class="l" name="386" href="#386">386</a>	 */</span>
<a class="l" name="387" href="#387">387</a>	<b>public</b> <b>byte</b>[] <a class="xmt" name="getHandshakeBytes"/><a href="/source/s?refs=getHandshakeBytes&amp;project=rtmp_client" class="xmt">getHandshakeBytes</a>() {
<a class="l" name="388" href="#388">388</a>		<b>return</b> <a class="d" href="#handshakeBytes">handshakeBytes</a>;
<a class="l" name="389" href="#389">389</a>	}
<a class="hl" name="390" href="#390">390</a>
<a class="l" name="391" href="#391">391</a>	<span class="c">/**
<a class="l" name="392" href="#392">392</a>	 * Sets the handshake type. Currently only two types are supported, plain and encrypted.
<a class="l" name="393" href="#393">393</a>	 *
<a class="l" name="394" href="#394">394</a>	 * <strong>@param</strong> <em>handshakeType</em>
<a class="l" name="395" href="#395">395</a>	 */</span>
<a class="l" name="396" href="#396">396</a>	<b>public</b> <b>void</b> <a class="xmt" name="setHandshakeType"/><a href="/source/s?refs=setHandshakeType&amp;project=rtmp_client" class="xmt">setHandshakeType</a>(<b>byte</b> <a class="xa" name="handshakeType"/><a href="/source/s?refs=handshakeType&amp;project=rtmp_client" class="xa">handshakeType</a>) {
<a class="l" name="397" href="#397">397</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"Setting handshake type: {}"</span>, <a href="/source/s?defs=handshakeType&amp;project=rtmp_client">handshakeType</a>);
<a class="l" name="398" href="#398">398</a>		<b>this</b>.<a href="/source/s?defs=handshakeType&amp;project=rtmp_client">handshakeType</a> = <a href="/source/s?defs=handshakeType&amp;project=rtmp_client">handshakeType</a>;
<a class="l" name="399" href="#399">399</a>	}
<a class="hl" name="400" href="#400">400</a>
<a class="l" name="401" href="#401">401</a>	<span class="c">/**
<a class="l" name="402" href="#402">402</a>	 * Returns the handshake type.
<a class="l" name="403" href="#403">403</a>	 *
<a class="l" name="404" href="#404">404</a>	 * <strong>@return</strong> handshakeType
<a class="l" name="405" href="#405">405</a>	 */</span>
<a class="l" name="406" href="#406">406</a>	<b>public</b> <b>byte</b> <a class="xmt" name="getHandshakeType"/><a href="/source/s?refs=getHandshakeType&amp;project=rtmp_client" class="xmt">getHandshakeType</a>() {
<a class="l" name="407" href="#407">407</a>		<b>return</b> <a href="/source/s?defs=handshakeType&amp;project=rtmp_client">handshakeType</a>;
<a class="l" name="408" href="#408">408</a>	}
<a class="l" name="409" href="#409">409</a>
<a class="hl" name="410" href="#410">410</a>	<span class="c">/**
<a class="l" name="411" href="#411">411</a>	 * Gets the DH offset in the handshake bytes array based on validation scheme
<a class="l" name="412" href="#412">412</a>	 * Generates DH keypair
<a class="l" name="413" href="#413">413</a>	 * Adds public key to handshake bytes
<a class="l" name="414" href="#414">414</a>	 */</span>
<a class="l" name="415" href="#415">415</a>	<b>public</b> <a href="/source/s?defs=Cipher&amp;project=rtmp_client">Cipher</a> <a class="xmt" name="getCipherOut"/><a href="/source/s?refs=getCipherOut&amp;project=rtmp_client" class="xmt">getCipherOut</a>() {
<a class="l" name="416" href="#416">416</a>		<b>return</b> <a class="d" href="#cipherOut">cipherOut</a>;
<a class="l" name="417" href="#417">417</a>	}
<a class="l" name="418" href="#418">418</a>
<a class="l" name="419" href="#419">419</a>	<span class="c">/**
<a class="hl" name="420" href="#420">420</a>	 * Returns the contained handshake bytes. These are just random bytes
<a class="l" name="421" href="#421">421</a>	 * if the player is using an non-versioned player.
<a class="l" name="422" href="#422">422</a>	 *
<a class="l" name="423" href="#423">423</a>	 * <strong>@return</strong> handshake bytes
<a class="l" name="424" href="#424">424</a>	 */</span>
<a class="l" name="425" href="#425">425</a>	<b>public</b> <a href="/source/s?defs=Cipher&amp;project=rtmp_client">Cipher</a> <a class="xmt" name="getCipherIn"/><a href="/source/s?refs=getCipherIn&amp;project=rtmp_client" class="xmt">getCipherIn</a>() {
<a class="l" name="426" href="#426">426</a>		<b>return</b> <a class="d" href="#cipherIn">cipherIn</a>;
<a class="l" name="427" href="#427">427</a>	}
<a class="l" name="428" href="#428">428</a>
<a class="l" name="429" href="#429">429</a>}
<a class="hl" name="430" href="#430">430</a>