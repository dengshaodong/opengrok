<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["KeepAliveJob",1120],["RTMPConnection",78],["WaitForHandshakeJob",1165]]],["Package","xp",[["org.red5.server.net.rtmp",1]]],["Method","xmt",[["RTMPConnection",229],["addClientStream",521],["close",605],["closeChannel",362],["connect",261],["createOutputStream",402],["createStreamName",871],["deleteStreamById",667],["equals",1094],["execute",1127],["execute",1168],["getChannel",348],["getClientBytesRead",740],["getEncoding",314],["getId",235],["getInvokeId",759],["getLastPingTime",966],["getNextAvailableChannelId",323],["getPendingCall",851],["getPendingVideoMessages",928],["getReadBytes",834],["getState",243],["getStateCode",247],["getStreamByChannelId",576],["getStreamById",550],["getStreamIdForChannel",563],["getStreams",371],["getUsedStreamCount",545],["getWrittenBytes",840],["hashCode",1077],["invoke",750],["invoke",774],["invoke",786],["invoke",791],["invoke",796],["invoke",801],["isChannelUsed",338],["messageDropped",922],["messageReceived",896],["messageSent",908],["newBroadcastStream",413],["notify",810],["notify",815],["notify",822],["notify",827],["onInactive",1012],["ping",683],["ping",935],["pingReceived",955],["rawWrite",692],["receivedBytesRead",725],["registerDeferredResult",1026],["registerPendingCall",769],["registerStream",589],["rememberStreamBufferDuration",1050],["removeClientStream",536],["reserveStreamId",376],["retrievePendingCall",862],["sendPendingServiceCallsCloseError",642],["setId",239],["setMaxHandshakeTimeout",1059],["setMaxInactivity",986],["setPingInterval",976],["setSchedulingService",1005],["setState",255],["setStateCode",251],["setup",298],["startRoundTripMeasurement",993],["startWaitForHandshake",1069],["toString",1016],["unregisterDeferredResult",1041],["unregisterStream",599],["unreserveStreamId",654],["unscheduleWaitForHandshakeJob",277],["updateBytesRead",704],["write",699],["writingMessage",881]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><span class="c">//import static org.red5.server.api.ScopeUtils.getScopeService;</span>
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a><span class="c">//import java.beans.ConstructorProperties;</span>
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=BitSet&amp;project=rtmp_client">BitSet</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Collection&amp;project=rtmp_client">Collection</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashSet&amp;project=rtmp_client">HashSet</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=UUID&amp;project=rtmp_client">UUID</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=concurrent&amp;project=rtmp_client">concurrent</a>.<a href="/source/s?defs=ConcurrentHashMap&amp;project=rtmp_client">ConcurrentHashMap</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=concurrent&amp;project=rtmp_client">concurrent</a>.<a href="/source/s?defs=ConcurrentMap&amp;project=rtmp_client">ConcurrentMap</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=concurrent&amp;project=rtmp_client">concurrent</a>.<a href="/source/s?defs=atomic&amp;project=rtmp_client">atomic</a>.<a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a>;
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=concurrent&amp;project=rtmp_client">concurrent</a>.<a href="/source/s?defs=atomic&amp;project=rtmp_client">atomic</a>.<a href="/source/s?defs=AtomicLong&amp;project=rtmp_client">AtomicLong</a>;
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a href="/source/s?defs=buffer&amp;project=rtmp_client">buffer</a>.<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a>;
<a class="l" name="36" href="#36">36</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=BaseConnection&amp;project=rtmp_client">BaseConnection</a>;
<a class="l" name="37" href="#37">37</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=IScheduledJob&amp;project=rtmp_client">IScheduledJob</a>;
<a class="l" name="38" href="#38">38</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=ISchedulingService&amp;project=rtmp_client">ISchedulingService</a>;
<a class="l" name="39" href="#39">39</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=Red5&amp;project=rtmp_client">Red5</a>;
<a class="hl" name="40" href="#40">40</a><span class="c">//import org.red5.server.api.IScope;</span>
<a class="l" name="41" href="#41">41</a><span class="c">//import org.red5.server.api.stream.IClientBroadcastStream;</span>
<a class="l" name="42" href="#42">42</a><span class="c">//import org.red5.server.api.stream.IClientStream;</span>
<a class="l" name="43" href="#43">43</a><span class="c">//import org.red5.server.api.stream.IPlaylistSubscriberStream;</span>
<a class="l" name="44" href="#44">44</a><span class="c">//import org.red5.server.api.stream.ISingleItemSubscriberStream;</span>
<a class="l" name="45" href="#45">45</a><span class="c">//import org.red5.server.api.stream.IStreamCapableConnection;</span>
<a class="l" name="46" href="#46">46</a><span class="c">//import org.red5.server.exception.ClientRejectedException;</span>
<a class="l" name="47" href="#47">47</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=codec&amp;project=rtmp_client">codec</a>.<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>;
<a class="l" name="48" href="#48">48</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=BytesRead&amp;project=rtmp_client">BytesRead</a>;
<a class="l" name="49" href="#49">49</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>;
<a class="hl" name="50" href="#50">50</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>;
<a class="l" name="51" href="#51">51</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>;
<a class="l" name="52" href="#52">52</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=VideoData&amp;project=rtmp_client">VideoData</a>;
<a class="l" name="53" href="#53">53</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a>;
<a class="l" name="54" href="#54">54</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>;
<a class="l" name="55" href="#55">55</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a>;
<a class="l" name="56" href="#56">56</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a>;
<a class="l" name="57" href="#57">57</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a>;
<a class="l" name="58" href="#58">58</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=IServiceCapableConnection&amp;project=rtmp_client">IServiceCapableConnection</a>;
<a class="l" name="59" href="#59">59</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a>;
<a class="hl" name="60" href="#60">60</a><span class="c">//import org.red5.server.stream.ClientBroadcastStream;</span>
<a class="l" name="61" href="#61">61</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=IClientBroadcastStream&amp;project=rtmp_client">IClientBroadcastStream</a>;
<a class="l" name="62" href="#62">62</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=IClientStream&amp;project=rtmp_client">IClientStream</a>;
<a class="l" name="63" href="#63">63</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=IStreamCapableConnection&amp;project=rtmp_client">IStreamCapableConnection</a>;
<a class="l" name="64" href="#64">64</a><span class="c">//import org.red5.server.stream.IStreamService;</span>
<a class="l" name="65" href="#65">65</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=OutputStream&amp;project=rtmp_client">OutputStream</a>;
<a class="l" name="66" href="#66">66</a><span class="c">//import org.red5.server.stream.PlaylistSubscriberStream;</span>
<a class="l" name="67" href="#67">67</a><span class="c">//import org.red5.server.stream.SingleItemSubscriberStream;</span>
<a class="l" name="68" href="#68">68</a><span class="c">//import org.red5.server.stream.StreamService;</span>
<a class="l" name="69" href="#69">69</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="hl" name="70" href="#70">70</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="71" href="#71">71</a>
<a class="l" name="72" href="#72">72</a><span class="c">/**
<a class="l" name="73" href="#73">73</a> * RTMP connection. Stores information about client streams, data transfer
<a class="l" name="74" href="#74">74</a> * channels, pending RPC calls, bandwidth configuration, used encoding
<a class="l" name="75" href="#75">75</a> * (<a href="/source/s?path=AMF0/">AMF0</a>/<a href="/source/s?path=AMF0/AMF3">AMF3</a>), connection state (is alive, last ping time and ping result) and
<a class="l" name="76" href="#76">76</a> * session.
<a class="l" name="77" href="#77">77</a> */</span>
<a class="l" name="78" href="#78">78</a><b>public</b> <b>abstract</b> <b>class</b> <a class="xc" name="RTMPConnection"/><a href="/source/s?refs=RTMPConnection&amp;project=rtmp_client" class="xc">RTMPConnection</a> <b>extends</b> <a href="/source/s?defs=BaseConnection&amp;project=rtmp_client">BaseConnection</a> <b>implements</b> <a href="/source/s?defs=IStreamCapableConnection&amp;project=rtmp_client">IStreamCapableConnection</a>,<a href="/source/s?defs=IServiceCapableConnection&amp;project=rtmp_client">IServiceCapableConnection</a> {
<a class="l" name="79" href="#79">79</a>
<a class="hl" name="80" href="#80">80</a>	<b>private</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<b>class</b>);
<a class="l" name="81" href="#81">81</a>
<a class="l" name="82" href="#82">82</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="RTMP_CONNECTION_KEY"/><a href="/source/s?refs=RTMP_CONNECTION_KEY&amp;project=rtmp_client" class="xfld">RTMP_CONNECTION_KEY</a> = <span class="s">"rtmp.conn"</span>;
<a class="l" name="83" href="#83">83</a>
<a class="l" name="84" href="#84">84</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="RTMP_HANDSHAKE"/><a href="/source/s?refs=RTMP_HANDSHAKE&amp;project=rtmp_client" class="xfld">RTMP_HANDSHAKE</a> = <span class="s">"rtmp.handshake"</span>;
<a class="l" name="85" href="#85">85</a>
<a class="l" name="86" href="#86">86</a>	<span class="c">/**
<a class="l" name="87" href="#87">87</a>	 * Marker byte for standard or non-encrypted RTMP data.
<a class="l" name="88" href="#88">88</a>	 */</span>
<a class="l" name="89" href="#89">89</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="RTMP_NON_ENCRYPTED"/><a href="/source/s?refs=RTMP_NON_ENCRYPTED&amp;project=rtmp_client" class="xfld">RTMP_NON_ENCRYPTED</a> = (<b>byte</b>) <span class="n">0x03</span>;
<a class="hl" name="90" href="#90">90</a>
<a class="l" name="91" href="#91">91</a>	<span class="c">/**
<a class="l" name="92" href="#92">92</a>	 * Marker byte for encrypted RTMP data.
<a class="l" name="93" href="#93">93</a>	 */</span>
<a class="l" name="94" href="#94">94</a>	<b>public</b> <b>static</b> <b>final</b> <b>byte</b> <a class="xfld" name="RTMP_ENCRYPTED"/><a href="/source/s?refs=RTMP_ENCRYPTED&amp;project=rtmp_client" class="xfld">RTMP_ENCRYPTED</a> = (<b>byte</b>) <span class="n">0x06</span>;
<a class="l" name="95" href="#95">95</a>
<a class="l" name="96" href="#96">96</a>	<span class="c">/**
<a class="l" name="97" href="#97">97</a>	 * Cipher for RTMPE input
<a class="l" name="98" href="#98">98</a>	 */</span>
<a class="l" name="99" href="#99">99</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="RTMPE_CIPHER_IN"/><a href="/source/s?refs=RTMPE_CIPHER_IN&amp;project=rtmp_client" class="xfld">RTMPE_CIPHER_IN</a> = <span class="s">"rtmpe.cipher.in"</span>;
<a class="hl" name="100" href="#100">100</a>
<a class="l" name="101" href="#101">101</a>	<span class="c">/**
<a class="l" name="102" href="#102">102</a>	 * Cipher for RTMPE output
<a class="l" name="103" href="#103">103</a>	 */</span>
<a class="l" name="104" href="#104">104</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="RTMPE_CIPHER_OUT"/><a href="/source/s?refs=RTMPE_CIPHER_OUT&amp;project=rtmp_client" class="xfld">RTMPE_CIPHER_OUT</a> = <span class="s">"rtmpe.cipher.out"</span>;
<a class="l" name="105" href="#105">105</a>
<a class="l" name="106" href="#106">106</a>	<span class="c">/**
<a class="l" name="107" href="#107">107</a>	 * Connection channels
<a class="l" name="108" href="#108">108</a>	 *
<a class="l" name="109" href="#109">109</a>	 * <strong>@see</strong> org.red5.server.net.rtmp.Channel
<a class="hl" name="110" href="#110">110</a>	 */</span>
<a class="l" name="111" href="#111">111</a>	<b>private</b> <a href="/source/s?defs=ConcurrentMap&amp;project=rtmp_client">ConcurrentMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a>&gt; <a class="xfld" name="channels"/><a href="/source/s?refs=channels&amp;project=rtmp_client" class="xfld">channels</a> = <b>new</b> <a href="/source/s?defs=ConcurrentHashMap&amp;project=rtmp_client">ConcurrentHashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a>&gt;();
<a class="l" name="112" href="#112">112</a>
<a class="l" name="113" href="#113">113</a>	<span class="c">/**
<a class="l" name="114" href="#114">114</a>	 * Client streams
<a class="l" name="115" href="#115">115</a>	 *
<a class="l" name="116" href="#116">116</a>	 * <strong>@see</strong> org.red5.server.stream.IClientStream
<a class="l" name="117" href="#117">117</a>	 */</span>
<a class="l" name="118" href="#118">118</a>	<b>private</b> <a href="/source/s?defs=ConcurrentMap&amp;project=rtmp_client">ConcurrentMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=IClientStream&amp;project=rtmp_client">IClientStream</a>&gt; <a class="xfld" name="streams"/><a href="/source/s?refs=streams&amp;project=rtmp_client" class="xfld">streams</a> = <b>new</b> <a href="/source/s?defs=ConcurrentHashMap&amp;project=rtmp_client">ConcurrentHashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=IClientStream&amp;project=rtmp_client">IClientStream</a>&gt;();
<a class="l" name="119" href="#119">119</a>
<a class="hl" name="120" href="#120">120</a>	<b>private</b> <b>final</b> <a href="/source/s?defs=BitSet&amp;project=rtmp_client">BitSet</a> <a class="xfld" name="reservedStreams"/><a href="/source/s?refs=reservedStreams&amp;project=rtmp_client" class="xfld">reservedStreams</a> = <b>new</b> <a href="/source/s?defs=BitSet&amp;project=rtmp_client">BitSet</a>();
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>	<span class="c">/**
<a class="l" name="123" href="#123">123</a>	 * Identifier for remote calls.
<a class="l" name="124" href="#124">124</a>	 */</span>
<a class="l" name="125" href="#125">125</a>	<b>private</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a> <a class="xfld" name="invokeId"/><a href="/source/s?refs=invokeId&amp;project=rtmp_client" class="xfld">invokeId</a> = <b>new</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a>(<span class="n">1</span>);
<a class="l" name="126" href="#126">126</a>
<a class="l" name="127" href="#127">127</a>	<span class="c">/**
<a class="l" name="128" href="#128">128</a>	 * Hash map that stores pending calls and ids as pairs.
<a class="l" name="129" href="#129">129</a>	 */</span>
<a class="hl" name="130" href="#130">130</a>	<b>private</b> <a href="/source/s?defs=ConcurrentMap&amp;project=rtmp_client">ConcurrentMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a>&gt; <a class="xfld" name="pendingCalls"/><a href="/source/s?refs=pendingCalls&amp;project=rtmp_client" class="xfld">pendingCalls</a> = <b>new</b> <a href="/source/s?defs=ConcurrentHashMap&amp;project=rtmp_client">ConcurrentHashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a>&gt;();
<a class="l" name="131" href="#131">131</a>
<a class="l" name="132" href="#132">132</a>	<span class="c">/**
<a class="l" name="133" href="#133">133</a>	 * Deferred results set.
<a class="l" name="134" href="#134">134</a>	 *
<a class="l" name="135" href="#135">135</a>	 * <strong>@see</strong> org.red5.server.net.rtmp.DeferredResult
<a class="l" name="136" href="#136">136</a>	 */</span>
<a class="l" name="137" href="#137">137</a>	<b>private</b> <b>final</b> <a href="/source/s?defs=HashSet&amp;project=rtmp_client">HashSet</a>&lt;<a href="/source/s?defs=DeferredResult&amp;project=rtmp_client">DeferredResult</a>&gt; <a class="xfld" name="deferredResults"/><a href="/source/s?refs=deferredResults&amp;project=rtmp_client" class="xfld">deferredResults</a> = <b>new</b> <a href="/source/s?defs=HashSet&amp;project=rtmp_client">HashSet</a>&lt;<a href="/source/s?defs=DeferredResult&amp;project=rtmp_client">DeferredResult</a>&gt;();
<a class="l" name="138" href="#138">138</a>
<a class="l" name="139" href="#139">139</a>	<span class="c">/**
<a class="hl" name="140" href="#140">140</a>	 * Last ping round trip time
<a class="l" name="141" href="#141">141</a>	 */</span>
<a class="l" name="142" href="#142">142</a>	<b>private</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a> <a class="xfld" name="lastPingTime"/><a href="/source/s?refs=lastPingTime&amp;project=rtmp_client" class="xfld">lastPingTime</a> = <b>new</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a>(-<span class="n">1</span>);
<a class="l" name="143" href="#143">143</a>
<a class="l" name="144" href="#144">144</a>	<span class="c">/**
<a class="l" name="145" href="#145">145</a>	 * Timestamp when last ping command was sent.
<a class="l" name="146" href="#146">146</a>	 */</span>
<a class="l" name="147" href="#147">147</a>	<b>private</b> <a href="/source/s?defs=AtomicLong&amp;project=rtmp_client">AtomicLong</a> <a class="xfld" name="lastPingSent"/><a href="/source/s?refs=lastPingSent&amp;project=rtmp_client" class="xfld">lastPingSent</a> = <b>new</b> <a href="/source/s?defs=AtomicLong&amp;project=rtmp_client">AtomicLong</a>(<span class="n">0</span>);
<a class="l" name="148" href="#148">148</a>
<a class="l" name="149" href="#149">149</a>	<span class="c">/**
<a class="hl" name="150" href="#150">150</a>	 * Timestamp when last ping result was received.
<a class="l" name="151" href="#151">151</a>	 */</span>
<a class="l" name="152" href="#152">152</a>	<b>private</b> <a href="/source/s?defs=AtomicLong&amp;project=rtmp_client">AtomicLong</a> <a class="xfld" name="lastPongReceived"/><a href="/source/s?refs=lastPongReceived&amp;project=rtmp_client" class="xfld">lastPongReceived</a> = <b>new</b> <a href="/source/s?defs=AtomicLong&amp;project=rtmp_client">AtomicLong</a>(<span class="n">0</span>);
<a class="l" name="153" href="#153">153</a>
<a class="l" name="154" href="#154">154</a>	<span class="c">/**
<a class="l" name="155" href="#155">155</a>	 * Name of quartz job that keeps connection alive.
<a class="l" name="156" href="#156">156</a>	 */</span>
<a class="l" name="157" href="#157">157</a>	<b>private</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="keepAliveJobName"/><a href="/source/s?refs=keepAliveJobName&amp;project=rtmp_client" class="xfld">keepAliveJobName</a>;
<a class="l" name="158" href="#158">158</a>
<a class="l" name="159" href="#159">159</a>	<span class="c">/**
<a class="hl" name="160" href="#160">160</a>	 * Ping interval in ms to detect dead clients.
<a class="l" name="161" href="#161">161</a>	 */</span>
<a class="l" name="162" href="#162">162</a>	<b>private</b> <b>volatile</b> <b>int</b> <a class="xfld" name="pingInterval"/><a href="/source/s?refs=pingInterval&amp;project=rtmp_client" class="xfld">pingInterval</a> = <span class="n">5000</span>;
<a class="l" name="163" href="#163">163</a>
<a class="l" name="164" href="#164">164</a>	<span class="c">/**
<a class="l" name="165" href="#165">165</a>	 * Maximum time in ms after which a client is disconnected because of inactivity.
<a class="l" name="166" href="#166">166</a>	 */</span>
<a class="l" name="167" href="#167">167</a>	<b>private</b> <b>volatile</b> <b>int</b> <a class="xfld" name="maxInactivity"/><a href="/source/s?refs=maxInactivity&amp;project=rtmp_client" class="xfld">maxInactivity</a> = <span class="n">60000</span>;
<a class="l" name="168" href="#168">168</a>
<a class="l" name="169" href="#169">169</a>	<span class="c">/**
<a class="hl" name="170" href="#170">170</a>	 * Data read interval
<a class="l" name="171" href="#171">171</a>	 */</span>
<a class="l" name="172" href="#172">172</a>	<b>protected</b> <b>int</b> <a class="xfld" name="bytesReadInterval"/><a href="/source/s?refs=bytesReadInterval&amp;project=rtmp_client" class="xfld">bytesReadInterval</a> = <span class="n">120</span> * <span class="n">1024</span>;
<a class="l" name="173" href="#173">173</a>
<a class="l" name="174" href="#174">174</a>	<span class="c">/**
<a class="l" name="175" href="#175">175</a>	 * Number of bytes to read next.
<a class="l" name="176" href="#176">176</a>	 */</span>
<a class="l" name="177" href="#177">177</a>	<b>protected</b> <b>int</b> <a class="xfld" name="nextBytesRead"/><a href="/source/s?refs=nextBytesRead&amp;project=rtmp_client" class="xfld">nextBytesRead</a> = <span class="n">120</span> * <span class="n">1024</span>;
<a class="l" name="178" href="#178">178</a>
<a class="l" name="179" href="#179">179</a>	<span class="c">/**
<a class="hl" name="180" href="#180">180</a>	 * Number of bytes the client reported to have received.
<a class="l" name="181" href="#181">181</a>	 */</span>
<a class="l" name="182" href="#182">182</a>	<b>private</b> <b>long</b> <a class="xfld" name="clientBytesRead"/><a href="/source/s?refs=clientBytesRead&amp;project=rtmp_client" class="xfld">clientBytesRead</a> = <span class="n">0</span>;
<a class="l" name="183" href="#183">183</a>
<a class="l" name="184" href="#184">184</a>	<span class="c">/**
<a class="l" name="185" href="#185">185</a>	 * Map for pending video packets and stream IDs.
<a class="l" name="186" href="#186">186</a>	 */</span>
<a class="l" name="187" href="#187">187</a>	<b>private</b> <a href="/source/s?defs=ConcurrentMap&amp;project=rtmp_client">ConcurrentMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a>&gt; <a class="xfld" name="pendingVideos"/><a href="/source/s?refs=pendingVideos&amp;project=rtmp_client" class="xfld">pendingVideos</a> = <b>new</b> <a href="/source/s?defs=ConcurrentHashMap&amp;project=rtmp_client">ConcurrentHashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a>&gt;();
<a class="l" name="188" href="#188">188</a>
<a class="l" name="189" href="#189">189</a>	<span class="c">/**
<a class="hl" name="190" href="#190">190</a>	 * Number of streams used.
<a class="l" name="191" href="#191">191</a>	 */</span>
<a class="l" name="192" href="#192">192</a>	<b>private</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a> <a class="xfld" name="usedStreams"/><a href="/source/s?refs=usedStreams&amp;project=rtmp_client" class="xfld">usedStreams</a> = <b>new</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a>(<span class="n">0</span>);
<a class="l" name="193" href="#193">193</a>
<a class="l" name="194" href="#194">194</a>	<span class="c">/**
<a class="l" name="195" href="#195">195</a>	 * AMF version, AMF0 by default.
<a class="l" name="196" href="#196">196</a>	 */</span>
<a class="l" name="197" href="#197">197</a>	<b>private</b> <b>volatile</b> <a href="/source/s?defs=Encoding&amp;project=rtmp_client">Encoding</a> <a class="xfld" name="encoding"/><a href="/source/s?refs=encoding&amp;project=rtmp_client" class="xfld">encoding</a> = <a href="/source/s?defs=Encoding&amp;project=rtmp_client">Encoding</a>.<a href="/source/s?defs=AMF0&amp;project=rtmp_client">AMF0</a>;
<a class="l" name="198" href="#198">198</a>
<a class="l" name="199" href="#199">199</a>	<span class="c">/**
<a class="hl" name="200" href="#200">200</a>	 * Remembered stream buffer durations.
<a class="l" name="201" href="#201">201</a>	 */</span>
<a class="l" name="202" href="#202">202</a>	<b>private</b> <a href="/source/s?defs=ConcurrentMap&amp;project=rtmp_client">ConcurrentMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt; <a class="xfld" name="streamBuffers"/><a href="/source/s?refs=streamBuffers&amp;project=rtmp_client" class="xfld">streamBuffers</a> = <b>new</b> <a href="/source/s?defs=ConcurrentHashMap&amp;project=rtmp_client">ConcurrentHashMap</a>&lt;<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>, <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>&gt;();
<a class="l" name="203" href="#203">203</a>
<a class="l" name="204" href="#204">204</a>	<span class="c">/**
<a class="l" name="205" href="#205">205</a>	 * Name of job that is waiting for a valid handshake.
<a class="l" name="206" href="#206">206</a>	 */</span>
<a class="l" name="207" href="#207">207</a>	<b>private</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="waitForHandshakeJob"/><a href="/source/s?refs=waitForHandshakeJob&amp;project=rtmp_client" class="xfld">waitForHandshakeJob</a>;
<a class="l" name="208" href="#208">208</a>
<a class="l" name="209" href="#209">209</a>	<span class="c">/**
<a class="hl" name="210" href="#210">210</a>	 * Maximum time in milliseconds to wait for a valid handshake.
<a class="l" name="211" href="#211">211</a>	 */</span>
<a class="l" name="212" href="#212">212</a>	<b>private</b> <b>volatile</b> <b>int</b> <a class="xfld" name="maxHandshakeTimeout"/><a href="/source/s?refs=maxHandshakeTimeout&amp;project=rtmp_client" class="xfld">maxHandshakeTimeout</a> = <span class="n">5000</span>;
<a class="l" name="213" href="#213">213</a>
<a class="l" name="214" href="#214">214</a>	<b>protected</b> <b>volatile</b> <b>int</b> <a class="xfld" name="clientId"/><a href="/source/s?refs=clientId&amp;project=rtmp_client" class="xfld">clientId</a>;
<a class="l" name="215" href="#215">215</a>
<a class="l" name="216" href="#216">216</a>	<span class="c">/**
<a class="l" name="217" href="#217">217</a>	 * protocol state
<a class="l" name="218" href="#218">218</a>	 */</span>
<a class="l" name="219" href="#219">219</a>	<b>protected</b> <b>volatile</b> <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xfld" name="state"/><a href="/source/s?refs=state&amp;project=rtmp_client" class="xfld">state</a>;
<a class="hl" name="220" href="#220">220</a>
<a class="l" name="221" href="#221">221</a>	<b>private</b> <a href="/source/s?defs=ISchedulingService&amp;project=rtmp_client">ISchedulingService</a> <a class="xfld" name="schedulingService"/><a href="/source/s?refs=schedulingService&amp;project=rtmp_client" class="xfld">schedulingService</a>;
<a class="l" name="222" href="#222">222</a>
<a class="l" name="223" href="#223">223</a>	<span class="c">/**
<a class="l" name="224" href="#224">224</a>	 * Creates anonymous RTMP connection without scope.
<a class="l" name="225" href="#225">225</a>	 *
<a class="l" name="226" href="#226">226</a>	 * <strong>@param</strong> <em>type</em> Connection type
<a class="l" name="227" href="#227">227</a>	 */</span>
<a class="l" name="228" href="#228">228</a>	<span class="c">//@ConstructorProperties({ "type" })</span>
<a class="l" name="229" href="#229">229</a>	<b>public</b> <a class="xmt" name="RTMPConnection"/><a href="/source/s?refs=RTMPConnection&amp;project=rtmp_client" class="xmt">RTMPConnection</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="type"/><a href="/source/s?refs=type&amp;project=rtmp_client" class="xa">type</a>) {
<a class="hl" name="230" href="#230">230</a>		<span class="c">// We start with an anonymous connection without a scope.</span>
<a class="l" name="231" href="#231">231</a>		<span class="c">// These parameters will be set during the call of "connect" later.</span>
<a class="l" name="232" href="#232">232</a>		<b>super</b>(<a class="d" href="#type">type</a>);
<a class="l" name="233" href="#233">233</a>	}
<a class="l" name="234" href="#234">234</a>
<a class="l" name="235" href="#235">235</a>	<b>public</b> <b>int</b> <a class="xmt" name="getId"/><a href="/source/s?refs=getId&amp;project=rtmp_client" class="xmt">getId</a>() {
<a class="l" name="236" href="#236">236</a>		<b>return</b> <a href="/source/s?defs=clientId&amp;project=rtmp_client">clientId</a>;
<a class="l" name="237" href="#237">237</a>	}
<a class="l" name="238" href="#238">238</a>
<a class="l" name="239" href="#239">239</a>	<b>public</b> <b>void</b> <a class="xmt" name="setId"/><a href="/source/s?refs=setId&amp;project=rtmp_client" class="xmt">setId</a>(<b>int</b> <a class="xa" name="clientId"/><a href="/source/s?refs=clientId&amp;project=rtmp_client" class="xa">clientId</a>) {
<a class="hl" name="240" href="#240">240</a>		<b>this</b>.<a href="/source/s?defs=clientId&amp;project=rtmp_client">clientId</a> = <a href="/source/s?defs=clientId&amp;project=rtmp_client">clientId</a>;
<a class="l" name="241" href="#241">241</a>	}
<a class="l" name="242" href="#242">242</a>
<a class="l" name="243" href="#243">243</a>	<b>public</b> <a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xmt" name="getState"/><a href="/source/s?refs=getState&amp;project=rtmp_client" class="xmt">getState</a>() {
<a class="l" name="244" href="#244">244</a>		<b>return</b> <a href="/source/s?defs=state&amp;project=rtmp_client">state</a>;
<a class="l" name="245" href="#245">245</a>	}
<a class="l" name="246" href="#246">246</a>
<a class="l" name="247" href="#247">247</a>	<b>public</b> <b>byte</b> <a class="xmt" name="getStateCode"/><a href="/source/s?refs=getStateCode&amp;project=rtmp_client" class="xmt">getStateCode</a>() {
<a class="l" name="248" href="#248">248</a>		<b>return</b> <a href="/source/s?defs=state&amp;project=rtmp_client">state</a>.<a class="d" href="#getState">getState</a>();
<a class="l" name="249" href="#249">249</a>	}
<a class="hl" name="250" href="#250">250</a>
<a class="l" name="251" href="#251">251</a>	<b>public</b> <b>void</b> <a class="xmt" name="setStateCode"/><a href="/source/s?refs=setStateCode&amp;project=rtmp_client" class="xmt">setStateCode</a>(<b>byte</b> <a class="xa" name="code"/><a href="/source/s?refs=code&amp;project=rtmp_client" class="xa">code</a>) {
<a class="l" name="252" href="#252">252</a>		<a href="/source/s?defs=state&amp;project=rtmp_client">state</a>.<a class="d" href="#setState">setState</a>(<a class="d" href="#code">code</a>);
<a class="l" name="253" href="#253">253</a>	}
<a class="l" name="254" href="#254">254</a>
<a class="l" name="255" href="#255">255</a>	<b>public</b> <b>void</b> <a class="xmt" name="setState"/><a href="/source/s?refs=setState&amp;project=rtmp_client" class="xmt">setState</a>(<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a> <a class="xa" name="state"/><a href="/source/s?refs=state&amp;project=rtmp_client" class="xa">state</a>) {
<a class="l" name="256" href="#256">256</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Set state: {}"</span>, <a href="/source/s?defs=state&amp;project=rtmp_client">state</a>);
<a class="l" name="257" href="#257">257</a>		<b>this</b>.<a href="/source/s?defs=state&amp;project=rtmp_client">state</a> = <a href="/source/s?defs=state&amp;project=rtmp_client">state</a>;
<a class="l" name="258" href="#258">258</a>	}
<a class="l" name="259" href="#259">259</a>
<a class="hl" name="260" href="#260">260</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="261" href="#261">261</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="connect"/><a href="/source/s?refs=connect&amp;project=rtmp_client" class="xmt">connect</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xa" name="params"/><a href="/source/s?refs=params&amp;project=rtmp_client" class="xa">params</a>) {
<a class="l" name="262" href="#262">262</a><span class="c">//		log.debug("Connect scope: {}", newScope);</span>
<a class="l" name="263" href="#263">263</a>		<b>try</b> {
<a class="l" name="264" href="#264">264</a>			<b>boolean</b> <a href="/source/s?defs=success&amp;project=rtmp_client">success</a> = <b>super</b>.<a class="d" href="#connect">connect</a>( <a href="/source/s?defs=params&amp;project=rtmp_client">params</a>);
<a class="l" name="265" href="#265">265</a>			<b>if</b> (<a href="/source/s?defs=success&amp;project=rtmp_client">success</a>) {
<a class="l" name="266" href="#266">266</a>				<a class="d" href="#unscheduleWaitForHandshakeJob">unscheduleWaitForHandshakeJob</a>();
<a class="l" name="267" href="#267">267</a>			}
<a class="l" name="268" href="#268">268</a>			<b>return</b> <a href="/source/s?defs=success&amp;project=rtmp_client">success</a>;
<a class="l" name="269" href="#269">269</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="hl" name="270" href="#270">270</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Client rejected, unscheduling waitForHandshakeJob"</span>, e);
<a class="l" name="271" href="#271">271</a>			<a class="d" href="#unscheduleWaitForHandshakeJob">unscheduleWaitForHandshakeJob</a>();
<a class="l" name="272" href="#272">272</a><span class="c">//			throw e;</span>
<a class="l" name="273" href="#273">273</a>		}
<a class="l" name="274" href="#274">274</a>		<b>return</b> <b>false</b>;
<a class="l" name="275" href="#275">275</a>	}
<a class="l" name="276" href="#276">276</a>
<a class="l" name="277" href="#277">277</a>	<b>private</b> <b>void</b> <a class="xmt" name="unscheduleWaitForHandshakeJob"/><a href="/source/s?refs=unscheduleWaitForHandshakeJob&amp;project=rtmp_client" class="xmt">unscheduleWaitForHandshakeJob</a>() {
<a class="l" name="278" href="#278">278</a>		<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=lock&amp;project=rtmp_client">lock</a>();
<a class="l" name="279" href="#279">279</a>		<b>try</b> {
<a class="hl" name="280" href="#280">280</a>			<b>if</b> (<a class="d" href="#waitForHandshakeJob">waitForHandshakeJob</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="281" href="#281">281</a>				<a href="/source/s?defs=schedulingService&amp;project=rtmp_client">schedulingService</a>.<a href="/source/s?defs=removeScheduledJob&amp;project=rtmp_client">removeScheduledJob</a>(<a class="d" href="#waitForHandshakeJob">waitForHandshakeJob</a>);
<a class="l" name="282" href="#282">282</a>				<a class="d" href="#waitForHandshakeJob">waitForHandshakeJob</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="283" href="#283">283</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Removed waitForHandshakeJob for: {}"</span>, <a class="d" href="#getId">getId</a>());
<a class="l" name="284" href="#284">284</a>			}
<a class="l" name="285" href="#285">285</a>		} <b>finally</b> {
<a class="l" name="286" href="#286">286</a>			<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=unlock&amp;project=rtmp_client">unlock</a>();
<a class="l" name="287" href="#287">287</a>		}
<a class="l" name="288" href="#288">288</a>	}
<a class="l" name="289" href="#289">289</a>
<a class="hl" name="290" href="#290">290</a>	<span class="c">/**
<a class="l" name="291" href="#291">291</a>	 * Initialize connection.
<a class="l" name="292" href="#292">292</a>	 *
<a class="l" name="293" href="#293">293</a>	 * <strong>@param</strong> <em>host</em> Connection host
<a class="l" name="294" href="#294">294</a>	 * <strong>@param</strong> <em>path</em> Connection path
<a class="l" name="295" href="#295">295</a>	 * <strong>@param</strong> <em>sessionId</em> Connection session id
<a class="l" name="296" href="#296">296</a>	 * <strong>@param</strong> <em>params</em> Params passed from client
<a class="l" name="297" href="#297">297</a>	 */</span>
<a class="l" name="298" href="#298">298</a>	<b>public</b> <b>void</b> <a class="xmt" name="setup"/><a href="/source/s?refs=setup&amp;project=rtmp_client" class="xmt">setup</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="host"/><a href="/source/s?refs=host&amp;project=rtmp_client" class="xa">host</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="path"/><a href="/source/s?refs=path&amp;project=rtmp_client" class="xa">path</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="sessionId"/><a href="/source/s?refs=sessionId&amp;project=rtmp_client" class="xa">sessionId</a>, <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xa" name="params"/><a href="/source/s?refs=params&amp;project=rtmp_client" class="xa">params</a>) {
<a class="l" name="299" href="#299">299</a>		<b>this</b>.<a class="d" href="#host">host</a> = <a class="d" href="#host">host</a>;
<a class="hl" name="300" href="#300">300</a>		<b>this</b>.<a class="d" href="#path">path</a> = <a class="d" href="#path">path</a>;
<a class="l" name="301" href="#301">301</a>		<b>this</b>.<a class="d" href="#sessionId">sessionId</a> = <a class="d" href="#sessionId">sessionId</a>;
<a class="l" name="302" href="#302">302</a>		<b>this</b>.<a href="/source/s?defs=params&amp;project=rtmp_client">params</a> = <a href="/source/s?defs=params&amp;project=rtmp_client">params</a>;
<a class="l" name="303" href="#303">303</a>		<b>if</b> (<a href="/source/s?defs=params&amp;project=rtmp_client">params</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<span class="s">"objectEncoding"</span>) == <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<span class="n">3</span>)) {
<a class="l" name="304" href="#304">304</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"Setting object encoding to AMF3"</span>);
<a class="l" name="305" href="#305">305</a>			<a class="d" href="#encoding">encoding</a> = <a href="/source/s?defs=Encoding&amp;project=rtmp_client">Encoding</a>.<a href="/source/s?defs=AMF3&amp;project=rtmp_client">AMF3</a>;
<a class="l" name="306" href="#306">306</a>		}
<a class="l" name="307" href="#307">307</a>	}
<a class="l" name="308" href="#308">308</a>
<a class="l" name="309" href="#309">309</a>	<span class="c">/**
<a class="hl" name="310" href="#310">310</a>	 * Return AMF protocol encoding used by this connection.
<a class="l" name="311" href="#311">311</a>	 *
<a class="l" name="312" href="#312">312</a>	 * <strong>@return</strong> AMF encoding used by connection
<a class="l" name="313" href="#313">313</a>	 */</span>
<a class="l" name="314" href="#314">314</a>	<b>public</b> <a href="/source/s?defs=Encoding&amp;project=rtmp_client">Encoding</a> <a class="xmt" name="getEncoding"/><a href="/source/s?refs=getEncoding&amp;project=rtmp_client" class="xmt">getEncoding</a>() {
<a class="l" name="315" href="#315">315</a>		<b>return</b> <a class="d" href="#encoding">encoding</a>;
<a class="l" name="316" href="#316">316</a>	}
<a class="l" name="317" href="#317">317</a>
<a class="l" name="318" href="#318">318</a>	<span class="c">/**
<a class="l" name="319" href="#319">319</a>	 * Getter for next available channel id.
<a class="hl" name="320" href="#320">320</a>	 *
<a class="l" name="321" href="#321">321</a>	 * <strong>@return</strong> Next available channel id
<a class="l" name="322" href="#322">322</a>	 */</span>
<a class="l" name="323" href="#323">323</a>	<b>public</b> <b>int</b> <a class="xmt" name="getNextAvailableChannelId"/><a href="/source/s?refs=getNextAvailableChannelId&amp;project=rtmp_client" class="xmt">getNextAvailableChannelId</a>() {
<a class="l" name="324" href="#324">324</a>		<b>int</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <span class="n">4</span>;
<a class="l" name="325" href="#325">325</a>		<b>while</b> (<a class="d" href="#isChannelUsed">isChannelUsed</a>(<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>)) {
<a class="l" name="326" href="#326">326</a>			<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>++;
<a class="l" name="327" href="#327">327</a>		}
<a class="l" name="328" href="#328">328</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="329" href="#329">329</a>	}
<a class="hl" name="330" href="#330">330</a>
<a class="l" name="331" href="#331">331</a>	<span class="c">/**
<a class="l" name="332" href="#332">332</a>	 * Checks whether channel is used.
<a class="l" name="333" href="#333">333</a>	 *
<a class="l" name="334" href="#334">334</a>	 * <strong>@param</strong> <em>channelId</em> Channel id
<a class="l" name="335" href="#335">335</a>	 * <strong>@return</strong> &lt;code&gt;true&lt;/code&gt; if channel is in use, &lt;code&gt;false&lt;/code&gt;
<a class="l" name="336" href="#336">336</a>	 *         otherwise
<a class="l" name="337" href="#337">337</a>	 */</span>
<a class="l" name="338" href="#338">338</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="isChannelUsed"/><a href="/source/s?refs=isChannelUsed&amp;project=rtmp_client" class="xmt">isChannelUsed</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>) {
<a class="l" name="339" href="#339">339</a>		<b>return</b> <a class="d" href="#channels">channels</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>) != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="hl" name="340" href="#340">340</a>	}
<a class="l" name="341" href="#341">341</a>
<a class="l" name="342" href="#342">342</a>	<span class="c">/**
<a class="l" name="343" href="#343">343</a>	 * Return channel by id.
<a class="l" name="344" href="#344">344</a>	 *
<a class="l" name="345" href="#345">345</a>	 * <strong>@param</strong> <em>channelId</em> Channel id
<a class="l" name="346" href="#346">346</a>	 * <strong>@return</strong> Channel by id
<a class="l" name="347" href="#347">347</a>	 */</span>
<a class="l" name="348" href="#348">348</a>	<b>public</b> <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a class="xmt" name="getChannel"/><a href="/source/s?refs=getChannel&amp;project=rtmp_client" class="xmt">getChannel</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>) {
<a class="l" name="349" href="#349">349</a>		<b>final</b> <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <b>new</b> <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a>(<b>this</b>, <a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>);
<a class="hl" name="350" href="#350">350</a>		<a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a class="d" href="#channels">channels</a>.<a href="/source/s?defs=putIfAbsent&amp;project=rtmp_client">putIfAbsent</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="351" href="#351">351</a>		<b>if</b> (<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="352" href="#352">352</a>			<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>;
<a class="l" name="353" href="#353">353</a>		}
<a class="l" name="354" href="#354">354</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="355" href="#355">355</a>	}
<a class="l" name="356" href="#356">356</a>
<a class="l" name="357" href="#357">357</a>	<span class="c">/**
<a class="l" name="358" href="#358">358</a>	 * Closes channel.
<a class="l" name="359" href="#359">359</a>	 *
<a class="hl" name="360" href="#360">360</a>	 * <strong>@param</strong> <em>channelId</em> Channel id
<a class="l" name="361" href="#361">361</a>	 */</span>
<a class="l" name="362" href="#362">362</a>	<b>public</b> <b>void</b> <a class="xmt" name="closeChannel"/><a href="/source/s?refs=closeChannel&amp;project=rtmp_client" class="xmt">closeChannel</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>) {
<a class="l" name="363" href="#363">363</a>		<a class="d" href="#channels">channels</a>.<a href="/source/s?defs=remove&amp;project=rtmp_client">remove</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>);
<a class="l" name="364" href="#364">364</a>	}
<a class="l" name="365" href="#365">365</a>
<a class="l" name="366" href="#366">366</a>	<span class="c">/**
<a class="l" name="367" href="#367">367</a>	 * Getter for client streams.
<a class="l" name="368" href="#368">368</a>	 *
<a class="l" name="369" href="#369">369</a>	 * <strong>@return</strong> Client streams as array
<a class="hl" name="370" href="#370">370</a>	 */</span>
<a class="l" name="371" href="#371">371</a>	<b>protected</b> <a href="/source/s?defs=Collection&amp;project=rtmp_client">Collection</a>&lt;<a href="/source/s?defs=IClientStream&amp;project=rtmp_client">IClientStream</a>&gt; <a class="xmt" name="getStreams"/><a href="/source/s?refs=getStreams&amp;project=rtmp_client" class="xmt">getStreams</a>() {
<a class="l" name="372" href="#372">372</a>		<b>return</b> <a class="d" href="#streams">streams</a>.<a href="/source/s?defs=values&amp;project=rtmp_client">values</a>();
<a class="l" name="373" href="#373">373</a>	}
<a class="l" name="374" href="#374">374</a>
<a class="l" name="375" href="#375">375</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="376" href="#376">376</a>	<b>public</b> <b>int</b> <a class="xmt" name="reserveStreamId"/><a href="/source/s?refs=reserveStreamId&amp;project=rtmp_client" class="xmt">reserveStreamId</a>() {
<a class="l" name="377" href="#377">377</a>		<b>int</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = -<span class="n">1</span>;
<a class="l" name="378" href="#378">378</a>		<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=lock&amp;project=rtmp_client">lock</a>();
<a class="l" name="379" href="#379">379</a>		<b>try</b> {
<a class="hl" name="380" href="#380">380</a>			<b>for</b> (<b>int</b> i = <span class="n">0</span>; <b>true</b>; i++) {
<a class="l" name="381" href="#381">381</a>				<b>if</b> (!<a class="d" href="#reservedStreams">reservedStreams</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(i)) {
<a class="l" name="382" href="#382">382</a>					<a class="d" href="#reservedStreams">reservedStreams</a>.<a href="/source/s?defs=set&amp;project=rtmp_client">set</a>(i);
<a class="l" name="383" href="#383">383</a>					<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = i;
<a class="l" name="384" href="#384">384</a>					<b>break</b>;
<a class="l" name="385" href="#385">385</a>				}
<a class="l" name="386" href="#386">386</a>			}
<a class="l" name="387" href="#387">387</a>		} <b>finally</b> {
<a class="l" name="388" href="#388">388</a>			<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=unlock&amp;project=rtmp_client">unlock</a>();
<a class="l" name="389" href="#389">389</a>		}
<a class="hl" name="390" href="#390">390</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> + <span class="n">1</span>;
<a class="l" name="391" href="#391">391</a>	}
<a class="l" name="392" href="#392">392</a>
<a class="l" name="393" href="#393">393</a>	<span class="c">/**
<a class="l" name="394" href="#394">394</a>	 * Creates output stream object from stream id. Output stream consists of
<a class="l" name="395" href="#395">395</a>	 * audio, data and video channels.
<a class="l" name="396" href="#396">396</a>	 *
<a class="l" name="397" href="#397">397</a>	 * <strong>@see</strong> org.red5.server.stream.OutputStream
<a class="l" name="398" href="#398">398</a>	 *
<a class="l" name="399" href="#399">399</a>	 * <strong>@param</strong> <em>streamId</em> Stream id
<a class="hl" name="400" href="#400">400</a>	 * <strong>@return</strong> Output stream object
<a class="l" name="401" href="#401">401</a>	 */</span>
<a class="l" name="402" href="#402">402</a>	<b>public</b> <a href="/source/s?defs=OutputStream&amp;project=rtmp_client">OutputStream</a> <a class="xmt" name="createOutputStream"/><a href="/source/s?refs=createOutputStream&amp;project=rtmp_client" class="xmt">createOutputStream</a>(<b>int</b> <a class="xa" name="streamId"/><a href="/source/s?refs=streamId&amp;project=rtmp_client" class="xa">streamId</a>) {
<a class="l" name="403" href="#403">403</a>		<b>int</b> <a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a> = (<span class="n">4</span> + ((<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a> - <span class="n">1</span>) * <span class="n">5</span>));
<a class="l" name="404" href="#404">404</a>		<b>final</b> <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a href="/source/s?defs=data&amp;project=rtmp_client">data</a> = <a class="d" href="#getChannel">getChannel</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>++);
<a class="l" name="405" href="#405">405</a>		<b>final</b> <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a href="/source/s?defs=video&amp;project=rtmp_client">video</a> = <a class="d" href="#getChannel">getChannel</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>++);
<a class="l" name="406" href="#406">406</a>		<b>final</b> <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a href="/source/s?defs=audio&amp;project=rtmp_client">audio</a> = <a class="d" href="#getChannel">getChannel</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>++);
<a class="l" name="407" href="#407">407</a>		<span class="c">// final Channel unknown = getChannel(channelId++);</span>
<a class="l" name="408" href="#408">408</a>		<span class="c">// final Channel ctrl = getChannel(channelId++);</span>
<a class="l" name="409" href="#409">409</a>		<b>return</b> <b>new</b> <a href="/source/s?defs=OutputStream&amp;project=rtmp_client">OutputStream</a>(<a href="/source/s?defs=video&amp;project=rtmp_client">video</a>, <a href="/source/s?defs=audio&amp;project=rtmp_client">audio</a>, <a href="/source/s?defs=data&amp;project=rtmp_client">data</a>);
<a class="hl" name="410" href="#410">410</a>	}
<a class="l" name="411" href="#411">411</a>
<a class="l" name="412" href="#412">412</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="413" href="#413">413</a>	<b>public</b> <a href="/source/s?defs=IClientBroadcastStream&amp;project=rtmp_client">IClientBroadcastStream</a> <a class="xmt" name="newBroadcastStream"/><a href="/source/s?refs=newBroadcastStream&amp;project=rtmp_client" class="xmt">newBroadcastStream</a>(<b>int</b> <a class="xa" name="streamId"/><a href="/source/s?refs=streamId&amp;project=rtmp_client" class="xa">streamId</a>) {
<a class="l" name="414" href="#414">414</a><span class="c">//		getReadLock().lock();</span>
<a class="l" name="415" href="#415">415</a><span class="c">//		try {</span>
<a class="l" name="416" href="#416">416</a><span class="c">//			int index = streamId - 1;</span>
<a class="l" name="417" href="#417">417</a><span class="c">//			if (index &lt; 0 || !reservedStreams.get(index)) {</span>
<a class="l" name="418" href="#418">418</a><span class="c">//				// StreamId has not been reserved before</span>
<a class="l" name="419" href="#419">419</a><span class="c">//				return null;</span>
<a class="hl" name="420" href="#420">420</a><span class="c">//			}</span>
<a class="l" name="421" href="#421">421</a><span class="c">//		} finally {</span>
<a class="l" name="422" href="#422">422</a><span class="c">//			getReadLock().unlock();</span>
<a class="l" name="423" href="#423">423</a><span class="c">//		}</span>
<a class="l" name="424" href="#424">424</a><span class="c">//</span>
<a class="l" name="425" href="#425">425</a><span class="c">//		if (streams.get(streamId - 1) != null) {</span>
<a class="l" name="426" href="#426">426</a><span class="c">//			// Another stream already exists with this id</span>
<a class="l" name="427" href="#427">427</a><span class="c">//			return null;</span>
<a class="l" name="428" href="#428">428</a><span class="c">//		}</span>
<a class="l" name="429" href="#429">429</a><span class="c">//		/**</span>
<a class="hl" name="430" href="#430">430</a><span class="c">//		 * Picking up the ClientBroadcastStream defined as a spring</span>
<a class="l" name="431" href="#431">431</a><span class="c">//		 * prototype in <a href="/source/s?path=red5-common.xml&amp;project=rtmp_client">red5-common.xml</a></span>
<a class="l" name="432" href="#432">432</a><span class="c">//		 */</span>
<a class="l" name="433" href="#433">433</a><span class="c">//		ClientBroadcastStream cbs = new clientBroadcastStream();</span>
<a class="l" name="434" href="#434">434</a><span class="c">//		Integer buffer = streamBuffers.get(streamId - 1);</span>
<a class="l" name="435" href="#435">435</a><span class="c">//		if (buffer != null) {</span>
<a class="l" name="436" href="#436">436</a><span class="c">//			cbs.setClientBufferDuration(buffer);</span>
<a class="l" name="437" href="#437">437</a><span class="c">//		}</span>
<a class="l" name="438" href="#438">438</a><span class="c">//		cbs.setStreamId(streamId);</span>
<a class="l" name="439" href="#439">439</a><span class="c">//		cbs.setConnection(this);</span>
<a class="hl" name="440" href="#440">440</a><span class="c">//		cbs.setName(createStreamName());</span>
<a class="l" name="441" href="#441">441</a><span class="c">////		cbs.setScope(this.getScope());</span>
<a class="l" name="442" href="#442">442</a><span class="c">//</span>
<a class="l" name="443" href="#443">443</a><span class="c">//		registerStream(cbs);</span>
<a class="l" name="444" href="#444">444</a><span class="c">//		usedStreams.incrementAndGet();</span>
<a class="l" name="445" href="#445">445</a><span class="c">//		return cbs;</span>
<a class="l" name="446" href="#446">446</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="447" href="#447">447</a>	}
<a class="l" name="448" href="#448">448</a>
<a class="l" name="449" href="#449">449</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="450" href="#450">450</a><span class="c">//	public ISingleItemSubscriberStream newSingleItemSubscriberStream(int streamId) {</span>
<a class="l" name="451" href="#451">451</a><span class="c">//		getReadLock().lock();</span>
<a class="l" name="452" href="#452">452</a><span class="c">//		try {</span>
<a class="l" name="453" href="#453">453</a><span class="c">//			int index = streamId - 1;</span>
<a class="l" name="454" href="#454">454</a><span class="c">//			if (index &lt; 0 || !reservedStreams.get(streamId - 1)) {</span>
<a class="l" name="455" href="#455">455</a><span class="c">//				// StreamId has not been reserved before</span>
<a class="l" name="456" href="#456">456</a><span class="c">//				return null;</span>
<a class="l" name="457" href="#457">457</a><span class="c">//			}</span>
<a class="l" name="458" href="#458">458</a><span class="c">//		} finally {</span>
<a class="l" name="459" href="#459">459</a><span class="c">//			getReadLock().unlock();</span>
<a class="hl" name="460" href="#460">460</a><span class="c">//		}</span>
<a class="l" name="461" href="#461">461</a><span class="c">//</span>
<a class="l" name="462" href="#462">462</a><span class="c">//		if (streams.get(streamId - 1) != null) {</span>
<a class="l" name="463" href="#463">463</a><span class="c">//			// Another stream already exists with this id</span>
<a class="l" name="464" href="#464">464</a><span class="c">//			return null;</span>
<a class="l" name="465" href="#465">465</a><span class="c">//		}</span>
<a class="l" name="466" href="#466">466</a><span class="c">//		/**</span>
<a class="l" name="467" href="#467">467</a><span class="c">//		 * Picking up the SingleItemSubscriberStream defined as a Spring</span>
<a class="l" name="468" href="#468">468</a><span class="c">//		 * prototype in <a href="/source/s?path=red5-common.xml&amp;project=rtmp_client">red5-common.xml</a></span>
<a class="l" name="469" href="#469">469</a><span class="c">//		 */</span>
<a class="hl" name="470" href="#470">470</a><span class="c">////		SingleItemSubscriberStream siss = new SingleItemSubscriberStream();</span>
<a class="l" name="471" href="#471">471</a><span class="c">////		Integer buffer = streamBuffers.get(streamId - 1);</span>
<a class="l" name="472" href="#472">472</a><span class="c">////		if (buffer != null) {</span>
<a class="l" name="473" href="#473">473</a><span class="c">////			siss.setClientBufferDuration(buffer);</span>
<a class="l" name="474" href="#474">474</a><span class="c">////		}</span>
<a class="l" name="475" href="#475">475</a><span class="c">////		siss.setName(createStreamName());</span>
<a class="l" name="476" href="#476">476</a><span class="c">////		siss.setConnection(this);</span>
<a class="l" name="477" href="#477">477</a><span class="c">////		siss.setScope(this.getScope());</span>
<a class="l" name="478" href="#478">478</a><span class="c">////		siss.setStreamId(streamId);</span>
<a class="l" name="479" href="#479">479</a><span class="c">////		registerStream(siss);</span>
<a class="hl" name="480" href="#480">480</a><span class="c">////		usedStreams.incrementAndGet();</span>
<a class="l" name="481" href="#481">481</a><span class="c">////		return siss;</span>
<a class="l" name="482" href="#482">482</a><span class="c">//		return null;</span>
<a class="l" name="483" href="#483">483</a><span class="c">//	}</span>
<a class="l" name="484" href="#484">484</a>
<a class="l" name="485" href="#485">485</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="486" href="#486">486</a><span class="c">//	public IPlaylistSubscriberStream newPlaylistSubscriberStream(int streamId) {</span>
<a class="l" name="487" href="#487">487</a><span class="c">//		getReadLock().lock();</span>
<a class="l" name="488" href="#488">488</a><span class="c">//		try {</span>
<a class="l" name="489" href="#489">489</a><span class="c">//			int index = streamId - 1;</span>
<a class="hl" name="490" href="#490">490</a><span class="c">//			if (index &lt; 0 || !reservedStreams.get(streamId - 1)) {</span>
<a class="l" name="491" href="#491">491</a><span class="c">//				// StreamId has not been reserved before</span>
<a class="l" name="492" href="#492">492</a><span class="c">//				return null;</span>
<a class="l" name="493" href="#493">493</a><span class="c">//			}</span>
<a class="l" name="494" href="#494">494</a><span class="c">//		} finally {</span>
<a class="l" name="495" href="#495">495</a><span class="c">//			getReadLock().unlock();</span>
<a class="l" name="496" href="#496">496</a><span class="c">//		}</span>
<a class="l" name="497" href="#497">497</a><span class="c">//</span>
<a class="l" name="498" href="#498">498</a><span class="c">//		if (streams.get(streamId - 1) != null) {</span>
<a class="l" name="499" href="#499">499</a><span class="c">//			// Another stream already exists with this id</span>
<a class="hl" name="500" href="#500">500</a><span class="c">//			return null;</span>
<a class="l" name="501" href="#501">501</a><span class="c">//		}</span>
<a class="l" name="502" href="#502">502</a><span class="c">//		/**</span>
<a class="l" name="503" href="#503">503</a><span class="c">//		 * Picking up the PlaylistSubscriberStream defined as a Spring</span>
<a class="l" name="504" href="#504">504</a><span class="c">//		 * prototype in <a href="/source/s?path=red5-common.xml&amp;project=rtmp_client">red5-common.xml</a></span>
<a class="l" name="505" href="#505">505</a><span class="c">//		 */</span>
<a class="l" name="506" href="#506">506</a><span class="c">//		PlaylistSubscriberStream pss = new PlaylistSubscriberStream() ;</span>
<a class="l" name="507" href="#507">507</a><span class="c">//		Integer buffer = streamBuffers.get(streamId - 1);</span>
<a class="l" name="508" href="#508">508</a><span class="c">//		if (buffer != null) {</span>
<a class="l" name="509" href="#509">509</a><span class="c">//			pss.setClientBufferDuration(buffer);</span>
<a class="hl" name="510" href="#510">510</a><span class="c">//		}</span>
<a class="l" name="511" href="#511">511</a><span class="c">//		pss.setName(createStreamName());</span>
<a class="l" name="512" href="#512">512</a><span class="c">//		pss.setConnection(this);</span>
<a class="l" name="513" href="#513">513</a><span class="c">//		pss.setScope(this.getScope());</span>
<a class="l" name="514" href="#514">514</a><span class="c">//		pss.setStreamId(streamId);</span>
<a class="l" name="515" href="#515">515</a><span class="c">//		registerStream(pss);</span>
<a class="l" name="516" href="#516">516</a><span class="c">//		usedStreams.incrementAndGet();</span>
<a class="l" name="517" href="#517">517</a><span class="c">//		return pss;</span>
<a class="l" name="518" href="#518">518</a><span class="c">//		return null;</span>
<a class="l" name="519" href="#519">519</a><span class="c">//	}</span>
<a class="hl" name="520" href="#520">520</a><span class="c">//</span>
<a class="l" name="521" href="#521">521</a>	<b>public</b> <b>void</b> <a class="xmt" name="addClientStream"/><a href="/source/s?refs=addClientStream&amp;project=rtmp_client" class="xmt">addClientStream</a>(<a href="/source/s?defs=IClientStream&amp;project=rtmp_client">IClientStream</a> <a class="xa" name="stream"/><a href="/source/s?refs=stream&amp;project=rtmp_client" class="xa">stream</a>) {
<a class="l" name="522" href="#522">522</a>		<b>int</b> <a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a> = <a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=getStreamId&amp;project=rtmp_client">getStreamId</a>();
<a class="l" name="523" href="#523">523</a>		<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=lock&amp;project=rtmp_client">lock</a>();
<a class="l" name="524" href="#524">524</a>		<b>try</b> {
<a class="l" name="525" href="#525">525</a>			<b>if</b> (<a class="d" href="#reservedStreams">reservedStreams</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a> - <span class="n">1</span>)) {
<a class="l" name="526" href="#526">526</a>				<b>return</b>;
<a class="l" name="527" href="#527">527</a>			}
<a class="l" name="528" href="#528">528</a>			<a class="d" href="#reservedStreams">reservedStreams</a>.<a href="/source/s?defs=set&amp;project=rtmp_client">set</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a> - <span class="n">1</span>);
<a class="l" name="529" href="#529">529</a>		} <b>finally</b> {
<a class="hl" name="530" href="#530">530</a>			<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=unlock&amp;project=rtmp_client">unlock</a>();
<a class="l" name="531" href="#531">531</a>		}
<a class="l" name="532" href="#532">532</a>		<a class="d" href="#streams">streams</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a> - <span class="n">1</span>, <a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>);
<a class="l" name="533" href="#533">533</a>		<a class="d" href="#usedStreams">usedStreams</a>.<a href="/source/s?defs=incrementAndGet&amp;project=rtmp_client">incrementAndGet</a>();
<a class="l" name="534" href="#534">534</a>	}
<a class="l" name="535" href="#535">535</a>
<a class="l" name="536" href="#536">536</a>	<b>public</b> <b>void</b> <a class="xmt" name="removeClientStream"/><a href="/source/s?refs=removeClientStream&amp;project=rtmp_client" class="xmt">removeClientStream</a>(<b>int</b> <a class="xa" name="streamId"/><a href="/source/s?refs=streamId&amp;project=rtmp_client" class="xa">streamId</a>) {
<a class="l" name="537" href="#537">537</a>		<a class="d" href="#unreserveStreamId">unreserveStreamId</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a>);
<a class="l" name="538" href="#538">538</a>	}
<a class="l" name="539" href="#539">539</a>
<a class="hl" name="540" href="#540">540</a>	<span class="c">/**
<a class="l" name="541" href="#541">541</a>	 * Getter for used stream count.
<a class="l" name="542" href="#542">542</a>	 *
<a class="l" name="543" href="#543">543</a>	 * <strong>@return</strong> Value for property 'usedStreamCount'.
<a class="l" name="544" href="#544">544</a>	 */</span>
<a class="l" name="545" href="#545">545</a>	<b>protected</b> <b>int</b> <a class="xmt" name="getUsedStreamCount"/><a href="/source/s?refs=getUsedStreamCount&amp;project=rtmp_client" class="xmt">getUsedStreamCount</a>() {
<a class="l" name="546" href="#546">546</a>		<b>return</b> <a class="d" href="#usedStreams">usedStreams</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="547" href="#547">547</a>	}
<a class="l" name="548" href="#548">548</a>
<a class="l" name="549" href="#549">549</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="550" href="#550">550</a>	<b>public</b> <a href="/source/s?defs=IClientStream&amp;project=rtmp_client">IClientStream</a> <a class="xmt" name="getStreamById"/><a href="/source/s?refs=getStreamById&amp;project=rtmp_client" class="xmt">getStreamById</a>(<b>int</b> <a class="xa" name="id"/><a href="/source/s?refs=id&amp;project=rtmp_client" class="xa">id</a>) {
<a class="l" name="551" href="#551">551</a>		<b>if</b> (<a class="d" href="#id">id</a> &lt;= <span class="n">0</span>) {
<a class="l" name="552" href="#552">552</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="553" href="#553">553</a>		}
<a class="l" name="554" href="#554">554</a>		<b>return</b> <a class="d" href="#streams">streams</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a class="d" href="#id">id</a> - <span class="n">1</span>);
<a class="l" name="555" href="#555">555</a>	}
<a class="l" name="556" href="#556">556</a>
<a class="l" name="557" href="#557">557</a>	<span class="c">/**
<a class="l" name="558" href="#558">558</a>	 * Return stream id for given channel id.
<a class="l" name="559" href="#559">559</a>	 *
<a class="hl" name="560" href="#560">560</a>	 * <strong>@param</strong> <em>channelId</em> Channel id
<a class="l" name="561" href="#561">561</a>	 * <strong>@return</strong> ID of stream that channel belongs to
<a class="l" name="562" href="#562">562</a>	 */</span>
<a class="l" name="563" href="#563">563</a>	<b>public</b> <b>int</b> <a class="xmt" name="getStreamIdForChannel"/><a href="/source/s?refs=getStreamIdForChannel&amp;project=rtmp_client" class="xmt">getStreamIdForChannel</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>) {
<a class="l" name="564" href="#564">564</a>		<b>if</b> (<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a> &lt; <span class="n">4</span>) {
<a class="l" name="565" href="#565">565</a>			<b>return</b> <span class="n">0</span>;
<a class="l" name="566" href="#566">566</a>		}
<a class="l" name="567" href="#567">567</a>		<b>return</b> ((<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a> - <span class="n">4</span>) / <span class="n">5</span>) + <span class="n">1</span>;
<a class="l" name="568" href="#568">568</a>	}
<a class="l" name="569" href="#569">569</a>
<a class="hl" name="570" href="#570">570</a>	<span class="c">/**
<a class="l" name="571" href="#571">571</a>	 * Return stream by given channel id.
<a class="l" name="572" href="#572">572</a>	 *
<a class="l" name="573" href="#573">573</a>	 * <strong>@param</strong> <em>channelId</em> Channel id
<a class="l" name="574" href="#574">574</a>	 * <strong>@return</strong> Stream that channel belongs to
<a class="l" name="575" href="#575">575</a>	 */</span>
<a class="l" name="576" href="#576">576</a>	<b>public</b> <a href="/source/s?defs=IClientStream&amp;project=rtmp_client">IClientStream</a> <a class="xmt" name="getStreamByChannelId"/><a href="/source/s?refs=getStreamByChannelId&amp;project=rtmp_client" class="xmt">getStreamByChannelId</a>(<b>int</b> <a class="xa" name="channelId"/><a href="/source/s?refs=channelId&amp;project=rtmp_client" class="xa">channelId</a>) {
<a class="l" name="577" href="#577">577</a>		<b>if</b> (<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a> &lt; <span class="n">4</span>) {
<a class="l" name="578" href="#578">578</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="579" href="#579">579</a>		}
<a class="hl" name="580" href="#580">580</a>		<b>return</b> <a class="d" href="#streams">streams</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a class="d" href="#getStreamIdForChannel">getStreamIdForChannel</a>(<a href="/source/s?defs=channelId&amp;project=rtmp_client">channelId</a>) - <span class="n">1</span>);
<a class="l" name="581" href="#581">581</a>	}
<a class="l" name="582" href="#582">582</a>
<a class="l" name="583" href="#583">583</a>	<span class="c">/**
<a class="l" name="584" href="#584">584</a>	 * Store a stream in the connection.
<a class="l" name="585" href="#585">585</a>	 *
<a class="l" name="586" href="#586">586</a>	 * <strong>@param</strong> <em>stream</em>
<a class="l" name="587" href="#587">587</a>	 */</span>
<a class="l" name="588" href="#588">588</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unused"</span>)
<a class="l" name="589" href="#589">589</a>	<b>private</b> <b>void</b> <a class="xmt" name="registerStream"/><a href="/source/s?refs=registerStream&amp;project=rtmp_client" class="xmt">registerStream</a>(<a href="/source/s?defs=IClientStream&amp;project=rtmp_client">IClientStream</a> <a class="xa" name="stream"/><a href="/source/s?refs=stream&amp;project=rtmp_client" class="xa">stream</a>) {
<a class="hl" name="590" href="#590">590</a>		<a class="d" href="#streams">streams</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=getStreamId&amp;project=rtmp_client">getStreamId</a>() - <span class="n">1</span>, <a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>);
<a class="l" name="591" href="#591">591</a>	}
<a class="l" name="592" href="#592">592</a>
<a class="l" name="593" href="#593">593</a>	<span class="c">/**
<a class="l" name="594" href="#594">594</a>	 * Remove a stream from the connection.
<a class="l" name="595" href="#595">595</a>	 *
<a class="l" name="596" href="#596">596</a>	 * <strong>@param</strong> <em>stream</em>
<a class="l" name="597" href="#597">597</a>	 */</span>
<a class="l" name="598" href="#598">598</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>(<span class="s">"unused"</span>)
<a class="l" name="599" href="#599">599</a>	<b>private</b> <b>void</b> <a class="xmt" name="unregisterStream"/><a href="/source/s?refs=unregisterStream&amp;project=rtmp_client" class="xmt">unregisterStream</a>(<a href="/source/s?defs=IClientStream&amp;project=rtmp_client">IClientStream</a> <a class="xa" name="stream"/><a href="/source/s?refs=stream&amp;project=rtmp_client" class="xa">stream</a>) {
<a class="hl" name="600" href="#600">600</a>		<a class="d" href="#streams">streams</a>.<a href="/source/s?defs=remove&amp;project=rtmp_client">remove</a>(<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a href="/source/s?defs=getStreamId&amp;project=rtmp_client">getStreamId</a>());
<a class="l" name="601" href="#601">601</a>	}
<a class="l" name="602" href="#602">602</a>
<a class="l" name="603" href="#603">603</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="604" href="#604">604</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="605" href="#605">605</a>	<b>public</b> <b>void</b> <a class="xmt" name="close"/><a href="/source/s?refs=close&amp;project=rtmp_client" class="xmt">close</a>() {
<a class="l" name="606" href="#606">606</a>		<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=lock&amp;project=rtmp_client">lock</a>();
<a class="l" name="607" href="#607">607</a>		<b>try</b> {
<a class="l" name="608" href="#608">608</a>			<b>if</b> (<a class="d" href="#keepAliveJobName">keepAliveJobName</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="609" href="#609">609</a>				<a href="/source/s?defs=schedulingService&amp;project=rtmp_client">schedulingService</a>.<a href="/source/s?defs=removeScheduledJob&amp;project=rtmp_client">removeScheduledJob</a>(<a class="d" href="#keepAliveJobName">keepAliveJobName</a>);
<a class="hl" name="610" href="#610">610</a>				<a class="d" href="#keepAliveJobName">keepAliveJobName</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="611" href="#611">611</a>			}
<a class="l" name="612" href="#612">612</a>		} <b>finally</b> {
<a class="l" name="613" href="#613">613</a>			<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=unlock&amp;project=rtmp_client">unlock</a>();
<a class="l" name="614" href="#614">614</a>		}
<a class="l" name="615" href="#615">615</a>		<a href="/source/s?defs=Red5&amp;project=rtmp_client">Red5</a>.<a href="/source/s?defs=setConnectionLocal&amp;project=rtmp_client">setConnectionLocal</a>(<b>this</b>);
<a class="l" name="616" href="#616">616</a><span class="c">//		IStreamService streamService = (IStreamService) getScopeService(scope, IStreamService.class, StreamService.class);</span>
<a class="l" name="617" href="#617">617</a><span class="c">//		if (streamService != null) {</span>
<a class="l" name="618" href="#618">618</a><span class="c">//			for (Map.Entry&lt;Integer, IClientStream&gt; entry : streams.entrySet()) {</span>
<a class="l" name="619" href="#619">619</a><span class="c">//				IClientStream stream = entry.getValue();</span>
<a class="hl" name="620" href="#620">620</a><span class="c">//				if (stream != null) {</span>
<a class="l" name="621" href="#621">621</a><span class="c">//					log.debug("Closing stream: {}", stream.getStreamId());</span>
<a class="l" name="622" href="#622">622</a><span class="c">//					streamService.deleteStream(this, stream.getStreamId());</span>
<a class="l" name="623" href="#623">623</a><span class="c">//					usedStreams.decrementAndGet();</span>
<a class="l" name="624" href="#624">624</a><span class="c">//				}</span>
<a class="l" name="625" href="#625">625</a><span class="c">//			}</span>
<a class="l" name="626" href="#626">626</a><span class="c">//			streams.clear();</span>
<a class="l" name="627" href="#627">627</a><span class="c">//		}</span>
<a class="l" name="628" href="#628">628</a>		<a class="d" href="#channels">channels</a>.<a href="/source/s?defs=clear&amp;project=rtmp_client">clear</a>();
<a class="l" name="629" href="#629">629</a>		<b>super</b>.<a class="d" href="#close">close</a>();
<a class="hl" name="630" href="#630">630</a>	}
<a class="l" name="631" href="#631">631</a>
<a class="l" name="632" href="#632">632</a>	<span class="c">/**
<a class="l" name="633" href="#633">633</a>	 * When the connection has been closed, notify any remaining pending service calls that they have failed because
<a class="l" name="634" href="#634">634</a>	 * the connection is broken. Implementors of IPendingServiceCallback may only deduce from this notification that
<a class="l" name="635" href="#635">635</a>	 * it was not possible to read a result for this service call. It is possible that (1) the service call was never
<a class="l" name="636" href="#636">636</a>	 * written to the service, or (2) the service call was written to the service and although the remote method was
<a class="l" name="637" href="#637">637</a>	 * invoked, the connection failed before the result could be read, or (3) although the remote method was invoked
<a class="l" name="638" href="#638">638</a>	 * on the service, the service implementor detected the failure of the connection and performed only partial
<a class="l" name="639" href="#639">639</a>	 * processing. The caller only knows that it cannot be confirmed that the callee has invoked the service call
<a class="hl" name="640" href="#640">640</a>	 * and returned a result.
<a class="l" name="641" href="#641">641</a>	 */</span>
<a class="l" name="642" href="#642">642</a>	<b>public</b> <b>void</b> <a class="xmt" name="sendPendingServiceCallsCloseError"/><a href="/source/s?refs=sendPendingServiceCallsCloseError&amp;project=rtmp_client" class="xmt">sendPendingServiceCallsCloseError</a>() {
<a class="l" name="643" href="#643">643</a>		<b>if</b> (<a class="d" href="#pendingCalls">pendingCalls</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; !<a class="d" href="#pendingCalls">pendingCalls</a>.<a href="/source/s?defs=isEmpty&amp;project=rtmp_client">isEmpty</a>()) {
<a class="l" name="644" href="#644">644</a>			<b>for</b> (<a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a> <a href="/source/s?defs=call&amp;project=rtmp_client">call</a> : <a class="d" href="#pendingCalls">pendingCalls</a>.<a href="/source/s?defs=values&amp;project=rtmp_client">values</a>()) {
<a class="l" name="645" href="#645">645</a>				<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=setStatus&amp;project=rtmp_client">setStatus</a>(<a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>.<a href="/source/s?defs=STATUS_NOT_CONNECTED&amp;project=rtmp_client">STATUS_NOT_CONNECTED</a>);
<a class="l" name="646" href="#646">646</a>				<b>for</b> (<a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> <a href="/source/s?defs=callback&amp;project=rtmp_client">callback</a> : <a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=getCallbacks&amp;project=rtmp_client">getCallbacks</a>()) {
<a class="l" name="647" href="#647">647</a>					<a href="/source/s?defs=callback&amp;project=rtmp_client">callback</a>.<a href="/source/s?defs=resultReceived&amp;project=rtmp_client">resultReceived</a>(<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>);
<a class="l" name="648" href="#648">648</a>				}
<a class="l" name="649" href="#649">649</a>			}
<a class="hl" name="650" href="#650">650</a>		}
<a class="l" name="651" href="#651">651</a>	}
<a class="l" name="652" href="#652">652</a>
<a class="l" name="653" href="#653">653</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="654" href="#654">654</a>	<b>public</b> <b>void</b> <a class="xmt" name="unreserveStreamId"/><a href="/source/s?refs=unreserveStreamId&amp;project=rtmp_client" class="xmt">unreserveStreamId</a>(<b>int</b> <a class="xa" name="streamId"/><a href="/source/s?refs=streamId&amp;project=rtmp_client" class="xa">streamId</a>) {
<a class="l" name="655" href="#655">655</a>		<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=lock&amp;project=rtmp_client">lock</a>();
<a class="l" name="656" href="#656">656</a>		<b>try</b> {
<a class="l" name="657" href="#657">657</a>			<a class="d" href="#deleteStreamById">deleteStreamById</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a>);
<a class="l" name="658" href="#658">658</a>			<b>if</b> (<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a> &gt; <span class="n">0</span>) {
<a class="l" name="659" href="#659">659</a>				<a class="d" href="#reservedStreams">reservedStreams</a>.<a href="/source/s?defs=clear&amp;project=rtmp_client">clear</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a> - <span class="n">1</span>);
<a class="hl" name="660" href="#660">660</a>			}
<a class="l" name="661" href="#661">661</a>		} <b>finally</b> {
<a class="l" name="662" href="#662">662</a>			<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=unlock&amp;project=rtmp_client">unlock</a>();
<a class="l" name="663" href="#663">663</a>		}
<a class="l" name="664" href="#664">664</a>	}
<a class="l" name="665" href="#665">665</a>
<a class="l" name="666" href="#666">666</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="667" href="#667">667</a>	<b>public</b> <b>void</b> <a class="xmt" name="deleteStreamById"/><a href="/source/s?refs=deleteStreamById&amp;project=rtmp_client" class="xmt">deleteStreamById</a>(<b>int</b> <a class="xa" name="streamId"/><a href="/source/s?refs=streamId&amp;project=rtmp_client" class="xa">streamId</a>) {
<a class="l" name="668" href="#668">668</a>		<b>if</b> (<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a> &gt; <span class="n">0</span>) {
<a class="l" name="669" href="#669">669</a>			<b>if</b> (<a class="d" href="#streams">streams</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a> - <span class="n">1</span>) != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="670" href="#670">670</a>				<a class="d" href="#pendingVideos">pendingVideos</a>.<a href="/source/s?defs=remove&amp;project=rtmp_client">remove</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a>);
<a class="l" name="671" href="#671">671</a>				<a class="d" href="#usedStreams">usedStreams</a>.<a href="/source/s?defs=decrementAndGet&amp;project=rtmp_client">decrementAndGet</a>();
<a class="l" name="672" href="#672">672</a>				<a class="d" href="#streams">streams</a>.<a href="/source/s?defs=remove&amp;project=rtmp_client">remove</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a> - <span class="n">1</span>);
<a class="l" name="673" href="#673">673</a>				<a class="d" href="#streamBuffers">streamBuffers</a>.<a href="/source/s?defs=remove&amp;project=rtmp_client">remove</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a> - <span class="n">1</span>);
<a class="l" name="674" href="#674">674</a>			}
<a class="l" name="675" href="#675">675</a>		}
<a class="l" name="676" href="#676">676</a>	}
<a class="l" name="677" href="#677">677</a>
<a class="l" name="678" href="#678">678</a>	<span class="c">/**
<a class="l" name="679" href="#679">679</a>	 * Handler for ping event.
<a class="hl" name="680" href="#680">680</a>	 *
<a class="l" name="681" href="#681">681</a>	 * <strong>@param</strong> <em>ping</em> Ping event context
<a class="l" name="682" href="#682">682</a>	 */</span>
<a class="l" name="683" href="#683">683</a>	<b>public</b> <b>void</b> <a class="xa" name="ping"/><a href="/source/s?refs=ping&amp;project=rtmp_client" class="xa">ping</a>(<a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a> <a class="xa" name="ping"/><a href="/source/s?refs=ping&amp;project=rtmp_client" class="xa">ping</a>) {
<a class="l" name="684" href="#684">684</a>		<a class="d" href="#getChannel">getChannel</a>(<span class="n">2</span>).<a class="d" href="#write">write</a>(<a href="/source/s?defs=ping&amp;project=rtmp_client">ping</a>);
<a class="l" name="685" href="#685">685</a>	}
<a class="l" name="686" href="#686">686</a>
<a class="l" name="687" href="#687">687</a>	<span class="c">/**
<a class="l" name="688" href="#688">688</a>	 * Write raw byte buffer.
<a class="l" name="689" href="#689">689</a>	 *
<a class="hl" name="690" href="#690">690</a>	 * <strong>@param</strong> <em>out</em> IoBuffer
<a class="l" name="691" href="#691">691</a>	 */</span>
<a class="l" name="692" href="#692">692</a>	<b>public</b> <b>abstract</b> <b>void</b> <a class="xmt" name="rawWrite"/><a href="/source/s?refs=rawWrite&amp;project=rtmp_client" class="xmt">rawWrite</a>(<a href="/source/s?defs=IoBuffer&amp;project=rtmp_client">IoBuffer</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>);
<a class="l" name="693" href="#693">693</a>
<a class="l" name="694" href="#694">694</a>	<span class="c">/**
<a class="l" name="695" href="#695">695</a>	 * Write packet.
<a class="l" name="696" href="#696">696</a>	 *
<a class="l" name="697" href="#697">697</a>	 * <strong>@param</strong> <em>out</em> Packet
<a class="l" name="698" href="#698">698</a>	 */</span>
<a class="l" name="699" href="#699">699</a>	<b>public</b> <b>abstract</b> <b>void</b> <a class="xmt" name="write"/><a href="/source/s?refs=write&amp;project=rtmp_client" class="xmt">write</a>(<a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a> <a class="xa" name="out"/><a href="/source/s?refs=out&amp;project=rtmp_client" class="xa">out</a>);
<a class="hl" name="700" href="#700">700</a>
<a class="l" name="701" href="#701">701</a>	<span class="c">/**
<a class="l" name="702" href="#702">702</a>	 * Update number of bytes to read next value.
<a class="l" name="703" href="#703">703</a>	 */</span>
<a class="l" name="704" href="#704">704</a>	<b>protected</b> <b>void</b> <a class="xmt" name="updateBytesRead"/><a href="/source/s?refs=updateBytesRead&amp;project=rtmp_client" class="xmt">updateBytesRead</a>() {
<a class="l" name="705" href="#705">705</a>		<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=lock&amp;project=rtmp_client">lock</a>();
<a class="l" name="706" href="#706">706</a>		<b>try</b> {
<a class="l" name="707" href="#707">707</a>			<b>long</b> <a href="/source/s?defs=bytesRead&amp;project=rtmp_client">bytesRead</a> = <a class="d" href="#getReadBytes">getReadBytes</a>();
<a class="l" name="708" href="#708">708</a>			<b>if</b> (<a href="/source/s?defs=bytesRead&amp;project=rtmp_client">bytesRead</a> &gt;= <a class="d" href="#nextBytesRead">nextBytesRead</a>) {
<a class="l" name="709" href="#709">709</a>				<a href="/source/s?defs=BytesRead&amp;project=rtmp_client">BytesRead</a> <a href="/source/s?defs=sbr&amp;project=rtmp_client">sbr</a> = <b>new</b> <a href="/source/s?defs=BytesRead&amp;project=rtmp_client">BytesRead</a>((<b>int</b>) <a href="/source/s?defs=bytesRead&amp;project=rtmp_client">bytesRead</a>);
<a class="hl" name="710" href="#710">710</a>				<a class="d" href="#getChannel">getChannel</a>(<span class="n">2</span>).<a class="d" href="#write">write</a>(<a href="/source/s?defs=sbr&amp;project=rtmp_client">sbr</a>);
<a class="l" name="711" href="#711">711</a>				<span class="c">// @todo: what do we want to see printed here?</span>
<a class="l" name="712" href="#712">712</a>				<span class="c">// log.info(sbr);</span>
<a class="l" name="713" href="#713">713</a>				<a class="d" href="#nextBytesRead">nextBytesRead</a> += <a class="d" href="#bytesReadInterval">bytesReadInterval</a>;
<a class="l" name="714" href="#714">714</a>			}
<a class="l" name="715" href="#715">715</a>		} <b>finally</b> {
<a class="l" name="716" href="#716">716</a>			<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=unlock&amp;project=rtmp_client">unlock</a>();
<a class="l" name="717" href="#717">717</a>		}
<a class="l" name="718" href="#718">718</a>	}
<a class="l" name="719" href="#719">719</a>
<a class="hl" name="720" href="#720">720</a>	<span class="c">/**
<a class="l" name="721" href="#721">721</a>	 * Read number of received bytes.
<a class="l" name="722" href="#722">722</a>	 *
<a class="l" name="723" href="#723">723</a>	 * <strong>@param</strong> <em>bytes</em> Number of bytes
<a class="l" name="724" href="#724">724</a>	 */</span>
<a class="l" name="725" href="#725">725</a>	<b>public</b> <b>void</b> <a class="xmt" name="receivedBytesRead"/><a href="/source/s?refs=receivedBytesRead&amp;project=rtmp_client" class="xmt">receivedBytesRead</a>(<b>int</b> <a class="xa" name="bytes"/><a href="/source/s?refs=bytes&amp;project=rtmp_client" class="xa">bytes</a>) {
<a class="l" name="726" href="#726">726</a>		<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=lock&amp;project=rtmp_client">lock</a>();
<a class="l" name="727" href="#727">727</a>		<b>try</b> {
<a class="l" name="728" href="#728">728</a><span class="c">//			log.debug("Client received {} bytes, written {} bytes, {} messages pending", new Object[] { bytes, getWrittenBytes(), getPendingMessages() });</span>
<a class="l" name="729" href="#729">729</a>			<a class="d" href="#clientBytesRead">clientBytesRead</a> = <a class="d" href="#bytes">bytes</a>;
<a class="hl" name="730" href="#730">730</a>		} <b>finally</b> {
<a class="l" name="731" href="#731">731</a>			<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=unlock&amp;project=rtmp_client">unlock</a>();
<a class="l" name="732" href="#732">732</a>		}
<a class="l" name="733" href="#733">733</a>	}
<a class="l" name="734" href="#734">734</a>
<a class="l" name="735" href="#735">735</a>	<span class="c">/**
<a class="l" name="736" href="#736">736</a>	 * Get number of bytes the client reported to have received.
<a class="l" name="737" href="#737">737</a>	 *
<a class="l" name="738" href="#738">738</a>	 * <strong>@return</strong> Number of bytes
<a class="l" name="739" href="#739">739</a>	 */</span>
<a class="hl" name="740" href="#740">740</a>	<b>public</b> <b>long</b> <a class="xmt" name="getClientBytesRead"/><a href="/source/s?refs=getClientBytesRead&amp;project=rtmp_client" class="xmt">getClientBytesRead</a>() {
<a class="l" name="741" href="#741">741</a>		<a href="/source/s?defs=getReadLock&amp;project=rtmp_client">getReadLock</a>().<a href="/source/s?defs=lock&amp;project=rtmp_client">lock</a>();
<a class="l" name="742" href="#742">742</a>		<b>try</b> {
<a class="l" name="743" href="#743">743</a>			<b>return</b> <a class="d" href="#clientBytesRead">clientBytesRead</a>;
<a class="l" name="744" href="#744">744</a>		} <b>finally</b> {
<a class="l" name="745" href="#745">745</a>			<a href="/source/s?defs=getReadLock&amp;project=rtmp_client">getReadLock</a>().<a href="/source/s?defs=unlock&amp;project=rtmp_client">unlock</a>();
<a class="l" name="746" href="#746">746</a>		}
<a class="l" name="747" href="#747">747</a>	}
<a class="l" name="748" href="#748">748</a>
<a class="l" name="749" href="#749">749</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="750" href="#750">750</a>	<b>public</b> <b>void</b> <a class="xmt" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xmt">invoke</a>(<a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a> <a class="xa" name="call"/><a href="/source/s?refs=call&amp;project=rtmp_client" class="xa">call</a>) {
<a class="l" name="751" href="#751">751</a>		<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>(<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>, <span class="n">3</span>);
<a class="l" name="752" href="#752">752</a>	}
<a class="l" name="753" href="#753">753</a>
<a class="l" name="754" href="#754">754</a>	<span class="c">/**
<a class="l" name="755" href="#755">755</a>	 * Generate next invoke id.
<a class="l" name="756" href="#756">756</a>	 *
<a class="l" name="757" href="#757">757</a>	 * <strong>@return</strong> Next invoke id for RPC
<a class="l" name="758" href="#758">758</a>	 */</span>
<a class="l" name="759" href="#759">759</a>	<b>public</b> <b>int</b> <a class="xmt" name="getInvokeId"/><a href="/source/s?refs=getInvokeId&amp;project=rtmp_client" class="xmt">getInvokeId</a>() {
<a class="hl" name="760" href="#760">760</a>		<b>return</b> <a href="/source/s?defs=invokeId&amp;project=rtmp_client">invokeId</a>.<a href="/source/s?defs=incrementAndGet&amp;project=rtmp_client">incrementAndGet</a>();
<a class="l" name="761" href="#761">761</a>	}
<a class="l" name="762" href="#762">762</a>
<a class="l" name="763" href="#763">763</a>	<span class="c">/**
<a class="l" name="764" href="#764">764</a>	 * Register pending call (remote function call that is yet to finish).
<a class="l" name="765" href="#765">765</a>	 *
<a class="l" name="766" href="#766">766</a>	 * <strong>@param</strong> <em>invokeId</em> Deferred operation id
<a class="l" name="767" href="#767">767</a>	 * <strong>@param</strong> <em>call</em> Call service
<a class="l" name="768" href="#768">768</a>	 */</span>
<a class="l" name="769" href="#769">769</a>	<b>public</b> <b>void</b> <a class="xmt" name="registerPendingCall"/><a href="/source/s?refs=registerPendingCall&amp;project=rtmp_client" class="xmt">registerPendingCall</a>(<b>int</b> <a class="xa" name="invokeId"/><a href="/source/s?refs=invokeId&amp;project=rtmp_client" class="xa">invokeId</a>, <a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a> <a class="xa" name="call"/><a href="/source/s?refs=call&amp;project=rtmp_client" class="xa">call</a>) {
<a class="hl" name="770" href="#770">770</a>		<a class="d" href="#pendingCalls">pendingCalls</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=invokeId&amp;project=rtmp_client">invokeId</a>, <a href="/source/s?defs=call&amp;project=rtmp_client">call</a>);
<a class="l" name="771" href="#771">771</a>	}
<a class="l" name="772" href="#772">772</a>
<a class="l" name="773" href="#773">773</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="774" href="#774">774</a>	<b>public</b> <b>void</b> <a class="xmt" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xmt">invoke</a>(<a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a> <a class="xa" name="call"/><a href="/source/s?refs=call&amp;project=rtmp_client" class="xa">call</a>, <b>int</b> <a class="xa" name="channel"/><a href="/source/s?refs=channel&amp;project=rtmp_client" class="xa">channel</a>) {
<a class="l" name="775" href="#775">775</a>		<span class="c">// We need to use Invoke for all calls to the client</span>
<a class="l" name="776" href="#776">776</a>		<a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a> <a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a> = <b>new</b> <a href="/source/s?defs=Invoke&amp;project=rtmp_client">Invoke</a>();
<a class="l" name="777" href="#777">777</a>		<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=setCall&amp;project=rtmp_client">setCall</a>(<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>);
<a class="l" name="778" href="#778">778</a>		<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a href="/source/s?defs=setInvokeId&amp;project=rtmp_client">setInvokeId</a>(<a class="d" href="#getInvokeId">getInvokeId</a>());
<a class="l" name="779" href="#779">779</a>		<b>if</b> (<a href="/source/s?defs=call&amp;project=rtmp_client">call</a> <b>instanceof</b> <a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a>) {
<a class="hl" name="780" href="#780">780</a>			<a class="d" href="#registerPendingCall">registerPendingCall</a>(<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>.<a class="d" href="#getInvokeId">getInvokeId</a>(), (<a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a>) <a href="/source/s?defs=call&amp;project=rtmp_client">call</a>);
<a class="l" name="781" href="#781">781</a>		}
<a class="l" name="782" href="#782">782</a>		<a class="d" href="#getChannel">getChannel</a>(<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>).<a class="d" href="#write">write</a>(<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>);
<a class="l" name="783" href="#783">783</a>	}
<a class="l" name="784" href="#784">784</a>
<a class="l" name="785" href="#785">785</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="786" href="#786">786</a>	<b>public</b> <b>void</b> <a class="xmt" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xmt">invoke</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="method"/><a href="/source/s?refs=method&amp;project=rtmp_client" class="xa">method</a>) {
<a class="l" name="787" href="#787">787</a>		<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>(<a href="/source/s?defs=method&amp;project=rtmp_client">method</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="788" href="#788">788</a>	}
<a class="l" name="789" href="#789">789</a>
<a class="hl" name="790" href="#790">790</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="791" href="#791">791</a>	<b>public</b> <b>void</b> <a class="xmt" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xmt">invoke</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="method"/><a href="/source/s?refs=method&amp;project=rtmp_client" class="xa">method</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xa" name="params"/><a href="/source/s?refs=params&amp;project=rtmp_client" class="xa">params</a>) {
<a class="l" name="792" href="#792">792</a>		<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>(<a href="/source/s?defs=method&amp;project=rtmp_client">method</a>, <a href="/source/s?defs=params&amp;project=rtmp_client">params</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="793" href="#793">793</a>	}
<a class="l" name="794" href="#794">794</a>
<a class="l" name="795" href="#795">795</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="796" href="#796">796</a>	<b>public</b> <b>void</b> <a class="xmt" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xmt">invoke</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="method"/><a href="/source/s?refs=method&amp;project=rtmp_client" class="xa">method</a>, <a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> <a class="xa" name="callback"/><a href="/source/s?refs=callback&amp;project=rtmp_client" class="xa">callback</a>) {
<a class="l" name="797" href="#797">797</a>		<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>(<a href="/source/s?defs=method&amp;project=rtmp_client">method</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a href="/source/s?defs=callback&amp;project=rtmp_client">callback</a>);
<a class="l" name="798" href="#798">798</a>	}
<a class="l" name="799" href="#799">799</a>
<a class="hl" name="800" href="#800">800</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="801" href="#801">801</a>	<b>public</b> <b>void</b> <a class="xmt" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xmt">invoke</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="method"/><a href="/source/s?refs=method&amp;project=rtmp_client" class="xa">method</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xa" name="params"/><a href="/source/s?refs=params&amp;project=rtmp_client" class="xa">params</a>, <a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> <a class="xa" name="callback"/><a href="/source/s?refs=callback&amp;project=rtmp_client" class="xa">callback</a>) {
<a class="l" name="802" href="#802">802</a>		<a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a> <a href="/source/s?defs=call&amp;project=rtmp_client">call</a> = <b>new</b> <a href="/source/s?defs=PendingCall&amp;project=rtmp_client">PendingCall</a>(<a href="/source/s?defs=method&amp;project=rtmp_client">method</a>, <a href="/source/s?defs=params&amp;project=rtmp_client">params</a>);
<a class="l" name="803" href="#803">803</a>		<b>if</b> (<a href="/source/s?defs=callback&amp;project=rtmp_client">callback</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="804" href="#804">804</a>			<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>.<a href="/source/s?defs=registerCallback&amp;project=rtmp_client">registerCallback</a>(<a href="/source/s?defs=callback&amp;project=rtmp_client">callback</a>);
<a class="l" name="805" href="#805">805</a>		}
<a class="l" name="806" href="#806">806</a>		<a href="/source/s?defs=invoke&amp;project=rtmp_client">invoke</a>(<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>);
<a class="l" name="807" href="#807">807</a>	}
<a class="l" name="808" href="#808">808</a>
<a class="l" name="809" href="#809">809</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="hl" name="810" href="#810">810</a>	<b>public</b> <b>void</b> <a class="xmt" name="notify"/><a href="/source/s?refs=notify&amp;project=rtmp_client" class="xmt">notify</a>(<a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a> <a class="xa" name="call"/><a href="/source/s?refs=call&amp;project=rtmp_client" class="xa">call</a>) {
<a class="l" name="811" href="#811">811</a>		<a href="/source/s?defs=notify&amp;project=rtmp_client">notify</a>(<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>, <span class="n">3</span>);
<a class="l" name="812" href="#812">812</a>	}
<a class="l" name="813" href="#813">813</a>
<a class="l" name="814" href="#814">814</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="815" href="#815">815</a>	<b>public</b> <b>void</b> <a class="xmt" name="notify"/><a href="/source/s?refs=notify&amp;project=rtmp_client" class="xmt">notify</a>(<a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a> <a class="xa" name="call"/><a href="/source/s?refs=call&amp;project=rtmp_client" class="xa">call</a>, <b>int</b> <a class="xa" name="channel"/><a href="/source/s?refs=channel&amp;project=rtmp_client" class="xa">channel</a>) {
<a class="l" name="816" href="#816">816</a>		<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a> <a href="/source/s?defs=notify&amp;project=rtmp_client">notify</a> = <b>new</b> <a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>();
<a class="l" name="817" href="#817">817</a>		<a href="/source/s?defs=notify&amp;project=rtmp_client">notify</a>.<a href="/source/s?defs=setCall&amp;project=rtmp_client">setCall</a>(<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>);
<a class="l" name="818" href="#818">818</a>		<a class="d" href="#getChannel">getChannel</a>(<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>).<a class="d" href="#write">write</a>(<a href="/source/s?defs=notify&amp;project=rtmp_client">notify</a>);
<a class="l" name="819" href="#819">819</a>	}
<a class="hl" name="820" href="#820">820</a>
<a class="l" name="821" href="#821">821</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="822" href="#822">822</a>	<b>public</b> <b>void</b> <a class="xmt" name="notify"/><a href="/source/s?refs=notify&amp;project=rtmp_client" class="xmt">notify</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="method"/><a href="/source/s?refs=method&amp;project=rtmp_client" class="xa">method</a>) {
<a class="l" name="823" href="#823">823</a>		<a href="/source/s?defs=notify&amp;project=rtmp_client">notify</a>(<a href="/source/s?defs=method&amp;project=rtmp_client">method</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="824" href="#824">824</a>	}
<a class="l" name="825" href="#825">825</a>
<a class="l" name="826" href="#826">826</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="827" href="#827">827</a>	<b>public</b> <b>void</b> <a class="xmt" name="notify"/><a href="/source/s?refs=notify&amp;project=rtmp_client" class="xmt">notify</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="method"/><a href="/source/s?refs=method&amp;project=rtmp_client" class="xa">method</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xa" name="params"/><a href="/source/s?refs=params&amp;project=rtmp_client" class="xa">params</a>) {
<a class="l" name="828" href="#828">828</a>		<a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a> <a href="/source/s?defs=call&amp;project=rtmp_client">call</a> = <b>new</b> <a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>(<a href="/source/s?defs=method&amp;project=rtmp_client">method</a>, <a href="/source/s?defs=params&amp;project=rtmp_client">params</a>);
<a class="l" name="829" href="#829">829</a>		<a href="/source/s?defs=notify&amp;project=rtmp_client">notify</a>(<a href="/source/s?defs=call&amp;project=rtmp_client">call</a>);
<a class="hl" name="830" href="#830">830</a>	}
<a class="l" name="831" href="#831">831</a>
<a class="l" name="832" href="#832">832</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="833" href="#833">833</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="834" href="#834">834</a>	<b>public</b> <b>long</b> <a class="xmt" name="getReadBytes"/><a href="/source/s?refs=getReadBytes&amp;project=rtmp_client" class="xmt">getReadBytes</a>() {
<a class="l" name="835" href="#835">835</a>		<b>return</b> <span class="n">0</span>;
<a class="l" name="836" href="#836">836</a>	}
<a class="l" name="837" href="#837">837</a>
<a class="l" name="838" href="#838">838</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="839" href="#839">839</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="hl" name="840" href="#840">840</a>	<b>public</b> <b>long</b> <a class="xmt" name="getWrittenBytes"/><a href="/source/s?refs=getWrittenBytes&amp;project=rtmp_client" class="xmt">getWrittenBytes</a>() {
<a class="l" name="841" href="#841">841</a>		<b>return</b> <span class="n">0</span>;
<a class="l" name="842" href="#842">842</a>	}
<a class="l" name="843" href="#843">843</a>
<a class="l" name="844" href="#844">844</a>	<span class="c">/**
<a class="l" name="845" href="#845">845</a>	 * Get pending call service by id.
<a class="l" name="846" href="#846">846</a>	 *
<a class="l" name="847" href="#847">847</a>	 * <strong>@param</strong> <em>invokeId</em>
<a class="l" name="848" href="#848">848</a>	 *            Pending call service id
<a class="l" name="849" href="#849">849</a>	 * <strong>@return</strong> Pending call service object
<a class="hl" name="850" href="#850">850</a>	 */</span>
<a class="l" name="851" href="#851">851</a>	<b>protected</b> <a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a> <a class="xmt" name="getPendingCall"/><a href="/source/s?refs=getPendingCall&amp;project=rtmp_client" class="xmt">getPendingCall</a>(<b>int</b> <a class="xa" name="invokeId"/><a href="/source/s?refs=invokeId&amp;project=rtmp_client" class="xa">invokeId</a>) {
<a class="l" name="852" href="#852">852</a>		<b>return</b> <a class="d" href="#pendingCalls">pendingCalls</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=invokeId&amp;project=rtmp_client">invokeId</a>);
<a class="l" name="853" href="#853">853</a>	}
<a class="l" name="854" href="#854">854</a>
<a class="l" name="855" href="#855">855</a>	<span class="c">/**
<a class="l" name="856" href="#856">856</a>	 * Retrieve pending call service by id. The call will be removed afterwards.
<a class="l" name="857" href="#857">857</a>	 *
<a class="l" name="858" href="#858">858</a>	 * <strong>@param</strong> <em>invokeId</em>
<a class="l" name="859" href="#859">859</a>	 *            Pending call service id
<a class="hl" name="860" href="#860">860</a>	 * <strong>@return</strong> Pending call service object
<a class="l" name="861" href="#861">861</a>	 */</span>
<a class="l" name="862" href="#862">862</a>	<b>protected</b> <a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a> <a class="xmt" name="retrievePendingCall"/><a href="/source/s?refs=retrievePendingCall&amp;project=rtmp_client" class="xmt">retrievePendingCall</a>(<b>int</b> <a class="xa" name="invokeId"/><a href="/source/s?refs=invokeId&amp;project=rtmp_client" class="xa">invokeId</a>) {
<a class="l" name="863" href="#863">863</a>		<b>return</b> <a class="d" href="#pendingCalls">pendingCalls</a>.<a href="/source/s?defs=remove&amp;project=rtmp_client">remove</a>(<a href="/source/s?defs=invokeId&amp;project=rtmp_client">invokeId</a>);
<a class="l" name="864" href="#864">864</a>	}
<a class="l" name="865" href="#865">865</a>
<a class="l" name="866" href="#866">866</a>	<span class="c">/**
<a class="l" name="867" href="#867">867</a>	 * Generates new stream name.
<a class="l" name="868" href="#868">868</a>	 *
<a class="l" name="869" href="#869">869</a>	 * <strong>@return</strong> New stream name
<a class="hl" name="870" href="#870">870</a>	 */</span>
<a class="l" name="871" href="#871">871</a>	<b>protected</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="createStreamName"/><a href="/source/s?refs=createStreamName&amp;project=rtmp_client" class="xmt">createStreamName</a>() {
<a class="l" name="872" href="#872">872</a>		<b>return</b> <a href="/source/s?defs=UUID&amp;project=rtmp_client">UUID</a>.<a href="/source/s?defs=randomUUID&amp;project=rtmp_client">randomUUID</a>().<a class="d" href="#toString">toString</a>();
<a class="l" name="873" href="#873">873</a>	}
<a class="l" name="874" href="#874">874</a>
<a class="l" name="875" href="#875">875</a>	<span class="c">/**
<a class="l" name="876" href="#876">876</a>	 * Mark message as being written.
<a class="l" name="877" href="#877">877</a>	 *
<a class="l" name="878" href="#878">878</a>	 * <strong>@param</strong> <em>message</em>
<a class="l" name="879" href="#879">879</a>	 *            Message to mark
<a class="hl" name="880" href="#880">880</a>	 */</span>
<a class="l" name="881" href="#881">881</a>	<b>protected</b> <b>void</b> <a class="xmt" name="writingMessage"/><a href="/source/s?refs=writingMessage&amp;project=rtmp_client" class="xmt">writingMessage</a>(<a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a> <a class="xa" name="message"/><a href="/source/s?refs=message&amp;project=rtmp_client" class="xa">message</a>) {
<a class="l" name="882" href="#882">882</a>		<b>if</b> (<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=getMessage&amp;project=rtmp_client">getMessage</a>() <b>instanceof</b> <a href="/source/s?defs=VideoData&amp;project=rtmp_client">VideoData</a>) {
<a class="l" name="883" href="#883">883</a>			<b>int</b> <a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a> = <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=getHeader&amp;project=rtmp_client">getHeader</a>().<a href="/source/s?defs=getStreamId&amp;project=rtmp_client">getStreamId</a>();
<a class="l" name="884" href="#884">884</a>			<b>final</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a> <a href="/source/s?defs=value&amp;project=rtmp_client">value</a> = <b>new</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a>();
<a class="l" name="885" href="#885">885</a>			<a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a> <a href="/source/s?defs=old&amp;project=rtmp_client">old</a> = <a class="d" href="#pendingVideos">pendingVideos</a>.<a href="/source/s?defs=putIfAbsent&amp;project=rtmp_client">putIfAbsent</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a>, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="886" href="#886">886</a>			<b>if</b> (<a href="/source/s?defs=old&amp;project=rtmp_client">old</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="887" href="#887">887</a>				<a href="/source/s?defs=old&amp;project=rtmp_client">old</a> = <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>;
<a class="l" name="888" href="#888">888</a>			}
<a class="l" name="889" href="#889">889</a>			<a href="/source/s?defs=old&amp;project=rtmp_client">old</a>.<a href="/source/s?defs=incrementAndGet&amp;project=rtmp_client">incrementAndGet</a>();
<a class="hl" name="890" href="#890">890</a>		}
<a class="l" name="891" href="#891">891</a>	}
<a class="l" name="892" href="#892">892</a>
<a class="l" name="893" href="#893">893</a>	<span class="c">/**
<a class="l" name="894" href="#894">894</a>	 * Increases number of read messages by one. Updates number of bytes read.
<a class="l" name="895" href="#895">895</a>	 */</span>
<a class="l" name="896" href="#896">896</a>	<b>public</b> <b>void</b> <a class="xmt" name="messageReceived"/><a href="/source/s?refs=messageReceived&amp;project=rtmp_client" class="xmt">messageReceived</a>() {
<a class="l" name="897" href="#897">897</a>		<a href="/source/s?defs=readMessages&amp;project=rtmp_client">readMessages</a>.<a href="/source/s?defs=incrementAndGet&amp;project=rtmp_client">incrementAndGet</a>();
<a class="l" name="898" href="#898">898</a>		<span class="c">// Trigger generation of BytesRead messages</span>
<a class="l" name="899" href="#899">899</a>		<a class="d" href="#updateBytesRead">updateBytesRead</a>();
<a class="hl" name="900" href="#900">900</a>	}
<a class="l" name="901" href="#901">901</a>
<a class="l" name="902" href="#902">902</a>	<span class="c">/**
<a class="l" name="903" href="#903">903</a>	 * Mark message as sent.
<a class="l" name="904" href="#904">904</a>	 *
<a class="l" name="905" href="#905">905</a>	 * <strong>@param</strong> <em>message</em>
<a class="l" name="906" href="#906">906</a>	 *            Message to mark
<a class="l" name="907" href="#907">907</a>	 */</span>
<a class="l" name="908" href="#908">908</a>	<b>public</b> <b>void</b> <a class="xmt" name="messageSent"/><a href="/source/s?refs=messageSent&amp;project=rtmp_client" class="xmt">messageSent</a>(<a href="/source/s?defs=Packet&amp;project=rtmp_client">Packet</a> <a class="xa" name="message"/><a href="/source/s?refs=message&amp;project=rtmp_client" class="xa">message</a>) {
<a class="l" name="909" href="#909">909</a>		<b>if</b> (<a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=getMessage&amp;project=rtmp_client">getMessage</a>() <b>instanceof</b> <a href="/source/s?defs=VideoData&amp;project=rtmp_client">VideoData</a>) {
<a class="hl" name="910" href="#910">910</a>			<b>int</b> <a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a> = <a href="/source/s?defs=message&amp;project=rtmp_client">message</a>.<a href="/source/s?defs=getHeader&amp;project=rtmp_client">getHeader</a>().<a href="/source/s?defs=getStreamId&amp;project=rtmp_client">getStreamId</a>();
<a class="l" name="911" href="#911">911</a>			<a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a> <a href="/source/s?defs=pending&amp;project=rtmp_client">pending</a> = <a class="d" href="#pendingVideos">pendingVideos</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a>);
<a class="l" name="912" href="#912">912</a>			<b>if</b> (<a href="/source/s?defs=pending&amp;project=rtmp_client">pending</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="913" href="#913">913</a>				<a href="/source/s?defs=pending&amp;project=rtmp_client">pending</a>.<a href="/source/s?defs=decrementAndGet&amp;project=rtmp_client">decrementAndGet</a>();
<a class="l" name="914" href="#914">914</a>			}
<a class="l" name="915" href="#915">915</a>		}
<a class="l" name="916" href="#916">916</a>		<a href="/source/s?defs=writtenMessages&amp;project=rtmp_client">writtenMessages</a>.<a href="/source/s?defs=incrementAndGet&amp;project=rtmp_client">incrementAndGet</a>();
<a class="l" name="917" href="#917">917</a>	}
<a class="l" name="918" href="#918">918</a>
<a class="l" name="919" href="#919">919</a>	<span class="c">/**
<a class="hl" name="920" href="#920">920</a>	 * Increases number of dropped messages.
<a class="l" name="921" href="#921">921</a>	 */</span>
<a class="l" name="922" href="#922">922</a>	<b>protected</b> <b>void</b> <a class="xmt" name="messageDropped"/><a href="/source/s?refs=messageDropped&amp;project=rtmp_client" class="xmt">messageDropped</a>() {
<a class="l" name="923" href="#923">923</a>		<a href="/source/s?defs=droppedMessages&amp;project=rtmp_client">droppedMessages</a>.<a href="/source/s?defs=incrementAndGet&amp;project=rtmp_client">incrementAndGet</a>();
<a class="l" name="924" href="#924">924</a>	}
<a class="l" name="925" href="#925">925</a>
<a class="l" name="926" href="#926">926</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="927" href="#927">927</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="928" href="#928">928</a>	<b>public</b> <b>long</b> <a class="xmt" name="getPendingVideoMessages"/><a href="/source/s?refs=getPendingVideoMessages&amp;project=rtmp_client" class="xmt">getPendingVideoMessages</a>(<b>int</b> <a class="xa" name="streamId"/><a href="/source/s?refs=streamId&amp;project=rtmp_client" class="xa">streamId</a>) {
<a class="l" name="929" href="#929">929</a>		<a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a> <a href="/source/s?defs=count&amp;project=rtmp_client">count</a> = <a class="d" href="#pendingVideos">pendingVideos</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a>);
<a class="hl" name="930" href="#930">930</a>		<b>long</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = (<a href="/source/s?defs=count&amp;project=rtmp_client">count</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> ? <a href="/source/s?defs=count&amp;project=rtmp_client">count</a>.<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>() - <a class="d" href="#getUsedStreamCount">getUsedStreamCount</a>() : <span class="n">0</span>);
<a class="l" name="931" href="#931">931</a>		<b>return</b> (<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> &gt; <span class="n">0</span> ? <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> : <span class="n">0</span>);
<a class="l" name="932" href="#932">932</a>	}
<a class="l" name="933" href="#933">933</a>
<a class="l" name="934" href="#934">934</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="935" href="#935">935</a>	<b>public</b> <b>void</b> <a class="xmt" name="ping"/><a href="/source/s?refs=ping&amp;project=rtmp_client" class="xmt">ping</a>() {
<a class="l" name="936" href="#936">936</a>		<b>long</b> <a href="/source/s?defs=newPingTime&amp;project=rtmp_client">newPingTime</a> = <a href="/source/s?defs=System&amp;project=rtmp_client">System</a>.<a href="/source/s?defs=currentTimeMillis&amp;project=rtmp_client">currentTimeMillis</a>();
<a class="l" name="937" href="#937">937</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Pinging client with id {} at {}, last ping sent at {}"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <a class="d" href="#getId">getId</a>(), <a href="/source/s?defs=newPingTime&amp;project=rtmp_client">newPingTime</a>, <a class="d" href="#lastPingSent">lastPingSent</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() });
<a class="l" name="938" href="#938">938</a>		<b>if</b> (<a class="d" href="#lastPingSent">lastPingSent</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() == <span class="n">0</span>) {
<a class="l" name="939" href="#939">939</a>			<a class="d" href="#lastPongReceived">lastPongReceived</a>.<a href="/source/s?defs=set&amp;project=rtmp_client">set</a>(<a href="/source/s?defs=newPingTime&amp;project=rtmp_client">newPingTime</a>);
<a class="hl" name="940" href="#940">940</a>		}
<a class="l" name="941" href="#941">941</a>		<a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a> <a href="/source/s?defs=pingRequest&amp;project=rtmp_client">pingRequest</a> = <b>new</b> <a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>();
<a class="l" name="942" href="#942">942</a>		<a href="/source/s?defs=pingRequest&amp;project=rtmp_client">pingRequest</a>.<a href="/source/s?defs=setEventType&amp;project=rtmp_client">setEventType</a>(<a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a>.<a href="/source/s?defs=PING_CLIENT&amp;project=rtmp_client">PING_CLIENT</a>);
<a class="l" name="943" href="#943">943</a>		<a class="d" href="#lastPingSent">lastPingSent</a>.<a href="/source/s?defs=set&amp;project=rtmp_client">set</a>(<a href="/source/s?defs=newPingTime&amp;project=rtmp_client">newPingTime</a>);
<a class="l" name="944" href="#944">944</a>		<b>int</b> <a href="/source/s?defs=now&amp;project=rtmp_client">now</a> = (<b>int</b>) (<a href="/source/s?defs=newPingTime&amp;project=rtmp_client">newPingTime</a> &amp; <span class="n">0xffffffff</span>);
<a class="l" name="945" href="#945">945</a>		<a href="/source/s?defs=pingRequest&amp;project=rtmp_client">pingRequest</a>.<a href="/source/s?defs=setValue2&amp;project=rtmp_client">setValue2</a>(<a href="/source/s?defs=now&amp;project=rtmp_client">now</a>);
<a class="l" name="946" href="#946">946</a>		<a href="/source/s?defs=ping&amp;project=rtmp_client">ping</a>(<a href="/source/s?defs=pingRequest&amp;project=rtmp_client">pingRequest</a>);
<a class="l" name="947" href="#947">947</a>	}
<a class="l" name="948" href="#948">948</a>
<a class="l" name="949" href="#949">949</a>	<span class="c">/**
<a class="hl" name="950" href="#950">950</a>	 * Marks that ping back was received.
<a class="l" name="951" href="#951">951</a>	 *
<a class="l" name="952" href="#952">952</a>	 * <strong>@param</strong> <em>pong</em>
<a class="l" name="953" href="#953">953</a>	 *            Ping object
<a class="l" name="954" href="#954">954</a>	 */</span>
<a class="l" name="955" href="#955">955</a>	<b>public</b> <b>void</b> <a class="xmt" name="pingReceived"/><a href="/source/s?refs=pingReceived&amp;project=rtmp_client" class="xmt">pingReceived</a>(<a href="/source/s?defs=Ping&amp;project=rtmp_client">Ping</a> <a class="xa" name="pong"/><a href="/source/s?refs=pong&amp;project=rtmp_client" class="xa">pong</a>) {
<a class="l" name="956" href="#956">956</a>		<b>long</b> <a href="/source/s?defs=now&amp;project=rtmp_client">now</a> = <a href="/source/s?defs=System&amp;project=rtmp_client">System</a>.<a href="/source/s?defs=currentTimeMillis&amp;project=rtmp_client">currentTimeMillis</a>();
<a class="l" name="957" href="#957">957</a>		<b>long</b> <a href="/source/s?defs=previousReceived&amp;project=rtmp_client">previousReceived</a> = (<b>int</b>) (<a class="d" href="#lastPingSent">lastPingSent</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &amp; <span class="n">0xffffffff</span>);
<a class="l" name="958" href="#958">958</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Pong from client id {} at {} with value {}, previous received at {}"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <a class="d" href="#getId">getId</a>(), <a href="/source/s?defs=now&amp;project=rtmp_client">now</a>, <a class="d" href="#pong">pong</a>.<a href="/source/s?defs=getValue2&amp;project=rtmp_client">getValue2</a>(), <a href="/source/s?defs=previousReceived&amp;project=rtmp_client">previousReceived</a> });
<a class="l" name="959" href="#959">959</a>		<b>if</b> (<a class="d" href="#pong">pong</a>.<a href="/source/s?defs=getValue2&amp;project=rtmp_client">getValue2</a>() == <a href="/source/s?defs=previousReceived&amp;project=rtmp_client">previousReceived</a>) {
<a class="hl" name="960" href="#960">960</a>			<a class="d" href="#lastPingTime">lastPingTime</a>.<a href="/source/s?defs=set&amp;project=rtmp_client">set</a>((<b>int</b>) (<a href="/source/s?defs=now&amp;project=rtmp_client">now</a> &amp; <span class="n">0xffffffff</span>) - <a class="d" href="#pong">pong</a>.<a href="/source/s?defs=getValue2&amp;project=rtmp_client">getValue2</a>());
<a class="l" name="961" href="#961">961</a>		}
<a class="l" name="962" href="#962">962</a>		<a class="d" href="#lastPongReceived">lastPongReceived</a>.<a href="/source/s?defs=set&amp;project=rtmp_client">set</a>(<a href="/source/s?defs=now&amp;project=rtmp_client">now</a>);
<a class="l" name="963" href="#963">963</a>	}
<a class="l" name="964" href="#964">964</a>
<a class="l" name="965" href="#965">965</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="966" href="#966">966</a>	<b>public</b> <b>int</b> <a class="xmt" name="getLastPingTime"/><a href="/source/s?refs=getLastPingTime&amp;project=rtmp_client" class="xmt">getLastPingTime</a>() {
<a class="l" name="967" href="#967">967</a>		<b>return</b> <a class="d" href="#lastPingTime">lastPingTime</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="968" href="#968">968</a>	}
<a class="l" name="969" href="#969">969</a>
<a class="hl" name="970" href="#970">970</a>	<span class="c">/**
<a class="l" name="971" href="#971">971</a>	 * Setter for ping interval.
<a class="l" name="972" href="#972">972</a>	 *
<a class="l" name="973" href="#973">973</a>	 * <strong>@param</strong> <em>pingInterval</em> Interval in ms to ping clients. Set to &lt;code&gt;0&lt;/code&gt; to
<a class="l" name="974" href="#974">974</a>	 *            disable ghost detection code.
<a class="l" name="975" href="#975">975</a>	 */</span>
<a class="l" name="976" href="#976">976</a>	<b>public</b> <b>void</b> <a class="xmt" name="setPingInterval"/><a href="/source/s?refs=setPingInterval&amp;project=rtmp_client" class="xmt">setPingInterval</a>(<b>int</b> <a class="xa" name="pingInterval"/><a href="/source/s?refs=pingInterval&amp;project=rtmp_client" class="xa">pingInterval</a>) {
<a class="l" name="977" href="#977">977</a>		<b>this</b>.<a href="/source/s?defs=pingInterval&amp;project=rtmp_client">pingInterval</a> = <a href="/source/s?defs=pingInterval&amp;project=rtmp_client">pingInterval</a>;
<a class="l" name="978" href="#978">978</a>	}
<a class="l" name="979" href="#979">979</a>
<a class="hl" name="980" href="#980">980</a>	<span class="c">/**
<a class="l" name="981" href="#981">981</a>	 * Setter for maximum inactivity.
<a class="l" name="982" href="#982">982</a>	 *
<a class="l" name="983" href="#983">983</a>	 * <strong>@param</strong> <em>maxInactivity</em> Maximum time in ms after which a client is disconnected in
<a class="l" name="984" href="#984">984</a>	 *            case of inactivity.
<a class="l" name="985" href="#985">985</a>	 */</span>
<a class="l" name="986" href="#986">986</a>	<b>public</b> <b>void</b> <a class="xmt" name="setMaxInactivity"/><a href="/source/s?refs=setMaxInactivity&amp;project=rtmp_client" class="xmt">setMaxInactivity</a>(<b>int</b> <a class="xa" name="maxInactivity"/><a href="/source/s?refs=maxInactivity&amp;project=rtmp_client" class="xa">maxInactivity</a>) {
<a class="l" name="987" href="#987">987</a>		<b>this</b>.<a href="/source/s?defs=maxInactivity&amp;project=rtmp_client">maxInactivity</a> = <a href="/source/s?defs=maxInactivity&amp;project=rtmp_client">maxInactivity</a>;
<a class="l" name="988" href="#988">988</a>	}
<a class="l" name="989" href="#989">989</a>
<a class="hl" name="990" href="#990">990</a>	<span class="c">/**
<a class="l" name="991" href="#991">991</a>	 * Starts measurement.
<a class="l" name="992" href="#992">992</a>	 */</span>
<a class="l" name="993" href="#993">993</a>	<b>public</b> <b>void</b> <a class="xmt" name="startRoundTripMeasurement"/><a href="/source/s?refs=startRoundTripMeasurement&amp;project=rtmp_client" class="xmt">startRoundTripMeasurement</a>() {
<a class="l" name="994" href="#994">994</a>		<b>if</b> (<a href="/source/s?defs=pingInterval&amp;project=rtmp_client">pingInterval</a> &gt; <span class="n">0</span> &amp;&amp; <a class="d" href="#keepAliveJobName">keepAliveJobName</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="995" href="#995">995</a>			<a class="d" href="#keepAliveJobName">keepAliveJobName</a> = <a href="/source/s?defs=schedulingService&amp;project=rtmp_client">schedulingService</a>.<a href="/source/s?defs=addScheduledJob&amp;project=rtmp_client">addScheduledJob</a>(<a href="/source/s?defs=pingInterval&amp;project=rtmp_client">pingInterval</a>, <b>new</b> <a class="d" href="#KeepAliveJob">KeepAliveJob</a>());
<a class="l" name="996" href="#996">996</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Keep alive job name {} for client id {}"</span>, <a class="d" href="#keepAliveJobName">keepAliveJobName</a>, <a class="d" href="#getId">getId</a>());
<a class="l" name="997" href="#997">997</a>		}
<a class="l" name="998" href="#998">998</a>	}
<a class="l" name="999" href="#999">999</a>
<a class="hl" name="1000" href="#1000">1000</a>	<span class="c">/**
<a class="l" name="1001" href="#1001">1001</a>	 * Sets the scheduling service.
<a class="l" name="1002" href="#1002">1002</a>	 *
<a class="l" name="1003" href="#1003">1003</a>	 * <strong>@param</strong> <em>schedulingService</em> scheduling service
<a class="l" name="1004" href="#1004">1004</a>	 */</span>
<a class="l" name="1005" href="#1005">1005</a>	<b>public</b> <b>void</b> <a class="xmt" name="setSchedulingService"/><a href="/source/s?refs=setSchedulingService&amp;project=rtmp_client" class="xmt">setSchedulingService</a>(<a href="/source/s?defs=ISchedulingService&amp;project=rtmp_client">ISchedulingService</a> <a class="xa" name="schedulingService"/><a href="/source/s?refs=schedulingService&amp;project=rtmp_client" class="xa">schedulingService</a>) {
<a class="l" name="1006" href="#1006">1006</a>		<b>this</b>.<a href="/source/s?defs=schedulingService&amp;project=rtmp_client">schedulingService</a> = <a href="/source/s?defs=schedulingService&amp;project=rtmp_client">schedulingService</a>;
<a class="l" name="1007" href="#1007">1007</a>	}
<a class="l" name="1008" href="#1008">1008</a>
<a class="l" name="1009" href="#1009">1009</a>	<span class="c">/**
<a class="hl" name="1010" href="#1010">1010</a>	 * Inactive state event handler.
<a class="l" name="1011" href="#1011">1011</a>	 */</span>
<a class="l" name="1012" href="#1012">1012</a>	<b>protected</b> <b>abstract</b> <b>void</b> <a class="xmt" name="onInactive"/><a href="/source/s?refs=onInactive&amp;project=rtmp_client" class="xmt">onInactive</a>();
<a class="l" name="1013" href="#1013">1013</a>
<a class="l" name="1014" href="#1014">1014</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="1015" href="#1015">1015</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="1016" href="#1016">1016</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="toString"/><a href="/source/s?refs=toString&amp;project=rtmp_client" class="xmt">toString</a>() {
<a class="l" name="1017" href="#1017">1017</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a href="/source/s?defs=args&amp;project=rtmp_client">args</a> = <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>().<a href="/source/s?defs=getSimpleName&amp;project=rtmp_client">getSimpleName</a>(), <a href="/source/s?defs=getRemoteAddress&amp;project=rtmp_client">getRemoteAddress</a>(), <a href="/source/s?defs=getRemotePort&amp;project=rtmp_client">getRemotePort</a>(), <a href="/source/s?defs=getHost&amp;project=rtmp_client">getHost</a>(), <a class="d" href="#getReadBytes">getReadBytes</a>(), <a class="d" href="#getWrittenBytes">getWrittenBytes</a>() };
<a class="l" name="1018" href="#1018">1018</a>		<b>return</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<a href="/source/s?defs=format&amp;project=rtmp_client">format</a>(<span class="s">"%1$s from %2$s : %3$s to %4$s (in: %5$s out %6$s )"</span>, <a href="/source/s?defs=args&amp;project=rtmp_client">args</a>);
<a class="l" name="1019" href="#1019">1019</a>	}
<a class="hl" name="1020" href="#1020">1020</a>
<a class="l" name="1021" href="#1021">1021</a>	<span class="c">/**
<a class="l" name="1022" href="#1022">1022</a>	 * Registers deferred result.
<a class="l" name="1023" href="#1023">1023</a>	 *
<a class="l" name="1024" href="#1024">1024</a>	 * <strong>@param</strong> <em>result</em> Result to register
<a class="l" name="1025" href="#1025">1025</a>	 */</span>
<a class="l" name="1026" href="#1026">1026</a>	<b>protected</b> <b>void</b> <a class="xmt" name="registerDeferredResult"/><a href="/source/s?refs=registerDeferredResult&amp;project=rtmp_client" class="xmt">registerDeferredResult</a>(<a href="/source/s?defs=DeferredResult&amp;project=rtmp_client">DeferredResult</a> <a class="xa" name="result"/><a href="/source/s?refs=result&amp;project=rtmp_client" class="xa">result</a>) {
<a class="l" name="1027" href="#1027">1027</a>		<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=lock&amp;project=rtmp_client">lock</a>();
<a class="l" name="1028" href="#1028">1028</a>		<b>try</b> {
<a class="l" name="1029" href="#1029">1029</a>			<a class="d" href="#deferredResults">deferredResults</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>);
<a class="hl" name="1030" href="#1030">1030</a>		} <b>finally</b> {
<a class="l" name="1031" href="#1031">1031</a>			<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=unlock&amp;project=rtmp_client">unlock</a>();
<a class="l" name="1032" href="#1032">1032</a>		}
<a class="l" name="1033" href="#1033">1033</a>	}
<a class="l" name="1034" href="#1034">1034</a>
<a class="l" name="1035" href="#1035">1035</a>	<span class="c">/**
<a class="l" name="1036" href="#1036">1036</a>	 * Unregister deferred result
<a class="l" name="1037" href="#1037">1037</a>	 *
<a class="l" name="1038" href="#1038">1038</a>	 * <strong>@param</strong> <em>result</em>
<a class="l" name="1039" href="#1039">1039</a>	 *            Result to unregister
<a class="hl" name="1040" href="#1040">1040</a>	 */</span>
<a class="l" name="1041" href="#1041">1041</a>	<b>protected</b> <b>void</b> <a class="xmt" name="unregisterDeferredResult"/><a href="/source/s?refs=unregisterDeferredResult&amp;project=rtmp_client" class="xmt">unregisterDeferredResult</a>(<a href="/source/s?defs=DeferredResult&amp;project=rtmp_client">DeferredResult</a> <a class="xa" name="result"/><a href="/source/s?refs=result&amp;project=rtmp_client" class="xa">result</a>) {
<a class="l" name="1042" href="#1042">1042</a>		<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=lock&amp;project=rtmp_client">lock</a>();
<a class="l" name="1043" href="#1043">1043</a>		<b>try</b> {
<a class="l" name="1044" href="#1044">1044</a>			<a class="d" href="#deferredResults">deferredResults</a>.<a href="/source/s?defs=remove&amp;project=rtmp_client">remove</a>(<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>);
<a class="l" name="1045" href="#1045">1045</a>		} <b>finally</b> {
<a class="l" name="1046" href="#1046">1046</a>			<a href="/source/s?defs=getWriteLock&amp;project=rtmp_client">getWriteLock</a>().<a href="/source/s?defs=unlock&amp;project=rtmp_client">unlock</a>();
<a class="l" name="1047" href="#1047">1047</a>		}
<a class="l" name="1048" href="#1048">1048</a>	}
<a class="l" name="1049" href="#1049">1049</a>
<a class="hl" name="1050" href="#1050">1050</a>	<b>protected</b> <b>void</b> <a class="xmt" name="rememberStreamBufferDuration"/><a href="/source/s?refs=rememberStreamBufferDuration&amp;project=rtmp_client" class="xmt">rememberStreamBufferDuration</a>(<b>int</b> <a class="xa" name="streamId"/><a href="/source/s?refs=streamId&amp;project=rtmp_client" class="xa">streamId</a>, <b>int</b> <a class="xa" name="bufferDuration"/><a href="/source/s?refs=bufferDuration&amp;project=rtmp_client" class="xa">bufferDuration</a>) {
<a class="l" name="1051" href="#1051">1051</a>		<a class="d" href="#streamBuffers">streamBuffers</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=streamId&amp;project=rtmp_client">streamId</a> - <span class="n">1</span>, <a class="d" href="#bufferDuration">bufferDuration</a>);
<a class="l" name="1052" href="#1052">1052</a>	}
<a class="l" name="1053" href="#1053">1053</a>
<a class="l" name="1054" href="#1054">1054</a>	<span class="c">/**
<a class="l" name="1055" href="#1055">1055</a>	 * Set maximum time to wait for valid handshake in milliseconds.
<a class="l" name="1056" href="#1056">1056</a>	 *
<a class="l" name="1057" href="#1057">1057</a>	 * <strong>@param</strong> <em>maxHandshakeTimeout</em> Maximum time in milliseconds
<a class="l" name="1058" href="#1058">1058</a>	 */</span>
<a class="l" name="1059" href="#1059">1059</a>	<b>public</b> <b>void</b> <a class="xmt" name="setMaxHandshakeTimeout"/><a href="/source/s?refs=setMaxHandshakeTimeout&amp;project=rtmp_client" class="xmt">setMaxHandshakeTimeout</a>(<b>int</b> <a class="xa" name="maxHandshakeTimeout"/><a href="/source/s?refs=maxHandshakeTimeout&amp;project=rtmp_client" class="xa">maxHandshakeTimeout</a>) {
<a class="hl" name="1060" href="#1060">1060</a>		<b>this</b>.<a href="/source/s?defs=maxHandshakeTimeout&amp;project=rtmp_client">maxHandshakeTimeout</a> = <a href="/source/s?defs=maxHandshakeTimeout&amp;project=rtmp_client">maxHandshakeTimeout</a>;
<a class="l" name="1061" href="#1061">1061</a>	}
<a class="l" name="1062" href="#1062">1062</a>
<a class="l" name="1063" href="#1063">1063</a>	<span class="c">/**
<a class="l" name="1064" href="#1064">1064</a>	 * Start waiting for a valid handshake.
<a class="l" name="1065" href="#1065">1065</a>	 *
<a class="l" name="1066" href="#1066">1066</a>	 * <strong>@param</strong> <em>service</em>
<a class="l" name="1067" href="#1067">1067</a>	 *            The scheduling service to use
<a class="l" name="1068" href="#1068">1068</a>	 */</span>
<a class="l" name="1069" href="#1069">1069</a>	<b>protected</b> <b>void</b> <a class="xmt" name="startWaitForHandshake"/><a href="/source/s?refs=startWaitForHandshake&amp;project=rtmp_client" class="xmt">startWaitForHandshake</a>(<a href="/source/s?defs=ISchedulingService&amp;project=rtmp_client">ISchedulingService</a> <a class="xa" name="service"/><a href="/source/s?refs=service&amp;project=rtmp_client" class="xa">service</a>) {
<a class="hl" name="1070" href="#1070">1070</a>		<a class="d" href="#waitForHandshakeJob">waitForHandshakeJob</a> = <a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=addScheduledOnceJob&amp;project=rtmp_client">addScheduledOnceJob</a>(<a href="/source/s?defs=maxHandshakeTimeout&amp;project=rtmp_client">maxHandshakeTimeout</a>, <b>new</b> <a class="d" href="#WaitForHandshakeJob">WaitForHandshakeJob</a>());
<a class="l" name="1071" href="#1071">1071</a>	}
<a class="l" name="1072" href="#1072">1072</a>
<a class="l" name="1073" href="#1073">1073</a>	<span class="c">/* (non-Javadoc)
<a class="l" name="1074" href="#1074">1074</a>	 * @see java.lang.Object#hashCode()
<a class="l" name="1075" href="#1075">1075</a>	 */</span>
<a class="l" name="1076" href="#1076">1076</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="1077" href="#1077">1077</a>	<b>public</b> <b>int</b> <a class="xmt" name="hashCode"/><a href="/source/s?refs=hashCode&amp;project=rtmp_client" class="xmt">hashCode</a>() {
<a class="l" name="1078" href="#1078">1078</a>		<b>final</b> <b>int</b> <a href="/source/s?defs=prime&amp;project=rtmp_client">prime</a> = <span class="n">31</span>;
<a class="l" name="1079" href="#1079">1079</a>		<b>int</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <span class="n">1</span>;
<a class="hl" name="1080" href="#1080">1080</a>		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=prime&amp;project=rtmp_client">prime</a> * <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> + <a href="/source/s?defs=clientId&amp;project=rtmp_client">clientId</a>;
<a class="l" name="1081" href="#1081">1081</a>		<b>if</b> (<a class="d" href="#host">host</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="1082" href="#1082">1082</a>			<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> + <a class="d" href="#host">host</a>.<a class="d" href="#hashCode">hashCode</a>();
<a class="l" name="1083" href="#1083">1083</a>		}
<a class="l" name="1084" href="#1084">1084</a>		<b>if</b> (<a href="/source/s?defs=remoteAddress&amp;project=rtmp_client">remoteAddress</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="1085" href="#1085">1085</a>			<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> + <a href="/source/s?defs=remoteAddress&amp;project=rtmp_client">remoteAddress</a>.<a class="d" href="#hashCode">hashCode</a>();
<a class="l" name="1086" href="#1086">1086</a>		}
<a class="l" name="1087" href="#1087">1087</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="1088" href="#1088">1088</a>	}
<a class="l" name="1089" href="#1089">1089</a>
<a class="hl" name="1090" href="#1090">1090</a>	<span class="c">/* (non-Javadoc)
<a class="l" name="1091" href="#1091">1091</a>	 * @see java.lang.Object#equals(java.lang.Object)
<a class="l" name="1092" href="#1092">1092</a>	 */</span>
<a class="l" name="1093" href="#1093">1093</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="1094" href="#1094">1094</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="equals"/><a href="/source/s?refs=equals&amp;project=rtmp_client" class="xmt">equals</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="obj"/><a href="/source/s?refs=obj&amp;project=rtmp_client" class="xa">obj</a>) {
<a class="l" name="1095" href="#1095">1095</a>		<b>if</b> (<b>this</b> == <a class="d" href="#obj">obj</a>) {
<a class="l" name="1096" href="#1096">1096</a>			<b>return</b> <b>true</b>;
<a class="l" name="1097" href="#1097">1097</a>		}
<a class="l" name="1098" href="#1098">1098</a>		<b>if</b> (<a class="d" href="#obj">obj</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="1099" href="#1099">1099</a>			<b>return</b> <b>false</b>;
<a class="hl" name="1100" href="#1100">1100</a>		}
<a class="l" name="1101" href="#1101">1101</a>		<b>if</b> (<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>() != <a class="d" href="#obj">obj</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>()) {
<a class="l" name="1102" href="#1102">1102</a>			<b>return</b> <b>false</b>;
<a class="l" name="1103" href="#1103">1103</a>		}
<a class="l" name="1104" href="#1104">1104</a>		<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a> <a href="/source/s?defs=other&amp;project=rtmp_client">other</a> = (<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>) <a class="d" href="#obj">obj</a>;
<a class="l" name="1105" href="#1105">1105</a>		<b>if</b> (<a href="/source/s?defs=clientId&amp;project=rtmp_client">clientId</a> != <a href="/source/s?defs=other&amp;project=rtmp_client">other</a>.<a href="/source/s?defs=clientId&amp;project=rtmp_client">clientId</a>) {
<a class="l" name="1106" href="#1106">1106</a>			<b>return</b> <b>false</b>;
<a class="l" name="1107" href="#1107">1107</a>		}
<a class="l" name="1108" href="#1108">1108</a>		<b>if</b> (<a class="d" href="#host">host</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; !<a class="d" href="#host">host</a>.<a class="d" href="#equals">equals</a>(<a href="/source/s?defs=other&amp;project=rtmp_client">other</a>.<a href="/source/s?defs=getHost&amp;project=rtmp_client">getHost</a>())) {
<a class="l" name="1109" href="#1109">1109</a>			<b>return</b> <b>false</b>;
<a class="hl" name="1110" href="#1110">1110</a>		}
<a class="l" name="1111" href="#1111">1111</a>		<b>if</b> (<a href="/source/s?defs=remoteAddress&amp;project=rtmp_client">remoteAddress</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; !<a href="/source/s?defs=remoteAddress&amp;project=rtmp_client">remoteAddress</a>.<a class="d" href="#equals">equals</a>(<a href="/source/s?defs=other&amp;project=rtmp_client">other</a>.<a href="/source/s?defs=getRemoteAddress&amp;project=rtmp_client">getRemoteAddress</a>())) {
<a class="l" name="1112" href="#1112">1112</a>			<b>return</b> <b>false</b>;
<a class="l" name="1113" href="#1113">1113</a>		}
<a class="l" name="1114" href="#1114">1114</a>		<b>return</b> <b>true</b>;
<a class="l" name="1115" href="#1115">1115</a>	}
<a class="l" name="1116" href="#1116">1116</a>
<a class="l" name="1117" href="#1117">1117</a>	<span class="c">/**
<a class="l" name="1118" href="#1118">1118</a>	 * Quartz job that keeps connection alive and disconnects if client is dead.
<a class="l" name="1119" href="#1119">1119</a>	 */</span>
<a class="hl" name="1120" href="#1120">1120</a>	<b>private</b> <b>class</b> <a class="xc" name="KeepAliveJob"/><a href="/source/s?refs=KeepAliveJob&amp;project=rtmp_client" class="xc">KeepAliveJob</a> <b>implements</b> <a href="/source/s?defs=IScheduledJob&amp;project=rtmp_client">IScheduledJob</a> {
<a class="l" name="1121" href="#1121">1121</a>
<a class="l" name="1122" href="#1122">1122</a>		<b>private</b> <b>final</b> <a href="/source/s?defs=AtomicLong&amp;project=rtmp_client">AtomicLong</a> <a class="xfld" name="lastBytesRead"/><a href="/source/s?refs=lastBytesRead&amp;project=rtmp_client" class="xfld">lastBytesRead</a> = <b>new</b> <a href="/source/s?defs=AtomicLong&amp;project=rtmp_client">AtomicLong</a>(<span class="n">0</span>);
<a class="l" name="1123" href="#1123">1123</a>
<a class="l" name="1124" href="#1124">1124</a>		<b>private</b> <b>volatile</b> <b>long</b> <a class="xfld" name="lastBytesReadTime"/><a href="/source/s?refs=lastBytesReadTime&amp;project=rtmp_client" class="xfld">lastBytesReadTime</a> = <span class="n">0</span>;
<a class="l" name="1125" href="#1125">1125</a>
<a class="l" name="1126" href="#1126">1126</a>		<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="1127" href="#1127">1127</a>		<b>public</b> <b>void</b> <a class="xmt" name="execute"/><a href="/source/s?refs=execute&amp;project=rtmp_client" class="xmt">execute</a>(<a href="/source/s?defs=ISchedulingService&amp;project=rtmp_client">ISchedulingService</a> <a class="xa" name="service"/><a href="/source/s?refs=service&amp;project=rtmp_client" class="xa">service</a>) {
<a class="l" name="1128" href="#1128">1128</a>			<b>long</b> <a href="/source/s?defs=thisRead&amp;project=rtmp_client">thisRead</a> = <a class="d" href="#getReadBytes">getReadBytes</a>();
<a class="l" name="1129" href="#1129">1129</a>			<b>long</b> <a href="/source/s?defs=previousReadBytes&amp;project=rtmp_client">previousReadBytes</a> = <a class="d" href="#lastBytesRead">lastBytesRead</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="hl" name="1130" href="#1130">1130</a>			<b>if</b> (<a href="/source/s?defs=thisRead&amp;project=rtmp_client">thisRead</a> &gt; <a href="/source/s?defs=previousReadBytes&amp;project=rtmp_client">previousReadBytes</a>) {
<a class="l" name="1131" href="#1131">1131</a>				<span class="c">// Client sent data since last check and thus is not dead. No need to ping</span>
<a class="l" name="1132" href="#1132">1132</a>				<b>if</b> (<a class="d" href="#lastBytesRead">lastBytesRead</a>.<a href="/source/s?defs=compareAndSet&amp;project=rtmp_client">compareAndSet</a>(<a href="/source/s?defs=previousReadBytes&amp;project=rtmp_client">previousReadBytes</a>, <a href="/source/s?defs=thisRead&amp;project=rtmp_client">thisRead</a>)) {
<a class="l" name="1133" href="#1133">1133</a>					<a class="d" href="#lastBytesReadTime">lastBytesReadTime</a> = <a href="/source/s?defs=System&amp;project=rtmp_client">System</a>.<a href="/source/s?defs=currentTimeMillis&amp;project=rtmp_client">currentTimeMillis</a>();
<a class="l" name="1134" href="#1134">1134</a>				}
<a class="l" name="1135" href="#1135">1135</a>				<b>return</b>;
<a class="l" name="1136" href="#1136">1136</a>			}
<a class="l" name="1137" href="#1137">1137</a>			<span class="c">// Client didn't send response to ping command and didn't sent data for too long, disconnect</span>
<a class="l" name="1138" href="#1138">1138</a>			<b>if</b> (<a class="d" href="#lastPongReceived">lastPongReceived</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &gt; <span class="n">0</span> &amp;&amp; (<a class="d" href="#lastPingSent">lastPingSent</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() - <a class="d" href="#lastPongReceived">lastPongReceived</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &gt; <a href="/source/s?defs=maxInactivity&amp;project=rtmp_client">maxInactivity</a>) &amp;&amp; !(<a href="/source/s?defs=System&amp;project=rtmp_client">System</a>.<a href="/source/s?defs=currentTimeMillis&amp;project=rtmp_client">currentTimeMillis</a>() - <a class="d" href="#lastBytesReadTime">lastBytesReadTime</a> &lt; <a href="/source/s?defs=maxInactivity&amp;project=rtmp_client">maxInactivity</a>)) {
<a class="l" name="1139" href="#1139">1139</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Keep alive job name {}"</span>, <a class="d" href="#keepAliveJobName">keepAliveJobName</a>);
<a class="hl" name="1140" href="#1140">1140</a>				<b>if</b> (<a class="d" href="#log">log</a>.<a href="/source/s?defs=isDebugEnabled&amp;project=rtmp_client">isDebugEnabled</a>()) {
<a class="l" name="1141" href="#1141">1141</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Scheduled job list"</span>);
<a class="l" name="1142" href="#1142">1142</a>					<b>for</b> (<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=jobName&amp;project=rtmp_client">jobName</a> : <a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=getScheduledJobNames&amp;project=rtmp_client">getScheduledJobNames</a>()) {
<a class="l" name="1143" href="#1143">1143</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Job: {}"</span>, <a href="/source/s?defs=jobName&amp;project=rtmp_client">jobName</a>);
<a class="l" name="1144" href="#1144">1144</a>					}
<a class="l" name="1145" href="#1145">1145</a>				}
<a class="l" name="1146" href="#1146">1146</a>				<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=removeScheduledJob&amp;project=rtmp_client">removeScheduledJob</a>(<a class="d" href="#keepAliveJobName">keepAliveJobName</a>);
<a class="l" name="1147" href="#1147">1147</a>				<a class="d" href="#keepAliveJobName">keepAliveJobName</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="1148" href="#1148">1148</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Closing {}, with id {}, due to too much inactivity ({}ms), last ping sent {}ms ago"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<b>this</b>, <a class="d" href="#getId">getId</a>(),
<a class="l" name="1149" href="#1149">1149</a>						(<a class="d" href="#lastPingSent">lastPingSent</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() - <a class="d" href="#lastPongReceived">lastPongReceived</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>()), (<a href="/source/s?defs=System&amp;project=rtmp_client">System</a>.<a href="/source/s?defs=currentTimeMillis&amp;project=rtmp_client">currentTimeMillis</a>() - <a class="d" href="#lastPingSent">lastPingSent</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>()) });
<a class="hl" name="1150" href="#1150">1150</a>				<span class="c">// Add the following line to (hopefully) deal with a very common support request</span>
<a class="l" name="1151" href="#1151">1151</a>				<span class="c">// on the Red5 list</span>
<a class="l" name="1152" href="#1152">1152</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"This often happens if YOUR Red5 application generated an exception on start-up. Check earlier in the log for that exception first!"</span>);
<a class="l" name="1153" href="#1153">1153</a>				<a class="d" href="#onInactive">onInactive</a>();
<a class="l" name="1154" href="#1154">1154</a>				<b>return</b>;
<a class="l" name="1155" href="#1155">1155</a>			}
<a class="l" name="1156" href="#1156">1156</a>			<span class="c">// Send ping command to client to trigger sending of data</span>
<a class="l" name="1157" href="#1157">1157</a>			<a href="/source/s?defs=ping&amp;project=rtmp_client">ping</a>();
<a class="l" name="1158" href="#1158">1158</a>		}
<a class="l" name="1159" href="#1159">1159</a>	}
<a class="hl" name="1160" href="#1160">1160</a>
<a class="l" name="1161" href="#1161">1161</a>	<span class="c">/**
<a class="l" name="1162" href="#1162">1162</a>	 * Quartz job that waits for a valid handshake and disconnects the client if
<a class="l" name="1163" href="#1163">1163</a>	 * none is received.
<a class="l" name="1164" href="#1164">1164</a>	 */</span>
<a class="l" name="1165" href="#1165">1165</a>	<b>private</b> <b>class</b> <a class="xc" name="WaitForHandshakeJob"/><a href="/source/s?refs=WaitForHandshakeJob&amp;project=rtmp_client" class="xc">WaitForHandshakeJob</a> <b>implements</b> <a href="/source/s?defs=IScheduledJob&amp;project=rtmp_client">IScheduledJob</a> {
<a class="l" name="1166" href="#1166">1166</a>
<a class="l" name="1167" href="#1167">1167</a>		<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="1168" href="#1168">1168</a>		<b>public</b> <b>void</b> <a class="xmt" name="execute"/><a href="/source/s?refs=execute&amp;project=rtmp_client" class="xmt">execute</a>(<a href="/source/s?defs=ISchedulingService&amp;project=rtmp_client">ISchedulingService</a> <a class="xa" name="service"/><a href="/source/s?refs=service&amp;project=rtmp_client" class="xa">service</a>) {
<a class="l" name="1169" href="#1169">1169</a>			<a class="d" href="#waitForHandshakeJob">waitForHandshakeJob</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="hl" name="1170" href="#1170">1170</a>			<span class="c">// Client didn't send a valid handshake, disconnect</span>
<a class="l" name="1171" href="#1171">1171</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Closing {}, with id {} due to long handshake"</span>, <a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>.<b>this</b>, <a class="d" href="#getId">getId</a>());
<a class="l" name="1172" href="#1172">1172</a>			<a class="d" href="#onInactive">onInactive</a>();
<a class="l" name="1173" href="#1173">1173</a>		}
<a class="l" name="1174" href="#1174">1174</a>	}
<a class="l" name="1175" href="#1175">1175</a>
<a class="l" name="1176" href="#1176">1176</a>}
<a class="l" name="1177" href="#1177">1177</a>