<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.red5.server.net.rtmp.status",1]]],["Interface","xi",[["StatusCodes",26]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=status&amp;project=rtmp_client">status</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><span class="c">/**
<a class="l" name="23" href="#23">23</a> * Collection of commonly used constants with status codes. Descriptions provided as in FMS 2.0.1
<a class="l" name="24" href="#24">24</a> * documentation available at adobe.com with some minor additions and comments.
<a class="l" name="25" href="#25">25</a> */</span>
<a class="l" name="26" href="#26">26</a><b>public</b> <b>interface</b> <a class="xi" name="StatusCodes"/><a href="/source/s?refs=StatusCodes&amp;project=rtmp_client" class="xi">StatusCodes</a> {
<a class="l" name="27" href="#27">27</a>    <span class="c">/**
<a class="l" name="28" href="#28">28</a>     * The NetConnection.call method was not able to invoke the server-side method or
<a class="l" name="29" href="#29">29</a>     * command.
<a class="hl" name="30" href="#30">30</a>     */</span>
<a class="l" name="31" href="#31">31</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NC_CALL_FAILED"/><a href="/source/s?refs=NC_CALL_FAILED&amp;project=rtmp_client" class="xfld">NC_CALL_FAILED</a> = <span class="s">"NetConnection.Call.Failed"</span>;
<a class="l" name="32" href="#32">32</a>    <span class="c">/**
<a class="l" name="33" href="#33">33</a>     * The URI specified in the NetConnection.connect method did not
<a class="l" name="34" href="#34">34</a>     * specify 'rtmp' as the protocol. 'rtmp' must be specified when connecting to
<a class="l" name="35" href="#35">35</a>     * FMS and Red5. Either not supported version of AMF was used (3 when only 0 is supported)
<a class="l" name="36" href="#36">36</a>     */</span>
<a class="l" name="37" href="#37">37</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NC_CALL_BADVERSION"/><a href="/source/s?refs=NC_CALL_BADVERSION&amp;project=rtmp_client" class="xfld">NC_CALL_BADVERSION</a> = <span class="s">"NetConnection.Call.BadVersion"</span>;
<a class="l" name="38" href="#38">38</a>    <span class="c">/**
<a class="l" name="39" href="#39">39</a>     * The application has been shut down (for example, if the application is out of
<a class="hl" name="40" href="#40">40</a>     * memory resources and must shut down to prevent the server from crashing) or the server has shut down.
<a class="l" name="41" href="#41">41</a>     */</span>
<a class="l" name="42" href="#42">42</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NC_CONNECT_APPSHUTDOWN"/><a href="/source/s?refs=NC_CONNECT_APPSHUTDOWN&amp;project=rtmp_client" class="xfld">NC_CONNECT_APPSHUTDOWN</a> = <span class="s">"NetConnection.Connect.AppShutdown"</span>;
<a class="l" name="43" href="#43">43</a>    <span class="c">/**
<a class="l" name="44" href="#44">44</a>     * The connection was closed successfully
<a class="l" name="45" href="#45">45</a>     */</span>
<a class="l" name="46" href="#46">46</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NC_CONNECT_CLOSED"/><a href="/source/s?refs=NC_CONNECT_CLOSED&amp;project=rtmp_client" class="xfld">NC_CONNECT_CLOSED</a> = <span class="s">"NetConnection.Connect.Closed"</span>;
<a class="l" name="47" href="#47">47</a>    <span class="c">/**
<a class="l" name="48" href="#48">48</a>     * The connection attempt failed.
<a class="l" name="49" href="#49">49</a>     */</span>
<a class="hl" name="50" href="#50">50</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NC_CONNECT_FAILED"/><a href="/source/s?refs=NC_CONNECT_FAILED&amp;project=rtmp_client" class="xfld">NC_CONNECT_FAILED</a> = <span class="s">"NetConnection.Connect.Failed"</span>;
<a class="l" name="51" href="#51">51</a>    <span class="c">/**
<a class="l" name="52" href="#52">52</a>     * The client does not have permission to connect to the application, the
<a class="l" name="53" href="#53">53</a>     * application expected different parameters from those that were passed,
<a class="l" name="54" href="#54">54</a>     * or the application name specified during the connection attempt was not found on
<a class="l" name="55" href="#55">55</a>     * the server.
<a class="l" name="56" href="#56">56</a>     */</span>
<a class="l" name="57" href="#57">57</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NC_CONNECT_REJECTED"/><a href="/source/s?refs=NC_CONNECT_REJECTED&amp;project=rtmp_client" class="xfld">NC_CONNECT_REJECTED</a> = <span class="s">"NetConnection.Connect.Rejected"</span>;
<a class="l" name="58" href="#58">58</a>    <span class="c">/**
<a class="l" name="59" href="#59">59</a>     * The connection attempt succeeded.
<a class="hl" name="60" href="#60">60</a>     */</span>
<a class="l" name="61" href="#61">61</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NC_CONNECT_SUCCESS"/><a href="/source/s?refs=NC_CONNECT_SUCCESS&amp;project=rtmp_client" class="xfld">NC_CONNECT_SUCCESS</a> = <span class="s">"NetConnection.Connect.Success"</span>;
<a class="l" name="62" href="#62">62</a>    <span class="c">/**
<a class="l" name="63" href="#63">63</a>     * The application name specified during connect is invalid.
<a class="l" name="64" href="#64">64</a>     */</span>
<a class="l" name="65" href="#65">65</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NC_CONNECT_INVALID_APPLICATION"/><a href="/source/s?refs=NC_CONNECT_INVALID_APPLICATION&amp;project=rtmp_client" class="xfld">NC_CONNECT_INVALID_APPLICATION</a> = <span class="s">"NetConnection.Connect.InvalidApp"</span>;
<a class="l" name="66" href="#66">66</a>	<span class="c">/**
<a class="l" name="67" href="#67">67</a>	 * Invalid arguments were passed to a NetStream method.
<a class="l" name="68" href="#68">68</a>	 */</span>
<a class="l" name="69" href="#69">69</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_INVALID_ARGUMENT"/><a href="/source/s?refs=NS_INVALID_ARGUMENT&amp;project=rtmp_client" class="xfld">NS_INVALID_ARGUMENT</a> = <span class="s">"NetStream.InvalidArg"</span>;
<a class="hl" name="70" href="#70">70</a>    <span class="c">/**
<a class="l" name="71" href="#71">71</a>     * A recorded stream was deleted successfully.
<a class="l" name="72" href="#72">72</a>     */</span>
<a class="l" name="73" href="#73">73</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_CLEAR_SUCCESS"/><a href="/source/s?refs=NS_CLEAR_SUCCESS&amp;project=rtmp_client" class="xfld">NS_CLEAR_SUCCESS</a> = <span class="s">"NetStream.Clear.Success"</span>;
<a class="l" name="74" href="#74">74</a>    <span class="c">/**
<a class="l" name="75" href="#75">75</a>     * A recorded stream failed to delete.
<a class="l" name="76" href="#76">76</a>     */</span>
<a class="l" name="77" href="#77">77</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_CLEAR_FAILED"/><a href="/source/s?refs=NS_CLEAR_FAILED&amp;project=rtmp_client" class="xfld">NS_CLEAR_FAILED</a> = <span class="s">"NetStream.Clear.Failed"</span>;
<a class="l" name="78" href="#78">78</a>    <span class="c">/**
<a class="l" name="79" href="#79">79</a>     * An attempt to publish was successful.
<a class="hl" name="80" href="#80">80</a>     */</span>
<a class="l" name="81" href="#81">81</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_PUBLISH_START"/><a href="/source/s?refs=NS_PUBLISH_START&amp;project=rtmp_client" class="xfld">NS_PUBLISH_START</a> = <span class="s">"NetStream.Publish.Start"</span>;
<a class="l" name="82" href="#82">82</a>    <span class="c">/**
<a class="l" name="83" href="#83">83</a>     * An attempt was made to publish a stream that is already being published by someone else.
<a class="l" name="84" href="#84">84</a>     */</span>
<a class="l" name="85" href="#85">85</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_PUBLISH_BADNAME"/><a href="/source/s?refs=NS_PUBLISH_BADNAME&amp;project=rtmp_client" class="xfld">NS_PUBLISH_BADNAME</a> = <span class="s">"NetStream.Publish.BadName"</span>;
<a class="l" name="86" href="#86">86</a>    <span class="c">/**
<a class="l" name="87" href="#87">87</a>     * An attempt to use a Stream method (at client-side) failed
<a class="l" name="88" href="#88">88</a>     */</span>
<a class="l" name="89" href="#89">89</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_FAILED"/><a href="/source/s?refs=NS_FAILED&amp;project=rtmp_client" class="xfld">NS_FAILED</a> = <span class="s">"NetStream.Failed"</span>;
<a class="hl" name="90" href="#90">90</a>    <span class="c">/**
<a class="l" name="91" href="#91">91</a>     * An attempt to unpublish was successful
<a class="l" name="92" href="#92">92</a>     */</span>
<a class="l" name="93" href="#93">93</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_UNPUBLISHED_SUCCESS"/><a href="/source/s?refs=NS_UNPUBLISHED_SUCCESS&amp;project=rtmp_client" class="xfld">NS_UNPUBLISHED_SUCCESS</a> = <span class="s">"NetStream.Unpublish.Success"</span>;
<a class="l" name="94" href="#94">94</a>    <span class="c">/**
<a class="l" name="95" href="#95">95</a>     * Recording was started
<a class="l" name="96" href="#96">96</a>     */</span>
<a class="l" name="97" href="#97">97</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_RECORD_START"/><a href="/source/s?refs=NS_RECORD_START&amp;project=rtmp_client" class="xfld">NS_RECORD_START</a> = <span class="s">"NetStream.Record.Start"</span>;
<a class="l" name="98" href="#98">98</a>    <span class="c">/**
<a class="l" name="99" href="#99">99</a>     * An attempt was made to record a read-only stream
<a class="hl" name="100" href="#100">100</a>     */</span>
<a class="l" name="101" href="#101">101</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_RECORD_NOACCESS"/><a href="/source/s?refs=NS_RECORD_NOACCESS&amp;project=rtmp_client" class="xfld">NS_RECORD_NOACCESS</a> = <span class="s">"NetStream.Record.NoAccess"</span>;
<a class="l" name="102" href="#102">102</a>    <span class="c">/**
<a class="l" name="103" href="#103">103</a>     * Recording was stopped
<a class="l" name="104" href="#104">104</a>     */</span>
<a class="l" name="105" href="#105">105</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_RECORD_STOP"/><a href="/source/s?refs=NS_RECORD_STOP&amp;project=rtmp_client" class="xfld">NS_RECORD_STOP</a> = <span class="s">"NetStream.Record.Stop"</span>;
<a class="l" name="106" href="#106">106</a>    <span class="c">/**
<a class="l" name="107" href="#107">107</a>     * An attempt to record a stream failed
<a class="l" name="108" href="#108">108</a>     */</span>
<a class="l" name="109" href="#109">109</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_RECORD_FAILED"/><a href="/source/s?refs=NS_RECORD_FAILED&amp;project=rtmp_client" class="xfld">NS_RECORD_FAILED</a> = <span class="s">"NetStream.Record.Failed"</span>;
<a class="hl" name="110" href="#110">110</a>
<a class="l" name="111" href="#111">111</a>	<span class="c">/**
<a class="l" name="112" href="#112">112</a>	 * The buffer is empty (sent from server to client)
<a class="l" name="113" href="#113">113</a>	 */</span>
<a class="l" name="114" href="#114">114</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_BUFFER_EMPTY"/><a href="/source/s?refs=NS_BUFFER_EMPTY&amp;project=rtmp_client" class="xfld">NS_BUFFER_EMPTY</a> = <span class="s">"NetStream.Buffer.Empty"</span>;
<a class="l" name="115" href="#115">115</a>
<a class="l" name="116" href="#116">116</a>	<span class="c">/**
<a class="l" name="117" href="#117">117</a>	 * Data is playing behind the normal speed
<a class="l" name="118" href="#118">118</a>	 */</span>
<a class="l" name="119" href="#119">119</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_PLAY_INSUFFICIENT_BW"/><a href="/source/s?refs=NS_PLAY_INSUFFICIENT_BW&amp;project=rtmp_client" class="xfld">NS_PLAY_INSUFFICIENT_BW</a> = <span class="s">"NetStream.Play.InsufficientBW"</span>;
<a class="hl" name="120" href="#120">120</a>    <span class="c">/**
<a class="l" name="121" href="#121">121</a>     * Play was started
<a class="l" name="122" href="#122">122</a>     */</span>
<a class="l" name="123" href="#123">123</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_PLAY_START"/><a href="/source/s?refs=NS_PLAY_START&amp;project=rtmp_client" class="xfld">NS_PLAY_START</a> = <span class="s">"NetStream.Play.Start"</span>;
<a class="l" name="124" href="#124">124</a>    <span class="c">/**
<a class="l" name="125" href="#125">125</a>     * An attempt was made to play a stream that does not exist
<a class="l" name="126" href="#126">126</a>     */</span>
<a class="l" name="127" href="#127">127</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_PLAY_STREAMNOTFOUND"/><a href="/source/s?refs=NS_PLAY_STREAMNOTFOUND&amp;project=rtmp_client" class="xfld">NS_PLAY_STREAMNOTFOUND</a> = <span class="s">"NetStream.Play.StreamNotFound"</span>;
<a class="l" name="128" href="#128">128</a>    <span class="c">/**
<a class="l" name="129" href="#129">129</a>     * Play was stopped
<a class="hl" name="130" href="#130">130</a>     */</span>
<a class="l" name="131" href="#131">131</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_PLAY_STOP"/><a href="/source/s?refs=NS_PLAY_STOP&amp;project=rtmp_client" class="xfld">NS_PLAY_STOP</a> = <span class="s">"NetStream.Play.Stop"</span>;
<a class="l" name="132" href="#132">132</a>    <span class="c">/**
<a class="l" name="133" href="#133">133</a>     * An attempt to play back a stream failed
<a class="l" name="134" href="#134">134</a>     */</span>
<a class="l" name="135" href="#135">135</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_PLAY_FAILED"/><a href="/source/s?refs=NS_PLAY_FAILED&amp;project=rtmp_client" class="xfld">NS_PLAY_FAILED</a> = <span class="s">"NetStream.Play.Failed"</span>;
<a class="l" name="136" href="#136">136</a>    <span class="c">/**
<a class="l" name="137" href="#137">137</a>     * A playlist was reset
<a class="l" name="138" href="#138">138</a>     */</span>
<a class="l" name="139" href="#139">139</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_PLAY_RESET"/><a href="/source/s?refs=NS_PLAY_RESET&amp;project=rtmp_client" class="xfld">NS_PLAY_RESET</a> = <span class="s">"NetStream.Play.Reset"</span>;
<a class="hl" name="140" href="#140">140</a>    <span class="c">/**
<a class="l" name="141" href="#141">141</a>     * The initial publish to a stream was successful. This message is sent to all subscribers
<a class="l" name="142" href="#142">142</a>     */</span>
<a class="l" name="143" href="#143">143</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_PLAY_PUBLISHNOTIFY"/><a href="/source/s?refs=NS_PLAY_PUBLISHNOTIFY&amp;project=rtmp_client" class="xfld">NS_PLAY_PUBLISHNOTIFY</a> = <span class="s">"NetStream.Play.PublishNotify"</span>;
<a class="l" name="144" href="#144">144</a>    <span class="c">/**
<a class="l" name="145" href="#145">145</a>     * An unpublish from a stream was successful. This message is sent to all subscribers
<a class="l" name="146" href="#146">146</a>     */</span>
<a class="l" name="147" href="#147">147</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_PLAY_UNPUBLISHNOTIFY"/><a href="/source/s?refs=NS_PLAY_UNPUBLISHNOTIFY&amp;project=rtmp_client" class="xfld">NS_PLAY_UNPUBLISHNOTIFY</a> = <span class="s">"NetStream.Play.UnpublishNotify"</span>;
<a class="l" name="148" href="#148">148</a>    <span class="c">/**
<a class="l" name="149" href="#149">149</a>     * Playlist playback switched from one stream to another.
<a class="hl" name="150" href="#150">150</a>     */</span>
<a class="l" name="151" href="#151">151</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_PLAY_SWITCH"/><a href="/source/s?refs=NS_PLAY_SWITCH&amp;project=rtmp_client" class="xfld">NS_PLAY_SWITCH</a> = <span class="s">"NetStream.Play.Switch"</span>;
<a class="l" name="152" href="#152">152</a>    <span class="c">/**
<a class="l" name="153" href="#153">153</a>     * Playlist playback is complete.
<a class="l" name="154" href="#154">154</a>     */</span>
<a class="l" name="155" href="#155">155</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_PLAY_COMPLETE"/><a href="/source/s?refs=NS_PLAY_COMPLETE&amp;project=rtmp_client" class="xfld">NS_PLAY_COMPLETE</a> = <span class="s">"NetStream.Play.Complete"</span>;
<a class="l" name="156" href="#156">156</a>    <span class="c">/**
<a class="l" name="157" href="#157">157</a>     * The subscriber has used the seek command to move to a particular location in the recorded stream.
<a class="l" name="158" href="#158">158</a>     */</span>
<a class="l" name="159" href="#159">159</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_SEEK_NOTIFY"/><a href="/source/s?refs=NS_SEEK_NOTIFY&amp;project=rtmp_client" class="xfld">NS_SEEK_NOTIFY</a> = <span class="s">"NetStream.Seek.Notify"</span>;
<a class="hl" name="160" href="#160">160</a>	<span class="c">/**
<a class="l" name="161" href="#161">161</a>	 * The stream doesn't support seeking.
<a class="l" name="162" href="#162">162</a>	 */</span>
<a class="l" name="163" href="#163">163</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_SEEK_FAILED"/><a href="/source/s?refs=NS_SEEK_FAILED&amp;project=rtmp_client" class="xfld">NS_SEEK_FAILED</a> = <span class="s">"NetStream.Seek.Failed"</span>;
<a class="l" name="164" href="#164">164</a>    <span class="c">/**
<a class="l" name="165" href="#165">165</a>     * The subscriber has used the seek command to move to a particular location in the recorded stream.
<a class="l" name="166" href="#166">166</a>     */</span>
<a class="l" name="167" href="#167">167</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_PAUSE_NOTIFY"/><a href="/source/s?refs=NS_PAUSE_NOTIFY&amp;project=rtmp_client" class="xfld">NS_PAUSE_NOTIFY</a> = <span class="s">"NetStream.Pause.Notify"</span>;
<a class="l" name="168" href="#168">168</a>    <span class="c">/**
<a class="l" name="169" href="#169">169</a>     * Publishing has stopped
<a class="hl" name="170" href="#170">170</a>     */</span>
<a class="l" name="171" href="#171">171</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_UNPAUSE_NOTIFY"/><a href="/source/s?refs=NS_UNPAUSE_NOTIFY&amp;project=rtmp_client" class="xfld">NS_UNPAUSE_NOTIFY</a> = <span class="s">"NetStream.Unpause.Notify"</span>;
<a class="l" name="172" href="#172">172</a>    <span class="c">/**
<a class="l" name="173" href="#173">173</a>     *
<a class="l" name="174" href="#174">174</a>     */</span>
<a class="l" name="175" href="#175">175</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_DATA_START"/><a href="/source/s?refs=NS_DATA_START&amp;project=rtmp_client" class="xfld">NS_DATA_START</a> = <span class="s">"NetStream.Data.Start"</span>;
<a class="l" name="176" href="#176">176</a>    <span class="c">/**
<a class="l" name="177" href="#177">177</a>     * The ActionScript engine has encountered a runtime error. In addition to the standard infoObject
<a class="l" name="178" href="#178">178</a>     * properties, the following properties are set:
<a class="l" name="179" href="#179">179</a>     *
<a class="hl" name="180" href="#180">180</a>     * filename: name of the offending ASC file.
<a class="l" name="181" href="#181">181</a>     * lineno: line number where the error occurred.
<a class="l" name="182" href="#182">182</a>     * linebuf: source code of the offending line.
<a class="l" name="183" href="#183">183</a>     */</span>
<a class="l" name="184" href="#184">184</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="APP_SCRIPT_ERROR"/><a href="/source/s?refs=APP_SCRIPT_ERROR&amp;project=rtmp_client" class="xfld">APP_SCRIPT_ERROR</a> = <span class="s">"Application.Script.Error"</span>;
<a class="l" name="185" href="#185">185</a>    <span class="c">/**
<a class="l" name="186" href="#186">186</a>     * The ActionScript engine has encountered a runtime warning. In addition to the standard infoObject
<a class="l" name="187" href="#187">187</a>     * properties, the following properties are set:
<a class="l" name="188" href="#188">188</a>     *
<a class="l" name="189" href="#189">189</a>     * filename: name of the offending ASC file.
<a class="hl" name="190" href="#190">190</a>     * lineno: line number where the error occurred.
<a class="l" name="191" href="#191">191</a>     * linebuf: source code of the offending line
<a class="l" name="192" href="#192">192</a>     */</span>
<a class="l" name="193" href="#193">193</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="APP_SCRIPT_WARNING"/><a href="/source/s?refs=APP_SCRIPT_WARNING&amp;project=rtmp_client" class="xfld">APP_SCRIPT_WARNING</a> = <span class="s">"Application.Script.Warning"</span>;
<a class="l" name="194" href="#194">194</a>    <span class="c">/**
<a class="l" name="195" href="#195">195</a>     * The ActionScript engine is low on runtime memory. This provides an opportunity for the
<a class="l" name="196" href="#196">196</a>     * application instance to free some resources or take suitable action. If the application instance
<a class="l" name="197" href="#197">197</a>     * runs out of memory, it is unloaded and all users are disconnected. In this state, the server will
<a class="l" name="198" href="#198">198</a>     * not invoke the Application.onDisconnect event handler or the Application.onAppStop event handler
<a class="l" name="199" href="#199">199</a>     */</span>
<a class="hl" name="200" href="#200">200</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="APP_RESOURCE_LOWMEMORY"/><a href="/source/s?refs=APP_RESOURCE_LOWMEMORY&amp;project=rtmp_client" class="xfld">APP_RESOURCE_LOWMEMORY</a> = <span class="s">"Application.Resource.LowMemory"</span>;
<a class="l" name="201" href="#201">201</a>    <span class="c">/**
<a class="l" name="202" href="#202">202</a>     * This information object is passed to the onAppStop handler when the application is being shut down
<a class="l" name="203" href="#203">203</a>     */</span>
<a class="l" name="204" href="#204">204</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="APP_SHUTDOWN"/><a href="/source/s?refs=APP_SHUTDOWN&amp;project=rtmp_client" class="xfld">APP_SHUTDOWN</a> = <span class="s">"Application.Shutdown"</span>;
<a class="l" name="205" href="#205">205</a>    <span class="c">/**
<a class="l" name="206" href="#206">206</a>     * This information object is passed to the onAppStop event handler when the application instance
<a class="l" name="207" href="#207">207</a>     * is about to be destroyed by the server.
<a class="l" name="208" href="#208">208</a>     */</span>
<a class="l" name="209" href="#209">209</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="APP_GC"/><a href="/source/s?refs=APP_GC&amp;project=rtmp_client" class="xfld">APP_GC</a> = <span class="s">"Application.GC"</span>;
<a class="hl" name="210" href="#210">210</a>	<span class="c">/**
<a class="l" name="211" href="#211">211</a>	 * Read access to a shared object was denied.
<a class="l" name="212" href="#212">212</a>	 */</span>
<a class="l" name="213" href="#213">213</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="SO_NO_READ_ACCESS"/><a href="/source/s?refs=SO_NO_READ_ACCESS&amp;project=rtmp_client" class="xfld">SO_NO_READ_ACCESS</a> = <span class="s">"SharedObject.NoReadAccess"</span>;
<a class="l" name="214" href="#214">214</a>	<span class="c">/**
<a class="l" name="215" href="#215">215</a>	 * Write access to a shared object was denied.
<a class="l" name="216" href="#216">216</a>	 */</span>
<a class="l" name="217" href="#217">217</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="SO_NO_WRITE_ACCESS"/><a href="/source/s?refs=SO_NO_WRITE_ACCESS&amp;project=rtmp_client" class="xfld">SO_NO_WRITE_ACCESS</a> = <span class="s">"SharedObject.NoWriteAccess"</span>;
<a class="l" name="218" href="#218">218</a>	<span class="c">/**
<a class="l" name="219" href="#219">219</a>	 * The creation of a shared object was denied.
<a class="hl" name="220" href="#220">220</a>	 */</span>
<a class="l" name="221" href="#221">221</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="SO_CREATION_FAILED"/><a href="/source/s?refs=SO_CREATION_FAILED&amp;project=rtmp_client" class="xfld">SO_CREATION_FAILED</a> = <span class="s">"SharedObject.ObjectCreationFailed"</span>;
<a class="l" name="222" href="#222">222</a>	<span class="c">/**
<a class="l" name="223" href="#223">223</a>	 * The persistence parameter passed to SharedObject.getRemote() is different from the one used
<a class="l" name="224" href="#224">224</a>	 * when the shared object was created.
<a class="l" name="225" href="#225">225</a>	 */</span>
<a class="l" name="226" href="#226">226</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="SO_PERSISTENCE_MISMATCH"/><a href="/source/s?refs=SO_PERSISTENCE_MISMATCH&amp;project=rtmp_client" class="xfld">SO_PERSISTENCE_MISMATCH</a> = <span class="s">"SharedObject.BadPersistence"</span>;
<a class="l" name="227" href="#227">227</a>
<a class="l" name="228" href="#228">228</a>	<span class="c">/**
<a class="l" name="229" href="#229">229</a>	 * This event is sent if the player detects an MP4 with an invalid file structure.
<a class="hl" name="230" href="#230">230</a>	 * Flash Player cannot play files that have invalid file structures.
<a class="l" name="231" href="#231">231</a>	 *
<a class="l" name="232" href="#232">232</a>	 * New for FMS3
<a class="l" name="233" href="#233">233</a>	 */</span>
<a class="l" name="234" href="#234">234</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_PLAY_FILE_STRUCTURE_INVALID"/><a href="/source/s?refs=NS_PLAY_FILE_STRUCTURE_INVALID&amp;project=rtmp_client" class="xfld">NS_PLAY_FILE_STRUCTURE_INVALID</a> = <span class="s">"NetStream.Play.FileStructureInvalid"</span>;
<a class="l" name="235" href="#235">235</a>
<a class="l" name="236" href="#236">236</a>	<span class="c">/**
<a class="l" name="237" href="#237">237</a>	 * This event is sent if the player does not detect any supported tracks. If there aren't any supported
<a class="l" name="238" href="#238">238</a>	 * video, audio or data tracks found, Flash Player does not play the file.
<a class="l" name="239" href="#239">239</a>	 *
<a class="hl" name="240" href="#240">240</a>	 * New for FMS3
<a class="l" name="241" href="#241">241</a>	 */</span>
<a class="l" name="242" href="#242">242</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NS_PLAY_NO_SUPPORTED_TRACK_FOUND"/><a href="/source/s?refs=NS_PLAY_NO_SUPPORTED_TRACK_FOUND&amp;project=rtmp_client" class="xfld">NS_PLAY_NO_SUPPORTED_TRACK_FOUND</a> = <span class="s">"NetStream.Play.NoSupportedTrackFound"</span>;
<a class="l" name="243" href="#243">243</a>
<a class="l" name="244" href="#244">244</a>
<a class="l" name="245" href="#245">245</a>}
<a class="l" name="246" href="#246">246</a>