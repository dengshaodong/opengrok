<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["RTMPClient",45]]],["Package","xp",[["org.red5.server.net.rtmp",1]]],["Method","xmt",[["RTMPClient",61],["disconnect",103],["makeDefaultConnectionParams",69],["startConnector",79]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=InetSocketAddress&amp;project=rtmp_client">InetSocketAddress</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a class="d" href="#future">future</a>.<a href="/source/s?defs=ConnectFuture&amp;project=rtmp_client">ConnectFuture</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a class="d" href="#future">future</a>.<a href="/source/s?defs=IoFuture&amp;project=rtmp_client">IoFuture</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=core&amp;project=rtmp_client">core</a>.<a class="d" href="#future">future</a>.<a href="/source/s?defs=IoFutureListener&amp;project=rtmp_client">IoFutureListener</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=transport&amp;project=rtmp_client">transport</a>.<a href="/source/s?defs=socket&amp;project=rtmp_client">socket</a>.<a href="/source/s?defs=SocketConnector&amp;project=rtmp_client">SocketConnector</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=apache&amp;project=rtmp_client">apache</a>.<a href="/source/s?defs=mina&amp;project=rtmp_client">mina</a>.<a href="/source/s?defs=transport&amp;project=rtmp_client">transport</a>.<a href="/source/s?defs=socket&amp;project=rtmp_client">socket</a>.<a href="/source/s?defs=nio&amp;project=rtmp_client">nio</a>.<a href="/source/s?defs=NioSocketConnector&amp;project=rtmp_client">NioSocketConnector</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=codec&amp;project=rtmp_client">codec</a>.<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a><span class="c">/**
<a class="l" name="35" href="#35">35</a> * RTMP client object. Initial client mode code by Christian Eckerle.
<a class="l" name="36" href="#36">36</a> *
<a class="l" name="37" href="#37">37</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="38" href="#38">38</a> * <strong>@author</strong> Christian Eckerle (ce@publishing-etc.de)
<a class="l" name="39" href="#39">39</a> * <strong>@author</strong> Joachim Bauch (jojo@struktur.de)
<a class="hl" name="40" href="#40">40</a> * <strong>@author</strong> Paul Gregoire (mondain@gmail.com)
<a class="l" name="41" href="#41">41</a> * <strong>@author</strong> Steven Gong (steven.gong@gmail.com)
<a class="l" name="42" href="#42">42</a> * <strong>@author</strong> Anton Lebedevich (mabrek@gmail.com)
<a class="l" name="43" href="#43">43</a> * <strong>@author</strong> Tiago Daniel Jacobs (tiago@imdt.com.br)
<a class="l" name="44" href="#44">44</a> */</span>
<a class="l" name="45" href="#45">45</a><b>public</b> <b>class</b> <a class="xc" name="RTMPClient"/><a href="/source/s?refs=RTMPClient&amp;project=rtmp_client" class="xc">RTMPClient</a> <b>extends</b> <a href="/source/s?defs=BaseRTMPClientHandler&amp;project=rtmp_client">BaseRTMPClientHandler</a> {
<a class="l" name="46" href="#46">46</a>
<a class="l" name="47" href="#47">47</a>	<b>private</b> <b>static</b> <b>final</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a href="/source/s?defs=RTMPClient&amp;project=rtmp_client">RTMPClient</a>.<b>class</b>);
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>	<b>protected</b> <b>static</b> <b>final</b> <b>int</b> <a class="xfld" name="CONNECTOR_WORKER_TIMEOUT"/><a href="/source/s?refs=CONNECTOR_WORKER_TIMEOUT&amp;project=rtmp_client" class="xfld">CONNECTOR_WORKER_TIMEOUT</a> = <span class="n">7000</span>; <span class="c">// seconds</span>
<a class="hl" name="50" href="#50">50</a>
<a class="l" name="51" href="#51">51</a>	<span class="c">// I/O handler</span>
<a class="l" name="52" href="#52">52</a>	<b>private</b> <b>final</b> <a href="/source/s?defs=RTMPMinaIoHandler&amp;project=rtmp_client">RTMPMinaIoHandler</a> <a class="xfld" name="ioHandler"/><a href="/source/s?refs=ioHandler&amp;project=rtmp_client" class="xfld">ioHandler</a>;
<a class="l" name="53" href="#53">53</a>
<a class="l" name="54" href="#54">54</a>	<span class="c">// Socket connector, disposed on disconnect</span>
<a class="l" name="55" href="#55">55</a>	<b>protected</b> <a href="/source/s?defs=SocketConnector&amp;project=rtmp_client">SocketConnector</a> <a class="xfld" name="socketConnector"/><a href="/source/s?refs=socketConnector&amp;project=rtmp_client" class="xfld">socketConnector</a>;
<a class="l" name="56" href="#56">56</a>
<a class="l" name="57" href="#57">57</a>	<span class="c">//</span>
<a class="l" name="58" href="#58">58</a>	<b>protected</b> <a href="/source/s?defs=ConnectFuture&amp;project=rtmp_client">ConnectFuture</a> <a class="xfld" name="future"/><a href="/source/s?refs=future&amp;project=rtmp_client" class="xfld">future</a>;
<a class="l" name="59" href="#59">59</a>
<a class="hl" name="60" href="#60">60</a>	<span class="c">/** Constructs a new RTMPClient. */</span>
<a class="l" name="61" href="#61">61</a>    <b>public</b> <a class="xmt" name="RTMPClient"/><a href="/source/s?refs=RTMPClient&amp;project=rtmp_client" class="xmt">RTMPClient</a>() {
<a class="l" name="62" href="#62">62</a>		<a class="d" href="#ioHandler">ioHandler</a> = <b>new</b> <a href="/source/s?defs=RTMPMinaIoHandler&amp;project=rtmp_client">RTMPMinaIoHandler</a>();
<a class="l" name="63" href="#63">63</a>		<a class="d" href="#ioHandler">ioHandler</a>.<a href="/source/s?defs=setCodecFactory&amp;project=rtmp_client">setCodecFactory</a>(<a href="/source/s?defs=getCodecFactory&amp;project=rtmp_client">getCodecFactory</a>());
<a class="l" name="64" href="#64">64</a>		<a class="d" href="#ioHandler">ioHandler</a>.<a href="/source/s?defs=setMode&amp;project=rtmp_client">setMode</a>(<a href="/source/s?defs=RTMP&amp;project=rtmp_client">RTMP</a>.<a href="/source/s?defs=MODE_CLIENT&amp;project=rtmp_client">MODE_CLIENT</a>);
<a class="l" name="65" href="#65">65</a>		<a class="d" href="#ioHandler">ioHandler</a>.<a href="/source/s?defs=setHandler&amp;project=rtmp_client">setHandler</a>(<b>this</b>);
<a class="l" name="66" href="#66">66</a>		<a class="d" href="#ioHandler">ioHandler</a>.<a href="/source/s?defs=setRtmpConnManager&amp;project=rtmp_client">setRtmpConnManager</a>(<a href="/source/s?defs=RTMPClientConnManager&amp;project=rtmp_client">RTMPClientConnManager</a>.<a href="/source/s?defs=getInstance&amp;project=rtmp_client">getInstance</a>());
<a class="l" name="67" href="#67">67</a>	}
<a class="l" name="68" href="#68">68</a>
<a class="l" name="69" href="#69">69</a>	<b>public</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xmt" name="makeDefaultConnectionParams"/><a href="/source/s?refs=makeDefaultConnectionParams&amp;project=rtmp_client" class="xmt">makeDefaultConnectionParams</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="server"/><a href="/source/s?refs=server&amp;project=rtmp_client" class="xa">server</a>, <b>int</b> <a class="xa" name="port"/><a href="/source/s?refs=port&amp;project=rtmp_client" class="xa">port</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="application"/><a href="/source/s?refs=application&amp;project=rtmp_client" class="xa">application</a>) {
<a class="hl" name="70" href="#70">70</a>		<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=params&amp;project=rtmp_client">params</a> = <b>super</b>.<a class="d" href="#makeDefaultConnectionParams">makeDefaultConnectionParams</a>(<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>, <a href="/source/s?defs=port&amp;project=rtmp_client">port</a>, <a class="d" href="#application">application</a>);
<a class="l" name="71" href="#71">71</a>		<b>if</b> (!<a href="/source/s?defs=params&amp;project=rtmp_client">params</a>.<a href="/source/s?defs=containsKey&amp;project=rtmp_client">containsKey</a>(<span class="s">"tcUrl"</span>)) {
<a class="l" name="72" href="#72">72</a>			<a href="/source/s?defs=params&amp;project=rtmp_client">params</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<span class="s">"tcUrl"</span>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<a href="/source/s?defs=format&amp;project=rtmp_client">format</a>(<span class="s">"rtmp://%s:%s/%s"</span>, <a href="/source/s?defs=server&amp;project=rtmp_client">server</a>, <a href="/source/s?defs=port&amp;project=rtmp_client">port</a>, <a class="d" href="#application">application</a>));
<a class="l" name="73" href="#73">73</a>		}
<a class="l" name="74" href="#74">74</a>		<b>return</b> <a href="/source/s?defs=params&amp;project=rtmp_client">params</a>;
<a class="l" name="75" href="#75">75</a>	}
<a class="l" name="76" href="#76">76</a>
<a class="l" name="77" href="#77">77</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>({ <span class="s">"rawtypes"</span> })
<a class="l" name="78" href="#78">78</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="79" href="#79">79</a>	<b>protected</b> <b>void</b> <a class="xmt" name="startConnector"/><a href="/source/s?refs=startConnector&amp;project=rtmp_client" class="xmt">startConnector</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="server"/><a href="/source/s?refs=server&amp;project=rtmp_client" class="xa">server</a>, <b>int</b> <a class="xa" name="port"/><a href="/source/s?refs=port&amp;project=rtmp_client" class="xa">port</a>) {
<a class="hl" name="80" href="#80">80</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"startConnector...."</span>);
<a class="l" name="81" href="#81">81</a>		<a class="d" href="#socketConnector">socketConnector</a> = <b>new</b> <a href="/source/s?defs=NioSocketConnector&amp;project=rtmp_client">NioSocketConnector</a>();
<a class="l" name="82" href="#82">82</a>		<a class="d" href="#socketConnector">socketConnector</a>.<a href="/source/s?defs=setHandler&amp;project=rtmp_client">setHandler</a>(<a class="d" href="#ioHandler">ioHandler</a>);
<a class="l" name="83" href="#83">83</a>		<a class="d" href="#future">future</a> = <a class="d" href="#socketConnector">socketConnector</a>.<a href="/source/s?defs=connect&amp;project=rtmp_client">connect</a>(<b>new</b> <a href="/source/s?defs=InetSocketAddress&amp;project=rtmp_client">InetSocketAddress</a>(<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>, <a href="/source/s?defs=port&amp;project=rtmp_client">port</a>));
<a class="l" name="84" href="#84">84</a>		<a class="d" href="#future">future</a>.<a href="/source/s?defs=addListener&amp;project=rtmp_client">addListener</a>(
<a class="l" name="85" href="#85">85</a>				<b>new</b> <a href="/source/s?defs=IoFutureListener&amp;project=rtmp_client">IoFutureListener</a>() {
<a class="l" name="86" href="#86">86</a>					<b>public</b> <b>void</b> <a href="/source/s?defs=operationComplete&amp;project=rtmp_client">operationComplete</a>(<a href="/source/s?defs=IoFuture&amp;project=rtmp_client">IoFuture</a> <a class="d" href="#future">future</a>) {
<a class="l" name="87" href="#87">87</a>						<b>try</b> {
<a class="l" name="88" href="#88">88</a>							<span class="c">// will throw RuntimeException after connection error</span>
<a class="l" name="89" href="#89">89</a>							<a class="d" href="#future">future</a>.<a href="/source/s?defs=getSession&amp;project=rtmp_client">getSession</a>();
<a class="hl" name="90" href="#90">90</a>						} <b>catch</b> (<a href="/source/s?defs=Throwable&amp;project=rtmp_client">Throwable</a> e) {
<a class="l" name="91" href="#91">91</a>							<span class="c">//if there isn't an ClientExceptionHandler set, a</span>
<a class="l" name="92" href="#92">92</a>							<span class="c">//RuntimeException may be thrown in handleException</span>
<a class="l" name="93" href="#93">93</a>							<a href="/source/s?defs=handleException&amp;project=rtmp_client">handleException</a>(e);
<a class="l" name="94" href="#94">94</a>						}
<a class="l" name="95" href="#95">95</a>					}
<a class="l" name="96" href="#96">96</a>				}
<a class="l" name="97" href="#97">97</a>		);
<a class="l" name="98" href="#98">98</a>	    <span class="c">// Now wait for the close to be completed</span>
<a class="l" name="99" href="#99">99</a>		<a class="d" href="#future">future</a>.<a href="/source/s?defs=awaitUninterruptibly&amp;project=rtmp_client">awaitUninterruptibly</a>(<a class="d" href="#CONNECTOR_WORKER_TIMEOUT">CONNECTOR_WORKER_TIMEOUT</a>);
<a class="hl" name="100" href="#100">100</a>	}
<a class="l" name="101" href="#101">101</a>
<a class="l" name="102" href="#102">102</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="103" href="#103">103</a>	<b>public</b> <b>void</b> <a class="xmt" name="disconnect"/><a href="/source/s?refs=disconnect&amp;project=rtmp_client" class="xmt">disconnect</a>() {
<a class="l" name="104" href="#104">104</a>	    <span class="c">// Do the close requesting that the pending messages are sent before</span>
<a class="l" name="105" href="#105">105</a>	    <span class="c">// the session is closed</span>
<a class="l" name="106" href="#106">106</a>		<a class="d" href="#future">future</a>.<a href="/source/s?defs=getSession&amp;project=rtmp_client">getSession</a>().<a href="/source/s?defs=close&amp;project=rtmp_client">close</a>(<b>false</b>);
<a class="l" name="107" href="#107">107</a>	    <span class="c">// Now wait for the close to be completed</span>
<a class="l" name="108" href="#108">108</a>		<a class="d" href="#future">future</a>.<a href="/source/s?defs=awaitUninterruptibly&amp;project=rtmp_client">awaitUninterruptibly</a>(<a class="d" href="#CONNECTOR_WORKER_TIMEOUT">CONNECTOR_WORKER_TIMEOUT</a>);
<a class="l" name="109" href="#109">109</a>	    <span class="c">// We can now dispose the connector</span>
<a class="hl" name="110" href="#110">110</a>		<a class="d" href="#socketConnector">socketConnector</a>.<a href="/source/s?defs=dispose&amp;project=rtmp_client">dispose</a>();
<a class="l" name="111" href="#111">111</a>		<b>super</b>.<a class="d" href="#disconnect">disconnect</a>();
<a class="l" name="112" href="#112">112</a>	}
<a class="l" name="113" href="#113">113</a>}
<a class="l" name="114" href="#114">114</a>