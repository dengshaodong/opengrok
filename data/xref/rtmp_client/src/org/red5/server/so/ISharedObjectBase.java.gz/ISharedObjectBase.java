<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.red5.server.so",1]]],["Interface","xi",[["ISharedObjectBase",51]]],["Method","xmt",[["addSharedObjectListener",111],["beginUpdate",91],["beginUpdate",98],["clear",145],["close",152],["endUpdate",104],["getData",76],["getVersion",60],["isLocked",137],["isPersistentObject",68],["lock",124],["removeSharedObjectListener",118],["sendMessage",85],["unlock",130]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=so&amp;project=rtmp_client">so</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=ICastingAttributeStore&amp;project=rtmp_client">ICastingAttributeStore</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=IEventListener&amp;project=rtmp_client">IEventListener</a>;
<a class="l" name="27" href="#27">27</a>
<a class="l" name="28" href="#28">28</a><span class="c">/**
<a class="l" name="29" href="#29">29</a> * Base interface for shared objects. Changes to the shared objects are
<a class="hl" name="30" href="#30">30</a> * propagated to all subscribed clients.
<a class="l" name="31" href="#31">31</a> *
<a class="l" name="32" href="#32">32</a> * If you want to modify multiple attributes and notify the clients about all
<a class="l" name="33" href="#33">33</a> * changes at once, you can use code like this:
<a class="l" name="34" href="#34">34</a> * &lt;p&gt;
<a class="l" name="35" href="#35">35</a> * &lt;code&gt;
<a class="l" name="36" href="#36">36</a> * SharedObject.beginUpdate();&lt;br /&gt;
<a class="l" name="37" href="#37">37</a> * SharedObject.setAttribute("One", '1');&lt;br /&gt;
<a class="l" name="38" href="#38">38</a> * SharedObject.setAttribute("Two", '2');&lt;br /&gt;
<a class="l" name="39" href="#39">39</a> * SharedObject.removeAttribute("Three");&lt;br /&gt;
<a class="hl" name="40" href="#40">40</a> * SharedObject.endUpdate();&lt;br /&gt;
<a class="l" name="41" href="#41">41</a> * &lt;/code&gt;
<a class="l" name="42" href="#42">42</a> * &lt;/p&gt;
<a class="l" name="43" href="#43">43</a> *
<a class="l" name="44" href="#44">44</a> * All changes between "beginUpdate" and "endUpdate" will be sent to the clients
<a class="l" name="45" href="#45">45</a> * using one notification event.
<a class="l" name="46" href="#46">46</a> *
<a class="l" name="47" href="#47">47</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="48" href="#48">48</a> * <strong>@author</strong> Joachim Bauch (jojo@struktur.de)
<a class="l" name="49" href="#49">49</a> */</span>
<a class="hl" name="50" href="#50">50</a>
<a class="l" name="51" href="#51">51</a><b>public</b> <b>interface</b> <a class="xi" name="ISharedObjectBase"/><a href="/source/s?refs=ISharedObjectBase&amp;project=rtmp_client" class="xi">ISharedObjectBase</a> <b>extends</b> <a href="/source/s?defs=ISharedObjectHandlerProvider&amp;project=rtmp_client">ISharedObjectHandlerProvider</a>,
<a class="l" name="52" href="#52">52</a>		<a href="/source/s?defs=ICastingAttributeStore&amp;project=rtmp_client">ICastingAttributeStore</a> {
<a class="l" name="53" href="#53">53</a>
<a class="l" name="54" href="#54">54</a>	<span class="c">/**
<a class="l" name="55" href="#55">55</a>	 * Returns the version of the shared object. The version is incremented
<a class="l" name="56" href="#56">56</a>	 * automatically on each modification.
<a class="l" name="57" href="#57">57</a>	 *
<a class="l" name="58" href="#58">58</a>	 * <strong>@return</strong> the version of the shared object
<a class="l" name="59" href="#59">59</a>	 */</span>
<a class="hl" name="60" href="#60">60</a>	<b>public</b> <b>int</b> <a class="xmt" name="getVersion"/><a href="/source/s?refs=getVersion&amp;project=rtmp_client" class="xmt">getVersion</a>();
<a class="l" name="61" href="#61">61</a>
<a class="l" name="62" href="#62">62</a>	<span class="c">/**
<a class="l" name="63" href="#63">63</a>	 * Check if the object has been created as persistent shared object by the
<a class="l" name="64" href="#64">64</a>	 * client.
<a class="l" name="65" href="#65">65</a>	 *
<a class="l" name="66" href="#66">66</a>	 * <strong>@return</strong> true if the shared object is persistent, false otherwise
<a class="l" name="67" href="#67">67</a>	 */</span>
<a class="l" name="68" href="#68">68</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="isPersistentObject"/><a href="/source/s?refs=isPersistentObject&amp;project=rtmp_client" class="xmt">isPersistentObject</a>();
<a class="l" name="69" href="#69">69</a>
<a class="hl" name="70" href="#70">70</a>	<span class="c">/**
<a class="l" name="71" href="#71">71</a>	 * Return a map containing all attributes of the shared object. &lt;br /&gt;
<a class="l" name="72" href="#72">72</a>	 * NOTE: The returned map will be read-only.
<a class="l" name="73" href="#73">73</a>	 *
<a class="l" name="74" href="#74">74</a>	 * <strong>@return</strong> a map containing all attributes of the shared object
<a class="l" name="75" href="#75">75</a>	 */</span>
<a class="l" name="76" href="#76">76</a>	<b>public</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xmt" name="getData"/><a href="/source/s?refs=getData&amp;project=rtmp_client" class="xmt">getData</a>();
<a class="l" name="77" href="#77">77</a>
<a class="l" name="78" href="#78">78</a>	<span class="c">/**
<a class="l" name="79" href="#79">79</a>	 * Send a message to a handler of the shared object.
<a class="hl" name="80" href="#80">80</a>	 *
<a class="l" name="81" href="#81">81</a>	 * <strong>@param</strong> <em>handler</em> the name of the handler to call
<a class="l" name="82" href="#82">82</a>	 * <strong>@param</strong> <em>arguments</em> a list of objects that should be passed as arguments to the
<a class="l" name="83" href="#83">83</a>	 *            handler
<a class="l" name="84" href="#84">84</a>	 */</span>
<a class="l" name="85" href="#85">85</a>	<b>public</b> <b>void</b> <a class="xmt" name="sendMessage"/><a href="/source/s?refs=sendMessage&amp;project=rtmp_client" class="xmt">sendMessage</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="handler"/><a href="/source/s?refs=handler&amp;project=rtmp_client" class="xa">handler</a>, <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;?&gt; <a class="xa" name="arguments"/><a href="/source/s?refs=arguments&amp;project=rtmp_client" class="xa">arguments</a>);
<a class="l" name="86" href="#86">86</a>
<a class="l" name="87" href="#87">87</a>	<span class="c">/**
<a class="l" name="88" href="#88">88</a>	 * Start performing multiple updates to the shared object from serverside
<a class="l" name="89" href="#89">89</a>	 * code.
<a class="hl" name="90" href="#90">90</a>	 */</span>
<a class="l" name="91" href="#91">91</a>	<b>public</b> <b>void</b> <a class="xmt" name="beginUpdate"/><a href="/source/s?refs=beginUpdate&amp;project=rtmp_client" class="xmt">beginUpdate</a>();
<a class="l" name="92" href="#92">92</a>
<a class="l" name="93" href="#93">93</a>	<span class="c">/**
<a class="l" name="94" href="#94">94</a>	 * Start performing multiple updates to the shared object from a connected
<a class="l" name="95" href="#95">95</a>	 * client.
<a class="l" name="96" href="#96">96</a>     * <strong>@param</strong> <em>source</em>      Update events listener
<a class="l" name="97" href="#97">97</a>     */</span>
<a class="l" name="98" href="#98">98</a>	<b>public</b> <b>void</b> <a class="xmt" name="beginUpdate"/><a href="/source/s?refs=beginUpdate&amp;project=rtmp_client" class="xmt">beginUpdate</a>(<a href="/source/s?defs=IEventListener&amp;project=rtmp_client">IEventListener</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>);
<a class="l" name="99" href="#99">99</a>
<a class="hl" name="100" href="#100">100</a>	<span class="c">/**
<a class="l" name="101" href="#101">101</a>	 * The multiple updates are complete, notify clients about all changes at
<a class="l" name="102" href="#102">102</a>	 * once.
<a class="l" name="103" href="#103">103</a>	 */</span>
<a class="l" name="104" href="#104">104</a>	<b>public</b> <b>void</b> <a class="xmt" name="endUpdate"/><a href="/source/s?refs=endUpdate&amp;project=rtmp_client" class="xmt">endUpdate</a>();
<a class="l" name="105" href="#105">105</a>
<a class="l" name="106" href="#106">106</a>	<span class="c">/**
<a class="l" name="107" href="#107">107</a>	 * Register object that will be notified about update events.
<a class="l" name="108" href="#108">108</a>	 *
<a class="l" name="109" href="#109">109</a>	 * <strong>@param</strong> <em>listener</em> the object to notify
<a class="hl" name="110" href="#110">110</a>	 */</span>
<a class="l" name="111" href="#111">111</a>	<b>public</b> <b>void</b> <a class="xmt" name="addSharedObjectListener"/><a href="/source/s?refs=addSharedObjectListener&amp;project=rtmp_client" class="xmt">addSharedObjectListener</a>(<a href="/source/s?defs=ISharedObjectListener&amp;project=rtmp_client">ISharedObjectListener</a> <a class="xa" name="listener"/><a href="/source/s?refs=listener&amp;project=rtmp_client" class="xa">listener</a>);
<a class="l" name="112" href="#112">112</a>
<a class="l" name="113" href="#113">113</a>	<span class="c">/**
<a class="l" name="114" href="#114">114</a>	 * Unregister object to not longer receive update events.
<a class="l" name="115" href="#115">115</a>	 *
<a class="l" name="116" href="#116">116</a>	 * <strong>@param</strong> <em>listener</em> the object to unregister
<a class="l" name="117" href="#117">117</a>	 */</span>
<a class="l" name="118" href="#118">118</a>	<b>public</b> <b>void</b> <a class="xmt" name="removeSharedObjectListener"/><a href="/source/s?refs=removeSharedObjectListener&amp;project=rtmp_client" class="xmt">removeSharedObjectListener</a>(<a href="/source/s?defs=ISharedObjectListener&amp;project=rtmp_client">ISharedObjectListener</a> <a class="xa" name="listener"/><a href="/source/s?refs=listener&amp;project=rtmp_client" class="xa">listener</a>);
<a class="l" name="119" href="#119">119</a>
<a class="hl" name="120" href="#120">120</a>	<span class="c">/**
<a class="l" name="121" href="#121">121</a>	 * Locks the shared object instance. Prevents any changes to this object by
<a class="l" name="122" href="#122">122</a>	 * clients until the SharedObject.unlock() method is called.
<a class="l" name="123" href="#123">123</a>	 */</span>
<a class="l" name="124" href="#124">124</a>	<b>public</b> <b>void</b> <a class="xmt" name="lock"/><a href="/source/s?refs=lock&amp;project=rtmp_client" class="xmt">lock</a>();
<a class="l" name="125" href="#125">125</a>
<a class="l" name="126" href="#126">126</a>	<span class="c">/**
<a class="l" name="127" href="#127">127</a>	 * Unlocks a shared object instance that was locked with
<a class="l" name="128" href="#128">128</a>	 * SharedObject.lock().
<a class="l" name="129" href="#129">129</a>	 */</span>
<a class="hl" name="130" href="#130">130</a>	<b>public</b> <b>void</b> <a class="xmt" name="unlock"/><a href="/source/s?refs=unlock&amp;project=rtmp_client" class="xmt">unlock</a>();
<a class="l" name="131" href="#131">131</a>
<a class="l" name="132" href="#132">132</a>	<span class="c">/**
<a class="l" name="133" href="#133">133</a>	 * Returns the locked state of this SharedObject.
<a class="l" name="134" href="#134">134</a>	 *
<a class="l" name="135" href="#135">135</a>	 * <strong>@return</strong> true if in a locked state; false otherwise
<a class="l" name="136" href="#136">136</a>	 */</span>
<a class="l" name="137" href="#137">137</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="isLocked"/><a href="/source/s?refs=isLocked&amp;project=rtmp_client" class="xmt">isLocked</a>();
<a class="l" name="138" href="#138">138</a>
<a class="l" name="139" href="#139">139</a>	<span class="c">/**
<a class="hl" name="140" href="#140">140</a>	 * Deletes all the attributes and sends a clear event to all listeners. The
<a class="l" name="141" href="#141">141</a>	 * persistent data object is also removed from a persistent shared object.
<a class="l" name="142" href="#142">142</a>	 *
<a class="l" name="143" href="#143">143</a>	 * <strong>@return</strong> true if successful; false otherwise
<a class="l" name="144" href="#144">144</a>	 */</span>
<a class="l" name="145" href="#145">145</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="clear"/><a href="/source/s?refs=clear&amp;project=rtmp_client" class="xmt">clear</a>();
<a class="l" name="146" href="#146">146</a>
<a class="l" name="147" href="#147">147</a>	<span class="c">/**
<a class="l" name="148" href="#148">148</a>	 * Detaches a reference from this shared object, this will destroy the
<a class="l" name="149" href="#149">149</a>	 * reference immediately. This is useful when you don't want to proxy a
<a class="hl" name="150" href="#150">150</a>	 * shared object any longer.
<a class="l" name="151" href="#151">151</a>	 */</span>
<a class="l" name="152" href="#152">152</a>	<b>public</b> <b>void</b> <a class="xmt" name="close"/><a href="/source/s?refs=close&amp;project=rtmp_client" class="xmt">close</a>();
<a class="l" name="153" href="#153">153</a>
<a class="l" name="154" href="#154">154</a>}
<a class="l" name="155" href="#155">155</a>