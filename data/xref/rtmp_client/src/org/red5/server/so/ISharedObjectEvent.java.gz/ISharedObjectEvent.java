<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.red5.server.so",1]]],["Interface","xi",[["ISharedObjectEvent",25]]],["Enum","xe",[["CLIENT_CLEAR_DATA",29],["CLIENT_DELETE_ATTRIBUTE",29],["CLIENT_DELETE_DATA",29],["CLIENT_INITIAL_DATA",30],["CLIENT_SEND_MESSAGE",31],["CLIENT_STATUS",30],["CLIENT_UPDATE_ATTRIBUTE",30],["CLIENT_UPDATE_DATA",30],["SERVER_CONNECT",28],["SERVER_DELETE_ATTRIBUTE",28],["SERVER_DISCONNECT",28],["SERVER_SEND_MESSAGE",29],["SERVER_SET_ATTRIBUTE",28],["Type",27]]],["Method","xmt",[["getKey",54],["getType",39],["getValue",68]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=so&amp;project=rtmp_client">so</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><span class="c">/**
<a class="l" name="23" href="#23">23</a> * One update event for a shared object received through a connection.
<a class="l" name="24" href="#24">24</a> */</span>
<a class="l" name="25" href="#25">25</a><b>public</b> <b>interface</b> <a class="xi" name="ISharedObjectEvent"/><a href="/source/s?refs=ISharedObjectEvent&amp;project=rtmp_client" class="xi">ISharedObjectEvent</a> {
<a class="l" name="26" href="#26">26</a>
<a class="l" name="27" href="#27">27</a>	<b>enum</b> <a class="xe" name="Type"/><a href="/source/s?refs=Type&amp;project=rtmp_client" class="xe">Type</a> {
<a class="l" name="28" href="#28">28</a>		<a class="xe" name="SERVER_CONNECT"/><a href="/source/s?refs=SERVER_CONNECT&amp;project=rtmp_client" class="xe">SERVER_CONNECT</a>, <a class="xe" name="SERVER_DISCONNECT"/><a href="/source/s?refs=SERVER_DISCONNECT&amp;project=rtmp_client" class="xe">SERVER_DISCONNECT</a>, <a class="xe" name="SERVER_SET_ATTRIBUTE"/><a href="/source/s?refs=SERVER_SET_ATTRIBUTE&amp;project=rtmp_client" class="xe">SERVER_SET_ATTRIBUTE</a>, <a class="xe" name="SERVER_DELETE_ATTRIBUTE"/><a href="/source/s?refs=SERVER_DELETE_ATTRIBUTE&amp;project=rtmp_client" class="xe">SERVER_DELETE_ATTRIBUTE</a>,
<a class="l" name="29" href="#29">29</a>		<a class="xe" name="SERVER_SEND_MESSAGE"/><a href="/source/s?refs=SERVER_SEND_MESSAGE&amp;project=rtmp_client" class="xe">SERVER_SEND_MESSAGE</a>, <a class="xe" name="CLIENT_CLEAR_DATA"/><a href="/source/s?refs=CLIENT_CLEAR_DATA&amp;project=rtmp_client" class="xe">CLIENT_CLEAR_DATA</a>, <a class="xe" name="CLIENT_DELETE_ATTRIBUTE"/><a href="/source/s?refs=CLIENT_DELETE_ATTRIBUTE&amp;project=rtmp_client" class="xe">CLIENT_DELETE_ATTRIBUTE</a>, <a class="xe" name="CLIENT_DELETE_DATA"/><a href="/source/s?refs=CLIENT_DELETE_DATA&amp;project=rtmp_client" class="xe">CLIENT_DELETE_DATA</a>,
<a class="hl" name="30" href="#30">30</a>		<a class="xe" name="CLIENT_INITIAL_DATA"/><a href="/source/s?refs=CLIENT_INITIAL_DATA&amp;project=rtmp_client" class="xe">CLIENT_INITIAL_DATA</a>, <a class="xe" name="CLIENT_STATUS"/><a href="/source/s?refs=CLIENT_STATUS&amp;project=rtmp_client" class="xe">CLIENT_STATUS</a>, <a class="xe" name="CLIENT_UPDATE_DATA"/><a href="/source/s?refs=CLIENT_UPDATE_DATA&amp;project=rtmp_client" class="xe">CLIENT_UPDATE_DATA</a>, <a class="xe" name="CLIENT_UPDATE_ATTRIBUTE"/><a href="/source/s?refs=CLIENT_UPDATE_ATTRIBUTE&amp;project=rtmp_client" class="xe">CLIENT_UPDATE_ATTRIBUTE</a>,
<a class="l" name="31" href="#31">31</a>		<a class="xe" name="CLIENT_SEND_MESSAGE"/><a href="/source/s?refs=CLIENT_SEND_MESSAGE&amp;project=rtmp_client" class="xe">CLIENT_SEND_MESSAGE</a>
<a class="l" name="32" href="#32">32</a>	};
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a>	<span class="c">/**
<a class="l" name="35" href="#35">35</a>	 * Returns the type of the event.
<a class="l" name="36" href="#36">36</a>	 *
<a class="l" name="37" href="#37">37</a>	 * <strong>@return</strong> the type of the event.
<a class="l" name="38" href="#38">38</a>	 */</span>
<a class="l" name="39" href="#39">39</a>	<b>public</b> <a class="d" href="#Type">Type</a> <a class="xmt" name="getType"/><a href="/source/s?refs=getType&amp;project=rtmp_client" class="xmt">getType</a>();
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a>	<span class="c">/**
<a class="l" name="42" href="#42">42</a>	 * Returns the key of the event.
<a class="l" name="43" href="#43">43</a>	 *
<a class="l" name="44" href="#44">44</a>	 * Depending on the type this contains:
<a class="l" name="45" href="#45">45</a>	 * &lt;ul&gt;
<a class="l" name="46" href="#46">46</a>	 * &lt;li&gt;the attribute name to set for SET_ATTRIBUTE&lt;/li&gt;
<a class="l" name="47" href="#47">47</a>	 * &lt;li&gt;the attribute name to delete for DELETE_ATTRIBUTE&lt;/li&gt;
<a class="l" name="48" href="#48">48</a>	 * &lt;li&gt;the handler name to call for SEND_MESSAGE&lt;/li&gt;
<a class="l" name="49" href="#49">49</a>	 * &lt;/ul&gt;
<a class="hl" name="50" href="#50">50</a>	 * In all other cases the key is &lt;code&gt;null&lt;/code&gt;.
<a class="l" name="51" href="#51">51</a>	 *
<a class="l" name="52" href="#52">52</a>	 * <strong>@return</strong> the key of the event
<a class="l" name="53" href="#53">53</a>	 */</span>
<a class="l" name="54" href="#54">54</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getKey"/><a href="/source/s?refs=getKey&amp;project=rtmp_client" class="xmt">getKey</a>();
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a>	<span class="c">/**
<a class="l" name="57" href="#57">57</a>	 * Returns the value of the event.
<a class="l" name="58" href="#58">58</a>	 *
<a class="l" name="59" href="#59">59</a>	 * Depending on the type this contains:
<a class="hl" name="60" href="#60">60</a>	 * &lt;ul&gt;
<a class="l" name="61" href="#61">61</a>	 * &lt;li&gt;the attribute value to set for SET_ATTRIBUTE&lt;/li&gt;
<a class="l" name="62" href="#62">62</a>	 * &lt;li&gt;a list of parameters to pass to the handler for SEND_MESSAGE&lt;/li&gt;
<a class="l" name="63" href="#63">63</a>	 * &lt;/ul&gt;
<a class="l" name="64" href="#64">64</a>	 * In all other cases the value is &lt;code&gt;null&lt;/code&gt;.
<a class="l" name="65" href="#65">65</a>	 *
<a class="l" name="66" href="#66">66</a>	 * <strong>@return</strong> the value of the event
<a class="l" name="67" href="#67">67</a>	 */</span>
<a class="l" name="68" href="#68">68</a>	<b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="getValue"/><a href="/source/s?refs=getValue&amp;project=rtmp_client" class="xmt">getValue</a>();
<a class="l" name="69" href="#69">69</a>}
<a class="hl" name="70" href="#70">70</a>