<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["SharedObject",70]]],["Package","xp",[["org.red5.server.so",1]]],["Method","xmt",[["SharedObject",178],["SharedObject",193],["SharedObject",206],["SharedObject",226],["acquire",740],["beginUpdate",637],["beginUpdate",645],["checkRelease",601],["clear",697],["close",712],["deserialize",672],["endUpdate",655],["getActiveListeners",785],["getAttribute",419],["getCreationTime",768],["getData",536],["getLastModified",259],["getListeners",629],["getMaxListeners",779],["getName",233],["getPath",243],["getStore",687],["getTotalChanges",791],["getTotalDeletes",796],["getTotalListeners",773],["getTotalSends",801],["getType",253],["getVersion",545],["isAcquired",749],["isPersistent",273],["isPersistentObject",268],["notifyModified",374],["register",580],["release",758],["removeAttribute",504],["removeAttributes",560],["returnAttributeValue",408],["returnError",399],["sendMessage",524],["sendUpdates",285],["serialize",664],["setAttribute",445],["setAttributes",471],["setAttributes",491],["setName",238],["setPath",248],["setPersistent",278],["setStore",682],["unregister",618],["updateVersion",552]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=so&amp;project=rtmp_client">so</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><span class="c">//import static org.red5.server.api.so.ISharedObject.TYPE;</span>
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=concurrent&amp;project=rtmp_client">concurrent</a>.<a href="/source/s?defs=ConcurrentLinkedQueue&amp;project=rtmp_client">ConcurrentLinkedQueue</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=concurrent&amp;project=rtmp_client">concurrent</a>.<a href="/source/s?defs=CopyOnWriteArraySet&amp;project=rtmp_client">CopyOnWriteArraySet</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=concurrent&amp;project=rtmp_client">concurrent</a>.<a href="/source/s?defs=ExecutorService&amp;project=rtmp_client">ExecutorService</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=concurrent&amp;project=rtmp_client">concurrent</a>.<a href="/source/s?defs=Executors&amp;project=rtmp_client">Executors</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=concurrent&amp;project=rtmp_client">concurrent</a>.<a href="/source/s?defs=TimeUnit&amp;project=rtmp_client">TimeUnit</a>;
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=concurrent&amp;project=rtmp_client">concurrent</a>.<a href="/source/s?defs=atomic&amp;project=rtmp_client">atomic</a>.<a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a>;
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a>;
<a class="l" name="36" href="#36">36</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a>;
<a class="l" name="37" href="#37">37</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a>;
<a class="l" name="38" href="#38">38</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=object&amp;project=rtmp_client">object</a>.<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>;
<a class="l" name="39" href="#39">39</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=AttributeStore&amp;project=rtmp_client">AttributeStore</a>;
<a class="hl" name="40" href="#40">40</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=IAttributeStore&amp;project=rtmp_client">IAttributeStore</a>;
<a class="l" name="41" href="#41">41</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=IEventListener&amp;project=rtmp_client">IEventListener</a>;
<a class="l" name="42" href="#42">42</a><span class="c">//import org.red5.server.api.statistics.ISharedObjectStatistics;</span>
<a class="l" name="43" href="#43">43</a><span class="c">//import org.red5.server.api.statistics.support.StatisticsCounter;</span>
<a class="l" name="44" href="#44">44</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a>;
<a class="l" name="45" href="#45">45</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>;
<a class="l" name="46" href="#46">46</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a class="d" href="#message">message</a>.<a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a>;
<a class="l" name="47" href="#47">47</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=so&amp;project=rtmp_client">so</a>.<a href="/source/s?defs=ISharedObjectEvent&amp;project=rtmp_client">ISharedObjectEvent</a>.<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>;
<a class="l" name="48" href="#48">48</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="49" href="#49">49</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="hl" name="50" href="#50">50</a>
<a class="l" name="51" href="#51">51</a><span class="c">/**
<a class="l" name="52" href="#52">52</a> * Represents shared object on server-side. Shared Objects in Flash are like cookies that are stored
<a class="l" name="53" href="#53">53</a> * on client side. In Red5 and Flash Media Server there's one more special type of SOs : remote Shared Objects.
<a class="l" name="54" href="#54">54</a> *
<a class="l" name="55" href="#55">55</a> * These are shared by multiple clients and synchronized between them automatically on each data change. This is done
<a class="l" name="56" href="#56">56</a> * asynchronously, used as events handling and is widely used in multiplayer Flash online games.
<a class="l" name="57" href="#57">57</a> *
<a class="l" name="58" href="#58">58</a> * Shared object can be persistent or transient. The difference is that first are saved to the disk and can be
<a class="l" name="59" href="#59">59</a> * accessed later on next connection, transient objects are not saved and get lost each time they last client
<a class="hl" name="60" href="#60">60</a> * disconnects from it.
<a class="l" name="61" href="#61">61</a> *
<a class="l" name="62" href="#62">62</a> * Shared Objects has name identifiers and path on server's HD (if persistent). On deeper level server-side
<a class="l" name="63" href="#63">63</a> * Shared Object in this implementation actually uses IPersistenceStore to delegate all (de)serialization work.
<a class="l" name="64" href="#64">64</a> *
<a class="l" name="65" href="#65">65</a> * SOs store data as simple map, that is, "name-value" pairs. Each value in turn can be complex object or map.
<a class="l" name="66" href="#66">66</a> *
<a class="l" name="67" href="#67">67</a> * All access to methods that change properties in the SO must be properly
<a class="l" name="68" href="#68">68</a> * synchronized for multi-threaded access.
<a class="l" name="69" href="#69">69</a> */</span>
<a class="hl" name="70" href="#70">70</a><b>public</b> <b>class</b> <a class="xc" name="SharedObject"/><a href="/source/s?refs=SharedObject&amp;project=rtmp_client" class="xc">SharedObject</a> <b>extends</b> <a href="/source/s?defs=AttributeStore&amp;project=rtmp_client">AttributeStore</a> <b>implements</b>  <a href="/source/s?defs=IPersistable&amp;project=rtmp_client">IPersistable</a>, <a href="/source/s?defs=Constants&amp;project=rtmp_client">Constants</a> {
<a class="l" name="71" href="#71">71</a>	<span class="c">/**
<a class="l" name="72" href="#72">72</a>	 * Logger
<a class="l" name="73" href="#73">73</a>	 */</span>
<a class="l" name="74" href="#74">74</a>	<b>protected</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a href="/source/s?defs=SharedObject&amp;project=rtmp_client">SharedObject</a>.<b>class</b>);
<a class="l" name="75" href="#75">75</a>
<a class="l" name="76" href="#76">76</a>	<span class="c">/**
<a class="l" name="77" href="#77">77</a>	 * Shared Object name (identifier)
<a class="l" name="78" href="#78">78</a>	 */</span>
<a class="l" name="79" href="#79">79</a>	<b>protected</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xfld">name</a> = <span class="s">""</span>;
<a class="hl" name="80" href="#80">80</a>
<a class="l" name="81" href="#81">81</a>	<span class="c">/**
<a class="l" name="82" href="#82">82</a>	 * SO path
<a class="l" name="83" href="#83">83</a>	 */</span>
<a class="l" name="84" href="#84">84</a>	<b>protected</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="path"/><a href="/source/s?refs=path&amp;project=rtmp_client" class="xfld">path</a> = <span class="s">""</span>;
<a class="l" name="85" href="#85">85</a>
<a class="l" name="86" href="#86">86</a>	<span class="c">/**
<a class="l" name="87" href="#87">87</a>	 * true if the SharedObject was stored by the persistence framework (NOT in database,
<a class="l" name="88" href="#88">88</a>	 * just plain serialization to the disk) and can be used later on reconnection
<a class="l" name="89" href="#89">89</a>	 */</span>
<a class="hl" name="90" href="#90">90</a>	<b>protected</b> <b>boolean</b> <a class="xfld" name="persistent"/><a href="/source/s?refs=persistent&amp;project=rtmp_client" class="xfld">persistent</a>;
<a class="l" name="91" href="#91">91</a>
<a class="l" name="92" href="#92">92</a>	<span class="c">/**
<a class="l" name="93" href="#93">93</a>	 * true if the client / server created the SO to be persistent
<a class="l" name="94" href="#94">94</a>	 */</span>
<a class="l" name="95" href="#95">95</a>	<b>protected</b> <b>boolean</b> <a class="xfld" name="persistentSO"/><a href="/source/s?refs=persistentSO&amp;project=rtmp_client" class="xfld">persistentSO</a>;
<a class="l" name="96" href="#96">96</a>
<a class="l" name="97" href="#97">97</a>	<span class="c">/**
<a class="l" name="98" href="#98">98</a>	 * Object that is delegated with all storage work for persistent SOs
<a class="l" name="99" href="#99">99</a>	 */</span>
<a class="hl" name="100" href="#100">100</a>	<b>protected</b> <a href="/source/s?defs=IPersistenceStore&amp;project=rtmp_client">IPersistenceStore</a> <a class="xfld" name="storage"/><a href="/source/s?refs=storage&amp;project=rtmp_client" class="xfld">storage</a>;
<a class="l" name="101" href="#101">101</a>
<a class="l" name="102" href="#102">102</a>	<span class="c">/**
<a class="l" name="103" href="#103">103</a>	 * Version. Used on synchronization purposes.
<a class="l" name="104" href="#104">104</a>	 */</span>
<a class="l" name="105" href="#105">105</a>	<b>protected</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a> <a class="xfld" name="version"/><a href="/source/s?refs=version&amp;project=rtmp_client" class="xfld">version</a> = <b>new</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a>(<span class="n">1</span>);
<a class="l" name="106" href="#106">106</a>
<a class="l" name="107" href="#107">107</a>	<span class="c">/**
<a class="l" name="108" href="#108">108</a>	 * Number of pending update operations
<a class="l" name="109" href="#109">109</a>	 */</span>
<a class="hl" name="110" href="#110">110</a>	<b>protected</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a> <a class="xfld" name="updateCounter"/><a href="/source/s?refs=updateCounter&amp;project=rtmp_client" class="xfld">updateCounter</a> = <b>new</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a>();
<a class="l" name="111" href="#111">111</a>
<a class="l" name="112" href="#112">112</a>	<span class="c">/**
<a class="l" name="113" href="#113">113</a>	 * Has changes? flag
<a class="l" name="114" href="#114">114</a>	 */</span>
<a class="l" name="115" href="#115">115</a>	<b>protected</b> <b>boolean</b> <a class="xfld" name="modified"/><a href="/source/s?refs=modified&amp;project=rtmp_client" class="xfld">modified</a>;
<a class="l" name="116" href="#116">116</a>
<a class="l" name="117" href="#117">117</a>	<span class="c">/**
<a class="l" name="118" href="#118">118</a>	 * Last modified timestamp
<a class="l" name="119" href="#119">119</a>	 */</span>
<a class="hl" name="120" href="#120">120</a>	<b>protected</b> <b>long</b> <a class="xfld" name="lastModified"/><a href="/source/s?refs=lastModified&amp;project=rtmp_client" class="xfld">lastModified</a> = -<span class="n">1</span>;
<a class="l" name="121" href="#121">121</a>
<a class="l" name="122" href="#122">122</a>	<span class="c">/**
<a class="l" name="123" href="#123">123</a>	 * Owner event
<a class="l" name="124" href="#124">124</a>	 */</span>
<a class="l" name="125" href="#125">125</a>	<b>protected</b> <a href="/source/s?defs=SharedObjectMessage&amp;project=rtmp_client">SharedObjectMessage</a> <a class="xfld" name="ownerMessage"/><a href="/source/s?refs=ownerMessage&amp;project=rtmp_client" class="xfld">ownerMessage</a>;
<a class="l" name="126" href="#126">126</a>
<a class="l" name="127" href="#127">127</a>	<span class="c">/**
<a class="l" name="128" href="#128">128</a>	 * Synchronization events
<a class="l" name="129" href="#129">129</a>	 */</span>
<a class="hl" name="130" href="#130">130</a>	<b>protected</b> <a href="/source/s?defs=ConcurrentLinkedQueue&amp;project=rtmp_client">ConcurrentLinkedQueue</a>&lt;<a href="/source/s?defs=ISharedObjectEvent&amp;project=rtmp_client">ISharedObjectEvent</a>&gt; <a class="xfld" name="syncEvents"/><a href="/source/s?refs=syncEvents&amp;project=rtmp_client" class="xfld">syncEvents</a> = <b>new</b> <a href="/source/s?defs=ConcurrentLinkedQueue&amp;project=rtmp_client">ConcurrentLinkedQueue</a>&lt;<a href="/source/s?defs=ISharedObjectEvent&amp;project=rtmp_client">ISharedObjectEvent</a>&gt;();
<a class="l" name="131" href="#131">131</a>
<a class="l" name="132" href="#132">132</a>	<span class="c">/**
<a class="l" name="133" href="#133">133</a>	 * Listeners
<a class="l" name="134" href="#134">134</a>	 */</span>
<a class="l" name="135" href="#135">135</a>	<b>protected</b> <a href="/source/s?defs=CopyOnWriteArraySet&amp;project=rtmp_client">CopyOnWriteArraySet</a>&lt;<a href="/source/s?defs=IEventListener&amp;project=rtmp_client">IEventListener</a>&gt; <a class="xfld" name="listeners"/><a href="/source/s?refs=listeners&amp;project=rtmp_client" class="xfld">listeners</a> = <b>new</b> <a href="/source/s?defs=CopyOnWriteArraySet&amp;project=rtmp_client">CopyOnWriteArraySet</a>&lt;<a href="/source/s?defs=IEventListener&amp;project=rtmp_client">IEventListener</a>&gt;();
<a class="l" name="136" href="#136">136</a>
<a class="l" name="137" href="#137">137</a>	<span class="c">/**
<a class="l" name="138" href="#138">138</a>	 * Event listener, actually RTMP connection
<a class="l" name="139" href="#139">139</a>	 */</span>
<a class="hl" name="140" href="#140">140</a>	<b>protected</b> <a href="/source/s?defs=IEventListener&amp;project=rtmp_client">IEventListener</a> <a class="xfld" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xfld">source</a>;
<a class="l" name="141" href="#141">141</a>
<a class="l" name="142" href="#142">142</a>	<span class="c">/**
<a class="l" name="143" href="#143">143</a>	 * Number of times the SO has been acquired
<a class="l" name="144" href="#144">144</a>	 */</span>
<a class="l" name="145" href="#145">145</a>	<b>protected</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a> <a class="xfld" name="acquireCount"/><a href="/source/s?refs=acquireCount&amp;project=rtmp_client" class="xfld">acquireCount</a> = <b>new</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a>();
<a class="l" name="146" href="#146">146</a>
<a class="l" name="147" href="#147">147</a>	<span class="c">/**
<a class="l" name="148" href="#148">148</a>	 * Timestamp the scope was created.
<a class="l" name="149" href="#149">149</a>	 */</span>
<a class="hl" name="150" href="#150">150</a>	<b>private</b> <b>long</b> <a class="xfld" name="creationTime"/><a href="/source/s?refs=creationTime&amp;project=rtmp_client" class="xfld">creationTime</a>;
<a class="l" name="151" href="#151">151</a>
<a class="l" name="152" href="#152">152</a>	<span class="c">/**
<a class="l" name="153" href="#153">153</a>	 * Manages listener statistics.
<a class="l" name="154" href="#154">154</a>	 */</span>
<a class="l" name="155" href="#155">155</a><span class="c">//	protected StatisticsCounter listenerStats = new StatisticsCounter();</span>
<a class="l" name="156" href="#156">156</a>
<a class="l" name="157" href="#157">157</a>	<span class="c">/**
<a class="l" name="158" href="#158">158</a>	 * Counts number of "change" events.
<a class="l" name="159" href="#159">159</a>	 */</span>
<a class="hl" name="160" href="#160">160</a>	<b>protected</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a> <a class="xfld" name="changeStats"/><a href="/source/s?refs=changeStats&amp;project=rtmp_client" class="xfld">changeStats</a> = <b>new</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a>();
<a class="l" name="161" href="#161">161</a>
<a class="l" name="162" href="#162">162</a>	<span class="c">/**
<a class="l" name="163" href="#163">163</a>	 * Counts number of "delete" events.
<a class="l" name="164" href="#164">164</a>	 */</span>
<a class="l" name="165" href="#165">165</a>	<b>protected</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a> <a class="xfld" name="deleteStats"/><a href="/source/s?refs=deleteStats&amp;project=rtmp_client" class="xfld">deleteStats</a> = <b>new</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a>();
<a class="l" name="166" href="#166">166</a>
<a class="l" name="167" href="#167">167</a>	<span class="c">/**
<a class="l" name="168" href="#168">168</a>	 * Counts number of "send message" events.
<a class="l" name="169" href="#169">169</a>	 */</span>
<a class="hl" name="170" href="#170">170</a>	<b>protected</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a> <a class="xfld" name="sendStats"/><a href="/source/s?refs=sendStats&amp;project=rtmp_client" class="xfld">sendStats</a> = <b>new</b> <a href="/source/s?defs=AtomicInteger&amp;project=rtmp_client">AtomicInteger</a>();
<a class="l" name="171" href="#171">171</a>
<a class="l" name="172" href="#172">172</a>	<span class="c">/**
<a class="l" name="173" href="#173">173</a>	 * Executor for sending messages to connections.
<a class="l" name="174" href="#174">174</a>	 */</span>
<a class="l" name="175" href="#175">175</a>	<b>protected</b> <a href="/source/s?defs=ExecutorService&amp;project=rtmp_client">ExecutorService</a> <a class="xfld" name="executor"/><a href="/source/s?refs=executor&amp;project=rtmp_client" class="xfld">executor</a>;
<a class="l" name="176" href="#176">176</a>
<a class="l" name="177" href="#177">177</a>	<span class="c">/** Constructs a new SharedObject. */</span>
<a class="l" name="178" href="#178">178</a>	<b>public</b> <a class="xmt" name="SharedObject"/><a href="/source/s?refs=SharedObject&amp;project=rtmp_client" class="xmt">SharedObject</a>() {
<a class="l" name="179" href="#179">179</a>		<span class="c">// This is used by the persistence framework</span>
<a class="hl" name="180" href="#180">180</a>		<b>super</b>();
<a class="l" name="181" href="#181">181</a>
<a class="l" name="182" href="#182">182</a>		<a class="d" href="#ownerMessage">ownerMessage</a> = <b>new</b> <a href="/source/s?defs=SharedObjectMessage&amp;project=rtmp_client">SharedObjectMessage</a>(<a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, -<span class="n">1</span>, <b>false</b>);
<a class="l" name="183" href="#183">183</a>		<a class="d" href="#creationTime">creationTime</a> = <a href="/source/s?defs=System&amp;project=rtmp_client">System</a>.<a href="/source/s?defs=currentTimeMillis&amp;project=rtmp_client">currentTimeMillis</a>();
<a class="l" name="184" href="#184">184</a>	}
<a class="l" name="185" href="#185">185</a>
<a class="l" name="186" href="#186">186</a>	<span class="c">/**
<a class="l" name="187" href="#187">187</a>	 * Constructs new SO from Input object
<a class="l" name="188" href="#188">188</a>	 * <strong>@param</strong> <em>input</em>              Input source
<a class="l" name="189" href="#189">189</a>	 * <strong>@throws</strong> <em>IOException</em>       I/O exception
<a class="hl" name="190" href="#190">190</a>	 *
<a class="l" name="191" href="#191">191</a>	 * <strong>@see</strong> org.red5.io.object.Input
<a class="l" name="192" href="#192">192</a>	 */</span>
<a class="l" name="193" href="#193">193</a>	<b>public</b> <a class="xmt" name="SharedObject"/><a href="/source/s?refs=SharedObject&amp;project=rtmp_client" class="xmt">SharedObject</a>(<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a> <a class="xa" name="input"/><a href="/source/s?refs=input&amp;project=rtmp_client" class="xa">input</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="194" href="#194">194</a>		<b>this</b>();
<a class="l" name="195" href="#195">195</a>		<a class="d" href="#deserialize">deserialize</a>(<a href="/source/s?defs=input&amp;project=rtmp_client">input</a>);
<a class="l" name="196" href="#196">196</a>	}
<a class="l" name="197" href="#197">197</a>
<a class="l" name="198" href="#198">198</a>	<span class="c">/**
<a class="l" name="199" href="#199">199</a>	 * Creates new SO from given data map, name, path and persistence option
<a class="hl" name="200" href="#200">200</a>	 *
<a class="l" name="201" href="#201">201</a>	 * <strong>@param</strong> <em>data</em>               Data
<a class="l" name="202" href="#202">202</a>	 * <strong>@param</strong> <em>name</em>               SO name
<a class="l" name="203" href="#203">203</a>	 * <strong>@param</strong> <em>path</em>               SO path
<a class="l" name="204" href="#204">204</a>	 * <strong>@param</strong> <em>persistent</em>         SO persistence
<a class="l" name="205" href="#205">205</a>	 */</span>
<a class="l" name="206" href="#206">206</a>	<b>public</b> <a class="xmt" name="SharedObject"/><a href="/source/s?refs=SharedObject&amp;project=rtmp_client" class="xmt">SharedObject</a>(<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xa" name="data"/><a href="/source/s?refs=data&amp;project=rtmp_client" class="xa">data</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="path"/><a href="/source/s?refs=path&amp;project=rtmp_client" class="xa">path</a>, <b>boolean</b> <a class="xa" name="persistent"/><a href="/source/s?refs=persistent&amp;project=rtmp_client" class="xa">persistent</a>) {
<a class="l" name="207" href="#207">207</a>		<b>super</b>();
<a class="l" name="208" href="#208">208</a>
<a class="l" name="209" href="#209">209</a>		<b>this</b>.<a href="/source/s?defs=name&amp;project=rtmp_client">name</a> = <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>;
<a class="hl" name="210" href="#210">210</a>		<b>this</b>.<a href="/source/s?defs=path&amp;project=rtmp_client">path</a> = <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>;
<a class="l" name="211" href="#211">211</a>		<b>this</b>.<a class="d" href="#persistentSO">persistentSO</a> = <a href="/source/s?defs=persistent&amp;project=rtmp_client">persistent</a>;
<a class="l" name="212" href="#212">212</a>
<a class="l" name="213" href="#213">213</a>		<a class="d" href="#ownerMessage">ownerMessage</a> = <b>new</b> <a href="/source/s?defs=SharedObjectMessage&amp;project=rtmp_client">SharedObjectMessage</a>(<a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <span class="n">0</span>, <a href="/source/s?defs=persistent&amp;project=rtmp_client">persistent</a>);
<a class="l" name="214" href="#214">214</a>		<a class="d" href="#creationTime">creationTime</a> = <a href="/source/s?defs=System&amp;project=rtmp_client">System</a>.<a href="/source/s?defs=currentTimeMillis&amp;project=rtmp_client">currentTimeMillis</a>();
<a class="l" name="215" href="#215">215</a>		<b>super</b>.<a href="/source/s?defs=setAttributes&amp;project=rtmp_client">setAttributes</a>(<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>);
<a class="l" name="216" href="#216">216</a>	}
<a class="l" name="217" href="#217">217</a>
<a class="l" name="218" href="#218">218</a>	<span class="c">/**
<a class="l" name="219" href="#219">219</a>	 * Creates new SO from given data map, name, path, storage object and persistence option
<a class="hl" name="220" href="#220">220</a>	 * <strong>@param</strong> <em>data</em>               Data
<a class="l" name="221" href="#221">221</a>	 * <strong>@param</strong> <em>name</em>               SO name
<a class="l" name="222" href="#222">222</a>	 * <strong>@param</strong> <em>path</em>               SO path
<a class="l" name="223" href="#223">223</a>	 * <strong>@param</strong> <em>persistent</em>         SO persistence
<a class="l" name="224" href="#224">224</a>	 * <strong>@param</strong> <em>storage</em>            Persistence storage
<a class="l" name="225" href="#225">225</a>	 */</span>
<a class="l" name="226" href="#226">226</a>	<b>public</b> <a class="xmt" name="SharedObject"/><a href="/source/s?refs=SharedObject&amp;project=rtmp_client" class="xmt">SharedObject</a>(<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xa" name="data"/><a href="/source/s?refs=data&amp;project=rtmp_client" class="xa">data</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="path"/><a href="/source/s?refs=path&amp;project=rtmp_client" class="xa">path</a>, <b>boolean</b> <a class="xa" name="persistent"/><a href="/source/s?refs=persistent&amp;project=rtmp_client" class="xa">persistent</a>,
<a class="l" name="227" href="#227">227</a>			<a href="/source/s?defs=IPersistenceStore&amp;project=rtmp_client">IPersistenceStore</a> <a href="/source/s?defs=storage&amp;project=rtmp_client">storage</a>) {
<a class="l" name="228" href="#228">228</a>		<b>this</b>(<a href="/source/s?defs=data&amp;project=rtmp_client">data</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>, <a href="/source/s?defs=persistent&amp;project=rtmp_client">persistent</a>);
<a class="l" name="229" href="#229">229</a>		<a class="d" href="#setStore">setStore</a>(<a href="/source/s?defs=storage&amp;project=rtmp_client">storage</a>);
<a class="hl" name="230" href="#230">230</a>	}
<a class="l" name="231" href="#231">231</a>
<a class="l" name="232" href="#232">232</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="233" href="#233">233</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getName"/><a href="/source/s?refs=getName&amp;project=rtmp_client" class="xmt">getName</a>() {
<a class="l" name="234" href="#234">234</a>		<b>return</b> <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>;
<a class="l" name="235" href="#235">235</a>	}
<a class="l" name="236" href="#236">236</a>
<a class="l" name="237" href="#237">237</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="238" href="#238">238</a>	<b>public</b> <b>void</b> <a class="xmt" name="setName"/><a href="/source/s?refs=setName&amp;project=rtmp_client" class="xmt">setName</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="l" name="239" href="#239">239</a>		<span class="c">// Shared objects don't support setting of their names</span>
<a class="hl" name="240" href="#240">240</a>	}
<a class="l" name="241" href="#241">241</a>
<a class="l" name="242" href="#242">242</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="243" href="#243">243</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getPath"/><a href="/source/s?refs=getPath&amp;project=rtmp_client" class="xmt">getPath</a>() {
<a class="l" name="244" href="#244">244</a>		<b>return</b> <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>;
<a class="l" name="245" href="#245">245</a>	}
<a class="l" name="246" href="#246">246</a>
<a class="l" name="247" href="#247">247</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="248" href="#248">248</a>	<b>public</b> <b>void</b> <a class="xmt" name="setPath"/><a href="/source/s?refs=setPath&amp;project=rtmp_client" class="xmt">setPath</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="path"/><a href="/source/s?refs=path&amp;project=rtmp_client" class="xa">path</a>) {
<a class="l" name="249" href="#249">249</a>		<b>this</b>.<a href="/source/s?defs=path&amp;project=rtmp_client">path</a> = <a href="/source/s?defs=path&amp;project=rtmp_client">path</a>;
<a class="hl" name="250" href="#250">250</a>	}
<a class="l" name="251" href="#251">251</a>
<a class="l" name="252" href="#252">252</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="253" href="#253">253</a>	<b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getType"/><a href="/source/s?refs=getType&amp;project=rtmp_client" class="xmt">getType</a>() {
<a class="l" name="254" href="#254">254</a><span class="c">//		return TYPE;</span>
<a class="l" name="255" href="#255">255</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="256" href="#256">256</a>	}
<a class="l" name="257" href="#257">257</a>
<a class="l" name="258" href="#258">258</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="259" href="#259">259</a>	<b>public</b> <b>long</b> <a class="xmt" name="getLastModified"/><a href="/source/s?refs=getLastModified&amp;project=rtmp_client" class="xmt">getLastModified</a>() {
<a class="hl" name="260" href="#260">260</a>		<b>return</b> <a class="d" href="#lastModified">lastModified</a>;
<a class="l" name="261" href="#261">261</a>	}
<a class="l" name="262" href="#262">262</a>
<a class="l" name="263" href="#263">263</a>	<span class="c">/**
<a class="l" name="264" href="#264">264</a>	 * Getter for persistent object
<a class="l" name="265" href="#265">265</a>	 *
<a class="l" name="266" href="#266">266</a>	 * <strong>@return</strong>  Persistent object
<a class="l" name="267" href="#267">267</a>	 */</span>
<a class="l" name="268" href="#268">268</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="isPersistentObject"/><a href="/source/s?refs=isPersistentObject&amp;project=rtmp_client" class="xmt">isPersistentObject</a>() {
<a class="l" name="269" href="#269">269</a>		<b>return</b> <a class="d" href="#persistentSO">persistentSO</a>;
<a class="hl" name="270" href="#270">270</a>	}
<a class="l" name="271" href="#271">271</a>
<a class="l" name="272" href="#272">272</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="273" href="#273">273</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="isPersistent"/><a href="/source/s?refs=isPersistent&amp;project=rtmp_client" class="xmt">isPersistent</a>() {
<a class="l" name="274" href="#274">274</a>		<b>return</b> <a href="/source/s?defs=persistent&amp;project=rtmp_client">persistent</a>;
<a class="l" name="275" href="#275">275</a>	}
<a class="l" name="276" href="#276">276</a>
<a class="l" name="277" href="#277">277</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="278" href="#278">278</a>	<b>public</b> <b>void</b> <a class="xmt" name="setPersistent"/><a href="/source/s?refs=setPersistent&amp;project=rtmp_client" class="xmt">setPersistent</a>(<b>boolean</b> <a class="xa" name="persistent"/><a href="/source/s?refs=persistent&amp;project=rtmp_client" class="xa">persistent</a>) {
<a class="l" name="279" href="#279">279</a>		<b>this</b>.<a href="/source/s?defs=persistent&amp;project=rtmp_client">persistent</a> = <a href="/source/s?defs=persistent&amp;project=rtmp_client">persistent</a>;
<a class="hl" name="280" href="#280">280</a>	}
<a class="l" name="281" href="#281">281</a>
<a class="l" name="282" href="#282">282</a>	<span class="c">/**
<a class="l" name="283" href="#283">283</a>	 * Send update notification over data channel of RTMP connection
<a class="l" name="284" href="#284">284</a>	 */</span>
<a class="l" name="285" href="#285">285</a>	<b>protected</b> <b>void</b> <a class="xmt" name="sendUpdates"/><a href="/source/s?refs=sendUpdates&amp;project=rtmp_client" class="xmt">sendUpdates</a>() {
<a class="l" name="286" href="#286">286</a>		<span class="c">//get the current version</span>
<a class="l" name="287" href="#287">287</a>		<b>int</b> <a href="/source/s?defs=currentVersion&amp;project=rtmp_client">currentVersion</a> = <a class="d" href="#getVersion">getVersion</a>();
<a class="l" name="288" href="#288">288</a>		<span class="c">//get the name</span>
<a class="l" name="289" href="#289">289</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=name&amp;project=rtmp_client">name</a> = <a class="d" href="#getName">getName</a>();
<a class="hl" name="290" href="#290">290</a>		<span class="c">//is it persistent</span>
<a class="l" name="291" href="#291">291</a>		<b>boolean</b> <a href="/source/s?defs=persist&amp;project=rtmp_client">persist</a> = <a class="d" href="#isPersistentObject">isPersistentObject</a>();
<a class="l" name="292" href="#292">292</a>		<span class="c">//used for notifying owner / consumers</span>
<a class="l" name="293" href="#293">293</a>		<a href="/source/s?defs=ConcurrentLinkedQueue&amp;project=rtmp_client">ConcurrentLinkedQueue</a>&lt;<a href="/source/s?defs=ISharedObjectEvent&amp;project=rtmp_client">ISharedObjectEvent</a>&gt; <a href="/source/s?defs=events&amp;project=rtmp_client">events</a> = <b>new</b> <a href="/source/s?defs=ConcurrentLinkedQueue&amp;project=rtmp_client">ConcurrentLinkedQueue</a>&lt;<a href="/source/s?defs=ISharedObjectEvent&amp;project=rtmp_client">ISharedObjectEvent</a>&gt;();
<a class="l" name="294" href="#294">294</a>		<span class="c">//get owner events</span>
<a class="l" name="295" href="#295">295</a>		<a href="/source/s?defs=ConcurrentLinkedQueue&amp;project=rtmp_client">ConcurrentLinkedQueue</a>&lt;<a href="/source/s?defs=ISharedObjectEvent&amp;project=rtmp_client">ISharedObjectEvent</a>&gt; <a href="/source/s?defs=ownerEvents&amp;project=rtmp_client">ownerEvents</a> = <a class="d" href="#ownerMessage">ownerMessage</a>.<a href="/source/s?defs=getEvents&amp;project=rtmp_client">getEvents</a>();
<a class="l" name="296" href="#296">296</a>		<span class="c">//get all current owner events</span>
<a class="l" name="297" href="#297">297</a>		<b>do</b> {
<a class="l" name="298" href="#298">298</a>    		<a href="/source/s?defs=ISharedObjectEvent&amp;project=rtmp_client">ISharedObjectEvent</a> <a href="/source/s?defs=soe&amp;project=rtmp_client">soe</a> = <a href="/source/s?defs=ownerEvents&amp;project=rtmp_client">ownerEvents</a>.<a href="/source/s?defs=poll&amp;project=rtmp_client">poll</a>();
<a class="l" name="299" href="#299">299</a>    		<b>if</b> (<a href="/source/s?defs=soe&amp;project=rtmp_client">soe</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="300" href="#300">300</a>    			<a href="/source/s?defs=events&amp;project=rtmp_client">events</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=soe&amp;project=rtmp_client">soe</a>);
<a class="l" name="301" href="#301">301</a>    		}
<a class="l" name="302" href="#302">302</a>		} <b>while</b> (!<a href="/source/s?defs=ownerEvents&amp;project=rtmp_client">ownerEvents</a>.<a href="/source/s?defs=isEmpty&amp;project=rtmp_client">isEmpty</a>());
<a class="l" name="303" href="#303">303</a>		<span class="c">//null out our ref</span>
<a class="l" name="304" href="#304">304</a>		<a href="/source/s?defs=ownerEvents&amp;project=rtmp_client">ownerEvents</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="305" href="#305">305</a>		<span class="c">//</span>
<a class="l" name="306" href="#306">306</a>		<b>if</b> (!<a href="/source/s?defs=events&amp;project=rtmp_client">events</a>.<a href="/source/s?defs=isEmpty&amp;project=rtmp_client">isEmpty</a>()) {
<a class="l" name="307" href="#307">307</a>			<span class="c">// Send update to "owner" of this update request</span>
<a class="l" name="308" href="#308">308</a>			<a href="/source/s?defs=SharedObjectMessage&amp;project=rtmp_client">SharedObjectMessage</a> <a href="/source/s?defs=syncOwner&amp;project=rtmp_client">syncOwner</a> = <b>new</b> <a href="/source/s?defs=SharedObjectMessage&amp;project=rtmp_client">SharedObjectMessage</a>(<a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=currentVersion&amp;project=rtmp_client">currentVersion</a>, <a href="/source/s?defs=persist&amp;project=rtmp_client">persist</a>);
<a class="l" name="309" href="#309">309</a>			<a href="/source/s?defs=syncOwner&amp;project=rtmp_client">syncOwner</a>.<a href="/source/s?defs=addEvents&amp;project=rtmp_client">addEvents</a>(<a href="/source/s?defs=events&amp;project=rtmp_client">events</a>);
<a class="hl" name="310" href="#310">310</a>			<b>if</b> (<a class="d" href="#source">source</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="311" href="#311">311</a>				<span class="c">// Only send updates when issued through RTMP request</span>
<a class="l" name="312" href="#312">312</a>				<a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a> = ((<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>) <a class="d" href="#source">source</a>).<a href="/source/s?defs=getChannel&amp;project=rtmp_client">getChannel</a>((<b>byte</b>) <span class="n">3</span>);
<a class="l" name="313" href="#313">313</a>				<b>if</b> (<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="314" href="#314">314</a>					<span class="c">//ownerMessage.acquire();</span>
<a class="l" name="315" href="#315">315</a>					<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=syncOwner&amp;project=rtmp_client">syncOwner</a>);
<a class="l" name="316" href="#316">316</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Owner: {}"</span>, <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>);
<a class="l" name="317" href="#317">317</a>				} <b>else</b> {
<a class="l" name="318" href="#318">318</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"No channel found for owner changes!?"</span>);
<a class="l" name="319" href="#319">319</a>				}
<a class="hl" name="320" href="#320">320</a>			}
<a class="l" name="321" href="#321">321</a>		}
<a class="l" name="322" href="#322">322</a>		<span class="c">//clear owner events</span>
<a class="l" name="323" href="#323">323</a>		<a href="/source/s?defs=events&amp;project=rtmp_client">events</a>.<a class="d" href="#clear">clear</a>();
<a class="l" name="324" href="#324">324</a>		<span class="c">//get all current sync events</span>
<a class="l" name="325" href="#325">325</a>		<b>do</b> {
<a class="l" name="326" href="#326">326</a>    		<a href="/source/s?defs=ISharedObjectEvent&amp;project=rtmp_client">ISharedObjectEvent</a> <a href="/source/s?defs=soe&amp;project=rtmp_client">soe</a> = <a class="d" href="#syncEvents">syncEvents</a>.<a href="/source/s?defs=poll&amp;project=rtmp_client">poll</a>();
<a class="l" name="327" href="#327">327</a>    		<b>if</b> (<a href="/source/s?defs=soe&amp;project=rtmp_client">soe</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="328" href="#328">328</a>    			<a href="/source/s?defs=events&amp;project=rtmp_client">events</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=soe&amp;project=rtmp_client">soe</a>);
<a class="l" name="329" href="#329">329</a>    		}
<a class="hl" name="330" href="#330">330</a>		} <b>while</b> (!<a class="d" href="#syncEvents">syncEvents</a>.<a href="/source/s?defs=isEmpty&amp;project=rtmp_client">isEmpty</a>());
<a class="l" name="331" href="#331">331</a>		<span class="c">//tell all the listeners</span>
<a class="l" name="332" href="#332">332</a>		<b>if</b> (!<a href="/source/s?defs=events&amp;project=rtmp_client">events</a>.<a href="/source/s?defs=isEmpty&amp;project=rtmp_client">isEmpty</a>()) {
<a class="l" name="333" href="#333">333</a>			<span class="c">//dont create the executor until we need it</span>
<a class="l" name="334" href="#334">334</a>			<b>if</b> (<a class="d" href="#executor">executor</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="335" href="#335">335</a>				<a class="d" href="#executor">executor</a> = <a href="/source/s?defs=Executors&amp;project=rtmp_client">Executors</a>.<a href="/source/s?defs=newCachedThreadPool&amp;project=rtmp_client">newCachedThreadPool</a>();
<a class="l" name="336" href="#336">336</a>			}
<a class="l" name="337" href="#337">337</a>			<span class="c">//get the listeners</span>
<a class="l" name="338" href="#338">338</a>			<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>&lt;<a href="/source/s?defs=IEventListener&amp;project=rtmp_client">IEventListener</a>&gt; <a class="d" href="#listeners">listeners</a> = <a class="d" href="#getListeners">getListeners</a>();
<a class="l" name="339" href="#339">339</a>			<span class="c">//updates all registered clients of this shared object</span>
<a class="hl" name="340" href="#340">340</a>			<b>for</b> (<a href="/source/s?defs=IEventListener&amp;project=rtmp_client">IEventListener</a> <a href="/source/s?defs=listener&amp;project=rtmp_client">listener</a> : <a class="d" href="#listeners">listeners</a>) {
<a class="l" name="341" href="#341">341</a>				<b>if</b> (<a href="/source/s?defs=listener&amp;project=rtmp_client">listener</a> != <a class="d" href="#source">source</a>) {
<a class="l" name="342" href="#342">342</a>					<b>if</b> (<a href="/source/s?defs=listener&amp;project=rtmp_client">listener</a> <b>instanceof</b> <a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>) {
<a class="l" name="343" href="#343">343</a>						<span class="c">//get the channel for so updates</span>
<a class="l" name="344" href="#344">344</a>						<b>final</b> <a href="/source/s?defs=Channel&amp;project=rtmp_client">Channel</a> <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a> = ((<a href="/source/s?defs=RTMPConnection&amp;project=rtmp_client">RTMPConnection</a>) <a href="/source/s?defs=listener&amp;project=rtmp_client">listener</a>).<a href="/source/s?defs=getChannel&amp;project=rtmp_client">getChannel</a>((<b>byte</b>) <span class="n">3</span>);
<a class="l" name="345" href="#345">345</a>						<span class="c">//create a new sync message for every client to avoid</span>
<a class="l" name="346" href="#346">346</a>						<span class="c">//concurrent access through multiple threads</span>
<a class="l" name="347" href="#347">347</a>						<b>final</b> <a href="/source/s?defs=SharedObjectMessage&amp;project=rtmp_client">SharedObjectMessage</a> <a href="/source/s?defs=syncMessage&amp;project=rtmp_client">syncMessage</a> = <b>new</b> <a href="/source/s?defs=SharedObjectMessage&amp;project=rtmp_client">SharedObjectMessage</a>(<a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=currentVersion&amp;project=rtmp_client">currentVersion</a>, <a href="/source/s?defs=persist&amp;project=rtmp_client">persist</a>);
<a class="l" name="348" href="#348">348</a>						<a href="/source/s?defs=syncMessage&amp;project=rtmp_client">syncMessage</a>.<a href="/source/s?defs=addEvents&amp;project=rtmp_client">addEvents</a>(<a href="/source/s?defs=events&amp;project=rtmp_client">events</a>);
<a class="l" name="349" href="#349">349</a>						<span class="c">//create a worker</span>
<a class="hl" name="350" href="#350">350</a>						<a href="/source/s?defs=Runnable&amp;project=rtmp_client">Runnable</a> <a href="/source/s?defs=worker&amp;project=rtmp_client">worker</a> = <b>new</b> <a href="/source/s?defs=Runnable&amp;project=rtmp_client">Runnable</a>() {
<a class="l" name="351" href="#351">351</a>							<b>public</b> <b>void</b> <a href="/source/s?defs=run&amp;project=rtmp_client">run</a>() {
<a class="l" name="352" href="#352">352</a>        						<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Send to {}"</span>, <a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>);
<a class="l" name="353" href="#353">353</a>        						<a href="/source/s?defs=channel&amp;project=rtmp_client">channel</a>.<a href="/source/s?defs=write&amp;project=rtmp_client">write</a>(<a href="/source/s?defs=syncMessage&amp;project=rtmp_client">syncMessage</a>);
<a class="l" name="354" href="#354">354</a>							}
<a class="l" name="355" href="#355">355</a>						};
<a class="l" name="356" href="#356">356</a>						<a class="d" href="#executor">executor</a>.<a href="/source/s?defs=execute&amp;project=rtmp_client">execute</a>(<a href="/source/s?defs=worker&amp;project=rtmp_client">worker</a>);
<a class="l" name="357" href="#357">357</a>					} <b>else</b> {
<a class="l" name="358" href="#358">358</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=warn&amp;project=rtmp_client">warn</a>(<span class="s">"Can't send sync message to unknown connection {}"</span>, <a href="/source/s?defs=listener&amp;project=rtmp_client">listener</a>);
<a class="l" name="359" href="#359">359</a>					}
<a class="hl" name="360" href="#360">360</a>				} <b>else</b> {
<a class="l" name="361" href="#361">361</a>					<span class="c">// Don't re-send update to active client</span>
<a class="l" name="362" href="#362">362</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Skipped {}"</span>, <a class="d" href="#source">source</a>);
<a class="l" name="363" href="#363">363</a>				}
<a class="l" name="364" href="#364">364</a>			}
<a class="l" name="365" href="#365">365</a>
<a class="l" name="366" href="#366">366</a>		}
<a class="l" name="367" href="#367">367</a>		<span class="c">//clear events</span>
<a class="l" name="368" href="#368">368</a>		<a href="/source/s?defs=events&amp;project=rtmp_client">events</a>.<a class="d" href="#clear">clear</a>();
<a class="l" name="369" href="#369">369</a>	}
<a class="hl" name="370" href="#370">370</a>
<a class="l" name="371" href="#371">371</a>	<span class="c">/**
<a class="l" name="372" href="#372">372</a>	 * Send notification about modification of SO
<a class="l" name="373" href="#373">373</a>	 */</span>
<a class="l" name="374" href="#374">374</a>	<b>protected</b> <b>void</b> <a class="xmt" name="notifyModified"/><a href="/source/s?refs=notifyModified&amp;project=rtmp_client" class="xmt">notifyModified</a>() {
<a class="l" name="375" href="#375">375</a>		<b>if</b> (<a class="d" href="#updateCounter">updateCounter</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &gt; <span class="n">0</span>) {
<a class="l" name="376" href="#376">376</a>			<span class="c">// we're inside a beginUpdate...endUpdate block</span>
<a class="l" name="377" href="#377">377</a>			<b>return</b>;
<a class="l" name="378" href="#378">378</a>		}
<a class="l" name="379" href="#379">379</a>		<b>if</b> (<a class="d" href="#modified">modified</a>) {
<a class="hl" name="380" href="#380">380</a>			<span class="c">// The client sent at least one update -&gt; increase version of SO</span>
<a class="l" name="381" href="#381">381</a>			<a class="d" href="#updateVersion">updateVersion</a>();
<a class="l" name="382" href="#382">382</a>			<a class="d" href="#lastModified">lastModified</a> = <a href="/source/s?defs=System&amp;project=rtmp_client">System</a>.<a href="/source/s?defs=currentTimeMillis&amp;project=rtmp_client">currentTimeMillis</a>();
<a class="l" name="383" href="#383">383</a>		}
<a class="l" name="384" href="#384">384</a>		<b>if</b> (<a class="d" href="#modified">modified</a> &amp;&amp; <a href="/source/s?defs=storage&amp;project=rtmp_client">storage</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="385" href="#385">385</a>			<b>if</b> (!<a href="/source/s?defs=storage&amp;project=rtmp_client">storage</a>.<a href="/source/s?defs=save&amp;project=rtmp_client">save</a>(<b>this</b>)) {
<a class="l" name="386" href="#386">386</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Could not store shared object."</span>);
<a class="l" name="387" href="#387">387</a>			}
<a class="l" name="388" href="#388">388</a>		}
<a class="l" name="389" href="#389">389</a>		<a class="d" href="#sendUpdates">sendUpdates</a>();
<a class="hl" name="390" href="#390">390</a>		<span class="c">//APPSERVER-291</span>
<a class="l" name="391" href="#391">391</a>		<a class="d" href="#modified">modified</a> = <b>false</b>;
<a class="l" name="392" href="#392">392</a>	}
<a class="l" name="393" href="#393">393</a>
<a class="l" name="394" href="#394">394</a>	<span class="c">/**
<a class="l" name="395" href="#395">395</a>	 * Return an error message to the client.
<a class="l" name="396" href="#396">396</a>	 *
<a class="l" name="397" href="#397">397</a>	 * <strong>@param</strong> <em>message</em>
<a class="l" name="398" href="#398">398</a>	 */</span>
<a class="l" name="399" href="#399">399</a>	<b>protected</b> <b>void</b> <a class="xmt" name="returnError"/><a href="/source/s?refs=returnError&amp;project=rtmp_client" class="xmt">returnError</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="message"/><a href="/source/s?refs=message&amp;project=rtmp_client" class="xa">message</a>) {
<a class="hl" name="400" href="#400">400</a>		<a class="d" href="#ownerMessage">ownerMessage</a>.<a href="/source/s?defs=addEvent&amp;project=rtmp_client">addEvent</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_STATUS&amp;project=rtmp_client">CLIENT_STATUS</a>, <span class="s">"error"</span>, <a class="d" href="#message">message</a>);
<a class="l" name="401" href="#401">401</a>	}
<a class="l" name="402" href="#402">402</a>
<a class="l" name="403" href="#403">403</a>	<span class="c">/**
<a class="l" name="404" href="#404">404</a>	 * Return an attribute value to the owner.
<a class="l" name="405" href="#405">405</a>	 *
<a class="l" name="406" href="#406">406</a>	 * <strong>@param</strong> <em>name</em>
<a class="l" name="407" href="#407">407</a>	 */</span>
<a class="l" name="408" href="#408">408</a>	<b>protected</b> <b>void</b> <a class="xmt" name="returnAttributeValue"/><a href="/source/s?refs=returnAttributeValue&amp;project=rtmp_client" class="xmt">returnAttributeValue</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="l" name="409" href="#409">409</a>		<a class="d" href="#ownerMessage">ownerMessage</a>.<a href="/source/s?defs=addEvent&amp;project=rtmp_client">addEvent</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_UPDATE_DATA&amp;project=rtmp_client">CLIENT_UPDATE_DATA</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a class="d" href="#getAttribute">getAttribute</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>));
<a class="hl" name="410" href="#410">410</a>	}
<a class="l" name="411" href="#411">411</a>
<a class="l" name="412" href="#412">412</a>	<span class="c">/**
<a class="l" name="413" href="#413">413</a>	 * Return attribute by name and set if it doesn't exist yet.
<a class="l" name="414" href="#414">414</a>	 * <strong>@param</strong> <em>name</em>         Attribute name
<a class="l" name="415" href="#415">415</a>	 * <strong>@param</strong> <em>value</em>        Value to set if attribute doesn't exist
<a class="l" name="416" href="#416">416</a>	 * <strong>@return</strong>             Attribute value
<a class="l" name="417" href="#417">417</a>	 */</span>
<a class="l" name="418" href="#418">418</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="419" href="#419">419</a>	<b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="getAttribute"/><a href="/source/s?refs=getAttribute&amp;project=rtmp_client" class="xmt">getAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="hl" name="420" href="#420">420</a>		<b>if</b> (<a href="/source/s?defs=name&amp;project=rtmp_client">name</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="421" href="#421">421</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="422" href="#422">422</a>		}
<a class="l" name="423" href="#423">423</a>
<a class="l" name="424" href="#424">424</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a>.<a href="/source/s?defs=putIfAbsent&amp;project=rtmp_client">putIfAbsent</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="425" href="#425">425</a>		<b>if</b> (<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="426" href="#426">426</a>			<span class="c">// No previous value</span>
<a class="l" name="427" href="#427">427</a>			<a class="d" href="#modified">modified</a> = <b>true</b>;
<a class="l" name="428" href="#428">428</a>			<a class="d" href="#ownerMessage">ownerMessage</a>.<a href="/source/s?defs=addEvent&amp;project=rtmp_client">addEvent</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_UPDATE_DATA&amp;project=rtmp_client">CLIENT_UPDATE_DATA</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>);
<a class="l" name="429" href="#429">429</a>			<a class="d" href="#syncEvents">syncEvents</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<b>new</b> <a href="/source/s?defs=SharedObjectEvent&amp;project=rtmp_client">SharedObjectEvent</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_UPDATE_DATA&amp;project=rtmp_client">CLIENT_UPDATE_DATA</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>));
<a class="hl" name="430" href="#430">430</a>			<a class="d" href="#notifyModified">notifyModified</a>();
<a class="l" name="431" href="#431">431</a>			<a class="d" href="#changeStats">changeStats</a>.<a href="/source/s?defs=incrementAndGet&amp;project=rtmp_client">incrementAndGet</a>();
<a class="l" name="432" href="#432">432</a>			<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>;
<a class="l" name="433" href="#433">433</a>		}
<a class="l" name="434" href="#434">434</a>
<a class="l" name="435" href="#435">435</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="436" href="#436">436</a>	}
<a class="l" name="437" href="#437">437</a>
<a class="l" name="438" href="#438">438</a>	<span class="c">/**
<a class="l" name="439" href="#439">439</a>	 * Set value of attribute with given name
<a class="hl" name="440" href="#440">440</a>	 * <strong>@param</strong> <em>name</em>         Attribute name
<a class="l" name="441" href="#441">441</a>	 * <strong>@param</strong> <em>value</em>        Attribute value
<a class="l" name="442" href="#442">442</a>	 * <strong>@return</strong>             &lt;code&gt;true&lt;/code&gt; if there's such attribute and value was set, &lt;code&gt;false&lt;/code&gt; otherwise
<a class="l" name="443" href="#443">443</a>	 */</span>
<a class="l" name="444" href="#444">444</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="445" href="#445">445</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="setAttribute"/><a href="/source/s?refs=setAttribute&amp;project=rtmp_client" class="xmt">setAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="l" name="446" href="#446">446</a>		<b>boolean</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>true</b>;
<a class="l" name="447" href="#447">447</a>		<a class="d" href="#ownerMessage">ownerMessage</a>.<a href="/source/s?defs=addEvent&amp;project=rtmp_client">addEvent</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_UPDATE_ATTRIBUTE&amp;project=rtmp_client">CLIENT_UPDATE_ATTRIBUTE</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="448" href="#448">448</a>		<b>if</b> (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <b>super</b>.<a class="d" href="#removeAttribute">removeAttribute</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>)) {
<a class="l" name="449" href="#449">449</a>			<span class="c">// Setting a null value removes the attribute</span>
<a class="hl" name="450" href="#450">450</a>			<a class="d" href="#modified">modified</a> = <b>true</b>;
<a class="l" name="451" href="#451">451</a>			<a class="d" href="#syncEvents">syncEvents</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<b>new</b> <a href="/source/s?defs=SharedObjectEvent&amp;project=rtmp_client">SharedObjectEvent</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_DELETE_DATA&amp;project=rtmp_client">CLIENT_DELETE_DATA</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>));
<a class="l" name="452" href="#452">452</a>			<a class="d" href="#deleteStats">deleteStats</a>.<a href="/source/s?defs=incrementAndGet&amp;project=rtmp_client">incrementAndGet</a>();
<a class="l" name="453" href="#453">453</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=value&amp;project=rtmp_client">value</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <b>super</b>.<a class="d" href="#setAttribute">setAttribute</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>)) {
<a class="l" name="454" href="#454">454</a>			<span class="c">// only sync if the attribute changed</span>
<a class="l" name="455" href="#455">455</a>			<a class="d" href="#modified">modified</a> = <b>true</b>;
<a class="l" name="456" href="#456">456</a>			<a class="d" href="#syncEvents">syncEvents</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<b>new</b> <a href="/source/s?defs=SharedObjectEvent&amp;project=rtmp_client">SharedObjectEvent</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_UPDATE_DATA&amp;project=rtmp_client">CLIENT_UPDATE_DATA</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=value&amp;project=rtmp_client">value</a>));
<a class="l" name="457" href="#457">457</a>			<a class="d" href="#changeStats">changeStats</a>.<a href="/source/s?defs=incrementAndGet&amp;project=rtmp_client">incrementAndGet</a>();
<a class="l" name="458" href="#458">458</a>		} <b>else</b> {
<a class="l" name="459" href="#459">459</a>			<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>false</b>;
<a class="hl" name="460" href="#460">460</a>		}
<a class="l" name="461" href="#461">461</a>		<a class="d" href="#notifyModified">notifyModified</a>();
<a class="l" name="462" href="#462">462</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="463" href="#463">463</a>	}
<a class="l" name="464" href="#464">464</a>
<a class="l" name="465" href="#465">465</a>	<span class="c">/**
<a class="l" name="466" href="#466">466</a>	 * Set attributes as map.
<a class="l" name="467" href="#467">467</a>	 *
<a class="l" name="468" href="#468">468</a>	 * <strong>@param</strong> <em>values</em>  Attributes.
<a class="l" name="469" href="#469">469</a>	 */</span>
<a class="hl" name="470" href="#470">470</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="471" href="#471">471</a>	<b>public</b> <b>void</b> <a class="xmt" name="setAttributes"/><a href="/source/s?refs=setAttributes&amp;project=rtmp_client" class="xmt">setAttributes</a>(<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xa" name="values"/><a href="/source/s?refs=values&amp;project=rtmp_client" class="xa">values</a>) {
<a class="l" name="472" href="#472">472</a>		<b>if</b> (<a href="/source/s?defs=values&amp;project=rtmp_client">values</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="473" href="#473">473</a>			<b>return</b>;
<a class="l" name="474" href="#474">474</a>		}
<a class="l" name="475" href="#475">475</a>		<a href="/source/s?defs=beginUpdate&amp;project=rtmp_client">beginUpdate</a>();
<a class="l" name="476" href="#476">476</a>		<b>try</b> {
<a class="l" name="477" href="#477">477</a>			<b>for</b> (<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>.<a href="/source/s?defs=Entry&amp;project=rtmp_client">Entry</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a> : <a href="/source/s?defs=values&amp;project=rtmp_client">values</a>.<a href="/source/s?defs=entrySet&amp;project=rtmp_client">entrySet</a>()) {
<a class="l" name="478" href="#478">478</a>				<a class="d" href="#setAttribute">setAttribute</a>(<a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a>.<a href="/source/s?defs=getKey&amp;project=rtmp_client">getKey</a>(), <a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a>.<a href="/source/s?defs=getValue&amp;project=rtmp_client">getValue</a>());
<a class="l" name="479" href="#479">479</a>			}
<a class="hl" name="480" href="#480">480</a>		} <b>finally</b> {
<a class="l" name="481" href="#481">481</a>			<a class="d" href="#endUpdate">endUpdate</a>();
<a class="l" name="482" href="#482">482</a>		}
<a class="l" name="483" href="#483">483</a>	}
<a class="l" name="484" href="#484">484</a>
<a class="l" name="485" href="#485">485</a>	<span class="c">/**
<a class="l" name="486" href="#486">486</a>	 * Set attributes as attributes store.
<a class="l" name="487" href="#487">487</a>	 *
<a class="l" name="488" href="#488">488</a>	 * <strong>@param</strong> <em>values</em>  Attributes.
<a class="l" name="489" href="#489">489</a>	 */</span>
<a class="hl" name="490" href="#490">490</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="491" href="#491">491</a>	<b>public</b> <b>void</b> <a class="xmt" name="setAttributes"/><a href="/source/s?refs=setAttributes&amp;project=rtmp_client" class="xmt">setAttributes</a>(<a href="/source/s?defs=IAttributeStore&amp;project=rtmp_client">IAttributeStore</a> <a class="xa" name="values"/><a href="/source/s?refs=values&amp;project=rtmp_client" class="xa">values</a>) {
<a class="l" name="492" href="#492">492</a>		<b>if</b> (<a href="/source/s?defs=values&amp;project=rtmp_client">values</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="493" href="#493">493</a>			<b>return</b>;
<a class="l" name="494" href="#494">494</a>		}
<a class="l" name="495" href="#495">495</a>		<a href="/source/s?defs=setAttributes&amp;project=rtmp_client">setAttributes</a>(<a href="/source/s?defs=values&amp;project=rtmp_client">values</a>.<a href="/source/s?defs=getAttributes&amp;project=rtmp_client">getAttributes</a>());
<a class="l" name="496" href="#496">496</a>	}
<a class="l" name="497" href="#497">497</a>
<a class="l" name="498" href="#498">498</a>	<span class="c">/**
<a class="l" name="499" href="#499">499</a>	 * Removes attribute with given name
<a class="hl" name="500" href="#500">500</a>	 * <strong>@param</strong> <em>name</em>    Attribute
<a class="l" name="501" href="#501">501</a>	 * <strong>@return</strong>        &lt;code&gt;true&lt;/code&gt; if there's such an attribute and it was removed, &lt;code&gt;false&lt;/code&gt; otherwise
<a class="l" name="502" href="#502">502</a>	 */</span>
<a class="l" name="503" href="#503">503</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="l" name="504" href="#504">504</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="removeAttribute"/><a href="/source/s?refs=removeAttribute&amp;project=rtmp_client" class="xmt">removeAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="l" name="505" href="#505">505</a>		<b>boolean</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>true</b>;
<a class="l" name="506" href="#506">506</a>		<span class="c">// Send confirmation to client</span>
<a class="l" name="507" href="#507">507</a>		<a class="d" href="#ownerMessage">ownerMessage</a>.<a href="/source/s?defs=addEvent&amp;project=rtmp_client">addEvent</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_DELETE_DATA&amp;project=rtmp_client">CLIENT_DELETE_DATA</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="508" href="#508">508</a>		<b>if</b> (<b>super</b>.<a class="d" href="#removeAttribute">removeAttribute</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>)) {
<a class="l" name="509" href="#509">509</a>			<a class="d" href="#modified">modified</a> = <b>true</b>;
<a class="hl" name="510" href="#510">510</a>			<a class="d" href="#syncEvents">syncEvents</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<b>new</b> <a href="/source/s?defs=SharedObjectEvent&amp;project=rtmp_client">SharedObjectEvent</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_DELETE_DATA&amp;project=rtmp_client">CLIENT_DELETE_DATA</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>));
<a class="l" name="511" href="#511">511</a>			<a class="d" href="#deleteStats">deleteStats</a>.<a href="/source/s?defs=incrementAndGet&amp;project=rtmp_client">incrementAndGet</a>();
<a class="l" name="512" href="#512">512</a>		} <b>else</b> {
<a class="l" name="513" href="#513">513</a>			<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>false</b>;
<a class="l" name="514" href="#514">514</a>		}
<a class="l" name="515" href="#515">515</a>		<a class="d" href="#notifyModified">notifyModified</a>();
<a class="l" name="516" href="#516">516</a>		<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="517" href="#517">517</a>	}
<a class="l" name="518" href="#518">518</a>
<a class="l" name="519" href="#519">519</a>	<span class="c">/**
<a class="hl" name="520" href="#520">520</a>	 * Broadcast event to event handler
<a class="l" name="521" href="#521">521</a>	 * <strong>@param</strong> <em>handler</em>         Event handler
<a class="l" name="522" href="#522">522</a>	 * <strong>@param</strong> <em>arguments</em>       Arguments
<a class="l" name="523" href="#523">523</a>	 */</span>
<a class="l" name="524" href="#524">524</a>	<b>protected</b> <b>void</b> <a class="xmt" name="sendMessage"/><a href="/source/s?refs=sendMessage&amp;project=rtmp_client" class="xmt">sendMessage</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="handler"/><a href="/source/s?refs=handler&amp;project=rtmp_client" class="xa">handler</a>, <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;?&gt; <a class="xa" name="arguments"/><a href="/source/s?refs=arguments&amp;project=rtmp_client" class="xa">arguments</a>) {
<a class="l" name="525" href="#525">525</a>		<span class="c">// Forward</span>
<a class="l" name="526" href="#526">526</a>		<a class="d" href="#ownerMessage">ownerMessage</a>.<a href="/source/s?defs=addEvent&amp;project=rtmp_client">addEvent</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_SEND_MESSAGE&amp;project=rtmp_client">CLIENT_SEND_MESSAGE</a>, <a class="d" href="#handler">handler</a>, <a class="d" href="#arguments">arguments</a>);
<a class="l" name="527" href="#527">527</a>		<a class="d" href="#syncEvents">syncEvents</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<b>new</b> <a href="/source/s?defs=SharedObjectEvent&amp;project=rtmp_client">SharedObjectEvent</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_SEND_MESSAGE&amp;project=rtmp_client">CLIENT_SEND_MESSAGE</a>, <a class="d" href="#handler">handler</a>, <a class="d" href="#arguments">arguments</a>));
<a class="l" name="528" href="#528">528</a>		<a class="d" href="#sendStats">sendStats</a>.<a href="/source/s?defs=incrementAndGet&amp;project=rtmp_client">incrementAndGet</a>();
<a class="l" name="529" href="#529">529</a>	}
<a class="hl" name="530" href="#530">530</a>
<a class="l" name="531" href="#531">531</a>	<span class="c">/**
<a class="l" name="532" href="#532">532</a>	 * Getter for data.
<a class="l" name="533" href="#533">533</a>	 *
<a class="l" name="534" href="#534">534</a>	 * <strong>@return</strong>  SO data as unmodifiable map
<a class="l" name="535" href="#535">535</a>	 */</span>
<a class="l" name="536" href="#536">536</a>	<b>public</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xmt" name="getData"/><a href="/source/s?refs=getData&amp;project=rtmp_client" class="xmt">getData</a>() {
<a class="l" name="537" href="#537">537</a>		<b>return</b> <a href="/source/s?defs=getAttributes&amp;project=rtmp_client">getAttributes</a>();
<a class="l" name="538" href="#538">538</a>	}
<a class="l" name="539" href="#539">539</a>
<a class="hl" name="540" href="#540">540</a>	<span class="c">/**
<a class="l" name="541" href="#541">541</a>	 * Getter for version.
<a class="l" name="542" href="#542">542</a>	 *
<a class="l" name="543" href="#543">543</a>	 * <strong>@return</strong>  SO version.
<a class="l" name="544" href="#544">544</a>	 */</span>
<a class="l" name="545" href="#545">545</a>	<b>public</b> <b>int</b> <a class="xmt" name="getVersion"/><a href="/source/s?refs=getVersion&amp;project=rtmp_client" class="xmt">getVersion</a>() {
<a class="l" name="546" href="#546">546</a>		<b>return</b> <a class="d" href="#version">version</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>();
<a class="l" name="547" href="#547">547</a>	}
<a class="l" name="548" href="#548">548</a>
<a class="l" name="549" href="#549">549</a>	<span class="c">/**
<a class="hl" name="550" href="#550">550</a>	 * Increases version by one
<a class="l" name="551" href="#551">551</a>	 */</span>
<a class="l" name="552" href="#552">552</a>	<b>private</b> <b>void</b> <a class="xmt" name="updateVersion"/><a href="/source/s?refs=updateVersion&amp;project=rtmp_client" class="xmt">updateVersion</a>() {
<a class="l" name="553" href="#553">553</a>		<a class="d" href="#version">version</a>.<a href="/source/s?defs=incrementAndGet&amp;project=rtmp_client">incrementAndGet</a>();
<a class="l" name="554" href="#554">554</a>	}
<a class="l" name="555" href="#555">555</a>
<a class="l" name="556" href="#556">556</a>	<span class="c">/**
<a class="l" name="557" href="#557">557</a>	 * Remove all attributes (clear Shared Object)
<a class="l" name="558" href="#558">558</a>	 */</span>
<a class="l" name="559" href="#559">559</a>	@<a href="/source/s?defs=Override&amp;project=rtmp_client">Override</a>
<a class="hl" name="560" href="#560">560</a>	<b>public</b> <b>void</b> <a class="xmt" name="removeAttributes"/><a href="/source/s?refs=removeAttributes&amp;project=rtmp_client" class="xmt">removeAttributes</a>() {
<a class="l" name="561" href="#561">561</a>		<span class="c">// TODO: there must be a direct way to clear the SO on the client side...</span>
<a class="l" name="562" href="#562">562</a>		<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt; <a href="/source/s?defs=names&amp;project=rtmp_client">names</a> = <a href="/source/s?defs=getAttributeNames&amp;project=rtmp_client">getAttributeNames</a>();
<a class="l" name="563" href="#563">563</a>		<b>for</b> (<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=key&amp;project=rtmp_client">key</a> : <a href="/source/s?defs=names&amp;project=rtmp_client">names</a>) {
<a class="l" name="564" href="#564">564</a>			<a class="d" href="#ownerMessage">ownerMessage</a>.<a href="/source/s?defs=addEvent&amp;project=rtmp_client">addEvent</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_DELETE_DATA&amp;project=rtmp_client">CLIENT_DELETE_DATA</a>, <a href="/source/s?defs=key&amp;project=rtmp_client">key</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="565" href="#565">565</a>			<a class="d" href="#syncEvents">syncEvents</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<b>new</b> <a href="/source/s?defs=SharedObjectEvent&amp;project=rtmp_client">SharedObjectEvent</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_DELETE_DATA&amp;project=rtmp_client">CLIENT_DELETE_DATA</a>, <a href="/source/s?defs=key&amp;project=rtmp_client">key</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>));
<a class="l" name="566" href="#566">566</a>		}
<a class="l" name="567" href="#567">567</a>		<a class="d" href="#deleteStats">deleteStats</a>.<a href="/source/s?defs=addAndGet&amp;project=rtmp_client">addAndGet</a>(<a href="/source/s?defs=names&amp;project=rtmp_client">names</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>());
<a class="l" name="568" href="#568">568</a>		<span class="c">// Clear data</span>
<a class="l" name="569" href="#569">569</a>		<b>super</b>.<a class="d" href="#removeAttributes">removeAttributes</a>();
<a class="hl" name="570" href="#570">570</a>		<span class="c">// Mark as modified</span>
<a class="l" name="571" href="#571">571</a>		<a class="d" href="#modified">modified</a> = <b>true</b>;
<a class="l" name="572" href="#572">572</a>		<span class="c">// Broadcast 'modified' event</span>
<a class="l" name="573" href="#573">573</a>		<a class="d" href="#notifyModified">notifyModified</a>();
<a class="l" name="574" href="#574">574</a>	}
<a class="l" name="575" href="#575">575</a>
<a class="l" name="576" href="#576">576</a>	<span class="c">/**
<a class="l" name="577" href="#577">577</a>	 * Register event listener
<a class="l" name="578" href="#578">578</a>	 * <strong>@param</strong> <em>listener</em>        Event listener
<a class="l" name="579" href="#579">579</a>	 */</span>
<a class="hl" name="580" href="#580">580</a>	<b>protected</b> <b>void</b> <a class="xmt" name="register"/><a href="/source/s?refs=register&amp;project=rtmp_client" class="xmt">register</a>(<a href="/source/s?defs=IEventListener&amp;project=rtmp_client">IEventListener</a> <a class="xa" name="listener"/><a href="/source/s?refs=listener&amp;project=rtmp_client" class="xa">listener</a>) {
<a class="l" name="581" href="#581">581</a>		<a class="d" href="#listeners">listeners</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=listener&amp;project=rtmp_client">listener</a>);
<a class="l" name="582" href="#582">582</a><span class="c">//		listenerStats.increment();</span>
<a class="l" name="583" href="#583">583</a>
<a class="l" name="584" href="#584">584</a>		<span class="c">// prepare response for new client</span>
<a class="l" name="585" href="#585">585</a>		<a class="d" href="#ownerMessage">ownerMessage</a>.<a href="/source/s?defs=addEvent&amp;project=rtmp_client">addEvent</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_INITIAL_DATA&amp;project=rtmp_client">CLIENT_INITIAL_DATA</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="586" href="#586">586</a>		<b>if</b> (!<a class="d" href="#isPersistentObject">isPersistentObject</a>()) {
<a class="l" name="587" href="#587">587</a>			<a class="d" href="#ownerMessage">ownerMessage</a>.<a href="/source/s?defs=addEvent&amp;project=rtmp_client">addEvent</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_CLEAR_DATA&amp;project=rtmp_client">CLIENT_CLEAR_DATA</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="588" href="#588">588</a>		}
<a class="l" name="589" href="#589">589</a>		<b>if</b> (!<a href="/source/s?defs=attributes&amp;project=rtmp_client">attributes</a>.<a href="/source/s?defs=isEmpty&amp;project=rtmp_client">isEmpty</a>()) {
<a class="hl" name="590" href="#590">590</a>			<a class="d" href="#ownerMessage">ownerMessage</a>.<a href="/source/s?defs=addEvent&amp;project=rtmp_client">addEvent</a>(<b>new</b> <a href="/source/s?defs=SharedObjectEvent&amp;project=rtmp_client">SharedObjectEvent</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_UPDATE_DATA&amp;project=rtmp_client">CLIENT_UPDATE_DATA</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>, <a href="/source/s?defs=getAttributes&amp;project=rtmp_client">getAttributes</a>()));
<a class="l" name="591" href="#591">591</a>		}
<a class="l" name="592" href="#592">592</a>
<a class="l" name="593" href="#593">593</a>		<span class="c">// we call notifyModified here to send response if we're not in a</span>
<a class="l" name="594" href="#594">594</a>		<span class="c">// beginUpdate block</span>
<a class="l" name="595" href="#595">595</a>		<a class="d" href="#notifyModified">notifyModified</a>();
<a class="l" name="596" href="#596">596</a>	}
<a class="l" name="597" href="#597">597</a>
<a class="l" name="598" href="#598">598</a>	<span class="c">/**
<a class="l" name="599" href="#599">599</a>	 * Check if shared object must be released.
<a class="hl" name="600" href="#600">600</a>	 */</span>
<a class="l" name="601" href="#601">601</a>	<b>protected</b> <b>void</b> <a class="xmt" name="checkRelease"/><a href="/source/s?refs=checkRelease&amp;project=rtmp_client" class="xmt">checkRelease</a>() {
<a class="l" name="602" href="#602">602</a>		<span class="c">//part 3 of fix for TRAC #360</span>
<a class="l" name="603" href="#603">603</a>		<b>if</b> (!<a class="d" href="#isPersistentObject">isPersistentObject</a>() &amp;&amp; <a class="d" href="#listeners">listeners</a>.<a href="/source/s?defs=isEmpty&amp;project=rtmp_client">isEmpty</a>() &amp;&amp; !<a class="d" href="#isAcquired">isAcquired</a>()) {
<a class="l" name="604" href="#604">604</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=info&amp;project=rtmp_client">info</a>(<span class="s">"Deleting shared object {} because all clients disconnected and it is no longer acquired."</span>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>);
<a class="l" name="605" href="#605">605</a>			<b>if</b> (<a href="/source/s?defs=storage&amp;project=rtmp_client">storage</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="606" href="#606">606</a>				<b>if</b> (!<a href="/source/s?defs=storage&amp;project=rtmp_client">storage</a>.<a href="/source/s?defs=remove&amp;project=rtmp_client">remove</a>(<b>this</b>)) {
<a class="l" name="607" href="#607">607</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Could not remove shared object."</span>);
<a class="l" name="608" href="#608">608</a>				}
<a class="l" name="609" href="#609">609</a>			}
<a class="hl" name="610" href="#610">610</a>			<a class="d" href="#close">close</a>();
<a class="l" name="611" href="#611">611</a>		}
<a class="l" name="612" href="#612">612</a>	}
<a class="l" name="613" href="#613">613</a>
<a class="l" name="614" href="#614">614</a>	<span class="c">/**
<a class="l" name="615" href="#615">615</a>	 * Unregister event listener
<a class="l" name="616" href="#616">616</a>	 * <strong>@param</strong> <em>listener</em>        Event listener
<a class="l" name="617" href="#617">617</a>	 */</span>
<a class="l" name="618" href="#618">618</a>	<b>protected</b> <b>void</b> <a class="xmt" name="unregister"/><a href="/source/s?refs=unregister&amp;project=rtmp_client" class="xmt">unregister</a>(<a href="/source/s?defs=IEventListener&amp;project=rtmp_client">IEventListener</a> <a class="xa" name="listener"/><a href="/source/s?refs=listener&amp;project=rtmp_client" class="xa">listener</a>) {
<a class="l" name="619" href="#619">619</a>		<a class="d" href="#listeners">listeners</a>.<a href="/source/s?defs=remove&amp;project=rtmp_client">remove</a>(<a href="/source/s?defs=listener&amp;project=rtmp_client">listener</a>);
<a class="hl" name="620" href="#620">620</a><span class="c">//		listenerStats.decrement();</span>
<a class="l" name="621" href="#621">621</a>		<a class="d" href="#checkRelease">checkRelease</a>();
<a class="l" name="622" href="#622">622</a>	}
<a class="l" name="623" href="#623">623</a>
<a class="l" name="624" href="#624">624</a>	<span class="c">/**
<a class="l" name="625" href="#625">625</a>	 * Get event listeners.
<a class="l" name="626" href="#626">626</a>	 *
<a class="l" name="627" href="#627">627</a>	 * <strong>@return</strong> Value for property 'listeners'.
<a class="l" name="628" href="#628">628</a>	 */</span>
<a class="l" name="629" href="#629">629</a>	<b>public</b> <a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>&lt;<a href="/source/s?defs=IEventListener&amp;project=rtmp_client">IEventListener</a>&gt; <a class="xmt" name="getListeners"/><a href="/source/s?refs=getListeners&amp;project=rtmp_client" class="xmt">getListeners</a>() {
<a class="hl" name="630" href="#630">630</a>		<b>return</b> <a class="d" href="#listeners">listeners</a>;
<a class="l" name="631" href="#631">631</a>	}
<a class="l" name="632" href="#632">632</a>
<a class="l" name="633" href="#633">633</a>	<span class="c">/**
<a class="l" name="634" href="#634">634</a>	 * Begin update of this Shared Object.
<a class="l" name="635" href="#635">635</a>	 * Increases number of pending update operations
<a class="l" name="636" href="#636">636</a>	 */</span>
<a class="l" name="637" href="#637">637</a>	<b>protected</b> <b>void</b> <a class="xmt" name="beginUpdate"/><a href="/source/s?refs=beginUpdate&amp;project=rtmp_client" class="xmt">beginUpdate</a>() {
<a class="l" name="638" href="#638">638</a>		<a href="/source/s?defs=beginUpdate&amp;project=rtmp_client">beginUpdate</a>(<a class="d" href="#source">source</a>);
<a class="l" name="639" href="#639">639</a>	}
<a class="hl" name="640" href="#640">640</a>
<a class="l" name="641" href="#641">641</a>	<span class="c">/**
<a class="l" name="642" href="#642">642</a>	 * Begin update of this Shared Object and setting listener
<a class="l" name="643" href="#643">643</a>	 * <strong>@param</strong> <em>listener</em>      Update with listener
<a class="l" name="644" href="#644">644</a>	 */</span>
<a class="l" name="645" href="#645">645</a>	<b>protected</b> <b>void</b> <a class="xmt" name="beginUpdate"/><a href="/source/s?refs=beginUpdate&amp;project=rtmp_client" class="xmt">beginUpdate</a>(<a href="/source/s?defs=IEventListener&amp;project=rtmp_client">IEventListener</a> <a class="xa" name="listener"/><a href="/source/s?refs=listener&amp;project=rtmp_client" class="xa">listener</a>) {
<a class="l" name="646" href="#646">646</a>		<a class="d" href="#source">source</a> = <a href="/source/s?defs=listener&amp;project=rtmp_client">listener</a>;
<a class="l" name="647" href="#647">647</a>		<span class="c">// Increase number of pending updates</span>
<a class="l" name="648" href="#648">648</a>		<a class="d" href="#updateCounter">updateCounter</a>.<a href="/source/s?defs=incrementAndGet&amp;project=rtmp_client">incrementAndGet</a>();
<a class="l" name="649" href="#649">649</a>	}
<a class="hl" name="650" href="#650">650</a>
<a class="l" name="651" href="#651">651</a>	<span class="c">/**
<a class="l" name="652" href="#652">652</a>	 * End update of this Shared Object. Decreases number of pending update operations and
<a class="l" name="653" href="#653">653</a>	 * broadcasts modified event if it is equal to zero (i.e. no more pending update operations).
<a class="l" name="654" href="#654">654</a>	 */</span>
<a class="l" name="655" href="#655">655</a>	<b>protected</b> <b>void</b> <a class="xmt" name="endUpdate"/><a href="/source/s?refs=endUpdate&amp;project=rtmp_client" class="xmt">endUpdate</a>() {
<a class="l" name="656" href="#656">656</a>		<span class="c">// Decrease number of pending updates</span>
<a class="l" name="657" href="#657">657</a>		<b>if</b> (<a class="d" href="#updateCounter">updateCounter</a>.<a href="/source/s?defs=decrementAndGet&amp;project=rtmp_client">decrementAndGet</a>() == <span class="n">0</span>) {
<a class="l" name="658" href="#658">658</a>			<a class="d" href="#notifyModified">notifyModified</a>();
<a class="l" name="659" href="#659">659</a>			<a class="d" href="#source">source</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="hl" name="660" href="#660">660</a>		}
<a class="l" name="661" href="#661">661</a>	}
<a class="l" name="662" href="#662">662</a>
<a class="l" name="663" href="#663">663</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="664" href="#664">664</a>	<b>public</b> <b>void</b> <a class="xmt" name="serialize"/><a href="/source/s?refs=serialize&amp;project=rtmp_client" class="xmt">serialize</a>(<a href="/source/s?defs=Output&amp;project=rtmp_client">Output</a> <a class="xa" name="output"/><a href="/source/s?refs=output&amp;project=rtmp_client" class="xa">output</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="665" href="#665">665</a>		<a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a> <a href="/source/s?defs=ser&amp;project=rtmp_client">ser</a> = <b>new</b> <a href="/source/s?defs=Serializer&amp;project=rtmp_client">Serializer</a>();
<a class="l" name="666" href="#666">666</a>		<a href="/source/s?defs=ser&amp;project=rtmp_client">ser</a>.<a class="d" href="#serialize">serialize</a>(<a class="d" href="#output">output</a>, <a class="d" href="#getName">getName</a>());
<a class="l" name="667" href="#667">667</a>		<a href="/source/s?defs=ser&amp;project=rtmp_client">ser</a>.<a class="d" href="#serialize">serialize</a>(<a class="d" href="#output">output</a>, <a href="/source/s?defs=getAttributes&amp;project=rtmp_client">getAttributes</a>());
<a class="l" name="668" href="#668">668</a>	}
<a class="l" name="669" href="#669">669</a>
<a class="hl" name="670" href="#670">670</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="671" href="#671">671</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>({ <span class="s">"unchecked"</span>, <span class="s">"rawtypes"</span> })
<a class="l" name="672" href="#672">672</a>	<b>public</b> <b>void</b> <a class="xmt" name="deserialize"/><a href="/source/s?refs=deserialize&amp;project=rtmp_client" class="xmt">deserialize</a>(<a href="/source/s?defs=Input&amp;project=rtmp_client">Input</a> <a class="xa" name="input"/><a href="/source/s?refs=input&amp;project=rtmp_client" class="xa">input</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="673" href="#673">673</a>		<a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a> <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a> = <b>new</b> <a href="/source/s?defs=Deserializer&amp;project=rtmp_client">Deserializer</a>();
<a class="l" name="674" href="#674">674</a>		<a href="/source/s?defs=name&amp;project=rtmp_client">name</a> = <a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.<a class="d" href="#deserialize">deserialize</a>(<a href="/source/s?defs=input&amp;project=rtmp_client">input</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>);
<a class="l" name="675" href="#675">675</a>		<a class="d" href="#persistentSO">persistentSO</a> = <a href="/source/s?defs=persistent&amp;project=rtmp_client">persistent</a> = <b>true</b>;
<a class="l" name="676" href="#676">676</a>		<b>super</b>.<a href="/source/s?defs=setAttributes&amp;project=rtmp_client">setAttributes</a>(<a href="/source/s?defs=deserializer&amp;project=rtmp_client">deserializer</a>.&lt;<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&gt; <a class="d" href="#deserialize">deserialize</a>(<a href="/source/s?defs=input&amp;project=rtmp_client">input</a>, <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>.<b>class</b>));
<a class="l" name="677" href="#677">677</a>		<a class="d" href="#ownerMessage">ownerMessage</a>.<a class="d" href="#setName">setName</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>);
<a class="l" name="678" href="#678">678</a>		<a class="d" href="#ownerMessage">ownerMessage</a>.<a href="/source/s?defs=setIsPersistent&amp;project=rtmp_client">setIsPersistent</a>(<b>true</b>);
<a class="l" name="679" href="#679">679</a>	}
<a class="hl" name="680" href="#680">680</a>
<a class="l" name="681" href="#681">681</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="682" href="#682">682</a>	<b>public</b> <b>void</b> <a class="xmt" name="setStore"/><a href="/source/s?refs=setStore&amp;project=rtmp_client" class="xmt">setStore</a>(<a href="/source/s?defs=IPersistenceStore&amp;project=rtmp_client">IPersistenceStore</a> <a class="xa" name="store"/><a href="/source/s?refs=store&amp;project=rtmp_client" class="xa">store</a>) {
<a class="l" name="683" href="#683">683</a>		<b>this</b>.<a href="/source/s?defs=storage&amp;project=rtmp_client">storage</a> = <a class="d" href="#store">store</a>;
<a class="l" name="684" href="#684">684</a>	}
<a class="l" name="685" href="#685">685</a>
<a class="l" name="686" href="#686">686</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="687" href="#687">687</a>	<b>public</b> <a href="/source/s?defs=IPersistenceStore&amp;project=rtmp_client">IPersistenceStore</a> <a class="xmt" name="getStore"/><a href="/source/s?refs=getStore&amp;project=rtmp_client" class="xmt">getStore</a>() {
<a class="l" name="688" href="#688">688</a>		<b>return</b> <a href="/source/s?defs=storage&amp;project=rtmp_client">storage</a>;
<a class="l" name="689" href="#689">689</a>	}
<a class="hl" name="690" href="#690">690</a>
<a class="l" name="691" href="#691">691</a>	<span class="c">/**
<a class="l" name="692" href="#692">692</a>	 * Deletes all the attributes and sends a clear event to all listeners. The
<a class="l" name="693" href="#693">693</a>	 * persistent data object is also removed from a persistent shared object.
<a class="l" name="694" href="#694">694</a>	 *
<a class="l" name="695" href="#695">695</a>	 * <strong>@return</strong> &lt;code&gt;true&lt;/code&gt; on success, &lt;code&gt;false&lt;/code&gt; otherwise
<a class="l" name="696" href="#696">696</a>	 */</span>
<a class="l" name="697" href="#697">697</a>	<b>protected</b> <b>boolean</b> <a class="xmt" name="clear"/><a href="/source/s?refs=clear&amp;project=rtmp_client" class="xmt">clear</a>() {
<a class="l" name="698" href="#698">698</a>		<b>super</b>.<a class="d" href="#removeAttributes">removeAttributes</a>();
<a class="l" name="699" href="#699">699</a>		<span class="c">// Send confirmation to client</span>
<a class="hl" name="700" href="#700">700</a>		<a class="d" href="#ownerMessage">ownerMessage</a>.<a href="/source/s?defs=addEvent&amp;project=rtmp_client">addEvent</a>(<a href="/source/s?defs=Type&amp;project=rtmp_client">Type</a>.<a href="/source/s?defs=CLIENT_CLEAR_DATA&amp;project=rtmp_client">CLIENT_CLEAR_DATA</a>, <a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="701" href="#701">701</a>		<a class="d" href="#notifyModified">notifyModified</a>();
<a class="l" name="702" href="#702">702</a>		<a class="d" href="#changeStats">changeStats</a>.<a href="/source/s?defs=incrementAndGet&amp;project=rtmp_client">incrementAndGet</a>();
<a class="l" name="703" href="#703">703</a>		<span class="c">// Is it clear now?</span>
<a class="l" name="704" href="#704">704</a>		<b>return</b> <b>true</b>;
<a class="l" name="705" href="#705">705</a>	}
<a class="l" name="706" href="#706">706</a>
<a class="l" name="707" href="#707">707</a>	<span class="c">/**
<a class="l" name="708" href="#708">708</a>	 * Detaches a reference from this shared object, reset it's state, this will destroy the
<a class="l" name="709" href="#709">709</a>	 * reference immediately. This is useful when you don't want to proxy a
<a class="hl" name="710" href="#710">710</a>	 * shared object any longer.
<a class="l" name="711" href="#711">711</a>	 */</span>
<a class="l" name="712" href="#712">712</a>	<b>protected</b> <b>void</b> <a class="xmt" name="close"/><a href="/source/s?refs=close&amp;project=rtmp_client" class="xmt">close</a>() {
<a class="l" name="713" href="#713">713</a>		<span class="c">// clear collections</span>
<a class="l" name="714" href="#714">714</a>		<b>super</b>.<a class="d" href="#removeAttributes">removeAttributes</a>();
<a class="l" name="715" href="#715">715</a>		<a class="d" href="#listeners">listeners</a>.<a class="d" href="#clear">clear</a>();
<a class="l" name="716" href="#716">716</a>		<a class="d" href="#syncEvents">syncEvents</a>.<a class="d" href="#clear">clear</a>();
<a class="l" name="717" href="#717">717</a>		<a class="d" href="#ownerMessage">ownerMessage</a>.<a href="/source/s?defs=getEvents&amp;project=rtmp_client">getEvents</a>().<a class="d" href="#clear">clear</a>();
<a class="l" name="718" href="#718">718</a>		<b>if</b> (<a class="d" href="#executor">executor</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="719" href="#719">719</a>    		<span class="c">//disable new tasks from being submitted</span>
<a class="hl" name="720" href="#720">720</a>    		<a class="d" href="#executor">executor</a>.<a href="/source/s?defs=shutdown&amp;project=rtmp_client">shutdown</a>();
<a class="l" name="721" href="#721">721</a>    		<b>try</b> {
<a class="l" name="722" href="#722">722</a>    			<span class="c">//wait a while for existing tasks to terminate</span>
<a class="l" name="723" href="#723">723</a>    			<b>if</b> (!<a class="d" href="#executor">executor</a>.<a href="/source/s?defs=awaitTermination&amp;project=rtmp_client">awaitTermination</a>(<span class="n">250</span>, <a href="/source/s?defs=TimeUnit&amp;project=rtmp_client">TimeUnit</a>.<a href="/source/s?defs=MILLISECONDS&amp;project=rtmp_client">MILLISECONDS</a>)) {
<a class="l" name="724" href="#724">724</a>    				<a class="d" href="#executor">executor</a>.<a href="/source/s?defs=shutdownNow&amp;project=rtmp_client">shutdownNow</a>(); <span class="c">// cancel currently executing tasks</span>
<a class="l" name="725" href="#725">725</a>    			}
<a class="l" name="726" href="#726">726</a>    		} <b>catch</b> (<a href="/source/s?defs=InterruptedException&amp;project=rtmp_client">InterruptedException</a> <a href="/source/s?defs=ie&amp;project=rtmp_client">ie</a>) {
<a class="l" name="727" href="#727">727</a>    			<span class="c">// re-cancel if current thread also interrupted</span>
<a class="l" name="728" href="#728">728</a>    			<a class="d" href="#executor">executor</a>.<a href="/source/s?defs=shutdownNow&amp;project=rtmp_client">shutdownNow</a>();
<a class="l" name="729" href="#729">729</a>    			<span class="c">// preserve interrupt status</span>
<a class="hl" name="730" href="#730">730</a>    			<a href="/source/s?defs=Thread&amp;project=rtmp_client">Thread</a>.<a href="/source/s?defs=currentThread&amp;project=rtmp_client">currentThread</a>().<a href="/source/s?defs=interrupt&amp;project=rtmp_client">interrupt</a>();
<a class="l" name="731" href="#731">731</a>    		}
<a class="l" name="732" href="#732">732</a>		}
<a class="l" name="733" href="#733">733</a>	}
<a class="l" name="734" href="#734">734</a>
<a class="l" name="735" href="#735">735</a>	<span class="c">/**
<a class="l" name="736" href="#736">736</a>	 * Prevent shared object from being released. Each call to &lt;code&gt;acquire&lt;/code&gt;
<a class="l" name="737" href="#737">737</a>	 * must be paired with a call to &lt;code&gt;release&lt;/code&gt; so the SO isn't held
<a class="l" name="738" href="#738">738</a>	 * forever. This is only valid for non-persistent SOs.
<a class="l" name="739" href="#739">739</a>	 */</span>
<a class="hl" name="740" href="#740">740</a>	<b>public</b> <b>void</b> <a class="xmt" name="acquire"/><a href="/source/s?refs=acquire&amp;project=rtmp_client" class="xmt">acquire</a>() {
<a class="l" name="741" href="#741">741</a>		<a class="d" href="#acquireCount">acquireCount</a>.<a href="/source/s?defs=incrementAndGet&amp;project=rtmp_client">incrementAndGet</a>();
<a class="l" name="742" href="#742">742</a>	}
<a class="l" name="743" href="#743">743</a>
<a class="l" name="744" href="#744">744</a>	<span class="c">/**
<a class="l" name="745" href="#745">745</a>	 * Check if shared object currently is acquired.
<a class="l" name="746" href="#746">746</a>	 *
<a class="l" name="747" href="#747">747</a>	 * <strong>@return</strong> &lt;code&gt;true&lt;/code&gt; if the SO is acquired, otherwise &lt;code&gt;false&lt;/code&gt;
<a class="l" name="748" href="#748">748</a>	 */</span>
<a class="l" name="749" href="#749">749</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="isAcquired"/><a href="/source/s?refs=isAcquired&amp;project=rtmp_client" class="xmt">isAcquired</a>() {
<a class="hl" name="750" href="#750">750</a>		<b>return</b> <a class="d" href="#acquireCount">acquireCount</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() &gt; <span class="n">0</span>;
<a class="l" name="751" href="#751">751</a>	}
<a class="l" name="752" href="#752">752</a>
<a class="l" name="753" href="#753">753</a>	<span class="c">/**
<a class="l" name="754" href="#754">754</a>	 * Release previously acquired shared object. If the SO is non-persistent,
<a class="l" name="755" href="#755">755</a>	 * no more clients are connected the SO isn't acquired any more, the data
<a class="l" name="756" href="#756">756</a>	 * is released.
<a class="l" name="757" href="#757">757</a>	 */</span>
<a class="l" name="758" href="#758">758</a>	<b>public</b> <b>void</b> <a class="xmt" name="release"/><a href="/source/s?refs=release&amp;project=rtmp_client" class="xmt">release</a>() {
<a class="l" name="759" href="#759">759</a>		<b>if</b> (<a class="d" href="#acquireCount">acquireCount</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>() == <span class="n">0</span>) {
<a class="hl" name="760" href="#760">760</a>			<b>throw</b> <b>new</b> <a href="/source/s?defs=RuntimeException&amp;project=rtmp_client">RuntimeException</a>(<span class="s">"The shared object was not acquired before."</span>);
<a class="l" name="761" href="#761">761</a>		}
<a class="l" name="762" href="#762">762</a>		<b>if</b> (<a class="d" href="#acquireCount">acquireCount</a>.<a href="/source/s?defs=decrementAndGet&amp;project=rtmp_client">decrementAndGet</a>() == <span class="n">0</span>) {
<a class="l" name="763" href="#763">763</a>			<a class="d" href="#checkRelease">checkRelease</a>();
<a class="l" name="764" href="#764">764</a>		}
<a class="l" name="765" href="#765">765</a>	}
<a class="l" name="766" href="#766">766</a>
<a class="l" name="767" href="#767">767</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="768" href="#768">768</a>	<b>public</b> <b>long</b> <a class="xmt" name="getCreationTime"/><a href="/source/s?refs=getCreationTime&amp;project=rtmp_client" class="xmt">getCreationTime</a>() {
<a class="l" name="769" href="#769">769</a>		<b>return</b> <a class="d" href="#creationTime">creationTime</a>;
<a class="hl" name="770" href="#770">770</a>	}
<a class="l" name="771" href="#771">771</a>
<a class="l" name="772" href="#772">772</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="773" href="#773">773</a>	<b>public</b> <b>int</b> <a class="xmt" name="getTotalListeners"/><a href="/source/s?refs=getTotalListeners&amp;project=rtmp_client" class="xmt">getTotalListeners</a>() {
<a class="l" name="774" href="#774">774</a><span class="c">//		return listenerStats.getTotal();</span>
<a class="l" name="775" href="#775">775</a>		<b>return</b> <span class="n">0</span>;
<a class="l" name="776" href="#776">776</a>	}
<a class="l" name="777" href="#777">777</a>
<a class="l" name="778" href="#778">778</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="779" href="#779">779</a>	<b>public</b> <b>int</b> <a class="xmt" name="getMaxListeners"/><a href="/source/s?refs=getMaxListeners&amp;project=rtmp_client" class="xmt">getMaxListeners</a>() {
<a class="hl" name="780" href="#780">780</a><span class="c">//		return listenerStats.getMax();</span>
<a class="l" name="781" href="#781">781</a>		<b>return</b> <span class="n">0</span>;
<a class="l" name="782" href="#782">782</a>	}
<a class="l" name="783" href="#783">783</a>
<a class="l" name="784" href="#784">784</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="785" href="#785">785</a>	<b>public</b> <b>int</b> <a class="xmt" name="getActiveListeners"/><a href="/source/s?refs=getActiveListeners&amp;project=rtmp_client" class="xmt">getActiveListeners</a>() {
<a class="l" name="786" href="#786">786</a><span class="c">//		return listenerStats.getCurrent();</span>
<a class="l" name="787" href="#787">787</a>		<b>return</b> <span class="n">0</span>;
<a class="l" name="788" href="#788">788</a>	}
<a class="l" name="789" href="#789">789</a>
<a class="hl" name="790" href="#790">790</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="791" href="#791">791</a>	<b>public</b> <b>int</b> <a class="xmt" name="getTotalChanges"/><a href="/source/s?refs=getTotalChanges&amp;project=rtmp_client" class="xmt">getTotalChanges</a>() {
<a class="l" name="792" href="#792">792</a>		<b>return</b> <a class="d" href="#changeStats">changeStats</a>.<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>();
<a class="l" name="793" href="#793">793</a>	}
<a class="l" name="794" href="#794">794</a>
<a class="l" name="795" href="#795">795</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="796" href="#796">796</a>	<b>public</b> <b>int</b> <a class="xmt" name="getTotalDeletes"/><a href="/source/s?refs=getTotalDeletes&amp;project=rtmp_client" class="xmt">getTotalDeletes</a>() {
<a class="l" name="797" href="#797">797</a>		<b>return</b> <a class="d" href="#deleteStats">deleteStats</a>.<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>();
<a class="l" name="798" href="#798">798</a>	}
<a class="l" name="799" href="#799">799</a>
<a class="hl" name="800" href="#800">800</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="801" href="#801">801</a>	<b>public</b> <b>int</b> <a class="xmt" name="getTotalSends"/><a href="/source/s?refs=getTotalSends&amp;project=rtmp_client" class="xmt">getTotalSends</a>() {
<a class="l" name="802" href="#802">802</a>		<b>return</b> <a class="d" href="#sendStats">sendStats</a>.<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>();
<a class="l" name="803" href="#803">803</a>	}
<a class="l" name="804" href="#804">804</a>
<a class="l" name="805" href="#805">805</a>}
<a class="l" name="806" href="#806">806</a>