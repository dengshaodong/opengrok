<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["AttributeStore",31]]],["Package","xp",[["org.red5.server",1]]],["Method","xmt",[["AttributeStore",64],["AttributeStore",72],["AttributeStore",80],["filterNull",44],["getAttribute",108],["getAttribute",123],["getAttributeNames",89],["getAttributes",98],["getBoolAttribute",219],["getByteAttribute",229],["getDoubleAttribute",239],["getIntAttribute",249],["getListAttribute",259],["getLongAttribute",269],["getMapAttribute",279],["getSetAttribute",289],["getShortAttribute",299],["getStringAttribute",309],["hasAttribute",145],["removeAttribute",198],["removeAttributes",209],["setAttribute",159],["setAttributes",179],["setAttributes",188]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Collections&amp;project=rtmp_client">Collections</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=concurrent&amp;project=rtmp_client">concurrent</a>.<a href="/source/s?defs=ConcurrentHashMap&amp;project=rtmp_client">ConcurrentHashMap</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=concurrent&amp;project=rtmp_client">concurrent</a>.<a href="/source/s?defs=ConcurrentMap&amp;project=rtmp_client">ConcurrentMap</a>;
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a><b>public</b> <b>class</b> <a class="xc" name="AttributeStore"/><a href="/source/s?refs=AttributeStore&amp;project=rtmp_client" class="xc">AttributeStore</a> <b>implements</b> <a href="/source/s?defs=ICastingAttributeStore&amp;project=rtmp_client">ICastingAttributeStore</a> {
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a>    <span class="c">/**
<a class="l" name="34" href="#34">34</a>     * Map for attributes
<a class="l" name="35" href="#35">35</a>     */</span>
<a class="l" name="36" href="#36">36</a>    <b>protected</b> <a href="/source/s?defs=ConcurrentMap&amp;project=rtmp_client">ConcurrentMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xfld" name="attributes"/><a href="/source/s?refs=attributes&amp;project=rtmp_client" class="xfld">attributes</a> = <b>new</b> <a href="/source/s?defs=ConcurrentHashMap&amp;project=rtmp_client">ConcurrentHashMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;(<span class="n">1</span>);
<a class="l" name="37" href="#37">37</a>
<a class="l" name="38" href="#38">38</a>    <span class="c">/**
<a class="l" name="39" href="#39">39</a>     * Filter &lt;code&gt;null&lt;/code&gt; keys and values from given map.
<a class="hl" name="40" href="#40">40</a>     *
<a class="l" name="41" href="#41">41</a>     * <strong>@param</strong> <em>values</em>		the map to filter
<a class="l" name="42" href="#42">42</a>     * <strong>@return</strong> filtered map
<a class="l" name="43" href="#43">43</a>     */</span>
<a class="l" name="44" href="#44">44</a>    <b>protected</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xmt" name="filterNull"/><a href="/source/s?refs=filterNull&amp;project=rtmp_client" class="xmt">filterNull</a>(<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xa" name="values"/><a href="/source/s?refs=values&amp;project=rtmp_client" class="xa">values</a>) {
<a class="l" name="45" href="#45">45</a>    	<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="l" name="46" href="#46">46</a>    	<b>for</b> (<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>.<a href="/source/s?defs=Entry&amp;project=rtmp_client">Entry</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a> : <a href="/source/s?defs=values&amp;project=rtmp_client">values</a>.<a href="/source/s?defs=entrySet&amp;project=rtmp_client">entrySet</a>()) {
<a class="l" name="47" href="#47">47</a>    		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=key&amp;project=rtmp_client">key</a> = <a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a>.<a href="/source/s?defs=getKey&amp;project=rtmp_client">getKey</a>();
<a class="l" name="48" href="#48">48</a>    		<b>if</b> (<a href="/source/s?defs=key&amp;project=rtmp_client">key</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="49" href="#49">49</a>    			<b>continue</b>;
<a class="hl" name="50" href="#50">50</a>    		}
<a class="l" name="51" href="#51">51</a>    		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="d" href="#value">value</a> = <a href="/source/s?defs=entry&amp;project=rtmp_client">entry</a>.<a href="/source/s?defs=getValue&amp;project=rtmp_client">getValue</a>();
<a class="l" name="52" href="#52">52</a>    		<b>if</b> (<a class="d" href="#value">value</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="53" href="#53">53</a>    			<b>continue</b>;
<a class="l" name="54" href="#54">54</a>    		}
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a>    		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=key&amp;project=rtmp_client">key</a>, <a class="d" href="#value">value</a>);
<a class="l" name="57" href="#57">57</a>    	}
<a class="l" name="58" href="#58">58</a>    	<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="59" href="#59">59</a>    }
<a class="hl" name="60" href="#60">60</a>
<a class="l" name="61" href="#61">61</a>    <span class="c">/**
<a class="l" name="62" href="#62">62</a>     * Creates empty attribute store. Object is not associated with a persistence storage.
<a class="l" name="63" href="#63">63</a>     */</span>
<a class="l" name="64" href="#64">64</a>    <b>public</b> <a class="xmt" name="AttributeStore"/><a href="/source/s?refs=AttributeStore&amp;project=rtmp_client" class="xmt">AttributeStore</a>() {
<a class="l" name="65" href="#65">65</a>    	<span class="c">// Nothing to do here</span>
<a class="l" name="66" href="#66">66</a>	}
<a class="l" name="67" href="#67">67</a>
<a class="l" name="68" href="#68">68</a>    <span class="c">/**
<a class="l" name="69" href="#69">69</a>     * Creates attribute store with initial values. Object is not associated with a persistence storage.
<a class="hl" name="70" href="#70">70</a>     * <strong>@param</strong> <em>values</em> map
<a class="l" name="71" href="#71">71</a>     */</span>
<a class="l" name="72" href="#72">72</a>    <b>public</b> <a class="xmt" name="AttributeStore"/><a href="/source/s?refs=AttributeStore&amp;project=rtmp_client" class="xmt">AttributeStore</a>(<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xa" name="values"/><a href="/source/s?refs=values&amp;project=rtmp_client" class="xa">values</a>) {
<a class="l" name="73" href="#73">73</a>    	<a href="/source/s?defs=setAttributes&amp;project=rtmp_client">setAttributes</a>(<a href="/source/s?defs=values&amp;project=rtmp_client">values</a>);
<a class="l" name="74" href="#74">74</a>	}
<a class="l" name="75" href="#75">75</a>
<a class="l" name="76" href="#76">76</a>    <span class="c">/**
<a class="l" name="77" href="#77">77</a>     * Creates attribute store with initial values. Object is not associated with a persistence storage.
<a class="l" name="78" href="#78">78</a>     * <strong>@param</strong> <em>values</em> map
<a class="l" name="79" href="#79">79</a>     */</span>
<a class="hl" name="80" href="#80">80</a>    <b>public</b> <a class="xmt" name="AttributeStore"/><a href="/source/s?refs=AttributeStore&amp;project=rtmp_client" class="xmt">AttributeStore</a>(<a href="/source/s?defs=IAttributeStore&amp;project=rtmp_client">IAttributeStore</a> <a class="xa" name="values"/><a href="/source/s?refs=values&amp;project=rtmp_client" class="xa">values</a>) {
<a class="l" name="81" href="#81">81</a>    	<a href="/source/s?defs=setAttributes&amp;project=rtmp_client">setAttributes</a>(<a href="/source/s?defs=values&amp;project=rtmp_client">values</a>);
<a class="l" name="82" href="#82">82</a>	}
<a class="l" name="83" href="#83">83</a>
<a class="l" name="84" href="#84">84</a>    <span class="c">/**
<a class="l" name="85" href="#85">85</a>     * Get the attribute names. The resulting set will be read-only.
<a class="l" name="86" href="#86">86</a>     *
<a class="l" name="87" href="#87">87</a>     * <strong>@return</strong> set containing all attribute names
<a class="l" name="88" href="#88">88</a>     */</span>
<a class="l" name="89" href="#89">89</a>    <b>public</b> <a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>&gt; <a class="xmt" name="getAttributeNames"/><a href="/source/s?refs=getAttributeNames&amp;project=rtmp_client" class="xmt">getAttributeNames</a>() {
<a class="hl" name="90" href="#90">90</a>        <b>return</b> <a href="/source/s?defs=Collections&amp;project=rtmp_client">Collections</a>.<a href="/source/s?defs=unmodifiableSet&amp;project=rtmp_client">unmodifiableSet</a>(<a class="d" href="#attributes">attributes</a>.<a href="/source/s?defs=keySet&amp;project=rtmp_client">keySet</a>());
<a class="l" name="91" href="#91">91</a>    }
<a class="l" name="92" href="#92">92</a>
<a class="l" name="93" href="#93">93</a>    <span class="c">/**
<a class="l" name="94" href="#94">94</a>     * Get the attributes. The resulting map will be read-only.
<a class="l" name="95" href="#95">95</a>     *
<a class="l" name="96" href="#96">96</a>     * <strong>@return</strong> map containing all attributes
<a class="l" name="97" href="#97">97</a>     */</span>
<a class="l" name="98" href="#98">98</a>    <b>public</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xmt" name="getAttributes"/><a href="/source/s?refs=getAttributes&amp;project=rtmp_client" class="xmt">getAttributes</a>() {
<a class="l" name="99" href="#99">99</a>        <b>return</b> <a href="/source/s?defs=Collections&amp;project=rtmp_client">Collections</a>.<a href="/source/s?defs=unmodifiableMap&amp;project=rtmp_client">unmodifiableMap</a>(<a class="d" href="#attributes">attributes</a>);
<a class="hl" name="100" href="#100">100</a>    }
<a class="l" name="101" href="#101">101</a>
<a class="l" name="102" href="#102">102</a>    <span class="c">/**
<a class="l" name="103" href="#103">103</a>     * Return the value for a given attribute.
<a class="l" name="104" href="#104">104</a>     *
<a class="l" name="105" href="#105">105</a>     * <strong>@param</strong> <em>name</em> the name of the attribute to get
<a class="l" name="106" href="#106">106</a>     * <strong>@return</strong> the attribute value or null if the attribute doesn't exist
<a class="l" name="107" href="#107">107</a>     */</span>
<a class="l" name="108" href="#108">108</a>    <b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="getAttribute"/><a href="/source/s?refs=getAttribute&amp;project=rtmp_client" class="xmt">getAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="l" name="109" href="#109">109</a>    	<b>if</b> (<a href="/source/s?defs=name&amp;project=rtmp_client">name</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="110" href="#110">110</a>    		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="111" href="#111">111</a>    	}
<a class="l" name="112" href="#112">112</a>        <b>return</b> <a class="d" href="#attributes">attributes</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>);
<a class="l" name="113" href="#113">113</a>    }
<a class="l" name="114" href="#114">114</a>
<a class="l" name="115" href="#115">115</a>    <span class="c">/**
<a class="l" name="116" href="#116">116</a>     * Return the value for a given attribute and set it if it doesn't exist.
<a class="l" name="117" href="#117">117</a>     *
<a class="l" name="118" href="#118">118</a>     * <strong>@param</strong> <em>name</em>         the name of the attribute to get
<a class="l" name="119" href="#119">119</a>     * <strong>@param</strong> <em>defaultValue</em> the value of the attribute to set if the attribute doesn't
<a class="hl" name="120" href="#120">120</a>     *                     exist
<a class="l" name="121" href="#121">121</a>     * <strong>@return</strong> the attribute value
<a class="l" name="122" href="#122">122</a>     */</span>
<a class="l" name="123" href="#123">123</a>    <b>public</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="getAttribute"/><a href="/source/s?refs=getAttribute&amp;project=rtmp_client" class="xmt">getAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="defaultValue"/><a href="/source/s?refs=defaultValue&amp;project=rtmp_client" class="xa">defaultValue</a>) {
<a class="l" name="124" href="#124">124</a>    	<b>if</b> (<a href="/source/s?defs=name&amp;project=rtmp_client">name</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="125" href="#125">125</a>    		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="126" href="#126">126</a>    	}
<a class="l" name="127" href="#127">127</a>    	<b>if</b> (<a class="d" href="#defaultValue">defaultValue</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="128" href="#128">128</a>    		<b>throw</b> <b>new</b> <a href="/source/s?defs=NullPointerException&amp;project=rtmp_client">NullPointerException</a>(<span class="s">"the default value may not be null"</span>);
<a class="l" name="129" href="#129">129</a>    	}
<a class="hl" name="130" href="#130">130</a>
<a class="l" name="131" href="#131">131</a>    	<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a class="d" href="#attributes">attributes</a>.<a href="/source/s?defs=putIfAbsent&amp;project=rtmp_client">putIfAbsent</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a class="d" href="#defaultValue">defaultValue</a>);
<a class="l" name="132" href="#132">132</a>    	<b>if</b> (<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="133" href="#133">133</a>    		<span class="c">// No previous value, the default has been set</span>
<a class="l" name="134" href="#134">134</a>    		<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a class="d" href="#defaultValue">defaultValue</a>;
<a class="l" name="135" href="#135">135</a>    	}
<a class="l" name="136" href="#136">136</a>    	<b>return</b> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="l" name="137" href="#137">137</a>    }
<a class="l" name="138" href="#138">138</a>
<a class="l" name="139" href="#139">139</a>    <span class="c">/**
<a class="hl" name="140" href="#140">140</a>     * Check the object has an attribute.
<a class="l" name="141" href="#141">141</a>     *
<a class="l" name="142" href="#142">142</a>     * <strong>@param</strong> <em>name</em> the name of the attribute to check
<a class="l" name="143" href="#143">143</a>     * <strong>@return</strong> true if the attribute exists otherwise false
<a class="l" name="144" href="#144">144</a>     */</span>
<a class="l" name="145" href="#145">145</a>    <b>public</b> <b>boolean</b> <a class="xmt" name="hasAttribute"/><a href="/source/s?refs=hasAttribute&amp;project=rtmp_client" class="xmt">hasAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="l" name="146" href="#146">146</a>    	<b>if</b> (<a href="/source/s?defs=name&amp;project=rtmp_client">name</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="147" href="#147">147</a>    		<b>return</b> <b>false</b>;
<a class="l" name="148" href="#148">148</a>    	}
<a class="l" name="149" href="#149">149</a>        <b>return</b> <a class="d" href="#attributes">attributes</a>.<a href="/source/s?defs=containsKey&amp;project=rtmp_client">containsKey</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>);
<a class="hl" name="150" href="#150">150</a>    }
<a class="l" name="151" href="#151">151</a>
<a class="l" name="152" href="#152">152</a>    <span class="c">/**
<a class="l" name="153" href="#153">153</a>     * Set an attribute on this object.
<a class="l" name="154" href="#154">154</a>     *
<a class="l" name="155" href="#155">155</a>     * <strong>@param</strong> <em>name</em>  the name of the attribute to change
<a class="l" name="156" href="#156">156</a>     * <strong>@param</strong> <em>value</em> the new value of the attribute
<a class="l" name="157" href="#157">157</a>     * <strong>@return</strong> true if the attribute value changed otherwise false
<a class="l" name="158" href="#158">158</a>     */</span>
<a class="l" name="159" href="#159">159</a>    <b>public</b> <b>boolean</b> <a class="xmt" name="setAttribute"/><a href="/source/s?refs=setAttribute&amp;project=rtmp_client" class="xmt">setAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=rtmp_client" class="xa">value</a>) {
<a class="hl" name="160" href="#160">160</a>        <b>if</b> (<a href="/source/s?defs=name&amp;project=rtmp_client">name</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="161" href="#161">161</a>            <b>return</b> <b>false</b>;
<a class="l" name="162" href="#162">162</a>        }
<a class="l" name="163" href="#163">163</a>
<a class="l" name="164" href="#164">164</a>        <b>if</b> (<a class="d" href="#value">value</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="165" href="#165">165</a>        	<span class="c">// Remove value</span>
<a class="l" name="166" href="#166">166</a>        	<b>return</b> (<a class="d" href="#attributes">attributes</a>.<a href="/source/s?defs=remove&amp;project=rtmp_client">remove</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>) != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="167" href="#167">167</a>        } <b>else</b> {
<a class="l" name="168" href="#168">168</a>        	<span class="c">// Update with new value</span>
<a class="l" name="169" href="#169">169</a>        	<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=previous&amp;project=rtmp_client">previous</a> = <a class="d" href="#attributes">attributes</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>, <a class="d" href="#value">value</a>);
<a class="hl" name="170" href="#170">170</a>        	<b>return</b> (<a href="/source/s?defs=previous&amp;project=rtmp_client">previous</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> || <a class="d" href="#value">value</a> == <a href="/source/s?defs=previous&amp;project=rtmp_client">previous</a> || !<a class="d" href="#value">value</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=previous&amp;project=rtmp_client">previous</a>));
<a class="l" name="171" href="#171">171</a>        }
<a class="l" name="172" href="#172">172</a>    }
<a class="l" name="173" href="#173">173</a>
<a class="l" name="174" href="#174">174</a>    <span class="c">/**
<a class="l" name="175" href="#175">175</a>     * Set multiple attributes on this object.
<a class="l" name="176" href="#176">176</a>     *
<a class="l" name="177" href="#177">177</a>     * <strong>@param</strong> <em>values</em> the attributes to set
<a class="l" name="178" href="#178">178</a>     */</span>
<a class="l" name="179" href="#179">179</a>    <b>public</b> <b>void</b> <a class="xmt" name="setAttributes"/><a href="/source/s?refs=setAttributes&amp;project=rtmp_client" class="xmt">setAttributes</a>(<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xa" name="values"/><a href="/source/s?refs=values&amp;project=rtmp_client" class="xa">values</a>) {
<a class="hl" name="180" href="#180">180</a>    	<a class="d" href="#attributes">attributes</a>.<a href="/source/s?defs=putAll&amp;project=rtmp_client">putAll</a>(<a class="d" href="#filterNull">filterNull</a>(<a href="/source/s?defs=values&amp;project=rtmp_client">values</a>));
<a class="l" name="181" href="#181">181</a>    }
<a class="l" name="182" href="#182">182</a>
<a class="l" name="183" href="#183">183</a>    <span class="c">/**
<a class="l" name="184" href="#184">184</a>     * Set multiple attributes on this object.
<a class="l" name="185" href="#185">185</a>     *
<a class="l" name="186" href="#186">186</a>     * <strong>@param</strong> <em>values</em> the attributes to set
<a class="l" name="187" href="#187">187</a>     */</span>
<a class="l" name="188" href="#188">188</a>    <b>public</b> <b>void</b> <a class="xmt" name="setAttributes"/><a href="/source/s?refs=setAttributes&amp;project=rtmp_client" class="xmt">setAttributes</a>(<a href="/source/s?defs=IAttributeStore&amp;project=rtmp_client">IAttributeStore</a> <a class="xa" name="values"/><a href="/source/s?refs=values&amp;project=rtmp_client" class="xa">values</a>) {
<a class="l" name="189" href="#189">189</a>    	<a href="/source/s?defs=setAttributes&amp;project=rtmp_client">setAttributes</a>(<a href="/source/s?defs=values&amp;project=rtmp_client">values</a>.<a class="d" href="#getAttributes">getAttributes</a>());
<a class="hl" name="190" href="#190">190</a>    }
<a class="l" name="191" href="#191">191</a>
<a class="l" name="192" href="#192">192</a>    <span class="c">/**
<a class="l" name="193" href="#193">193</a>     * Remove an attribute.
<a class="l" name="194" href="#194">194</a>     *
<a class="l" name="195" href="#195">195</a>     * <strong>@param</strong> <em>name</em> the name of the attribute to remove
<a class="l" name="196" href="#196">196</a>     * <strong>@return</strong> true if the attribute was found and removed otherwise false
<a class="l" name="197" href="#197">197</a>     */</span>
<a class="l" name="198" href="#198">198</a>    <b>public</b> <b>boolean</b> <a class="xmt" name="removeAttribute"/><a href="/source/s?refs=removeAttribute&amp;project=rtmp_client" class="xmt">removeAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="l" name="199" href="#199">199</a>        <b>if</b> (<a href="/source/s?defs=name&amp;project=rtmp_client">name</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="200" href="#200">200</a>            <b>return</b> <b>false</b>;
<a class="l" name="201" href="#201">201</a>        }
<a class="l" name="202" href="#202">202</a>
<a class="l" name="203" href="#203">203</a>        <b>return</b> (<a class="d" href="#attributes">attributes</a>.<a href="/source/s?defs=remove&amp;project=rtmp_client">remove</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>) != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>);
<a class="l" name="204" href="#204">204</a>    }
<a class="l" name="205" href="#205">205</a>
<a class="l" name="206" href="#206">206</a>    <span class="c">/**
<a class="l" name="207" href="#207">207</a>     * Remove all attributes.
<a class="l" name="208" href="#208">208</a>     */</span>
<a class="l" name="209" href="#209">209</a>    <b>public</b> <b>void</b> <a class="xmt" name="removeAttributes"/><a href="/source/s?refs=removeAttributes&amp;project=rtmp_client" class="xmt">removeAttributes</a>() {
<a class="hl" name="210" href="#210">210</a>    	<a class="d" href="#attributes">attributes</a>.<a href="/source/s?defs=clear&amp;project=rtmp_client">clear</a>();
<a class="l" name="211" href="#211">211</a>    }
<a class="l" name="212" href="#212">212</a>
<a class="l" name="213" href="#213">213</a>    <span class="c">/**
<a class="l" name="214" href="#214">214</a>     * Get Boolean attribute by name
<a class="l" name="215" href="#215">215</a>     *
<a class="l" name="216" href="#216">216</a>     * <strong>@param</strong> <em>name</em> Attribute name
<a class="l" name="217" href="#217">217</a>     * <strong>@return</strong> Attribute
<a class="l" name="218" href="#218">218</a>     */</span>
<a class="l" name="219" href="#219">219</a>    <b>public</b> <a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a> <a class="xmt" name="getBoolAttribute"/><a href="/source/s?refs=getBoolAttribute&amp;project=rtmp_client" class="xmt">getBoolAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="hl" name="220" href="#220">220</a>        <b>return</b> (<a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a>) <a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>);
<a class="l" name="221" href="#221">221</a>    }
<a class="l" name="222" href="#222">222</a>
<a class="l" name="223" href="#223">223</a>    <span class="c">/**
<a class="l" name="224" href="#224">224</a>     * Get Byte attribute by name
<a class="l" name="225" href="#225">225</a>     *
<a class="l" name="226" href="#226">226</a>     * <strong>@param</strong> <em>name</em> Attribute name
<a class="l" name="227" href="#227">227</a>     * <strong>@return</strong> Attribute
<a class="l" name="228" href="#228">228</a>     */</span>
<a class="l" name="229" href="#229">229</a>    <b>public</b> <a href="/source/s?defs=Byte&amp;project=rtmp_client">Byte</a> <a class="xmt" name="getByteAttribute"/><a href="/source/s?refs=getByteAttribute&amp;project=rtmp_client" class="xmt">getByteAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="hl" name="230" href="#230">230</a>        <b>return</b> (<a href="/source/s?defs=Byte&amp;project=rtmp_client">Byte</a>) <a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>);
<a class="l" name="231" href="#231">231</a>    }
<a class="l" name="232" href="#232">232</a>
<a class="l" name="233" href="#233">233</a>    <span class="c">/**
<a class="l" name="234" href="#234">234</a>     * Get Double attribute by name
<a class="l" name="235" href="#235">235</a>     *
<a class="l" name="236" href="#236">236</a>     * <strong>@param</strong> <em>name</em> Attribute name
<a class="l" name="237" href="#237">237</a>     * <strong>@return</strong> Attribute
<a class="l" name="238" href="#238">238</a>     */</span>
<a class="l" name="239" href="#239">239</a>    <b>public</b> <a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a> <a class="xmt" name="getDoubleAttribute"/><a href="/source/s?refs=getDoubleAttribute&amp;project=rtmp_client" class="xmt">getDoubleAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="hl" name="240" href="#240">240</a>        <b>return</b> (<a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>) <a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>);
<a class="l" name="241" href="#241">241</a>    }
<a class="l" name="242" href="#242">242</a>
<a class="l" name="243" href="#243">243</a>    <span class="c">/**
<a class="l" name="244" href="#244">244</a>     * Get Integer attribute by name
<a class="l" name="245" href="#245">245</a>     *
<a class="l" name="246" href="#246">246</a>     * <strong>@param</strong> <em>name</em> Attribute name
<a class="l" name="247" href="#247">247</a>     * <strong>@return</strong> Attribute
<a class="l" name="248" href="#248">248</a>     */</span>
<a class="l" name="249" href="#249">249</a>    <b>public</b> <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a> <a class="xmt" name="getIntAttribute"/><a href="/source/s?refs=getIntAttribute&amp;project=rtmp_client" class="xmt">getIntAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="hl" name="250" href="#250">250</a>        <b>return</b> (<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>) <a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>);
<a class="l" name="251" href="#251">251</a>    }
<a class="l" name="252" href="#252">252</a>
<a class="l" name="253" href="#253">253</a>    <span class="c">/**
<a class="l" name="254" href="#254">254</a>     * Get List attribute by name
<a class="l" name="255" href="#255">255</a>     *
<a class="l" name="256" href="#256">256</a>     * <strong>@param</strong> <em>name</em> Attribute name
<a class="l" name="257" href="#257">257</a>     * <strong>@return</strong> Attribute
<a class="l" name="258" href="#258">258</a>     */</span>
<a class="l" name="259" href="#259">259</a>    <b>public</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;?&gt; <a class="xmt" name="getListAttribute"/><a href="/source/s?refs=getListAttribute&amp;project=rtmp_client" class="xmt">getListAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="hl" name="260" href="#260">260</a>        <b>return</b> (<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;?&gt;) <a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>);
<a class="l" name="261" href="#261">261</a>    }
<a class="l" name="262" href="#262">262</a>
<a class="l" name="263" href="#263">263</a>    <span class="c">/**
<a class="l" name="264" href="#264">264</a>     * Get boolean attribute by name
<a class="l" name="265" href="#265">265</a>     *
<a class="l" name="266" href="#266">266</a>     * <strong>@param</strong> <em>name</em> Attribute name
<a class="l" name="267" href="#267">267</a>     * <strong>@return</strong> Attribute
<a class="l" name="268" href="#268">268</a>     */</span>
<a class="l" name="269" href="#269">269</a>    <b>public</b> <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a> <a class="xmt" name="getLongAttribute"/><a href="/source/s?refs=getLongAttribute&amp;project=rtmp_client" class="xmt">getLongAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="hl" name="270" href="#270">270</a>        <b>return</b> (<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>) <a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>);
<a class="l" name="271" href="#271">271</a>    }
<a class="l" name="272" href="#272">272</a>
<a class="l" name="273" href="#273">273</a>    <span class="c">/**
<a class="l" name="274" href="#274">274</a>     * Get Long attribute by name
<a class="l" name="275" href="#275">275</a>     *
<a class="l" name="276" href="#276">276</a>     * <strong>@param</strong> <em>name</em> Attribute name
<a class="l" name="277" href="#277">277</a>     * <strong>@return</strong> Attribute
<a class="l" name="278" href="#278">278</a>     */</span>
<a class="l" name="279" href="#279">279</a>    <b>public</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;?, ?&gt; <a class="xmt" name="getMapAttribute"/><a href="/source/s?refs=getMapAttribute&amp;project=rtmp_client" class="xmt">getMapAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="hl" name="280" href="#280">280</a>        <b>return</b> (<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;?, ?&gt;) <a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>);
<a class="l" name="281" href="#281">281</a>    }
<a class="l" name="282" href="#282">282</a>
<a class="l" name="283" href="#283">283</a>    <span class="c">/**
<a class="l" name="284" href="#284">284</a>     * Get Set attribute by name
<a class="l" name="285" href="#285">285</a>     *
<a class="l" name="286" href="#286">286</a>     * <strong>@param</strong> <em>name</em> Attribute name
<a class="l" name="287" href="#287">287</a>     * <strong>@return</strong> Attribute
<a class="l" name="288" href="#288">288</a>     */</span>
<a class="l" name="289" href="#289">289</a>    <b>public</b> <a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>&lt;?&gt; <a class="xmt" name="getSetAttribute"/><a href="/source/s?refs=getSetAttribute&amp;project=rtmp_client" class="xmt">getSetAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="hl" name="290" href="#290">290</a>        <b>return</b> (<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>&lt;?&gt;) <a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>);
<a class="l" name="291" href="#291">291</a>    }
<a class="l" name="292" href="#292">292</a>
<a class="l" name="293" href="#293">293</a>    <span class="c">/**
<a class="l" name="294" href="#294">294</a>     * Get Short attribute by name
<a class="l" name="295" href="#295">295</a>     *
<a class="l" name="296" href="#296">296</a>     * <strong>@param</strong> <em>name</em> Attribute name
<a class="l" name="297" href="#297">297</a>     * <strong>@return</strong> Attribute
<a class="l" name="298" href="#298">298</a>     */</span>
<a class="l" name="299" href="#299">299</a>    <b>public</b> <a href="/source/s?defs=Short&amp;project=rtmp_client">Short</a> <a class="xmt" name="getShortAttribute"/><a href="/source/s?refs=getShortAttribute&amp;project=rtmp_client" class="xmt">getShortAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="hl" name="300" href="#300">300</a>        <b>return</b> (<a href="/source/s?defs=Short&amp;project=rtmp_client">Short</a>) <a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>);
<a class="l" name="301" href="#301">301</a>    }
<a class="l" name="302" href="#302">302</a>
<a class="l" name="303" href="#303">303</a>    <span class="c">/**
<a class="l" name="304" href="#304">304</a>     * Get String attribute by name
<a class="l" name="305" href="#305">305</a>     *
<a class="l" name="306" href="#306">306</a>     * <strong>@param</strong> <em>name</em> Attribute name
<a class="l" name="307" href="#307">307</a>     * <strong>@return</strong> Attribute
<a class="l" name="308" href="#308">308</a>     */</span>
<a class="l" name="309" href="#309">309</a>    <b>public</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xmt" name="getStringAttribute"/><a href="/source/s?refs=getStringAttribute&amp;project=rtmp_client" class="xmt">getStringAttribute</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="name"/><a href="/source/s?refs=name&amp;project=rtmp_client" class="xa">name</a>) {
<a class="hl" name="310" href="#310">310</a>        <b>return</b> (<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>) <a href="/source/s?defs=getAttribute&amp;project=rtmp_client">getAttribute</a>(<a href="/source/s?defs=name&amp;project=rtmp_client">name</a>);
<a class="l" name="311" href="#311">311</a>    }
<a class="l" name="312" href="#312">312</a>}
<a class="l" name="313" href="#313">313</a>