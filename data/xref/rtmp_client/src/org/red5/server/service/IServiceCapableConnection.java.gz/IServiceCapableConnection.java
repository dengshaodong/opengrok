<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.red5.server.service",1]]],["Interface","xi",[["IServiceCapableConnection",28]]],["Method","xmt",[["invoke",33],["invoke",40],["invoke",46],["invoke",53],["invoke",60],["invoke",68],["notify",75],["notify",82],["notify",88],["notify",95]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=IConnection&amp;project=rtmp_client">IConnection</a>;
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a><span class="c">/**
<a class="l" name="25" href="#25">25</a> * Connection that has options to invoke and handle remote calls
<a class="l" name="26" href="#26">26</a> */</span>
<a class="l" name="27" href="#27">27</a><span class="c">// TODO: this should really extend IServiceInvoker</span>
<a class="l" name="28" href="#28">28</a><b>public</b> <b>interface</b> <a class="xi" name="IServiceCapableConnection"/><a href="/source/s?refs=IServiceCapableConnection&amp;project=rtmp_client" class="xi">IServiceCapableConnection</a> <b>extends</b> <a href="/source/s?defs=IConnection&amp;project=rtmp_client">IConnection</a> {
<a class="l" name="29" href="#29">29</a>    <span class="c">/**
<a class="hl" name="30" href="#30">30</a>     * Invokes service using remoting call object
<a class="l" name="31" href="#31">31</a>     * <strong>@param</strong> <em>call</em>       Service call object
<a class="l" name="32" href="#32">32</a>     */</span>
<a class="l" name="33" href="#33">33</a>    <b>void</b> <a class="xmt" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xmt">invoke</a>(<a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a> <a class="xa" name="call"/><a href="/source/s?refs=call&amp;project=rtmp_client" class="xa">call</a>);
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a>    <span class="c">/**
<a class="l" name="36" href="#36">36</a>     * Invoke service using call and channel
<a class="l" name="37" href="#37">37</a>     * <strong>@param</strong> <em>call</em>       Service call
<a class="l" name="38" href="#38">38</a>     * <strong>@param</strong> <em>channel</em>    Channel used
<a class="l" name="39" href="#39">39</a>     */</span>
<a class="hl" name="40" href="#40">40</a>    <b>void</b> <a class="xmt" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xmt">invoke</a>(<a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a> <a class="xa" name="call"/><a href="/source/s?refs=call&amp;project=rtmp_client" class="xa">call</a>, <b>int</b> <a class="xa" name="channel"/><a href="/source/s?refs=channel&amp;project=rtmp_client" class="xa">channel</a>);
<a class="l" name="41" href="#41">41</a>
<a class="l" name="42" href="#42">42</a>    <span class="c">/**
<a class="l" name="43" href="#43">43</a>     * Invoke method by name
<a class="l" name="44" href="#44">44</a>     * <strong>@param</strong> <em>method</em>     Called method name
<a class="l" name="45" href="#45">45</a>     */</span>
<a class="l" name="46" href="#46">46</a>    <b>void</b> <a class="xmt" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xmt">invoke</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="method"/><a href="/source/s?refs=method&amp;project=rtmp_client" class="xa">method</a>);
<a class="l" name="47" href="#47">47</a>
<a class="l" name="48" href="#48">48</a>    <span class="c">/**
<a class="l" name="49" href="#49">49</a>     * Invoke method by name with callback
<a class="hl" name="50" href="#50">50</a>     * <strong>@param</strong> <em>method</em>     Called method name
<a class="l" name="51" href="#51">51</a>     * <strong>@param</strong> <em>callback</em>   Callback
<a class="l" name="52" href="#52">52</a>     */</span>
<a class="l" name="53" href="#53">53</a>    <b>void</b> <a class="xmt" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xmt">invoke</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="method"/><a href="/source/s?refs=method&amp;project=rtmp_client" class="xa">method</a>, <a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> <a class="xa" name="callback"/><a href="/source/s?refs=callback&amp;project=rtmp_client" class="xa">callback</a>);
<a class="l" name="54" href="#54">54</a>
<a class="l" name="55" href="#55">55</a>    <span class="c">/**
<a class="l" name="56" href="#56">56</a>     * Invoke method with parameters
<a class="l" name="57" href="#57">57</a>     * <strong>@param</strong> <em>method</em>     Method name
<a class="l" name="58" href="#58">58</a>     * <strong>@param</strong> <em>params</em>     Invocation parameters passed to method
<a class="l" name="59" href="#59">59</a>     */</span>
<a class="hl" name="60" href="#60">60</a>    <b>void</b> <a class="xmt" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xmt">invoke</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="method"/><a href="/source/s?refs=method&amp;project=rtmp_client" class="xa">method</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xa" name="params"/><a href="/source/s?refs=params&amp;project=rtmp_client" class="xa">params</a>);
<a class="l" name="61" href="#61">61</a>
<a class="l" name="62" href="#62">62</a>    <span class="c">/**
<a class="l" name="63" href="#63">63</a>     *
<a class="l" name="64" href="#64">64</a>     * <strong>@param</strong> <em>method</em>
<a class="l" name="65" href="#65">65</a>     * <strong>@param</strong> <em>params</em>
<a class="l" name="66" href="#66">66</a>     * <strong>@param</strong> <em>callback</em>
<a class="l" name="67" href="#67">67</a>     */</span>
<a class="l" name="68" href="#68">68</a>    <b>void</b> <a class="xmt" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xmt">invoke</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="method"/><a href="/source/s?refs=method&amp;project=rtmp_client" class="xa">method</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xa" name="params"/><a href="/source/s?refs=params&amp;project=rtmp_client" class="xa">params</a>,
<a class="l" name="69" href="#69">69</a>			<a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> <a href="/source/s?defs=callback&amp;project=rtmp_client">callback</a>);
<a class="hl" name="70" href="#70">70</a>
<a class="l" name="71" href="#71">71</a>    <span class="c">/**
<a class="l" name="72" href="#72">72</a>     *
<a class="l" name="73" href="#73">73</a>     * <strong>@param</strong> <em>call</em>
<a class="l" name="74" href="#74">74</a>     */</span>
<a class="l" name="75" href="#75">75</a>    <b>void</b> <a class="xmt" name="notify"/><a href="/source/s?refs=notify&amp;project=rtmp_client" class="xmt">notify</a>(<a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a> <a class="xa" name="call"/><a href="/source/s?refs=call&amp;project=rtmp_client" class="xa">call</a>);
<a class="l" name="76" href="#76">76</a>
<a class="l" name="77" href="#77">77</a>    <span class="c">/**
<a class="l" name="78" href="#78">78</a>     *
<a class="l" name="79" href="#79">79</a>     * <strong>@param</strong> <em>call</em>
<a class="hl" name="80" href="#80">80</a>     * <strong>@param</strong> <em>channel</em>
<a class="l" name="81" href="#81">81</a>     */</span>
<a class="l" name="82" href="#82">82</a>    <b>void</b> <a class="xmt" name="notify"/><a href="/source/s?refs=notify&amp;project=rtmp_client" class="xmt">notify</a>(<a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a> <a class="xa" name="call"/><a href="/source/s?refs=call&amp;project=rtmp_client" class="xa">call</a>, <b>int</b> <a class="xa" name="channel"/><a href="/source/s?refs=channel&amp;project=rtmp_client" class="xa">channel</a>);
<a class="l" name="83" href="#83">83</a>
<a class="l" name="84" href="#84">84</a>    <span class="c">/**
<a class="l" name="85" href="#85">85</a>     *
<a class="l" name="86" href="#86">86</a>     * <strong>@param</strong> <em>method</em>
<a class="l" name="87" href="#87">87</a>     */</span>
<a class="l" name="88" href="#88">88</a>    <b>void</b> <a class="xmt" name="notify"/><a href="/source/s?refs=notify&amp;project=rtmp_client" class="xmt">notify</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="method"/><a href="/source/s?refs=method&amp;project=rtmp_client" class="xa">method</a>);
<a class="l" name="89" href="#89">89</a>
<a class="hl" name="90" href="#90">90</a>    <span class="c">/**
<a class="l" name="91" href="#91">91</a>     *
<a class="l" name="92" href="#92">92</a>     * <strong>@param</strong> <em>method</em>
<a class="l" name="93" href="#93">93</a>     * <strong>@param</strong> <em>params</em>
<a class="l" name="94" href="#94">94</a>     */</span>
<a class="l" name="95" href="#95">95</a>    <b>void</b> <a class="xmt" name="notify"/><a href="/source/s?refs=notify&amp;project=rtmp_client" class="xmt">notify</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="method"/><a href="/source/s?refs=method&amp;project=rtmp_client" class="xa">method</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xa" name="params"/><a href="/source/s?refs=params&amp;project=rtmp_client" class="xa">params</a>);
<a class="l" name="96" href="#96">96</a>
<a class="l" name="97" href="#97">97</a>}
<a class="l" name="98" href="#98">98</a>