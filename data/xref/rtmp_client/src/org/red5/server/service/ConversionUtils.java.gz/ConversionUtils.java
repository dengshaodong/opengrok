<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["ConversionUtils",49]]],["Package","xp",[["org.red5.server.service",1]]],["Method","xmt",[["convert",98],["convertArrayToList",358],["convertArrayToSet",405],["convertBeanToMap",395],["convertMapToBean",373],["convertMapToList",193],["convertNumberToWrapper",265],["convertParams",322],["convertParams",335],["convertStringToWrapper",236],["convertToArray",166],["convertToWrappedPrimitive",205],["findMethodsByNameAndNumParams",295],["newInstance",418]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=lang&amp;project=rtmp_client">lang</a>.<a href="/source/s?defs=reflect&amp;project=rtmp_client">reflect</a>.<a href="/source/s?defs=Array&amp;project=rtmp_client">Array</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=lang&amp;project=rtmp_client">lang</a>.<a href="/source/s?defs=reflect&amp;project=rtmp_client">reflect</a>.<a href="/source/s?defs=Method&amp;project=rtmp_client">Method</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Collection&amp;project=rtmp_client">Collection</a>;
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>;
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=HashSet&amp;project=rtmp_client">HashSet</a>;
<a class="l" name="28" href="#28">28</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Iterator&amp;project=rtmp_client">Iterator</a>;
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=LinkedHashMap&amp;project=rtmp_client">LinkedHashMap</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=LinkedList&amp;project=rtmp_client">LinkedList</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>;
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a><span class="c">//import org.apache.commons.beanutils.BeanMap;</span>
<a class="l" name="36" href="#36">36</a><span class="c">//import org.apache.commons.beanutils.BeanUtils;</span>
<a class="l" name="37" href="#37">37</a><span class="c">//import org.apache.commons.beanutils.ConversionException;</span>
<a class="l" name="38" href="#38">38</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=IConnection&amp;project=rtmp_client">IConnection</a>;
<a class="l" name="39" href="#39">39</a><span class="c">//import org.red5.server.api.remoting.IRemotingConnection;</span>
<a class="hl" name="40" href="#40">40</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="41" href="#41">41</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a><span class="c">/**
<a class="l" name="44" href="#44">44</a> * Misc utils for conversions
<a class="l" name="45" href="#45">45</a> *
<a class="l" name="46" href="#46">46</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="l" name="47" href="#47">47</a> * <strong>@author</strong> Luke Hubbard, Codegent Ltd (luke@codegent.com)
<a class="l" name="48" href="#48">48</a> */</span>
<a class="l" name="49" href="#49">49</a><b>public</b> <b>class</b> <a class="xc" name="ConversionUtils"/><a href="/source/s?refs=ConversionUtils&amp;project=rtmp_client" class="xc">ConversionUtils</a> {
<a class="hl" name="50" href="#50">50</a>
<a class="l" name="51" href="#51">51</a>	<b>private</b> <b>static</b> <b>final</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a class="d" href="#ConversionUtils">ConversionUtils</a>.<b>class</b>);
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>	<b>private</b> <b>static</b> <b>final</b> <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;[] <a class="xfld" name="PRIMITIVES"/><a href="/source/s?refs=PRIMITIVES&amp;project=rtmp_client" class="xfld">PRIMITIVES</a> = { <b>boolean</b>.<b>class</b>, <b>byte</b>.<b>class</b>, <b>char</b>.<b>class</b>, <b>short</b>.<b>class</b>, <b>int</b>.<b>class</b>,
<a class="l" name="54" href="#54">54</a>			<b>long</b>.<b>class</b>, <b>float</b>.<b>class</b>, <b>double</b>.<b>class</b> };
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a>	<b>private</b> <b>static</b> <b>final</b> <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;[] <a class="xfld" name="WRAPPERS"/><a href="/source/s?refs=WRAPPERS&amp;project=rtmp_client" class="xfld">WRAPPERS</a> = { <a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a>.<b>class</b>, <a href="/source/s?defs=Byte&amp;project=rtmp_client">Byte</a>.<b>class</b>, <a href="/source/s?defs=Character&amp;project=rtmp_client">Character</a>.<b>class</b>, <a href="/source/s?defs=Short&amp;project=rtmp_client">Short</a>.<b>class</b>,
<a class="l" name="57" href="#57">57</a>			<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<b>class</b>, <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>.<b>class</b>, <a href="/source/s?defs=Float&amp;project=rtmp_client">Float</a>.<b>class</b>, <a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>.<b>class</b> };
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a>	<b>private</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="NUMERIC_TYPE"/><a href="/source/s?refs=NUMERIC_TYPE&amp;project=rtmp_client" class="xfld">NUMERIC_TYPE</a> = <span class="s">"[-]?\\b\\d+\\b|[-]?\\b[0-9]*\\.?[0-9]+(?:[eE][-+]?[0-9]+)?\\b"</span>;
<a class="hl" name="60" href="#60">60</a>
<a class="l" name="61" href="#61">61</a>	<span class="c">/**
<a class="l" name="62" href="#62">62</a>	 * Parameter chains
<a class="l" name="63" href="#63">63</a>	 */</span>
<a class="l" name="64" href="#64">64</a>	<b>private</b> <b>static</b> <b>final</b> <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;[][] <a class="xfld" name="PARAMETER_CHAINS"/><a href="/source/s?refs=PARAMETER_CHAINS&amp;project=rtmp_client" class="xfld">PARAMETER_CHAINS</a> = { { <b>boolean</b>.<b>class</b>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> }, { <b>byte</b>.<b>class</b>, <a href="/source/s?defs=Short&amp;project=rtmp_client">Short</a>.<b>class</b> },
<a class="l" name="65" href="#65">65</a>			{ <b>char</b>.<b>class</b>, <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<b>class</b> }, { <b>short</b>.<b>class</b>, <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<b>class</b> }, { <b>int</b>.<b>class</b>, <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>.<b>class</b> },
<a class="l" name="66" href="#66">66</a>			{ <b>long</b>.<b>class</b>, <a href="/source/s?defs=Float&amp;project=rtmp_client">Float</a>.<b>class</b> }, { <b>float</b>.<b>class</b>, <a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>.<b>class</b> }, { <b>double</b>.<b>class</b>, <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> } };
<a class="l" name="67" href="#67">67</a>
<a class="l" name="68" href="#68">68</a>	<span class="c">/** Mapping of primitives to wrappers */</span>
<a class="l" name="69" href="#69">69</a>	<b>private</b> <b>static</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;, <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;&gt; <a class="xfld" name="primitiveMap"/><a href="/source/s?refs=primitiveMap&amp;project=rtmp_client" class="xfld">primitiveMap</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;, <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;&gt;();
<a class="hl" name="70" href="#70">70</a>
<a class="l" name="71" href="#71">71</a>	<span class="c">/** Mapping of wrappers to primitives */</span>
<a class="l" name="72" href="#72">72</a>	<b>private</b> <b>static</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;, <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;&gt; <a class="xfld" name="wrapperMap"/><a href="/source/s?refs=wrapperMap&amp;project=rtmp_client" class="xfld">wrapperMap</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;, <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;&gt;();
<a class="l" name="73" href="#73">73</a>
<a class="l" name="74" href="#74">74</a>	<span class="c">/**
<a class="l" name="75" href="#75">75</a>	 * Mapping from wrapper class to appropriate parameter types (in order)
<a class="l" name="76" href="#76">76</a>	 * Each entry is an array of Classes, the last of which is either null
<a class="l" name="77" href="#77">77</a>	 * (for no chaining) or the next class to try
<a class="l" name="78" href="#78">78</a>	 */</span>
<a class="l" name="79" href="#79">79</a>	<b>private</b> <b>static</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;, <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;[]&gt; <a class="xfld" name="parameterMap"/><a href="/source/s?refs=parameterMap&amp;project=rtmp_client" class="xfld">parameterMap</a> = <b>new</b> <a href="/source/s?defs=HashMap&amp;project=rtmp_client">HashMap</a>&lt;<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;, <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;[]&gt;();
<a class="hl" name="80" href="#80">80</a>
<a class="l" name="81" href="#81">81</a>	<b>static</b> {
<a class="l" name="82" href="#82">82</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a class="d" href="#PRIMITIVES">PRIMITIVES</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>; i++) {
<a class="l" name="83" href="#83">83</a>			<a class="d" href="#primitiveMap">primitiveMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#PRIMITIVES">PRIMITIVES</a>[i], <a class="d" href="#WRAPPERS">WRAPPERS</a>[i]);
<a class="l" name="84" href="#84">84</a>			<a class="d" href="#wrapperMap">wrapperMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#WRAPPERS">WRAPPERS</a>[i], <a class="d" href="#PRIMITIVES">PRIMITIVES</a>[i]);
<a class="l" name="85" href="#85">85</a>			<a class="d" href="#parameterMap">parameterMap</a>.<a href="/source/s?defs=put&amp;project=rtmp_client">put</a>(<a class="d" href="#WRAPPERS">WRAPPERS</a>[i], <a class="d" href="#PARAMETER_CHAINS">PARAMETER_CHAINS</a>[i]);
<a class="l" name="86" href="#86">86</a>		}
<a class="l" name="87" href="#87">87</a>	}
<a class="l" name="88" href="#88">88</a>
<a class="l" name="89" href="#89">89</a>	<span class="c">/**
<a class="hl" name="90" href="#90">90</a>	 * Convert source to given class
<a class="l" name="91" href="#91">91</a>	 * <strong>@param</strong> <em>source</em>         Source object
<a class="l" name="92" href="#92">92</a>	 * <strong>@param</strong> <em>target</em>         Target class
<a class="l" name="93" href="#93">93</a>	 * <strong>@return</strong>               Converted object
<a class="l" name="94" href="#94">94</a>	 * <strong>@throws</strong> <em>ConversionException</em>           If object can't be converted
<a class="l" name="95" href="#95">95</a>	 *
<a class="l" name="96" href="#96">96</a>	 */</span>
<a class="l" name="97" href="#97">97</a>	@<a href="/source/s?defs=SuppressWarnings&amp;project=rtmp_client">SuppressWarnings</a>({ <span class="s">"unchecked"</span>, <span class="s">"rawtypes"</span> })
<a class="l" name="98" href="#98">98</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="convert"/><a href="/source/s?refs=convert&amp;project=rtmp_client" class="xmt">convert</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>)  {
<a class="l" name="99" href="#99">99</a>		<b>if</b> (<a href="/source/s?defs=target&amp;project=rtmp_client">target</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="100" href="#100">100</a><span class="c">//			throw new ConversionException("Unable to perform conversion, target was null");</span>
<a class="l" name="101" href="#101">101</a>		}
<a class="l" name="102" href="#102">102</a>		<b>if</b> (<a href="/source/s?defs=source&amp;project=rtmp_client">source</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="103" href="#103">103</a>			<b>if</b> (<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=isPrimitive&amp;project=rtmp_client">isPrimitive</a>()) {
<a class="l" name="104" href="#104">104</a><span class="c">//				throw new ConversionException(String.format("Unable to convert null to primitive value of %s", target));</span>
<a class="l" name="105" href="#105">105</a>			}
<a class="l" name="106" href="#106">106</a>			<b>return</b> <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>;
<a class="l" name="107" href="#107">107</a>		} <b>else</b> <b>if</b> ((<a href="/source/s?defs=source&amp;project=rtmp_client">source</a> <b>instanceof</b> <a href="/source/s?defs=Float&amp;project=rtmp_client">Float</a> &amp;&amp; ((<a href="/source/s?defs=Float&amp;project=rtmp_client">Float</a>) <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>).<a href="/source/s?defs=isNaN&amp;project=rtmp_client">isNaN</a>())
<a class="l" name="108" href="#108">108</a>				|| (<a href="/source/s?defs=source&amp;project=rtmp_client">source</a> <b>instanceof</b> <a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a> &amp;&amp; ((<a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>) <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>).<a href="/source/s?defs=isNaN&amp;project=rtmp_client">isNaN</a>())) {
<a class="l" name="109" href="#109">109</a>			<span class="c">// Don't convert NaN values</span>
<a class="hl" name="110" href="#110">110</a>			<b>return</b> <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>;
<a class="l" name="111" href="#111">111</a>		}
<a class="l" name="112" href="#112">112</a>
<a class="l" name="113" href="#113">113</a>		<span class="c">//log.trace("Source: {} Target: {}", source.getClass(), target);</span>
<a class="l" name="114" href="#114">114</a>		<b>if</b> (<a href="/source/s?defs=IConnection&amp;project=rtmp_client">IConnection</a>.<b>class</b>.<a href="/source/s?defs=isAssignableFrom&amp;project=rtmp_client">isAssignableFrom</a>(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>()) &amp;&amp; (!<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=IConnection&amp;project=rtmp_client">IConnection</a>.<b>class</b>))) {
<a class="l" name="115" href="#115">115</a><span class="c">//			throw new ConversionException("IConnection must match exactly");</span>
<a class="l" name="116" href="#116">116</a>		}
<a class="l" name="117" href="#117">117</a>		<b>if</b> (<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=isInstance&amp;project=rtmp_client">isInstance</a>(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>)) {
<a class="l" name="118" href="#118">118</a>			<b>return</b> <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>;
<a class="l" name="119" href="#119">119</a>		}
<a class="hl" name="120" href="#120">120</a>		<b>if</b> (<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=isAssignableFrom&amp;project=rtmp_client">isAssignableFrom</a>(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>())) {
<a class="l" name="121" href="#121">121</a>			<b>return</b> <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>;
<a class="l" name="122" href="#122">122</a>		}
<a class="l" name="123" href="#123">123</a>		<b>if</b> (<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=isArray&amp;project=rtmp_client">isArray</a>()) {
<a class="l" name="124" href="#124">124</a><span class="c">//			return convertToArray(source, target);</span>
<a class="l" name="125" href="#125">125</a>		}
<a class="l" name="126" href="#126">126</a>		<b>if</b> (<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>)) {
<a class="l" name="127" href="#127">127</a>			<b>return</b> <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>();
<a class="l" name="128" href="#128">128</a>		}
<a class="l" name="129" href="#129">129</a>		<b>if</b> (<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=isPrimitive&amp;project=rtmp_client">isPrimitive</a>()) {
<a class="hl" name="130" href="#130">130</a>			<b>return</b> <a class="d" href="#convertToWrappedPrimitive">convertToWrappedPrimitive</a>(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>, <a class="d" href="#primitiveMap">primitiveMap</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>));
<a class="l" name="131" href="#131">131</a>		}
<a class="l" name="132" href="#132">132</a>		<b>if</b> (<a class="d" href="#wrapperMap">wrapperMap</a>.<a href="/source/s?defs=containsKey&amp;project=rtmp_client">containsKey</a>(<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>)) {
<a class="l" name="133" href="#133">133</a>			<b>return</b> <a class="d" href="#convertToWrappedPrimitive">convertToWrappedPrimitive</a>(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>, <a href="/source/s?defs=target&amp;project=rtmp_client">target</a>);
<a class="l" name="134" href="#134">134</a>		}
<a class="l" name="135" href="#135">135</a>		<b>if</b> (<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>.<b>class</b>)) {
<a class="l" name="136" href="#136">136</a>			<b>return</b> <a class="d" href="#convertBeanToMap">convertBeanToMap</a>(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>);
<a class="l" name="137" href="#137">137</a>		}
<a class="l" name="138" href="#138">138</a>		<b>if</b> (<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>.<b>class</b>) || <a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Collection&amp;project=rtmp_client">Collection</a>.<b>class</b>)) {
<a class="l" name="139" href="#139">139</a>			<b>if</b> (<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>().<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=LinkedHashMap&amp;project=rtmp_client">LinkedHashMap</a>.<b>class</b>)) {
<a class="hl" name="140" href="#140">140</a>				<b>return</b> <a class="d" href="#convertMapToList">convertMapToList</a>((<a href="/source/s?defs=LinkedHashMap&amp;project=rtmp_client">LinkedHashMap</a>&lt;?, ?&gt;) <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>);
<a class="l" name="141" href="#141">141</a>			} <b>else</b> <b>if</b> (<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>().<a href="/source/s?defs=isArray&amp;project=rtmp_client">isArray</a>()) {
<a class="l" name="142" href="#142">142</a><span class="c">//				return convertArrayToList((Object[]) source);</span>
<a class="l" name="143" href="#143">143</a>			}
<a class="l" name="144" href="#144">144</a>		}
<a class="l" name="145" href="#145">145</a>		<b>if</b> (<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>.<b>class</b>) &amp;&amp; <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>().<a href="/source/s?defs=isArray&amp;project=rtmp_client">isArray</a>()) {
<a class="l" name="146" href="#146">146</a>			<b>return</b> <a class="d" href="#convertArrayToSet">convertArrayToSet</a>((<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[]) <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>);
<a class="l" name="147" href="#147">147</a>		}
<a class="l" name="148" href="#148">148</a>		<b>if</b> (<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>.<b>class</b>) &amp;&amp; <a href="/source/s?defs=source&amp;project=rtmp_client">source</a> <b>instanceof</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>) {
<a class="l" name="149" href="#149">149</a>			<b>return</b> <b>new</b> <a href="/source/s?defs=HashSet&amp;project=rtmp_client">HashSet</a>((<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>) <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>);
<a class="hl" name="150" href="#150">150</a>		}
<a class="l" name="151" href="#151">151</a>		<span class="c">//Trac #352</span>
<a class="l" name="152" href="#152">152</a>		<b>if</b> (<a href="/source/s?defs=source&amp;project=rtmp_client">source</a> <b>instanceof</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>) {
<a class="l" name="153" href="#153">153</a><span class="c">//			return convertMapToBean((Map) source, target);</span>
<a class="l" name="154" href="#154">154</a>		}
<a class="l" name="155" href="#155">155</a><span class="c">//		throw new ConversionException(String.format("Unable to preform conversion from %s to %s", source, target));</span>
<a class="l" name="156" href="#156">156</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="157" href="#157">157</a>	}
<a class="l" name="158" href="#158">158</a>
<a class="l" name="159" href="#159">159</a>	<span class="c">/**
<a class="hl" name="160" href="#160">160</a>	 * Convert to array
<a class="l" name="161" href="#161">161</a>	 * <strong>@param</strong> <em>source</em>         Source object
<a class="l" name="162" href="#162">162</a>	 * <strong>@param</strong> <em>target</em>         Target class
<a class="l" name="163" href="#163">163</a>	 * <strong>@return</strong>               Converted object
<a class="l" name="164" href="#164">164</a>	 * <strong>@throws</strong> <em>ConversionException</em>           If object can't be converted
<a class="l" name="165" href="#165">165</a>	 */</span>
<a class="l" name="166" href="#166">166</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="convertToArray"/><a href="/source/s?refs=convertToArray&amp;project=rtmp_client" class="xmt">convertToArray</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>)  {
<a class="l" name="167" href="#167">167</a>		<b>try</b> {
<a class="l" name="168" href="#168">168</a>			<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a href="/source/s?defs=targetType&amp;project=rtmp_client">targetType</a> = <a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=getComponentType&amp;project=rtmp_client">getComponentType</a>();
<a class="l" name="169" href="#169">169</a>			<b>if</b> (<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>().<a href="/source/s?defs=isArray&amp;project=rtmp_client">isArray</a>()) {
<a class="hl" name="170" href="#170">170</a>				<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=targetInstance&amp;project=rtmp_client">targetInstance</a> = <a href="/source/s?defs=Array&amp;project=rtmp_client">Array</a>.<a class="d" href="#newInstance">newInstance</a>(<a href="/source/s?defs=targetType&amp;project=rtmp_client">targetType</a>, <a href="/source/s?defs=Array&amp;project=rtmp_client">Array</a>.<a href="/source/s?defs=getLength&amp;project=rtmp_client">getLength</a>(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>));
<a class="l" name="171" href="#171">171</a>				<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=Array&amp;project=rtmp_client">Array</a>.<a href="/source/s?defs=getLength&amp;project=rtmp_client">getLength</a>(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>); i++) {
<a class="l" name="172" href="#172">172</a>					<a href="/source/s?defs=Array&amp;project=rtmp_client">Array</a>.<a href="/source/s?defs=set&amp;project=rtmp_client">set</a>(<a href="/source/s?defs=targetInstance&amp;project=rtmp_client">targetInstance</a>, i, <a class="d" href="#convert">convert</a>(<a href="/source/s?defs=Array&amp;project=rtmp_client">Array</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>, i), <a href="/source/s?defs=targetType&amp;project=rtmp_client">targetType</a>));
<a class="l" name="173" href="#173">173</a>				}
<a class="l" name="174" href="#174">174</a>				<b>return</b> <a href="/source/s?defs=targetInstance&amp;project=rtmp_client">targetInstance</a>;
<a class="l" name="175" href="#175">175</a>			}
<a class="l" name="176" href="#176">176</a>			<b>if</b> (<a href="/source/s?defs=source&amp;project=rtmp_client">source</a> <b>instanceof</b> <a href="/source/s?defs=Collection&amp;project=rtmp_client">Collection</a>&lt;?&gt;) {
<a class="l" name="177" href="#177">177</a>				<a href="/source/s?defs=Collection&amp;project=rtmp_client">Collection</a>&lt;?&gt; <a href="/source/s?defs=sourceCollection&amp;project=rtmp_client">sourceCollection</a> = (<a href="/source/s?defs=Collection&amp;project=rtmp_client">Collection</a>&lt;?&gt;) <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>;
<a class="l" name="178" href="#178">178</a>				<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=targetInstance&amp;project=rtmp_client">targetInstance</a> = <a href="/source/s?defs=Array&amp;project=rtmp_client">Array</a>.<a class="d" href="#newInstance">newInstance</a>(<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=getComponentType&amp;project=rtmp_client">getComponentType</a>(), <a href="/source/s?defs=sourceCollection&amp;project=rtmp_client">sourceCollection</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>());
<a class="l" name="179" href="#179">179</a>				<a href="/source/s?defs=Iterator&amp;project=rtmp_client">Iterator</a>&lt;?&gt; <a href="/source/s?defs=it&amp;project=rtmp_client">it</a> = <a href="/source/s?defs=sourceCollection&amp;project=rtmp_client">sourceCollection</a>.<a href="/source/s?defs=iterator&amp;project=rtmp_client">iterator</a>();
<a class="hl" name="180" href="#180">180</a>				<b>int</b> i = <span class="n">0</span>;
<a class="l" name="181" href="#181">181</a>				<b>while</b> (<a href="/source/s?defs=it&amp;project=rtmp_client">it</a>.<a href="/source/s?defs=hasNext&amp;project=rtmp_client">hasNext</a>()) {
<a class="l" name="182" href="#182">182</a>					<a href="/source/s?defs=Array&amp;project=rtmp_client">Array</a>.<a href="/source/s?defs=set&amp;project=rtmp_client">set</a>(<a href="/source/s?defs=targetInstance&amp;project=rtmp_client">targetInstance</a>, i++, <a class="d" href="#convert">convert</a>(<a href="/source/s?defs=it&amp;project=rtmp_client">it</a>.<a href="/source/s?defs=next&amp;project=rtmp_client">next</a>(), <a href="/source/s?defs=targetType&amp;project=rtmp_client">targetType</a>));
<a class="l" name="183" href="#183">183</a>				}
<a class="l" name="184" href="#184">184</a>				<b>return</b> <a href="/source/s?defs=targetInstance&amp;project=rtmp_client">targetInstance</a>;
<a class="l" name="185" href="#185">185</a>			}
<a class="l" name="186" href="#186">186</a>			<span class="c">//throw new ConversionException("Unable to convert to array");</span>
<a class="l" name="187" href="#187">187</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> <a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>) {
<a class="l" name="188" href="#188">188</a>			<span class="c">//throw new ConversionException("Error converting to array", ex);</span>
<a class="l" name="189" href="#189">189</a>		}
<a class="hl" name="190" href="#190">190</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="191" href="#191">191</a>	}
<a class="l" name="192" href="#192">192</a>
<a class="l" name="193" href="#193">193</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a class="xmt" name="convertMapToList"/><a href="/source/s?refs=convertMapToList&amp;project=rtmp_client" class="xmt">convertMapToList</a>(<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;?, ?&gt; <a class="xa" name="map"/><a href="/source/s?refs=map&amp;project=rtmp_client" class="xa">map</a>) {
<a class="l" name="194" href="#194">194</a>		<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=list&amp;project=rtmp_client">list</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;(<a class="d" href="#map">map</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>());
<a class="l" name="195" href="#195">195</a>		<a href="/source/s?defs=list&amp;project=rtmp_client">list</a>.<a href="/source/s?defs=addAll&amp;project=rtmp_client">addAll</a>(<a class="d" href="#map">map</a>.<a href="/source/s?defs=values&amp;project=rtmp_client">values</a>());
<a class="l" name="196" href="#196">196</a>		<b>return</b> <a href="/source/s?defs=list&amp;project=rtmp_client">list</a>;
<a class="l" name="197" href="#197">197</a>	}
<a class="l" name="198" href="#198">198</a>
<a class="l" name="199" href="#199">199</a>	<span class="c">/**
<a class="hl" name="200" href="#200">200</a>	 * Convert to wrapped primitive
<a class="l" name="201" href="#201">201</a>	 * <strong>@param</strong> <em>source</em>            Source object
<a class="l" name="202" href="#202">202</a>	 * <strong>@param</strong> <em>wrapper</em>           Primitive wrapper type
<a class="l" name="203" href="#203">203</a>	 * <strong>@return</strong>                  Converted object
<a class="l" name="204" href="#204">204</a>	 */</span>
<a class="l" name="205" href="#205">205</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="convertToWrappedPrimitive"/><a href="/source/s?refs=convertToWrappedPrimitive&amp;project=rtmp_client" class="xmt">convertToWrappedPrimitive</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a class="xa" name="wrapper"/><a href="/source/s?refs=wrapper&amp;project=rtmp_client" class="xa">wrapper</a>) {
<a class="l" name="206" href="#206">206</a>		<b>if</b> (<a href="/source/s?defs=source&amp;project=rtmp_client">source</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> || <a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="207" href="#207">207</a>			<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="208" href="#208">208</a>		}
<a class="l" name="209" href="#209">209</a>		<b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=isInstance&amp;project=rtmp_client">isInstance</a>(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>)) {
<a class="hl" name="210" href="#210">210</a>			<b>return</b> <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>;
<a class="l" name="211" href="#211">211</a>		}
<a class="l" name="212" href="#212">212</a>		<b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=isAssignableFrom&amp;project=rtmp_client">isAssignableFrom</a>(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>())) {
<a class="l" name="213" href="#213">213</a>			<b>return</b> <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>;
<a class="l" name="214" href="#214">214</a>		}
<a class="l" name="215" href="#215">215</a>		<b>if</b> (<a href="/source/s?defs=source&amp;project=rtmp_client">source</a> <b>instanceof</b> <a href="/source/s?defs=Number&amp;project=rtmp_client">Number</a>) {
<a class="l" name="216" href="#216">216</a>			<b>return</b> <a class="d" href="#convertNumberToWrapper">convertNumberToWrapper</a>((<a href="/source/s?defs=Number&amp;project=rtmp_client">Number</a>) <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>, <a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>);
<a class="l" name="217" href="#217">217</a>		} <b>else</b> {
<a class="l" name="218" href="#218">218</a>			<span class="c">//ensure we dont try to convert text to a number, prevent</span>
<a class="l" name="219" href="#219">219</a>			<span class="c">//NumberFormatException</span>
<a class="hl" name="220" href="#220">220</a>			<b>if</b> (<a href="/source/s?defs=Number&amp;project=rtmp_client">Number</a>.<b>class</b>.<a href="/source/s?defs=isAssignableFrom&amp;project=rtmp_client">isAssignableFrom</a>(<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>)) {
<a class="l" name="221" href="#221">221</a>				<span class="c">//test for int or fp number</span>
<a class="l" name="222" href="#222">222</a>				<b>if</b> (!<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>().<a href="/source/s?defs=matches&amp;project=rtmp_client">matches</a>(<a class="d" href="#NUMERIC_TYPE">NUMERIC_TYPE</a>)) {
<a class="l" name="223" href="#223">223</a>					<span class="c">//throw new ConversionException(String.format("Unable to convert string %s its not a number type: %s", source, wrapper));</span>
<a class="l" name="224" href="#224">224</a>				}
<a class="l" name="225" href="#225">225</a>			}
<a class="l" name="226" href="#226">226</a>			<b>return</b> <a class="d" href="#convertStringToWrapper">convertStringToWrapper</a>(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>(), <a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>);
<a class="l" name="227" href="#227">227</a>		}
<a class="l" name="228" href="#228">228</a>	}
<a class="l" name="229" href="#229">229</a>
<a class="hl" name="230" href="#230">230</a>	<span class="c">/**
<a class="l" name="231" href="#231">231</a>	 * Convert string to primitive wrapper like Boolean or Float
<a class="l" name="232" href="#232">232</a>	 * <strong>@param</strong> <em>str</em>               String to convert
<a class="l" name="233" href="#233">233</a>	 * <strong>@param</strong> <em>wrapper</em>           Primitive wrapper type
<a class="l" name="234" href="#234">234</a>	 * <strong>@return</strong>                  Converted object
<a class="l" name="235" href="#235">235</a>	 */</span>
<a class="l" name="236" href="#236">236</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="convertStringToWrapper"/><a href="/source/s?refs=convertStringToWrapper&amp;project=rtmp_client" class="xmt">convertStringToWrapper</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="str"/><a href="/source/s?refs=str&amp;project=rtmp_client" class="xa">str</a>, <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a class="xa" name="wrapper"/><a href="/source/s?refs=wrapper&amp;project=rtmp_client" class="xa">wrapper</a>) {
<a class="l" name="237" href="#237">237</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=trace&amp;project=rtmp_client">trace</a>(<span class="s">"String: {} to wrapper: {}"</span>, <a class="d" href="#str">str</a>, <a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>);
<a class="l" name="238" href="#238">238</a>		<b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>)) {
<a class="l" name="239" href="#239">239</a>			<b>return</b> <a class="d" href="#str">str</a>;
<a class="hl" name="240" href="#240">240</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a>.<b>class</b>)) {
<a class="l" name="241" href="#241">241</a>			<b>return</b> <a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a class="d" href="#str">str</a>);
<a class="l" name="242" href="#242">242</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>.<b>class</b>)) {
<a class="l" name="243" href="#243">243</a>			<b>return</b> <a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a class="d" href="#str">str</a>);
<a class="l" name="244" href="#244">244</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>.<b>class</b>)) {
<a class="l" name="245" href="#245">245</a>			<b>return</b> <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a class="d" href="#str">str</a>);
<a class="l" name="246" href="#246">246</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Float&amp;project=rtmp_client">Float</a>.<b>class</b>)) {
<a class="l" name="247" href="#247">247</a>			<b>return</b> <a href="/source/s?defs=Float&amp;project=rtmp_client">Float</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a class="d" href="#str">str</a>);
<a class="l" name="248" href="#248">248</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<b>class</b>)) {
<a class="l" name="249" href="#249">249</a>			<b>return</b> <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a class="d" href="#str">str</a>);
<a class="hl" name="250" href="#250">250</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Short&amp;project=rtmp_client">Short</a>.<b>class</b>)) {
<a class="l" name="251" href="#251">251</a>			<b>return</b> <a href="/source/s?defs=Short&amp;project=rtmp_client">Short</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a class="d" href="#str">str</a>);
<a class="l" name="252" href="#252">252</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Byte&amp;project=rtmp_client">Byte</a>.<b>class</b>)) {
<a class="l" name="253" href="#253">253</a>			<b>return</b> <a href="/source/s?defs=Byte&amp;project=rtmp_client">Byte</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a class="d" href="#str">str</a>);
<a class="l" name="254" href="#254">254</a>		}
<a class="l" name="255" href="#255">255</a>		<span class="c">//throw new ConversionException(String.format("Unable to convert string to: %s", wrapper));</span>
<a class="l" name="256" href="#256">256</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="257" href="#257">257</a>	}
<a class="l" name="258" href="#258">258</a>
<a class="l" name="259" href="#259">259</a>	<span class="c">/**
<a class="hl" name="260" href="#260">260</a>	 * Convert number to primitive wrapper like Boolean or Float
<a class="l" name="261" href="#261">261</a>	 * <strong>@param</strong> <em>num</em>               Number to conver
<a class="l" name="262" href="#262">262</a>	 * <strong>@param</strong> <em>wrapper</em>           Primitive wrapper type
<a class="l" name="263" href="#263">263</a>	 * <strong>@return</strong>                  Converted object
<a class="l" name="264" href="#264">264</a>	 */</span>
<a class="l" name="265" href="#265">265</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="convertNumberToWrapper"/><a href="/source/s?refs=convertNumberToWrapper&amp;project=rtmp_client" class="xmt">convertNumberToWrapper</a>(<a href="/source/s?defs=Number&amp;project=rtmp_client">Number</a> <a class="xa" name="num"/><a href="/source/s?refs=num&amp;project=rtmp_client" class="xa">num</a>, <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a class="xa" name="wrapper"/><a href="/source/s?refs=wrapper&amp;project=rtmp_client" class="xa">wrapper</a>) {
<a class="l" name="266" href="#266">266</a>
<a class="l" name="267" href="#267">267</a>		<b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>.<b>class</b>)) {
<a class="l" name="268" href="#268">268</a>			<b>return</b> <a class="d" href="#num">num</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>();
<a class="l" name="269" href="#269">269</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a>.<b>class</b>)) {
<a class="hl" name="270" href="#270">270</a>			<b>return</b> <a href="/source/s?defs=Boolean&amp;project=rtmp_client">Boolean</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a class="d" href="#num">num</a>.<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>() == <span class="n">1</span>);
<a class="l" name="271" href="#271">271</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>.<b>class</b>)) {
<a class="l" name="272" href="#272">272</a>			<b>return</b> <a href="/source/s?defs=Double&amp;project=rtmp_client">Double</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a class="d" href="#num">num</a>.<a href="/source/s?defs=doubleValue&amp;project=rtmp_client">doubleValue</a>());
<a class="l" name="273" href="#273">273</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>.<b>class</b>)) {
<a class="l" name="274" href="#274">274</a>			<b>return</b> <a href="/source/s?defs=Long&amp;project=rtmp_client">Long</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a class="d" href="#num">num</a>.<a href="/source/s?defs=longValue&amp;project=rtmp_client">longValue</a>());
<a class="l" name="275" href="#275">275</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Float&amp;project=rtmp_client">Float</a>.<b>class</b>)) {
<a class="l" name="276" href="#276">276</a>			<b>return</b> <a href="/source/s?defs=Float&amp;project=rtmp_client">Float</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a class="d" href="#num">num</a>.<a href="/source/s?defs=floatValue&amp;project=rtmp_client">floatValue</a>());
<a class="l" name="277" href="#277">277</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<b>class</b>)) {
<a class="l" name="278" href="#278">278</a>			<b>return</b> <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a class="d" href="#num">num</a>.<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>());
<a class="l" name="279" href="#279">279</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Short&amp;project=rtmp_client">Short</a>.<b>class</b>)) {
<a class="hl" name="280" href="#280">280</a>			<b>return</b> <a href="/source/s?defs=Short&amp;project=rtmp_client">Short</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a class="d" href="#num">num</a>.<a href="/source/s?defs=shortValue&amp;project=rtmp_client">shortValue</a>());
<a class="l" name="281" href="#281">281</a>		} <b>else</b> <b>if</b> (<a href="/source/s?defs=wrapper&amp;project=rtmp_client">wrapper</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=Byte&amp;project=rtmp_client">Byte</a>.<b>class</b>)) {
<a class="l" name="282" href="#282">282</a>			<b>return</b> <a href="/source/s?defs=Byte&amp;project=rtmp_client">Byte</a>.<a href="/source/s?defs=valueOf&amp;project=rtmp_client">valueOf</a>(<a class="d" href="#num">num</a>.<a href="/source/s?defs=byteValue&amp;project=rtmp_client">byteValue</a>());
<a class="l" name="283" href="#283">283</a>		}
<a class="l" name="284" href="#284">284</a>		<span class="c">//throw new ConversionException(String.format("Unable to convert number to: %s", wrapper));</span>
<a class="l" name="285" href="#285">285</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="286" href="#286">286</a>	}
<a class="l" name="287" href="#287">287</a>
<a class="l" name="288" href="#288">288</a>	<span class="c">/**
<a class="l" name="289" href="#289">289</a>	 * Find method by name and number of parameters
<a class="hl" name="290" href="#290">290</a>	 * <strong>@param</strong> <em>object</em>            Object to find method on
<a class="l" name="291" href="#291">291</a>	 * <strong>@param</strong> <em>method</em>            Method name
<a class="l" name="292" href="#292">292</a>	 * <strong>@param</strong> <em>numParam</em>          Number of parameters
<a class="l" name="293" href="#293">293</a>	 * <strong>@return</strong>                  List of methods that match by name and number of parameters
<a class="l" name="294" href="#294">294</a>	 */</span>
<a class="l" name="295" href="#295">295</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Method&amp;project=rtmp_client">Method</a>&gt; <a class="xmt" name="findMethodsByNameAndNumParams"/><a href="/source/s?refs=findMethodsByNameAndNumParams&amp;project=rtmp_client" class="xmt">findMethodsByNameAndNumParams</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="object"/><a href="/source/s?refs=object&amp;project=rtmp_client" class="xa">object</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="method"/><a href="/source/s?refs=method&amp;project=rtmp_client" class="xa">method</a>, <b>int</b> <a class="xa" name="numParam"/><a href="/source/s?refs=numParam&amp;project=rtmp_client" class="xa">numParam</a>) {
<a class="l" name="296" href="#296">296</a>		<a href="/source/s?defs=LinkedList&amp;project=rtmp_client">LinkedList</a>&lt;<a href="/source/s?defs=Method&amp;project=rtmp_client">Method</a>&gt; <a href="/source/s?defs=list&amp;project=rtmp_client">list</a> = <b>new</b> <a href="/source/s?defs=LinkedList&amp;project=rtmp_client">LinkedList</a>&lt;<a href="/source/s?defs=Method&amp;project=rtmp_client">Method</a>&gt;();
<a class="l" name="297" href="#297">297</a>		<a href="/source/s?defs=Method&amp;project=rtmp_client">Method</a>[] <a href="/source/s?defs=methods&amp;project=rtmp_client">methods</a> = <a class="d" href="#object">object</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>().<a href="/source/s?defs=getMethods&amp;project=rtmp_client">getMethods</a>();
<a class="l" name="298" href="#298">298</a>		<b>for</b> (<a href="/source/s?defs=Method&amp;project=rtmp_client">Method</a> m : <a href="/source/s?defs=methods&amp;project=rtmp_client">methods</a>) {
<a class="l" name="299" href="#299">299</a><span class="c">//			log.debug("Method name: {}", m.getName());</span>
<a class="hl" name="300" href="#300">300</a>			<span class="c">//check parameter length first since this should speed things up</span>
<a class="l" name="301" href="#301">301</a>			<b>if</b> (m.<a href="/source/s?defs=getParameterTypes&amp;project=rtmp_client">getParameterTypes</a>().<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> != <a class="d" href="#numParam">numParam</a>) {
<a class="l" name="302" href="#302">302</a><span class="c">//				log.debug("Param length not the same");</span>
<a class="l" name="303" href="#303">303</a>				<b>continue</b>;
<a class="l" name="304" href="#304">304</a>			}
<a class="l" name="305" href="#305">305</a>			<span class="c">//now try to match the name</span>
<a class="l" name="306" href="#306">306</a>			<b>if</b> (!m.<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>().<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a class="d" href="#method">method</a>)) {
<a class="l" name="307" href="#307">307</a><span class="c">//				log.debug("Method name not the same");</span>
<a class="l" name="308" href="#308">308</a>				<b>continue</b>;
<a class="l" name="309" href="#309">309</a>			}
<a class="hl" name="310" href="#310">310</a>			<a href="/source/s?defs=list&amp;project=rtmp_client">list</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(m);
<a class="l" name="311" href="#311">311</a>		}
<a class="l" name="312" href="#312">312</a>		<b>return</b> <a href="/source/s?defs=list&amp;project=rtmp_client">list</a>;
<a class="l" name="313" href="#313">313</a>	}
<a class="l" name="314" href="#314">314</a>
<a class="l" name="315" href="#315">315</a>	<span class="c">/**
<a class="l" name="316" href="#316">316</a>	 * Convert parameters using methods of this utility class
<a class="l" name="317" href="#317">317</a>	 * <strong>@param</strong> <em>source</em>                Array of source object
<a class="l" name="318" href="#318">318</a>	 * <strong>@param</strong> <em>target</em>                Array of target classes
<a class="l" name="319" href="#319">319</a>	 * <strong>@return</strong>                      Array of converted objects
<a class="hl" name="320" href="#320">320</a>	 * <strong>@throws</strong> <em>ConversionException</em>  If object can't be converted
<a class="l" name="321" href="#321">321</a>	 */</span>
<a class="l" name="322" href="#322">322</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xmt" name="convertParams"/><a href="/source/s?refs=convertParams&amp;project=rtmp_client" class="xmt">convertParams</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;[] <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>)  {
<a class="l" name="323" href="#323">323</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a href="/source/s?defs=converted&amp;project=rtmp_client">converted</a> = <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>];
<a class="l" name="324" href="#324">324</a>		<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>; i++) {
<a class="l" name="325" href="#325">325</a>			<a href="/source/s?defs=converted&amp;project=rtmp_client">converted</a>[i] = <a class="d" href="#convert">convert</a>(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>[i], <a href="/source/s?defs=target&amp;project=rtmp_client">target</a>[i]);
<a class="l" name="326" href="#326">326</a>		}
<a class="l" name="327" href="#327">327</a>		<b>return</b> <a href="/source/s?defs=converted&amp;project=rtmp_client">converted</a>;
<a class="l" name="328" href="#328">328</a>	}
<a class="l" name="329" href="#329">329</a>
<a class="hl" name="330" href="#330">330</a>	<span class="c">/**
<a class="l" name="331" href="#331">331</a>	 * Convert parameters using methods of this utility class
<a class="l" name="332" href="#332">332</a>	 * <strong>@param</strong> <em>source</em>                Array of source object
<a class="l" name="333" href="#333">333</a>	 * <strong>@return</strong>                      Array of converted objects
<a class="l" name="334" href="#334">334</a>	 */</span>
<a class="l" name="335" href="#335">335</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;[] <a class="xmt" name="convertParams"/><a href="/source/s?refs=convertParams&amp;project=rtmp_client" class="xmt">convertParams</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>) {
<a class="l" name="336" href="#336">336</a>		<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;[] <a href="/source/s?defs=converted&amp;project=rtmp_client">converted</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="337" href="#337">337</a>		<b>if</b> (<a href="/source/s?defs=source&amp;project=rtmp_client">source</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="338" href="#338">338</a>			<a href="/source/s?defs=converted&amp;project=rtmp_client">converted</a> = <b>new</b> <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;[<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>];
<a class="l" name="339" href="#339">339</a>			<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>; i++) {
<a class="hl" name="340" href="#340">340</a>				<b>if</b> (<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>[i] != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="341" href="#341">341</a>					<a href="/source/s?defs=converted&amp;project=rtmp_client">converted</a>[i] = <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>[i].<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>();
<a class="l" name="342" href="#342">342</a>				} <b>else</b> {
<a class="l" name="343" href="#343">343</a>					<a href="/source/s?defs=converted&amp;project=rtmp_client">converted</a>[i] = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="344" href="#344">344</a>				}
<a class="l" name="345" href="#345">345</a>			}
<a class="l" name="346" href="#346">346</a>		} <b>else</b> {
<a class="l" name="347" href="#347">347</a>			<a href="/source/s?defs=converted&amp;project=rtmp_client">converted</a> = <b>new</b> <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt;[<span class="n">0</span>];
<a class="l" name="348" href="#348">348</a>		}
<a class="l" name="349" href="#349">349</a>		<b>return</b> <a href="/source/s?defs=converted&amp;project=rtmp_client">converted</a>;
<a class="hl" name="350" href="#350">350</a>	}
<a class="l" name="351" href="#351">351</a>
<a class="l" name="352" href="#352">352</a>	<span class="c">/**
<a class="l" name="353" href="#353">353</a>	 *
<a class="l" name="354" href="#354">354</a>	 * <strong>@param</strong> <em>source</em> source arra
<a class="l" name="355" href="#355">355</a>	 * <strong>@return</strong> list
<a class="l" name="356" href="#356">356</a>	 * <strong>@throws</strong> <em>ConversionException</em> on failure
<a class="l" name="357" href="#357">357</a>	 */</span>
<a class="l" name="358" href="#358">358</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;?&gt; <a class="xmt" name="convertArrayToList"/><a href="/source/s?refs=convertArrayToList&amp;project=rtmp_client" class="xmt">convertArrayToList</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>)  {
<a class="l" name="359" href="#359">359</a>		<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=list&amp;project=rtmp_client">list</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;(<a href="/source/s?defs=source&amp;project=rtmp_client">source</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>);
<a class="hl" name="360" href="#360">360</a>		<b>for</b> (<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=element&amp;project=rtmp_client">element</a> : <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>) {
<a class="l" name="361" href="#361">361</a>			<a href="/source/s?defs=list&amp;project=rtmp_client">list</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=element&amp;project=rtmp_client">element</a>);
<a class="l" name="362" href="#362">362</a>		}
<a class="l" name="363" href="#363">363</a>		<b>return</b> <a href="/source/s?defs=list&amp;project=rtmp_client">list</a>;
<a class="l" name="364" href="#364">364</a>	}
<a class="l" name="365" href="#365">365</a>
<a class="l" name="366" href="#366">366</a>	<span class="c">/**
<a class="l" name="367" href="#367">367</a>	 * Convert map to bean
<a class="l" name="368" href="#368">368</a>	 * <strong>@param</strong> <em>source</em>                Source map
<a class="l" name="369" href="#369">369</a>	 * <strong>@param</strong> <em>target</em>                Target class
<a class="hl" name="370" href="#370">370</a>	 * <strong>@return</strong>                      Bean of that class
<a class="l" name="371" href="#371">371</a>	 * <strong>@throws</strong> <em>ConversionException</em> on failure
<a class="l" name="372" href="#372">372</a>	 */</span>
<a class="l" name="373" href="#373">373</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="convertMapToBean"/><a href="/source/s?refs=convertMapToBean&amp;project=rtmp_client" class="xmt">convertMapToBean</a>(<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;?, ?&gt; <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>, <a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a class="xa" name="target"/><a href="/source/s?refs=target&amp;project=rtmp_client" class="xa">target</a>)  {
<a class="l" name="374" href="#374">374</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=bean&amp;project=rtmp_client">bean</a> = <a class="d" href="#newInstance">newInstance</a>(<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=getClass&amp;project=rtmp_client">getClass</a>().<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>());
<a class="l" name="375" href="#375">375</a>		<b>if</b> (<a href="/source/s?defs=bean&amp;project=rtmp_client">bean</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="376" href="#376">376</a>			<span class="c">//try with just the target name as specified in Trac #352</span>
<a class="l" name="377" href="#377">377</a>			<a href="/source/s?defs=bean&amp;project=rtmp_client">bean</a> = <a class="d" href="#newInstance">newInstance</a>(<a href="/source/s?defs=target&amp;project=rtmp_client">target</a>.<a href="/source/s?defs=getName&amp;project=rtmp_client">getName</a>());
<a class="l" name="378" href="#378">378</a>			<b>if</b> (<a href="/source/s?defs=bean&amp;project=rtmp_client">bean</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="379" href="#379">379</a>				<span class="c">//throw new ConversionException("Unable to create bean using empty constructor");</span>
<a class="hl" name="380" href="#380">380</a>			}
<a class="l" name="381" href="#381">381</a>		}
<a class="l" name="382" href="#382">382</a>		<b>try</b> {
<a class="l" name="383" href="#383">383</a><span class="c">//			BeanUtils.populate(bean, source);</span>
<a class="l" name="384" href="#384">384</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> e) {
<a class="l" name="385" href="#385">385</a><span class="c">//			throw new ConversionException("Error populating bean", e);</span>
<a class="l" name="386" href="#386">386</a>		}
<a class="l" name="387" href="#387">387</a>		<b>return</b> <a href="/source/s?defs=bean&amp;project=rtmp_client">bean</a>;
<a class="l" name="388" href="#388">388</a>	}
<a class="l" name="389" href="#389">389</a>
<a class="hl" name="390" href="#390">390</a>	<span class="c">/**
<a class="l" name="391" href="#391">391</a>	 * Convert bean to map
<a class="l" name="392" href="#392">392</a>	 * <strong>@param</strong> <em>source</em>      Source bean
<a class="l" name="393" href="#393">393</a>	 * <strong>@return</strong>            Converted map
<a class="l" name="394" href="#394">394</a>	 */</span>
<a class="l" name="395" href="#395">395</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;?, ?&gt; <a class="xmt" name="convertBeanToMap"/><a href="/source/s?refs=convertBeanToMap&amp;project=rtmp_client" class="xmt">convertBeanToMap</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>) {
<a class="l" name="396" href="#396">396</a><span class="c">//		return new BeanMap(source);</span>
<a class="l" name="397" href="#397">397</a>		<b>return</b> <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="398" href="#398">398</a>	}
<a class="l" name="399" href="#399">399</a>
<a class="hl" name="400" href="#400">400</a>	<span class="c">/**
<a class="l" name="401" href="#401">401</a>	 * Convert array to set, removing duplicates
<a class="l" name="402" href="#402">402</a>	 * <strong>@param</strong> <em>source</em>      Source array
<a class="l" name="403" href="#403">403</a>	 * <strong>@return</strong>            Set
<a class="l" name="404" href="#404">404</a>	 */</span>
<a class="l" name="405" href="#405">405</a>	<b>public</b> <b>static</b> <a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>&lt;?&gt; <a class="xmt" name="convertArrayToSet"/><a href="/source/s?refs=convertArrayToSet&amp;project=rtmp_client" class="xmt">convertArrayToSet</a>(<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xa" name="source"/><a href="/source/s?refs=source&amp;project=rtmp_client" class="xa">source</a>) {
<a class="l" name="406" href="#406">406</a>		<a href="/source/s?defs=Set&amp;project=rtmp_client">Set</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=set&amp;project=rtmp_client">set</a> = <b>new</b> <a href="/source/s?defs=HashSet&amp;project=rtmp_client">HashSet</a>&lt;<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt;();
<a class="l" name="407" href="#407">407</a>		<b>for</b> (<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=element&amp;project=rtmp_client">element</a> : <a href="/source/s?defs=source&amp;project=rtmp_client">source</a>) {
<a class="l" name="408" href="#408">408</a>			<a href="/source/s?defs=set&amp;project=rtmp_client">set</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a href="/source/s?defs=element&amp;project=rtmp_client">element</a>);
<a class="l" name="409" href="#409">409</a>		}
<a class="hl" name="410" href="#410">410</a>		<b>return</b> <a href="/source/s?defs=set&amp;project=rtmp_client">set</a>;
<a class="l" name="411" href="#411">411</a>	}
<a class="l" name="412" href="#412">412</a>
<a class="l" name="413" href="#413">413</a>	<span class="c">/**
<a class="l" name="414" href="#414">414</a>	 * Create new class instance
<a class="l" name="415" href="#415">415</a>	 * <strong>@param</strong> <em>className</em>   Class name; may not be loaded by JVM yet
<a class="l" name="416" href="#416">416</a>	 * <strong>@return</strong>            Instance of given class
<a class="l" name="417" href="#417">417</a>	 */</span>
<a class="l" name="418" href="#418">418</a>	<b>protected</b> <b>static</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xmt" name="newInstance"/><a href="/source/s?refs=newInstance&amp;project=rtmp_client" class="xmt">newInstance</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="className"/><a href="/source/s?refs=className&amp;project=rtmp_client" class="xa">className</a>) {
<a class="l" name="419" href="#419">419</a>		<a href="/source/s?defs=ClassLoader&amp;project=rtmp_client">ClassLoader</a> <a href="/source/s?defs=cl&amp;project=rtmp_client">cl</a> =  <a href="/source/s?defs=Thread&amp;project=rtmp_client">Thread</a>.<a href="/source/s?defs=currentThread&amp;project=rtmp_client">currentThread</a>().<a href="/source/s?defs=getContextClassLoader&amp;project=rtmp_client">getContextClassLoader</a>();
<a class="hl" name="420" href="#420">420</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Conversion utils classloader: {}"</span>, <a href="/source/s?defs=cl&amp;project=rtmp_client">cl</a>);
<a class="l" name="421" href="#421">421</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=instance&amp;project=rtmp_client">instance</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="422" href="#422">422</a>		<b>try</b> {
<a class="l" name="423" href="#423">423</a>			<a href="/source/s?defs=Class&amp;project=rtmp_client">Class</a>&lt;?&gt; <a href="/source/s?defs=clazz&amp;project=rtmp_client">clazz</a> = <a href="/source/s?defs=cl&amp;project=rtmp_client">cl</a>.<a href="/source/s?defs=loadClass&amp;project=rtmp_client">loadClass</a>(<a class="d" href="#className">className</a>);
<a class="l" name="424" href="#424">424</a>			<a href="/source/s?defs=instance&amp;project=rtmp_client">instance</a> = <a href="/source/s?defs=clazz&amp;project=rtmp_client">clazz</a>.<a class="d" href="#newInstance">newInstance</a>();
<a class="l" name="425" href="#425">425</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> <a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>) {
<a class="l" name="426" href="#426">426</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error loading class: {}"</span>, <a class="d" href="#className">className</a>, <a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>);
<a class="l" name="427" href="#427">427</a>		}
<a class="l" name="428" href="#428">428</a>		<b>return</b> <a href="/source/s?defs=instance&amp;project=rtmp_client">instance</a>;
<a class="l" name="429" href="#429">429</a>	}
<a class="hl" name="430" href="#430">430</a>
<a class="l" name="431" href="#431">431</a>}
<a class="l" name="432" href="#432">432</a>