<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["ServiceInvoker",42]]],["Package","xp",[["org.red5.server.service",1]]],["Method","xmt",[["invoke",117]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a class="d" href="#service">service</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">/*
<a class="l" name="4" href="#4">4</a> * RED5 Open Source Flash Server - <a href="http://code.google.com/p/red5/">http://code.google.com/p/red5/</a>
<a class="l" name="5" href="#5">5</a> *
<a class="l" name="6" href="#6">6</a> * Copyright (c) 2006-2010 by respective authors (see below). All rights reserved.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * This library is free software; you can redistribute it <a href="/source/s?path=and/">and</a>/<a href="/source/s?path=and/or">or</a> modify it under the
<a class="l" name="9" href="#9">9</a> * terms of the GNU Lesser General Public License as published by the Free Software
<a class="hl" name="10" href="#10">10</a> * Foundation; either version 2.1 of the License, or (at your option) any later
<a class="l" name="11" href="#11">11</a> * version.
<a class="l" name="12" href="#12">12</a> *
<a class="l" name="13" href="#13">13</a> * This library is distributed in the hope that it will be useful, but WITHOUT ANY
<a class="l" name="14" href="#14">14</a> * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
<a class="l" name="15" href="#15">15</a> * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * You should have received a copy of the GNU Lesser General Public License along
<a class="l" name="18" href="#18">18</a> * with this library; if not, write to the Free Software Foundation, Inc.,
<a class="l" name="19" href="#19">19</a> * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
<a class="hl" name="20" href="#20">20</a> */</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=lang&amp;project=rtmp_client">lang</a>.<a href="/source/s?defs=reflect&amp;project=rtmp_client">reflect</a>.<a href="/source/s?defs=InvocationTargetException&amp;project=rtmp_client">InvocationTargetException</a>;
<a class="l" name="23" href="#23">23</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=lang&amp;project=rtmp_client">lang</a>.<a href="/source/s?defs=reflect&amp;project=rtmp_client">reflect</a>.<a href="/source/s?defs=Method&amp;project=rtmp_client">Method</a>;
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Arrays&amp;project=rtmp_client">Arrays</a>;
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Collections&amp;project=rtmp_client">Collections</a>;
<a class="l" name="26" href="#26">26</a><span class="c">//import java.util.HashSet;</span>
<a class="l" name="27" href="#27">27</a><span class="c">//import java.util.Set;</span>
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=annotations&amp;project=rtmp_client">annotations</a>.<a href="/source/s?defs=DeclarePrivate&amp;project=rtmp_client">DeclarePrivate</a>;
<a class="hl" name="30" href="#30">30</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=annotations&amp;project=rtmp_client">annotations</a>.<a href="/source/s?defs=DeclareProtected&amp;project=rtmp_client">DeclareProtected</a>;
<a class="l" name="31" href="#31">31</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=IConnection&amp;project=rtmp_client">IConnection</a>;
<a class="l" name="32" href="#32">32</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=Red5&amp;project=rtmp_client">Red5</a>;
<a class="l" name="33" href="#33">33</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="34" href="#34">34</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="35" href="#35">35</a>
<a class="l" name="36" href="#36">36</a><span class="c">/**
<a class="l" name="37" href="#37">37</a> * Makes remote calls, invoking services, resolves service handlers
<a class="l" name="38" href="#38">38</a> *
<a class="l" name="39" href="#39">39</a> * <strong>@author</strong> The Red5 Project (red5@osflash.org)
<a class="hl" name="40" href="#40">40</a> * <strong>@author</strong> Luke Hubbard, Codegent Ltd (luke@codegent.com)
<a class="l" name="41" href="#41">41</a> */</span>
<a class="l" name="42" href="#42">42</a><b>public</b> <b>class</b> <a class="xc" name="ServiceInvoker"/><a href="/source/s?refs=ServiceInvoker&amp;project=rtmp_client" class="xc">ServiceInvoker</a> <b>implements</b> <a href="/source/s?defs=IServiceInvoker&amp;project=rtmp_client">IServiceInvoker</a> {
<a class="l" name="43" href="#43">43</a>
<a class="l" name="44" href="#44">44</a>	<span class="c">/**
<a class="l" name="45" href="#45">45</a>	 * Logger
<a class="l" name="46" href="#46">46</a>	 */</span>
<a class="l" name="47" href="#47">47</a>	<b>private</b> <b>static</b> <b>final</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a class="d" href="#ServiceInvoker">ServiceInvoker</a>.<b>class</b>);
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>	<span class="c">/**
<a class="hl" name="50" href="#50">50</a>	 * Service name
<a class="l" name="51" href="#51">51</a>	 */</span>
<a class="l" name="52" href="#52">52</a>	<b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="SERVICE_NAME"/><a href="/source/s?refs=SERVICE_NAME&amp;project=rtmp_client" class="xfld">SERVICE_NAME</a> = <span class="s">"serviceInvoker"</span>;
<a class="l" name="53" href="#53">53</a>
<a class="l" name="54" href="#54">54</a>	<span class="c">/**
<a class="l" name="55" href="#55">55</a>	 * Service resolvers set
<a class="l" name="56" href="#56">56</a>	 */</span>
<a class="l" name="57" href="#57">57</a><span class="c">//	private Set&lt;IServiceResolver&gt; serviceResolvers = new HashSet&lt;IServiceResolver&gt;();</span>
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a>	<span class="c">/**
<a class="hl" name="60" href="#60">60</a>	 * Setter for service resolvers.
<a class="l" name="61" href="#61">61</a>	 *
<a class="l" name="62" href="#62">62</a>	 * <strong>@param</strong> <em>resolvers</em> Service resolvers
<a class="l" name="63" href="#63">63</a>	 */</span>
<a class="l" name="64" href="#64">64</a><span class="c">//	public void setServiceResolvers(Set&lt;IServiceResolver&gt; resolvers) {</span>
<a class="l" name="65" href="#65">65</a><span class="c">//		serviceResolvers = resolvers;</span>
<a class="l" name="66" href="#66">66</a><span class="c">//	}</span>
<a class="l" name="67" href="#67">67</a>
<a class="l" name="68" href="#68">68</a>	<span class="c">/**
<a class="l" name="69" href="#69">69</a>	 * Lookup a handler for the passed service name in the given scope.
<a class="hl" name="70" href="#70">70</a>	 *
<a class="l" name="71" href="#71">71</a>	 * <strong>@param</strong> <em>scope</em>
<a class="l" name="72" href="#72">72</a>	 *            Scope
<a class="l" name="73" href="#73">73</a>	 * <strong>@param</strong> <em>serviceName</em>
<a class="l" name="74" href="#74">74</a>	 *            Service name
<a class="l" name="75" href="#75">75</a>	 * <strong>@return</strong> Service handler
<a class="l" name="76" href="#76">76</a>	 */</span>
<a class="l" name="77" href="#77">77</a><span class="c">//	private Object getServiceHandler(IScope scope, String serviceName) {</span>
<a class="l" name="78" href="#78">78</a><span class="c">//		// Get application scope handler first</span>
<a class="l" name="79" href="#79">79</a><span class="c">//		Object service = scope.getHandler();</span>
<a class="hl" name="80" href="#80">80</a><span class="c">//		if (serviceName == null || serviceName.equals("")) {</span>
<a class="l" name="81" href="#81">81</a><span class="c">//			// No service requested, return application scope handler</span>
<a class="l" name="82" href="#82">82</a><span class="c">//			return service;</span>
<a class="l" name="83" href="#83">83</a><span class="c">//		}</span>
<a class="l" name="84" href="#84">84</a><span class="c">//</span>
<a class="l" name="85" href="#85">85</a><span class="c">//		// Search service resolver that knows about service name</span>
<a class="l" name="86" href="#86">86</a><span class="c">//		for (IServiceResolver resolver : serviceResolvers) {</span>
<a class="l" name="87" href="#87">87</a><span class="c">//			service = resolver.resolveService(scope, serviceName);</span>
<a class="l" name="88" href="#88">88</a><span class="c">//			if (service != null) {</span>
<a class="l" name="89" href="#89">89</a><span class="c">//				return service;</span>
<a class="hl" name="90" href="#90">90</a><span class="c">//			}</span>
<a class="l" name="91" href="#91">91</a><span class="c">//		}</span>
<a class="l" name="92" href="#92">92</a><span class="c">//</span>
<a class="l" name="93" href="#93">93</a><span class="c">//		// Requested service does not exist.</span>
<a class="l" name="94" href="#94">94</a><span class="c">//		return null;</span>
<a class="l" name="95" href="#95">95</a><span class="c">//	}</span>
<a class="l" name="96" href="#96">96</a>
<a class="l" name="97" href="#97">97</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="98" href="#98">98</a><span class="c">//	public boolean invoke(IServiceCall call, IScope scope) {</span>
<a class="l" name="99" href="#99">99</a><span class="c">//		String serviceName = call.getServiceName();</span>
<a class="hl" name="100" href="#100">100</a><span class="c">//		log.trace("Service name {}", serviceName);</span>
<a class="l" name="101" href="#101">101</a><span class="c">//		Object service = getServiceHandler(scope, serviceName);</span>
<a class="l" name="102" href="#102">102</a><span class="c">//		if (service == null) {</span>
<a class="l" name="103" href="#103">103</a><span class="c">//			// Exception must be thrown if service was not found</span>
<a class="l" name="104" href="#104">104</a><span class="c">//			call.setException(new ServiceNotFoundException(serviceName));</span>
<a class="l" name="105" href="#105">105</a><span class="c">//			// Set call status</span>
<a class="l" name="106" href="#106">106</a><span class="c">//			call.setStatus(Call.STATUS_SERVICE_NOT_FOUND);</span>
<a class="l" name="107" href="#107">107</a><span class="c">//			log.warn("Service not found: {}", serviceName);</span>
<a class="l" name="108" href="#108">108</a><span class="c">//			return false;</span>
<a class="l" name="109" href="#109">109</a><span class="c">//		} else {</span>
<a class="hl" name="110" href="#110">110</a><span class="c">//			log.trace("Service found: {}", serviceName);</span>
<a class="l" name="111" href="#111">111</a><span class="c">//		}</span>
<a class="l" name="112" href="#112">112</a><span class="c">//		// Invoke if everything is ok</span>
<a class="l" name="113" href="#113">113</a><span class="c">//		return invoke(call, service);</span>
<a class="l" name="114" href="#114">114</a><span class="c">//	}</span>
<a class="l" name="115" href="#115">115</a>
<a class="l" name="116" href="#116">116</a>	<span class="c">/** {<strong>@inheritDoc</strong>} */</span>
<a class="l" name="117" href="#117">117</a>	<b>public</b> <b>boolean</b> <a class="xmt" name="invoke"/><a href="/source/s?refs=invoke&amp;project=rtmp_client" class="xmt">invoke</a>(<a href="/source/s?defs=IServiceCall&amp;project=rtmp_client">IServiceCall</a> <a class="xa" name="call"/><a href="/source/s?refs=call&amp;project=rtmp_client" class="xa">call</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a class="xa" name="service"/><a href="/source/s?refs=service&amp;project=rtmp_client" class="xa">service</a>) {
<a class="l" name="118" href="#118">118</a>		<a href="/source/s?defs=IConnection&amp;project=rtmp_client">IConnection</a> <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> = <a href="/source/s?defs=Red5&amp;project=rtmp_client">Red5</a>.<a href="/source/s?defs=getConnectionLocal&amp;project=rtmp_client">getConnectionLocal</a>();
<a class="l" name="119" href="#119">119</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=methodName&amp;project=rtmp_client">methodName</a> = <a class="d" href="#call">call</a>.<a href="/source/s?defs=getServiceMethodName&amp;project=rtmp_client">getServiceMethodName</a>();
<a class="hl" name="120" href="#120">120</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Service: {} method name: {}"</span>, <a class="d" href="#call">call</a>.<a href="/source/s?defs=getServiceName&amp;project=rtmp_client">getServiceName</a>(), <a href="/source/s?defs=methodName&amp;project=rtmp_client">methodName</a>);
<a class="l" name="121" href="#121">121</a>		<span class="c">//pull off the prefixes since java doesnt allow this on a method name</span>
<a class="l" name="122" href="#122">122</a>		<b>if</b> (<a href="/source/s?defs=methodName&amp;project=rtmp_client">methodName</a>.<a href="/source/s?defs=charAt&amp;project=rtmp_client">charAt</a>(<span class="n">0</span>) == <span class="s">'@'</span>) {
<a class="l" name="123" href="#123">123</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Method name contained an illegal prefix, it will be removed: {}"</span>, <a href="/source/s?defs=methodName&amp;project=rtmp_client">methodName</a>);
<a class="l" name="124" href="#124">124</a>			<a href="/source/s?defs=methodName&amp;project=rtmp_client">methodName</a> = <a href="/source/s?defs=methodName&amp;project=rtmp_client">methodName</a>.<a href="/source/s?defs=substring&amp;project=rtmp_client">substring</a>(<span class="n">1</span>);
<a class="l" name="125" href="#125">125</a>		}
<a class="l" name="126" href="#126">126</a>
<a class="l" name="127" href="#127">127</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a href="/source/s?defs=args&amp;project=rtmp_client">args</a> = <a class="d" href="#call">call</a>.<a href="/source/s?defs=getArguments&amp;project=rtmp_client">getArguments</a>();
<a class="l" name="128" href="#128">128</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a href="/source/s?defs=argsWithConnection&amp;project=rtmp_client">argsWithConnection</a>;
<a class="l" name="129" href="#129">129</a>		<b>if</b> (<a href="/source/s?defs=args&amp;project=rtmp_client">args</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="hl" name="130" href="#130">130</a>			<a href="/source/s?defs=argsWithConnection&amp;project=rtmp_client">argsWithConnection</a> = <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[<a href="/source/s?defs=args&amp;project=rtmp_client">args</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> + <span class="n">1</span>];
<a class="l" name="131" href="#131">131</a>			<a href="/source/s?defs=argsWithConnection&amp;project=rtmp_client">argsWithConnection</a>[<span class="n">0</span>] = <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>;
<a class="l" name="132" href="#132">132</a>			<b>for</b> (<b>int</b> i = <span class="n">0</span>; i &lt; <a href="/source/s?defs=args&amp;project=rtmp_client">args</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a>; i++) {
<a class="l" name="133" href="#133">133</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"\t{} =&gt; {}"</span>, i, <a href="/source/s?defs=args&amp;project=rtmp_client">args</a>[i]);
<a class="l" name="134" href="#134">134</a>				<a href="/source/s?defs=argsWithConnection&amp;project=rtmp_client">argsWithConnection</a>[i + <span class="n">1</span>] = <a href="/source/s?defs=args&amp;project=rtmp_client">args</a>[i];
<a class="l" name="135" href="#135">135</a>			}
<a class="l" name="136" href="#136">136</a>		} <b>else</b> {
<a class="l" name="137" href="#137">137</a>			<a href="/source/s?defs=argsWithConnection&amp;project=rtmp_client">argsWithConnection</a> = <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] { <a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a> };
<a class="l" name="138" href="#138">138</a>		}
<a class="l" name="139" href="#139">139</a>
<a class="hl" name="140" href="#140">140</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a href="/source/s?defs=methodResult&amp;project=rtmp_client">methodResult</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="l" name="141" href="#141">141</a>		<span class="c">// First, search for method with the connection as first parameter.</span>
<a class="l" name="142" href="#142">142</a>		<a href="/source/s?defs=methodResult&amp;project=rtmp_client">methodResult</a> = <a href="/source/s?defs=ServiceUtils&amp;project=rtmp_client">ServiceUtils</a>.<a href="/source/s?defs=findMethodWithExactParameters&amp;project=rtmp_client">findMethodWithExactParameters</a>(<a class="d" href="#service">service</a>, <a href="/source/s?defs=methodName&amp;project=rtmp_client">methodName</a>, <a href="/source/s?defs=argsWithConnection&amp;project=rtmp_client">argsWithConnection</a>);
<a class="l" name="143" href="#143">143</a>		<b>if</b> (<a href="/source/s?defs=methodResult&amp;project=rtmp_client">methodResult</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> == <span class="n">0</span> || <a href="/source/s?defs=methodResult&amp;project=rtmp_client">methodResult</a>[<span class="n">0</span>] == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="144" href="#144">144</a>			<span class="c">// Second, search for method without the connection as first</span>
<a class="l" name="145" href="#145">145</a>			<span class="c">// parameter.</span>
<a class="l" name="146" href="#146">146</a>			<a href="/source/s?defs=methodResult&amp;project=rtmp_client">methodResult</a> = <a href="/source/s?defs=ServiceUtils&amp;project=rtmp_client">ServiceUtils</a>.<a href="/source/s?defs=findMethodWithExactParameters&amp;project=rtmp_client">findMethodWithExactParameters</a>(<a class="d" href="#service">service</a>, <a href="/source/s?defs=methodName&amp;project=rtmp_client">methodName</a>, <a href="/source/s?defs=args&amp;project=rtmp_client">args</a>);
<a class="l" name="147" href="#147">147</a>			<b>if</b> (<a href="/source/s?defs=methodResult&amp;project=rtmp_client">methodResult</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> == <span class="n">0</span> || <a href="/source/s?defs=methodResult&amp;project=rtmp_client">methodResult</a>[<span class="n">0</span>] == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="148" href="#148">148</a>				<span class="c">// Third, search for method with the connection as first</span>
<a class="l" name="149" href="#149">149</a>				<span class="c">// parameter in a list argument.</span>
<a class="hl" name="150" href="#150">150</a>				<a href="/source/s?defs=methodResult&amp;project=rtmp_client">methodResult</a> = <a href="/source/s?defs=ServiceUtils&amp;project=rtmp_client">ServiceUtils</a>.<a href="/source/s?defs=findMethodWithListParameters&amp;project=rtmp_client">findMethodWithListParameters</a>(<a class="d" href="#service">service</a>, <a href="/source/s?defs=methodName&amp;project=rtmp_client">methodName</a>, <a href="/source/s?defs=argsWithConnection&amp;project=rtmp_client">argsWithConnection</a>);
<a class="l" name="151" href="#151">151</a>				<b>if</b> (<a href="/source/s?defs=methodResult&amp;project=rtmp_client">methodResult</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> == <span class="n">0</span> || <a href="/source/s?defs=methodResult&amp;project=rtmp_client">methodResult</a>[<span class="n">0</span>] == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="152" href="#152">152</a>					<span class="c">// Fourth, search for method without the connection as first</span>
<a class="l" name="153" href="#153">153</a>					<span class="c">// parameter in a list argument.</span>
<a class="l" name="154" href="#154">154</a>					<a href="/source/s?defs=methodResult&amp;project=rtmp_client">methodResult</a> = <a href="/source/s?defs=ServiceUtils&amp;project=rtmp_client">ServiceUtils</a>.<a href="/source/s?defs=findMethodWithListParameters&amp;project=rtmp_client">findMethodWithListParameters</a>(<a class="d" href="#service">service</a>, <a href="/source/s?defs=methodName&amp;project=rtmp_client">methodName</a>, <a href="/source/s?defs=args&amp;project=rtmp_client">args</a>);
<a class="l" name="155" href="#155">155</a>					<b>if</b> (<a href="/source/s?defs=methodResult&amp;project=rtmp_client">methodResult</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> == <span class="n">0</span> || <a href="/source/s?defs=methodResult&amp;project=rtmp_client">methodResult</a>[<span class="n">0</span>] == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="156" href="#156">156</a>						<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Method {} with parameters {} not found in {}"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[]{<a href="/source/s?defs=methodName&amp;project=rtmp_client">methodName</a>, (<a href="/source/s?defs=args&amp;project=rtmp_client">args</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> ? <a href="/source/s?defs=Collections&amp;project=rtmp_client">Collections</a>.<a href="/source/s?defs=EMPTY_LIST&amp;project=rtmp_client">EMPTY_LIST</a> : <a href="/source/s?defs=Arrays&amp;project=rtmp_client">Arrays</a>.<a href="/source/s?defs=asList&amp;project=rtmp_client">asList</a>(<a href="/source/s?defs=args&amp;project=rtmp_client">args</a>)), <a class="d" href="#service">service</a>});
<a class="l" name="157" href="#157">157</a>						<a class="d" href="#call">call</a>.<a href="/source/s?defs=setStatus&amp;project=rtmp_client">setStatus</a>(<a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>.<a href="/source/s?defs=STATUS_METHOD_NOT_FOUND&amp;project=rtmp_client">STATUS_METHOD_NOT_FOUND</a>);
<a class="l" name="158" href="#158">158</a>						<b>if</b> (<a href="/source/s?defs=args&amp;project=rtmp_client">args</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> &amp;&amp; <a href="/source/s?defs=args&amp;project=rtmp_client">args</a>.<a href="/source/s?defs=length&amp;project=rtmp_client">length</a> &gt; <span class="n">0</span>) {
<a class="l" name="159" href="#159">159</a>							<a class="d" href="#call">call</a>.<a href="/source/s?defs=setException&amp;project=rtmp_client">setException</a>(<b>new</b> <a href="/source/s?defs=MethodNotFoundException&amp;project=rtmp_client">MethodNotFoundException</a>(<a href="/source/s?defs=methodName&amp;project=rtmp_client">methodName</a>, <a href="/source/s?defs=args&amp;project=rtmp_client">args</a>));
<a class="hl" name="160" href="#160">160</a>						} <b>else</b> {
<a class="l" name="161" href="#161">161</a>							<a class="d" href="#call">call</a>.<a href="/source/s?defs=setException&amp;project=rtmp_client">setException</a>(<b>new</b> <a href="/source/s?defs=MethodNotFoundException&amp;project=rtmp_client">MethodNotFoundException</a>(<a href="/source/s?defs=methodName&amp;project=rtmp_client">methodName</a>));
<a class="l" name="162" href="#162">162</a>						}
<a class="l" name="163" href="#163">163</a>						<b>return</b> <b>false</b>;
<a class="l" name="164" href="#164">164</a>					}
<a class="l" name="165" href="#165">165</a>				}
<a class="l" name="166" href="#166">166</a>			}
<a class="l" name="167" href="#167">167</a>		}
<a class="l" name="168" href="#168">168</a>
<a class="l" name="169" href="#169">169</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>;
<a class="hl" name="170" href="#170">170</a>		<a href="/source/s?defs=Method&amp;project=rtmp_client">Method</a> <a href="/source/s?defs=method&amp;project=rtmp_client">method</a> = (<a href="/source/s?defs=Method&amp;project=rtmp_client">Method</a>) <a href="/source/s?defs=methodResult&amp;project=rtmp_client">methodResult</a>[<span class="n">0</span>];
<a class="l" name="171" href="#171">171</a>		<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a href="/source/s?defs=params&amp;project=rtmp_client">params</a> = (<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[]) <a href="/source/s?defs=methodResult&amp;project=rtmp_client">methodResult</a>[<span class="n">1</span>];
<a class="l" name="172" href="#172">172</a>
<a class="l" name="173" href="#173">173</a>		<b>try</b> {
<a class="l" name="174" href="#174">174</a>			<b>if</b> (<a href="/source/s?defs=method&amp;project=rtmp_client">method</a>.<a href="/source/s?defs=isAnnotationPresent&amp;project=rtmp_client">isAnnotationPresent</a>(<a href="/source/s?defs=DeclarePrivate&amp;project=rtmp_client">DeclarePrivate</a>.<b>class</b>)) {
<a class="l" name="175" href="#175">175</a>				<span class="c">// Method may not be called by clients.</span>
<a class="l" name="176" href="#176">176</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Method {} is declared private."</span>, <a href="/source/s?defs=method&amp;project=rtmp_client">method</a>);
<a class="l" name="177" href="#177">177</a>				<b>throw</b> <b>new</b> <a href="/source/s?defs=NotAllowedException&amp;project=rtmp_client">NotAllowedException</a>(<span class="s">"you are not allowed to execute this method"</span>);
<a class="l" name="178" href="#178">178</a>			}
<a class="l" name="179" href="#179">179</a>
<a class="hl" name="180" href="#180">180</a>			<b>final</b> <a href="/source/s?defs=DeclareProtected&amp;project=rtmp_client">DeclareProtected</a> <a href="/source/s?defs=annotation&amp;project=rtmp_client">annotation</a> = <a href="/source/s?defs=method&amp;project=rtmp_client">method</a>.<a href="/source/s?defs=getAnnotation&amp;project=rtmp_client">getAnnotation</a>(<a href="/source/s?defs=DeclareProtected&amp;project=rtmp_client">DeclareProtected</a>.<b>class</b>);
<a class="l" name="181" href="#181">181</a>			<b>if</b> (<a href="/source/s?defs=annotation&amp;project=rtmp_client">annotation</a> != <a href="/source/s?defs=null&amp;project=rtmp_client">null</a>) {
<a class="l" name="182" href="#182">182</a>				<b>if</b> (!<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=getClient&amp;project=rtmp_client">getClient</a>().<a href="/source/s?defs=hasPermission&amp;project=rtmp_client">hasPermission</a>(<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>, <a href="/source/s?defs=annotation&amp;project=rtmp_client">annotation</a>.<a href="/source/s?defs=permission&amp;project=rtmp_client">permission</a>())) {
<a class="l" name="183" href="#183">183</a>					<span class="c">// Client doesn't have required permission</span>
<a class="l" name="184" href="#184">184</a>					<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Client {} doesn't have required permission {} to call {}"</span>, <b>new</b> <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[]{<a href="/source/s?defs=conn&amp;project=rtmp_client">conn</a>.<a href="/source/s?defs=getClient&amp;project=rtmp_client">getClient</a>(), <a href="/source/s?defs=annotation&amp;project=rtmp_client">annotation</a>.<a href="/source/s?defs=permission&amp;project=rtmp_client">permission</a>(), <a href="/source/s?defs=method&amp;project=rtmp_client">method</a>});
<a class="l" name="185" href="#185">185</a>					<b>throw</b> <b>new</b> <a href="/source/s?defs=NotAllowedException&amp;project=rtmp_client">NotAllowedException</a>(<span class="s">"you are not allowed to execute this method"</span>);
<a class="l" name="186" href="#186">186</a>				}
<a class="l" name="187" href="#187">187</a>			}
<a class="l" name="188" href="#188">188</a>
<a class="l" name="189" href="#189">189</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"Invoking method: {}"</span>, <a href="/source/s?defs=method&amp;project=rtmp_client">method</a>.<a href="/source/s?defs=toString&amp;project=rtmp_client">toString</a>());
<a class="hl" name="190" href="#190">190</a>
<a class="l" name="191" href="#191">191</a>			<b>if</b> (<a href="/source/s?defs=method&amp;project=rtmp_client">method</a>.<a href="/source/s?defs=getReturnType&amp;project=rtmp_client">getReturnType</a>() == <a href="/source/s?defs=Void&amp;project=rtmp_client">Void</a>.<b>class</b>) {
<a class="l" name="192" href="#192">192</a>				<a href="/source/s?defs=method&amp;project=rtmp_client">method</a>.<a class="d" href="#invoke">invoke</a>(<a class="d" href="#service">service</a>, <a href="/source/s?defs=params&amp;project=rtmp_client">params</a>);
<a class="l" name="193" href="#193">193</a>				<a class="d" href="#call">call</a>.<a href="/source/s?defs=setStatus&amp;project=rtmp_client">setStatus</a>(<a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>.<a href="/source/s?defs=STATUS_SUCCESS_VOID&amp;project=rtmp_client">STATUS_SUCCESS_VOID</a>);
<a class="l" name="194" href="#194">194</a>			} <b>else</b> {
<a class="l" name="195" href="#195">195</a>				<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a href="/source/s?defs=method&amp;project=rtmp_client">method</a>.<a class="d" href="#invoke">invoke</a>(<a class="d" href="#service">service</a>, <a href="/source/s?defs=params&amp;project=rtmp_client">params</a>);
<a class="l" name="196" href="#196">196</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"result: {}"</span>, <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>);
<a class="l" name="197" href="#197">197</a>				<a class="d" href="#call">call</a>.<a href="/source/s?defs=setStatus&amp;project=rtmp_client">setStatus</a>(<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> == <a href="/source/s?defs=null&amp;project=rtmp_client">null</a> ? <a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>.<a href="/source/s?defs=STATUS_SUCCESS_NULL&amp;project=rtmp_client">STATUS_SUCCESS_NULL</a> : <a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>.<a href="/source/s?defs=STATUS_SUCCESS_RESULT&amp;project=rtmp_client">STATUS_SUCCESS_RESULT</a>);
<a class="l" name="198" href="#198">198</a>			}
<a class="l" name="199" href="#199">199</a>			<b>if</b> (<a class="d" href="#call">call</a> <b>instanceof</b> <a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a>) {
<a class="hl" name="200" href="#200">200</a>				((<a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a>) <a class="d" href="#call">call</a>).<a href="/source/s?defs=setResult&amp;project=rtmp_client">setResult</a>(<a href="/source/s?defs=result&amp;project=rtmp_client">result</a>);
<a class="l" name="201" href="#201">201</a>			}
<a class="l" name="202" href="#202">202</a>		} <b>catch</b> (<a href="/source/s?defs=NotAllowedException&amp;project=rtmp_client">NotAllowedException</a> e) {
<a class="l" name="203" href="#203">203</a>			<a class="d" href="#call">call</a>.<a href="/source/s?defs=setException&amp;project=rtmp_client">setException</a>(e);
<a class="l" name="204" href="#204">204</a>			<a class="d" href="#call">call</a>.<a href="/source/s?defs=setStatus&amp;project=rtmp_client">setStatus</a>(<a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>.<a href="/source/s?defs=STATUS_ACCESS_DENIED&amp;project=rtmp_client">STATUS_ACCESS_DENIED</a>);
<a class="l" name="205" href="#205">205</a>			<b>return</b> <b>false</b>;
<a class="l" name="206" href="#206">206</a>		} <b>catch</b> (<a href="/source/s?defs=IllegalAccessException&amp;project=rtmp_client">IllegalAccessException</a> <a href="/source/s?defs=accessEx&amp;project=rtmp_client">accessEx</a>) {
<a class="l" name="207" href="#207">207</a>			<a class="d" href="#call">call</a>.<a href="/source/s?defs=setException&amp;project=rtmp_client">setException</a>(<a href="/source/s?defs=accessEx&amp;project=rtmp_client">accessEx</a>);
<a class="l" name="208" href="#208">208</a>			<a class="d" href="#call">call</a>.<a href="/source/s?defs=setStatus&amp;project=rtmp_client">setStatus</a>(<a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>.<a href="/source/s?defs=STATUS_ACCESS_DENIED&amp;project=rtmp_client">STATUS_ACCESS_DENIED</a>);
<a class="l" name="209" href="#209">209</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error executing call: {}"</span>, <a class="d" href="#call">call</a>);
<a class="hl" name="210" href="#210">210</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Service invocation error"</span>, <a href="/source/s?defs=accessEx&amp;project=rtmp_client">accessEx</a>);
<a class="l" name="211" href="#211">211</a>			<b>return</b> <b>false</b>;
<a class="l" name="212" href="#212">212</a>		} <b>catch</b> (<a href="/source/s?defs=InvocationTargetException&amp;project=rtmp_client">InvocationTargetException</a> <a href="/source/s?defs=invocationEx&amp;project=rtmp_client">invocationEx</a>) {
<a class="l" name="213" href="#213">213</a>			<a class="d" href="#call">call</a>.<a href="/source/s?defs=setException&amp;project=rtmp_client">setException</a>(<a href="/source/s?defs=invocationEx&amp;project=rtmp_client">invocationEx</a>);
<a class="l" name="214" href="#214">214</a>			<a class="d" href="#call">call</a>.<a href="/source/s?defs=setStatus&amp;project=rtmp_client">setStatus</a>(<a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>.<a href="/source/s?defs=STATUS_INVOCATION_EXCEPTION&amp;project=rtmp_client">STATUS_INVOCATION_EXCEPTION</a>);
<a class="l" name="215" href="#215">215</a>			<b>if</b> (!(<a href="/source/s?defs=invocationEx&amp;project=rtmp_client">invocationEx</a>.<a href="/source/s?defs=getCause&amp;project=rtmp_client">getCause</a>() <b>instanceof</b> <a href="/source/s?defs=ClientDetailsException&amp;project=rtmp_client">ClientDetailsException</a>)) {
<a class="l" name="216" href="#216">216</a>				<span class="c">// Only log if not handled by client</span>
<a class="l" name="217" href="#217">217</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error executing call: {}"</span>, <a class="d" href="#call">call</a>);
<a class="l" name="218" href="#218">218</a>				<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Service invocation error"</span>, <a href="/source/s?defs=invocationEx&amp;project=rtmp_client">invocationEx</a>);
<a class="l" name="219" href="#219">219</a>			}
<a class="hl" name="220" href="#220">220</a>			<b>return</b> <b>false</b>;
<a class="l" name="221" href="#221">221</a>		} <b>catch</b> (<a href="/source/s?defs=Exception&amp;project=rtmp_client">Exception</a> <a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>) {
<a class="l" name="222" href="#222">222</a>			<a class="d" href="#call">call</a>.<a href="/source/s?defs=setException&amp;project=rtmp_client">setException</a>(<a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>);
<a class="l" name="223" href="#223">223</a>			<a class="d" href="#call">call</a>.<a href="/source/s?defs=setStatus&amp;project=rtmp_client">setStatus</a>(<a href="/source/s?defs=Call&amp;project=rtmp_client">Call</a>.<a href="/source/s?defs=STATUS_GENERAL_EXCEPTION&amp;project=rtmp_client">STATUS_GENERAL_EXCEPTION</a>);
<a class="l" name="224" href="#224">224</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Error executing call: {}"</span>, <a class="d" href="#call">call</a>);
<a class="l" name="225" href="#225">225</a>			<a class="d" href="#log">log</a>.<a href="/source/s?defs=error&amp;project=rtmp_client">error</a>(<span class="s">"Service invocation error"</span>, <a href="/source/s?defs=ex&amp;project=rtmp_client">ex</a>);
<a class="l" name="226" href="#226">226</a>			<b>return</b> <b>false</b>;
<a class="l" name="227" href="#227">227</a>		}
<a class="l" name="228" href="#228">228</a>		<b>return</b> <b>true</b>;
<a class="l" name="229" href="#229">229</a>	}
<a class="hl" name="230" href="#230">230</a>
<a class="l" name="231" href="#231">231</a>}
<a class="l" name="232" href="#232">232</a>