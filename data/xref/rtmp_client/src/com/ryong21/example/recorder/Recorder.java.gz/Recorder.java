<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["Recorder",8]]],["Package","xp",[["com.ryong21.example.recorder",1]]],["Method","xmt",[["main",12]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=com&amp;project=rtmp_client">com</a>.<a href="/source/s?defs=ryong21&amp;project=rtmp_client">ryong21</a>.<a href="/source/s?defs=example&amp;project=rtmp_client">example</a>.<a href="/source/s?defs=recorder&amp;project=rtmp_client">recorder</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="4" href="#4">4</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a><b>import</b> <a href="/source/s?defs=com&amp;project=rtmp_client">com</a>.<a href="/source/s?defs=ryong21&amp;project=rtmp_client">ryong21</a>.<a href="/source/s?defs=example&amp;project=rtmp_client">example</a>.<a href="/source/s?defs=recorder&amp;project=rtmp_client">recorder</a>.<a href="/source/s?defs=RecorderClient&amp;project=rtmp_client">RecorderClient</a>;
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a><b>public</b> <b>class</b> <a class="xc" name="Recorder"/><a href="/source/s?refs=Recorder&amp;project=rtmp_client" class="xc">Recorder</a> {
<a class="l" name="9" href="#9">9</a>
<a class="hl" name="10" href="#10">10</a>	<b>protected</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a class="d" href="#Recorder">Recorder</a>.<b>class</b>);
<a class="l" name="11" href="#11">11</a>
<a class="l" name="12" href="#12">12</a>	<b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="main"/><a href="/source/s?refs=main&amp;project=rtmp_client" class="xmt">main</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>[] <a class="xa" name="args"/><a href="/source/s?refs=args&amp;project=rtmp_client" class="xa">args</a>) {
<a class="l" name="13" href="#13">13</a>
<a class="l" name="14" href="#14">14</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=playFileName&amp;project=rtmp_client">playFileName</a> = <span class="s">"2.mp3"</span>;
<a class="l" name="15" href="#15">15</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=saveAsFileName&amp;project=rtmp_client">saveAsFileName</a> = <span class="s">"22.flv"</span>;
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=host&amp;project=rtmp_client">host</a> = <span class="s">"192.168.1.200"</span>;
<a class="l" name="18" href="#18">18</a>		<b>int</b> <a href="/source/s?defs=port&amp;project=rtmp_client">port</a> = <span class="n">1935</span>;
<a class="l" name="19" href="#19">19</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=app&amp;project=rtmp_client">app</a> = <span class="s">"vod"</span>;
<a class="hl" name="20" href="#20">20</a>
<a class="l" name="21" href="#21">21</a>		<a href="/source/s?defs=RecorderClient&amp;project=rtmp_client">RecorderClient</a> <a href="/source/s?defs=client&amp;project=rtmp_client">client</a> = <b>new</b> <a href="/source/s?defs=RecorderClient&amp;project=rtmp_client">RecorderClient</a>();
<a class="l" name="22" href="#22">22</a>		<a href="/source/s?defs=client&amp;project=rtmp_client">client</a>.<a href="/source/s?defs=setHost&amp;project=rtmp_client">setHost</a>(<a href="/source/s?defs=host&amp;project=rtmp_client">host</a>);
<a class="l" name="23" href="#23">23</a>		<a href="/source/s?defs=client&amp;project=rtmp_client">client</a>.<a href="/source/s?defs=setPort&amp;project=rtmp_client">setPort</a>(<a href="/source/s?defs=port&amp;project=rtmp_client">port</a>);
<a class="l" name="24" href="#24">24</a>		<a href="/source/s?defs=client&amp;project=rtmp_client">client</a>.<a href="/source/s?defs=setApp&amp;project=rtmp_client">setApp</a>(<a href="/source/s?defs=app&amp;project=rtmp_client">app</a>);
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a>		<a href="/source/s?defs=client&amp;project=rtmp_client">client</a>.<a href="/source/s?defs=start&amp;project=rtmp_client">start</a>(<a href="/source/s?defs=playFileName&amp;project=rtmp_client">playFileName</a>, <a href="/source/s?defs=saveAsFileName&amp;project=rtmp_client">saveAsFileName</a>);
<a class="l" name="27" href="#27">27</a>	}
<a class="l" name="28" href="#28">28</a>}
<a class="l" name="29" href="#29">29</a>