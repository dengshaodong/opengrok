<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["PublishClient",23]]],["Package","xp",[["com.ryong21.example.publisher",1]]],["Method","xmt",[["getState",55],["onStreamEvent",97],["pushMessage",88],["resultReceived",110],["setApp",67],["setHost",59],["setPort",63],["start",71],["stop",81]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>package</b> <a href="/source/s?defs=com&amp;project=rtmp_client">com</a>.<a href="/source/s?defs=ryong21&amp;project=rtmp_client">ryong21</a>.<a href="/source/s?defs=example&amp;project=rtmp_client">example</a>.<a href="/source/s?defs=publisher&amp;project=rtmp_client">publisher</a>;
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a>;
<a class="l" name="4" href="#4">4</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>;
<a class="l" name="5" href="#5">5</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=List&amp;project=rtmp_client">List</a>;
<a class="l" name="6" href="#6">6</a><b>import</b> <a href="/source/s?defs=java&amp;project=rtmp_client">java</a>.<a href="/source/s?defs=util&amp;project=rtmp_client">util</a>.<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>;
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=io&amp;project=rtmp_client">io</a>.<a href="/source/s?defs=utils&amp;project=rtmp_client">utils</a>.<a href="/source/s?defs=ObjectMap&amp;project=rtmp_client">ObjectMap</a>;
<a class="l" name="9" href="#9">9</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=messaging&amp;project=rtmp_client">messaging</a>.<a href="/source/s?defs=IMessage&amp;project=rtmp_client">IMessage</a>;
<a class="hl" name="10" href="#10">10</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=INetStreamEventHandler&amp;project=rtmp_client">INetStreamEventHandler</a>;
<a class="l" name="11" href="#11">11</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=RTMPClient&amp;project=rtmp_client">RTMPClient</a>;
<a class="l" name="12" href="#12">12</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=event&amp;project=rtmp_client">event</a>.<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a>;
<a class="l" name="13" href="#13">13</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=net&amp;project=rtmp_client">net</a>.<a href="/source/s?defs=rtmp&amp;project=rtmp_client">rtmp</a>.<a href="/source/s?defs=status&amp;project=rtmp_client">status</a>.<a href="/source/s?defs=StatusCodes&amp;project=rtmp_client">StatusCodes</a>;
<a class="l" name="14" href="#14">14</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a>;
<a class="l" name="15" href="#15">15</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=service&amp;project=rtmp_client">service</a>.<a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a>;
<a class="l" name="16" href="#16">16</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=red5&amp;project=rtmp_client">red5</a>.<a href="/source/s?defs=server&amp;project=rtmp_client">server</a>.<a href="/source/s?defs=stream&amp;project=rtmp_client">stream</a>.<a class="d" href="#message">message</a>.<a href="/source/s?defs=RTMPMessage&amp;project=rtmp_client">RTMPMessage</a>;
<a class="l" name="17" href="#17">17</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a>;
<a class="l" name="18" href="#18">18</a><b>import</b> <a href="/source/s?defs=org&amp;project=rtmp_client">org</a>.<a href="/source/s?defs=slf4j&amp;project=rtmp_client">slf4j</a>.<a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>;
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a><span class="c">/**
<a class="l" name="21" href="#21">21</a> * A publish client  publish stream to server.
<a class="l" name="22" href="#22">22</a> */</span>
<a class="l" name="23" href="#23">23</a><b>public</b> <b>class</b> <a class="xc" name="PublishClient"/><a href="/source/s?refs=PublishClient&amp;project=rtmp_client" class="xc">PublishClient</a> <b>implements</b> <a href="/source/s?defs=INetStreamEventHandler&amp;project=rtmp_client">INetStreamEventHandler</a>, <a href="/source/s?defs=IPendingServiceCallback&amp;project=rtmp_client">IPendingServiceCallback</a> {
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a>	<b>private</b> <b>static</b> <a href="/source/s?defs=Logger&amp;project=rtmp_client">Logger</a> <a class="xfld" name="log"/><a href="/source/s?refs=log&amp;project=rtmp_client" class="xfld">log</a> = <a href="/source/s?defs=LoggerFactory&amp;project=rtmp_client">LoggerFactory</a>.<a href="/source/s?defs=getLogger&amp;project=rtmp_client">getLogger</a>(<a class="d" href="#PublishClient">PublishClient</a>.<b>class</b>);
<a class="l" name="26" href="#26">26</a>
<a class="l" name="27" href="#27">27</a>	<b>private</b> <a href="/source/s?defs=List&amp;project=rtmp_client">List</a>&lt;<a href="/source/s?defs=IMessage&amp;project=rtmp_client">IMessage</a>&gt; <a class="xfld" name="frameBuffer"/><a href="/source/s?refs=frameBuffer&amp;project=rtmp_client" class="xfld">frameBuffer</a> = <b>new</b> <a href="/source/s?defs=ArrayList&amp;project=rtmp_client">ArrayList</a>&lt;<a href="/source/s?defs=IMessage&amp;project=rtmp_client">IMessage</a>&gt;();
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a>	<b>public</b> <b>static</b> <b>final</b> <b>int</b> <a class="xfld" name="STOPPED"/><a href="/source/s?refs=STOPPED&amp;project=rtmp_client" class="xfld">STOPPED</a> = <span class="n">0</span>;
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a>	<b>public</b> <b>static</b> <b>final</b> <b>int</b> <a class="xfld" name="CONNECTING"/><a href="/source/s?refs=CONNECTING&amp;project=rtmp_client" class="xfld">CONNECTING</a> = <span class="n">1</span>;
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a>	<b>public</b> <b>static</b> <b>final</b> <b>int</b> <a class="xfld" name="STREAM_CREATING"/><a href="/source/s?refs=STREAM_CREATING&amp;project=rtmp_client" class="xfld">STREAM_CREATING</a> = <span class="n">2</span>;
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a>	<b>public</b> <b>static</b> <b>final</b> <b>int</b> <a class="xfld" name="PUBLISHING"/><a href="/source/s?refs=PUBLISHING&amp;project=rtmp_client" class="xfld">PUBLISHING</a> = <span class="n">3</span>;
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a>	<b>public</b> <b>static</b> <b>final</b> <b>int</b> <a class="xfld" name="PUBLISHED"/><a href="/source/s?refs=PUBLISHED&amp;project=rtmp_client" class="xfld">PUBLISHED</a> = <span class="n">4</span>;
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>	<b>private</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="host"/><a href="/source/s?refs=host&amp;project=rtmp_client" class="xfld">host</a>;
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a>	<b>private</b> <b>int</b> <a class="xfld" name="port"/><a href="/source/s?refs=port&amp;project=rtmp_client" class="xfld">port</a>;
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a>	<b>private</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="app"/><a href="/source/s?refs=app&amp;project=rtmp_client" class="xfld">app</a>;
<a class="l" name="44" href="#44">44</a>
<a class="l" name="45" href="#45">45</a>	<b>private</b> <b>int</b> <a class="xfld" name="state"/><a href="/source/s?refs=state&amp;project=rtmp_client" class="xfld">state</a>;
<a class="l" name="46" href="#46">46</a>
<a class="l" name="47" href="#47">47</a>	<b>private</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="publishName"/><a href="/source/s?refs=publishName&amp;project=rtmp_client" class="xfld">publishName</a>;
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>	<b>private</b> <b>int</b> <a class="xfld" name="streamId"/><a href="/source/s?refs=streamId&amp;project=rtmp_client" class="xfld">streamId</a>;
<a class="hl" name="50" href="#50">50</a>
<a class="l" name="51" href="#51">51</a>	<b>private</b> <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xfld" name="publishMode"/><a href="/source/s?refs=publishMode&amp;project=rtmp_client" class="xfld">publishMode</a>;
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>	<b>private</b> <a href="/source/s?defs=RTMPClient&amp;project=rtmp_client">RTMPClient</a> <a class="xfld" name="rtmpClient"/><a href="/source/s?refs=rtmpClient&amp;project=rtmp_client" class="xfld">rtmpClient</a>;
<a class="l" name="54" href="#54">54</a>
<a class="l" name="55" href="#55">55</a>	<b>public</b> <b>int</b> <a class="xmt" name="getState"/><a href="/source/s?refs=getState&amp;project=rtmp_client" class="xmt">getState</a>() {
<a class="l" name="56" href="#56">56</a>		<b>return</b> <a class="d" href="#state">state</a>;
<a class="l" name="57" href="#57">57</a>	}
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a>	<b>public</b> <b>void</b> <a class="xmt" name="setHost"/><a href="/source/s?refs=setHost&amp;project=rtmp_client" class="xmt">setHost</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="host"/><a href="/source/s?refs=host&amp;project=rtmp_client" class="xa">host</a>) {
<a class="hl" name="60" href="#60">60</a>		<b>this</b>.<a href="/source/s?defs=host&amp;project=rtmp_client">host</a> = <a href="/source/s?defs=host&amp;project=rtmp_client">host</a>;
<a class="l" name="61" href="#61">61</a>	}
<a class="l" name="62" href="#62">62</a>
<a class="l" name="63" href="#63">63</a>	<b>public</b> <b>void</b> <a class="xmt" name="setPort"/><a href="/source/s?refs=setPort&amp;project=rtmp_client" class="xmt">setPort</a>(<b>int</b> <a class="xa" name="port"/><a href="/source/s?refs=port&amp;project=rtmp_client" class="xa">port</a>) {
<a class="l" name="64" href="#64">64</a>		<b>this</b>.<a href="/source/s?defs=port&amp;project=rtmp_client">port</a> = <a href="/source/s?defs=port&amp;project=rtmp_client">port</a>;
<a class="l" name="65" href="#65">65</a>	}
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a>	<b>public</b> <b>void</b> <a class="xmt" name="setApp"/><a href="/source/s?refs=setApp&amp;project=rtmp_client" class="xmt">setApp</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="app"/><a href="/source/s?refs=app&amp;project=rtmp_client" class="xa">app</a>) {
<a class="l" name="68" href="#68">68</a>		<b>this</b>.<a href="/source/s?defs=app&amp;project=rtmp_client">app</a> = <a href="/source/s?defs=app&amp;project=rtmp_client">app</a>;
<a class="l" name="69" href="#69">69</a>	}
<a class="hl" name="70" href="#70">70</a>
<a class="l" name="71" href="#71">71</a>	<b>public</b> <b>synchronized</b> <b>void</b> <a class="xmt" name="start"/><a href="/source/s?refs=start&amp;project=rtmp_client" class="xmt">start</a>(<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="publishName"/><a href="/source/s?refs=publishName&amp;project=rtmp_client" class="xa">publishName</a>, <a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a class="xa" name="publishMode"/><a href="/source/s?refs=publishMode&amp;project=rtmp_client" class="xa">publishMode</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>[] <a class="xa" name="params"/><a href="/source/s?refs=params&amp;project=rtmp_client" class="xa">params</a>) {
<a class="l" name="72" href="#72">72</a>		<a class="d" href="#state">state</a> = <a class="d" href="#CONNECTING">CONNECTING</a>;
<a class="l" name="73" href="#73">73</a>		<b>this</b>.<a href="/source/s?defs=publishName&amp;project=rtmp_client">publishName</a> = <a href="/source/s?defs=publishName&amp;project=rtmp_client">publishName</a>;
<a class="l" name="74" href="#74">74</a>		<b>this</b>.<a href="/source/s?defs=publishMode&amp;project=rtmp_client">publishMode</a> = <a href="/source/s?defs=publishMode&amp;project=rtmp_client">publishMode</a>;
<a class="l" name="75" href="#75">75</a>		<a class="d" href="#rtmpClient">rtmpClient</a> = <b>new</b> <a href="/source/s?defs=RTMPClient&amp;project=rtmp_client">RTMPClient</a>();
<a class="l" name="76" href="#76">76</a>
<a class="l" name="77" href="#77">77</a>		<a href="/source/s?defs=Map&amp;project=rtmp_client">Map</a>&lt;<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>, <a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a>&gt; <a href="/source/s?defs=defParams&amp;project=rtmp_client">defParams</a> = <a class="d" href="#rtmpClient">rtmpClient</a>.<a href="/source/s?defs=makeDefaultConnectionParams&amp;project=rtmp_client">makeDefaultConnectionParams</a>(<a href="/source/s?defs=host&amp;project=rtmp_client">host</a>, <a href="/source/s?defs=port&amp;project=rtmp_client">port</a>, <a href="/source/s?defs=app&amp;project=rtmp_client">app</a>);
<a class="l" name="78" href="#78">78</a>		<a class="d" href="#rtmpClient">rtmpClient</a>.<a href="/source/s?defs=connect&amp;project=rtmp_client">connect</a>(<a href="/source/s?defs=host&amp;project=rtmp_client">host</a>, <a href="/source/s?defs=port&amp;project=rtmp_client">port</a>, <a href="/source/s?defs=defParams&amp;project=rtmp_client">defParams</a>, <b>this</b>, <a class="d" href="#params">params</a>);
<a class="l" name="79" href="#79">79</a>	}
<a class="hl" name="80" href="#80">80</a>
<a class="l" name="81" href="#81">81</a>	<b>public</b> <b>synchronized</b> <b>void</b> <a class="xmt" name="stop"/><a href="/source/s?refs=stop&amp;project=rtmp_client" class="xmt">stop</a>() {
<a class="l" name="82" href="#82">82</a>		<b>if</b> (<a class="d" href="#state">state</a> &gt;= <a class="d" href="#STREAM_CREATING">STREAM_CREATING</a>) {
<a class="l" name="83" href="#83">83</a>			<a class="d" href="#rtmpClient">rtmpClient</a>.<a href="/source/s?defs=disconnect&amp;project=rtmp_client">disconnect</a>();
<a class="l" name="84" href="#84">84</a>		}
<a class="l" name="85" href="#85">85</a>		<a class="d" href="#state">state</a> = <a class="d" href="#STOPPED">STOPPED</a>;
<a class="l" name="86" href="#86">86</a>	}
<a class="l" name="87" href="#87">87</a>
<a class="l" name="88" href="#88">88</a>	<b>synchronized</b> <b>public</b> <b>void</b> <a class="xmt" name="pushMessage"/><a href="/source/s?refs=pushMessage&amp;project=rtmp_client" class="xmt">pushMessage</a>(<a href="/source/s?defs=IMessage&amp;project=rtmp_client">IMessage</a> <a class="xa" name="message"/><a href="/source/s?refs=message&amp;project=rtmp_client" class="xa">message</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=rtmp_client">IOException</a> {
<a class="l" name="89" href="#89">89</a>		<b>if</b> (<a class="d" href="#state">state</a> &gt;= <a class="d" href="#PUBLISHED">PUBLISHED</a> &amp;&amp; <a class="d" href="#message">message</a> <b>instanceof</b> <a href="/source/s?defs=RTMPMessage&amp;project=rtmp_client">RTMPMessage</a>) {
<a class="hl" name="90" href="#90">90</a>			<a href="/source/s?defs=RTMPMessage&amp;project=rtmp_client">RTMPMessage</a> <a href="/source/s?defs=rtmpMsg&amp;project=rtmp_client">rtmpMsg</a> = (<a href="/source/s?defs=RTMPMessage&amp;project=rtmp_client">RTMPMessage</a>) <a class="d" href="#message">message</a>;
<a class="l" name="91" href="#91">91</a>			<a class="d" href="#rtmpClient">rtmpClient</a>.<a href="/source/s?defs=publishStreamData&amp;project=rtmp_client">publishStreamData</a>(<a class="d" href="#streamId">streamId</a>, <a href="/source/s?defs=rtmpMsg&amp;project=rtmp_client">rtmpMsg</a>);
<a class="l" name="92" href="#92">92</a>		} <b>else</b> {
<a class="l" name="93" href="#93">93</a>			<a class="d" href="#frameBuffer">frameBuffer</a>.<a href="/source/s?defs=add&amp;project=rtmp_client">add</a>(<a class="d" href="#message">message</a>);
<a class="l" name="94" href="#94">94</a>		}
<a class="l" name="95" href="#95">95</a>	}
<a class="l" name="96" href="#96">96</a>
<a class="l" name="97" href="#97">97</a>	<b>public</b> <b>synchronized</b> <b>void</b> <a class="xmt" name="onStreamEvent"/><a href="/source/s?refs=onStreamEvent&amp;project=rtmp_client" class="xmt">onStreamEvent</a>(<a href="/source/s?defs=Notify&amp;project=rtmp_client">Notify</a> <a class="xa" name="notify"/><a href="/source/s?refs=notify&amp;project=rtmp_client" class="xa">notify</a>) {
<a class="l" name="98" href="#98">98</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"onStreamEvent: {}"</span>, <a class="d" href="#notify">notify</a>);
<a class="l" name="99" href="#99">99</a>		<a href="/source/s?defs=ObjectMap&amp;project=rtmp_client">ObjectMap</a>&lt;?, ?&gt; <a href="/source/s?defs=map&amp;project=rtmp_client">map</a> = (<a href="/source/s?defs=ObjectMap&amp;project=rtmp_client">ObjectMap</a>&lt;?, ?&gt;) <a class="d" href="#notify">notify</a>.<a href="/source/s?defs=getCall&amp;project=rtmp_client">getCall</a>().<a href="/source/s?defs=getArguments&amp;project=rtmp_client">getArguments</a>()[<span class="n">0</span>];
<a class="hl" name="100" href="#100">100</a>		<a href="/source/s?defs=String&amp;project=rtmp_client">String</a> <a href="/source/s?defs=code&amp;project=rtmp_client">code</a> = (<a href="/source/s?defs=String&amp;project=rtmp_client">String</a>) <a href="/source/s?defs=map&amp;project=rtmp_client">map</a>.<a href="/source/s?defs=get&amp;project=rtmp_client">get</a>(<span class="s">"code"</span>);
<a class="l" name="101" href="#101">101</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"&lt;:{}"</span>, <a href="/source/s?defs=code&amp;project=rtmp_client">code</a>);
<a class="l" name="102" href="#102">102</a>		<b>if</b> (<a href="/source/s?defs=StatusCodes&amp;project=rtmp_client">StatusCodes</a>.<a href="/source/s?defs=NS_PUBLISH_START&amp;project=rtmp_client">NS_PUBLISH_START</a>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a href="/source/s?defs=code&amp;project=rtmp_client">code</a>)) {
<a class="l" name="103" href="#103">103</a>			<a class="d" href="#state">state</a> = <a class="d" href="#PUBLISHED">PUBLISHED</a>;
<a class="l" name="104" href="#104">104</a>			<b>while</b> (<a class="d" href="#frameBuffer">frameBuffer</a>.<a href="/source/s?defs=size&amp;project=rtmp_client">size</a>() &gt; <span class="n">0</span>) {
<a class="l" name="105" href="#105">105</a>				<a class="d" href="#rtmpClient">rtmpClient</a>.<a href="/source/s?defs=publishStreamData&amp;project=rtmp_client">publishStreamData</a>(<a class="d" href="#streamId">streamId</a>, <a class="d" href="#frameBuffer">frameBuffer</a>.<a href="/source/s?defs=remove&amp;project=rtmp_client">remove</a>(<span class="n">0</span>));
<a class="l" name="106" href="#106">106</a>			}
<a class="l" name="107" href="#107">107</a>		}
<a class="l" name="108" href="#108">108</a>	}
<a class="l" name="109" href="#109">109</a>
<a class="hl" name="110" href="#110">110</a>	<b>public</b> <b>synchronized</b> <b>void</b> <a class="xmt" name="resultReceived"/><a href="/source/s?refs=resultReceived&amp;project=rtmp_client" class="xmt">resultReceived</a>(<a href="/source/s?defs=IPendingServiceCall&amp;project=rtmp_client">IPendingServiceCall</a> <a class="xa" name="call"/><a href="/source/s?refs=call&amp;project=rtmp_client" class="xa">call</a>) {
<a class="l" name="111" href="#111">111</a>		<a class="d" href="#log">log</a>.<a href="/source/s?defs=debug&amp;project=rtmp_client">debug</a>(<span class="s">"resultReceived:&gt; {}"</span>, <a class="d" href="#call">call</a>.<a href="/source/s?defs=getServiceMethodName&amp;project=rtmp_client">getServiceMethodName</a>());
<a class="l" name="112" href="#112">112</a>		<b>if</b> (<span class="s">"connect"</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a class="d" href="#call">call</a>.<a href="/source/s?defs=getServiceMethodName&amp;project=rtmp_client">getServiceMethodName</a>())) {
<a class="l" name="113" href="#113">113</a>			<a class="d" href="#state">state</a> = <a class="d" href="#STREAM_CREATING">STREAM_CREATING</a>;
<a class="l" name="114" href="#114">114</a>			<a class="d" href="#rtmpClient">rtmpClient</a>.<a href="/source/s?defs=createStream&amp;project=rtmp_client">createStream</a>(<b>this</b>);
<a class="l" name="115" href="#115">115</a>		} <b>else</b> <b>if</b> (<span class="s">"createStream"</span>.<a href="/source/s?defs=equals&amp;project=rtmp_client">equals</a>(<a class="d" href="#call">call</a>.<a href="/source/s?defs=getServiceMethodName&amp;project=rtmp_client">getServiceMethodName</a>())) {
<a class="l" name="116" href="#116">116</a>			<a class="d" href="#state">state</a> = <a class="d" href="#PUBLISHING">PUBLISHING</a>;
<a class="l" name="117" href="#117">117</a>			<a href="/source/s?defs=Object&amp;project=rtmp_client">Object</a> <a href="/source/s?defs=result&amp;project=rtmp_client">result</a> = <a class="d" href="#call">call</a>.<a href="/source/s?defs=getResult&amp;project=rtmp_client">getResult</a>();
<a class="l" name="118" href="#118">118</a>			<b>if</b> (<a href="/source/s?defs=result&amp;project=rtmp_client">result</a> <b>instanceof</b> <a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>) {
<a class="l" name="119" href="#119">119</a>				<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a> <a href="/source/s?defs=streamIdInt&amp;project=rtmp_client">streamIdInt</a> = (<a href="/source/s?defs=Integer&amp;project=rtmp_client">Integer</a>) <a href="/source/s?defs=result&amp;project=rtmp_client">result</a>;
<a class="hl" name="120" href="#120">120</a>				<a class="d" href="#streamId">streamId</a> = <a href="/source/s?defs=streamIdInt&amp;project=rtmp_client">streamIdInt</a>.<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>();
<a class="l" name="121" href="#121">121</a>				<a class="d" href="#rtmpClient">rtmpClient</a>.<a href="/source/s?defs=publish&amp;project=rtmp_client">publish</a>(<a href="/source/s?defs=streamIdInt&amp;project=rtmp_client">streamIdInt</a>.<a href="/source/s?defs=intValue&amp;project=rtmp_client">intValue</a>(), <a href="/source/s?defs=publishName&amp;project=rtmp_client">publishName</a>, <a href="/source/s?defs=publishMode&amp;project=rtmp_client">publishMode</a>, <b>this</b>);
<a class="l" name="122" href="#122">122</a>			} <b>else</b> {
<a class="l" name="123" href="#123">123</a>				<a class="d" href="#rtmpClient">rtmpClient</a>.<a href="/source/s?defs=disconnect&amp;project=rtmp_client">disconnect</a>();
<a class="l" name="124" href="#124">124</a>				<a class="d" href="#state">state</a> = <a class="d" href="#STOPPED">STOPPED</a>;
<a class="l" name="125" href="#125">125</a>			}
<a class="l" name="126" href="#126">126</a>		}
<a class="l" name="127" href="#127">127</a>	}
<a class="l" name="128" href="#128">128</a>}
<a class="l" name="129" href="#129">129</a>